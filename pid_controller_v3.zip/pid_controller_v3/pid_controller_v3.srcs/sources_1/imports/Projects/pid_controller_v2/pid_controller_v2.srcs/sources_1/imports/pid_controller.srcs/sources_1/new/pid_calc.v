`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/25/2026 12:01:55 AM
// Design Name: 
// Module Name: pid_calc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pid_calc(
    input            [0:0]  clock,
    input   signed  [31:0]  angle,
    
    input   signed  [31:0]  target_angle, 
    input            [0:0]  new_target_angle_available,
    
    input   signed   [8:0]  kp,
    input   signed   [8:0]  ki,
    input   signed   [8:0]  kd,
    
    output  signed  [31:0]  output_velocity,
    output           [0:0]  new_velocity_available
    
    );
    
    // pre calculation registers 
    reg     signed  [31:0]  error;
    reg     signed  [31:0]  error_prev;
    reg     signed  [31:0]  integral; 
    reg     signed  [31:0]  integral_prev; 
    reg     signed  [31:0]  derivative;
    reg     signed  [31:0]  saved_target_angle; 
    // term calculation registers 
    reg     signed  [41:0]  p_term; 
    reg     signed  [41:0]  i_term; 
    reg     signed  [41:0]  d_term; 
    // velocity calculation registers 
    reg     signed  [73:0]  interim_velocity; 
    reg     signed  [31:0]  velocity; 
    reg              [0:0]  nv_flag; 
    
    
    // wire assignments 
    assign output_velocity = velocity; 
    assign new_velocity_available = nv_flag; 
    
    // initialization 
    initial begin 
        error <= 0; 
        error_prev <= 0; 
        integral <= 0; 
        integral_prev <= 0; 
        derivative <= 0; 
        saved_target_angle <= 0; 
        p_term <= 0; 
        i_term <= 0; 
        d_term <= 0; 
        interim_velocity <= 0;
        velocity <= 0; 
        nv_flag <= 0; 
    end
    
    always @(posedge clock) begin 
        // initial math 
        if (new_target_angle_available == 1) begin 
            saved_target_angle <= target_angle; 
            integral <= 0;
            error <= saved_target_angle - angle; 
        end 
        else begin 
            error <= saved_target_angle - angle; 
            integral <= integral_prev + (error >>> 6); 
        end 
        derivative <= (error - error_prev) <<< 6; 
        error_prev <= error; 
        integral_prev <= integral; 
    
        // term calculation 
        p_term <= kp * error; 
        i_term <= ki * integral; 
        d_term <= kd * derivative; 
        
        // velocity calculation 
        interim_velocity <= (p_term + i_term + d_term); 
        if (((velocity - interim_velocity) > 32'sd16) || ((interim_velocity - velocity) > 32'sd16)) begin 
            velocity <= interim_velocity; 
            nv_flag <= 1; 
        end 
        else begin 
            nv_flag <= 0; 
        end
    
    end 
    
    
endmodule
