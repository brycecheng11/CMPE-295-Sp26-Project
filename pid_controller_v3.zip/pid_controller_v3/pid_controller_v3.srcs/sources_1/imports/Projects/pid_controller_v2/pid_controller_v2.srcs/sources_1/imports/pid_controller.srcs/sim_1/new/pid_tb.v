`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 07:53:54 PM
// Design Name: 
// Module Name: pid_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pid_tb;


    reg [31:0] angle_0;
    reg [11:0] kd_0;
    reg [11:0] ki_0;
    reg [11:0] kp_0;
    reg        new_target_angle_available_0;
    reg        sys_clock;
    reg [31:0] target_angle_0;


    wire [31:0] output_velocity_0;
    wire        new_velocity_available_0;


    pid_reexpanded uut (
        .angle_0(angle_0),
        .kd_in_0(kd_0),
        .ki_in_0(ki_0),
        .kp_in_0(kp_0),
        .new_target_angle_available_0(new_target_angle_available_0),
        .new_velocity_available_0(new_velocity_available_0),
        .output_velocity_0(output_velocity_0),
        .sys_clk(sys_clock),
        .target_angle_0(target_angle_0)
    );


    always #1 sys_clock = ~sys_clock;

    initial begin
        sys_clock = 0;
        angle_0 = 32'sd90;
        target_angle_0 = 32'd0;
        kp_0 = 12'h100; 
        ki_0 = 12'h50; 
        kd_0 = 12'h25; 


        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b1;
        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b0;

        angle_0 = 32'sd45; 
        repeat (500) begin
            #10000; 
//            angle_0 = angle_0 + 32'sd5;
        end

        target_angle_0 = 32'sd5; 
        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b1;
        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b0;

        angle_0 = angle_0 - 32'sd90;
        repeat (500) begin
            #10000;
//            angle_0 = angle_0 - 32'sd4;
        end

        $finish;
    end


endmodule
