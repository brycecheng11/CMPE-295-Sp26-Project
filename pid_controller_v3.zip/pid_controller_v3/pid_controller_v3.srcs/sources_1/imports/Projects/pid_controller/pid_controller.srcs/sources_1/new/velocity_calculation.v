`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 07:39:45 PM
// Design Name: 
// Module Name: velocity_calculation
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module velocity_calculation(
    input                   clock,
    input   signed  [31:0]  p_term,
    input   signed  [31:0]  i_term,
    input   signed  [31:0]  d_term,
    output  signed  [31:0]  output_velocity,
    output                  new_velocity_available
    );
    
    reg     signed  [31:0]  interim; 
    reg     signed  [31:0]  velocity; 
    reg                     nv_flag; 
    
    assign output_velocity = velocity; 
    assign new_velocity_available = nv_flag; 
    
    initial begin 
        interim = 0; 
        velocity = 0; 
        nv_flag = 0; 
    end 
    
    always @(posedge clock) begin 
        interim <= (p_term + i_term + d_term) >>> 11; 
        if (((velocity - interim) > 32'sd16) || ((interim - velocity) > 32'sd16)) begin 
            velocity <= interim; 
            nv_flag <= 1; 
        end 
        else begin 
            nv_flag <= 0; 
        end
    
   end 
    
endmodule
