`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 04:59:40 PM
// Design Name: 
// Module Name: initial_math
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module initial_math(
    input                   clock,
    input   signed  [31:0]  angle,
    
    input   signed  [31:0]  target_angle, 
    input                   new_target_angle_available,
    
    input   signed  [31:0]  error_in,
    input   signed  [31:0]  integral_in,
    
    output  signed  [31:0]  error_out,
    output  signed  [31:0]  integral_out, 
    output  signed  [31:0]  derivative_out, 
    output  signed  [31:0]  angle_out
    );
    
    reg                     clock_count; 
    
    reg     signed  [31:0]  error;
    reg     signed  [31:0]  integral; 
    reg     signed  [31:0]  derivative;
    
    reg     signed  [31:0]  saved_angle; 
    reg     signed  [31:0]  saved_target_angle; 
    
    assign error_out = error; 
    assign integral_out = integral; 
    assign derivative_out = derivative; 
    assign angle_out = saved_angle; 
    
    initial begin 
        error <= 0; 
        integral <= 0; 
        derivative <= 0; 
        saved_angle <= 0;
        saved_target_angle <= 0; 
        clock_count <= 0; 
    end 
    
    always @ (posedge clock) begin 
        saved_angle <= angle; 
        if (clock_count == 0) begin 
            clock_count = 1; 
            integral <= 0;
        end 
        else begin 
            if (new_target_angle_available == 1'b1) begin 
                clock_count = 0; 
                saved_target_angle <= target_angle; 
            end 
            else begin 
                error <= saved_target_angle - angle; 
                integral <= integral_in + (error >>> 5); 
                derivative <= (error - error_in) <<< 5; 
            end 
        end
    end
    
    
    
endmodule
