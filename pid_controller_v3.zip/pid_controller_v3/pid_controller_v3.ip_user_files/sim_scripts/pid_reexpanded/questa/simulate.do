onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib pid_reexpanded_opt

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure
view signals

do {pid_reexpanded.udo}

run -all

quit -force
