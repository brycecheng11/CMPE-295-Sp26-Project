vopt +acc=npr -l elaborate.log -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.pid_reexpanded xil_defaultlib.glbl -o pid_reexpanded_opt
