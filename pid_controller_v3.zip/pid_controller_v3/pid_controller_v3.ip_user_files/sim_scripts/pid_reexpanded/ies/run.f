-makelib ies_lib/xil_defaultlib \
  "../../../bd/pid_reexpanded/ip/pid_reexpanded_term_calculation_0_0/sim/pid_reexpanded_term_calculation_0_0.v" \
  "../../../bd/pid_reexpanded/ip/pid_reexpanded_k_math_0_0/sim/pid_reexpanded_k_math_0_0.v" \
  "../../../bd/pid_reexpanded/ip/pid_reexpanded_velocity_calculation_0_0/sim/pid_reexpanded_velocity_calculation_0_0.v" \
  "../../../bd/pid_reexpanded/ip/pid_reexpanded_prev_value_flip_flop_0_0/sim/pid_reexpanded_prev_value_flip_flop_0_0.v" \
  "../../../bd/pid_reexpanded/ip/pid_reexpanded_initial_math_0_0/sim/pid_reexpanded_initial_math_0_0.v" \
  "../../../bd/pid_reexpanded/sim/pid_reexpanded.v" \
-endlib
-makelib ies_lib/xil_defaultlib \
  glbl.v
-endlib

