onbreak {quit -force}
onerror {quit -force}

asim +access +r +m+pid_reexpanded -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.pid_reexpanded xil_defaultlib.glbl

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure

do {pid_reexpanded.udo}

run -all

endsim

quit -force
