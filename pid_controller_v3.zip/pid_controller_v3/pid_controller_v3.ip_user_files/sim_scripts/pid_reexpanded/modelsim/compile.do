vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xil_defaultlib

vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib

vlog -work xil_defaultlib  -incr -mfcu \
"../../../bd/pid_reexpanded/ip/pid_reexpanded_term_calculation_0_0/sim/pid_reexpanded_term_calculation_0_0.v" \
"../../../bd/pid_reexpanded/ip/pid_reexpanded_k_math_0_0/sim/pid_reexpanded_k_math_0_0.v" \
"../../../bd/pid_reexpanded/ip/pid_reexpanded_prev_value_flip_flop_0_0/sim/pid_reexpanded_prev_value_flip_flop_0_0.v" \
"../../../bd/pid_reexpanded/ip/pid_reexpanded_initial_math_0_0/sim/pid_reexpanded_initial_math_0_0.v" \
"../../../bd/pid_reexpanded/ip/pid_reexpanded_velocity_calculation_0_0/sim/pid_reexpanded_velocity_calculation_0_0.v" \
"../../../bd/pid_reexpanded/sim/pid_reexpanded.v" \


vlog -work xil_defaultlib \
"glbl.v"

