// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Wed Oct 28 17:31:38 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_reexpanded_k_math_0_0_stub.v
// Design      : pid_reexpanded_k_math_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "k_math,Vivado 2021.1" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clock, kp_in, ki_in, kd_in, kp_out, ki_out, kd_out)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],kp_in[11:0],ki_in[11:0],kd_in[11:0],kp_out[8:0],ki_out[8:0],kd_out[8:0]" */;
  input [0:0]clock;
  input [11:0]kp_in;
  input [11:0]ki_in;
  input [11:0]kd_in;
  output [8:0]kp_out;
  output [8:0]ki_out;
  output [8:0]kd_out;
endmodule
