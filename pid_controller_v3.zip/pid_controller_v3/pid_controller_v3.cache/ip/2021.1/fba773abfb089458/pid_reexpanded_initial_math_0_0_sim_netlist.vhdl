-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Thu Oct 29 12:58:58 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_reexpanded_initial_math_0_0_sim_netlist.vhdl
-- Design      : pid_reexpanded_initial_math_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math is
  port (
    Q : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative_out : out STD_LOGIC_VECTOR ( 26 downto 0 );
    angle_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_target_angle_available : in STD_LOGIC;
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_in : in STD_LOGIC_VECTOR ( 26 downto 0 );
    target_angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clock : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math is
  signal \^q\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal clock_count : STD_LOGIC;
  signal clock_count_i_1_n_0 : STD_LOGIC;
  signal derivative1 : STD_LOGIC_VECTOR ( 26 downto 0 );
  signal \derivative1_carry__0_n_0\ : STD_LOGIC;
  signal \derivative1_carry__0_n_1\ : STD_LOGIC;
  signal \derivative1_carry__0_n_2\ : STD_LOGIC;
  signal \derivative1_carry__0_n_3\ : STD_LOGIC;
  signal \derivative1_carry__1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__1_n_1\ : STD_LOGIC;
  signal \derivative1_carry__1_n_2\ : STD_LOGIC;
  signal \derivative1_carry__1_n_3\ : STD_LOGIC;
  signal \derivative1_carry__2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__2_n_1\ : STD_LOGIC;
  signal \derivative1_carry__2_n_2\ : STD_LOGIC;
  signal \derivative1_carry__2_n_3\ : STD_LOGIC;
  signal \derivative1_carry__3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__3_n_1\ : STD_LOGIC;
  signal \derivative1_carry__3_n_2\ : STD_LOGIC;
  signal \derivative1_carry__3_n_3\ : STD_LOGIC;
  signal \derivative1_carry__4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__4_n_1\ : STD_LOGIC;
  signal \derivative1_carry__4_n_2\ : STD_LOGIC;
  signal \derivative1_carry__4_n_3\ : STD_LOGIC;
  signal \derivative1_carry__5_n_2\ : STD_LOGIC;
  signal \derivative1_carry__5_n_3\ : STD_LOGIC;
  signal \derivative1_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_1__3_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_1__4_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_1__5_n_0\ : STD_LOGIC;
  signal derivative1_carry_i_1_n_0 : STD_LOGIC;
  signal \derivative1_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_2__3_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_2__4_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_2__5_n_0\ : STD_LOGIC;
  signal derivative1_carry_i_2_n_0 : STD_LOGIC;
  signal \derivative1_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_3__3_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_3__4_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_3__5_n_0\ : STD_LOGIC;
  signal derivative1_carry_i_3_n_0 : STD_LOGIC;
  signal \derivative1_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_4__2_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_4__3_n_0\ : STD_LOGIC;
  signal \derivative1_carry_i_4__4_n_0\ : STD_LOGIC;
  signal derivative1_carry_i_4_n_0 : STD_LOGIC;
  signal derivative1_carry_n_0 : STD_LOGIC;
  signal derivative1_carry_n_1 : STD_LOGIC;
  signal derivative1_carry_n_2 : STD_LOGIC;
  signal derivative1_carry_n_3 : STD_LOGIC;
  signal error0 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \error0_carry__0_n_0\ : STD_LOGIC;
  signal \error0_carry__0_n_1\ : STD_LOGIC;
  signal \error0_carry__0_n_2\ : STD_LOGIC;
  signal \error0_carry__0_n_3\ : STD_LOGIC;
  signal \error0_carry__1_n_0\ : STD_LOGIC;
  signal \error0_carry__1_n_1\ : STD_LOGIC;
  signal \error0_carry__1_n_2\ : STD_LOGIC;
  signal \error0_carry__1_n_3\ : STD_LOGIC;
  signal \error0_carry__2_n_0\ : STD_LOGIC;
  signal \error0_carry__2_n_1\ : STD_LOGIC;
  signal \error0_carry__2_n_2\ : STD_LOGIC;
  signal \error0_carry__2_n_3\ : STD_LOGIC;
  signal \error0_carry__3_n_0\ : STD_LOGIC;
  signal \error0_carry__3_n_1\ : STD_LOGIC;
  signal \error0_carry__3_n_2\ : STD_LOGIC;
  signal \error0_carry__3_n_3\ : STD_LOGIC;
  signal \error0_carry__4_n_0\ : STD_LOGIC;
  signal \error0_carry__4_n_1\ : STD_LOGIC;
  signal \error0_carry__4_n_2\ : STD_LOGIC;
  signal \error0_carry__4_n_3\ : STD_LOGIC;
  signal \error0_carry__5_n_0\ : STD_LOGIC;
  signal \error0_carry__5_n_1\ : STD_LOGIC;
  signal \error0_carry__5_n_2\ : STD_LOGIC;
  signal \error0_carry__5_n_3\ : STD_LOGIC;
  signal \error0_carry__6_n_1\ : STD_LOGIC;
  signal \error0_carry__6_n_2\ : STD_LOGIC;
  signal \error0_carry__6_n_3\ : STD_LOGIC;
  signal \error0_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_1_n_0 : STD_LOGIC;
  signal \error0_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_2_n_0 : STD_LOGIC;
  signal \error0_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_3_n_0 : STD_LOGIC;
  signal \error0_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_4_n_0 : STD_LOGIC;
  signal error0_carry_n_0 : STD_LOGIC;
  signal error0_carry_n_1 : STD_LOGIC;
  signal error0_carry_n_2 : STD_LOGIC;
  signal error0_carry_n_3 : STD_LOGIC;
  signal \error[31]_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_n_1\ : STD_LOGIC;
  signal \integral0_carry__0_n_2\ : STD_LOGIC;
  signal \integral0_carry__0_n_3\ : STD_LOGIC;
  signal \integral0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_n_1\ : STD_LOGIC;
  signal \integral0_carry__1_n_2\ : STD_LOGIC;
  signal \integral0_carry__1_n_3\ : STD_LOGIC;
  signal \integral0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_n_1\ : STD_LOGIC;
  signal \integral0_carry__2_n_2\ : STD_LOGIC;
  signal \integral0_carry__2_n_3\ : STD_LOGIC;
  signal \integral0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_n_1\ : STD_LOGIC;
  signal \integral0_carry__3_n_2\ : STD_LOGIC;
  signal \integral0_carry__3_n_3\ : STD_LOGIC;
  signal \integral0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_n_1\ : STD_LOGIC;
  signal \integral0_carry__4_n_2\ : STD_LOGIC;
  signal \integral0_carry__4_n_3\ : STD_LOGIC;
  signal \integral0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_i_5_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_n_1\ : STD_LOGIC;
  signal \integral0_carry__5_n_2\ : STD_LOGIC;
  signal \integral0_carry__5_n_3\ : STD_LOGIC;
  signal \integral0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_n_1\ : STD_LOGIC;
  signal \integral0_carry__6_n_2\ : STD_LOGIC;
  signal \integral0_carry__6_n_3\ : STD_LOGIC;
  signal integral0_carry_i_1_n_0 : STD_LOGIC;
  signal integral0_carry_i_2_n_0 : STD_LOGIC;
  signal integral0_carry_i_3_n_0 : STD_LOGIC;
  signal integral0_carry_i_4_n_0 : STD_LOGIC;
  signal integral0_carry_n_0 : STD_LOGIC;
  signal integral0_carry_n_1 : STD_LOGIC;
  signal integral0_carry_n_2 : STD_LOGIC;
  signal integral0_carry_n_3 : STD_LOGIC;
  signal \integral[31]_i_2_n_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal p_2_in : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal saved_target_angle : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal saved_target_angle_0 : STD_LOGIC;
  signal \NLW_derivative1_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative1_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_error0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of derivative1_carry : label is 35;
  attribute ADDER_THRESHOLD of \derivative1_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative1_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative1_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative1_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative1_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative1_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of error0_carry : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__6\ : label is 35;
  attribute ADDER_THRESHOLD of integral0_carry : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__6\ : label is 35;
begin
  Q(31 downto 0) <= \^q\(31 downto 0);
clock_count_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => new_target_angle_available,
      I1 => clock_count,
      O => clock_count_i_1_n_0
    );
clock_count_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => clock_count_i_1_n_0,
      Q => clock_count,
      R => '0'
    );
derivative1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => derivative1_carry_n_0,
      CO(2) => derivative1_carry_n_1,
      CO(1) => derivative1_carry_n_2,
      CO(0) => derivative1_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => \^q\(3 downto 0),
      O(3 downto 0) => derivative1(3 downto 0),
      S(3) => derivative1_carry_i_1_n_0,
      S(2) => derivative1_carry_i_2_n_0,
      S(1) => derivative1_carry_i_3_n_0,
      S(0) => derivative1_carry_i_4_n_0
    );
\derivative1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => derivative1_carry_n_0,
      CO(3) => \derivative1_carry__0_n_0\,
      CO(2) => \derivative1_carry__0_n_1\,
      CO(1) => \derivative1_carry__0_n_2\,
      CO(0) => \derivative1_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^q\(7 downto 4),
      O(3 downto 0) => derivative1(7 downto 4),
      S(3) => \derivative1_carry_i_1__0_n_0\,
      S(2) => \derivative1_carry_i_2__0_n_0\,
      S(1) => \derivative1_carry_i_3__0_n_0\,
      S(0) => \derivative1_carry_i_4__0_n_0\
    );
\derivative1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__0_n_0\,
      CO(3) => \derivative1_carry__1_n_0\,
      CO(2) => \derivative1_carry__1_n_1\,
      CO(1) => \derivative1_carry__1_n_2\,
      CO(0) => \derivative1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^q\(11 downto 8),
      O(3 downto 0) => derivative1(11 downto 8),
      S(3) => \derivative1_carry_i_1__1_n_0\,
      S(2) => \derivative1_carry_i_2__1_n_0\,
      S(1) => \derivative1_carry_i_3__1_n_0\,
      S(0) => \derivative1_carry_i_4__1_n_0\
    );
\derivative1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__1_n_0\,
      CO(3) => \derivative1_carry__2_n_0\,
      CO(2) => \derivative1_carry__2_n_1\,
      CO(1) => \derivative1_carry__2_n_2\,
      CO(0) => \derivative1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^q\(15 downto 12),
      O(3 downto 0) => derivative1(15 downto 12),
      S(3) => \derivative1_carry_i_1__2_n_0\,
      S(2) => \derivative1_carry_i_2__2_n_0\,
      S(1) => \derivative1_carry_i_3__2_n_0\,
      S(0) => \derivative1_carry_i_4__2_n_0\
    );
\derivative1_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__2_n_0\,
      CO(3) => \derivative1_carry__3_n_0\,
      CO(2) => \derivative1_carry__3_n_1\,
      CO(1) => \derivative1_carry__3_n_2\,
      CO(0) => \derivative1_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^q\(19 downto 16),
      O(3 downto 0) => derivative1(19 downto 16),
      S(3) => \derivative1_carry_i_1__3_n_0\,
      S(2) => \derivative1_carry_i_2__3_n_0\,
      S(1) => \derivative1_carry_i_3__3_n_0\,
      S(0) => \derivative1_carry_i_4__3_n_0\
    );
\derivative1_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__3_n_0\,
      CO(3) => \derivative1_carry__4_n_0\,
      CO(2) => \derivative1_carry__4_n_1\,
      CO(1) => \derivative1_carry__4_n_2\,
      CO(0) => \derivative1_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^q\(23 downto 20),
      O(3 downto 0) => derivative1(23 downto 20),
      S(3) => \derivative1_carry_i_1__4_n_0\,
      S(2) => \derivative1_carry_i_2__4_n_0\,
      S(1) => \derivative1_carry_i_3__4_n_0\,
      S(0) => \derivative1_carry_i_4__4_n_0\
    );
\derivative1_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__4_n_0\,
      CO(3 downto 2) => \NLW_derivative1_carry__5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative1_carry__5_n_2\,
      CO(0) => \derivative1_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => \^q\(25 downto 24),
      O(3) => \NLW_derivative1_carry__5_O_UNCONNECTED\(3),
      O(2 downto 0) => derivative1(26 downto 24),
      S(3) => '0',
      S(2) => \derivative1_carry_i_1__5_n_0\,
      S(1) => \derivative1_carry_i_2__5_n_0\,
      S(0) => \derivative1_carry_i_3__5_n_0\
    );
derivative1_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(3),
      I1 => error_in(3),
      O => derivative1_carry_i_1_n_0
    );
\derivative1_carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(7),
      I1 => error_in(7),
      O => \derivative1_carry_i_1__0_n_0\
    );
\derivative1_carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(11),
      I1 => error_in(11),
      O => \derivative1_carry_i_1__1_n_0\
    );
\derivative1_carry_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(15),
      I1 => error_in(15),
      O => \derivative1_carry_i_1__2_n_0\
    );
\derivative1_carry_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(19),
      I1 => error_in(19),
      O => \derivative1_carry_i_1__3_n_0\
    );
\derivative1_carry_i_1__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(23),
      I1 => error_in(23),
      O => \derivative1_carry_i_1__4_n_0\
    );
\derivative1_carry_i_1__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(26),
      I1 => error_in(26),
      O => \derivative1_carry_i_1__5_n_0\
    );
derivative1_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(2),
      I1 => error_in(2),
      O => derivative1_carry_i_2_n_0
    );
\derivative1_carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(6),
      I1 => error_in(6),
      O => \derivative1_carry_i_2__0_n_0\
    );
\derivative1_carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(10),
      I1 => error_in(10),
      O => \derivative1_carry_i_2__1_n_0\
    );
\derivative1_carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(14),
      I1 => error_in(14),
      O => \derivative1_carry_i_2__2_n_0\
    );
\derivative1_carry_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(18),
      I1 => error_in(18),
      O => \derivative1_carry_i_2__3_n_0\
    );
\derivative1_carry_i_2__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(22),
      I1 => error_in(22),
      O => \derivative1_carry_i_2__4_n_0\
    );
\derivative1_carry_i_2__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(25),
      I1 => error_in(25),
      O => \derivative1_carry_i_2__5_n_0\
    );
derivative1_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(1),
      I1 => error_in(1),
      O => derivative1_carry_i_3_n_0
    );
\derivative1_carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(5),
      I1 => error_in(5),
      O => \derivative1_carry_i_3__0_n_0\
    );
\derivative1_carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(9),
      I1 => error_in(9),
      O => \derivative1_carry_i_3__1_n_0\
    );
\derivative1_carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(13),
      I1 => error_in(13),
      O => \derivative1_carry_i_3__2_n_0\
    );
\derivative1_carry_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(17),
      I1 => error_in(17),
      O => \derivative1_carry_i_3__3_n_0\
    );
\derivative1_carry_i_3__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(21),
      I1 => error_in(21),
      O => \derivative1_carry_i_3__4_n_0\
    );
\derivative1_carry_i_3__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(24),
      I1 => error_in(24),
      O => \derivative1_carry_i_3__5_n_0\
    );
derivative1_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(0),
      I1 => error_in(0),
      O => derivative1_carry_i_4_n_0
    );
\derivative1_carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(4),
      I1 => error_in(4),
      O => \derivative1_carry_i_4__0_n_0\
    );
\derivative1_carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(8),
      I1 => error_in(8),
      O => \derivative1_carry_i_4__1_n_0\
    );
\derivative1_carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(12),
      I1 => error_in(12),
      O => \derivative1_carry_i_4__2_n_0\
    );
\derivative1_carry_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(16),
      I1 => error_in(16),
      O => \derivative1_carry_i_4__3_n_0\
    );
\derivative1_carry_i_4__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^q\(20),
      I1 => error_in(20),
      O => \derivative1_carry_i_4__4_n_0\
    );
\derivative_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(5),
      Q => derivative_out(5),
      R => '0'
    );
\derivative_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(6),
      Q => derivative_out(6),
      R => '0'
    );
\derivative_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(7),
      Q => derivative_out(7),
      R => '0'
    );
\derivative_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(8),
      Q => derivative_out(8),
      R => '0'
    );
\derivative_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(9),
      Q => derivative_out(9),
      R => '0'
    );
\derivative_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(10),
      Q => derivative_out(10),
      R => '0'
    );
\derivative_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(11),
      Q => derivative_out(11),
      R => '0'
    );
\derivative_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(12),
      Q => derivative_out(12),
      R => '0'
    );
\derivative_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(13),
      Q => derivative_out(13),
      R => '0'
    );
\derivative_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(14),
      Q => derivative_out(14),
      R => '0'
    );
\derivative_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(15),
      Q => derivative_out(15),
      R => '0'
    );
\derivative_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(16),
      Q => derivative_out(16),
      R => '0'
    );
\derivative_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(17),
      Q => derivative_out(17),
      R => '0'
    );
\derivative_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(18),
      Q => derivative_out(18),
      R => '0'
    );
\derivative_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(19),
      Q => derivative_out(19),
      R => '0'
    );
\derivative_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(20),
      Q => derivative_out(20),
      R => '0'
    );
\derivative_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(21),
      Q => derivative_out(21),
      R => '0'
    );
\derivative_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(22),
      Q => derivative_out(22),
      R => '0'
    );
\derivative_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(23),
      Q => derivative_out(23),
      R => '0'
    );
\derivative_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(24),
      Q => derivative_out(24),
      R => '0'
    );
\derivative_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(25),
      Q => derivative_out(25),
      R => '0'
    );
\derivative_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(26),
      Q => derivative_out(26),
      R => '0'
    );
\derivative_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(0),
      Q => derivative_out(0),
      R => '0'
    );
\derivative_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(1),
      Q => derivative_out(1),
      R => '0'
    );
\derivative_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(2),
      Q => derivative_out(2),
      R => '0'
    );
\derivative_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(3),
      Q => derivative_out(3),
      R => '0'
    );
\derivative_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => derivative1(4),
      Q => derivative_out(4),
      R => '0'
    );
error0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => error0_carry_n_0,
      CO(2) => error0_carry_n_1,
      CO(1) => error0_carry_n_2,
      CO(0) => error0_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => saved_target_angle(3 downto 0),
      O(3 downto 0) => error0(3 downto 0),
      S(3) => error0_carry_i_1_n_0,
      S(2) => error0_carry_i_2_n_0,
      S(1) => error0_carry_i_3_n_0,
      S(0) => error0_carry_i_4_n_0
    );
\error0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => error0_carry_n_0,
      CO(3) => \error0_carry__0_n_0\,
      CO(2) => \error0_carry__0_n_1\,
      CO(1) => \error0_carry__0_n_2\,
      CO(0) => \error0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(7 downto 4),
      O(3 downto 0) => error0(7 downto 4),
      S(3) => \error0_carry_i_1__0_n_0\,
      S(2) => \error0_carry_i_2__0_n_0\,
      S(1) => \error0_carry_i_3__0_n_0\,
      S(0) => \error0_carry_i_4__0_n_0\
    );
\error0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__0_n_0\,
      CO(3) => \error0_carry__1_n_0\,
      CO(2) => \error0_carry__1_n_1\,
      CO(1) => \error0_carry__1_n_2\,
      CO(0) => \error0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(11 downto 8),
      O(3 downto 0) => error0(11 downto 8),
      S(3) => \error0_carry_i_1__1_n_0\,
      S(2) => \error0_carry_i_2__1_n_0\,
      S(1) => \error0_carry_i_3__1_n_0\,
      S(0) => \error0_carry_i_4__1_n_0\
    );
\error0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__1_n_0\,
      CO(3) => \error0_carry__2_n_0\,
      CO(2) => \error0_carry__2_n_1\,
      CO(1) => \error0_carry__2_n_2\,
      CO(0) => \error0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(15 downto 12),
      O(3 downto 0) => error0(15 downto 12),
      S(3) => \error0_carry_i_1__2_n_0\,
      S(2) => \error0_carry_i_2__2_n_0\,
      S(1) => \error0_carry_i_3__2_n_0\,
      S(0) => \error0_carry_i_4__2_n_0\
    );
\error0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__2_n_0\,
      CO(3) => \error0_carry__3_n_0\,
      CO(2) => \error0_carry__3_n_1\,
      CO(1) => \error0_carry__3_n_2\,
      CO(0) => \error0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(19 downto 16),
      O(3 downto 0) => error0(19 downto 16),
      S(3) => \error0_carry_i_1__3_n_0\,
      S(2) => \error0_carry_i_2__3_n_0\,
      S(1) => \error0_carry_i_3__3_n_0\,
      S(0) => \error0_carry_i_4__3_n_0\
    );
\error0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__3_n_0\,
      CO(3) => \error0_carry__4_n_0\,
      CO(2) => \error0_carry__4_n_1\,
      CO(1) => \error0_carry__4_n_2\,
      CO(0) => \error0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(23 downto 20),
      O(3 downto 0) => error0(23 downto 20),
      S(3) => \error0_carry_i_1__4_n_0\,
      S(2) => \error0_carry_i_2__4_n_0\,
      S(1) => \error0_carry_i_3__4_n_0\,
      S(0) => \error0_carry_i_4__4_n_0\
    );
\error0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__4_n_0\,
      CO(3) => \error0_carry__5_n_0\,
      CO(2) => \error0_carry__5_n_1\,
      CO(1) => \error0_carry__5_n_2\,
      CO(0) => \error0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(27 downto 24),
      O(3 downto 0) => error0(27 downto 24),
      S(3) => \error0_carry_i_1__5_n_0\,
      S(2) => \error0_carry_i_2__5_n_0\,
      S(1) => \error0_carry_i_3__5_n_0\,
      S(0) => \error0_carry_i_4__5_n_0\
    );
\error0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__5_n_0\,
      CO(3) => \NLW_error0_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \error0_carry__6_n_1\,
      CO(1) => \error0_carry__6_n_2\,
      CO(0) => \error0_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => saved_target_angle(30 downto 28),
      O(3 downto 0) => error0(31 downto 28),
      S(3) => \error0_carry_i_1__6_n_0\,
      S(2) => \error0_carry_i_2__6_n_0\,
      S(1) => \error0_carry_i_3__6_n_0\,
      S(0) => \error0_carry_i_4__6_n_0\
    );
error0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(3),
      I1 => angle(3),
      O => error0_carry_i_1_n_0
    );
\error0_carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(7),
      I1 => angle(7),
      O => \error0_carry_i_1__0_n_0\
    );
\error0_carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(11),
      I1 => angle(11),
      O => \error0_carry_i_1__1_n_0\
    );
\error0_carry_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(15),
      I1 => angle(15),
      O => \error0_carry_i_1__2_n_0\
    );
\error0_carry_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(19),
      I1 => angle(19),
      O => \error0_carry_i_1__3_n_0\
    );
\error0_carry_i_1__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(23),
      I1 => angle(23),
      O => \error0_carry_i_1__4_n_0\
    );
\error0_carry_i_1__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(27),
      I1 => angle(27),
      O => \error0_carry_i_1__5_n_0\
    );
\error0_carry_i_1__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(31),
      I1 => angle(31),
      O => \error0_carry_i_1__6_n_0\
    );
error0_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(2),
      I1 => angle(2),
      O => error0_carry_i_2_n_0
    );
\error0_carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(6),
      I1 => angle(6),
      O => \error0_carry_i_2__0_n_0\
    );
\error0_carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(10),
      I1 => angle(10),
      O => \error0_carry_i_2__1_n_0\
    );
\error0_carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(14),
      I1 => angle(14),
      O => \error0_carry_i_2__2_n_0\
    );
\error0_carry_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(18),
      I1 => angle(18),
      O => \error0_carry_i_2__3_n_0\
    );
\error0_carry_i_2__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(22),
      I1 => angle(22),
      O => \error0_carry_i_2__4_n_0\
    );
\error0_carry_i_2__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(26),
      I1 => angle(26),
      O => \error0_carry_i_2__5_n_0\
    );
\error0_carry_i_2__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(30),
      I1 => angle(30),
      O => \error0_carry_i_2__6_n_0\
    );
error0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(1),
      I1 => angle(1),
      O => error0_carry_i_3_n_0
    );
\error0_carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(5),
      I1 => angle(5),
      O => \error0_carry_i_3__0_n_0\
    );
\error0_carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(9),
      I1 => angle(9),
      O => \error0_carry_i_3__1_n_0\
    );
\error0_carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(13),
      I1 => angle(13),
      O => \error0_carry_i_3__2_n_0\
    );
\error0_carry_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(17),
      I1 => angle(17),
      O => \error0_carry_i_3__3_n_0\
    );
\error0_carry_i_3__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(21),
      I1 => angle(21),
      O => \error0_carry_i_3__4_n_0\
    );
\error0_carry_i_3__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(25),
      I1 => angle(25),
      O => \error0_carry_i_3__5_n_0\
    );
\error0_carry_i_3__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(29),
      I1 => angle(29),
      O => \error0_carry_i_3__6_n_0\
    );
error0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(0),
      I1 => angle(0),
      O => error0_carry_i_4_n_0
    );
\error0_carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(4),
      I1 => angle(4),
      O => \error0_carry_i_4__0_n_0\
    );
\error0_carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(8),
      I1 => angle(8),
      O => \error0_carry_i_4__1_n_0\
    );
\error0_carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(12),
      I1 => angle(12),
      O => \error0_carry_i_4__2_n_0\
    );
\error0_carry_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(16),
      I1 => angle(16),
      O => \error0_carry_i_4__3_n_0\
    );
\error0_carry_i_4__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(20),
      I1 => angle(20),
      O => \error0_carry_i_4__4_n_0\
    );
\error0_carry_i_4__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(24),
      I1 => angle(24),
      O => \error0_carry_i_4__5_n_0\
    );
\error0_carry_i_4__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(28),
      I1 => angle(28),
      O => \error0_carry_i_4__6_n_0\
    );
\error[31]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => clock_count,
      I1 => new_target_angle_available,
      O => \error[31]_i_1_n_0\
    );
\error_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(0),
      Q => \^q\(0),
      R => '0'
    );
\error_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(10),
      Q => \^q\(10),
      R => '0'
    );
\error_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(11),
      Q => \^q\(11),
      R => '0'
    );
\error_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(12),
      Q => \^q\(12),
      R => '0'
    );
\error_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(13),
      Q => \^q\(13),
      R => '0'
    );
\error_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(14),
      Q => \^q\(14),
      R => '0'
    );
\error_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(15),
      Q => \^q\(15),
      R => '0'
    );
\error_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(16),
      Q => \^q\(16),
      R => '0'
    );
\error_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(17),
      Q => \^q\(17),
      R => '0'
    );
\error_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(18),
      Q => \^q\(18),
      R => '0'
    );
\error_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(19),
      Q => \^q\(19),
      R => '0'
    );
\error_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(1),
      Q => \^q\(1),
      R => '0'
    );
\error_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(20),
      Q => \^q\(20),
      R => '0'
    );
\error_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(21),
      Q => \^q\(21),
      R => '0'
    );
\error_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(22),
      Q => \^q\(22),
      R => '0'
    );
\error_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(23),
      Q => \^q\(23),
      R => '0'
    );
\error_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(24),
      Q => \^q\(24),
      R => '0'
    );
\error_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(25),
      Q => \^q\(25),
      R => '0'
    );
\error_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(26),
      Q => \^q\(26),
      R => '0'
    );
\error_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(27),
      Q => \^q\(27),
      R => '0'
    );
\error_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(28),
      Q => \^q\(28),
      R => '0'
    );
\error_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(29),
      Q => \^q\(29),
      R => '0'
    );
\error_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(2),
      Q => \^q\(2),
      R => '0'
    );
\error_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(30),
      Q => \^q\(30),
      R => '0'
    );
\error_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(31),
      Q => \^q\(31),
      R => '0'
    );
\error_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(3),
      Q => \^q\(3),
      R => '0'
    );
\error_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(4),
      Q => \^q\(4),
      R => '0'
    );
\error_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(5),
      Q => \^q\(5),
      R => '0'
    );
\error_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(6),
      Q => \^q\(6),
      R => '0'
    );
\error_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(7),
      Q => \^q\(7),
      R => '0'
    );
\error_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(8),
      Q => \^q\(8),
      R => '0'
    );
\error_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \error[31]_i_1_n_0\,
      D => error0(9),
      Q => \^q\(9),
      R => '0'
    );
integral0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => integral0_carry_n_0,
      CO(2) => integral0_carry_n_1,
      CO(1) => integral0_carry_n_2,
      CO(0) => integral0_carry_n_3,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(3 downto 0),
      O(3 downto 0) => p_2_in(3 downto 0),
      S(3) => integral0_carry_i_1_n_0,
      S(2) => integral0_carry_i_2_n_0,
      S(1) => integral0_carry_i_3_n_0,
      S(0) => integral0_carry_i_4_n_0
    );
\integral0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => integral0_carry_n_0,
      CO(3) => \integral0_carry__0_n_0\,
      CO(2) => \integral0_carry__0_n_1\,
      CO(1) => \integral0_carry__0_n_2\,
      CO(0) => \integral0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(7 downto 4),
      O(3 downto 0) => p_2_in(7 downto 4),
      S(3) => \integral0_carry__0_i_1_n_0\,
      S(2) => \integral0_carry__0_i_2_n_0\,
      S(1) => \integral0_carry__0_i_3_n_0\,
      S(0) => \integral0_carry__0_i_4_n_0\
    );
\integral0_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(7),
      I1 => \^q\(12),
      O => \integral0_carry__0_i_1_n_0\
    );
\integral0_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(6),
      I1 => \^q\(11),
      O => \integral0_carry__0_i_2_n_0\
    );
\integral0_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(5),
      I1 => \^q\(10),
      O => \integral0_carry__0_i_3_n_0\
    );
\integral0_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(4),
      I1 => \^q\(9),
      O => \integral0_carry__0_i_4_n_0\
    );
\integral0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__0_n_0\,
      CO(3) => \integral0_carry__1_n_0\,
      CO(2) => \integral0_carry__1_n_1\,
      CO(1) => \integral0_carry__1_n_2\,
      CO(0) => \integral0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(11 downto 8),
      O(3 downto 0) => p_2_in(11 downto 8),
      S(3) => \integral0_carry__1_i_1_n_0\,
      S(2) => \integral0_carry__1_i_2_n_0\,
      S(1) => \integral0_carry__1_i_3_n_0\,
      S(0) => \integral0_carry__1_i_4_n_0\
    );
\integral0_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(11),
      I1 => \^q\(16),
      O => \integral0_carry__1_i_1_n_0\
    );
\integral0_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(10),
      I1 => \^q\(15),
      O => \integral0_carry__1_i_2_n_0\
    );
\integral0_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(9),
      I1 => \^q\(14),
      O => \integral0_carry__1_i_3_n_0\
    );
\integral0_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(8),
      I1 => \^q\(13),
      O => \integral0_carry__1_i_4_n_0\
    );
\integral0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__1_n_0\,
      CO(3) => \integral0_carry__2_n_0\,
      CO(2) => \integral0_carry__2_n_1\,
      CO(1) => \integral0_carry__2_n_2\,
      CO(0) => \integral0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(15 downto 12),
      O(3 downto 0) => p_2_in(15 downto 12),
      S(3) => \integral0_carry__2_i_1_n_0\,
      S(2) => \integral0_carry__2_i_2_n_0\,
      S(1) => \integral0_carry__2_i_3_n_0\,
      S(0) => \integral0_carry__2_i_4_n_0\
    );
\integral0_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(15),
      I1 => \^q\(20),
      O => \integral0_carry__2_i_1_n_0\
    );
\integral0_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(14),
      I1 => \^q\(19),
      O => \integral0_carry__2_i_2_n_0\
    );
\integral0_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(13),
      I1 => \^q\(18),
      O => \integral0_carry__2_i_3_n_0\
    );
\integral0_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(12),
      I1 => \^q\(17),
      O => \integral0_carry__2_i_4_n_0\
    );
\integral0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__2_n_0\,
      CO(3) => \integral0_carry__3_n_0\,
      CO(2) => \integral0_carry__3_n_1\,
      CO(1) => \integral0_carry__3_n_2\,
      CO(0) => \integral0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(19 downto 16),
      O(3 downto 0) => p_2_in(19 downto 16),
      S(3) => \integral0_carry__3_i_1_n_0\,
      S(2) => \integral0_carry__3_i_2_n_0\,
      S(1) => \integral0_carry__3_i_3_n_0\,
      S(0) => \integral0_carry__3_i_4_n_0\
    );
\integral0_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(19),
      I1 => \^q\(24),
      O => \integral0_carry__3_i_1_n_0\
    );
\integral0_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(18),
      I1 => \^q\(23),
      O => \integral0_carry__3_i_2_n_0\
    );
\integral0_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(17),
      I1 => \^q\(22),
      O => \integral0_carry__3_i_3_n_0\
    );
\integral0_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(16),
      I1 => \^q\(21),
      O => \integral0_carry__3_i_4_n_0\
    );
\integral0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__3_n_0\,
      CO(3) => \integral0_carry__4_n_0\,
      CO(2) => \integral0_carry__4_n_1\,
      CO(1) => \integral0_carry__4_n_2\,
      CO(0) => \integral0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(23 downto 20),
      O(3 downto 0) => p_2_in(23 downto 20),
      S(3) => \integral0_carry__4_i_1_n_0\,
      S(2) => \integral0_carry__4_i_2_n_0\,
      S(1) => \integral0_carry__4_i_3_n_0\,
      S(0) => \integral0_carry__4_i_4_n_0\
    );
\integral0_carry__4_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(23),
      I1 => \^q\(28),
      O => \integral0_carry__4_i_1_n_0\
    );
\integral0_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(22),
      I1 => \^q\(27),
      O => \integral0_carry__4_i_2_n_0\
    );
\integral0_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(21),
      I1 => \^q\(26),
      O => \integral0_carry__4_i_3_n_0\
    );
\integral0_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(20),
      I1 => \^q\(25),
      O => \integral0_carry__4_i_4_n_0\
    );
\integral0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__4_n_0\,
      CO(3) => \integral0_carry__5_n_0\,
      CO(2) => \integral0_carry__5_n_1\,
      CO(1) => \integral0_carry__5_n_2\,
      CO(0) => \integral0_carry__5_n_3\,
      CYINIT => '0',
      DI(3) => \integral0_carry__5_i_1_n_0\,
      DI(2) => \^q\(31),
      DI(1 downto 0) => integral_in(25 downto 24),
      O(3 downto 0) => p_2_in(27 downto 24),
      S(3) => \integral0_carry__5_i_2_n_0\,
      S(2) => \integral0_carry__5_i_3_n_0\,
      S(1) => \integral0_carry__5_i_4_n_0\,
      S(0) => \integral0_carry__5_i_5_n_0\
    );
\integral0_carry__5_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^q\(31),
      O => \integral0_carry__5_i_1_n_0\
    );
\integral0_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^q\(31),
      I1 => integral_in(27),
      O => \integral0_carry__5_i_2_n_0\
    );
\integral0_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^q\(31),
      I1 => integral_in(26),
      O => \integral0_carry__5_i_3_n_0\
    );
\integral0_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(25),
      I1 => \^q\(30),
      O => \integral0_carry__5_i_4_n_0\
    );
\integral0_carry__5_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(24),
      I1 => \^q\(29),
      O => \integral0_carry__5_i_5_n_0\
    );
\integral0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__5_n_0\,
      CO(3) => \NLW_integral0_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \integral0_carry__6_n_1\,
      CO(1) => \integral0_carry__6_n_2\,
      CO(0) => \integral0_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => integral_in(29 downto 27),
      O(3 downto 0) => p_2_in(31 downto 28),
      S(3) => \integral0_carry__6_i_1_n_0\,
      S(2) => \integral0_carry__6_i_2_n_0\,
      S(1) => \integral0_carry__6_i_3_n_0\,
      S(0) => \integral0_carry__6_i_4_n_0\
    );
\integral0_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => integral_in(30),
      I1 => integral_in(31),
      O => \integral0_carry__6_i_1_n_0\
    );
\integral0_carry__6_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => integral_in(29),
      I1 => integral_in(30),
      O => \integral0_carry__6_i_2_n_0\
    );
\integral0_carry__6_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => integral_in(28),
      I1 => integral_in(29),
      O => \integral0_carry__6_i_3_n_0\
    );
\integral0_carry__6_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => integral_in(27),
      I1 => integral_in(28),
      O => \integral0_carry__6_i_4_n_0\
    );
integral0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(3),
      I1 => \^q\(8),
      O => integral0_carry_i_1_n_0
    );
integral0_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(2),
      I1 => \^q\(7),
      O => integral0_carry_i_2_n_0
    );
integral0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(1),
      I1 => \^q\(6),
      O => integral0_carry_i_3_n_0
    );
integral0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(0),
      I1 => \^q\(5),
      O => integral0_carry_i_4_n_0
    );
\integral[31]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => clock_count,
      O => p_0_in
    );
\integral[31]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => new_target_angle_available,
      O => \integral[31]_i_2_n_0\
    );
\integral_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(0),
      Q => integral_out(0),
      R => p_0_in
    );
\integral_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(10),
      Q => integral_out(10),
      R => p_0_in
    );
\integral_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(11),
      Q => integral_out(11),
      R => p_0_in
    );
\integral_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(12),
      Q => integral_out(12),
      R => p_0_in
    );
\integral_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(13),
      Q => integral_out(13),
      R => p_0_in
    );
\integral_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(14),
      Q => integral_out(14),
      R => p_0_in
    );
\integral_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(15),
      Q => integral_out(15),
      R => p_0_in
    );
\integral_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(16),
      Q => integral_out(16),
      R => p_0_in
    );
\integral_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(17),
      Q => integral_out(17),
      R => p_0_in
    );
\integral_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(18),
      Q => integral_out(18),
      R => p_0_in
    );
\integral_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(19),
      Q => integral_out(19),
      R => p_0_in
    );
\integral_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(1),
      Q => integral_out(1),
      R => p_0_in
    );
\integral_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(20),
      Q => integral_out(20),
      R => p_0_in
    );
\integral_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(21),
      Q => integral_out(21),
      R => p_0_in
    );
\integral_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(22),
      Q => integral_out(22),
      R => p_0_in
    );
\integral_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(23),
      Q => integral_out(23),
      R => p_0_in
    );
\integral_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(24),
      Q => integral_out(24),
      R => p_0_in
    );
\integral_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(25),
      Q => integral_out(25),
      R => p_0_in
    );
\integral_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(26),
      Q => integral_out(26),
      R => p_0_in
    );
\integral_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(27),
      Q => integral_out(27),
      R => p_0_in
    );
\integral_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(28),
      Q => integral_out(28),
      R => p_0_in
    );
\integral_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(29),
      Q => integral_out(29),
      R => p_0_in
    );
\integral_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(2),
      Q => integral_out(2),
      R => p_0_in
    );
\integral_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(30),
      Q => integral_out(30),
      R => p_0_in
    );
\integral_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(31),
      Q => integral_out(31),
      R => p_0_in
    );
\integral_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(3),
      Q => integral_out(3),
      R => p_0_in
    );
\integral_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(4),
      Q => integral_out(4),
      R => p_0_in
    );
\integral_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(5),
      Q => integral_out(5),
      R => p_0_in
    );
\integral_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(6),
      Q => integral_out(6),
      R => p_0_in
    );
\integral_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(7),
      Q => integral_out(7),
      R => p_0_in
    );
\integral_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(8),
      Q => integral_out(8),
      R => p_0_in
    );
\integral_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => \integral[31]_i_2_n_0\,
      D => p_2_in(9),
      Q => integral_out(9),
      R => p_0_in
    );
\saved_angle_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(0),
      Q => angle_out(0),
      R => '0'
    );
\saved_angle_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(10),
      Q => angle_out(10),
      R => '0'
    );
\saved_angle_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(11),
      Q => angle_out(11),
      R => '0'
    );
\saved_angle_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(12),
      Q => angle_out(12),
      R => '0'
    );
\saved_angle_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(13),
      Q => angle_out(13),
      R => '0'
    );
\saved_angle_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(14),
      Q => angle_out(14),
      R => '0'
    );
\saved_angle_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(15),
      Q => angle_out(15),
      R => '0'
    );
\saved_angle_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(16),
      Q => angle_out(16),
      R => '0'
    );
\saved_angle_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(17),
      Q => angle_out(17),
      R => '0'
    );
\saved_angle_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(18),
      Q => angle_out(18),
      R => '0'
    );
\saved_angle_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(19),
      Q => angle_out(19),
      R => '0'
    );
\saved_angle_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(1),
      Q => angle_out(1),
      R => '0'
    );
\saved_angle_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(20),
      Q => angle_out(20),
      R => '0'
    );
\saved_angle_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(21),
      Q => angle_out(21),
      R => '0'
    );
\saved_angle_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(22),
      Q => angle_out(22),
      R => '0'
    );
\saved_angle_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(23),
      Q => angle_out(23),
      R => '0'
    );
\saved_angle_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(24),
      Q => angle_out(24),
      R => '0'
    );
\saved_angle_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(25),
      Q => angle_out(25),
      R => '0'
    );
\saved_angle_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(26),
      Q => angle_out(26),
      R => '0'
    );
\saved_angle_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(27),
      Q => angle_out(27),
      R => '0'
    );
\saved_angle_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(28),
      Q => angle_out(28),
      R => '0'
    );
\saved_angle_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(29),
      Q => angle_out(29),
      R => '0'
    );
\saved_angle_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(2),
      Q => angle_out(2),
      R => '0'
    );
\saved_angle_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(30),
      Q => angle_out(30),
      R => '0'
    );
\saved_angle_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(31),
      Q => angle_out(31),
      R => '0'
    );
\saved_angle_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(3),
      Q => angle_out(3),
      R => '0'
    );
\saved_angle_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(4),
      Q => angle_out(4),
      R => '0'
    );
\saved_angle_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(5),
      Q => angle_out(5),
      R => '0'
    );
\saved_angle_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(6),
      Q => angle_out(6),
      R => '0'
    );
\saved_angle_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(7),
      Q => angle_out(7),
      R => '0'
    );
\saved_angle_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(8),
      Q => angle_out(8),
      R => '0'
    );
\saved_angle_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => angle(9),
      Q => angle_out(9),
      R => '0'
    );
\saved_target_angle[31]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => clock_count,
      I1 => new_target_angle_available,
      O => saved_target_angle_0
    );
\saved_target_angle_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(0),
      Q => saved_target_angle(0),
      R => '0'
    );
\saved_target_angle_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(10),
      Q => saved_target_angle(10),
      R => '0'
    );
\saved_target_angle_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(11),
      Q => saved_target_angle(11),
      R => '0'
    );
\saved_target_angle_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(12),
      Q => saved_target_angle(12),
      R => '0'
    );
\saved_target_angle_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(13),
      Q => saved_target_angle(13),
      R => '0'
    );
\saved_target_angle_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(14),
      Q => saved_target_angle(14),
      R => '0'
    );
\saved_target_angle_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(15),
      Q => saved_target_angle(15),
      R => '0'
    );
\saved_target_angle_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(16),
      Q => saved_target_angle(16),
      R => '0'
    );
\saved_target_angle_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(17),
      Q => saved_target_angle(17),
      R => '0'
    );
\saved_target_angle_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(18),
      Q => saved_target_angle(18),
      R => '0'
    );
\saved_target_angle_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(19),
      Q => saved_target_angle(19),
      R => '0'
    );
\saved_target_angle_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(1),
      Q => saved_target_angle(1),
      R => '0'
    );
\saved_target_angle_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(20),
      Q => saved_target_angle(20),
      R => '0'
    );
\saved_target_angle_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(21),
      Q => saved_target_angle(21),
      R => '0'
    );
\saved_target_angle_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(22),
      Q => saved_target_angle(22),
      R => '0'
    );
\saved_target_angle_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(23),
      Q => saved_target_angle(23),
      R => '0'
    );
\saved_target_angle_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(24),
      Q => saved_target_angle(24),
      R => '0'
    );
\saved_target_angle_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(25),
      Q => saved_target_angle(25),
      R => '0'
    );
\saved_target_angle_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(26),
      Q => saved_target_angle(26),
      R => '0'
    );
\saved_target_angle_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(27),
      Q => saved_target_angle(27),
      R => '0'
    );
\saved_target_angle_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(28),
      Q => saved_target_angle(28),
      R => '0'
    );
\saved_target_angle_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(29),
      Q => saved_target_angle(29),
      R => '0'
    );
\saved_target_angle_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(2),
      Q => saved_target_angle(2),
      R => '0'
    );
\saved_target_angle_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(30),
      Q => saved_target_angle(30),
      R => '0'
    );
\saved_target_angle_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(31),
      Q => saved_target_angle(31),
      R => '0'
    );
\saved_target_angle_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(3),
      Q => saved_target_angle(3),
      R => '0'
    );
\saved_target_angle_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(4),
      Q => saved_target_angle(4),
      R => '0'
    );
\saved_target_angle_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(5),
      Q => saved_target_angle(5),
      R => '0'
    );
\saved_target_angle_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(6),
      Q => saved_target_angle(6),
      R => '0'
    );
\saved_target_angle_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(7),
      Q => saved_target_angle(7),
      R => '0'
    );
\saved_target_angle_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(8),
      Q => saved_target_angle(8),
      R => '0'
    );
\saved_target_angle_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => saved_target_angle_0,
      D => target_angle(9),
      Q => saved_target_angle(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clock : in STD_LOGIC;
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    target_angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    new_target_angle_available : in STD_LOGIC;
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    angle_out : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "pid_reexpanded_initial_math_0_0,initial_math,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "initial_math,Vivado 2021.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  signal \^derivative_out\ : STD_LOGIC_VECTOR ( 31 downto 5 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_reexpanded_clock_0, INSERT_VIP 0";
begin
  derivative_out(31 downto 5) <= \^derivative_out\(31 downto 5);
  derivative_out(4) <= \<const0>\;
  derivative_out(3) <= \<const0>\;
  derivative_out(2) <= \<const0>\;
  derivative_out(1) <= \<const0>\;
  derivative_out(0) <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math
     port map (
      Q(31 downto 0) => error_out(31 downto 0),
      angle(31 downto 0) => angle(31 downto 0),
      angle_out(31 downto 0) => angle_out(31 downto 0),
      clock => clock,
      derivative_out(26 downto 0) => \^derivative_out\(31 downto 5),
      error_in(26 downto 0) => error_in(26 downto 0),
      integral_in(31 downto 0) => integral_in(31 downto 0),
      integral_out(31 downto 0) => integral_out(31 downto 0),
      new_target_angle_available => new_target_angle_available,
      target_angle(31 downto 0) => target_angle(31 downto 0)
    );
end STRUCTURE;
