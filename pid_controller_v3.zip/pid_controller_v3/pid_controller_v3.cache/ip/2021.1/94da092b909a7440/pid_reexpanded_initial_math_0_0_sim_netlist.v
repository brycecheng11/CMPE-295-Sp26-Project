// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Wed Oct 28 19:46:40 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_reexpanded_initial_math_0_0_sim_netlist.v
// Design      : pid_reexpanded_initial_math_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math
   (Q,
    integral_out,
    derivative_out,
    angle,
    integral_in,
    error_in,
    new_target_angle_available,
    target_angle,
    clock);
  output [31:0]Q;
  output [31:0]integral_out;
  output [25:0]derivative_out;
  input [31:0]angle;
  input [31:0]integral_in;
  input [25:0]error_in;
  input [0:0]new_target_angle_available;
  input [31:0]target_angle;
  input [0:0]clock;

  wire [31:0]Q;
  wire [31:0]angle;
  wire [0:0]clock;
  wire [25:0]derivative1;
  wire derivative1_carry__0_n_0;
  wire derivative1_carry__0_n_1;
  wire derivative1_carry__0_n_2;
  wire derivative1_carry__0_n_3;
  wire derivative1_carry__1_n_0;
  wire derivative1_carry__1_n_1;
  wire derivative1_carry__1_n_2;
  wire derivative1_carry__1_n_3;
  wire derivative1_carry__2_n_0;
  wire derivative1_carry__2_n_1;
  wire derivative1_carry__2_n_2;
  wire derivative1_carry__2_n_3;
  wire derivative1_carry__3_n_0;
  wire derivative1_carry__3_n_1;
  wire derivative1_carry__3_n_2;
  wire derivative1_carry__3_n_3;
  wire derivative1_carry__4_n_0;
  wire derivative1_carry__4_n_1;
  wire derivative1_carry__4_n_2;
  wire derivative1_carry__4_n_3;
  wire derivative1_carry__5_n_3;
  wire derivative1_carry_i_1__0_n_0;
  wire derivative1_carry_i_1__1_n_0;
  wire derivative1_carry_i_1__2_n_0;
  wire derivative1_carry_i_1__3_n_0;
  wire derivative1_carry_i_1__4_n_0;
  wire derivative1_carry_i_1__5_n_0;
  wire derivative1_carry_i_1_n_0;
  wire derivative1_carry_i_2__0_n_0;
  wire derivative1_carry_i_2__1_n_0;
  wire derivative1_carry_i_2__2_n_0;
  wire derivative1_carry_i_2__3_n_0;
  wire derivative1_carry_i_2__4_n_0;
  wire derivative1_carry_i_2__5_n_0;
  wire derivative1_carry_i_2_n_0;
  wire derivative1_carry_i_3__0_n_0;
  wire derivative1_carry_i_3__1_n_0;
  wire derivative1_carry_i_3__2_n_0;
  wire derivative1_carry_i_3__3_n_0;
  wire derivative1_carry_i_3__4_n_0;
  wire derivative1_carry_i_3_n_0;
  wire derivative1_carry_i_4__0_n_0;
  wire derivative1_carry_i_4__1_n_0;
  wire derivative1_carry_i_4__2_n_0;
  wire derivative1_carry_i_4__3_n_0;
  wire derivative1_carry_i_4__4_n_0;
  wire derivative1_carry_i_4_n_0;
  wire derivative1_carry_n_0;
  wire derivative1_carry_n_1;
  wire derivative1_carry_n_2;
  wire derivative1_carry_n_3;
  wire \derivative[31]_i_1_n_0 ;
  wire [25:0]derivative_out;
  wire [31:0]error0;
  wire error0_carry__0_n_0;
  wire error0_carry__0_n_1;
  wire error0_carry__0_n_2;
  wire error0_carry__0_n_3;
  wire error0_carry__1_n_0;
  wire error0_carry__1_n_1;
  wire error0_carry__1_n_2;
  wire error0_carry__1_n_3;
  wire error0_carry__2_n_0;
  wire error0_carry__2_n_1;
  wire error0_carry__2_n_2;
  wire error0_carry__2_n_3;
  wire error0_carry__3_n_0;
  wire error0_carry__3_n_1;
  wire error0_carry__3_n_2;
  wire error0_carry__3_n_3;
  wire error0_carry__4_n_0;
  wire error0_carry__4_n_1;
  wire error0_carry__4_n_2;
  wire error0_carry__4_n_3;
  wire error0_carry__5_n_0;
  wire error0_carry__5_n_1;
  wire error0_carry__5_n_2;
  wire error0_carry__5_n_3;
  wire error0_carry__6_n_1;
  wire error0_carry__6_n_2;
  wire error0_carry__6_n_3;
  wire error0_carry_i_1__0_n_0;
  wire error0_carry_i_1__1_n_0;
  wire error0_carry_i_1__2_n_0;
  wire error0_carry_i_1__3_n_0;
  wire error0_carry_i_1__4_n_0;
  wire error0_carry_i_1__5_n_0;
  wire error0_carry_i_1__6_n_0;
  wire error0_carry_i_1_n_0;
  wire error0_carry_i_2__0_n_0;
  wire error0_carry_i_2__1_n_0;
  wire error0_carry_i_2__2_n_0;
  wire error0_carry_i_2__3_n_0;
  wire error0_carry_i_2__4_n_0;
  wire error0_carry_i_2__5_n_0;
  wire error0_carry_i_2__6_n_0;
  wire error0_carry_i_2_n_0;
  wire error0_carry_i_3__0_n_0;
  wire error0_carry_i_3__1_n_0;
  wire error0_carry_i_3__2_n_0;
  wire error0_carry_i_3__3_n_0;
  wire error0_carry_i_3__4_n_0;
  wire error0_carry_i_3__5_n_0;
  wire error0_carry_i_3__6_n_0;
  wire error0_carry_i_3_n_0;
  wire error0_carry_i_4__0_n_0;
  wire error0_carry_i_4__1_n_0;
  wire error0_carry_i_4__2_n_0;
  wire error0_carry_i_4__3_n_0;
  wire error0_carry_i_4__4_n_0;
  wire error0_carry_i_4__5_n_0;
  wire error0_carry_i_4__6_n_0;
  wire error0_carry_i_4_n_0;
  wire error0_carry_n_0;
  wire error0_carry_n_1;
  wire error0_carry_n_2;
  wire error0_carry_n_3;
  wire [25:0]error_in;
  wire integral0_carry__0_i_1_n_0;
  wire integral0_carry__0_i_2_n_0;
  wire integral0_carry__0_i_3_n_0;
  wire integral0_carry__0_i_4_n_0;
  wire integral0_carry__0_n_0;
  wire integral0_carry__0_n_1;
  wire integral0_carry__0_n_2;
  wire integral0_carry__0_n_3;
  wire integral0_carry__1_i_1_n_0;
  wire integral0_carry__1_i_2_n_0;
  wire integral0_carry__1_i_3_n_0;
  wire integral0_carry__1_i_4_n_0;
  wire integral0_carry__1_n_0;
  wire integral0_carry__1_n_1;
  wire integral0_carry__1_n_2;
  wire integral0_carry__1_n_3;
  wire integral0_carry__2_i_1_n_0;
  wire integral0_carry__2_i_2_n_0;
  wire integral0_carry__2_i_3_n_0;
  wire integral0_carry__2_i_4_n_0;
  wire integral0_carry__2_n_0;
  wire integral0_carry__2_n_1;
  wire integral0_carry__2_n_2;
  wire integral0_carry__2_n_3;
  wire integral0_carry__3_i_1_n_0;
  wire integral0_carry__3_i_2_n_0;
  wire integral0_carry__3_i_3_n_0;
  wire integral0_carry__3_i_4_n_0;
  wire integral0_carry__3_n_0;
  wire integral0_carry__3_n_1;
  wire integral0_carry__3_n_2;
  wire integral0_carry__3_n_3;
  wire integral0_carry__4_i_1_n_0;
  wire integral0_carry__4_i_2_n_0;
  wire integral0_carry__4_i_3_n_0;
  wire integral0_carry__4_i_4_n_0;
  wire integral0_carry__4_n_0;
  wire integral0_carry__4_n_1;
  wire integral0_carry__4_n_2;
  wire integral0_carry__4_n_3;
  wire integral0_carry__5_i_1_n_0;
  wire integral0_carry__5_i_2_n_0;
  wire integral0_carry__5_i_3_n_0;
  wire integral0_carry__5_i_4_n_0;
  wire integral0_carry__5_i_5_n_0;
  wire integral0_carry__5_n_0;
  wire integral0_carry__5_n_1;
  wire integral0_carry__5_n_2;
  wire integral0_carry__5_n_3;
  wire integral0_carry__6_i_1_n_0;
  wire integral0_carry__6_i_2_n_0;
  wire integral0_carry__6_i_3_n_0;
  wire integral0_carry__6_i_4_n_0;
  wire integral0_carry__6_n_1;
  wire integral0_carry__6_n_2;
  wire integral0_carry__6_n_3;
  wire integral0_carry_i_1_n_0;
  wire integral0_carry_i_2_n_0;
  wire integral0_carry_i_3_n_0;
  wire integral0_carry_i_4_n_0;
  wire integral0_carry_n_0;
  wire integral0_carry_n_1;
  wire integral0_carry_n_2;
  wire integral0_carry_n_3;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [0:0]new_target_angle_available;
  wire [31:0]p_0_in;
  wire [31:0]saved_target_angle;
  wire [31:0]target_angle;
  wire [3:1]NLW_derivative1_carry__5_CO_UNCONNECTED;
  wire [3:2]NLW_derivative1_carry__5_O_UNCONNECTED;
  wire [3:3]NLW_error0_carry__6_CO_UNCONNECTED;
  wire [3:3]NLW_integral0_carry__6_CO_UNCONNECTED;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1_carry
       (.CI(1'b0),
        .CO({derivative1_carry_n_0,derivative1_carry_n_1,derivative1_carry_n_2,derivative1_carry_n_3}),
        .CYINIT(1'b1),
        .DI(Q[3:0]),
        .O(derivative1[3:0]),
        .S({derivative1_carry_i_1_n_0,derivative1_carry_i_2_n_0,derivative1_carry_i_3_n_0,derivative1_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1_carry__0
       (.CI(derivative1_carry_n_0),
        .CO({derivative1_carry__0_n_0,derivative1_carry__0_n_1,derivative1_carry__0_n_2,derivative1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(Q[7:4]),
        .O(derivative1[7:4]),
        .S({derivative1_carry_i_1__0_n_0,derivative1_carry_i_2__0_n_0,derivative1_carry_i_3__0_n_0,derivative1_carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1_carry__1
       (.CI(derivative1_carry__0_n_0),
        .CO({derivative1_carry__1_n_0,derivative1_carry__1_n_1,derivative1_carry__1_n_2,derivative1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(Q[11:8]),
        .O(derivative1[11:8]),
        .S({derivative1_carry_i_1__1_n_0,derivative1_carry_i_2__1_n_0,derivative1_carry_i_3__1_n_0,derivative1_carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1_carry__2
       (.CI(derivative1_carry__1_n_0),
        .CO({derivative1_carry__2_n_0,derivative1_carry__2_n_1,derivative1_carry__2_n_2,derivative1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(Q[15:12]),
        .O(derivative1[15:12]),
        .S({derivative1_carry_i_1__2_n_0,derivative1_carry_i_2__2_n_0,derivative1_carry_i_3__2_n_0,derivative1_carry_i_4__2_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1_carry__3
       (.CI(derivative1_carry__2_n_0),
        .CO({derivative1_carry__3_n_0,derivative1_carry__3_n_1,derivative1_carry__3_n_2,derivative1_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(Q[19:16]),
        .O(derivative1[19:16]),
        .S({derivative1_carry_i_1__3_n_0,derivative1_carry_i_2__3_n_0,derivative1_carry_i_3__3_n_0,derivative1_carry_i_4__3_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1_carry__4
       (.CI(derivative1_carry__3_n_0),
        .CO({derivative1_carry__4_n_0,derivative1_carry__4_n_1,derivative1_carry__4_n_2,derivative1_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(Q[23:20]),
        .O(derivative1[23:20]),
        .S({derivative1_carry_i_1__4_n_0,derivative1_carry_i_2__4_n_0,derivative1_carry_i_3__4_n_0,derivative1_carry_i_4__4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1_carry__5
       (.CI(derivative1_carry__4_n_0),
        .CO({NLW_derivative1_carry__5_CO_UNCONNECTED[3:1],derivative1_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,Q[24]}),
        .O({NLW_derivative1_carry__5_O_UNCONNECTED[3:2],derivative1[25:24]}),
        .S({1'b0,1'b0,derivative1_carry_i_1__5_n_0,derivative1_carry_i_2__5_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_1
       (.I0(Q[3]),
        .I1(error_in[3]),
        .O(derivative1_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_1__0
       (.I0(Q[7]),
        .I1(error_in[7]),
        .O(derivative1_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_1__1
       (.I0(Q[11]),
        .I1(error_in[11]),
        .O(derivative1_carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_1__2
       (.I0(Q[15]),
        .I1(error_in[15]),
        .O(derivative1_carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_1__3
       (.I0(Q[19]),
        .I1(error_in[19]),
        .O(derivative1_carry_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_1__4
       (.I0(Q[23]),
        .I1(error_in[23]),
        .O(derivative1_carry_i_1__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_1__5
       (.I0(Q[25]),
        .I1(error_in[25]),
        .O(derivative1_carry_i_1__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_2
       (.I0(Q[2]),
        .I1(error_in[2]),
        .O(derivative1_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_2__0
       (.I0(Q[6]),
        .I1(error_in[6]),
        .O(derivative1_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_2__1
       (.I0(Q[10]),
        .I1(error_in[10]),
        .O(derivative1_carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_2__2
       (.I0(Q[14]),
        .I1(error_in[14]),
        .O(derivative1_carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_2__3
       (.I0(Q[18]),
        .I1(error_in[18]),
        .O(derivative1_carry_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_2__4
       (.I0(Q[22]),
        .I1(error_in[22]),
        .O(derivative1_carry_i_2__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_2__5
       (.I0(Q[24]),
        .I1(error_in[24]),
        .O(derivative1_carry_i_2__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_3
       (.I0(Q[1]),
        .I1(error_in[1]),
        .O(derivative1_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_3__0
       (.I0(Q[5]),
        .I1(error_in[5]),
        .O(derivative1_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_3__1
       (.I0(Q[9]),
        .I1(error_in[9]),
        .O(derivative1_carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_3__2
       (.I0(Q[13]),
        .I1(error_in[13]),
        .O(derivative1_carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_3__3
       (.I0(Q[17]),
        .I1(error_in[17]),
        .O(derivative1_carry_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_3__4
       (.I0(Q[21]),
        .I1(error_in[21]),
        .O(derivative1_carry_i_3__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_4
       (.I0(Q[0]),
        .I1(error_in[0]),
        .O(derivative1_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_4__0
       (.I0(Q[4]),
        .I1(error_in[4]),
        .O(derivative1_carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_4__1
       (.I0(Q[8]),
        .I1(error_in[8]),
        .O(derivative1_carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_4__2
       (.I0(Q[12]),
        .I1(error_in[12]),
        .O(derivative1_carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_4__3
       (.I0(Q[16]),
        .I1(error_in[16]),
        .O(derivative1_carry_i_4__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative1_carry_i_4__4
       (.I0(Q[20]),
        .I1(error_in[20]),
        .O(derivative1_carry_i_4__4_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_1 
       (.I0(new_target_angle_available),
        .O(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[10] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[4]),
        .Q(derivative_out[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[11] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[5]),
        .Q(derivative_out[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[12] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[6]),
        .Q(derivative_out[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[13] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[7]),
        .Q(derivative_out[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[14] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[8]),
        .Q(derivative_out[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[15] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[9]),
        .Q(derivative_out[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[16] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[10]),
        .Q(derivative_out[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[17] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[11]),
        .Q(derivative_out[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[18] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[12]),
        .Q(derivative_out[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[19] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[13]),
        .Q(derivative_out[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[20] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[14]),
        .Q(derivative_out[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[21] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[15]),
        .Q(derivative_out[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[22] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[16]),
        .Q(derivative_out[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[23] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[17]),
        .Q(derivative_out[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[24] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[18]),
        .Q(derivative_out[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[25] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[19]),
        .Q(derivative_out[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[26] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[20]),
        .Q(derivative_out[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[27] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[21]),
        .Q(derivative_out[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[28] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[22]),
        .Q(derivative_out[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[29] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[23]),
        .Q(derivative_out[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[30] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[24]),
        .Q(derivative_out[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[31] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[25]),
        .Q(derivative_out[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[6] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[0]),
        .Q(derivative_out[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[7] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[1]),
        .Q(derivative_out[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[8] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[2]),
        .Q(derivative_out[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[9] 
       (.C(clock),
        .CE(\derivative[31]_i_1_n_0 ),
        .D(derivative1[3]),
        .Q(derivative_out[3]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry
       (.CI(1'b0),
        .CO({error0_carry_n_0,error0_carry_n_1,error0_carry_n_2,error0_carry_n_3}),
        .CYINIT(1'b1),
        .DI(saved_target_angle[3:0]),
        .O(error0[3:0]),
        .S({error0_carry_i_1_n_0,error0_carry_i_2_n_0,error0_carry_i_3_n_0,error0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__0
       (.CI(error0_carry_n_0),
        .CO({error0_carry__0_n_0,error0_carry__0_n_1,error0_carry__0_n_2,error0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(saved_target_angle[7:4]),
        .O(error0[7:4]),
        .S({error0_carry_i_1__0_n_0,error0_carry_i_2__0_n_0,error0_carry_i_3__0_n_0,error0_carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__1
       (.CI(error0_carry__0_n_0),
        .CO({error0_carry__1_n_0,error0_carry__1_n_1,error0_carry__1_n_2,error0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(saved_target_angle[11:8]),
        .O(error0[11:8]),
        .S({error0_carry_i_1__1_n_0,error0_carry_i_2__1_n_0,error0_carry_i_3__1_n_0,error0_carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__2
       (.CI(error0_carry__1_n_0),
        .CO({error0_carry__2_n_0,error0_carry__2_n_1,error0_carry__2_n_2,error0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(saved_target_angle[15:12]),
        .O(error0[15:12]),
        .S({error0_carry_i_1__2_n_0,error0_carry_i_2__2_n_0,error0_carry_i_3__2_n_0,error0_carry_i_4__2_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__3
       (.CI(error0_carry__2_n_0),
        .CO({error0_carry__3_n_0,error0_carry__3_n_1,error0_carry__3_n_2,error0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(saved_target_angle[19:16]),
        .O(error0[19:16]),
        .S({error0_carry_i_1__3_n_0,error0_carry_i_2__3_n_0,error0_carry_i_3__3_n_0,error0_carry_i_4__3_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__4
       (.CI(error0_carry__3_n_0),
        .CO({error0_carry__4_n_0,error0_carry__4_n_1,error0_carry__4_n_2,error0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(saved_target_angle[23:20]),
        .O(error0[23:20]),
        .S({error0_carry_i_1__4_n_0,error0_carry_i_2__4_n_0,error0_carry_i_3__4_n_0,error0_carry_i_4__4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__5
       (.CI(error0_carry__4_n_0),
        .CO({error0_carry__5_n_0,error0_carry__5_n_1,error0_carry__5_n_2,error0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(saved_target_angle[27:24]),
        .O(error0[27:24]),
        .S({error0_carry_i_1__5_n_0,error0_carry_i_2__5_n_0,error0_carry_i_3__5_n_0,error0_carry_i_4__5_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__6
       (.CI(error0_carry__5_n_0),
        .CO({NLW_error0_carry__6_CO_UNCONNECTED[3],error0_carry__6_n_1,error0_carry__6_n_2,error0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,saved_target_angle[30:28]}),
        .O(error0[31:28]),
        .S({error0_carry_i_1__6_n_0,error0_carry_i_2__6_n_0,error0_carry_i_3__6_n_0,error0_carry_i_4__6_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1
       (.I0(saved_target_angle[3]),
        .I1(angle[3]),
        .O(error0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__0
       (.I0(saved_target_angle[7]),
        .I1(angle[7]),
        .O(error0_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__1
       (.I0(saved_target_angle[11]),
        .I1(angle[11]),
        .O(error0_carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__2
       (.I0(saved_target_angle[15]),
        .I1(angle[15]),
        .O(error0_carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__3
       (.I0(saved_target_angle[19]),
        .I1(angle[19]),
        .O(error0_carry_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__4
       (.I0(saved_target_angle[23]),
        .I1(angle[23]),
        .O(error0_carry_i_1__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__5
       (.I0(saved_target_angle[27]),
        .I1(angle[27]),
        .O(error0_carry_i_1__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__6
       (.I0(saved_target_angle[31]),
        .I1(angle[31]),
        .O(error0_carry_i_1__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2
       (.I0(saved_target_angle[2]),
        .I1(angle[2]),
        .O(error0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__0
       (.I0(saved_target_angle[6]),
        .I1(angle[6]),
        .O(error0_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__1
       (.I0(saved_target_angle[10]),
        .I1(angle[10]),
        .O(error0_carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__2
       (.I0(saved_target_angle[14]),
        .I1(angle[14]),
        .O(error0_carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__3
       (.I0(saved_target_angle[18]),
        .I1(angle[18]),
        .O(error0_carry_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__4
       (.I0(saved_target_angle[22]),
        .I1(angle[22]),
        .O(error0_carry_i_2__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__5
       (.I0(saved_target_angle[26]),
        .I1(angle[26]),
        .O(error0_carry_i_2__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__6
       (.I0(saved_target_angle[30]),
        .I1(angle[30]),
        .O(error0_carry_i_2__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3
       (.I0(saved_target_angle[1]),
        .I1(angle[1]),
        .O(error0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__0
       (.I0(saved_target_angle[5]),
        .I1(angle[5]),
        .O(error0_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__1
       (.I0(saved_target_angle[9]),
        .I1(angle[9]),
        .O(error0_carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__2
       (.I0(saved_target_angle[13]),
        .I1(angle[13]),
        .O(error0_carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__3
       (.I0(saved_target_angle[17]),
        .I1(angle[17]),
        .O(error0_carry_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__4
       (.I0(saved_target_angle[21]),
        .I1(angle[21]),
        .O(error0_carry_i_3__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__5
       (.I0(saved_target_angle[25]),
        .I1(angle[25]),
        .O(error0_carry_i_3__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__6
       (.I0(saved_target_angle[29]),
        .I1(angle[29]),
        .O(error0_carry_i_3__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4
       (.I0(saved_target_angle[0]),
        .I1(angle[0]),
        .O(error0_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__0
       (.I0(saved_target_angle[4]),
        .I1(angle[4]),
        .O(error0_carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__1
       (.I0(saved_target_angle[8]),
        .I1(angle[8]),
        .O(error0_carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__2
       (.I0(saved_target_angle[12]),
        .I1(angle[12]),
        .O(error0_carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__3
       (.I0(saved_target_angle[16]),
        .I1(angle[16]),
        .O(error0_carry_i_4__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__4
       (.I0(saved_target_angle[20]),
        .I1(angle[20]),
        .O(error0_carry_i_4__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__5
       (.I0(saved_target_angle[24]),
        .I1(angle[24]),
        .O(error0_carry_i_4__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__6
       (.I0(saved_target_angle[28]),
        .I1(angle[28]),
        .O(error0_carry_i_4__6_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[0]),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[10]),
        .Q(Q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[11]),
        .Q(Q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[12]),
        .Q(Q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[13]),
        .Q(Q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[14]),
        .Q(Q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[15]),
        .Q(Q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[16]),
        .Q(Q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[17]),
        .Q(Q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[18]),
        .Q(Q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[19]),
        .Q(Q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[1]),
        .Q(Q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[20]),
        .Q(Q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[21]),
        .Q(Q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[22]),
        .Q(Q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[23]),
        .Q(Q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[24]),
        .Q(Q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[25]),
        .Q(Q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[26]),
        .Q(Q[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[27]),
        .Q(Q[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[28]),
        .Q(Q[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[29]),
        .Q(Q[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[2]),
        .Q(Q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[30]),
        .Q(Q[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[31]),
        .Q(Q[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[3]),
        .Q(Q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[4]),
        .Q(Q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[5]),
        .Q(Q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[6]),
        .Q(Q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[7]),
        .Q(Q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[8]),
        .Q(Q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(error0[9]),
        .Q(Q[9]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry
       (.CI(1'b0),
        .CO({integral0_carry_n_0,integral0_carry_n_1,integral0_carry_n_2,integral0_carry_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[3:0]),
        .O(p_0_in[3:0]),
        .S({integral0_carry_i_1_n_0,integral0_carry_i_2_n_0,integral0_carry_i_3_n_0,integral0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__0
       (.CI(integral0_carry_n_0),
        .CO({integral0_carry__0_n_0,integral0_carry__0_n_1,integral0_carry__0_n_2,integral0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[7:4]),
        .O(p_0_in[7:4]),
        .S({integral0_carry__0_i_1_n_0,integral0_carry__0_i_2_n_0,integral0_carry__0_i_3_n_0,integral0_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_1
       (.I0(integral_in[7]),
        .I1(Q[13]),
        .O(integral0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_2
       (.I0(integral_in[6]),
        .I1(Q[12]),
        .O(integral0_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_3
       (.I0(integral_in[5]),
        .I1(Q[11]),
        .O(integral0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_4
       (.I0(integral_in[4]),
        .I1(Q[10]),
        .O(integral0_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__1
       (.CI(integral0_carry__0_n_0),
        .CO({integral0_carry__1_n_0,integral0_carry__1_n_1,integral0_carry__1_n_2,integral0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[11:8]),
        .O(p_0_in[11:8]),
        .S({integral0_carry__1_i_1_n_0,integral0_carry__1_i_2_n_0,integral0_carry__1_i_3_n_0,integral0_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_1
       (.I0(integral_in[11]),
        .I1(Q[17]),
        .O(integral0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_2
       (.I0(integral_in[10]),
        .I1(Q[16]),
        .O(integral0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_3
       (.I0(integral_in[9]),
        .I1(Q[15]),
        .O(integral0_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_4
       (.I0(integral_in[8]),
        .I1(Q[14]),
        .O(integral0_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__2
       (.CI(integral0_carry__1_n_0),
        .CO({integral0_carry__2_n_0,integral0_carry__2_n_1,integral0_carry__2_n_2,integral0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[15:12]),
        .O(p_0_in[15:12]),
        .S({integral0_carry__2_i_1_n_0,integral0_carry__2_i_2_n_0,integral0_carry__2_i_3_n_0,integral0_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_1
       (.I0(integral_in[15]),
        .I1(Q[21]),
        .O(integral0_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_2
       (.I0(integral_in[14]),
        .I1(Q[20]),
        .O(integral0_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_3
       (.I0(integral_in[13]),
        .I1(Q[19]),
        .O(integral0_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_4
       (.I0(integral_in[12]),
        .I1(Q[18]),
        .O(integral0_carry__2_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__3
       (.CI(integral0_carry__2_n_0),
        .CO({integral0_carry__3_n_0,integral0_carry__3_n_1,integral0_carry__3_n_2,integral0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[19:16]),
        .O(p_0_in[19:16]),
        .S({integral0_carry__3_i_1_n_0,integral0_carry__3_i_2_n_0,integral0_carry__3_i_3_n_0,integral0_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_1
       (.I0(integral_in[19]),
        .I1(Q[25]),
        .O(integral0_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_2
       (.I0(integral_in[18]),
        .I1(Q[24]),
        .O(integral0_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_3
       (.I0(integral_in[17]),
        .I1(Q[23]),
        .O(integral0_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_4
       (.I0(integral_in[16]),
        .I1(Q[22]),
        .O(integral0_carry__3_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__4
       (.CI(integral0_carry__3_n_0),
        .CO({integral0_carry__4_n_0,integral0_carry__4_n_1,integral0_carry__4_n_2,integral0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[23:20]),
        .O(p_0_in[23:20]),
        .S({integral0_carry__4_i_1_n_0,integral0_carry__4_i_2_n_0,integral0_carry__4_i_3_n_0,integral0_carry__4_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_1
       (.I0(integral_in[23]),
        .I1(Q[29]),
        .O(integral0_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_2
       (.I0(integral_in[22]),
        .I1(Q[28]),
        .O(integral0_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_3
       (.I0(integral_in[21]),
        .I1(Q[27]),
        .O(integral0_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_4
       (.I0(integral_in[20]),
        .I1(Q[26]),
        .O(integral0_carry__4_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__5
       (.CI(integral0_carry__4_n_0),
        .CO({integral0_carry__5_n_0,integral0_carry__5_n_1,integral0_carry__5_n_2,integral0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({integral_in[26],integral0_carry__5_i_1_n_0,Q[31],integral_in[24]}),
        .O(p_0_in[27:24]),
        .S({integral0_carry__5_i_2_n_0,integral0_carry__5_i_3_n_0,integral0_carry__5_i_4_n_0,integral0_carry__5_i_5_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    integral0_carry__5_i_1
       (.I0(Q[31]),
        .O(integral0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    integral0_carry__5_i_2
       (.I0(integral_in[26]),
        .I1(integral_in[27]),
        .O(integral0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__5_i_3
       (.I0(Q[31]),
        .I1(integral_in[26]),
        .O(integral0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__5_i_4
       (.I0(Q[31]),
        .I1(integral_in[25]),
        .O(integral0_carry__5_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__5_i_5
       (.I0(integral_in[24]),
        .I1(Q[30]),
        .O(integral0_carry__5_i_5_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__6
       (.CI(integral0_carry__5_n_0),
        .CO({NLW_integral0_carry__6_CO_UNCONNECTED[3],integral0_carry__6_n_1,integral0_carry__6_n_2,integral0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,integral_in[29:27]}),
        .O(p_0_in[31:28]),
        .S({integral0_carry__6_i_1_n_0,integral0_carry__6_i_2_n_0,integral0_carry__6_i_3_n_0,integral0_carry__6_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    integral0_carry__6_i_1
       (.I0(integral_in[30]),
        .I1(integral_in[31]),
        .O(integral0_carry__6_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    integral0_carry__6_i_2
       (.I0(integral_in[29]),
        .I1(integral_in[30]),
        .O(integral0_carry__6_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    integral0_carry__6_i_3
       (.I0(integral_in[28]),
        .I1(integral_in[29]),
        .O(integral0_carry__6_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    integral0_carry__6_i_4
       (.I0(integral_in[27]),
        .I1(integral_in[28]),
        .O(integral0_carry__6_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1
       (.I0(integral_in[3]),
        .I1(Q[9]),
        .O(integral0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2
       (.I0(integral_in[2]),
        .I1(Q[8]),
        .O(integral0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3
       (.I0(integral_in[1]),
        .I1(Q[7]),
        .O(integral0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4
       (.I0(integral_in[0]),
        .I1(Q[6]),
        .O(integral0_carry_i_4_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(integral_out[0]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[10]),
        .Q(integral_out[10]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[11]),
        .Q(integral_out[11]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[12]),
        .Q(integral_out[12]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[13]),
        .Q(integral_out[13]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[14]),
        .Q(integral_out[14]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[15]),
        .Q(integral_out[15]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[16]),
        .Q(integral_out[16]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[17]),
        .Q(integral_out[17]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[18]),
        .Q(integral_out[18]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[19]),
        .Q(integral_out[19]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(integral_out[1]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[20]),
        .Q(integral_out[20]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[21]),
        .Q(integral_out[21]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[22]),
        .Q(integral_out[22]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[23]),
        .Q(integral_out[23]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[24]),
        .Q(integral_out[24]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[25]),
        .Q(integral_out[25]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[26]),
        .Q(integral_out[26]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[27]),
        .Q(integral_out[27]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[28]),
        .Q(integral_out[28]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[29]),
        .Q(integral_out[29]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(integral_out[2]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[30]),
        .Q(integral_out[30]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[31]),
        .Q(integral_out[31]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(integral_out[3]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(integral_out[4]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[5]),
        .Q(integral_out[5]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[6]),
        .Q(integral_out[6]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[7]),
        .Q(integral_out[7]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[8]),
        .Q(integral_out[8]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[9]),
        .Q(integral_out[9]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[0] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[0]),
        .Q(saved_target_angle[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[10] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[10]),
        .Q(saved_target_angle[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[11] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[11]),
        .Q(saved_target_angle[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[12] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[12]),
        .Q(saved_target_angle[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[13] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[13]),
        .Q(saved_target_angle[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[14] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[14]),
        .Q(saved_target_angle[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[15] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[15]),
        .Q(saved_target_angle[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[16] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[16]),
        .Q(saved_target_angle[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[17] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[17]),
        .Q(saved_target_angle[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[18] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[18]),
        .Q(saved_target_angle[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[19] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[19]),
        .Q(saved_target_angle[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[1] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[1]),
        .Q(saved_target_angle[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[20] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[20]),
        .Q(saved_target_angle[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[21] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[21]),
        .Q(saved_target_angle[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[22] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[22]),
        .Q(saved_target_angle[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[23] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[23]),
        .Q(saved_target_angle[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[24] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[24]),
        .Q(saved_target_angle[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[25] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[25]),
        .Q(saved_target_angle[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[26] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[26]),
        .Q(saved_target_angle[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[27] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[27]),
        .Q(saved_target_angle[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[28] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[28]),
        .Q(saved_target_angle[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[29] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[29]),
        .Q(saved_target_angle[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[2] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[2]),
        .Q(saved_target_angle[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[30] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[30]),
        .Q(saved_target_angle[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[31] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[31]),
        .Q(saved_target_angle[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[3] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[3]),
        .Q(saved_target_angle[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[4] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[4]),
        .Q(saved_target_angle[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[5] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[5]),
        .Q(saved_target_angle[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[6] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[6]),
        .Q(saved_target_angle[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[7] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[7]),
        .Q(saved_target_angle[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[8] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[8]),
        .Q(saved_target_angle[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[9] 
       (.C(clock),
        .CE(new_target_angle_available),
        .D(target_angle[9]),
        .Q(saved_target_angle[9]),
        .R(1'b0));
endmodule

(* CHECK_LICENSE_TYPE = "pid_reexpanded_initial_math_0_0,initial_math,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "initial_math,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clock,
    angle,
    target_angle,
    new_target_angle_available,
    error_in,
    integral_in,
    error_out,
    integral_out,
    derivative_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_reexpanded_clock_0, INSERT_VIP 0" *) input [0:0]clock;
  input [31:0]angle;
  input [31:0]target_angle;
  input [0:0]new_target_angle_available;
  input [31:0]error_in;
  input [31:0]integral_in;
  output [31:0]error_out;
  output [31:0]integral_out;
  output [31:0]derivative_out;

  wire \<const0> ;
  wire [31:0]angle;
  wire [0:0]clock;
  wire [31:6]\^derivative_out ;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [0:0]new_target_angle_available;
  wire [31:0]target_angle;

  assign derivative_out[31:6] = \^derivative_out [31:6];
  assign derivative_out[5] = \<const0> ;
  assign derivative_out[4] = \<const0> ;
  assign derivative_out[3] = \<const0> ;
  assign derivative_out[2] = \<const0> ;
  assign derivative_out[1] = \<const0> ;
  assign derivative_out[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math inst
       (.Q(error_out),
        .angle(angle),
        .clock(clock),
        .derivative_out(\^derivative_out ),
        .error_in(error_in[25:0]),
        .integral_in(integral_in),
        .integral_out(integral_out),
        .new_target_angle_available(new_target_angle_available),
        .target_angle(target_angle));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
