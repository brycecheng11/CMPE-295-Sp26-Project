// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Wed Oct 28 20:21:27 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_reexpanded_prev_value_flip_flop_0_0_sim_netlist.v
// Design      : pid_reexpanded_prev_value_flip_flop_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "pid_reexpanded_prev_value_flip_flop_0_0,prev_value_flip_flop,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "prev_value_flip_flop,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clock,
    new_target_angle_available,
    error_in,
    integral_in,
    error_out,
    integral_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_reexpanded_clock_0, INSERT_VIP 0" *) input [0:0]clock;
  input [0:0]new_target_angle_available;
  input [31:0]error_in;
  input [31:0]integral_in;
  output [31:0]error_out;
  output [31:0]integral_out;

  wire [0:0]clock;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [0:0]new_target_angle_available;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop inst
       (.clock(clock),
        .error_in(error_in),
        .error_out(error_out),
        .integral_in(integral_in),
        .integral_out(integral_out),
        .new_target_angle_available(new_target_angle_available));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop
   (error_out,
    integral_out,
    error_in,
    clock,
    new_target_angle_available,
    integral_in);
  output [31:0]error_out;
  output [31:0]integral_out;
  input [31:0]error_in;
  input [0:0]clock;
  input [0:0]new_target_angle_available;
  input [31:0]integral_in;

  wire [0:0]clock;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [0:0]new_target_angle_available;

  FDRE #(
    .INIT(1'b0)) 
    \error_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[0]),
        .Q(error_out[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[10]),
        .Q(error_out[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[11]),
        .Q(error_out[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[12]),
        .Q(error_out[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[13]),
        .Q(error_out[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[14]),
        .Q(error_out[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[15]),
        .Q(error_out[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[16]),
        .Q(error_out[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[17]),
        .Q(error_out[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[18]),
        .Q(error_out[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[19]),
        .Q(error_out[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[1]),
        .Q(error_out[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[20]),
        .Q(error_out[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[21]),
        .Q(error_out[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[22]),
        .Q(error_out[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[23]),
        .Q(error_out[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[24]),
        .Q(error_out[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[25]),
        .Q(error_out[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[26]),
        .Q(error_out[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[27]),
        .Q(error_out[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[28]),
        .Q(error_out[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[29]),
        .Q(error_out[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[2]),
        .Q(error_out[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[30]),
        .Q(error_out[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[31]),
        .Q(error_out[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[3]),
        .Q(error_out[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[4]),
        .Q(error_out[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[5]),
        .Q(error_out[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[6]),
        .Q(error_out[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[7]),
        .Q(error_out[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[8]),
        .Q(error_out[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[9]),
        .Q(error_out[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[0]),
        .Q(integral_out[0]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[10]),
        .Q(integral_out[10]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[11]),
        .Q(integral_out[11]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[12]),
        .Q(integral_out[12]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[13]),
        .Q(integral_out[13]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[14]),
        .Q(integral_out[14]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[15]),
        .Q(integral_out[15]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[16]),
        .Q(integral_out[16]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[17]),
        .Q(integral_out[17]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[18]),
        .Q(integral_out[18]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[19]),
        .Q(integral_out[19]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[1]),
        .Q(integral_out[1]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[20]),
        .Q(integral_out[20]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[21]),
        .Q(integral_out[21]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[22]),
        .Q(integral_out[22]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[23]),
        .Q(integral_out[23]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[24]),
        .Q(integral_out[24]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[25]),
        .Q(integral_out[25]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[26]),
        .Q(integral_out[26]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[27]),
        .Q(integral_out[27]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[28]),
        .Q(integral_out[28]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[29]),
        .Q(integral_out[29]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[2]),
        .Q(integral_out[2]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[30]),
        .Q(integral_out[30]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[31]),
        .Q(integral_out[31]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[3]),
        .Q(integral_out[3]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[4]),
        .Q(integral_out[4]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[5]),
        .Q(integral_out[5]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[6]),
        .Q(integral_out[6]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[7]),
        .Q(integral_out[7]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[8]),
        .Q(integral_out[8]),
        .R(new_target_angle_available));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[9]),
        .Q(integral_out[9]),
        .R(new_target_angle_available));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
