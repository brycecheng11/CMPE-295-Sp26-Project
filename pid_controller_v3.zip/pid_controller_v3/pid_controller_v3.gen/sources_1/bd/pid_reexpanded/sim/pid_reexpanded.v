//Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
//Date        : Thu Oct 29 13:03:07 2026
//Host        : Dell-XPS running 64-bit major release  (build 9200)
//Command     : generate_target pid_reexpanded.bd
//Design      : pid_reexpanded
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "pid_reexpanded,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=pid_reexpanded,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=5,numReposBlks=5,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=5,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "pid_reexpanded.hwdef" *) 
module pid_reexpanded
   (angle_0,
    angle_out_0,
    kd_in_0,
    ki_in_0,
    kp_in_0,
    new_target_angle_available_0,
    new_velocity_available_0,
    output_velocity_0,
    sys_clk,
    target_angle_0);
  input [31:0]angle_0;
  output [31:0]angle_out_0;
  input [11:0]kd_in_0;
  input [11:0]ki_in_0;
  input [11:0]kp_in_0;
  input [0:0]new_target_angle_available_0;
  output [0:0]new_velocity_available_0;
  output [31:0]output_velocity_0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.SYS_CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.SYS_CLK, CLK_DOMAIN pid_reexpanded_clock_0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input [0:0]sys_clk;
  input [31:0]target_angle_0;

  wire [31:0]angle_0_1;
  wire [0:0]clock_0_1;
  wire [31:0]initial_math_0_angle_out;
  wire [31:0]initial_math_0_derivative_out;
  wire [31:0]initial_math_0_error_out;
  wire [31:0]initial_math_0_integral_out;
  wire [8:0]k_math_0_kd_out;
  wire [8:0]k_math_0_ki_out;
  wire [8:0]k_math_0_kp_out;
  wire [11:0]kd_in_0_1;
  wire [11:0]ki_in_0_1;
  wire [11:0]kp_in_0_1;
  wire [0:0]new_target_angle_available_0_1;
  wire [31:0]prev_value_flip_flop_0_error_out;
  wire [31:0]prev_value_flip_flop_0_integral_out;
  wire [31:0]target_angle_0_1;
  wire [31:0]term_calculation_0_d_term;
  wire [31:0]term_calculation_0_i_term;
  wire [31:0]term_calculation_0_p_term;
  wire velocity_calculation_0_new_velocity_available;
  wire [31:0]velocity_calculation_0_output_velocity;

  assign angle_0_1 = angle_0[31:0];
  assign angle_out_0[31:0] = initial_math_0_angle_out;
  assign clock_0_1 = sys_clk[0];
  assign kd_in_0_1 = kd_in_0[11:0];
  assign ki_in_0_1 = ki_in_0[11:0];
  assign kp_in_0_1 = kp_in_0[11:0];
  assign new_target_angle_available_0_1 = new_target_angle_available_0[0];
  assign new_velocity_available_0[0] = velocity_calculation_0_new_velocity_available;
  assign output_velocity_0[31:0] = velocity_calculation_0_output_velocity;
  assign target_angle_0_1 = target_angle_0[31:0];
  pid_reexpanded_initial_math_0_0 initial_math_0
       (.angle(angle_0_1),
        .angle_out(initial_math_0_angle_out),
        .clock(clock_0_1),
        .derivative_out(initial_math_0_derivative_out),
        .error_in(prev_value_flip_flop_0_error_out),
        .error_out(initial_math_0_error_out),
        .integral_in(prev_value_flip_flop_0_integral_out),
        .integral_out(initial_math_0_integral_out),
        .new_target_angle_available(new_target_angle_available_0_1),
        .target_angle(target_angle_0_1));
  pid_reexpanded_k_math_0_0 k_math_0
       (.clock(clock_0_1),
        .kd_in(kd_in_0_1),
        .kd_out(k_math_0_kd_out),
        .ki_in(ki_in_0_1),
        .ki_out(k_math_0_ki_out),
        .kp_in(kp_in_0_1),
        .kp_out(k_math_0_kp_out));
  pid_reexpanded_prev_value_flip_flop_0_0 prev_value_flip_flop_0
       (.clock(clock_0_1),
        .error_in(initial_math_0_error_out),
        .error_out(prev_value_flip_flop_0_error_out),
        .integral_in(initial_math_0_integral_out),
        .integral_out(prev_value_flip_flop_0_integral_out),
        .new_target_angle_available(new_target_angle_available_0_1));
  pid_reexpanded_term_calculation_0_0 term_calculation_0
       (.clock(clock_0_1),
        .d_term(term_calculation_0_d_term),
        .derivative(initial_math_0_derivative_out),
        .error(initial_math_0_error_out),
        .i_term(term_calculation_0_i_term),
        .integral(initial_math_0_integral_out),
        .kd(k_math_0_kd_out),
        .ki(k_math_0_ki_out),
        .kp(k_math_0_kp_out),
        .p_term(term_calculation_0_p_term));
  pid_reexpanded_velocity_calculation_0_0 velocity_calculation_0
       (.clock(clock_0_1),
        .d_term(term_calculation_0_d_term),
        .i_term(term_calculation_0_i_term),
        .new_velocity_available(velocity_calculation_0_new_velocity_available),
        .output_velocity(velocity_calculation_0_output_velocity),
        .p_term(term_calculation_0_p_term));
endmodule
