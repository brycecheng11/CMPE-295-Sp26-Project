-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Thu Nov  5 13:25:21 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Xilinx/Projects/pid_controller_v3/pid_controller_v3.gen/sources_1/bd/pid_reexpanded/ip/pid_reexpanded_velocity_calculation_0_0/pid_reexpanded_velocity_calculation_0_0_sim_netlist.vhdl
-- Design      : pid_reexpanded_velocity_calculation_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity pid_reexpanded_velocity_calculation_0_0_velocity_calculation is
  port (
    output_velocity : out STD_LOGIC_VECTOR ( 20 downto 0 );
    new_velocity_available : out STD_LOGIC;
    d_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    p_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clock : in STD_LOGIC;
    send_it : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of pid_reexpanded_velocity_calculation_0_0_velocity_calculation : entity is "velocity_calculation";
end pid_reexpanded_velocity_calculation_0_0_velocity_calculation;

architecture STRUCTURE of pid_reexpanded_velocity_calculation_0_0_velocity_calculation is
  signal \i__carry_i_10__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__0_n_1\ : STD_LOGIC;
  signal \i__carry_i_10__0_n_2\ : STD_LOGIC;
  signal \i__carry_i_10__0_n_3\ : STD_LOGIC;
  signal \i__carry_i_10__0_n_4\ : STD_LOGIC;
  signal \i__carry_i_10__0_n_5\ : STD_LOGIC;
  signal \i__carry_i_10__0_n_6\ : STD_LOGIC;
  signal \i__carry_i_10__0_n_7\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_1\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_2\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_3\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_4\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_5\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_6\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_7\ : STD_LOGIC;
  signal \i__carry_i_10__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_10_n_0\ : STD_LOGIC;
  signal \i__carry_i_10_n_1\ : STD_LOGIC;
  signal \i__carry_i_10_n_2\ : STD_LOGIC;
  signal \i__carry_i_10_n_3\ : STD_LOGIC;
  signal \i__carry_i_10_n_4\ : STD_LOGIC;
  signal \i__carry_i_10_n_5\ : STD_LOGIC;
  signal \i__carry_i_10_n_6\ : STD_LOGIC;
  signal \i__carry_i_10_n_7\ : STD_LOGIC;
  signal \i__carry_i_11__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_11_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_12_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_13_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_14_n_0\ : STD_LOGIC;
  signal \i__carry_i_15__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_15__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_15__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_15_n_0\ : STD_LOGIC;
  signal \i__carry_i_16__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_16__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_16__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_16_n_0\ : STD_LOGIC;
  signal \i__carry_i_17__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_17__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_17__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_17_n_0\ : STD_LOGIC;
  signal \i__carry_i_18__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_18__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_18_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_1\ : STD_LOGIC;
  signal \i__carry_i_2_n_2\ : STD_LOGIC;
  signal \i__carry_i_2_n_3\ : STD_LOGIC;
  signal \i__carry_i_2_n_4\ : STD_LOGIC;
  signal \i__carry_i_2_n_5\ : STD_LOGIC;
  signal \i__carry_i_2_n_6\ : STD_LOGIC;
  signal \i__carry_i_2_n_7\ : STD_LOGIC;
  signal \i__carry_i_3__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_4_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_5_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_1\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_2\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_3\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_4\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_5\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_6\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_7\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_1\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_2\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_3\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_4\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_5\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_6\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_7\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_1\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_2\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_3\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_4\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_5\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_6\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_7\ : STD_LOGIC;
  signal \i__carry_i_9_n_0\ : STD_LOGIC;
  signal \i__carry_i_9_n_1\ : STD_LOGIC;
  signal \i__carry_i_9_n_2\ : STD_LOGIC;
  signal \i__carry_i_9_n_3\ : STD_LOGIC;
  signal \i__carry_i_9_n_4\ : STD_LOGIC;
  signal \i__carry_i_9_n_5\ : STD_LOGIC;
  signal \i__carry_i_9_n_6\ : STD_LOGIC;
  signal \i__carry_i_9_n_7\ : STD_LOGIC;
  signal interim : STD_LOGIC_VECTOR ( 30 downto 0 );
  signal \interim[0]_i_10_n_0\ : STD_LOGIC;
  signal \interim[0]_i_12_n_0\ : STD_LOGIC;
  signal \interim[0]_i_13_n_0\ : STD_LOGIC;
  signal \interim[0]_i_14_n_0\ : STD_LOGIC;
  signal \interim[0]_i_15_n_0\ : STD_LOGIC;
  signal \interim[0]_i_16_n_0\ : STD_LOGIC;
  signal \interim[0]_i_17_n_0\ : STD_LOGIC;
  signal \interim[0]_i_18_n_0\ : STD_LOGIC;
  signal \interim[0]_i_19_n_0\ : STD_LOGIC;
  signal \interim[0]_i_20_n_0\ : STD_LOGIC;
  signal \interim[0]_i_21_n_0\ : STD_LOGIC;
  signal \interim[0]_i_22_n_0\ : STD_LOGIC;
  signal \interim[0]_i_23_n_0\ : STD_LOGIC;
  signal \interim[0]_i_24_n_0\ : STD_LOGIC;
  signal \interim[0]_i_25_n_0\ : STD_LOGIC;
  signal \interim[0]_i_26_n_0\ : STD_LOGIC;
  signal \interim[0]_i_3_n_0\ : STD_LOGIC;
  signal \interim[0]_i_4_n_0\ : STD_LOGIC;
  signal \interim[0]_i_5_n_0\ : STD_LOGIC;
  signal \interim[0]_i_6_n_0\ : STD_LOGIC;
  signal \interim[0]_i_7_n_0\ : STD_LOGIC;
  signal \interim[0]_i_8_n_0\ : STD_LOGIC;
  signal \interim[0]_i_9_n_0\ : STD_LOGIC;
  signal \interim[12]_i_2_n_0\ : STD_LOGIC;
  signal \interim[12]_i_3_n_0\ : STD_LOGIC;
  signal \interim[12]_i_4_n_0\ : STD_LOGIC;
  signal \interim[12]_i_5_n_0\ : STD_LOGIC;
  signal \interim[12]_i_6_n_0\ : STD_LOGIC;
  signal \interim[12]_i_7_n_0\ : STD_LOGIC;
  signal \interim[12]_i_8_n_0\ : STD_LOGIC;
  signal \interim[12]_i_9_n_0\ : STD_LOGIC;
  signal \interim[16]_i_2_n_0\ : STD_LOGIC;
  signal \interim[16]_i_3_n_0\ : STD_LOGIC;
  signal \interim[16]_i_4_n_0\ : STD_LOGIC;
  signal \interim[16]_i_5_n_0\ : STD_LOGIC;
  signal \interim[16]_i_6_n_0\ : STD_LOGIC;
  signal \interim[16]_i_7_n_0\ : STD_LOGIC;
  signal \interim[16]_i_8_n_0\ : STD_LOGIC;
  signal \interim[16]_i_9_n_0\ : STD_LOGIC;
  signal \interim[30]_i_2_n_0\ : STD_LOGIC;
  signal \interim[30]_i_3_n_0\ : STD_LOGIC;
  signal \interim[30]_i_4_n_0\ : STD_LOGIC;
  signal \interim[30]_i_5_n_0\ : STD_LOGIC;
  signal \interim[30]_i_6_n_0\ : STD_LOGIC;
  signal \interim[30]_i_7_n_0\ : STD_LOGIC;
  signal \interim[30]_i_8_n_0\ : STD_LOGIC;
  signal \interim[4]_i_2_n_0\ : STD_LOGIC;
  signal \interim[4]_i_3_n_0\ : STD_LOGIC;
  signal \interim[4]_i_4_n_0\ : STD_LOGIC;
  signal \interim[4]_i_5_n_0\ : STD_LOGIC;
  signal \interim[4]_i_6_n_0\ : STD_LOGIC;
  signal \interim[4]_i_7_n_0\ : STD_LOGIC;
  signal \interim[4]_i_8_n_0\ : STD_LOGIC;
  signal \interim[4]_i_9_n_0\ : STD_LOGIC;
  signal \interim[8]_i_2_n_0\ : STD_LOGIC;
  signal \interim[8]_i_3_n_0\ : STD_LOGIC;
  signal \interim[8]_i_4_n_0\ : STD_LOGIC;
  signal \interim[8]_i_5_n_0\ : STD_LOGIC;
  signal \interim[8]_i_6_n_0\ : STD_LOGIC;
  signal \interim[8]_i_7_n_0\ : STD_LOGIC;
  signal \interim[8]_i_8_n_0\ : STD_LOGIC;
  signal \interim[8]_i_9_n_0\ : STD_LOGIC;
  signal \interim_reg[0]_i_11_n_0\ : STD_LOGIC;
  signal \interim_reg[0]_i_11_n_1\ : STD_LOGIC;
  signal \interim_reg[0]_i_11_n_2\ : STD_LOGIC;
  signal \interim_reg[0]_i_11_n_3\ : STD_LOGIC;
  signal \interim_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[0]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[0]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[0]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[0]_i_1_n_4\ : STD_LOGIC;
  signal \interim_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \interim_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \interim_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \interim_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_4\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_5\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_6\ : STD_LOGIC;
  signal \interim_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_4\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_5\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_6\ : STD_LOGIC;
  signal \interim_reg[16]_i_1_n_7\ : STD_LOGIC;
  signal \interim_reg[30]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[30]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[30]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[30]_i_1_n_5\ : STD_LOGIC;
  signal \interim_reg[30]_i_1_n_6\ : STD_LOGIC;
  signal \interim_reg[30]_i_1_n_7\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \interim_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \interim_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal \^new_velocity_available\ : STD_LOGIC;
  signal nv_flag_i_1_n_0 : STD_LOGIC;
  signal \^output_velocity\ : STD_LOGIC_VECTOR ( 20 downto 0 );
  signal p_0_in0 : STD_LOGIC;
  signal velocity0 : STD_LOGIC;
  signal \velocity1_carry__0_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__0_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__0_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__0_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__0_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_n_1\ : STD_LOGIC;
  signal \velocity1_carry__0_n_2\ : STD_LOGIC;
  signal \velocity1_carry__0_n_3\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__1_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_n_1\ : STD_LOGIC;
  signal \velocity1_carry__1_n_2\ : STD_LOGIC;
  signal \velocity1_carry__1_n_3\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__2_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__2_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__2_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_n_1\ : STD_LOGIC;
  signal \velocity1_carry__2_n_2\ : STD_LOGIC;
  signal \velocity1_carry__2_n_3\ : STD_LOGIC;
  signal velocity1_carry_i_10_n_0 : STD_LOGIC;
  signal velocity1_carry_i_11_n_0 : STD_LOGIC;
  signal velocity1_carry_i_12_n_0 : STD_LOGIC;
  signal velocity1_carry_i_13_n_0 : STD_LOGIC;
  signal velocity1_carry_i_14_n_0 : STD_LOGIC;
  signal velocity1_carry_i_15_n_0 : STD_LOGIC;
  signal velocity1_carry_i_16_n_0 : STD_LOGIC;
  signal velocity1_carry_i_17_n_0 : STD_LOGIC;
  signal velocity1_carry_i_1_n_0 : STD_LOGIC;
  signal velocity1_carry_i_2_n_0 : STD_LOGIC;
  signal velocity1_carry_i_2_n_1 : STD_LOGIC;
  signal velocity1_carry_i_2_n_2 : STD_LOGIC;
  signal velocity1_carry_i_2_n_3 : STD_LOGIC;
  signal velocity1_carry_i_3_n_0 : STD_LOGIC;
  signal velocity1_carry_i_4_n_0 : STD_LOGIC;
  signal velocity1_carry_i_5_n_0 : STD_LOGIC;
  signal velocity1_carry_i_6_n_0 : STD_LOGIC;
  signal velocity1_carry_i_7_n_0 : STD_LOGIC;
  signal velocity1_carry_i_8_n_0 : STD_LOGIC;
  signal velocity1_carry_i_9_n_0 : STD_LOGIC;
  signal velocity1_carry_i_9_n_1 : STD_LOGIC;
  signal velocity1_carry_i_9_n_2 : STD_LOGIC;
  signal velocity1_carry_i_9_n_3 : STD_LOGIC;
  signal velocity1_carry_n_0 : STD_LOGIC;
  signal velocity1_carry_n_1 : STD_LOGIC;
  signal velocity1_carry_n_2 : STD_LOGIC;
  signal velocity1_carry_n_3 : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal velocity2 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_i__carry_i_9__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_interim_reg[0]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_interim_reg[0]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_interim_reg[0]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_interim_reg[30]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_velocity1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__2_i_9_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_velocity1_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \i__carry_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_10__0\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_10__1\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_9\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_9__0\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_9__1\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_9__2\ : label is 35;
  attribute HLUTNM : string;
  attribute HLUTNM of \interim[0]_i_10\ : label is "lutpair8";
  attribute HLUTNM of \interim[0]_i_12\ : label is "lutpair6";
  attribute HLUTNM of \interim[0]_i_13\ : label is "lutpair5";
  attribute HLUTNM of \interim[0]_i_14\ : label is "lutpair4";
  attribute HLUTNM of \interim[0]_i_15\ : label is "lutpair3";
  attribute HLUTNM of \interim[0]_i_16\ : label is "lutpair7";
  attribute HLUTNM of \interim[0]_i_17\ : label is "lutpair6";
  attribute HLUTNM of \interim[0]_i_18\ : label is "lutpair5";
  attribute HLUTNM of \interim[0]_i_19\ : label is "lutpair4";
  attribute HLUTNM of \interim[0]_i_20\ : label is "lutpair2";
  attribute HLUTNM of \interim[0]_i_21\ : label is "lutpair1";
  attribute HLUTNM of \interim[0]_i_22\ : label is "lutpair0";
  attribute HLUTNM of \interim[0]_i_23\ : label is "lutpair3";
  attribute HLUTNM of \interim[0]_i_24\ : label is "lutpair2";
  attribute HLUTNM of \interim[0]_i_25\ : label is "lutpair1";
  attribute HLUTNM of \interim[0]_i_26\ : label is "lutpair0";
  attribute HLUTNM of \interim[0]_i_3\ : label is "lutpair10";
  attribute HLUTNM of \interim[0]_i_4\ : label is "lutpair9";
  attribute HLUTNM of \interim[0]_i_5\ : label is "lutpair8";
  attribute HLUTNM of \interim[0]_i_6\ : label is "lutpair7";
  attribute HLUTNM of \interim[0]_i_7\ : label is "lutpair11";
  attribute HLUTNM of \interim[0]_i_8\ : label is "lutpair10";
  attribute HLUTNM of \interim[0]_i_9\ : label is "lutpair9";
  attribute HLUTNM of \interim[12]_i_2\ : label is "lutpair22";
  attribute HLUTNM of \interim[12]_i_3\ : label is "lutpair21";
  attribute HLUTNM of \interim[12]_i_4\ : label is "lutpair20";
  attribute HLUTNM of \interim[12]_i_5\ : label is "lutpair19";
  attribute HLUTNM of \interim[12]_i_6\ : label is "lutpair23";
  attribute HLUTNM of \interim[12]_i_7\ : label is "lutpair22";
  attribute HLUTNM of \interim[12]_i_8\ : label is "lutpair21";
  attribute HLUTNM of \interim[12]_i_9\ : label is "lutpair20";
  attribute HLUTNM of \interim[16]_i_2\ : label is "lutpair26";
  attribute HLUTNM of \interim[16]_i_3\ : label is "lutpair25";
  attribute HLUTNM of \interim[16]_i_4\ : label is "lutpair24";
  attribute HLUTNM of \interim[16]_i_5\ : label is "lutpair23";
  attribute HLUTNM of \interim[16]_i_6\ : label is "lutpair27";
  attribute HLUTNM of \interim[16]_i_7\ : label is "lutpair26";
  attribute HLUTNM of \interim[16]_i_8\ : label is "lutpair25";
  attribute HLUTNM of \interim[16]_i_9\ : label is "lutpair24";
  attribute HLUTNM of \interim[30]_i_2\ : label is "lutpair29";
  attribute HLUTNM of \interim[30]_i_3\ : label is "lutpair28";
  attribute HLUTNM of \interim[30]_i_4\ : label is "lutpair27";
  attribute HLUTNM of \interim[30]_i_7\ : label is "lutpair29";
  attribute HLUTNM of \interim[30]_i_8\ : label is "lutpair28";
  attribute HLUTNM of \interim[4]_i_2\ : label is "lutpair14";
  attribute HLUTNM of \interim[4]_i_3\ : label is "lutpair13";
  attribute HLUTNM of \interim[4]_i_4\ : label is "lutpair12";
  attribute HLUTNM of \interim[4]_i_5\ : label is "lutpair11";
  attribute HLUTNM of \interim[4]_i_6\ : label is "lutpair15";
  attribute HLUTNM of \interim[4]_i_7\ : label is "lutpair14";
  attribute HLUTNM of \interim[4]_i_8\ : label is "lutpair13";
  attribute HLUTNM of \interim[4]_i_9\ : label is "lutpair12";
  attribute HLUTNM of \interim[8]_i_2\ : label is "lutpair18";
  attribute HLUTNM of \interim[8]_i_3\ : label is "lutpair17";
  attribute HLUTNM of \interim[8]_i_4\ : label is "lutpair16";
  attribute HLUTNM of \interim[8]_i_5\ : label is "lutpair15";
  attribute HLUTNM of \interim[8]_i_6\ : label is "lutpair19";
  attribute HLUTNM of \interim[8]_i_7\ : label is "lutpair18";
  attribute HLUTNM of \interim[8]_i_8\ : label is "lutpair17";
  attribute HLUTNM of \interim[8]_i_9\ : label is "lutpair16";
  attribute ADDER_THRESHOLD of \interim_reg[0]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[0]_i_11\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[0]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[12]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[16]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[30]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[4]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[8]_i_1\ : label is 35;
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of velocity1_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__0\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__0_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__0_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__1\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__1_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__1_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__2\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__2_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__2_i_9\ : label is 35;
  attribute ADDER_THRESHOLD of velocity1_carry_i_2 : label is 35;
  attribute ADDER_THRESHOLD of velocity1_carry_i_9 : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__2\ : label is 11;
begin
  new_velocity_available <= \^new_velocity_available\;
  output_velocity(20 downto 0) <= \^output_velocity\(20 downto 0);
\i__carry_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_2_n_5\,
      I1 => \i__carry_i_2_n_4\,
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_2_n_0\,
      CO(3) => \i__carry_i_10_n_0\,
      CO(2) => \i__carry_i_10_n_1\,
      CO(1) => \i__carry_i_10_n_2\,
      CO(0) => \i__carry_i_10_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(11 downto 8),
      O(3) => \i__carry_i_10_n_4\,
      O(2) => \i__carry_i_10_n_5\,
      O(1) => \i__carry_i_10_n_6\,
      O(0) => \i__carry_i_10_n_7\,
      S(3) => \i__carry_i_15__0_n_0\,
      S(2) => \i__carry_i_16__0_n_0\,
      S(1) => \i__carry_i_17__0_n_0\,
      S(0) => \i__carry_i_18_n_0\
    );
\i__carry_i_10__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_9__0_n_0\,
      CO(3) => \i__carry_i_10__0_n_0\,
      CO(2) => \i__carry_i_10__0_n_1\,
      CO(1) => \i__carry_i_10__0_n_2\,
      CO(0) => \i__carry_i_10__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(19 downto 16),
      O(3) => \i__carry_i_10__0_n_4\,
      O(2) => \i__carry_i_10__0_n_5\,
      O(1) => \i__carry_i_10__0_n_6\,
      O(0) => \i__carry_i_10__0_n_7\,
      S(3) => \i__carry_i_15__1_n_0\,
      S(2) => \i__carry_i_16__1_n_0\,
      S(1) => \i__carry_i_17__1_n_0\,
      S(0) => \i__carry_i_18__0_n_0\
    );
\i__carry_i_10__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_9__1_n_0\,
      CO(3) => \i__carry_i_10__1_n_0\,
      CO(2) => \i__carry_i_10__1_n_1\,
      CO(1) => \i__carry_i_10__1_n_2\,
      CO(0) => \i__carry_i_10__1_n_3\,
      CYINIT => '0',
      DI(3) => \^output_velocity\(20),
      DI(2) => \^output_velocity\(20),
      DI(1) => \^output_velocity\(20),
      DI(0) => \^output_velocity\(20),
      O(3) => \i__carry_i_10__1_n_4\,
      O(2) => \i__carry_i_10__1_n_5\,
      O(1) => \i__carry_i_10__1_n_6\,
      O(0) => \i__carry_i_10__1_n_7\,
      S(3) => \i__carry_i_15__2_n_0\,
      S(2) => \i__carry_i_16__2_n_0\,
      S(1) => \i__carry_i_17__2_n_0\,
      S(0) => \i__carry_i_18__1_n_0\
    );
\i__carry_i_10__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(7),
      I1 => interim(7),
      O => \i__carry_i_10__2_n_0\
    );
\i__carry_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(6),
      I1 => interim(6),
      O => \i__carry_i_11_n_0\
    );
\i__carry_i_11__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(15),
      I1 => interim(15),
      O => \i__carry_i_11__0_n_0\
    );
\i__carry_i_11__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_11__1_n_0\
    );
\i__carry_i_11__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_11__2_n_0\
    );
\i__carry_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(5),
      I1 => interim(5),
      O => \i__carry_i_12_n_0\
    );
\i__carry_i_12__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(14),
      I1 => interim(14),
      O => \i__carry_i_12__0_n_0\
    );
\i__carry_i_12__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_12__1_n_0\
    );
\i__carry_i_12__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_12__2_n_0\
    );
\i__carry_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(4),
      I1 => interim(4),
      O => \i__carry_i_13_n_0\
    );
\i__carry_i_13__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(13),
      I1 => interim(13),
      O => \i__carry_i_13__0_n_0\
    );
\i__carry_i_13__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_13__1_n_0\
    );
\i__carry_i_13__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_13__2_n_0\
    );
\i__carry_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(3),
      I1 => interim(3),
      O => \i__carry_i_14_n_0\
    );
\i__carry_i_14__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(12),
      I1 => interim(12),
      O => \i__carry_i_14__0_n_0\
    );
\i__carry_i_14__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_14__1_n_0\
    );
\i__carry_i_14__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_14__2_n_0\
    );
\i__carry_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(2),
      I1 => interim(2),
      O => \i__carry_i_15_n_0\
    );
\i__carry_i_15__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(11),
      I1 => interim(11),
      O => \i__carry_i_15__0_n_0\
    );
\i__carry_i_15__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(19),
      I1 => interim(19),
      O => \i__carry_i_15__1_n_0\
    );
\i__carry_i_15__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_15__2_n_0\
    );
\i__carry_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(1),
      I1 => interim(1),
      O => \i__carry_i_16_n_0\
    );
\i__carry_i_16__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(10),
      I1 => interim(10),
      O => \i__carry_i_16__0_n_0\
    );
\i__carry_i_16__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(18),
      I1 => interim(18),
      O => \i__carry_i_16__1_n_0\
    );
\i__carry_i_16__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_16__2_n_0\
    );
\i__carry_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(0),
      I1 => interim(0),
      O => \i__carry_i_17_n_0\
    );
\i__carry_i_17__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(9),
      I1 => interim(9),
      O => \i__carry_i_17__0_n_0\
    );
\i__carry_i_17__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(17),
      I1 => interim(17),
      O => \i__carry_i_17__1_n_0\
    );
\i__carry_i_17__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_17__2_n_0\
    );
\i__carry_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(8),
      I1 => interim(8),
      O => \i__carry_i_18_n_0\
    );
\i__carry_i_18__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(16),
      I1 => interim(16),
      O => \i__carry_i_18__0_n_0\
    );
\i__carry_i_18__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => interim(30),
      O => \i__carry_i_18__1_n_0\
    );
\i__carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_9__0_n_5\,
      I1 => \i__carry_i_9__0_n_4\,
      O => \i__carry_i_1__0_n_0\
    );
\i__carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_9__1_n_5\,
      I1 => \i__carry_i_9__1_n_4\,
      O => \i__carry_i_1__1_n_0\
    );
\i__carry_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \i__carry_i_9__2_n_5\,
      I1 => \i__carry_i_9__2_n_4\,
      O => \i__carry_i_1__2_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_9_n_0\,
      CO(3) => \i__carry_i_2_n_0\,
      CO(2) => \i__carry_i_2_n_1\,
      CO(1) => \i__carry_i_2_n_2\,
      CO(0) => \i__carry_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(7 downto 4),
      O(3) => \i__carry_i_2_n_4\,
      O(2) => \i__carry_i_2_n_5\,
      O(1) => \i__carry_i_2_n_6\,
      O(0) => \i__carry_i_2_n_7\,
      S(3) => \i__carry_i_10__2_n_0\,
      S(2) => \i__carry_i_11_n_0\,
      S(1) => \i__carry_i_12_n_0\,
      S(0) => \i__carry_i_13_n_0\
    );
\i__carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_9__0_n_7\,
      I1 => \i__carry_i_9__0_n_6\,
      O => \i__carry_i_2__0_n_0\
    );
\i__carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_9__1_n_7\,
      I1 => \i__carry_i_9__1_n_6\,
      O => \i__carry_i_2__1_n_0\
    );
\i__carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_9__2_n_7\,
      I1 => \i__carry_i_9__2_n_6\,
      O => \i__carry_i_2__2_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_9_n_5\,
      I1 => \i__carry_i_9_n_4\,
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_10_n_5\,
      I1 => \i__carry_i_10_n_4\,
      O => \i__carry_i_3__0_n_0\
    );
\i__carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_10__0_n_5\,
      I1 => \i__carry_i_10__0_n_4\,
      O => \i__carry_i_3__1_n_0\
    );
\i__carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_10__1_n_5\,
      I1 => \i__carry_i_10__1_n_4\,
      O => \i__carry_i_3__2_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_9_n_7\,
      I1 => \i__carry_i_9_n_6\,
      O => \i__carry_i_4_n_0\
    );
\i__carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_10_n_7\,
      I1 => \i__carry_i_10_n_6\,
      O => \i__carry_i_4__0_n_0\
    );
\i__carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_10__0_n_7\,
      I1 => \i__carry_i_10__0_n_6\,
      O => \i__carry_i_4__1_n_0\
    );
\i__carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i__carry_i_10__1_n_7\,
      I1 => \i__carry_i_10__1_n_6\,
      O => \i__carry_i_4__2_n_0\
    );
\i__carry_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9__2_n_5\,
      I1 => \i__carry_i_9__2_n_4\,
      O => \i__carry_i_5_n_0\
    );
\i__carry_i_5__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9__1_n_5\,
      I1 => \i__carry_i_9__1_n_4\,
      O => \i__carry_i_5__0_n_0\
    );
\i__carry_i_5__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9__0_n_5\,
      I1 => \i__carry_i_9__0_n_4\,
      O => \i__carry_i_5__1_n_0\
    );
\i__carry_i_5__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_2_n_5\,
      I1 => \i__carry_i_2_n_4\,
      O => \i__carry_i_5__2_n_0\
    );
\i__carry_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9__2_n_7\,
      I1 => \i__carry_i_9__2_n_6\,
      O => \i__carry_i_6_n_0\
    );
\i__carry_i_6__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9__1_n_7\,
      I1 => \i__carry_i_9__1_n_6\,
      O => \i__carry_i_6__0_n_0\
    );
\i__carry_i_6__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9__0_n_7\,
      I1 => \i__carry_i_9__0_n_6\,
      O => \i__carry_i_6__1_n_0\
    );
\i__carry_i_6__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \i__carry_i_2_n_7\,
      I1 => \i__carry_i_2_n_6\,
      O => \i__carry_i_6__2_n_0\
    );
\i__carry_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_10__1_n_5\,
      I1 => \i__carry_i_10__1_n_4\,
      O => \i__carry_i_7_n_0\
    );
\i__carry_i_7__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_10__0_n_5\,
      I1 => \i__carry_i_10__0_n_4\,
      O => \i__carry_i_7__0_n_0\
    );
\i__carry_i_7__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_10_n_5\,
      I1 => \i__carry_i_10_n_4\,
      O => \i__carry_i_7__1_n_0\
    );
\i__carry_i_7__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9_n_5\,
      I1 => \i__carry_i_9_n_4\,
      O => \i__carry_i_7__2_n_0\
    );
\i__carry_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_10__1_n_7\,
      I1 => \i__carry_i_10__1_n_6\,
      O => \i__carry_i_8_n_0\
    );
\i__carry_i_8__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_10__0_n_7\,
      I1 => \i__carry_i_10__0_n_6\,
      O => \i__carry_i_8__0_n_0\
    );
\i__carry_i_8__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_10_n_7\,
      I1 => \i__carry_i_10_n_6\,
      O => \i__carry_i_8__1_n_0\
    );
\i__carry_i_8__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_9_n_7\,
      I1 => \i__carry_i_9_n_6\,
      O => \i__carry_i_8__2_n_0\
    );
\i__carry_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \i__carry_i_9_n_0\,
      CO(2) => \i__carry_i_9_n_1\,
      CO(1) => \i__carry_i_9_n_2\,
      CO(0) => \i__carry_i_9_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => \^output_velocity\(3 downto 0),
      O(3) => \i__carry_i_9_n_4\,
      O(2) => \i__carry_i_9_n_5\,
      O(1) => \i__carry_i_9_n_6\,
      O(0) => \i__carry_i_9_n_7\,
      S(3) => \i__carry_i_14_n_0\,
      S(2) => \i__carry_i_15_n_0\,
      S(1) => \i__carry_i_16_n_0\,
      S(0) => \i__carry_i_17_n_0\
    );
\i__carry_i_9__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_10_n_0\,
      CO(3) => \i__carry_i_9__0_n_0\,
      CO(2) => \i__carry_i_9__0_n_1\,
      CO(1) => \i__carry_i_9__0_n_2\,
      CO(0) => \i__carry_i_9__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(15 downto 12),
      O(3) => \i__carry_i_9__0_n_4\,
      O(2) => \i__carry_i_9__0_n_5\,
      O(1) => \i__carry_i_9__0_n_6\,
      O(0) => \i__carry_i_9__0_n_7\,
      S(3) => \i__carry_i_11__0_n_0\,
      S(2) => \i__carry_i_12__0_n_0\,
      S(1) => \i__carry_i_13__0_n_0\,
      S(0) => \i__carry_i_14__0_n_0\
    );
\i__carry_i_9__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_10__0_n_0\,
      CO(3) => \i__carry_i_9__1_n_0\,
      CO(2) => \i__carry_i_9__1_n_1\,
      CO(1) => \i__carry_i_9__1_n_2\,
      CO(0) => \i__carry_i_9__1_n_3\,
      CYINIT => '0',
      DI(3) => \^output_velocity\(20),
      DI(2) => \^output_velocity\(20),
      DI(1) => \^output_velocity\(20),
      DI(0) => \^output_velocity\(20),
      O(3) => \i__carry_i_9__1_n_4\,
      O(2) => \i__carry_i_9__1_n_5\,
      O(1) => \i__carry_i_9__1_n_6\,
      O(0) => \i__carry_i_9__1_n_7\,
      S(3) => \i__carry_i_11__2_n_0\,
      S(2) => \i__carry_i_12__1_n_0\,
      S(1) => \i__carry_i_13__1_n_0\,
      S(0) => \i__carry_i_14__1_n_0\
    );
\i__carry_i_9__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_10__1_n_0\,
      CO(3) => \NLW_i__carry_i_9__2_CO_UNCONNECTED\(3),
      CO(2) => \i__carry_i_9__2_n_1\,
      CO(1) => \i__carry_i_9__2_n_2\,
      CO(0) => \i__carry_i_9__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \^output_velocity\(20),
      DI(1) => \^output_velocity\(20),
      DI(0) => \^output_velocity\(20),
      O(3) => \i__carry_i_9__2_n_4\,
      O(2) => \i__carry_i_9__2_n_5\,
      O(1) => \i__carry_i_9__2_n_6\,
      O(0) => \i__carry_i_9__2_n_7\,
      S(3) => \i__carry_i_11__1_n_0\,
      S(2) => \i__carry_i_12__2_n_0\,
      S(1) => \i__carry_i_13__2_n_0\,
      S(0) => \i__carry_i_14__2_n_0\
    );
\interim[0]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(8),
      I1 => d_term(8),
      I2 => p_term(8),
      I3 => \interim[0]_i_6_n_0\,
      O => \interim[0]_i_10_n_0\
    );
\interim[0]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(6),
      I1 => d_term(6),
      I2 => p_term(6),
      O => \interim[0]_i_12_n_0\
    );
\interim[0]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(5),
      I1 => d_term(5),
      I2 => p_term(5),
      O => \interim[0]_i_13_n_0\
    );
\interim[0]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(4),
      I1 => d_term(4),
      I2 => p_term(4),
      O => \interim[0]_i_14_n_0\
    );
\interim[0]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(3),
      I1 => d_term(3),
      I2 => p_term(3),
      O => \interim[0]_i_15_n_0\
    );
\interim[0]_i_16\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(7),
      I1 => d_term(7),
      I2 => p_term(7),
      I3 => \interim[0]_i_12_n_0\,
      O => \interim[0]_i_16_n_0\
    );
\interim[0]_i_17\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(6),
      I1 => d_term(6),
      I2 => p_term(6),
      I3 => \interim[0]_i_13_n_0\,
      O => \interim[0]_i_17_n_0\
    );
\interim[0]_i_18\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(5),
      I1 => d_term(5),
      I2 => p_term(5),
      I3 => \interim[0]_i_14_n_0\,
      O => \interim[0]_i_18_n_0\
    );
\interim[0]_i_19\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(4),
      I1 => d_term(4),
      I2 => p_term(4),
      I3 => \interim[0]_i_15_n_0\,
      O => \interim[0]_i_19_n_0\
    );
\interim[0]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(2),
      I1 => d_term(2),
      I2 => p_term(2),
      O => \interim[0]_i_20_n_0\
    );
\interim[0]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(1),
      I1 => d_term(1),
      I2 => p_term(1),
      O => \interim[0]_i_21_n_0\
    );
\interim[0]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(0),
      I1 => d_term(0),
      I2 => p_term(0),
      O => \interim[0]_i_22_n_0\
    );
\interim[0]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(3),
      I1 => d_term(3),
      I2 => p_term(3),
      I3 => \interim[0]_i_20_n_0\,
      O => \interim[0]_i_23_n_0\
    );
\interim[0]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(2),
      I1 => d_term(2),
      I2 => p_term(2),
      I3 => \interim[0]_i_21_n_0\,
      O => \interim[0]_i_24_n_0\
    );
\interim[0]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(1),
      I1 => d_term(1),
      I2 => p_term(1),
      I3 => \interim[0]_i_22_n_0\,
      O => \interim[0]_i_25_n_0\
    );
\interim[0]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => i_term(0),
      I1 => d_term(0),
      I2 => p_term(0),
      O => \interim[0]_i_26_n_0\
    );
\interim[0]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(10),
      I1 => d_term(10),
      I2 => p_term(10),
      O => \interim[0]_i_3_n_0\
    );
\interim[0]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(9),
      I1 => d_term(9),
      I2 => p_term(9),
      O => \interim[0]_i_4_n_0\
    );
\interim[0]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(8),
      I1 => d_term(8),
      I2 => p_term(8),
      O => \interim[0]_i_5_n_0\
    );
\interim[0]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(7),
      I1 => d_term(7),
      I2 => p_term(7),
      O => \interim[0]_i_6_n_0\
    );
\interim[0]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(11),
      I1 => d_term(11),
      I2 => p_term(11),
      I3 => \interim[0]_i_3_n_0\,
      O => \interim[0]_i_7_n_0\
    );
\interim[0]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(10),
      I1 => d_term(10),
      I2 => p_term(10),
      I3 => \interim[0]_i_4_n_0\,
      O => \interim[0]_i_8_n_0\
    );
\interim[0]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(9),
      I1 => d_term(9),
      I2 => p_term(9),
      I3 => \interim[0]_i_5_n_0\,
      O => \interim[0]_i_9_n_0\
    );
\interim[12]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(22),
      I1 => d_term(22),
      I2 => p_term(22),
      O => \interim[12]_i_2_n_0\
    );
\interim[12]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(21),
      I1 => d_term(21),
      I2 => p_term(21),
      O => \interim[12]_i_3_n_0\
    );
\interim[12]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(20),
      I1 => d_term(20),
      I2 => p_term(20),
      O => \interim[12]_i_4_n_0\
    );
\interim[12]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(19),
      I1 => d_term(19),
      I2 => p_term(19),
      O => \interim[12]_i_5_n_0\
    );
\interim[12]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(23),
      I1 => d_term(23),
      I2 => p_term(23),
      I3 => \interim[12]_i_2_n_0\,
      O => \interim[12]_i_6_n_0\
    );
\interim[12]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(22),
      I1 => d_term(22),
      I2 => p_term(22),
      I3 => \interim[12]_i_3_n_0\,
      O => \interim[12]_i_7_n_0\
    );
\interim[12]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(21),
      I1 => d_term(21),
      I2 => p_term(21),
      I3 => \interim[12]_i_4_n_0\,
      O => \interim[12]_i_8_n_0\
    );
\interim[12]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(20),
      I1 => d_term(20),
      I2 => p_term(20),
      I3 => \interim[12]_i_5_n_0\,
      O => \interim[12]_i_9_n_0\
    );
\interim[16]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(26),
      I1 => d_term(26),
      I2 => p_term(26),
      O => \interim[16]_i_2_n_0\
    );
\interim[16]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(25),
      I1 => d_term(25),
      I2 => p_term(25),
      O => \interim[16]_i_3_n_0\
    );
\interim[16]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(24),
      I1 => d_term(24),
      I2 => p_term(24),
      O => \interim[16]_i_4_n_0\
    );
\interim[16]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(23),
      I1 => d_term(23),
      I2 => p_term(23),
      O => \interim[16]_i_5_n_0\
    );
\interim[16]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(27),
      I1 => d_term(27),
      I2 => p_term(27),
      I3 => \interim[16]_i_2_n_0\,
      O => \interim[16]_i_6_n_0\
    );
\interim[16]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(26),
      I1 => d_term(26),
      I2 => p_term(26),
      I3 => \interim[16]_i_3_n_0\,
      O => \interim[16]_i_7_n_0\
    );
\interim[16]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(25),
      I1 => d_term(25),
      I2 => p_term(25),
      I3 => \interim[16]_i_4_n_0\,
      O => \interim[16]_i_8_n_0\
    );
\interim[16]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(24),
      I1 => d_term(24),
      I2 => p_term(24),
      I3 => \interim[16]_i_5_n_0\,
      O => \interim[16]_i_9_n_0\
    );
\interim[30]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(29),
      I1 => d_term(29),
      I2 => p_term(29),
      O => \interim[30]_i_2_n_0\
    );
\interim[30]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(28),
      I1 => d_term(28),
      I2 => p_term(28),
      O => \interim[30]_i_3_n_0\
    );
\interim[30]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(27),
      I1 => d_term(27),
      I2 => p_term(27),
      O => \interim[30]_i_4_n_0\
    );
\interim[30]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => p_term(30),
      I1 => d_term(30),
      I2 => i_term(30),
      I3 => d_term(31),
      I4 => i_term(31),
      I5 => p_term(31),
      O => \interim[30]_i_5_n_0\
    );
\interim[30]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \interim[30]_i_2_n_0\,
      I1 => d_term(30),
      I2 => i_term(30),
      I3 => p_term(30),
      O => \interim[30]_i_6_n_0\
    );
\interim[30]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(29),
      I1 => d_term(29),
      I2 => p_term(29),
      I3 => \interim[30]_i_3_n_0\,
      O => \interim[30]_i_7_n_0\
    );
\interim[30]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(28),
      I1 => d_term(28),
      I2 => p_term(28),
      I3 => \interim[30]_i_4_n_0\,
      O => \interim[30]_i_8_n_0\
    );
\interim[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(14),
      I1 => d_term(14),
      I2 => p_term(14),
      O => \interim[4]_i_2_n_0\
    );
\interim[4]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(13),
      I1 => d_term(13),
      I2 => p_term(13),
      O => \interim[4]_i_3_n_0\
    );
\interim[4]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(12),
      I1 => d_term(12),
      I2 => p_term(12),
      O => \interim[4]_i_4_n_0\
    );
\interim[4]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(11),
      I1 => d_term(11),
      I2 => p_term(11),
      O => \interim[4]_i_5_n_0\
    );
\interim[4]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(15),
      I1 => d_term(15),
      I2 => p_term(15),
      I3 => \interim[4]_i_2_n_0\,
      O => \interim[4]_i_6_n_0\
    );
\interim[4]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(14),
      I1 => d_term(14),
      I2 => p_term(14),
      I3 => \interim[4]_i_3_n_0\,
      O => \interim[4]_i_7_n_0\
    );
\interim[4]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(13),
      I1 => d_term(13),
      I2 => p_term(13),
      I3 => \interim[4]_i_4_n_0\,
      O => \interim[4]_i_8_n_0\
    );
\interim[4]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(12),
      I1 => d_term(12),
      I2 => p_term(12),
      I3 => \interim[4]_i_5_n_0\,
      O => \interim[4]_i_9_n_0\
    );
\interim[8]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(18),
      I1 => d_term(18),
      I2 => p_term(18),
      O => \interim[8]_i_2_n_0\
    );
\interim[8]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(17),
      I1 => d_term(17),
      I2 => p_term(17),
      O => \interim[8]_i_3_n_0\
    );
\interim[8]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(16),
      I1 => d_term(16),
      I2 => p_term(16),
      O => \interim[8]_i_4_n_0\
    );
\interim[8]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(15),
      I1 => d_term(15),
      I2 => p_term(15),
      O => \interim[8]_i_5_n_0\
    );
\interim[8]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(19),
      I1 => d_term(19),
      I2 => p_term(19),
      I3 => \interim[8]_i_2_n_0\,
      O => \interim[8]_i_6_n_0\
    );
\interim[8]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(18),
      I1 => d_term(18),
      I2 => p_term(18),
      I3 => \interim[8]_i_3_n_0\,
      O => \interim[8]_i_7_n_0\
    );
\interim[8]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(17),
      I1 => d_term(17),
      I2 => p_term(17),
      I3 => \interim[8]_i_4_n_0\,
      O => \interim[8]_i_8_n_0\
    );
\interim[8]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(16),
      I1 => d_term(16),
      I2 => p_term(16),
      I3 => \interim[8]_i_5_n_0\,
      O => \interim[8]_i_9_n_0\
    );
\interim_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[0]_i_1_n_4\,
      Q => interim(0),
      R => '0'
    );
\interim_reg[0]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[0]_i_2_n_0\,
      CO(3) => \interim_reg[0]_i_1_n_0\,
      CO(2) => \interim_reg[0]_i_1_n_1\,
      CO(1) => \interim_reg[0]_i_1_n_2\,
      CO(0) => \interim_reg[0]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[0]_i_3_n_0\,
      DI(2) => \interim[0]_i_4_n_0\,
      DI(1) => \interim[0]_i_5_n_0\,
      DI(0) => \interim[0]_i_6_n_0\,
      O(3) => \interim_reg[0]_i_1_n_4\,
      O(2 downto 0) => \NLW_interim_reg[0]_i_1_O_UNCONNECTED\(2 downto 0),
      S(3) => \interim[0]_i_7_n_0\,
      S(2) => \interim[0]_i_8_n_0\,
      S(1) => \interim[0]_i_9_n_0\,
      S(0) => \interim[0]_i_10_n_0\
    );
\interim_reg[0]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \interim_reg[0]_i_11_n_0\,
      CO(2) => \interim_reg[0]_i_11_n_1\,
      CO(1) => \interim_reg[0]_i_11_n_2\,
      CO(0) => \interim_reg[0]_i_11_n_3\,
      CYINIT => '0',
      DI(3) => \interim[0]_i_20_n_0\,
      DI(2) => \interim[0]_i_21_n_0\,
      DI(1) => \interim[0]_i_22_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_interim_reg[0]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3) => \interim[0]_i_23_n_0\,
      S(2) => \interim[0]_i_24_n_0\,
      S(1) => \interim[0]_i_25_n_0\,
      S(0) => \interim[0]_i_26_n_0\
    );
\interim_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[0]_i_11_n_0\,
      CO(3) => \interim_reg[0]_i_2_n_0\,
      CO(2) => \interim_reg[0]_i_2_n_1\,
      CO(1) => \interim_reg[0]_i_2_n_2\,
      CO(0) => \interim_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \interim[0]_i_12_n_0\,
      DI(2) => \interim[0]_i_13_n_0\,
      DI(1) => \interim[0]_i_14_n_0\,
      DI(0) => \interim[0]_i_15_n_0\,
      O(3 downto 0) => \NLW_interim_reg[0]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \interim[0]_i_16_n_0\,
      S(2) => \interim[0]_i_17_n_0\,
      S(1) => \interim[0]_i_18_n_0\,
      S(0) => \interim[0]_i_19_n_0\
    );
\interim_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[12]_i_1_n_6\,
      Q => interim(10),
      R => '0'
    );
\interim_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[12]_i_1_n_5\,
      Q => interim(11),
      R => '0'
    );
\interim_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[12]_i_1_n_4\,
      Q => interim(12),
      R => '0'
    );
\interim_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[8]_i_1_n_0\,
      CO(3) => \interim_reg[12]_i_1_n_0\,
      CO(2) => \interim_reg[12]_i_1_n_1\,
      CO(1) => \interim_reg[12]_i_1_n_2\,
      CO(0) => \interim_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[12]_i_2_n_0\,
      DI(2) => \interim[12]_i_3_n_0\,
      DI(1) => \interim[12]_i_4_n_0\,
      DI(0) => \interim[12]_i_5_n_0\,
      O(3) => \interim_reg[12]_i_1_n_4\,
      O(2) => \interim_reg[12]_i_1_n_5\,
      O(1) => \interim_reg[12]_i_1_n_6\,
      O(0) => \interim_reg[12]_i_1_n_7\,
      S(3) => \interim[12]_i_6_n_0\,
      S(2) => \interim[12]_i_7_n_0\,
      S(1) => \interim[12]_i_8_n_0\,
      S(0) => \interim[12]_i_9_n_0\
    );
\interim_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[16]_i_1_n_7\,
      Q => interim(13),
      R => '0'
    );
\interim_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[16]_i_1_n_6\,
      Q => interim(14),
      R => '0'
    );
\interim_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[16]_i_1_n_5\,
      Q => interim(15),
      R => '0'
    );
\interim_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[16]_i_1_n_4\,
      Q => interim(16),
      R => '0'
    );
\interim_reg[16]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[12]_i_1_n_0\,
      CO(3) => \interim_reg[16]_i_1_n_0\,
      CO(2) => \interim_reg[16]_i_1_n_1\,
      CO(1) => \interim_reg[16]_i_1_n_2\,
      CO(0) => \interim_reg[16]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[16]_i_2_n_0\,
      DI(2) => \interim[16]_i_3_n_0\,
      DI(1) => \interim[16]_i_4_n_0\,
      DI(0) => \interim[16]_i_5_n_0\,
      O(3) => \interim_reg[16]_i_1_n_4\,
      O(2) => \interim_reg[16]_i_1_n_5\,
      O(1) => \interim_reg[16]_i_1_n_6\,
      O(0) => \interim_reg[16]_i_1_n_7\,
      S(3) => \interim[16]_i_6_n_0\,
      S(2) => \interim[16]_i_7_n_0\,
      S(1) => \interim[16]_i_8_n_0\,
      S(0) => \interim[16]_i_9_n_0\
    );
\interim_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[30]_i_1_n_7\,
      Q => interim(17),
      R => '0'
    );
\interim_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[30]_i_1_n_6\,
      Q => interim(18),
      R => '0'
    );
\interim_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[30]_i_1_n_5\,
      Q => interim(19),
      R => '0'
    );
\interim_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[4]_i_1_n_7\,
      Q => interim(1),
      R => '0'
    );
\interim_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[4]_i_1_n_6\,
      Q => interim(2),
      R => '0'
    );
\interim_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => p_0_in0,
      Q => interim(30),
      R => '0'
    );
\interim_reg[30]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[16]_i_1_n_0\,
      CO(3) => \NLW_interim_reg[30]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \interim_reg[30]_i_1_n_1\,
      CO(1) => \interim_reg[30]_i_1_n_2\,
      CO(0) => \interim_reg[30]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \interim[30]_i_2_n_0\,
      DI(1) => \interim[30]_i_3_n_0\,
      DI(0) => \interim[30]_i_4_n_0\,
      O(3) => p_0_in0,
      O(2) => \interim_reg[30]_i_1_n_5\,
      O(1) => \interim_reg[30]_i_1_n_6\,
      O(0) => \interim_reg[30]_i_1_n_7\,
      S(3) => \interim[30]_i_5_n_0\,
      S(2) => \interim[30]_i_6_n_0\,
      S(1) => \interim[30]_i_7_n_0\,
      S(0) => \interim[30]_i_8_n_0\
    );
\interim_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[4]_i_1_n_5\,
      Q => interim(3),
      R => '0'
    );
\interim_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[4]_i_1_n_4\,
      Q => interim(4),
      R => '0'
    );
\interim_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[0]_i_1_n_0\,
      CO(3) => \interim_reg[4]_i_1_n_0\,
      CO(2) => \interim_reg[4]_i_1_n_1\,
      CO(1) => \interim_reg[4]_i_1_n_2\,
      CO(0) => \interim_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[4]_i_2_n_0\,
      DI(2) => \interim[4]_i_3_n_0\,
      DI(1) => \interim[4]_i_4_n_0\,
      DI(0) => \interim[4]_i_5_n_0\,
      O(3) => \interim_reg[4]_i_1_n_4\,
      O(2) => \interim_reg[4]_i_1_n_5\,
      O(1) => \interim_reg[4]_i_1_n_6\,
      O(0) => \interim_reg[4]_i_1_n_7\,
      S(3) => \interim[4]_i_6_n_0\,
      S(2) => \interim[4]_i_7_n_0\,
      S(1) => \interim[4]_i_8_n_0\,
      S(0) => \interim[4]_i_9_n_0\
    );
\interim_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[8]_i_1_n_7\,
      Q => interim(5),
      R => '0'
    );
\interim_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[8]_i_1_n_6\,
      Q => interim(6),
      R => '0'
    );
\interim_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[8]_i_1_n_5\,
      Q => interim(7),
      R => '0'
    );
\interim_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[8]_i_1_n_4\,
      Q => interim(8),
      R => '0'
    );
\interim_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[4]_i_1_n_0\,
      CO(3) => \interim_reg[8]_i_1_n_0\,
      CO(2) => \interim_reg[8]_i_1_n_1\,
      CO(1) => \interim_reg[8]_i_1_n_2\,
      CO(0) => \interim_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[8]_i_2_n_0\,
      DI(2) => \interim[8]_i_3_n_0\,
      DI(1) => \interim[8]_i_4_n_0\,
      DI(0) => \interim[8]_i_5_n_0\,
      O(3) => \interim_reg[8]_i_1_n_4\,
      O(2) => \interim_reg[8]_i_1_n_5\,
      O(1) => \interim_reg[8]_i_1_n_6\,
      O(0) => \interim_reg[8]_i_1_n_7\,
      S(3) => \interim[8]_i_6_n_0\,
      S(2) => \interim[8]_i_7_n_0\,
      S(1) => \interim[8]_i_8_n_0\,
      S(0) => \interim[8]_i_9_n_0\
    );
\interim_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => \interim_reg[12]_i_1_n_7\,
      Q => interim(9),
      R => '0'
    );
nv_flag_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EEE8"
    )
        port map (
      I0 => \^new_velocity_available\,
      I1 => send_it,
      I2 => \velocity1_inferred__0/i__carry__2_n_0\,
      I3 => \velocity1_carry__2_n_0\,
      O => nv_flag_i_1_n_0
    );
nv_flag_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => '1',
      D => nv_flag_i_1_n_0,
      Q => \^new_velocity_available\,
      R => '0'
    );
velocity1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => velocity1_carry_n_0,
      CO(2) => velocity1_carry_n_1,
      CO(1) => velocity1_carry_n_2,
      CO(0) => velocity1_carry_n_3,
      CYINIT => '0',
      DI(3) => velocity1_carry_i_1_n_0,
      DI(2) => velocity2(5),
      DI(1) => velocity1_carry_i_3_n_0,
      DI(0) => velocity1_carry_i_4_n_0,
      O(3 downto 0) => NLW_velocity1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => velocity1_carry_i_5_n_0,
      S(2) => velocity1_carry_i_6_n_0,
      S(1) => velocity1_carry_i_7_n_0,
      S(0) => velocity1_carry_i_8_n_0
    );
\velocity1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => velocity1_carry_n_0,
      CO(3) => \velocity1_carry__0_n_0\,
      CO(2) => \velocity1_carry__0_n_1\,
      CO(1) => \velocity1_carry__0_n_2\,
      CO(0) => \velocity1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__0_i_1_n_0\,
      DI(2) => \velocity1_carry__0_i_2_n_0\,
      DI(1) => \velocity1_carry__0_i_3_n_0\,
      DI(0) => \velocity1_carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__0_i_5_n_0\,
      S(2) => \velocity1_carry__0_i_6_n_0\,
      S(1) => \velocity1_carry__0_i_7_n_0\,
      S(0) => \velocity1_carry__0_i_8_n_0\
    );
\velocity1_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(14),
      I1 => velocity2(15),
      O => \velocity1_carry__0_i_1_n_0\
    );
\velocity1_carry__0_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => velocity1_carry_i_2_n_0,
      CO(3) => \velocity1_carry__0_i_10_n_0\,
      CO(2) => \velocity1_carry__0_i_10_n_1\,
      CO(1) => \velocity1_carry__0_i_10_n_2\,
      CO(0) => \velocity1_carry__0_i_10_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => interim(11 downto 8),
      O(3 downto 0) => velocity2(11 downto 8),
      S(3) => \velocity1_carry__0_i_15_n_0\,
      S(2) => \velocity1_carry__0_i_16_n_0\,
      S(1) => \velocity1_carry__0_i_17_n_0\,
      S(0) => \velocity1_carry__0_i_18_n_0\
    );
\velocity1_carry__0_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(15),
      I1 => \^output_velocity\(15),
      O => \velocity1_carry__0_i_11_n_0\
    );
\velocity1_carry__0_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(14),
      I1 => \^output_velocity\(14),
      O => \velocity1_carry__0_i_12_n_0\
    );
\velocity1_carry__0_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(13),
      I1 => \^output_velocity\(13),
      O => \velocity1_carry__0_i_13_n_0\
    );
\velocity1_carry__0_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(12),
      I1 => \^output_velocity\(12),
      O => \velocity1_carry__0_i_14_n_0\
    );
\velocity1_carry__0_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(11),
      I1 => \^output_velocity\(11),
      O => \velocity1_carry__0_i_15_n_0\
    );
\velocity1_carry__0_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(10),
      I1 => \^output_velocity\(10),
      O => \velocity1_carry__0_i_16_n_0\
    );
\velocity1_carry__0_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(9),
      I1 => \^output_velocity\(9),
      O => \velocity1_carry__0_i_17_n_0\
    );
\velocity1_carry__0_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(8),
      I1 => \^output_velocity\(8),
      O => \velocity1_carry__0_i_18_n_0\
    );
\velocity1_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(12),
      I1 => velocity2(13),
      O => \velocity1_carry__0_i_2_n_0\
    );
\velocity1_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(10),
      I1 => velocity2(11),
      O => \velocity1_carry__0_i_3_n_0\
    );
\velocity1_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(8),
      I1 => velocity2(9),
      O => \velocity1_carry__0_i_4_n_0\
    );
\velocity1_carry__0_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(14),
      I1 => velocity2(15),
      O => \velocity1_carry__0_i_5_n_0\
    );
\velocity1_carry__0_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(12),
      I1 => velocity2(13),
      O => \velocity1_carry__0_i_6_n_0\
    );
\velocity1_carry__0_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(10),
      I1 => velocity2(11),
      O => \velocity1_carry__0_i_7_n_0\
    );
\velocity1_carry__0_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(8),
      I1 => velocity2(9),
      O => \velocity1_carry__0_i_8_n_0\
    );
\velocity1_carry__0_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__0_i_10_n_0\,
      CO(3) => \velocity1_carry__0_i_9_n_0\,
      CO(2) => \velocity1_carry__0_i_9_n_1\,
      CO(1) => \velocity1_carry__0_i_9_n_2\,
      CO(0) => \velocity1_carry__0_i_9_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => interim(15 downto 12),
      O(3 downto 0) => velocity2(15 downto 12),
      S(3) => \velocity1_carry__0_i_11_n_0\,
      S(2) => \velocity1_carry__0_i_12_n_0\,
      S(1) => \velocity1_carry__0_i_13_n_0\,
      S(0) => \velocity1_carry__0_i_14_n_0\
    );
\velocity1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__0_n_0\,
      CO(3) => \velocity1_carry__1_n_0\,
      CO(2) => \velocity1_carry__1_n_1\,
      CO(1) => \velocity1_carry__1_n_2\,
      CO(0) => \velocity1_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__1_i_1_n_0\,
      DI(2) => \velocity1_carry__1_i_2_n_0\,
      DI(1) => \velocity1_carry__1_i_3_n_0\,
      DI(0) => \velocity1_carry__1_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__1_i_5_n_0\,
      S(2) => \velocity1_carry__1_i_6_n_0\,
      S(1) => \velocity1_carry__1_i_7_n_0\,
      S(0) => \velocity1_carry__1_i_8_n_0\
    );
\velocity1_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(22),
      I1 => velocity2(23),
      O => \velocity1_carry__1_i_1_n_0\
    );
\velocity1_carry__1_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__0_i_9_n_0\,
      CO(3) => \velocity1_carry__1_i_10_n_0\,
      CO(2) => \velocity1_carry__1_i_10_n_1\,
      CO(1) => \velocity1_carry__1_i_10_n_2\,
      CO(0) => \velocity1_carry__1_i_10_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => interim(19 downto 16),
      O(3 downto 0) => velocity2(19 downto 16),
      S(3) => \velocity1_carry__1_i_15_n_0\,
      S(2) => \velocity1_carry__1_i_16_n_0\,
      S(1) => \velocity1_carry__1_i_17_n_0\,
      S(0) => \velocity1_carry__1_i_18_n_0\
    );
\velocity1_carry__1_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__1_i_11_n_0\
    );
\velocity1_carry__1_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__1_i_12_n_0\
    );
\velocity1_carry__1_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__1_i_13_n_0\
    );
\velocity1_carry__1_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__1_i_14_n_0\
    );
\velocity1_carry__1_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(19),
      I1 => \^output_velocity\(19),
      O => \velocity1_carry__1_i_15_n_0\
    );
\velocity1_carry__1_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(18),
      I1 => \^output_velocity\(18),
      O => \velocity1_carry__1_i_16_n_0\
    );
\velocity1_carry__1_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(17),
      I1 => \^output_velocity\(17),
      O => \velocity1_carry__1_i_17_n_0\
    );
\velocity1_carry__1_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(16),
      I1 => \^output_velocity\(16),
      O => \velocity1_carry__1_i_18_n_0\
    );
\velocity1_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(20),
      I1 => velocity2(21),
      O => \velocity1_carry__1_i_2_n_0\
    );
\velocity1_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(18),
      I1 => velocity2(19),
      O => \velocity1_carry__1_i_3_n_0\
    );
\velocity1_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(16),
      I1 => velocity2(17),
      O => \velocity1_carry__1_i_4_n_0\
    );
\velocity1_carry__1_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(22),
      I1 => velocity2(23),
      O => \velocity1_carry__1_i_5_n_0\
    );
\velocity1_carry__1_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(20),
      I1 => velocity2(21),
      O => \velocity1_carry__1_i_6_n_0\
    );
\velocity1_carry__1_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(18),
      I1 => velocity2(19),
      O => \velocity1_carry__1_i_7_n_0\
    );
\velocity1_carry__1_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(16),
      I1 => velocity2(17),
      O => \velocity1_carry__1_i_8_n_0\
    );
\velocity1_carry__1_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__1_i_10_n_0\,
      CO(3) => \velocity1_carry__1_i_9_n_0\,
      CO(2) => \velocity1_carry__1_i_9_n_1\,
      CO(1) => \velocity1_carry__1_i_9_n_2\,
      CO(0) => \velocity1_carry__1_i_9_n_3\,
      CYINIT => '0',
      DI(3) => interim(30),
      DI(2) => interim(30),
      DI(1) => interim(30),
      DI(0) => interim(30),
      O(3 downto 0) => velocity2(23 downto 20),
      S(3) => \velocity1_carry__1_i_11_n_0\,
      S(2) => \velocity1_carry__1_i_12_n_0\,
      S(1) => \velocity1_carry__1_i_13_n_0\,
      S(0) => \velocity1_carry__1_i_14_n_0\
    );
\velocity1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__1_n_0\,
      CO(3) => \velocity1_carry__2_n_0\,
      CO(2) => \velocity1_carry__2_n_1\,
      CO(1) => \velocity1_carry__2_n_2\,
      CO(0) => \velocity1_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__2_i_1_n_0\,
      DI(2) => \velocity1_carry__2_i_2_n_0\,
      DI(1) => \velocity1_carry__2_i_3_n_0\,
      DI(0) => \velocity1_carry__2_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__2_i_5_n_0\,
      S(2) => \velocity1_carry__2_i_6_n_0\,
      S(1) => \velocity1_carry__2_i_7_n_0\,
      S(0) => \velocity1_carry__2_i_8_n_0\
    );
\velocity1_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => velocity2(30),
      I1 => velocity2(31),
      O => \velocity1_carry__2_i_1_n_0\
    );
\velocity1_carry__2_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__1_i_9_n_0\,
      CO(3) => \velocity1_carry__2_i_10_n_0\,
      CO(2) => \velocity1_carry__2_i_10_n_1\,
      CO(1) => \velocity1_carry__2_i_10_n_2\,
      CO(0) => \velocity1_carry__2_i_10_n_3\,
      CYINIT => '0',
      DI(3) => interim(30),
      DI(2) => interim(30),
      DI(1) => interim(30),
      DI(0) => interim(30),
      O(3 downto 0) => velocity2(27 downto 24),
      S(3) => \velocity1_carry__2_i_15_n_0\,
      S(2) => \velocity1_carry__2_i_16_n_0\,
      S(1) => \velocity1_carry__2_i_17_n_0\,
      S(0) => \velocity1_carry__2_i_18_n_0\
    );
\velocity1_carry__2_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_11_n_0\
    );
\velocity1_carry__2_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_12_n_0\
    );
\velocity1_carry__2_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_13_n_0\
    );
\velocity1_carry__2_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_14_n_0\
    );
\velocity1_carry__2_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_15_n_0\
    );
\velocity1_carry__2_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_16_n_0\
    );
\velocity1_carry__2_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_17_n_0\
    );
\velocity1_carry__2_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(30),
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__2_i_18_n_0\
    );
\velocity1_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(28),
      I1 => velocity2(29),
      O => \velocity1_carry__2_i_2_n_0\
    );
\velocity1_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(26),
      I1 => velocity2(27),
      O => \velocity1_carry__2_i_3_n_0\
    );
\velocity1_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(24),
      I1 => velocity2(25),
      O => \velocity1_carry__2_i_4_n_0\
    );
\velocity1_carry__2_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(30),
      I1 => velocity2(31),
      O => \velocity1_carry__2_i_5_n_0\
    );
\velocity1_carry__2_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(28),
      I1 => velocity2(29),
      O => \velocity1_carry__2_i_6_n_0\
    );
\velocity1_carry__2_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(26),
      I1 => velocity2(27),
      O => \velocity1_carry__2_i_7_n_0\
    );
\velocity1_carry__2_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(24),
      I1 => velocity2(25),
      O => \velocity1_carry__2_i_8_n_0\
    );
\velocity1_carry__2_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__2_i_10_n_0\,
      CO(3) => \NLW_velocity1_carry__2_i_9_CO_UNCONNECTED\(3),
      CO(2) => \velocity1_carry__2_i_9_n_1\,
      CO(1) => \velocity1_carry__2_i_9_n_2\,
      CO(0) => \velocity1_carry__2_i_9_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => interim(30),
      DI(1) => interim(30),
      DI(0) => interim(30),
      O(3 downto 0) => velocity2(31 downto 28),
      S(3) => \velocity1_carry__2_i_11_n_0\,
      S(2) => \velocity1_carry__2_i_12_n_0\,
      S(1) => \velocity1_carry__2_i_13_n_0\,
      S(0) => \velocity1_carry__2_i_14_n_0\
    );
velocity1_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(6),
      I1 => velocity2(7),
      O => velocity1_carry_i_1_n_0
    );
velocity1_carry_i_10: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(7),
      I1 => \^output_velocity\(7),
      O => velocity1_carry_i_10_n_0
    );
velocity1_carry_i_11: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(6),
      I1 => \^output_velocity\(6),
      O => velocity1_carry_i_11_n_0
    );
velocity1_carry_i_12: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(5),
      I1 => \^output_velocity\(5),
      O => velocity1_carry_i_12_n_0
    );
velocity1_carry_i_13: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(4),
      I1 => \^output_velocity\(4),
      O => velocity1_carry_i_13_n_0
    );
velocity1_carry_i_14: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(3),
      I1 => \^output_velocity\(3),
      O => velocity1_carry_i_14_n_0
    );
velocity1_carry_i_15: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(2),
      I1 => \^output_velocity\(2),
      O => velocity1_carry_i_15_n_0
    );
velocity1_carry_i_16: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(1),
      I1 => \^output_velocity\(1),
      O => velocity1_carry_i_16_n_0
    );
velocity1_carry_i_17: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => interim(0),
      I1 => \^output_velocity\(0),
      O => velocity1_carry_i_17_n_0
    );
velocity1_carry_i_2: unisim.vcomponents.CARRY4
     port map (
      CI => velocity1_carry_i_9_n_0,
      CO(3) => velocity1_carry_i_2_n_0,
      CO(2) => velocity1_carry_i_2_n_1,
      CO(1) => velocity1_carry_i_2_n_2,
      CO(0) => velocity1_carry_i_2_n_3,
      CYINIT => '0',
      DI(3 downto 0) => interim(7 downto 4),
      O(3 downto 0) => velocity2(7 downto 4),
      S(3) => velocity1_carry_i_10_n_0,
      S(2) => velocity1_carry_i_11_n_0,
      S(1) => velocity1_carry_i_12_n_0,
      S(0) => velocity1_carry_i_13_n_0
    );
velocity1_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(2),
      I1 => velocity2(3),
      O => velocity1_carry_i_3_n_0
    );
velocity1_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(0),
      I1 => velocity2(1),
      O => velocity1_carry_i_4_n_0
    );
velocity1_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(6),
      I1 => velocity2(7),
      O => velocity1_carry_i_5_n_0
    );
velocity1_carry_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => velocity2(4),
      I1 => velocity2(5),
      O => velocity1_carry_i_6_n_0
    );
velocity1_carry_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(2),
      I1 => velocity2(3),
      O => velocity1_carry_i_7_n_0
    );
velocity1_carry_i_8: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(0),
      I1 => velocity2(1),
      O => velocity1_carry_i_8_n_0
    );
velocity1_carry_i_9: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => velocity1_carry_i_9_n_0,
      CO(2) => velocity1_carry_i_9_n_1,
      CO(1) => velocity1_carry_i_9_n_2,
      CO(0) => velocity1_carry_i_9_n_3,
      CYINIT => '1',
      DI(3 downto 0) => interim(3 downto 0),
      O(3 downto 0) => velocity2(3 downto 0),
      S(3) => velocity1_carry_i_14_n_0,
      S(2) => velocity1_carry_i_15_n_0,
      S(1) => velocity1_carry_i_16_n_0,
      S(0) => velocity1_carry_i_17_n_0
    );
\velocity1_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \velocity1_inferred__0/i__carry_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry_i_1_n_0\,
      DI(2) => \i__carry_i_2_n_6\,
      DI(1) => \i__carry_i_3_n_0\,
      DI(0) => \i__carry_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5__2_n_0\,
      S(2) => \i__carry_i_6__2_n_0\,
      S(1) => \i__carry_i_7__2_n_0\,
      S(0) => \i__carry_i_8__2_n_0\
    );
\velocity1_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__0_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__0_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__0_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry_i_1__0_n_0\,
      DI(2) => \i__carry_i_2__0_n_0\,
      DI(1) => \i__carry_i_3__0_n_0\,
      DI(0) => \i__carry_i_4__0_n_0\,
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5__1_n_0\,
      S(2) => \i__carry_i_6__1_n_0\,
      S(1) => \i__carry_i_7__1_n_0\,
      S(0) => \i__carry_i_8__1_n_0\
    );
\velocity1_inferred__0/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__0_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__1_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__1_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__1_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry_i_1__1_n_0\,
      DI(2) => \i__carry_i_2__1_n_0\,
      DI(1) => \i__carry_i_3__1_n_0\,
      DI(0) => \i__carry_i_4__1_n_0\,
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5__0_n_0\,
      S(2) => \i__carry_i_6__0_n_0\,
      S(1) => \i__carry_i_7__0_n_0\,
      S(0) => \i__carry_i_8__0_n_0\
    );
\velocity1_inferred__0/i__carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__1_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__2_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__2_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__2_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry_i_1__2_n_0\,
      DI(2) => \i__carry_i_2__2_n_0\,
      DI(1) => \i__carry_i_3__2_n_0\,
      DI(0) => \i__carry_i_4__2_n_0\,
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5_n_0\,
      S(2) => \i__carry_i_6_n_0\,
      S(1) => \i__carry_i_7_n_0\,
      S(0) => \i__carry_i_8_n_0\
    );
\velocity[31]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \velocity1_inferred__0/i__carry__2_n_0\,
      I1 => \velocity1_carry__2_n_0\,
      O => velocity0
    );
\velocity_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(0),
      Q => \^output_velocity\(0),
      R => '0'
    );
\velocity_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(10),
      Q => \^output_velocity\(10),
      R => '0'
    );
\velocity_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(11),
      Q => \^output_velocity\(11),
      R => '0'
    );
\velocity_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(12),
      Q => \^output_velocity\(12),
      R => '0'
    );
\velocity_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(13),
      Q => \^output_velocity\(13),
      R => '0'
    );
\velocity_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(14),
      Q => \^output_velocity\(14),
      R => '0'
    );
\velocity_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(15),
      Q => \^output_velocity\(15),
      R => '0'
    );
\velocity_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(16),
      Q => \^output_velocity\(16),
      R => '0'
    );
\velocity_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(17),
      Q => \^output_velocity\(17),
      R => '0'
    );
\velocity_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(18),
      Q => \^output_velocity\(18),
      R => '0'
    );
\velocity_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(19),
      Q => \^output_velocity\(19),
      R => '0'
    );
\velocity_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(1),
      Q => \^output_velocity\(1),
      R => '0'
    );
\velocity_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(2),
      Q => \^output_velocity\(2),
      R => '0'
    );
\velocity_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(30),
      Q => \^output_velocity\(20),
      R => '0'
    );
\velocity_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(3),
      Q => \^output_velocity\(3),
      R => '0'
    );
\velocity_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(4),
      Q => \^output_velocity\(4),
      R => '0'
    );
\velocity_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(5),
      Q => \^output_velocity\(5),
      R => '0'
    );
\velocity_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(6),
      Q => \^output_velocity\(6),
      R => '0'
    );
\velocity_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(7),
      Q => \^output_velocity\(7),
      R => '0'
    );
\velocity_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(8),
      Q => \^output_velocity\(8),
      R => '0'
    );
\velocity_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock,
      CE => velocity0,
      D => interim(9),
      Q => \^output_velocity\(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity pid_reexpanded_velocity_calculation_0_0 is
  port (
    clock : in STD_LOGIC;
    send_it : in STD_LOGIC;
    p_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of pid_reexpanded_velocity_calculation_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of pid_reexpanded_velocity_calculation_0_0 : entity is "pid_reexpanded_velocity_calculation_0_0,velocity_calculation,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of pid_reexpanded_velocity_calculation_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of pid_reexpanded_velocity_calculation_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of pid_reexpanded_velocity_calculation_0_0 : entity is "velocity_calculation,Vivado 2021.1";
end pid_reexpanded_velocity_calculation_0_0;

architecture STRUCTURE of pid_reexpanded_velocity_calculation_0_0 is
  signal \^output_velocity\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_reexpanded_clock_0, INSERT_VIP 0";
begin
  output_velocity(31) <= \^output_velocity\(31);
  output_velocity(30) <= \^output_velocity\(31);
  output_velocity(29) <= \^output_velocity\(31);
  output_velocity(28) <= \^output_velocity\(31);
  output_velocity(27) <= \^output_velocity\(31);
  output_velocity(26) <= \^output_velocity\(31);
  output_velocity(25) <= \^output_velocity\(31);
  output_velocity(24) <= \^output_velocity\(31);
  output_velocity(23) <= \^output_velocity\(31);
  output_velocity(22) <= \^output_velocity\(31);
  output_velocity(21) <= \^output_velocity\(31);
  output_velocity(20) <= \^output_velocity\(31);
  output_velocity(19 downto 0) <= \^output_velocity\(19 downto 0);
inst: entity work.pid_reexpanded_velocity_calculation_0_0_velocity_calculation
     port map (
      clock => clock,
      d_term(31 downto 0) => d_term(31 downto 0),
      i_term(31 downto 0) => i_term(31 downto 0),
      new_velocity_available => new_velocity_available,
      output_velocity(20) => \^output_velocity\(31),
      output_velocity(19 downto 0) => \^output_velocity\(19 downto 0),
      p_term(31 downto 0) => p_term(31 downto 0),
      send_it => send_it
    );
end STRUCTURE;
