// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Thu Nov  5 13:25:21 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Xilinx/Projects/pid_controller_v3/pid_controller_v3.gen/sources_1/bd/pid_reexpanded/ip/pid_reexpanded_velocity_calculation_0_0/pid_reexpanded_velocity_calculation_0_0_stub.v
// Design      : pid_reexpanded_velocity_calculation_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "velocity_calculation,Vivado 2021.1" *)
module pid_reexpanded_velocity_calculation_0_0(clock, send_it, p_term, i_term, d_term, 
  output_velocity, new_velocity_available)
/* synthesis syn_black_box black_box_pad_pin="clock,send_it,p_term[31:0],i_term[31:0],d_term[31:0],output_velocity[31:0],new_velocity_available" */;
  input clock;
  input send_it;
  input [31:0]p_term;
  input [31:0]i_term;
  input [31:0]d_term;
  output [31:0]output_velocity;
  output new_velocity_available;
endmodule
