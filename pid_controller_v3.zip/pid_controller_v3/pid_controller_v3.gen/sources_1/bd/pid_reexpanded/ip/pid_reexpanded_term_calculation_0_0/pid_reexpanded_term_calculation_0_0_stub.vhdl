-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Wed Oct 28 21:12:53 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top pid_reexpanded_term_calculation_0_0 -prefix
--               pid_reexpanded_term_calculation_0_0_ pid_reexpanded_term_calculation_0_0_stub.vhdl
-- Design      : pid_reexpanded_term_calculation_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity pid_reexpanded_term_calculation_0_0 is
  Port ( 
    clock : in STD_LOGIC;
    error : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral : in STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    p_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end pid_reexpanded_term_calculation_0_0;

architecture stub of pid_reexpanded_term_calculation_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock,error[31:0],integral[31:0],derivative[31:0],kp[8:0],ki[8:0],kd[8:0],p_term[31:0],i_term[31:0],d_term[31:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "term_calculation,Vivado 2021.1";
begin
end;
