-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Wed Oct 28 21:12:53 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top pid_reexpanded_term_calculation_0_0 -prefix
--               pid_reexpanded_term_calculation_0_0_ pid_reexpanded_term_calculation_0_0_sim_netlist.vhdl
-- Design      : pid_reexpanded_term_calculation_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity pid_reexpanded_term_calculation_0_0_term_calculation is
  port (
    p_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 );
    error : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clock : in STD_LOGIC;
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    integral : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    derivative : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end pid_reexpanded_term_calculation_0_0_term_calculation;

architecture STRUCTURE of pid_reexpanded_term_calculation_0_0_term_calculation is
  signal d_term0_n_100 : STD_LOGIC;
  signal d_term0_n_101 : STD_LOGIC;
  signal d_term0_n_102 : STD_LOGIC;
  signal d_term0_n_103 : STD_LOGIC;
  signal d_term0_n_104 : STD_LOGIC;
  signal d_term0_n_105 : STD_LOGIC;
  signal d_term0_n_106 : STD_LOGIC;
  signal d_term0_n_107 : STD_LOGIC;
  signal d_term0_n_108 : STD_LOGIC;
  signal d_term0_n_109 : STD_LOGIC;
  signal d_term0_n_110 : STD_LOGIC;
  signal d_term0_n_111 : STD_LOGIC;
  signal d_term0_n_112 : STD_LOGIC;
  signal d_term0_n_113 : STD_LOGIC;
  signal d_term0_n_114 : STD_LOGIC;
  signal d_term0_n_115 : STD_LOGIC;
  signal d_term0_n_116 : STD_LOGIC;
  signal d_term0_n_117 : STD_LOGIC;
  signal d_term0_n_118 : STD_LOGIC;
  signal d_term0_n_119 : STD_LOGIC;
  signal d_term0_n_120 : STD_LOGIC;
  signal d_term0_n_121 : STD_LOGIC;
  signal d_term0_n_122 : STD_LOGIC;
  signal d_term0_n_123 : STD_LOGIC;
  signal d_term0_n_124 : STD_LOGIC;
  signal d_term0_n_125 : STD_LOGIC;
  signal d_term0_n_126 : STD_LOGIC;
  signal d_term0_n_127 : STD_LOGIC;
  signal d_term0_n_128 : STD_LOGIC;
  signal d_term0_n_129 : STD_LOGIC;
  signal d_term0_n_130 : STD_LOGIC;
  signal d_term0_n_131 : STD_LOGIC;
  signal d_term0_n_132 : STD_LOGIC;
  signal d_term0_n_133 : STD_LOGIC;
  signal d_term0_n_134 : STD_LOGIC;
  signal d_term0_n_135 : STD_LOGIC;
  signal d_term0_n_136 : STD_LOGIC;
  signal d_term0_n_137 : STD_LOGIC;
  signal d_term0_n_138 : STD_LOGIC;
  signal d_term0_n_139 : STD_LOGIC;
  signal d_term0_n_140 : STD_LOGIC;
  signal d_term0_n_141 : STD_LOGIC;
  signal d_term0_n_142 : STD_LOGIC;
  signal d_term0_n_143 : STD_LOGIC;
  signal d_term0_n_144 : STD_LOGIC;
  signal d_term0_n_145 : STD_LOGIC;
  signal d_term0_n_146 : STD_LOGIC;
  signal d_term0_n_147 : STD_LOGIC;
  signal d_term0_n_148 : STD_LOGIC;
  signal d_term0_n_149 : STD_LOGIC;
  signal d_term0_n_150 : STD_LOGIC;
  signal d_term0_n_151 : STD_LOGIC;
  signal d_term0_n_152 : STD_LOGIC;
  signal d_term0_n_153 : STD_LOGIC;
  signal d_term0_n_58 : STD_LOGIC;
  signal d_term0_n_59 : STD_LOGIC;
  signal d_term0_n_60 : STD_LOGIC;
  signal d_term0_n_61 : STD_LOGIC;
  signal d_term0_n_62 : STD_LOGIC;
  signal d_term0_n_63 : STD_LOGIC;
  signal d_term0_n_64 : STD_LOGIC;
  signal d_term0_n_65 : STD_LOGIC;
  signal d_term0_n_66 : STD_LOGIC;
  signal d_term0_n_67 : STD_LOGIC;
  signal d_term0_n_68 : STD_LOGIC;
  signal d_term0_n_69 : STD_LOGIC;
  signal d_term0_n_70 : STD_LOGIC;
  signal d_term0_n_71 : STD_LOGIC;
  signal d_term0_n_72 : STD_LOGIC;
  signal d_term0_n_73 : STD_LOGIC;
  signal d_term0_n_74 : STD_LOGIC;
  signal d_term0_n_75 : STD_LOGIC;
  signal d_term0_n_76 : STD_LOGIC;
  signal d_term0_n_77 : STD_LOGIC;
  signal d_term0_n_78 : STD_LOGIC;
  signal d_term0_n_79 : STD_LOGIC;
  signal d_term0_n_80 : STD_LOGIC;
  signal d_term0_n_81 : STD_LOGIC;
  signal d_term0_n_82 : STD_LOGIC;
  signal d_term0_n_83 : STD_LOGIC;
  signal d_term0_n_84 : STD_LOGIC;
  signal d_term0_n_85 : STD_LOGIC;
  signal d_term0_n_86 : STD_LOGIC;
  signal d_term0_n_87 : STD_LOGIC;
  signal d_term0_n_88 : STD_LOGIC;
  signal d_term0_n_89 : STD_LOGIC;
  signal d_term0_n_90 : STD_LOGIC;
  signal d_term0_n_91 : STD_LOGIC;
  signal d_term0_n_92 : STD_LOGIC;
  signal d_term0_n_93 : STD_LOGIC;
  signal d_term0_n_94 : STD_LOGIC;
  signal d_term0_n_95 : STD_LOGIC;
  signal d_term0_n_96 : STD_LOGIC;
  signal d_term0_n_97 : STD_LOGIC;
  signal d_term0_n_98 : STD_LOGIC;
  signal d_term0_n_99 : STD_LOGIC;
  signal d_term_interim_reg_n_58 : STD_LOGIC;
  signal d_term_interim_reg_n_59 : STD_LOGIC;
  signal d_term_interim_reg_n_60 : STD_LOGIC;
  signal d_term_interim_reg_n_61 : STD_LOGIC;
  signal d_term_interim_reg_n_62 : STD_LOGIC;
  signal d_term_interim_reg_n_63 : STD_LOGIC;
  signal d_term_interim_reg_n_64 : STD_LOGIC;
  signal d_term_interim_reg_n_65 : STD_LOGIC;
  signal d_term_interim_reg_n_66 : STD_LOGIC;
  signal d_term_interim_reg_n_67 : STD_LOGIC;
  signal d_term_interim_reg_n_68 : STD_LOGIC;
  signal d_term_interim_reg_n_69 : STD_LOGIC;
  signal d_term_interim_reg_n_70 : STD_LOGIC;
  signal d_term_interim_reg_n_71 : STD_LOGIC;
  signal d_term_interim_reg_n_72 : STD_LOGIC;
  signal d_term_interim_reg_n_73 : STD_LOGIC;
  signal d_term_interim_reg_n_74 : STD_LOGIC;
  signal d_term_interim_reg_n_75 : STD_LOGIC;
  signal d_term_interim_reg_n_76 : STD_LOGIC;
  signal d_term_interim_reg_n_77 : STD_LOGIC;
  signal d_term_interim_reg_n_78 : STD_LOGIC;
  signal d_term_interim_reg_n_79 : STD_LOGIC;
  signal d_term_interim_reg_n_80 : STD_LOGIC;
  signal d_term_interim_reg_n_81 : STD_LOGIC;
  signal d_term_interim_reg_n_82 : STD_LOGIC;
  signal d_term_interim_reg_n_83 : STD_LOGIC;
  signal d_term_interim_reg_n_84 : STD_LOGIC;
  signal d_term_interim_reg_n_85 : STD_LOGIC;
  signal d_term_interim_reg_n_86 : STD_LOGIC;
  signal d_term_interim_reg_n_87 : STD_LOGIC;
  signal d_term_interim_reg_n_88 : STD_LOGIC;
  signal d_term_interim_reg_n_89 : STD_LOGIC;
  signal d_term_interim_reg_n_90 : STD_LOGIC;
  signal i_term0_n_100 : STD_LOGIC;
  signal i_term0_n_101 : STD_LOGIC;
  signal i_term0_n_102 : STD_LOGIC;
  signal i_term0_n_103 : STD_LOGIC;
  signal i_term0_n_104 : STD_LOGIC;
  signal i_term0_n_105 : STD_LOGIC;
  signal i_term0_n_106 : STD_LOGIC;
  signal i_term0_n_107 : STD_LOGIC;
  signal i_term0_n_108 : STD_LOGIC;
  signal i_term0_n_109 : STD_LOGIC;
  signal i_term0_n_110 : STD_LOGIC;
  signal i_term0_n_111 : STD_LOGIC;
  signal i_term0_n_112 : STD_LOGIC;
  signal i_term0_n_113 : STD_LOGIC;
  signal i_term0_n_114 : STD_LOGIC;
  signal i_term0_n_115 : STD_LOGIC;
  signal i_term0_n_116 : STD_LOGIC;
  signal i_term0_n_117 : STD_LOGIC;
  signal i_term0_n_118 : STD_LOGIC;
  signal i_term0_n_119 : STD_LOGIC;
  signal i_term0_n_120 : STD_LOGIC;
  signal i_term0_n_121 : STD_LOGIC;
  signal i_term0_n_122 : STD_LOGIC;
  signal i_term0_n_123 : STD_LOGIC;
  signal i_term0_n_124 : STD_LOGIC;
  signal i_term0_n_125 : STD_LOGIC;
  signal i_term0_n_126 : STD_LOGIC;
  signal i_term0_n_127 : STD_LOGIC;
  signal i_term0_n_128 : STD_LOGIC;
  signal i_term0_n_129 : STD_LOGIC;
  signal i_term0_n_130 : STD_LOGIC;
  signal i_term0_n_131 : STD_LOGIC;
  signal i_term0_n_132 : STD_LOGIC;
  signal i_term0_n_133 : STD_LOGIC;
  signal i_term0_n_134 : STD_LOGIC;
  signal i_term0_n_135 : STD_LOGIC;
  signal i_term0_n_136 : STD_LOGIC;
  signal i_term0_n_137 : STD_LOGIC;
  signal i_term0_n_138 : STD_LOGIC;
  signal i_term0_n_139 : STD_LOGIC;
  signal i_term0_n_140 : STD_LOGIC;
  signal i_term0_n_141 : STD_LOGIC;
  signal i_term0_n_142 : STD_LOGIC;
  signal i_term0_n_143 : STD_LOGIC;
  signal i_term0_n_144 : STD_LOGIC;
  signal i_term0_n_145 : STD_LOGIC;
  signal i_term0_n_146 : STD_LOGIC;
  signal i_term0_n_147 : STD_LOGIC;
  signal i_term0_n_148 : STD_LOGIC;
  signal i_term0_n_149 : STD_LOGIC;
  signal i_term0_n_150 : STD_LOGIC;
  signal i_term0_n_151 : STD_LOGIC;
  signal i_term0_n_152 : STD_LOGIC;
  signal i_term0_n_153 : STD_LOGIC;
  signal i_term0_n_58 : STD_LOGIC;
  signal i_term0_n_59 : STD_LOGIC;
  signal i_term0_n_60 : STD_LOGIC;
  signal i_term0_n_61 : STD_LOGIC;
  signal i_term0_n_62 : STD_LOGIC;
  signal i_term0_n_63 : STD_LOGIC;
  signal i_term0_n_64 : STD_LOGIC;
  signal i_term0_n_65 : STD_LOGIC;
  signal i_term0_n_66 : STD_LOGIC;
  signal i_term0_n_67 : STD_LOGIC;
  signal i_term0_n_68 : STD_LOGIC;
  signal i_term0_n_69 : STD_LOGIC;
  signal i_term0_n_70 : STD_LOGIC;
  signal i_term0_n_71 : STD_LOGIC;
  signal i_term0_n_72 : STD_LOGIC;
  signal i_term0_n_73 : STD_LOGIC;
  signal i_term0_n_74 : STD_LOGIC;
  signal i_term0_n_75 : STD_LOGIC;
  signal i_term0_n_76 : STD_LOGIC;
  signal i_term0_n_77 : STD_LOGIC;
  signal i_term0_n_78 : STD_LOGIC;
  signal i_term0_n_79 : STD_LOGIC;
  signal i_term0_n_80 : STD_LOGIC;
  signal i_term0_n_81 : STD_LOGIC;
  signal i_term0_n_82 : STD_LOGIC;
  signal i_term0_n_83 : STD_LOGIC;
  signal i_term0_n_84 : STD_LOGIC;
  signal i_term0_n_85 : STD_LOGIC;
  signal i_term0_n_86 : STD_LOGIC;
  signal i_term0_n_87 : STD_LOGIC;
  signal i_term0_n_88 : STD_LOGIC;
  signal i_term0_n_89 : STD_LOGIC;
  signal i_term0_n_90 : STD_LOGIC;
  signal i_term0_n_91 : STD_LOGIC;
  signal i_term0_n_92 : STD_LOGIC;
  signal i_term0_n_93 : STD_LOGIC;
  signal i_term0_n_94 : STD_LOGIC;
  signal i_term0_n_95 : STD_LOGIC;
  signal i_term0_n_96 : STD_LOGIC;
  signal i_term0_n_97 : STD_LOGIC;
  signal i_term0_n_98 : STD_LOGIC;
  signal i_term0_n_99 : STD_LOGIC;
  signal i_term_interim_reg_n_58 : STD_LOGIC;
  signal i_term_interim_reg_n_59 : STD_LOGIC;
  signal i_term_interim_reg_n_60 : STD_LOGIC;
  signal i_term_interim_reg_n_61 : STD_LOGIC;
  signal i_term_interim_reg_n_62 : STD_LOGIC;
  signal i_term_interim_reg_n_63 : STD_LOGIC;
  signal i_term_interim_reg_n_64 : STD_LOGIC;
  signal i_term_interim_reg_n_65 : STD_LOGIC;
  signal i_term_interim_reg_n_66 : STD_LOGIC;
  signal i_term_interim_reg_n_67 : STD_LOGIC;
  signal i_term_interim_reg_n_68 : STD_LOGIC;
  signal i_term_interim_reg_n_69 : STD_LOGIC;
  signal i_term_interim_reg_n_70 : STD_LOGIC;
  signal i_term_interim_reg_n_71 : STD_LOGIC;
  signal i_term_interim_reg_n_72 : STD_LOGIC;
  signal i_term_interim_reg_n_73 : STD_LOGIC;
  signal i_term_interim_reg_n_74 : STD_LOGIC;
  signal i_term_interim_reg_n_75 : STD_LOGIC;
  signal i_term_interim_reg_n_76 : STD_LOGIC;
  signal i_term_interim_reg_n_77 : STD_LOGIC;
  signal i_term_interim_reg_n_78 : STD_LOGIC;
  signal i_term_interim_reg_n_79 : STD_LOGIC;
  signal i_term_interim_reg_n_80 : STD_LOGIC;
  signal i_term_interim_reg_n_81 : STD_LOGIC;
  signal i_term_interim_reg_n_82 : STD_LOGIC;
  signal i_term_interim_reg_n_83 : STD_LOGIC;
  signal i_term_interim_reg_n_84 : STD_LOGIC;
  signal i_term_interim_reg_n_85 : STD_LOGIC;
  signal i_term_interim_reg_n_86 : STD_LOGIC;
  signal i_term_interim_reg_n_87 : STD_LOGIC;
  signal i_term_interim_reg_n_88 : STD_LOGIC;
  signal i_term_interim_reg_n_89 : STD_LOGIC;
  signal i_term_interim_reg_n_90 : STD_LOGIC;
  signal p_term0_n_100 : STD_LOGIC;
  signal p_term0_n_101 : STD_LOGIC;
  signal p_term0_n_102 : STD_LOGIC;
  signal p_term0_n_103 : STD_LOGIC;
  signal p_term0_n_104 : STD_LOGIC;
  signal p_term0_n_105 : STD_LOGIC;
  signal p_term0_n_106 : STD_LOGIC;
  signal p_term0_n_107 : STD_LOGIC;
  signal p_term0_n_108 : STD_LOGIC;
  signal p_term0_n_109 : STD_LOGIC;
  signal p_term0_n_110 : STD_LOGIC;
  signal p_term0_n_111 : STD_LOGIC;
  signal p_term0_n_112 : STD_LOGIC;
  signal p_term0_n_113 : STD_LOGIC;
  signal p_term0_n_114 : STD_LOGIC;
  signal p_term0_n_115 : STD_LOGIC;
  signal p_term0_n_116 : STD_LOGIC;
  signal p_term0_n_117 : STD_LOGIC;
  signal p_term0_n_118 : STD_LOGIC;
  signal p_term0_n_119 : STD_LOGIC;
  signal p_term0_n_120 : STD_LOGIC;
  signal p_term0_n_121 : STD_LOGIC;
  signal p_term0_n_122 : STD_LOGIC;
  signal p_term0_n_123 : STD_LOGIC;
  signal p_term0_n_124 : STD_LOGIC;
  signal p_term0_n_125 : STD_LOGIC;
  signal p_term0_n_126 : STD_LOGIC;
  signal p_term0_n_127 : STD_LOGIC;
  signal p_term0_n_128 : STD_LOGIC;
  signal p_term0_n_129 : STD_LOGIC;
  signal p_term0_n_130 : STD_LOGIC;
  signal p_term0_n_131 : STD_LOGIC;
  signal p_term0_n_132 : STD_LOGIC;
  signal p_term0_n_133 : STD_LOGIC;
  signal p_term0_n_134 : STD_LOGIC;
  signal p_term0_n_135 : STD_LOGIC;
  signal p_term0_n_136 : STD_LOGIC;
  signal p_term0_n_137 : STD_LOGIC;
  signal p_term0_n_138 : STD_LOGIC;
  signal p_term0_n_139 : STD_LOGIC;
  signal p_term0_n_140 : STD_LOGIC;
  signal p_term0_n_141 : STD_LOGIC;
  signal p_term0_n_142 : STD_LOGIC;
  signal p_term0_n_143 : STD_LOGIC;
  signal p_term0_n_144 : STD_LOGIC;
  signal p_term0_n_145 : STD_LOGIC;
  signal p_term0_n_146 : STD_LOGIC;
  signal p_term0_n_147 : STD_LOGIC;
  signal p_term0_n_148 : STD_LOGIC;
  signal p_term0_n_149 : STD_LOGIC;
  signal p_term0_n_150 : STD_LOGIC;
  signal p_term0_n_151 : STD_LOGIC;
  signal p_term0_n_152 : STD_LOGIC;
  signal p_term0_n_153 : STD_LOGIC;
  signal p_term0_n_58 : STD_LOGIC;
  signal p_term0_n_59 : STD_LOGIC;
  signal p_term0_n_60 : STD_LOGIC;
  signal p_term0_n_61 : STD_LOGIC;
  signal p_term0_n_62 : STD_LOGIC;
  signal p_term0_n_63 : STD_LOGIC;
  signal p_term0_n_64 : STD_LOGIC;
  signal p_term0_n_65 : STD_LOGIC;
  signal p_term0_n_66 : STD_LOGIC;
  signal p_term0_n_67 : STD_LOGIC;
  signal p_term0_n_68 : STD_LOGIC;
  signal p_term0_n_69 : STD_LOGIC;
  signal p_term0_n_70 : STD_LOGIC;
  signal p_term0_n_71 : STD_LOGIC;
  signal p_term0_n_72 : STD_LOGIC;
  signal p_term0_n_73 : STD_LOGIC;
  signal p_term0_n_74 : STD_LOGIC;
  signal p_term0_n_75 : STD_LOGIC;
  signal p_term0_n_76 : STD_LOGIC;
  signal p_term0_n_77 : STD_LOGIC;
  signal p_term0_n_78 : STD_LOGIC;
  signal p_term0_n_79 : STD_LOGIC;
  signal p_term0_n_80 : STD_LOGIC;
  signal p_term0_n_81 : STD_LOGIC;
  signal p_term0_n_82 : STD_LOGIC;
  signal p_term0_n_83 : STD_LOGIC;
  signal p_term0_n_84 : STD_LOGIC;
  signal p_term0_n_85 : STD_LOGIC;
  signal p_term0_n_86 : STD_LOGIC;
  signal p_term0_n_87 : STD_LOGIC;
  signal p_term0_n_88 : STD_LOGIC;
  signal p_term0_n_89 : STD_LOGIC;
  signal p_term0_n_90 : STD_LOGIC;
  signal p_term0_n_91 : STD_LOGIC;
  signal p_term0_n_92 : STD_LOGIC;
  signal p_term0_n_93 : STD_LOGIC;
  signal p_term0_n_94 : STD_LOGIC;
  signal p_term0_n_95 : STD_LOGIC;
  signal p_term0_n_96 : STD_LOGIC;
  signal p_term0_n_97 : STD_LOGIC;
  signal p_term0_n_98 : STD_LOGIC;
  signal p_term0_n_99 : STD_LOGIC;
  signal p_term_interim_reg_n_58 : STD_LOGIC;
  signal p_term_interim_reg_n_59 : STD_LOGIC;
  signal p_term_interim_reg_n_60 : STD_LOGIC;
  signal p_term_interim_reg_n_61 : STD_LOGIC;
  signal p_term_interim_reg_n_62 : STD_LOGIC;
  signal p_term_interim_reg_n_63 : STD_LOGIC;
  signal p_term_interim_reg_n_64 : STD_LOGIC;
  signal p_term_interim_reg_n_65 : STD_LOGIC;
  signal p_term_interim_reg_n_66 : STD_LOGIC;
  signal p_term_interim_reg_n_67 : STD_LOGIC;
  signal p_term_interim_reg_n_68 : STD_LOGIC;
  signal p_term_interim_reg_n_69 : STD_LOGIC;
  signal p_term_interim_reg_n_70 : STD_LOGIC;
  signal p_term_interim_reg_n_71 : STD_LOGIC;
  signal p_term_interim_reg_n_72 : STD_LOGIC;
  signal p_term_interim_reg_n_73 : STD_LOGIC;
  signal p_term_interim_reg_n_74 : STD_LOGIC;
  signal p_term_interim_reg_n_75 : STD_LOGIC;
  signal p_term_interim_reg_n_76 : STD_LOGIC;
  signal p_term_interim_reg_n_77 : STD_LOGIC;
  signal p_term_interim_reg_n_78 : STD_LOGIC;
  signal p_term_interim_reg_n_79 : STD_LOGIC;
  signal p_term_interim_reg_n_80 : STD_LOGIC;
  signal p_term_interim_reg_n_81 : STD_LOGIC;
  signal p_term_interim_reg_n_82 : STD_LOGIC;
  signal p_term_interim_reg_n_83 : STD_LOGIC;
  signal p_term_interim_reg_n_84 : STD_LOGIC;
  signal p_term_interim_reg_n_85 : STD_LOGIC;
  signal p_term_interim_reg_n_86 : STD_LOGIC;
  signal p_term_interim_reg_n_87 : STD_LOGIC;
  signal p_term_interim_reg_n_88 : STD_LOGIC;
  signal p_term_interim_reg_n_89 : STD_LOGIC;
  signal p_term_interim_reg_n_90 : STD_LOGIC;
  signal NLW_d_term0_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_d_term0_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_d_term0_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_d_term_interim_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_interim_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_interim_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_interim_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_interim_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_interim_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_interim_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_d_term_interim_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_d_term_interim_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_d_term_interim_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal NLW_i_term0_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_i_term0_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_i_term0_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_i_term_interim_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_interim_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_interim_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_interim_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_interim_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_interim_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_interim_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_i_term_interim_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_i_term_interim_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_i_term_interim_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal NLW_p_term0_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_p_term0_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_p_term0_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_p_term_interim_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_interim_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_interim_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_interim_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_interim_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_interim_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_interim_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_p_term_interim_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_p_term_interim_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_p_term_interim_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of d_term0 : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of d_term_interim_reg : label is "{SYNTH-12 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of i_term0 : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of i_term_interim_reg : label is "{SYNTH-12 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of p_term0 : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of p_term_interim_reg : label is "{SYNTH-12 {cell *THIS*}}";
begin
d_term0: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => derivative(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_d_term0_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kd(8),
      B(16) => kd(8),
      B(15) => kd(8),
      B(14) => kd(8),
      B(13) => kd(8),
      B(12) => kd(8),
      B(11) => kd(8),
      B(10) => kd(8),
      B(9) => kd(8),
      B(8 downto 0) => kd(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_d_term0_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_d_term0_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_d_term0_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_d_term0_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_d_term0_OVERFLOW_UNCONNECTED,
      P(47) => d_term0_n_58,
      P(46) => d_term0_n_59,
      P(45) => d_term0_n_60,
      P(44) => d_term0_n_61,
      P(43) => d_term0_n_62,
      P(42) => d_term0_n_63,
      P(41) => d_term0_n_64,
      P(40) => d_term0_n_65,
      P(39) => d_term0_n_66,
      P(38) => d_term0_n_67,
      P(37) => d_term0_n_68,
      P(36) => d_term0_n_69,
      P(35) => d_term0_n_70,
      P(34) => d_term0_n_71,
      P(33) => d_term0_n_72,
      P(32) => d_term0_n_73,
      P(31) => d_term0_n_74,
      P(30) => d_term0_n_75,
      P(29) => d_term0_n_76,
      P(28) => d_term0_n_77,
      P(27) => d_term0_n_78,
      P(26) => d_term0_n_79,
      P(25) => d_term0_n_80,
      P(24) => d_term0_n_81,
      P(23) => d_term0_n_82,
      P(22) => d_term0_n_83,
      P(21) => d_term0_n_84,
      P(20) => d_term0_n_85,
      P(19) => d_term0_n_86,
      P(18) => d_term0_n_87,
      P(17) => d_term0_n_88,
      P(16) => d_term0_n_89,
      P(15) => d_term0_n_90,
      P(14) => d_term0_n_91,
      P(13) => d_term0_n_92,
      P(12) => d_term0_n_93,
      P(11) => d_term0_n_94,
      P(10) => d_term0_n_95,
      P(9) => d_term0_n_96,
      P(8) => d_term0_n_97,
      P(7) => d_term0_n_98,
      P(6) => d_term0_n_99,
      P(5) => d_term0_n_100,
      P(4) => d_term0_n_101,
      P(3) => d_term0_n_102,
      P(2) => d_term0_n_103,
      P(1) => d_term0_n_104,
      P(0) => d_term0_n_105,
      PATTERNBDETECT => NLW_d_term0_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_d_term0_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => d_term0_n_106,
      PCOUT(46) => d_term0_n_107,
      PCOUT(45) => d_term0_n_108,
      PCOUT(44) => d_term0_n_109,
      PCOUT(43) => d_term0_n_110,
      PCOUT(42) => d_term0_n_111,
      PCOUT(41) => d_term0_n_112,
      PCOUT(40) => d_term0_n_113,
      PCOUT(39) => d_term0_n_114,
      PCOUT(38) => d_term0_n_115,
      PCOUT(37) => d_term0_n_116,
      PCOUT(36) => d_term0_n_117,
      PCOUT(35) => d_term0_n_118,
      PCOUT(34) => d_term0_n_119,
      PCOUT(33) => d_term0_n_120,
      PCOUT(32) => d_term0_n_121,
      PCOUT(31) => d_term0_n_122,
      PCOUT(30) => d_term0_n_123,
      PCOUT(29) => d_term0_n_124,
      PCOUT(28) => d_term0_n_125,
      PCOUT(27) => d_term0_n_126,
      PCOUT(26) => d_term0_n_127,
      PCOUT(25) => d_term0_n_128,
      PCOUT(24) => d_term0_n_129,
      PCOUT(23) => d_term0_n_130,
      PCOUT(22) => d_term0_n_131,
      PCOUT(21) => d_term0_n_132,
      PCOUT(20) => d_term0_n_133,
      PCOUT(19) => d_term0_n_134,
      PCOUT(18) => d_term0_n_135,
      PCOUT(17) => d_term0_n_136,
      PCOUT(16) => d_term0_n_137,
      PCOUT(15) => d_term0_n_138,
      PCOUT(14) => d_term0_n_139,
      PCOUT(13) => d_term0_n_140,
      PCOUT(12) => d_term0_n_141,
      PCOUT(11) => d_term0_n_142,
      PCOUT(10) => d_term0_n_143,
      PCOUT(9) => d_term0_n_144,
      PCOUT(8) => d_term0_n_145,
      PCOUT(7) => d_term0_n_146,
      PCOUT(6) => d_term0_n_147,
      PCOUT(5) => d_term0_n_148,
      PCOUT(4) => d_term0_n_149,
      PCOUT(3) => d_term0_n_150,
      PCOUT(2) => d_term0_n_151,
      PCOUT(1) => d_term0_n_152,
      PCOUT(0) => d_term0_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_d_term0_UNDERFLOW_UNCONNECTED
    );
d_term_interim_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => derivative(31),
      A(28) => derivative(31),
      A(27) => derivative(31),
      A(26) => derivative(31),
      A(25) => derivative(31),
      A(24) => derivative(31),
      A(23) => derivative(31),
      A(22) => derivative(31),
      A(21) => derivative(31),
      A(20) => derivative(31),
      A(19) => derivative(31),
      A(18) => derivative(31),
      A(17) => derivative(31),
      A(16) => derivative(31),
      A(15) => derivative(31),
      A(14 downto 0) => derivative(31 downto 17),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_d_term_interim_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kd(8),
      B(16) => kd(8),
      B(15) => kd(8),
      B(14) => kd(8),
      B(13) => kd(8),
      B(12) => kd(8),
      B(11) => kd(8),
      B(10) => kd(8),
      B(9) => kd(8),
      B(8 downto 0) => kd(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_d_term_interim_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_d_term_interim_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_d_term_interim_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '1',
      CLK => clock,
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_d_term_interim_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => NLW_d_term_interim_reg_OVERFLOW_UNCONNECTED,
      P(47) => d_term_interim_reg_n_58,
      P(46) => d_term_interim_reg_n_59,
      P(45) => d_term_interim_reg_n_60,
      P(44) => d_term_interim_reg_n_61,
      P(43) => d_term_interim_reg_n_62,
      P(42) => d_term_interim_reg_n_63,
      P(41) => d_term_interim_reg_n_64,
      P(40) => d_term_interim_reg_n_65,
      P(39) => d_term_interim_reg_n_66,
      P(38) => d_term_interim_reg_n_67,
      P(37) => d_term_interim_reg_n_68,
      P(36) => d_term_interim_reg_n_69,
      P(35) => d_term_interim_reg_n_70,
      P(34) => d_term_interim_reg_n_71,
      P(33) => d_term_interim_reg_n_72,
      P(32) => d_term_interim_reg_n_73,
      P(31) => d_term_interim_reg_n_74,
      P(30) => d_term_interim_reg_n_75,
      P(29) => d_term_interim_reg_n_76,
      P(28) => d_term_interim_reg_n_77,
      P(27) => d_term_interim_reg_n_78,
      P(26) => d_term_interim_reg_n_79,
      P(25) => d_term_interim_reg_n_80,
      P(24) => d_term_interim_reg_n_81,
      P(23) => d_term_interim_reg_n_82,
      P(22) => d_term_interim_reg_n_83,
      P(21) => d_term_interim_reg_n_84,
      P(20) => d_term_interim_reg_n_85,
      P(19) => d_term_interim_reg_n_86,
      P(18) => d_term_interim_reg_n_87,
      P(17) => d_term_interim_reg_n_88,
      P(16) => d_term_interim_reg_n_89,
      P(15) => d_term_interim_reg_n_90,
      P(14 downto 0) => d_term(31 downto 17),
      PATTERNBDETECT => NLW_d_term_interim_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_d_term_interim_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47) => d_term0_n_106,
      PCIN(46) => d_term0_n_107,
      PCIN(45) => d_term0_n_108,
      PCIN(44) => d_term0_n_109,
      PCIN(43) => d_term0_n_110,
      PCIN(42) => d_term0_n_111,
      PCIN(41) => d_term0_n_112,
      PCIN(40) => d_term0_n_113,
      PCIN(39) => d_term0_n_114,
      PCIN(38) => d_term0_n_115,
      PCIN(37) => d_term0_n_116,
      PCIN(36) => d_term0_n_117,
      PCIN(35) => d_term0_n_118,
      PCIN(34) => d_term0_n_119,
      PCIN(33) => d_term0_n_120,
      PCIN(32) => d_term0_n_121,
      PCIN(31) => d_term0_n_122,
      PCIN(30) => d_term0_n_123,
      PCIN(29) => d_term0_n_124,
      PCIN(28) => d_term0_n_125,
      PCIN(27) => d_term0_n_126,
      PCIN(26) => d_term0_n_127,
      PCIN(25) => d_term0_n_128,
      PCIN(24) => d_term0_n_129,
      PCIN(23) => d_term0_n_130,
      PCIN(22) => d_term0_n_131,
      PCIN(21) => d_term0_n_132,
      PCIN(20) => d_term0_n_133,
      PCIN(19) => d_term0_n_134,
      PCIN(18) => d_term0_n_135,
      PCIN(17) => d_term0_n_136,
      PCIN(16) => d_term0_n_137,
      PCIN(15) => d_term0_n_138,
      PCIN(14) => d_term0_n_139,
      PCIN(13) => d_term0_n_140,
      PCIN(12) => d_term0_n_141,
      PCIN(11) => d_term0_n_142,
      PCIN(10) => d_term0_n_143,
      PCIN(9) => d_term0_n_144,
      PCIN(8) => d_term0_n_145,
      PCIN(7) => d_term0_n_146,
      PCIN(6) => d_term0_n_147,
      PCIN(5) => d_term0_n_148,
      PCIN(4) => d_term0_n_149,
      PCIN(3) => d_term0_n_150,
      PCIN(2) => d_term0_n_151,
      PCIN(1) => d_term0_n_152,
      PCIN(0) => d_term0_n_153,
      PCOUT(47 downto 0) => NLW_d_term_interim_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_d_term_interim_reg_UNDERFLOW_UNCONNECTED
    );
\d_term_interim_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_105,
      Q => d_term(0),
      R => '0'
    );
\d_term_interim_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_95,
      Q => d_term(10),
      R => '0'
    );
\d_term_interim_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_94,
      Q => d_term(11),
      R => '0'
    );
\d_term_interim_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_93,
      Q => d_term(12),
      R => '0'
    );
\d_term_interim_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_92,
      Q => d_term(13),
      R => '0'
    );
\d_term_interim_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_91,
      Q => d_term(14),
      R => '0'
    );
\d_term_interim_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_90,
      Q => d_term(15),
      R => '0'
    );
\d_term_interim_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_89,
      Q => d_term(16),
      R => '0'
    );
\d_term_interim_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_104,
      Q => d_term(1),
      R => '0'
    );
\d_term_interim_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_103,
      Q => d_term(2),
      R => '0'
    );
\d_term_interim_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_102,
      Q => d_term(3),
      R => '0'
    );
\d_term_interim_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_101,
      Q => d_term(4),
      R => '0'
    );
\d_term_interim_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_100,
      Q => d_term(5),
      R => '0'
    );
\d_term_interim_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_99,
      Q => d_term(6),
      R => '0'
    );
\d_term_interim_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_98,
      Q => d_term(7),
      R => '0'
    );
\d_term_interim_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_97,
      Q => d_term(8),
      R => '0'
    );
\d_term_interim_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => d_term0_n_96,
      Q => d_term(9),
      R => '0'
    );
i_term0: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => integral(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_i_term0_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => ki(8),
      B(16) => ki(8),
      B(15) => ki(8),
      B(14) => ki(8),
      B(13) => ki(8),
      B(12) => ki(8),
      B(11) => ki(8),
      B(10) => ki(8),
      B(9) => ki(8),
      B(8 downto 0) => ki(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_i_term0_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_i_term0_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_i_term0_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_i_term0_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_i_term0_OVERFLOW_UNCONNECTED,
      P(47) => i_term0_n_58,
      P(46) => i_term0_n_59,
      P(45) => i_term0_n_60,
      P(44) => i_term0_n_61,
      P(43) => i_term0_n_62,
      P(42) => i_term0_n_63,
      P(41) => i_term0_n_64,
      P(40) => i_term0_n_65,
      P(39) => i_term0_n_66,
      P(38) => i_term0_n_67,
      P(37) => i_term0_n_68,
      P(36) => i_term0_n_69,
      P(35) => i_term0_n_70,
      P(34) => i_term0_n_71,
      P(33) => i_term0_n_72,
      P(32) => i_term0_n_73,
      P(31) => i_term0_n_74,
      P(30) => i_term0_n_75,
      P(29) => i_term0_n_76,
      P(28) => i_term0_n_77,
      P(27) => i_term0_n_78,
      P(26) => i_term0_n_79,
      P(25) => i_term0_n_80,
      P(24) => i_term0_n_81,
      P(23) => i_term0_n_82,
      P(22) => i_term0_n_83,
      P(21) => i_term0_n_84,
      P(20) => i_term0_n_85,
      P(19) => i_term0_n_86,
      P(18) => i_term0_n_87,
      P(17) => i_term0_n_88,
      P(16) => i_term0_n_89,
      P(15) => i_term0_n_90,
      P(14) => i_term0_n_91,
      P(13) => i_term0_n_92,
      P(12) => i_term0_n_93,
      P(11) => i_term0_n_94,
      P(10) => i_term0_n_95,
      P(9) => i_term0_n_96,
      P(8) => i_term0_n_97,
      P(7) => i_term0_n_98,
      P(6) => i_term0_n_99,
      P(5) => i_term0_n_100,
      P(4) => i_term0_n_101,
      P(3) => i_term0_n_102,
      P(2) => i_term0_n_103,
      P(1) => i_term0_n_104,
      P(0) => i_term0_n_105,
      PATTERNBDETECT => NLW_i_term0_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_i_term0_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => i_term0_n_106,
      PCOUT(46) => i_term0_n_107,
      PCOUT(45) => i_term0_n_108,
      PCOUT(44) => i_term0_n_109,
      PCOUT(43) => i_term0_n_110,
      PCOUT(42) => i_term0_n_111,
      PCOUT(41) => i_term0_n_112,
      PCOUT(40) => i_term0_n_113,
      PCOUT(39) => i_term0_n_114,
      PCOUT(38) => i_term0_n_115,
      PCOUT(37) => i_term0_n_116,
      PCOUT(36) => i_term0_n_117,
      PCOUT(35) => i_term0_n_118,
      PCOUT(34) => i_term0_n_119,
      PCOUT(33) => i_term0_n_120,
      PCOUT(32) => i_term0_n_121,
      PCOUT(31) => i_term0_n_122,
      PCOUT(30) => i_term0_n_123,
      PCOUT(29) => i_term0_n_124,
      PCOUT(28) => i_term0_n_125,
      PCOUT(27) => i_term0_n_126,
      PCOUT(26) => i_term0_n_127,
      PCOUT(25) => i_term0_n_128,
      PCOUT(24) => i_term0_n_129,
      PCOUT(23) => i_term0_n_130,
      PCOUT(22) => i_term0_n_131,
      PCOUT(21) => i_term0_n_132,
      PCOUT(20) => i_term0_n_133,
      PCOUT(19) => i_term0_n_134,
      PCOUT(18) => i_term0_n_135,
      PCOUT(17) => i_term0_n_136,
      PCOUT(16) => i_term0_n_137,
      PCOUT(15) => i_term0_n_138,
      PCOUT(14) => i_term0_n_139,
      PCOUT(13) => i_term0_n_140,
      PCOUT(12) => i_term0_n_141,
      PCOUT(11) => i_term0_n_142,
      PCOUT(10) => i_term0_n_143,
      PCOUT(9) => i_term0_n_144,
      PCOUT(8) => i_term0_n_145,
      PCOUT(7) => i_term0_n_146,
      PCOUT(6) => i_term0_n_147,
      PCOUT(5) => i_term0_n_148,
      PCOUT(4) => i_term0_n_149,
      PCOUT(3) => i_term0_n_150,
      PCOUT(2) => i_term0_n_151,
      PCOUT(1) => i_term0_n_152,
      PCOUT(0) => i_term0_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_i_term0_UNDERFLOW_UNCONNECTED
    );
i_term_interim_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => integral(31),
      A(28) => integral(31),
      A(27) => integral(31),
      A(26) => integral(31),
      A(25) => integral(31),
      A(24) => integral(31),
      A(23) => integral(31),
      A(22) => integral(31),
      A(21) => integral(31),
      A(20) => integral(31),
      A(19) => integral(31),
      A(18) => integral(31),
      A(17) => integral(31),
      A(16) => integral(31),
      A(15) => integral(31),
      A(14 downto 0) => integral(31 downto 17),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_i_term_interim_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => ki(8),
      B(16) => ki(8),
      B(15) => ki(8),
      B(14) => ki(8),
      B(13) => ki(8),
      B(12) => ki(8),
      B(11) => ki(8),
      B(10) => ki(8),
      B(9) => ki(8),
      B(8 downto 0) => ki(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_i_term_interim_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_i_term_interim_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_i_term_interim_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '1',
      CLK => clock,
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_i_term_interim_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => NLW_i_term_interim_reg_OVERFLOW_UNCONNECTED,
      P(47) => i_term_interim_reg_n_58,
      P(46) => i_term_interim_reg_n_59,
      P(45) => i_term_interim_reg_n_60,
      P(44) => i_term_interim_reg_n_61,
      P(43) => i_term_interim_reg_n_62,
      P(42) => i_term_interim_reg_n_63,
      P(41) => i_term_interim_reg_n_64,
      P(40) => i_term_interim_reg_n_65,
      P(39) => i_term_interim_reg_n_66,
      P(38) => i_term_interim_reg_n_67,
      P(37) => i_term_interim_reg_n_68,
      P(36) => i_term_interim_reg_n_69,
      P(35) => i_term_interim_reg_n_70,
      P(34) => i_term_interim_reg_n_71,
      P(33) => i_term_interim_reg_n_72,
      P(32) => i_term_interim_reg_n_73,
      P(31) => i_term_interim_reg_n_74,
      P(30) => i_term_interim_reg_n_75,
      P(29) => i_term_interim_reg_n_76,
      P(28) => i_term_interim_reg_n_77,
      P(27) => i_term_interim_reg_n_78,
      P(26) => i_term_interim_reg_n_79,
      P(25) => i_term_interim_reg_n_80,
      P(24) => i_term_interim_reg_n_81,
      P(23) => i_term_interim_reg_n_82,
      P(22) => i_term_interim_reg_n_83,
      P(21) => i_term_interim_reg_n_84,
      P(20) => i_term_interim_reg_n_85,
      P(19) => i_term_interim_reg_n_86,
      P(18) => i_term_interim_reg_n_87,
      P(17) => i_term_interim_reg_n_88,
      P(16) => i_term_interim_reg_n_89,
      P(15) => i_term_interim_reg_n_90,
      P(14 downto 0) => i_term(31 downto 17),
      PATTERNBDETECT => NLW_i_term_interim_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_i_term_interim_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47) => i_term0_n_106,
      PCIN(46) => i_term0_n_107,
      PCIN(45) => i_term0_n_108,
      PCIN(44) => i_term0_n_109,
      PCIN(43) => i_term0_n_110,
      PCIN(42) => i_term0_n_111,
      PCIN(41) => i_term0_n_112,
      PCIN(40) => i_term0_n_113,
      PCIN(39) => i_term0_n_114,
      PCIN(38) => i_term0_n_115,
      PCIN(37) => i_term0_n_116,
      PCIN(36) => i_term0_n_117,
      PCIN(35) => i_term0_n_118,
      PCIN(34) => i_term0_n_119,
      PCIN(33) => i_term0_n_120,
      PCIN(32) => i_term0_n_121,
      PCIN(31) => i_term0_n_122,
      PCIN(30) => i_term0_n_123,
      PCIN(29) => i_term0_n_124,
      PCIN(28) => i_term0_n_125,
      PCIN(27) => i_term0_n_126,
      PCIN(26) => i_term0_n_127,
      PCIN(25) => i_term0_n_128,
      PCIN(24) => i_term0_n_129,
      PCIN(23) => i_term0_n_130,
      PCIN(22) => i_term0_n_131,
      PCIN(21) => i_term0_n_132,
      PCIN(20) => i_term0_n_133,
      PCIN(19) => i_term0_n_134,
      PCIN(18) => i_term0_n_135,
      PCIN(17) => i_term0_n_136,
      PCIN(16) => i_term0_n_137,
      PCIN(15) => i_term0_n_138,
      PCIN(14) => i_term0_n_139,
      PCIN(13) => i_term0_n_140,
      PCIN(12) => i_term0_n_141,
      PCIN(11) => i_term0_n_142,
      PCIN(10) => i_term0_n_143,
      PCIN(9) => i_term0_n_144,
      PCIN(8) => i_term0_n_145,
      PCIN(7) => i_term0_n_146,
      PCIN(6) => i_term0_n_147,
      PCIN(5) => i_term0_n_148,
      PCIN(4) => i_term0_n_149,
      PCIN(3) => i_term0_n_150,
      PCIN(2) => i_term0_n_151,
      PCIN(1) => i_term0_n_152,
      PCIN(0) => i_term0_n_153,
      PCOUT(47 downto 0) => NLW_i_term_interim_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_i_term_interim_reg_UNDERFLOW_UNCONNECTED
    );
\i_term_interim_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_105,
      Q => i_term(0),
      R => '0'
    );
\i_term_interim_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_95,
      Q => i_term(10),
      R => '0'
    );
\i_term_interim_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_94,
      Q => i_term(11),
      R => '0'
    );
\i_term_interim_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_93,
      Q => i_term(12),
      R => '0'
    );
\i_term_interim_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_92,
      Q => i_term(13),
      R => '0'
    );
\i_term_interim_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_91,
      Q => i_term(14),
      R => '0'
    );
\i_term_interim_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_90,
      Q => i_term(15),
      R => '0'
    );
\i_term_interim_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_89,
      Q => i_term(16),
      R => '0'
    );
\i_term_interim_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_104,
      Q => i_term(1),
      R => '0'
    );
\i_term_interim_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_103,
      Q => i_term(2),
      R => '0'
    );
\i_term_interim_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_102,
      Q => i_term(3),
      R => '0'
    );
\i_term_interim_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_101,
      Q => i_term(4),
      R => '0'
    );
\i_term_interim_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_100,
      Q => i_term(5),
      R => '0'
    );
\i_term_interim_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_99,
      Q => i_term(6),
      R => '0'
    );
\i_term_interim_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_98,
      Q => i_term(7),
      R => '0'
    );
\i_term_interim_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_97,
      Q => i_term(8),
      R => '0'
    );
\i_term_interim_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => i_term0_n_96,
      Q => i_term(9),
      R => '0'
    );
p_term0: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => error(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_p_term0_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kp(8),
      B(16) => kp(8),
      B(15) => kp(8),
      B(14) => kp(8),
      B(13) => kp(8),
      B(12) => kp(8),
      B(11) => kp(8),
      B(10) => kp(8),
      B(9) => kp(8),
      B(8 downto 0) => kp(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_p_term0_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_p_term0_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_p_term0_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_p_term0_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_p_term0_OVERFLOW_UNCONNECTED,
      P(47) => p_term0_n_58,
      P(46) => p_term0_n_59,
      P(45) => p_term0_n_60,
      P(44) => p_term0_n_61,
      P(43) => p_term0_n_62,
      P(42) => p_term0_n_63,
      P(41) => p_term0_n_64,
      P(40) => p_term0_n_65,
      P(39) => p_term0_n_66,
      P(38) => p_term0_n_67,
      P(37) => p_term0_n_68,
      P(36) => p_term0_n_69,
      P(35) => p_term0_n_70,
      P(34) => p_term0_n_71,
      P(33) => p_term0_n_72,
      P(32) => p_term0_n_73,
      P(31) => p_term0_n_74,
      P(30) => p_term0_n_75,
      P(29) => p_term0_n_76,
      P(28) => p_term0_n_77,
      P(27) => p_term0_n_78,
      P(26) => p_term0_n_79,
      P(25) => p_term0_n_80,
      P(24) => p_term0_n_81,
      P(23) => p_term0_n_82,
      P(22) => p_term0_n_83,
      P(21) => p_term0_n_84,
      P(20) => p_term0_n_85,
      P(19) => p_term0_n_86,
      P(18) => p_term0_n_87,
      P(17) => p_term0_n_88,
      P(16) => p_term0_n_89,
      P(15) => p_term0_n_90,
      P(14) => p_term0_n_91,
      P(13) => p_term0_n_92,
      P(12) => p_term0_n_93,
      P(11) => p_term0_n_94,
      P(10) => p_term0_n_95,
      P(9) => p_term0_n_96,
      P(8) => p_term0_n_97,
      P(7) => p_term0_n_98,
      P(6) => p_term0_n_99,
      P(5) => p_term0_n_100,
      P(4) => p_term0_n_101,
      P(3) => p_term0_n_102,
      P(2) => p_term0_n_103,
      P(1) => p_term0_n_104,
      P(0) => p_term0_n_105,
      PATTERNBDETECT => NLW_p_term0_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_p_term0_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => p_term0_n_106,
      PCOUT(46) => p_term0_n_107,
      PCOUT(45) => p_term0_n_108,
      PCOUT(44) => p_term0_n_109,
      PCOUT(43) => p_term0_n_110,
      PCOUT(42) => p_term0_n_111,
      PCOUT(41) => p_term0_n_112,
      PCOUT(40) => p_term0_n_113,
      PCOUT(39) => p_term0_n_114,
      PCOUT(38) => p_term0_n_115,
      PCOUT(37) => p_term0_n_116,
      PCOUT(36) => p_term0_n_117,
      PCOUT(35) => p_term0_n_118,
      PCOUT(34) => p_term0_n_119,
      PCOUT(33) => p_term0_n_120,
      PCOUT(32) => p_term0_n_121,
      PCOUT(31) => p_term0_n_122,
      PCOUT(30) => p_term0_n_123,
      PCOUT(29) => p_term0_n_124,
      PCOUT(28) => p_term0_n_125,
      PCOUT(27) => p_term0_n_126,
      PCOUT(26) => p_term0_n_127,
      PCOUT(25) => p_term0_n_128,
      PCOUT(24) => p_term0_n_129,
      PCOUT(23) => p_term0_n_130,
      PCOUT(22) => p_term0_n_131,
      PCOUT(21) => p_term0_n_132,
      PCOUT(20) => p_term0_n_133,
      PCOUT(19) => p_term0_n_134,
      PCOUT(18) => p_term0_n_135,
      PCOUT(17) => p_term0_n_136,
      PCOUT(16) => p_term0_n_137,
      PCOUT(15) => p_term0_n_138,
      PCOUT(14) => p_term0_n_139,
      PCOUT(13) => p_term0_n_140,
      PCOUT(12) => p_term0_n_141,
      PCOUT(11) => p_term0_n_142,
      PCOUT(10) => p_term0_n_143,
      PCOUT(9) => p_term0_n_144,
      PCOUT(8) => p_term0_n_145,
      PCOUT(7) => p_term0_n_146,
      PCOUT(6) => p_term0_n_147,
      PCOUT(5) => p_term0_n_148,
      PCOUT(4) => p_term0_n_149,
      PCOUT(3) => p_term0_n_150,
      PCOUT(2) => p_term0_n_151,
      PCOUT(1) => p_term0_n_152,
      PCOUT(0) => p_term0_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_p_term0_UNDERFLOW_UNCONNECTED
    );
p_term_interim_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => error(31),
      A(28) => error(31),
      A(27) => error(31),
      A(26) => error(31),
      A(25) => error(31),
      A(24) => error(31),
      A(23) => error(31),
      A(22) => error(31),
      A(21) => error(31),
      A(20) => error(31),
      A(19) => error(31),
      A(18) => error(31),
      A(17) => error(31),
      A(16) => error(31),
      A(15) => error(31),
      A(14 downto 0) => error(31 downto 17),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_p_term_interim_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kp(8),
      B(16) => kp(8),
      B(15) => kp(8),
      B(14) => kp(8),
      B(13) => kp(8),
      B(12) => kp(8),
      B(11) => kp(8),
      B(10) => kp(8),
      B(9) => kp(8),
      B(8 downto 0) => kp(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_p_term_interim_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_p_term_interim_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_p_term_interim_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '1',
      CLK => clock,
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_p_term_interim_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => NLW_p_term_interim_reg_OVERFLOW_UNCONNECTED,
      P(47) => p_term_interim_reg_n_58,
      P(46) => p_term_interim_reg_n_59,
      P(45) => p_term_interim_reg_n_60,
      P(44) => p_term_interim_reg_n_61,
      P(43) => p_term_interim_reg_n_62,
      P(42) => p_term_interim_reg_n_63,
      P(41) => p_term_interim_reg_n_64,
      P(40) => p_term_interim_reg_n_65,
      P(39) => p_term_interim_reg_n_66,
      P(38) => p_term_interim_reg_n_67,
      P(37) => p_term_interim_reg_n_68,
      P(36) => p_term_interim_reg_n_69,
      P(35) => p_term_interim_reg_n_70,
      P(34) => p_term_interim_reg_n_71,
      P(33) => p_term_interim_reg_n_72,
      P(32) => p_term_interim_reg_n_73,
      P(31) => p_term_interim_reg_n_74,
      P(30) => p_term_interim_reg_n_75,
      P(29) => p_term_interim_reg_n_76,
      P(28) => p_term_interim_reg_n_77,
      P(27) => p_term_interim_reg_n_78,
      P(26) => p_term_interim_reg_n_79,
      P(25) => p_term_interim_reg_n_80,
      P(24) => p_term_interim_reg_n_81,
      P(23) => p_term_interim_reg_n_82,
      P(22) => p_term_interim_reg_n_83,
      P(21) => p_term_interim_reg_n_84,
      P(20) => p_term_interim_reg_n_85,
      P(19) => p_term_interim_reg_n_86,
      P(18) => p_term_interim_reg_n_87,
      P(17) => p_term_interim_reg_n_88,
      P(16) => p_term_interim_reg_n_89,
      P(15) => p_term_interim_reg_n_90,
      P(14 downto 0) => p_term(31 downto 17),
      PATTERNBDETECT => NLW_p_term_interim_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_p_term_interim_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47) => p_term0_n_106,
      PCIN(46) => p_term0_n_107,
      PCIN(45) => p_term0_n_108,
      PCIN(44) => p_term0_n_109,
      PCIN(43) => p_term0_n_110,
      PCIN(42) => p_term0_n_111,
      PCIN(41) => p_term0_n_112,
      PCIN(40) => p_term0_n_113,
      PCIN(39) => p_term0_n_114,
      PCIN(38) => p_term0_n_115,
      PCIN(37) => p_term0_n_116,
      PCIN(36) => p_term0_n_117,
      PCIN(35) => p_term0_n_118,
      PCIN(34) => p_term0_n_119,
      PCIN(33) => p_term0_n_120,
      PCIN(32) => p_term0_n_121,
      PCIN(31) => p_term0_n_122,
      PCIN(30) => p_term0_n_123,
      PCIN(29) => p_term0_n_124,
      PCIN(28) => p_term0_n_125,
      PCIN(27) => p_term0_n_126,
      PCIN(26) => p_term0_n_127,
      PCIN(25) => p_term0_n_128,
      PCIN(24) => p_term0_n_129,
      PCIN(23) => p_term0_n_130,
      PCIN(22) => p_term0_n_131,
      PCIN(21) => p_term0_n_132,
      PCIN(20) => p_term0_n_133,
      PCIN(19) => p_term0_n_134,
      PCIN(18) => p_term0_n_135,
      PCIN(17) => p_term0_n_136,
      PCIN(16) => p_term0_n_137,
      PCIN(15) => p_term0_n_138,
      PCIN(14) => p_term0_n_139,
      PCIN(13) => p_term0_n_140,
      PCIN(12) => p_term0_n_141,
      PCIN(11) => p_term0_n_142,
      PCIN(10) => p_term0_n_143,
      PCIN(9) => p_term0_n_144,
      PCIN(8) => p_term0_n_145,
      PCIN(7) => p_term0_n_146,
      PCIN(6) => p_term0_n_147,
      PCIN(5) => p_term0_n_148,
      PCIN(4) => p_term0_n_149,
      PCIN(3) => p_term0_n_150,
      PCIN(2) => p_term0_n_151,
      PCIN(1) => p_term0_n_152,
      PCIN(0) => p_term0_n_153,
      PCOUT(47 downto 0) => NLW_p_term_interim_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_p_term_interim_reg_UNDERFLOW_UNCONNECTED
    );
\p_term_interim_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_105,
      Q => p_term(0),
      R => '0'
    );
\p_term_interim_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_95,
      Q => p_term(10),
      R => '0'
    );
\p_term_interim_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_94,
      Q => p_term(11),
      R => '0'
    );
\p_term_interim_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_93,
      Q => p_term(12),
      R => '0'
    );
\p_term_interim_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_92,
      Q => p_term(13),
      R => '0'
    );
\p_term_interim_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_91,
      Q => p_term(14),
      R => '0'
    );
\p_term_interim_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_90,
      Q => p_term(15),
      R => '0'
    );
\p_term_interim_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_89,
      Q => p_term(16),
      R => '0'
    );
\p_term_interim_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_104,
      Q => p_term(1),
      R => '0'
    );
\p_term_interim_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_103,
      Q => p_term(2),
      R => '0'
    );
\p_term_interim_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_102,
      Q => p_term(3),
      R => '0'
    );
\p_term_interim_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_101,
      Q => p_term(4),
      R => '0'
    );
\p_term_interim_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_100,
      Q => p_term(5),
      R => '0'
    );
\p_term_interim_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_99,
      Q => p_term(6),
      R => '0'
    );
\p_term_interim_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_98,
      Q => p_term(7),
      R => '0'
    );
\p_term_interim_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_97,
      Q => p_term(8),
      R => '0'
    );
\p_term_interim_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock,
      CE => '1',
      D => p_term0_n_96,
      Q => p_term(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity pid_reexpanded_term_calculation_0_0 is
  port (
    clock : in STD_LOGIC;
    error : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral : in STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    p_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of pid_reexpanded_term_calculation_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of pid_reexpanded_term_calculation_0_0 : entity is "pid_reexpanded_term_calculation_0_0,term_calculation,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of pid_reexpanded_term_calculation_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of pid_reexpanded_term_calculation_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of pid_reexpanded_term_calculation_0_0 : entity is "term_calculation,Vivado 2021.1";
end pid_reexpanded_term_calculation_0_0;

architecture STRUCTURE of pid_reexpanded_term_calculation_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_reexpanded_clock_0, INSERT_VIP 0";
begin
inst: entity work.pid_reexpanded_term_calculation_0_0_term_calculation
     port map (
      clock => clock,
      d_term(31 downto 0) => d_term(31 downto 0),
      derivative(31 downto 0) => derivative(31 downto 0),
      error(31 downto 0) => error(31 downto 0),
      i_term(31 downto 0) => i_term(31 downto 0),
      integral(31 downto 0) => integral(31 downto 0),
      kd(8 downto 0) => kd(8 downto 0),
      ki(8 downto 0) => ki(8 downto 0),
      kp(8 downto 0) => kp(8 downto 0),
      p_term(31 downto 0) => p_term(31 downto 0)
    );
end STRUCTURE;
