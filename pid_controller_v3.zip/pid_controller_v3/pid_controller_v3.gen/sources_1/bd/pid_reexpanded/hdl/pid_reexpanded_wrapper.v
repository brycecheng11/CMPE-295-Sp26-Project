//Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
//Date        : Thu Nov  5 12:44:59 2026
//Host        : Dell-XPS running 64-bit major release  (build 9200)
//Command     : generate_target pid_reexpanded_wrapper.bd
//Design      : pid_reexpanded_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module pid_reexpanded_wrapper
   (angle_0,
    angle_out_0,
    kd_in_0,
    ki_in_0,
    kp_in_0,
    new_target_angle_available_0,
    new_velocity_available_0,
    output_velocity_0,
    ps_ready_0,
    sys_clk,
    target_angle_0);
  input [31:0]angle_0;
  output [31:0]angle_out_0;
  input [11:0]kd_in_0;
  input [11:0]ki_in_0;
  input [11:0]kp_in_0;
  input [0:0]new_target_angle_available_0;
  output [0:0]new_velocity_available_0;
  output [31:0]output_velocity_0;
  input ps_ready_0;
  input [0:0]sys_clk;
  input [31:0]target_angle_0;

  wire [31:0]angle_0;
  wire [31:0]angle_out_0;
  wire [11:0]kd_in_0;
  wire [11:0]ki_in_0;
  wire [11:0]kp_in_0;
  wire [0:0]new_target_angle_available_0;
  wire [0:0]new_velocity_available_0;
  wire [31:0]output_velocity_0;
  wire ps_ready_0;
  wire [0:0]sys_clk;
  wire [31:0]target_angle_0;

  pid_reexpanded pid_reexpanded_i
       (.angle_0(angle_0),
        .angle_out_0(angle_out_0),
        .kd_in_0(kd_in_0),
        .ki_in_0(ki_in_0),
        .kp_in_0(kp_in_0),
        .new_target_angle_available_0(new_target_angle_available_0),
        .new_velocity_available_0(new_velocity_available_0),
        .output_velocity_0(output_velocity_0),
        .ps_ready_0(ps_ready_0),
        .sys_clk(sys_clk),
        .target_angle_0(target_angle_0));
endmodule
