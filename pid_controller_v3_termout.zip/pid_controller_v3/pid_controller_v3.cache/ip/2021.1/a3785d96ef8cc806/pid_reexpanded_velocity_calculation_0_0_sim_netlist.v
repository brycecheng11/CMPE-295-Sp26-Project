// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Thu Nov  5 13:25:21 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_reexpanded_velocity_calculation_0_0_sim_netlist.v
// Design      : pid_reexpanded_velocity_calculation_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "pid_reexpanded_velocity_calculation_0_0,velocity_calculation,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "velocity_calculation,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clock,
    send_it,
    p_term,
    i_term,
    d_term,
    output_velocity,
    new_velocity_available);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_reexpanded_clock_0, INSERT_VIP 0" *) input clock;
  input send_it;
  input [31:0]p_term;
  input [31:0]i_term;
  input [31:0]d_term;
  output [31:0]output_velocity;
  output new_velocity_available;

  wire clock;
  wire [31:0]d_term;
  wire [31:0]i_term;
  wire new_velocity_available;
  wire [31:0]\^output_velocity ;
  wire [31:0]p_term;
  wire send_it;

  assign output_velocity[31] = \^output_velocity [31];
  assign output_velocity[30] = \^output_velocity [31];
  assign output_velocity[29] = \^output_velocity [31];
  assign output_velocity[28] = \^output_velocity [31];
  assign output_velocity[27] = \^output_velocity [31];
  assign output_velocity[26] = \^output_velocity [31];
  assign output_velocity[25] = \^output_velocity [31];
  assign output_velocity[24] = \^output_velocity [31];
  assign output_velocity[23] = \^output_velocity [31];
  assign output_velocity[22] = \^output_velocity [31];
  assign output_velocity[21] = \^output_velocity [31];
  assign output_velocity[20] = \^output_velocity [31];
  assign output_velocity[19:0] = \^output_velocity [19:0];
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_velocity_calculation inst
       (.clock(clock),
        .d_term(d_term),
        .i_term(i_term),
        .new_velocity_available(new_velocity_available),
        .output_velocity({\^output_velocity [31],\^output_velocity [19:0]}),
        .p_term(p_term),
        .send_it(send_it));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_velocity_calculation
   (output_velocity,
    new_velocity_available,
    d_term,
    i_term,
    p_term,
    clock,
    send_it);
  output [20:0]output_velocity;
  output new_velocity_available;
  input [31:0]d_term;
  input [31:0]i_term;
  input [31:0]p_term;
  input clock;
  input send_it;

  wire clock;
  wire [31:0]d_term;
  wire i__carry_i_10__0_n_0;
  wire i__carry_i_10__0_n_1;
  wire i__carry_i_10__0_n_2;
  wire i__carry_i_10__0_n_3;
  wire i__carry_i_10__0_n_4;
  wire i__carry_i_10__0_n_5;
  wire i__carry_i_10__0_n_6;
  wire i__carry_i_10__0_n_7;
  wire i__carry_i_10__1_n_0;
  wire i__carry_i_10__1_n_1;
  wire i__carry_i_10__1_n_2;
  wire i__carry_i_10__1_n_3;
  wire i__carry_i_10__1_n_4;
  wire i__carry_i_10__1_n_5;
  wire i__carry_i_10__1_n_6;
  wire i__carry_i_10__1_n_7;
  wire i__carry_i_10__2_n_0;
  wire i__carry_i_10_n_0;
  wire i__carry_i_10_n_1;
  wire i__carry_i_10_n_2;
  wire i__carry_i_10_n_3;
  wire i__carry_i_10_n_4;
  wire i__carry_i_10_n_5;
  wire i__carry_i_10_n_6;
  wire i__carry_i_10_n_7;
  wire i__carry_i_11__0_n_0;
  wire i__carry_i_11__1_n_0;
  wire i__carry_i_11__2_n_0;
  wire i__carry_i_11_n_0;
  wire i__carry_i_12__0_n_0;
  wire i__carry_i_12__1_n_0;
  wire i__carry_i_12__2_n_0;
  wire i__carry_i_12_n_0;
  wire i__carry_i_13__0_n_0;
  wire i__carry_i_13__1_n_0;
  wire i__carry_i_13__2_n_0;
  wire i__carry_i_13_n_0;
  wire i__carry_i_14__0_n_0;
  wire i__carry_i_14__1_n_0;
  wire i__carry_i_14__2_n_0;
  wire i__carry_i_14_n_0;
  wire i__carry_i_15__0_n_0;
  wire i__carry_i_15__1_n_0;
  wire i__carry_i_15__2_n_0;
  wire i__carry_i_15_n_0;
  wire i__carry_i_16__0_n_0;
  wire i__carry_i_16__1_n_0;
  wire i__carry_i_16__2_n_0;
  wire i__carry_i_16_n_0;
  wire i__carry_i_17__0_n_0;
  wire i__carry_i_17__1_n_0;
  wire i__carry_i_17__2_n_0;
  wire i__carry_i_17_n_0;
  wire i__carry_i_18__0_n_0;
  wire i__carry_i_18__1_n_0;
  wire i__carry_i_18_n_0;
  wire i__carry_i_1__0_n_0;
  wire i__carry_i_1__1_n_0;
  wire i__carry_i_1__2_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2__0_n_0;
  wire i__carry_i_2__1_n_0;
  wire i__carry_i_2__2_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_2_n_1;
  wire i__carry_i_2_n_2;
  wire i__carry_i_2_n_3;
  wire i__carry_i_2_n_4;
  wire i__carry_i_2_n_5;
  wire i__carry_i_2_n_6;
  wire i__carry_i_2_n_7;
  wire i__carry_i_3__0_n_0;
  wire i__carry_i_3__1_n_0;
  wire i__carry_i_3__2_n_0;
  wire i__carry_i_3_n_0;
  wire i__carry_i_4__0_n_0;
  wire i__carry_i_4__1_n_0;
  wire i__carry_i_4__2_n_0;
  wire i__carry_i_4_n_0;
  wire i__carry_i_5__0_n_0;
  wire i__carry_i_5__1_n_0;
  wire i__carry_i_5__2_n_0;
  wire i__carry_i_5_n_0;
  wire i__carry_i_6__0_n_0;
  wire i__carry_i_6__1_n_0;
  wire i__carry_i_6__2_n_0;
  wire i__carry_i_6_n_0;
  wire i__carry_i_7__0_n_0;
  wire i__carry_i_7__1_n_0;
  wire i__carry_i_7__2_n_0;
  wire i__carry_i_7_n_0;
  wire i__carry_i_8__0_n_0;
  wire i__carry_i_8__1_n_0;
  wire i__carry_i_8__2_n_0;
  wire i__carry_i_8_n_0;
  wire i__carry_i_9__0_n_0;
  wire i__carry_i_9__0_n_1;
  wire i__carry_i_9__0_n_2;
  wire i__carry_i_9__0_n_3;
  wire i__carry_i_9__0_n_4;
  wire i__carry_i_9__0_n_5;
  wire i__carry_i_9__0_n_6;
  wire i__carry_i_9__0_n_7;
  wire i__carry_i_9__1_n_0;
  wire i__carry_i_9__1_n_1;
  wire i__carry_i_9__1_n_2;
  wire i__carry_i_9__1_n_3;
  wire i__carry_i_9__1_n_4;
  wire i__carry_i_9__1_n_5;
  wire i__carry_i_9__1_n_6;
  wire i__carry_i_9__1_n_7;
  wire i__carry_i_9__2_n_1;
  wire i__carry_i_9__2_n_2;
  wire i__carry_i_9__2_n_3;
  wire i__carry_i_9__2_n_4;
  wire i__carry_i_9__2_n_5;
  wire i__carry_i_9__2_n_6;
  wire i__carry_i_9__2_n_7;
  wire i__carry_i_9_n_0;
  wire i__carry_i_9_n_1;
  wire i__carry_i_9_n_2;
  wire i__carry_i_9_n_3;
  wire i__carry_i_9_n_4;
  wire i__carry_i_9_n_5;
  wire i__carry_i_9_n_6;
  wire i__carry_i_9_n_7;
  wire [31:0]i_term;
  wire [30:0]interim;
  wire \interim[0]_i_10_n_0 ;
  wire \interim[0]_i_12_n_0 ;
  wire \interim[0]_i_13_n_0 ;
  wire \interim[0]_i_14_n_0 ;
  wire \interim[0]_i_15_n_0 ;
  wire \interim[0]_i_16_n_0 ;
  wire \interim[0]_i_17_n_0 ;
  wire \interim[0]_i_18_n_0 ;
  wire \interim[0]_i_19_n_0 ;
  wire \interim[0]_i_20_n_0 ;
  wire \interim[0]_i_21_n_0 ;
  wire \interim[0]_i_22_n_0 ;
  wire \interim[0]_i_23_n_0 ;
  wire \interim[0]_i_24_n_0 ;
  wire \interim[0]_i_25_n_0 ;
  wire \interim[0]_i_26_n_0 ;
  wire \interim[0]_i_3_n_0 ;
  wire \interim[0]_i_4_n_0 ;
  wire \interim[0]_i_5_n_0 ;
  wire \interim[0]_i_6_n_0 ;
  wire \interim[0]_i_7_n_0 ;
  wire \interim[0]_i_8_n_0 ;
  wire \interim[0]_i_9_n_0 ;
  wire \interim[12]_i_2_n_0 ;
  wire \interim[12]_i_3_n_0 ;
  wire \interim[12]_i_4_n_0 ;
  wire \interim[12]_i_5_n_0 ;
  wire \interim[12]_i_6_n_0 ;
  wire \interim[12]_i_7_n_0 ;
  wire \interim[12]_i_8_n_0 ;
  wire \interim[12]_i_9_n_0 ;
  wire \interim[16]_i_2_n_0 ;
  wire \interim[16]_i_3_n_0 ;
  wire \interim[16]_i_4_n_0 ;
  wire \interim[16]_i_5_n_0 ;
  wire \interim[16]_i_6_n_0 ;
  wire \interim[16]_i_7_n_0 ;
  wire \interim[16]_i_8_n_0 ;
  wire \interim[16]_i_9_n_0 ;
  wire \interim[30]_i_2_n_0 ;
  wire \interim[30]_i_3_n_0 ;
  wire \interim[30]_i_4_n_0 ;
  wire \interim[30]_i_5_n_0 ;
  wire \interim[30]_i_6_n_0 ;
  wire \interim[30]_i_7_n_0 ;
  wire \interim[30]_i_8_n_0 ;
  wire \interim[4]_i_2_n_0 ;
  wire \interim[4]_i_3_n_0 ;
  wire \interim[4]_i_4_n_0 ;
  wire \interim[4]_i_5_n_0 ;
  wire \interim[4]_i_6_n_0 ;
  wire \interim[4]_i_7_n_0 ;
  wire \interim[4]_i_8_n_0 ;
  wire \interim[4]_i_9_n_0 ;
  wire \interim[8]_i_2_n_0 ;
  wire \interim[8]_i_3_n_0 ;
  wire \interim[8]_i_4_n_0 ;
  wire \interim[8]_i_5_n_0 ;
  wire \interim[8]_i_6_n_0 ;
  wire \interim[8]_i_7_n_0 ;
  wire \interim[8]_i_8_n_0 ;
  wire \interim[8]_i_9_n_0 ;
  wire \interim_reg[0]_i_11_n_0 ;
  wire \interim_reg[0]_i_11_n_1 ;
  wire \interim_reg[0]_i_11_n_2 ;
  wire \interim_reg[0]_i_11_n_3 ;
  wire \interim_reg[0]_i_1_n_0 ;
  wire \interim_reg[0]_i_1_n_1 ;
  wire \interim_reg[0]_i_1_n_2 ;
  wire \interim_reg[0]_i_1_n_3 ;
  wire \interim_reg[0]_i_1_n_4 ;
  wire \interim_reg[0]_i_2_n_0 ;
  wire \interim_reg[0]_i_2_n_1 ;
  wire \interim_reg[0]_i_2_n_2 ;
  wire \interim_reg[0]_i_2_n_3 ;
  wire \interim_reg[12]_i_1_n_0 ;
  wire \interim_reg[12]_i_1_n_1 ;
  wire \interim_reg[12]_i_1_n_2 ;
  wire \interim_reg[12]_i_1_n_3 ;
  wire \interim_reg[12]_i_1_n_4 ;
  wire \interim_reg[12]_i_1_n_5 ;
  wire \interim_reg[12]_i_1_n_6 ;
  wire \interim_reg[12]_i_1_n_7 ;
  wire \interim_reg[16]_i_1_n_0 ;
  wire \interim_reg[16]_i_1_n_1 ;
  wire \interim_reg[16]_i_1_n_2 ;
  wire \interim_reg[16]_i_1_n_3 ;
  wire \interim_reg[16]_i_1_n_4 ;
  wire \interim_reg[16]_i_1_n_5 ;
  wire \interim_reg[16]_i_1_n_6 ;
  wire \interim_reg[16]_i_1_n_7 ;
  wire \interim_reg[30]_i_1_n_1 ;
  wire \interim_reg[30]_i_1_n_2 ;
  wire \interim_reg[30]_i_1_n_3 ;
  wire \interim_reg[30]_i_1_n_5 ;
  wire \interim_reg[30]_i_1_n_6 ;
  wire \interim_reg[30]_i_1_n_7 ;
  wire \interim_reg[4]_i_1_n_0 ;
  wire \interim_reg[4]_i_1_n_1 ;
  wire \interim_reg[4]_i_1_n_2 ;
  wire \interim_reg[4]_i_1_n_3 ;
  wire \interim_reg[4]_i_1_n_4 ;
  wire \interim_reg[4]_i_1_n_5 ;
  wire \interim_reg[4]_i_1_n_6 ;
  wire \interim_reg[4]_i_1_n_7 ;
  wire \interim_reg[8]_i_1_n_0 ;
  wire \interim_reg[8]_i_1_n_1 ;
  wire \interim_reg[8]_i_1_n_2 ;
  wire \interim_reg[8]_i_1_n_3 ;
  wire \interim_reg[8]_i_1_n_4 ;
  wire \interim_reg[8]_i_1_n_5 ;
  wire \interim_reg[8]_i_1_n_6 ;
  wire \interim_reg[8]_i_1_n_7 ;
  wire new_velocity_available;
  wire nv_flag_i_1_n_0;
  wire [20:0]output_velocity;
  wire p_0_in0;
  wire [31:0]p_term;
  wire send_it;
  wire velocity0;
  wire velocity1_carry__0_i_10_n_0;
  wire velocity1_carry__0_i_10_n_1;
  wire velocity1_carry__0_i_10_n_2;
  wire velocity1_carry__0_i_10_n_3;
  wire velocity1_carry__0_i_11_n_0;
  wire velocity1_carry__0_i_12_n_0;
  wire velocity1_carry__0_i_13_n_0;
  wire velocity1_carry__0_i_14_n_0;
  wire velocity1_carry__0_i_15_n_0;
  wire velocity1_carry__0_i_16_n_0;
  wire velocity1_carry__0_i_17_n_0;
  wire velocity1_carry__0_i_18_n_0;
  wire velocity1_carry__0_i_1_n_0;
  wire velocity1_carry__0_i_2_n_0;
  wire velocity1_carry__0_i_3_n_0;
  wire velocity1_carry__0_i_4_n_0;
  wire velocity1_carry__0_i_5_n_0;
  wire velocity1_carry__0_i_6_n_0;
  wire velocity1_carry__0_i_7_n_0;
  wire velocity1_carry__0_i_8_n_0;
  wire velocity1_carry__0_i_9_n_0;
  wire velocity1_carry__0_i_9_n_1;
  wire velocity1_carry__0_i_9_n_2;
  wire velocity1_carry__0_i_9_n_3;
  wire velocity1_carry__0_n_0;
  wire velocity1_carry__0_n_1;
  wire velocity1_carry__0_n_2;
  wire velocity1_carry__0_n_3;
  wire velocity1_carry__1_i_10_n_0;
  wire velocity1_carry__1_i_10_n_1;
  wire velocity1_carry__1_i_10_n_2;
  wire velocity1_carry__1_i_10_n_3;
  wire velocity1_carry__1_i_11_n_0;
  wire velocity1_carry__1_i_12_n_0;
  wire velocity1_carry__1_i_13_n_0;
  wire velocity1_carry__1_i_14_n_0;
  wire velocity1_carry__1_i_15_n_0;
  wire velocity1_carry__1_i_16_n_0;
  wire velocity1_carry__1_i_17_n_0;
  wire velocity1_carry__1_i_18_n_0;
  wire velocity1_carry__1_i_1_n_0;
  wire velocity1_carry__1_i_2_n_0;
  wire velocity1_carry__1_i_3_n_0;
  wire velocity1_carry__1_i_4_n_0;
  wire velocity1_carry__1_i_5_n_0;
  wire velocity1_carry__1_i_6_n_0;
  wire velocity1_carry__1_i_7_n_0;
  wire velocity1_carry__1_i_8_n_0;
  wire velocity1_carry__1_i_9_n_0;
  wire velocity1_carry__1_i_9_n_1;
  wire velocity1_carry__1_i_9_n_2;
  wire velocity1_carry__1_i_9_n_3;
  wire velocity1_carry__1_n_0;
  wire velocity1_carry__1_n_1;
  wire velocity1_carry__1_n_2;
  wire velocity1_carry__1_n_3;
  wire velocity1_carry__2_i_10_n_0;
  wire velocity1_carry__2_i_10_n_1;
  wire velocity1_carry__2_i_10_n_2;
  wire velocity1_carry__2_i_10_n_3;
  wire velocity1_carry__2_i_11_n_0;
  wire velocity1_carry__2_i_12_n_0;
  wire velocity1_carry__2_i_13_n_0;
  wire velocity1_carry__2_i_14_n_0;
  wire velocity1_carry__2_i_15_n_0;
  wire velocity1_carry__2_i_16_n_0;
  wire velocity1_carry__2_i_17_n_0;
  wire velocity1_carry__2_i_18_n_0;
  wire velocity1_carry__2_i_1_n_0;
  wire velocity1_carry__2_i_2_n_0;
  wire velocity1_carry__2_i_3_n_0;
  wire velocity1_carry__2_i_4_n_0;
  wire velocity1_carry__2_i_5_n_0;
  wire velocity1_carry__2_i_6_n_0;
  wire velocity1_carry__2_i_7_n_0;
  wire velocity1_carry__2_i_8_n_0;
  wire velocity1_carry__2_i_9_n_1;
  wire velocity1_carry__2_i_9_n_2;
  wire velocity1_carry__2_i_9_n_3;
  wire velocity1_carry__2_n_0;
  wire velocity1_carry__2_n_1;
  wire velocity1_carry__2_n_2;
  wire velocity1_carry__2_n_3;
  wire velocity1_carry_i_10_n_0;
  wire velocity1_carry_i_11_n_0;
  wire velocity1_carry_i_12_n_0;
  wire velocity1_carry_i_13_n_0;
  wire velocity1_carry_i_14_n_0;
  wire velocity1_carry_i_15_n_0;
  wire velocity1_carry_i_16_n_0;
  wire velocity1_carry_i_17_n_0;
  wire velocity1_carry_i_1_n_0;
  wire velocity1_carry_i_2_n_0;
  wire velocity1_carry_i_2_n_1;
  wire velocity1_carry_i_2_n_2;
  wire velocity1_carry_i_2_n_3;
  wire velocity1_carry_i_3_n_0;
  wire velocity1_carry_i_4_n_0;
  wire velocity1_carry_i_5_n_0;
  wire velocity1_carry_i_6_n_0;
  wire velocity1_carry_i_7_n_0;
  wire velocity1_carry_i_8_n_0;
  wire velocity1_carry_i_9_n_0;
  wire velocity1_carry_i_9_n_1;
  wire velocity1_carry_i_9_n_2;
  wire velocity1_carry_i_9_n_3;
  wire velocity1_carry_n_0;
  wire velocity1_carry_n_1;
  wire velocity1_carry_n_2;
  wire velocity1_carry_n_3;
  wire \velocity1_inferred__0/i__carry__0_n_0 ;
  wire \velocity1_inferred__0/i__carry__0_n_1 ;
  wire \velocity1_inferred__0/i__carry__0_n_2 ;
  wire \velocity1_inferred__0/i__carry__0_n_3 ;
  wire \velocity1_inferred__0/i__carry__1_n_0 ;
  wire \velocity1_inferred__0/i__carry__1_n_1 ;
  wire \velocity1_inferred__0/i__carry__1_n_2 ;
  wire \velocity1_inferred__0/i__carry__1_n_3 ;
  wire \velocity1_inferred__0/i__carry__2_n_0 ;
  wire \velocity1_inferred__0/i__carry__2_n_1 ;
  wire \velocity1_inferred__0/i__carry__2_n_2 ;
  wire \velocity1_inferred__0/i__carry__2_n_3 ;
  wire \velocity1_inferred__0/i__carry_n_0 ;
  wire \velocity1_inferred__0/i__carry_n_1 ;
  wire \velocity1_inferred__0/i__carry_n_2 ;
  wire \velocity1_inferred__0/i__carry_n_3 ;
  wire [31:0]velocity2;
  wire [3:3]NLW_i__carry_i_9__2_CO_UNCONNECTED;
  wire [2:0]\NLW_interim_reg[0]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_interim_reg[0]_i_11_O_UNCONNECTED ;
  wire [3:0]\NLW_interim_reg[0]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_interim_reg[30]_i_1_CO_UNCONNECTED ;
  wire [3:0]NLW_velocity1_carry_O_UNCONNECTED;
  wire [3:0]NLW_velocity1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_velocity1_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_velocity1_carry__2_O_UNCONNECTED;
  wire [3:3]NLW_velocity1_carry__2_i_9_CO_UNCONNECTED;
  wire [3:0]\NLW_velocity1_inferred__0/i__carry_O_UNCONNECTED ;
  wire [3:0]\NLW_velocity1_inferred__0/i__carry__0_O_UNCONNECTED ;
  wire [3:0]\NLW_velocity1_inferred__0/i__carry__1_O_UNCONNECTED ;
  wire [3:0]\NLW_velocity1_inferred__0/i__carry__2_O_UNCONNECTED ;

  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_1
       (.I0(i__carry_i_2_n_5),
        .I1(i__carry_i_2_n_4),
        .O(i__carry_i_1_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_10
       (.CI(i__carry_i_2_n_0),
        .CO({i__carry_i_10_n_0,i__carry_i_10_n_1,i__carry_i_10_n_2,i__carry_i_10_n_3}),
        .CYINIT(1'b0),
        .DI(output_velocity[11:8]),
        .O({i__carry_i_10_n_4,i__carry_i_10_n_5,i__carry_i_10_n_6,i__carry_i_10_n_7}),
        .S({i__carry_i_15__0_n_0,i__carry_i_16__0_n_0,i__carry_i_17__0_n_0,i__carry_i_18_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_10__0
       (.CI(i__carry_i_9__0_n_0),
        .CO({i__carry_i_10__0_n_0,i__carry_i_10__0_n_1,i__carry_i_10__0_n_2,i__carry_i_10__0_n_3}),
        .CYINIT(1'b0),
        .DI(output_velocity[19:16]),
        .O({i__carry_i_10__0_n_4,i__carry_i_10__0_n_5,i__carry_i_10__0_n_6,i__carry_i_10__0_n_7}),
        .S({i__carry_i_15__1_n_0,i__carry_i_16__1_n_0,i__carry_i_17__1_n_0,i__carry_i_18__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_10__1
       (.CI(i__carry_i_9__1_n_0),
        .CO({i__carry_i_10__1_n_0,i__carry_i_10__1_n_1,i__carry_i_10__1_n_2,i__carry_i_10__1_n_3}),
        .CYINIT(1'b0),
        .DI({output_velocity[20],output_velocity[20],output_velocity[20],output_velocity[20]}),
        .O({i__carry_i_10__1_n_4,i__carry_i_10__1_n_5,i__carry_i_10__1_n_6,i__carry_i_10__1_n_7}),
        .S({i__carry_i_15__2_n_0,i__carry_i_16__2_n_0,i__carry_i_17__2_n_0,i__carry_i_18__1_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_10__2
       (.I0(output_velocity[7]),
        .I1(interim[7]),
        .O(i__carry_i_10__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_11
       (.I0(output_velocity[6]),
        .I1(interim[6]),
        .O(i__carry_i_11_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_11__0
       (.I0(output_velocity[15]),
        .I1(interim[15]),
        .O(i__carry_i_11__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_11__1
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_11__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_11__2
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_11__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_12
       (.I0(output_velocity[5]),
        .I1(interim[5]),
        .O(i__carry_i_12_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_12__0
       (.I0(output_velocity[14]),
        .I1(interim[14]),
        .O(i__carry_i_12__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_12__1
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_12__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_12__2
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_12__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_13
       (.I0(output_velocity[4]),
        .I1(interim[4]),
        .O(i__carry_i_13_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_13__0
       (.I0(output_velocity[13]),
        .I1(interim[13]),
        .O(i__carry_i_13__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_13__1
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_13__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_13__2
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_13__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_14
       (.I0(output_velocity[3]),
        .I1(interim[3]),
        .O(i__carry_i_14_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_14__0
       (.I0(output_velocity[12]),
        .I1(interim[12]),
        .O(i__carry_i_14__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_14__1
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_14__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_14__2
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_14__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_15
       (.I0(output_velocity[2]),
        .I1(interim[2]),
        .O(i__carry_i_15_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_15__0
       (.I0(output_velocity[11]),
        .I1(interim[11]),
        .O(i__carry_i_15__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_15__1
       (.I0(output_velocity[19]),
        .I1(interim[19]),
        .O(i__carry_i_15__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_15__2
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_15__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_16
       (.I0(output_velocity[1]),
        .I1(interim[1]),
        .O(i__carry_i_16_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_16__0
       (.I0(output_velocity[10]),
        .I1(interim[10]),
        .O(i__carry_i_16__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_16__1
       (.I0(output_velocity[18]),
        .I1(interim[18]),
        .O(i__carry_i_16__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_16__2
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_16__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_17
       (.I0(output_velocity[0]),
        .I1(interim[0]),
        .O(i__carry_i_17_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_17__0
       (.I0(output_velocity[9]),
        .I1(interim[9]),
        .O(i__carry_i_17__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_17__1
       (.I0(output_velocity[17]),
        .I1(interim[17]),
        .O(i__carry_i_17__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_17__2
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_17__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_18
       (.I0(output_velocity[8]),
        .I1(interim[8]),
        .O(i__carry_i_18_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_18__0
       (.I0(output_velocity[16]),
        .I1(interim[16]),
        .O(i__carry_i_18__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    i__carry_i_18__1
       (.I0(output_velocity[20]),
        .I1(interim[30]),
        .O(i__carry_i_18__1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_1__0
       (.I0(i__carry_i_9__0_n_5),
        .I1(i__carry_i_9__0_n_4),
        .O(i__carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_1__1
       (.I0(i__carry_i_9__1_n_5),
        .I1(i__carry_i_9__1_n_4),
        .O(i__carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry_i_1__2
       (.I0(i__carry_i_9__2_n_5),
        .I1(i__carry_i_9__2_n_4),
        .O(i__carry_i_1__2_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_2
       (.CI(i__carry_i_9_n_0),
        .CO({i__carry_i_2_n_0,i__carry_i_2_n_1,i__carry_i_2_n_2,i__carry_i_2_n_3}),
        .CYINIT(1'b0),
        .DI(output_velocity[7:4]),
        .O({i__carry_i_2_n_4,i__carry_i_2_n_5,i__carry_i_2_n_6,i__carry_i_2_n_7}),
        .S({i__carry_i_10__2_n_0,i__carry_i_11_n_0,i__carry_i_12_n_0,i__carry_i_13_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_2__0
       (.I0(i__carry_i_9__0_n_7),
        .I1(i__carry_i_9__0_n_6),
        .O(i__carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_2__1
       (.I0(i__carry_i_9__1_n_7),
        .I1(i__carry_i_9__1_n_6),
        .O(i__carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_2__2
       (.I0(i__carry_i_9__2_n_7),
        .I1(i__carry_i_9__2_n_6),
        .O(i__carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_3
       (.I0(i__carry_i_9_n_5),
        .I1(i__carry_i_9_n_4),
        .O(i__carry_i_3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_3__0
       (.I0(i__carry_i_10_n_5),
        .I1(i__carry_i_10_n_4),
        .O(i__carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_3__1
       (.I0(i__carry_i_10__0_n_5),
        .I1(i__carry_i_10__0_n_4),
        .O(i__carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_3__2
       (.I0(i__carry_i_10__1_n_5),
        .I1(i__carry_i_10__1_n_4),
        .O(i__carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_4
       (.I0(i__carry_i_9_n_7),
        .I1(i__carry_i_9_n_6),
        .O(i__carry_i_4_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_4__0
       (.I0(i__carry_i_10_n_7),
        .I1(i__carry_i_10_n_6),
        .O(i__carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_4__1
       (.I0(i__carry_i_10__0_n_7),
        .I1(i__carry_i_10__0_n_6),
        .O(i__carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_4__2
       (.I0(i__carry_i_10__1_n_7),
        .I1(i__carry_i_10__1_n_6),
        .O(i__carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_5
       (.I0(i__carry_i_9__2_n_5),
        .I1(i__carry_i_9__2_n_4),
        .O(i__carry_i_5_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_5__0
       (.I0(i__carry_i_9__1_n_5),
        .I1(i__carry_i_9__1_n_4),
        .O(i__carry_i_5__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_5__1
       (.I0(i__carry_i_9__0_n_5),
        .I1(i__carry_i_9__0_n_4),
        .O(i__carry_i_5__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_5__2
       (.I0(i__carry_i_2_n_5),
        .I1(i__carry_i_2_n_4),
        .O(i__carry_i_5__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_6
       (.I0(i__carry_i_9__2_n_7),
        .I1(i__carry_i_9__2_n_6),
        .O(i__carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_6__0
       (.I0(i__carry_i_9__1_n_7),
        .I1(i__carry_i_9__1_n_6),
        .O(i__carry_i_6__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_6__1
       (.I0(i__carry_i_9__0_n_7),
        .I1(i__carry_i_9__0_n_6),
        .O(i__carry_i_6__1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry_i_6__2
       (.I0(i__carry_i_2_n_7),
        .I1(i__carry_i_2_n_6),
        .O(i__carry_i_6__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_7
       (.I0(i__carry_i_10__1_n_5),
        .I1(i__carry_i_10__1_n_4),
        .O(i__carry_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_7__0
       (.I0(i__carry_i_10__0_n_5),
        .I1(i__carry_i_10__0_n_4),
        .O(i__carry_i_7__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_7__1
       (.I0(i__carry_i_10_n_5),
        .I1(i__carry_i_10_n_4),
        .O(i__carry_i_7__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_7__2
       (.I0(i__carry_i_9_n_5),
        .I1(i__carry_i_9_n_4),
        .O(i__carry_i_7__2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_8
       (.I0(i__carry_i_10__1_n_7),
        .I1(i__carry_i_10__1_n_6),
        .O(i__carry_i_8_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_8__0
       (.I0(i__carry_i_10__0_n_7),
        .I1(i__carry_i_10__0_n_6),
        .O(i__carry_i_8__0_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_8__1
       (.I0(i__carry_i_10_n_7),
        .I1(i__carry_i_10_n_6),
        .O(i__carry_i_8__1_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_8__2
       (.I0(i__carry_i_9_n_7),
        .I1(i__carry_i_9_n_6),
        .O(i__carry_i_8__2_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_9
       (.CI(1'b0),
        .CO({i__carry_i_9_n_0,i__carry_i_9_n_1,i__carry_i_9_n_2,i__carry_i_9_n_3}),
        .CYINIT(1'b1),
        .DI(output_velocity[3:0]),
        .O({i__carry_i_9_n_4,i__carry_i_9_n_5,i__carry_i_9_n_6,i__carry_i_9_n_7}),
        .S({i__carry_i_14_n_0,i__carry_i_15_n_0,i__carry_i_16_n_0,i__carry_i_17_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_9__0
       (.CI(i__carry_i_10_n_0),
        .CO({i__carry_i_9__0_n_0,i__carry_i_9__0_n_1,i__carry_i_9__0_n_2,i__carry_i_9__0_n_3}),
        .CYINIT(1'b0),
        .DI(output_velocity[15:12]),
        .O({i__carry_i_9__0_n_4,i__carry_i_9__0_n_5,i__carry_i_9__0_n_6,i__carry_i_9__0_n_7}),
        .S({i__carry_i_11__0_n_0,i__carry_i_12__0_n_0,i__carry_i_13__0_n_0,i__carry_i_14__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_9__1
       (.CI(i__carry_i_10__0_n_0),
        .CO({i__carry_i_9__1_n_0,i__carry_i_9__1_n_1,i__carry_i_9__1_n_2,i__carry_i_9__1_n_3}),
        .CYINIT(1'b0),
        .DI({output_velocity[20],output_velocity[20],output_velocity[20],output_velocity[20]}),
        .O({i__carry_i_9__1_n_4,i__carry_i_9__1_n_5,i__carry_i_9__1_n_6,i__carry_i_9__1_n_7}),
        .S({i__carry_i_11__2_n_0,i__carry_i_12__1_n_0,i__carry_i_13__1_n_0,i__carry_i_14__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 i__carry_i_9__2
       (.CI(i__carry_i_10__1_n_0),
        .CO({NLW_i__carry_i_9__2_CO_UNCONNECTED[3],i__carry_i_9__2_n_1,i__carry_i_9__2_n_2,i__carry_i_9__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,output_velocity[20],output_velocity[20],output_velocity[20]}),
        .O({i__carry_i_9__2_n_4,i__carry_i_9__2_n_5,i__carry_i_9__2_n_6,i__carry_i_9__2_n_7}),
        .S({i__carry_i_11__1_n_0,i__carry_i_12__2_n_0,i__carry_i_13__2_n_0,i__carry_i_14__2_n_0}));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_10 
       (.I0(i_term[8]),
        .I1(d_term[8]),
        .I2(p_term[8]),
        .I3(\interim[0]_i_6_n_0 ),
        .O(\interim[0]_i_10_n_0 ));
  (* HLUTNM = "lutpair6" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_12 
       (.I0(i_term[6]),
        .I1(d_term[6]),
        .I2(p_term[6]),
        .O(\interim[0]_i_12_n_0 ));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_13 
       (.I0(i_term[5]),
        .I1(d_term[5]),
        .I2(p_term[5]),
        .O(\interim[0]_i_13_n_0 ));
  (* HLUTNM = "lutpair4" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_14 
       (.I0(i_term[4]),
        .I1(d_term[4]),
        .I2(p_term[4]),
        .O(\interim[0]_i_14_n_0 ));
  (* HLUTNM = "lutpair3" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_15 
       (.I0(i_term[3]),
        .I1(d_term[3]),
        .I2(p_term[3]),
        .O(\interim[0]_i_15_n_0 ));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_16 
       (.I0(i_term[7]),
        .I1(d_term[7]),
        .I2(p_term[7]),
        .I3(\interim[0]_i_12_n_0 ),
        .O(\interim[0]_i_16_n_0 ));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_17 
       (.I0(i_term[6]),
        .I1(d_term[6]),
        .I2(p_term[6]),
        .I3(\interim[0]_i_13_n_0 ),
        .O(\interim[0]_i_17_n_0 ));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_18 
       (.I0(i_term[5]),
        .I1(d_term[5]),
        .I2(p_term[5]),
        .I3(\interim[0]_i_14_n_0 ),
        .O(\interim[0]_i_18_n_0 ));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_19 
       (.I0(i_term[4]),
        .I1(d_term[4]),
        .I2(p_term[4]),
        .I3(\interim[0]_i_15_n_0 ),
        .O(\interim[0]_i_19_n_0 ));
  (* HLUTNM = "lutpair2" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_20 
       (.I0(i_term[2]),
        .I1(d_term[2]),
        .I2(p_term[2]),
        .O(\interim[0]_i_20_n_0 ));
  (* HLUTNM = "lutpair1" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_21 
       (.I0(i_term[1]),
        .I1(d_term[1]),
        .I2(p_term[1]),
        .O(\interim[0]_i_21_n_0 ));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_22 
       (.I0(i_term[0]),
        .I1(d_term[0]),
        .I2(p_term[0]),
        .O(\interim[0]_i_22_n_0 ));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_23 
       (.I0(i_term[3]),
        .I1(d_term[3]),
        .I2(p_term[3]),
        .I3(\interim[0]_i_20_n_0 ),
        .O(\interim[0]_i_23_n_0 ));
  (* HLUTNM = "lutpair2" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_24 
       (.I0(i_term[2]),
        .I1(d_term[2]),
        .I2(p_term[2]),
        .I3(\interim[0]_i_21_n_0 ),
        .O(\interim[0]_i_24_n_0 ));
  (* HLUTNM = "lutpair1" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_25 
       (.I0(i_term[1]),
        .I1(d_term[1]),
        .I2(p_term[1]),
        .I3(\interim[0]_i_22_n_0 ),
        .O(\interim[0]_i_25_n_0 ));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \interim[0]_i_26 
       (.I0(i_term[0]),
        .I1(d_term[0]),
        .I2(p_term[0]),
        .O(\interim[0]_i_26_n_0 ));
  (* HLUTNM = "lutpair10" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_3 
       (.I0(i_term[10]),
        .I1(d_term[10]),
        .I2(p_term[10]),
        .O(\interim[0]_i_3_n_0 ));
  (* HLUTNM = "lutpair9" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_4 
       (.I0(i_term[9]),
        .I1(d_term[9]),
        .I2(p_term[9]),
        .O(\interim[0]_i_4_n_0 ));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_5 
       (.I0(i_term[8]),
        .I1(d_term[8]),
        .I2(p_term[8]),
        .O(\interim[0]_i_5_n_0 ));
  (* HLUTNM = "lutpair7" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[0]_i_6 
       (.I0(i_term[7]),
        .I1(d_term[7]),
        .I2(p_term[7]),
        .O(\interim[0]_i_6_n_0 ));
  (* HLUTNM = "lutpair11" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_7 
       (.I0(i_term[11]),
        .I1(d_term[11]),
        .I2(p_term[11]),
        .I3(\interim[0]_i_3_n_0 ),
        .O(\interim[0]_i_7_n_0 ));
  (* HLUTNM = "lutpair10" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_8 
       (.I0(i_term[10]),
        .I1(d_term[10]),
        .I2(p_term[10]),
        .I3(\interim[0]_i_4_n_0 ),
        .O(\interim[0]_i_8_n_0 ));
  (* HLUTNM = "lutpair9" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[0]_i_9 
       (.I0(i_term[9]),
        .I1(d_term[9]),
        .I2(p_term[9]),
        .I3(\interim[0]_i_5_n_0 ),
        .O(\interim[0]_i_9_n_0 ));
  (* HLUTNM = "lutpair22" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[12]_i_2 
       (.I0(i_term[22]),
        .I1(d_term[22]),
        .I2(p_term[22]),
        .O(\interim[12]_i_2_n_0 ));
  (* HLUTNM = "lutpair21" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[12]_i_3 
       (.I0(i_term[21]),
        .I1(d_term[21]),
        .I2(p_term[21]),
        .O(\interim[12]_i_3_n_0 ));
  (* HLUTNM = "lutpair20" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[12]_i_4 
       (.I0(i_term[20]),
        .I1(d_term[20]),
        .I2(p_term[20]),
        .O(\interim[12]_i_4_n_0 ));
  (* HLUTNM = "lutpair19" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[12]_i_5 
       (.I0(i_term[19]),
        .I1(d_term[19]),
        .I2(p_term[19]),
        .O(\interim[12]_i_5_n_0 ));
  (* HLUTNM = "lutpair23" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[12]_i_6 
       (.I0(i_term[23]),
        .I1(d_term[23]),
        .I2(p_term[23]),
        .I3(\interim[12]_i_2_n_0 ),
        .O(\interim[12]_i_6_n_0 ));
  (* HLUTNM = "lutpair22" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[12]_i_7 
       (.I0(i_term[22]),
        .I1(d_term[22]),
        .I2(p_term[22]),
        .I3(\interim[12]_i_3_n_0 ),
        .O(\interim[12]_i_7_n_0 ));
  (* HLUTNM = "lutpair21" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[12]_i_8 
       (.I0(i_term[21]),
        .I1(d_term[21]),
        .I2(p_term[21]),
        .I3(\interim[12]_i_4_n_0 ),
        .O(\interim[12]_i_8_n_0 ));
  (* HLUTNM = "lutpair20" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[12]_i_9 
       (.I0(i_term[20]),
        .I1(d_term[20]),
        .I2(p_term[20]),
        .I3(\interim[12]_i_5_n_0 ),
        .O(\interim[12]_i_9_n_0 ));
  (* HLUTNM = "lutpair26" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[16]_i_2 
       (.I0(i_term[26]),
        .I1(d_term[26]),
        .I2(p_term[26]),
        .O(\interim[16]_i_2_n_0 ));
  (* HLUTNM = "lutpair25" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[16]_i_3 
       (.I0(i_term[25]),
        .I1(d_term[25]),
        .I2(p_term[25]),
        .O(\interim[16]_i_3_n_0 ));
  (* HLUTNM = "lutpair24" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[16]_i_4 
       (.I0(i_term[24]),
        .I1(d_term[24]),
        .I2(p_term[24]),
        .O(\interim[16]_i_4_n_0 ));
  (* HLUTNM = "lutpair23" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[16]_i_5 
       (.I0(i_term[23]),
        .I1(d_term[23]),
        .I2(p_term[23]),
        .O(\interim[16]_i_5_n_0 ));
  (* HLUTNM = "lutpair27" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[16]_i_6 
       (.I0(i_term[27]),
        .I1(d_term[27]),
        .I2(p_term[27]),
        .I3(\interim[16]_i_2_n_0 ),
        .O(\interim[16]_i_6_n_0 ));
  (* HLUTNM = "lutpair26" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[16]_i_7 
       (.I0(i_term[26]),
        .I1(d_term[26]),
        .I2(p_term[26]),
        .I3(\interim[16]_i_3_n_0 ),
        .O(\interim[16]_i_7_n_0 ));
  (* HLUTNM = "lutpair25" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[16]_i_8 
       (.I0(i_term[25]),
        .I1(d_term[25]),
        .I2(p_term[25]),
        .I3(\interim[16]_i_4_n_0 ),
        .O(\interim[16]_i_8_n_0 ));
  (* HLUTNM = "lutpair24" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[16]_i_9 
       (.I0(i_term[24]),
        .I1(d_term[24]),
        .I2(p_term[24]),
        .I3(\interim[16]_i_5_n_0 ),
        .O(\interim[16]_i_9_n_0 ));
  (* HLUTNM = "lutpair29" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[30]_i_2 
       (.I0(i_term[29]),
        .I1(d_term[29]),
        .I2(p_term[29]),
        .O(\interim[30]_i_2_n_0 ));
  (* HLUTNM = "lutpair28" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[30]_i_3 
       (.I0(i_term[28]),
        .I1(d_term[28]),
        .I2(p_term[28]),
        .O(\interim[30]_i_3_n_0 ));
  (* HLUTNM = "lutpair27" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[30]_i_4 
       (.I0(i_term[27]),
        .I1(d_term[27]),
        .I2(p_term[27]),
        .O(\interim[30]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    \interim[30]_i_5 
       (.I0(p_term[30]),
        .I1(d_term[30]),
        .I2(i_term[30]),
        .I3(d_term[31]),
        .I4(i_term[31]),
        .I5(p_term[31]),
        .O(\interim[30]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[30]_i_6 
       (.I0(\interim[30]_i_2_n_0 ),
        .I1(d_term[30]),
        .I2(i_term[30]),
        .I3(p_term[30]),
        .O(\interim[30]_i_6_n_0 ));
  (* HLUTNM = "lutpair29" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[30]_i_7 
       (.I0(i_term[29]),
        .I1(d_term[29]),
        .I2(p_term[29]),
        .I3(\interim[30]_i_3_n_0 ),
        .O(\interim[30]_i_7_n_0 ));
  (* HLUTNM = "lutpair28" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[30]_i_8 
       (.I0(i_term[28]),
        .I1(d_term[28]),
        .I2(p_term[28]),
        .I3(\interim[30]_i_4_n_0 ),
        .O(\interim[30]_i_8_n_0 ));
  (* HLUTNM = "lutpair14" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[4]_i_2 
       (.I0(i_term[14]),
        .I1(d_term[14]),
        .I2(p_term[14]),
        .O(\interim[4]_i_2_n_0 ));
  (* HLUTNM = "lutpair13" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[4]_i_3 
       (.I0(i_term[13]),
        .I1(d_term[13]),
        .I2(p_term[13]),
        .O(\interim[4]_i_3_n_0 ));
  (* HLUTNM = "lutpair12" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[4]_i_4 
       (.I0(i_term[12]),
        .I1(d_term[12]),
        .I2(p_term[12]),
        .O(\interim[4]_i_4_n_0 ));
  (* HLUTNM = "lutpair11" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[4]_i_5 
       (.I0(i_term[11]),
        .I1(d_term[11]),
        .I2(p_term[11]),
        .O(\interim[4]_i_5_n_0 ));
  (* HLUTNM = "lutpair15" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[4]_i_6 
       (.I0(i_term[15]),
        .I1(d_term[15]),
        .I2(p_term[15]),
        .I3(\interim[4]_i_2_n_0 ),
        .O(\interim[4]_i_6_n_0 ));
  (* HLUTNM = "lutpair14" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[4]_i_7 
       (.I0(i_term[14]),
        .I1(d_term[14]),
        .I2(p_term[14]),
        .I3(\interim[4]_i_3_n_0 ),
        .O(\interim[4]_i_7_n_0 ));
  (* HLUTNM = "lutpair13" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[4]_i_8 
       (.I0(i_term[13]),
        .I1(d_term[13]),
        .I2(p_term[13]),
        .I3(\interim[4]_i_4_n_0 ),
        .O(\interim[4]_i_8_n_0 ));
  (* HLUTNM = "lutpair12" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[4]_i_9 
       (.I0(i_term[12]),
        .I1(d_term[12]),
        .I2(p_term[12]),
        .I3(\interim[4]_i_5_n_0 ),
        .O(\interim[4]_i_9_n_0 ));
  (* HLUTNM = "lutpair18" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[8]_i_2 
       (.I0(i_term[18]),
        .I1(d_term[18]),
        .I2(p_term[18]),
        .O(\interim[8]_i_2_n_0 ));
  (* HLUTNM = "lutpair17" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[8]_i_3 
       (.I0(i_term[17]),
        .I1(d_term[17]),
        .I2(p_term[17]),
        .O(\interim[8]_i_3_n_0 ));
  (* HLUTNM = "lutpair16" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[8]_i_4 
       (.I0(i_term[16]),
        .I1(d_term[16]),
        .I2(p_term[16]),
        .O(\interim[8]_i_4_n_0 ));
  (* HLUTNM = "lutpair15" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[8]_i_5 
       (.I0(i_term[15]),
        .I1(d_term[15]),
        .I2(p_term[15]),
        .O(\interim[8]_i_5_n_0 ));
  (* HLUTNM = "lutpair19" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[8]_i_6 
       (.I0(i_term[19]),
        .I1(d_term[19]),
        .I2(p_term[19]),
        .I3(\interim[8]_i_2_n_0 ),
        .O(\interim[8]_i_6_n_0 ));
  (* HLUTNM = "lutpair18" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[8]_i_7 
       (.I0(i_term[18]),
        .I1(d_term[18]),
        .I2(p_term[18]),
        .I3(\interim[8]_i_3_n_0 ),
        .O(\interim[8]_i_7_n_0 ));
  (* HLUTNM = "lutpair17" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[8]_i_8 
       (.I0(i_term[17]),
        .I1(d_term[17]),
        .I2(p_term[17]),
        .I3(\interim[8]_i_4_n_0 ),
        .O(\interim[8]_i_8_n_0 ));
  (* HLUTNM = "lutpair16" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[8]_i_9 
       (.I0(i_term[16]),
        .I1(d_term[16]),
        .I2(p_term[16]),
        .I3(\interim[8]_i_5_n_0 ),
        .O(\interim[8]_i_9_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[0]_i_1_n_4 ),
        .Q(interim[0]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[0]_i_1 
       (.CI(\interim_reg[0]_i_2_n_0 ),
        .CO({\interim_reg[0]_i_1_n_0 ,\interim_reg[0]_i_1_n_1 ,\interim_reg[0]_i_1_n_2 ,\interim_reg[0]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[0]_i_3_n_0 ,\interim[0]_i_4_n_0 ,\interim[0]_i_5_n_0 ,\interim[0]_i_6_n_0 }),
        .O({\interim_reg[0]_i_1_n_4 ,\NLW_interim_reg[0]_i_1_O_UNCONNECTED [2:0]}),
        .S({\interim[0]_i_7_n_0 ,\interim[0]_i_8_n_0 ,\interim[0]_i_9_n_0 ,\interim[0]_i_10_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[0]_i_11 
       (.CI(1'b0),
        .CO({\interim_reg[0]_i_11_n_0 ,\interim_reg[0]_i_11_n_1 ,\interim_reg[0]_i_11_n_2 ,\interim_reg[0]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[0]_i_20_n_0 ,\interim[0]_i_21_n_0 ,\interim[0]_i_22_n_0 ,1'b0}),
        .O(\NLW_interim_reg[0]_i_11_O_UNCONNECTED [3:0]),
        .S({\interim[0]_i_23_n_0 ,\interim[0]_i_24_n_0 ,\interim[0]_i_25_n_0 ,\interim[0]_i_26_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[0]_i_2 
       (.CI(\interim_reg[0]_i_11_n_0 ),
        .CO({\interim_reg[0]_i_2_n_0 ,\interim_reg[0]_i_2_n_1 ,\interim_reg[0]_i_2_n_2 ,\interim_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[0]_i_12_n_0 ,\interim[0]_i_13_n_0 ,\interim[0]_i_14_n_0 ,\interim[0]_i_15_n_0 }),
        .O(\NLW_interim_reg[0]_i_2_O_UNCONNECTED [3:0]),
        .S({\interim[0]_i_16_n_0 ,\interim[0]_i_17_n_0 ,\interim[0]_i_18_n_0 ,\interim[0]_i_19_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[12]_i_1_n_6 ),
        .Q(interim[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[12]_i_1_n_5 ),
        .Q(interim[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[12]_i_1_n_4 ),
        .Q(interim[12]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[12]_i_1 
       (.CI(\interim_reg[8]_i_1_n_0 ),
        .CO({\interim_reg[12]_i_1_n_0 ,\interim_reg[12]_i_1_n_1 ,\interim_reg[12]_i_1_n_2 ,\interim_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[12]_i_2_n_0 ,\interim[12]_i_3_n_0 ,\interim[12]_i_4_n_0 ,\interim[12]_i_5_n_0 }),
        .O({\interim_reg[12]_i_1_n_4 ,\interim_reg[12]_i_1_n_5 ,\interim_reg[12]_i_1_n_6 ,\interim_reg[12]_i_1_n_7 }),
        .S({\interim[12]_i_6_n_0 ,\interim[12]_i_7_n_0 ,\interim[12]_i_8_n_0 ,\interim[12]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[16]_i_1_n_7 ),
        .Q(interim[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[16]_i_1_n_6 ),
        .Q(interim[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[16]_i_1_n_5 ),
        .Q(interim[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[16]_i_1_n_4 ),
        .Q(interim[16]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[16]_i_1 
       (.CI(\interim_reg[12]_i_1_n_0 ),
        .CO({\interim_reg[16]_i_1_n_0 ,\interim_reg[16]_i_1_n_1 ,\interim_reg[16]_i_1_n_2 ,\interim_reg[16]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[16]_i_2_n_0 ,\interim[16]_i_3_n_0 ,\interim[16]_i_4_n_0 ,\interim[16]_i_5_n_0 }),
        .O({\interim_reg[16]_i_1_n_4 ,\interim_reg[16]_i_1_n_5 ,\interim_reg[16]_i_1_n_6 ,\interim_reg[16]_i_1_n_7 }),
        .S({\interim[16]_i_6_n_0 ,\interim[16]_i_7_n_0 ,\interim[16]_i_8_n_0 ,\interim[16]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[30]_i_1_n_7 ),
        .Q(interim[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[30]_i_1_n_6 ),
        .Q(interim[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[30]_i_1_n_5 ),
        .Q(interim[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[4]_i_1_n_7 ),
        .Q(interim[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[4]_i_1_n_6 ),
        .Q(interim[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in0),
        .Q(interim[30]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[30]_i_1 
       (.CI(\interim_reg[16]_i_1_n_0 ),
        .CO({\NLW_interim_reg[30]_i_1_CO_UNCONNECTED [3],\interim_reg[30]_i_1_n_1 ,\interim_reg[30]_i_1_n_2 ,\interim_reg[30]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\interim[30]_i_2_n_0 ,\interim[30]_i_3_n_0 ,\interim[30]_i_4_n_0 }),
        .O({p_0_in0,\interim_reg[30]_i_1_n_5 ,\interim_reg[30]_i_1_n_6 ,\interim_reg[30]_i_1_n_7 }),
        .S({\interim[30]_i_5_n_0 ,\interim[30]_i_6_n_0 ,\interim[30]_i_7_n_0 ,\interim[30]_i_8_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[4]_i_1_n_5 ),
        .Q(interim[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[4]_i_1_n_4 ),
        .Q(interim[4]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[4]_i_1 
       (.CI(\interim_reg[0]_i_1_n_0 ),
        .CO({\interim_reg[4]_i_1_n_0 ,\interim_reg[4]_i_1_n_1 ,\interim_reg[4]_i_1_n_2 ,\interim_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[4]_i_2_n_0 ,\interim[4]_i_3_n_0 ,\interim[4]_i_4_n_0 ,\interim[4]_i_5_n_0 }),
        .O({\interim_reg[4]_i_1_n_4 ,\interim_reg[4]_i_1_n_5 ,\interim_reg[4]_i_1_n_6 ,\interim_reg[4]_i_1_n_7 }),
        .S({\interim[4]_i_6_n_0 ,\interim[4]_i_7_n_0 ,\interim[4]_i_8_n_0 ,\interim[4]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[8]_i_1_n_7 ),
        .Q(interim[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[8]_i_1_n_6 ),
        .Q(interim[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[8]_i_1_n_5 ),
        .Q(interim[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[8]_i_1_n_4 ),
        .Q(interim[8]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[8]_i_1 
       (.CI(\interim_reg[4]_i_1_n_0 ),
        .CO({\interim_reg[8]_i_1_n_0 ,\interim_reg[8]_i_1_n_1 ,\interim_reg[8]_i_1_n_2 ,\interim_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[8]_i_2_n_0 ,\interim[8]_i_3_n_0 ,\interim[8]_i_4_n_0 ,\interim[8]_i_5_n_0 }),
        .O({\interim_reg[8]_i_1_n_4 ,\interim_reg[8]_i_1_n_5 ,\interim_reg[8]_i_1_n_6 ,\interim_reg[8]_i_1_n_7 }),
        .S({\interim[8]_i_6_n_0 ,\interim[8]_i_7_n_0 ,\interim[8]_i_8_n_0 ,\interim[8]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(\interim_reg[12]_i_1_n_7 ),
        .Q(interim[9]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hEEE8)) 
    nv_flag_i_1
       (.I0(new_velocity_available),
        .I1(send_it),
        .I2(\velocity1_inferred__0/i__carry__2_n_0 ),
        .I3(velocity1_carry__2_n_0),
        .O(nv_flag_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    nv_flag_reg
       (.C(clock),
        .CE(1'b1),
        .D(nv_flag_i_1_n_0),
        .Q(new_velocity_available),
        .R(1'b0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 velocity1_carry
       (.CI(1'b0),
        .CO({velocity1_carry_n_0,velocity1_carry_n_1,velocity1_carry_n_2,velocity1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({velocity1_carry_i_1_n_0,velocity2[5],velocity1_carry_i_3_n_0,velocity1_carry_i_4_n_0}),
        .O(NLW_velocity1_carry_O_UNCONNECTED[3:0]),
        .S({velocity1_carry_i_5_n_0,velocity1_carry_i_6_n_0,velocity1_carry_i_7_n_0,velocity1_carry_i_8_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 velocity1_carry__0
       (.CI(velocity1_carry_n_0),
        .CO({velocity1_carry__0_n_0,velocity1_carry__0_n_1,velocity1_carry__0_n_2,velocity1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({velocity1_carry__0_i_1_n_0,velocity1_carry__0_i_2_n_0,velocity1_carry__0_i_3_n_0,velocity1_carry__0_i_4_n_0}),
        .O(NLW_velocity1_carry__0_O_UNCONNECTED[3:0]),
        .S({velocity1_carry__0_i_5_n_0,velocity1_carry__0_i_6_n_0,velocity1_carry__0_i_7_n_0,velocity1_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__0_i_1
       (.I0(velocity2[14]),
        .I1(velocity2[15]),
        .O(velocity1_carry__0_i_1_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry__0_i_10
       (.CI(velocity1_carry_i_2_n_0),
        .CO({velocity1_carry__0_i_10_n_0,velocity1_carry__0_i_10_n_1,velocity1_carry__0_i_10_n_2,velocity1_carry__0_i_10_n_3}),
        .CYINIT(1'b0),
        .DI(interim[11:8]),
        .O(velocity2[11:8]),
        .S({velocity1_carry__0_i_15_n_0,velocity1_carry__0_i_16_n_0,velocity1_carry__0_i_17_n_0,velocity1_carry__0_i_18_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_11
       (.I0(interim[15]),
        .I1(output_velocity[15]),
        .O(velocity1_carry__0_i_11_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_12
       (.I0(interim[14]),
        .I1(output_velocity[14]),
        .O(velocity1_carry__0_i_12_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_13
       (.I0(interim[13]),
        .I1(output_velocity[13]),
        .O(velocity1_carry__0_i_13_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_14
       (.I0(interim[12]),
        .I1(output_velocity[12]),
        .O(velocity1_carry__0_i_14_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_15
       (.I0(interim[11]),
        .I1(output_velocity[11]),
        .O(velocity1_carry__0_i_15_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_16
       (.I0(interim[10]),
        .I1(output_velocity[10]),
        .O(velocity1_carry__0_i_16_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_17
       (.I0(interim[9]),
        .I1(output_velocity[9]),
        .O(velocity1_carry__0_i_17_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__0_i_18
       (.I0(interim[8]),
        .I1(output_velocity[8]),
        .O(velocity1_carry__0_i_18_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__0_i_2
       (.I0(velocity2[12]),
        .I1(velocity2[13]),
        .O(velocity1_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__0_i_3
       (.I0(velocity2[10]),
        .I1(velocity2[11]),
        .O(velocity1_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__0_i_4
       (.I0(velocity2[8]),
        .I1(velocity2[9]),
        .O(velocity1_carry__0_i_4_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__0_i_5
       (.I0(velocity2[14]),
        .I1(velocity2[15]),
        .O(velocity1_carry__0_i_5_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__0_i_6
       (.I0(velocity2[12]),
        .I1(velocity2[13]),
        .O(velocity1_carry__0_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__0_i_7
       (.I0(velocity2[10]),
        .I1(velocity2[11]),
        .O(velocity1_carry__0_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__0_i_8
       (.I0(velocity2[8]),
        .I1(velocity2[9]),
        .O(velocity1_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry__0_i_9
       (.CI(velocity1_carry__0_i_10_n_0),
        .CO({velocity1_carry__0_i_9_n_0,velocity1_carry__0_i_9_n_1,velocity1_carry__0_i_9_n_2,velocity1_carry__0_i_9_n_3}),
        .CYINIT(1'b0),
        .DI(interim[15:12]),
        .O(velocity2[15:12]),
        .S({velocity1_carry__0_i_11_n_0,velocity1_carry__0_i_12_n_0,velocity1_carry__0_i_13_n_0,velocity1_carry__0_i_14_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 velocity1_carry__1
       (.CI(velocity1_carry__0_n_0),
        .CO({velocity1_carry__1_n_0,velocity1_carry__1_n_1,velocity1_carry__1_n_2,velocity1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({velocity1_carry__1_i_1_n_0,velocity1_carry__1_i_2_n_0,velocity1_carry__1_i_3_n_0,velocity1_carry__1_i_4_n_0}),
        .O(NLW_velocity1_carry__1_O_UNCONNECTED[3:0]),
        .S({velocity1_carry__1_i_5_n_0,velocity1_carry__1_i_6_n_0,velocity1_carry__1_i_7_n_0,velocity1_carry__1_i_8_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__1_i_1
       (.I0(velocity2[22]),
        .I1(velocity2[23]),
        .O(velocity1_carry__1_i_1_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry__1_i_10
       (.CI(velocity1_carry__0_i_9_n_0),
        .CO({velocity1_carry__1_i_10_n_0,velocity1_carry__1_i_10_n_1,velocity1_carry__1_i_10_n_2,velocity1_carry__1_i_10_n_3}),
        .CYINIT(1'b0),
        .DI(interim[19:16]),
        .O(velocity2[19:16]),
        .S({velocity1_carry__1_i_15_n_0,velocity1_carry__1_i_16_n_0,velocity1_carry__1_i_17_n_0,velocity1_carry__1_i_18_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_11
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__1_i_11_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_12
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__1_i_12_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_13
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__1_i_13_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_14
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__1_i_14_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_15
       (.I0(interim[19]),
        .I1(output_velocity[19]),
        .O(velocity1_carry__1_i_15_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_16
       (.I0(interim[18]),
        .I1(output_velocity[18]),
        .O(velocity1_carry__1_i_16_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_17
       (.I0(interim[17]),
        .I1(output_velocity[17]),
        .O(velocity1_carry__1_i_17_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__1_i_18
       (.I0(interim[16]),
        .I1(output_velocity[16]),
        .O(velocity1_carry__1_i_18_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__1_i_2
       (.I0(velocity2[20]),
        .I1(velocity2[21]),
        .O(velocity1_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__1_i_3
       (.I0(velocity2[18]),
        .I1(velocity2[19]),
        .O(velocity1_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__1_i_4
       (.I0(velocity2[16]),
        .I1(velocity2[17]),
        .O(velocity1_carry__1_i_4_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__1_i_5
       (.I0(velocity2[22]),
        .I1(velocity2[23]),
        .O(velocity1_carry__1_i_5_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__1_i_6
       (.I0(velocity2[20]),
        .I1(velocity2[21]),
        .O(velocity1_carry__1_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__1_i_7
       (.I0(velocity2[18]),
        .I1(velocity2[19]),
        .O(velocity1_carry__1_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__1_i_8
       (.I0(velocity2[16]),
        .I1(velocity2[17]),
        .O(velocity1_carry__1_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry__1_i_9
       (.CI(velocity1_carry__1_i_10_n_0),
        .CO({velocity1_carry__1_i_9_n_0,velocity1_carry__1_i_9_n_1,velocity1_carry__1_i_9_n_2,velocity1_carry__1_i_9_n_3}),
        .CYINIT(1'b0),
        .DI({interim[30],interim[30],interim[30],interim[30]}),
        .O(velocity2[23:20]),
        .S({velocity1_carry__1_i_11_n_0,velocity1_carry__1_i_12_n_0,velocity1_carry__1_i_13_n_0,velocity1_carry__1_i_14_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 velocity1_carry__2
       (.CI(velocity1_carry__1_n_0),
        .CO({velocity1_carry__2_n_0,velocity1_carry__2_n_1,velocity1_carry__2_n_2,velocity1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({velocity1_carry__2_i_1_n_0,velocity1_carry__2_i_2_n_0,velocity1_carry__2_i_3_n_0,velocity1_carry__2_i_4_n_0}),
        .O(NLW_velocity1_carry__2_O_UNCONNECTED[3:0]),
        .S({velocity1_carry__2_i_5_n_0,velocity1_carry__2_i_6_n_0,velocity1_carry__2_i_7_n_0,velocity1_carry__2_i_8_n_0}));
  LUT2 #(
    .INIT(4'h2)) 
    velocity1_carry__2_i_1
       (.I0(velocity2[30]),
        .I1(velocity2[31]),
        .O(velocity1_carry__2_i_1_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry__2_i_10
       (.CI(velocity1_carry__1_i_9_n_0),
        .CO({velocity1_carry__2_i_10_n_0,velocity1_carry__2_i_10_n_1,velocity1_carry__2_i_10_n_2,velocity1_carry__2_i_10_n_3}),
        .CYINIT(1'b0),
        .DI({interim[30],interim[30],interim[30],interim[30]}),
        .O(velocity2[27:24]),
        .S({velocity1_carry__2_i_15_n_0,velocity1_carry__2_i_16_n_0,velocity1_carry__2_i_17_n_0,velocity1_carry__2_i_18_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_11
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_11_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_12
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_12_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_13
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_13_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_14
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_14_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_15
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_15_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_16
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_16_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_17
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_17_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry__2_i_18
       (.I0(interim[30]),
        .I1(output_velocity[20]),
        .O(velocity1_carry__2_i_18_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__2_i_2
       (.I0(velocity2[28]),
        .I1(velocity2[29]),
        .O(velocity1_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__2_i_3
       (.I0(velocity2[26]),
        .I1(velocity2[27]),
        .O(velocity1_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry__2_i_4
       (.I0(velocity2[24]),
        .I1(velocity2[25]),
        .O(velocity1_carry__2_i_4_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__2_i_5
       (.I0(velocity2[30]),
        .I1(velocity2[31]),
        .O(velocity1_carry__2_i_5_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__2_i_6
       (.I0(velocity2[28]),
        .I1(velocity2[29]),
        .O(velocity1_carry__2_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__2_i_7
       (.I0(velocity2[26]),
        .I1(velocity2[27]),
        .O(velocity1_carry__2_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry__2_i_8
       (.I0(velocity2[24]),
        .I1(velocity2[25]),
        .O(velocity1_carry__2_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry__2_i_9
       (.CI(velocity1_carry__2_i_10_n_0),
        .CO({NLW_velocity1_carry__2_i_9_CO_UNCONNECTED[3],velocity1_carry__2_i_9_n_1,velocity1_carry__2_i_9_n_2,velocity1_carry__2_i_9_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,interim[30],interim[30],interim[30]}),
        .O(velocity2[31:28]),
        .S({velocity1_carry__2_i_11_n_0,velocity1_carry__2_i_12_n_0,velocity1_carry__2_i_13_n_0,velocity1_carry__2_i_14_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry_i_1
       (.I0(velocity2[6]),
        .I1(velocity2[7]),
        .O(velocity1_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_10
       (.I0(interim[7]),
        .I1(output_velocity[7]),
        .O(velocity1_carry_i_10_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_11
       (.I0(interim[6]),
        .I1(output_velocity[6]),
        .O(velocity1_carry_i_11_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_12
       (.I0(interim[5]),
        .I1(output_velocity[5]),
        .O(velocity1_carry_i_12_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_13
       (.I0(interim[4]),
        .I1(output_velocity[4]),
        .O(velocity1_carry_i_13_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_14
       (.I0(interim[3]),
        .I1(output_velocity[3]),
        .O(velocity1_carry_i_14_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_15
       (.I0(interim[2]),
        .I1(output_velocity[2]),
        .O(velocity1_carry_i_15_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_16
       (.I0(interim[1]),
        .I1(output_velocity[1]),
        .O(velocity1_carry_i_16_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    velocity1_carry_i_17
       (.I0(interim[0]),
        .I1(output_velocity[0]),
        .O(velocity1_carry_i_17_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry_i_2
       (.CI(velocity1_carry_i_9_n_0),
        .CO({velocity1_carry_i_2_n_0,velocity1_carry_i_2_n_1,velocity1_carry_i_2_n_2,velocity1_carry_i_2_n_3}),
        .CYINIT(1'b0),
        .DI(interim[7:4]),
        .O(velocity2[7:4]),
        .S({velocity1_carry_i_10_n_0,velocity1_carry_i_11_n_0,velocity1_carry_i_12_n_0,velocity1_carry_i_13_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry_i_3
       (.I0(velocity2[2]),
        .I1(velocity2[3]),
        .O(velocity1_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    velocity1_carry_i_4
       (.I0(velocity2[0]),
        .I1(velocity2[1]),
        .O(velocity1_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry_i_5
       (.I0(velocity2[6]),
        .I1(velocity2[7]),
        .O(velocity1_carry_i_5_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    velocity1_carry_i_6
       (.I0(velocity2[4]),
        .I1(velocity2[5]),
        .O(velocity1_carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry_i_7
       (.I0(velocity2[2]),
        .I1(velocity2[3]),
        .O(velocity1_carry_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    velocity1_carry_i_8
       (.I0(velocity2[0]),
        .I1(velocity2[1]),
        .O(velocity1_carry_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity1_carry_i_9
       (.CI(1'b0),
        .CO({velocity1_carry_i_9_n_0,velocity1_carry_i_9_n_1,velocity1_carry_i_9_n_2,velocity1_carry_i_9_n_3}),
        .CYINIT(1'b1),
        .DI(interim[3:0]),
        .O(velocity2[3:0]),
        .S({velocity1_carry_i_14_n_0,velocity1_carry_i_15_n_0,velocity1_carry_i_16_n_0,velocity1_carry_i_17_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \velocity1_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\velocity1_inferred__0/i__carry_n_0 ,\velocity1_inferred__0/i__carry_n_1 ,\velocity1_inferred__0/i__carry_n_2 ,\velocity1_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry_i_1_n_0,i__carry_i_2_n_6,i__carry_i_3_n_0,i__carry_i_4_n_0}),
        .O(\NLW_velocity1_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5__2_n_0,i__carry_i_6__2_n_0,i__carry_i_7__2_n_0,i__carry_i_8__2_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \velocity1_inferred__0/i__carry__0 
       (.CI(\velocity1_inferred__0/i__carry_n_0 ),
        .CO({\velocity1_inferred__0/i__carry__0_n_0 ,\velocity1_inferred__0/i__carry__0_n_1 ,\velocity1_inferred__0/i__carry__0_n_2 ,\velocity1_inferred__0/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry_i_1__0_n_0,i__carry_i_2__0_n_0,i__carry_i_3__0_n_0,i__carry_i_4__0_n_0}),
        .O(\NLW_velocity1_inferred__0/i__carry__0_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5__1_n_0,i__carry_i_6__1_n_0,i__carry_i_7__1_n_0,i__carry_i_8__1_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \velocity1_inferred__0/i__carry__1 
       (.CI(\velocity1_inferred__0/i__carry__0_n_0 ),
        .CO({\velocity1_inferred__0/i__carry__1_n_0 ,\velocity1_inferred__0/i__carry__1_n_1 ,\velocity1_inferred__0/i__carry__1_n_2 ,\velocity1_inferred__0/i__carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry_i_1__1_n_0,i__carry_i_2__1_n_0,i__carry_i_3__1_n_0,i__carry_i_4__1_n_0}),
        .O(\NLW_velocity1_inferred__0/i__carry__1_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5__0_n_0,i__carry_i_6__0_n_0,i__carry_i_7__0_n_0,i__carry_i_8__0_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \velocity1_inferred__0/i__carry__2 
       (.CI(\velocity1_inferred__0/i__carry__1_n_0 ),
        .CO({\velocity1_inferred__0/i__carry__2_n_0 ,\velocity1_inferred__0/i__carry__2_n_1 ,\velocity1_inferred__0/i__carry__2_n_2 ,\velocity1_inferred__0/i__carry__2_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry_i_1__2_n_0,i__carry_i_2__2_n_0,i__carry_i_3__2_n_0,i__carry_i_4__2_n_0}),
        .O(\NLW_velocity1_inferred__0/i__carry__2_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5_n_0,i__carry_i_6_n_0,i__carry_i_7_n_0,i__carry_i_8_n_0}));
  LUT2 #(
    .INIT(4'hE)) 
    \velocity[31]_i_1 
       (.I0(\velocity1_inferred__0/i__carry__2_n_0 ),
        .I1(velocity1_carry__2_n_0),
        .O(velocity0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[0] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[0]),
        .Q(output_velocity[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[10] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[10]),
        .Q(output_velocity[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[11] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[11]),
        .Q(output_velocity[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[12] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[12]),
        .Q(output_velocity[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[13] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[13]),
        .Q(output_velocity[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[14] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[14]),
        .Q(output_velocity[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[15] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[15]),
        .Q(output_velocity[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[16] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[16]),
        .Q(output_velocity[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[17] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[17]),
        .Q(output_velocity[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[18] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[18]),
        .Q(output_velocity[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[19] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[19]),
        .Q(output_velocity[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[1] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[1]),
        .Q(output_velocity[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[2] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[2]),
        .Q(output_velocity[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[31] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[30]),
        .Q(output_velocity[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[3] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[3]),
        .Q(output_velocity[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[4] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[4]),
        .Q(output_velocity[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[5] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[5]),
        .Q(output_velocity[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[6] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[6]),
        .Q(output_velocity[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[7] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[7]),
        .Q(output_velocity[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[8] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[8]),
        .Q(output_velocity[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[9] 
       (.C(clock),
        .CE(velocity0),
        .D(interim[9]),
        .Q(output_velocity[9]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
