# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: D:\Xilinx\Vitis\2021.1\Playground\MPU_6050\MPU_6050_On_ZyboZ7_20_system\_ide\scripts\systemdebugger_mpu_6050_on_zyboz7_20_system_standalone.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source D:\Xilinx\Vitis\2021.1\Playground\MPU_6050\MPU_6050_On_ZyboZ7_20_system\_ide\scripts\systemdebugger_mpu_6050_on_zyboz7_20_system_standalone.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Digilent Zybo Z7 210351B7B828A" && level==0 && jtag_device_ctx=="jsn-Zybo Z7-210351B7B828A-23727093-0"}
fpga -file D:/Xilinx/Vitis/2021.1/Playground/MPU_6050/MPU_6050_On_ZyboZ7_20/_ide/bitstream/MPU_6050_Test_On_ZyboZ7_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw D:/Xilinx/Vitis/2021.1/Playground/MPU_6050/MPU_6050_Test_On_ZyboZ7_wrapper/export/MPU_6050_Test_On_ZyboZ7_wrapper/hw/MPU_6050_Test_On_ZyboZ7_wrapper.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source D:/Xilinx/Vitis/2021.1/Playground/MPU_6050/MPU_6050_On_ZyboZ7_20/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow D:/Xilinx/Vitis/2021.1/Playground/MPU_6050/MPU_6050_On_ZyboZ7_20/Debug/MPU_6050_On_ZyboZ7_20.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
