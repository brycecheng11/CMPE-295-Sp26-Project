-= SD card boot image =-

Platform: MPU_6050_Test_On_ZyboZ7_wrapper
Application: MPU_6050_Test_On_ZyboZ7_wrapper

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
3. Insert SD card and turn board on
