# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct D:\Xilinx\Vitis\2021.1\Playground\MPU_6050\MPU_6050_Test_On_ZyboZ7_wrapper\platform.tcl
# 
# OR launch xsct and run below command.
# source D:\Xilinx\Vitis\2021.1\Playground\MPU_6050\MPU_6050_Test_On_ZyboZ7_wrapper\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {MPU_6050_Test_On_ZyboZ7_wrapper}\
-hw {D:\Xilinx\workspace_2021_1\MPU_6050_Test_On_ZyboZ7\MPU_6050_Test_On_ZyboZ7_wrapper.xsa}\
-out {D:/Xilinx/Vitis/2021.1/Playground/MPU_6050}

platform write
domain create -name {standalone_ps7_cortexa9_0} -display-name {standalone_ps7_cortexa9_0} -os {standalone} -proc {ps7_cortexa9_0} -runtime {cpp} -arch {32-bit} -support-app {empty_application}
platform generate -domains 
platform active {MPU_6050_Test_On_ZyboZ7_wrapper}
domain active {zynq_fsbl}
domain active {standalone_ps7_cortexa9_0}
platform generate -quick
platform generate
platform generate
