`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 07:53:54 PM
// Design Name: 
// Module Name: pid_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pid_tb;

    // Testbench Inputs (Registers) matching design_1 ports
    reg [31:0] angle_0;
    reg [11:0] kd_0;
    reg [11:0] ki_0;
    reg [11:0] kp_0;
    reg [0:0]  new_target_angle_available_0;
    reg        sys_clock;
    reg [31:0] target_angle_0;

    // Testbench Outputs (Wires)
    wire [31:0] output_velocity_0;
    wire  [0:0] new_velocity_available_0;

    // Instantiate the Unit Under Test (UUT)
    pid_compressed uut (
        .angle_0(angle_0),
        .kd_in_0(kd_0),
        .ki_in_0(ki_0),
        .kp_in_0(kp_0),
        .new_target_angle_available_0(new_target_angle_available_0),
        .new_velocity_available_0(new_velocity_available_0),
        .output_velocity_0(output_velocity_0),
        .sys_clk(sys_clock),
        .target_angle_0(target_angle_0)
    );

    // Clock Generation for 125 MHz (Period = 8000 ps = 8 ns)
    always #4000 sys_clock = ~sys_clock;

    // Stimulus Sequence
    initial begin
        // Initialize Signals
        sys_clock = 0;
        angle_0 = 32'd0;
        target_angle_0 = 32'd0;
        kp_0 = 12'h100; 
        ki_0 = 12'h10; 
        kd_0 = 12'h25; 


        @(posedge sys_clock);
        target_angle_0 = 32'sd90; // Target: 90 degrees
        new_target_angle_available_0 = 1'b1;
        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b0;

        repeat (15) begin
            #50000; 
            if (angle_0 < target_angle_0)
                angle_0 = angle_0 + 32'sd5;
        end

        @(posedge sys_clock);
        target_angle_0 = 32'sd30; 
        new_target_angle_available_0 = 1'b1;
        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b0;

        repeat (15) begin
            #10000;
            if (angle_0 > target_angle_0)
                angle_0 = angle_0 - 32'sd4;
        end

        // Finish simulation
        #100000;
        $finish;
    end


endmodule
