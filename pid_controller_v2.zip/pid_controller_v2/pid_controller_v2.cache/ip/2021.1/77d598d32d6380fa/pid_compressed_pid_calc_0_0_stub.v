// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Tue Oct  6 02:30:43 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_compressed_pid_calc_0_0_stub.v
// Design      : pid_compressed_pid_calc_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "pid_calc,Vivado 2021.1" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clock, angle, target_angle, 
  new_target_angle_available, kp, ki, kd, output_velocity, new_velocity_available)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],angle[31:0],target_angle[31:0],new_target_angle_available[0:0],kp[8:0],ki[8:0],kd[8:0],output_velocity[31:0],new_velocity_available[0:0]" */;
  input [0:0]clock;
  input [31:0]angle;
  input [31:0]target_angle;
  input [0:0]new_target_angle_available;
  input [8:0]kp;
  input [8:0]ki;
  input [8:0]kd;
  output [31:0]output_velocity;
  output [0:0]new_velocity_available;
endmodule
