-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Tue Oct  6 02:30:43 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_compressed_pid_calc_0_0_stub.vhdl
-- Design      : pid_compressed_pid_calc_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    target_angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    new_target_angle_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 )
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock[0:0],angle[31:0],target_angle[31:0],new_target_angle_available[0:0],kp[8:0],ki[8:0],kd[8:0],output_velocity[31:0],new_velocity_available[0:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "pid_calc,Vivado 2021.1";
begin
end;
