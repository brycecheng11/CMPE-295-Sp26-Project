-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Tue Oct  6 02:30:43 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_compressed_pid_calc_0_0_sim_netlist.vhdl
-- Design      : pid_compressed_pid_calc_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pid_calc is
  port (
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 );
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    new_target_angle_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    target_angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pid_calc;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pid_calc is
  signal d_term0_n_100 : STD_LOGIC;
  signal d_term0_n_101 : STD_LOGIC;
  signal d_term0_n_102 : STD_LOGIC;
  signal d_term0_n_103 : STD_LOGIC;
  signal d_term0_n_104 : STD_LOGIC;
  signal d_term0_n_105 : STD_LOGIC;
  signal d_term0_n_106 : STD_LOGIC;
  signal d_term0_n_107 : STD_LOGIC;
  signal d_term0_n_108 : STD_LOGIC;
  signal d_term0_n_109 : STD_LOGIC;
  signal d_term0_n_110 : STD_LOGIC;
  signal d_term0_n_111 : STD_LOGIC;
  signal d_term0_n_112 : STD_LOGIC;
  signal d_term0_n_113 : STD_LOGIC;
  signal d_term0_n_114 : STD_LOGIC;
  signal d_term0_n_115 : STD_LOGIC;
  signal d_term0_n_116 : STD_LOGIC;
  signal d_term0_n_117 : STD_LOGIC;
  signal d_term0_n_118 : STD_LOGIC;
  signal d_term0_n_119 : STD_LOGIC;
  signal d_term0_n_120 : STD_LOGIC;
  signal d_term0_n_121 : STD_LOGIC;
  signal d_term0_n_122 : STD_LOGIC;
  signal d_term0_n_123 : STD_LOGIC;
  signal d_term0_n_124 : STD_LOGIC;
  signal d_term0_n_125 : STD_LOGIC;
  signal d_term0_n_126 : STD_LOGIC;
  signal d_term0_n_127 : STD_LOGIC;
  signal d_term0_n_128 : STD_LOGIC;
  signal d_term0_n_129 : STD_LOGIC;
  signal d_term0_n_130 : STD_LOGIC;
  signal d_term0_n_131 : STD_LOGIC;
  signal d_term0_n_132 : STD_LOGIC;
  signal d_term0_n_133 : STD_LOGIC;
  signal d_term0_n_134 : STD_LOGIC;
  signal d_term0_n_135 : STD_LOGIC;
  signal d_term0_n_136 : STD_LOGIC;
  signal d_term0_n_137 : STD_LOGIC;
  signal d_term0_n_138 : STD_LOGIC;
  signal d_term0_n_139 : STD_LOGIC;
  signal d_term0_n_140 : STD_LOGIC;
  signal d_term0_n_141 : STD_LOGIC;
  signal d_term0_n_142 : STD_LOGIC;
  signal d_term0_n_143 : STD_LOGIC;
  signal d_term0_n_144 : STD_LOGIC;
  signal d_term0_n_145 : STD_LOGIC;
  signal d_term0_n_146 : STD_LOGIC;
  signal d_term0_n_147 : STD_LOGIC;
  signal d_term0_n_148 : STD_LOGIC;
  signal d_term0_n_149 : STD_LOGIC;
  signal d_term0_n_150 : STD_LOGIC;
  signal d_term0_n_151 : STD_LOGIC;
  signal d_term0_n_152 : STD_LOGIC;
  signal d_term0_n_153 : STD_LOGIC;
  signal d_term0_n_58 : STD_LOGIC;
  signal d_term0_n_59 : STD_LOGIC;
  signal d_term0_n_60 : STD_LOGIC;
  signal d_term0_n_61 : STD_LOGIC;
  signal d_term0_n_62 : STD_LOGIC;
  signal d_term0_n_63 : STD_LOGIC;
  signal d_term0_n_64 : STD_LOGIC;
  signal d_term0_n_65 : STD_LOGIC;
  signal d_term0_n_66 : STD_LOGIC;
  signal d_term0_n_67 : STD_LOGIC;
  signal d_term0_n_68 : STD_LOGIC;
  signal d_term0_n_69 : STD_LOGIC;
  signal d_term0_n_70 : STD_LOGIC;
  signal d_term0_n_71 : STD_LOGIC;
  signal d_term0_n_72 : STD_LOGIC;
  signal d_term0_n_73 : STD_LOGIC;
  signal d_term0_n_74 : STD_LOGIC;
  signal d_term0_n_75 : STD_LOGIC;
  signal d_term0_n_76 : STD_LOGIC;
  signal d_term0_n_77 : STD_LOGIC;
  signal d_term0_n_78 : STD_LOGIC;
  signal d_term0_n_79 : STD_LOGIC;
  signal d_term0_n_80 : STD_LOGIC;
  signal d_term0_n_81 : STD_LOGIC;
  signal d_term0_n_82 : STD_LOGIC;
  signal d_term0_n_83 : STD_LOGIC;
  signal d_term0_n_84 : STD_LOGIC;
  signal d_term0_n_85 : STD_LOGIC;
  signal d_term0_n_86 : STD_LOGIC;
  signal d_term0_n_87 : STD_LOGIC;
  signal d_term0_n_88 : STD_LOGIC;
  signal d_term0_n_89 : STD_LOGIC;
  signal d_term0_n_90 : STD_LOGIC;
  signal d_term0_n_91 : STD_LOGIC;
  signal d_term0_n_92 : STD_LOGIC;
  signal d_term0_n_93 : STD_LOGIC;
  signal d_term0_n_94 : STD_LOGIC;
  signal d_term0_n_95 : STD_LOGIC;
  signal d_term0_n_96 : STD_LOGIC;
  signal d_term0_n_97 : STD_LOGIC;
  signal d_term0_n_98 : STD_LOGIC;
  signal d_term0_n_99 : STD_LOGIC;
  signal \^d_term_reg\ : STD_LOGIC_VECTOR ( 40 downto 0 );
  signal d_term_reg_n_58 : STD_LOGIC;
  signal d_term_reg_n_59 : STD_LOGIC;
  signal d_term_reg_n_60 : STD_LOGIC;
  signal d_term_reg_n_61 : STD_LOGIC;
  signal d_term_reg_n_62 : STD_LOGIC;
  signal d_term_reg_n_63 : STD_LOGIC;
  signal d_term_reg_n_64 : STD_LOGIC;
  signal d_term_reg_n_65 : STD_LOGIC;
  signal d_term_reg_n_66 : STD_LOGIC;
  signal d_term_reg_n_67 : STD_LOGIC;
  signal d_term_reg_n_68 : STD_LOGIC;
  signal d_term_reg_n_69 : STD_LOGIC;
  signal d_term_reg_n_70 : STD_LOGIC;
  signal d_term_reg_n_71 : STD_LOGIC;
  signal d_term_reg_n_72 : STD_LOGIC;
  signal d_term_reg_n_73 : STD_LOGIC;
  signal d_term_reg_n_74 : STD_LOGIC;
  signal d_term_reg_n_75 : STD_LOGIC;
  signal d_term_reg_n_76 : STD_LOGIC;
  signal d_term_reg_n_77 : STD_LOGIC;
  signal d_term_reg_n_78 : STD_LOGIC;
  signal d_term_reg_n_79 : STD_LOGIC;
  signal d_term_reg_n_80 : STD_LOGIC;
  signal d_term_reg_n_81 : STD_LOGIC;
  signal \derivative0__0_carry__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry__0_n_1\ : STD_LOGIC;
  signal \derivative0__0_carry__0_n_2\ : STD_LOGIC;
  signal \derivative0__0_carry__0_n_3\ : STD_LOGIC;
  signal \derivative0__0_carry__0_n_4\ : STD_LOGIC;
  signal \derivative0__0_carry__0_n_5\ : STD_LOGIC;
  signal \derivative0__0_carry__0_n_6\ : STD_LOGIC;
  signal \derivative0__0_carry__0_n_7\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_1\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_2\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_3\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_4\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_5\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_6\ : STD_LOGIC;
  signal \derivative0__0_carry__1_n_7\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_1\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_2\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_3\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_4\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_5\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_6\ : STD_LOGIC;
  signal \derivative0__0_carry__2_n_7\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_1\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_2\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_3\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_4\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_5\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_6\ : STD_LOGIC;
  signal \derivative0__0_carry__3_n_7\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_1\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_2\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_3\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_4\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_5\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_6\ : STD_LOGIC;
  signal \derivative0__0_carry__4_n_7\ : STD_LOGIC;
  signal \derivative0__0_carry__5_n_1\ : STD_LOGIC;
  signal \derivative0__0_carry__5_n_2\ : STD_LOGIC;
  signal \derivative0__0_carry__5_n_3\ : STD_LOGIC;
  signal \derivative0__0_carry__5_n_4\ : STD_LOGIC;
  signal \derivative0__0_carry__5_n_5\ : STD_LOGIC;
  signal \derivative0__0_carry__5_n_6\ : STD_LOGIC;
  signal \derivative0__0_carry__5_n_7\ : STD_LOGIC;
  signal \derivative0__0_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_1__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_1__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_1__5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_2__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_2__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_2__5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_3__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_3__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_3__5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_4__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_4__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_4__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_4__5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_5__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_5__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_5__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_5__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_5__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_5__5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_6__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_6__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_6__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_6__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_6__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_6__5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_6_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_7__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_7__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_7__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_7__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_7__4_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_7__5_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_7_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_8__0_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_8__1_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_8__2_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_8__3_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_i_8_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_n_0\ : STD_LOGIC;
  signal \derivative0__0_carry_n_1\ : STD_LOGIC;
  signal \derivative0__0_carry_n_2\ : STD_LOGIC;
  signal \derivative0__0_carry_n_3\ : STD_LOGIC;
  signal \derivative0__0_carry_n_4\ : STD_LOGIC;
  signal \derivative0__0_carry_n_5\ : STD_LOGIC;
  signal \derivative0__0_carry_n_6\ : STD_LOGIC;
  signal \derivative0__0_carry_n_7\ : STD_LOGIC;
  signal derivative1 : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \derivative1__0\ : STD_LOGIC_VECTOR ( 30 downto 3 );
  signal \derivative1_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__0_n_0\ : STD_LOGIC;
  signal \derivative1_carry__0_n_1\ : STD_LOGIC;
  signal \derivative1_carry__0_n_2\ : STD_LOGIC;
  signal \derivative1_carry__0_n_3\ : STD_LOGIC;
  signal \derivative1_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__1_n_1\ : STD_LOGIC;
  signal \derivative1_carry__1_n_2\ : STD_LOGIC;
  signal \derivative1_carry__1_n_3\ : STD_LOGIC;
  signal \derivative1_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__2_n_1\ : STD_LOGIC;
  signal \derivative1_carry__2_n_2\ : STD_LOGIC;
  signal \derivative1_carry__2_n_3\ : STD_LOGIC;
  signal \derivative1_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__3_n_1\ : STD_LOGIC;
  signal \derivative1_carry__3_n_2\ : STD_LOGIC;
  signal \derivative1_carry__3_n_3\ : STD_LOGIC;
  signal \derivative1_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__4_n_1\ : STD_LOGIC;
  signal \derivative1_carry__4_n_2\ : STD_LOGIC;
  signal \derivative1_carry__4_n_3\ : STD_LOGIC;
  signal \derivative1_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \derivative1_carry__5_n_0\ : STD_LOGIC;
  signal \derivative1_carry__5_n_1\ : STD_LOGIC;
  signal \derivative1_carry__5_n_2\ : STD_LOGIC;
  signal \derivative1_carry__5_n_3\ : STD_LOGIC;
  signal \derivative1_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \derivative1_carry__6_i_2_n_0\ : STD_LOGIC;
  signal \derivative1_carry__6_i_3_n_0\ : STD_LOGIC;
  signal \derivative1_carry__6_n_2\ : STD_LOGIC;
  signal \derivative1_carry__6_n_3\ : STD_LOGIC;
  signal derivative1_carry_i_1_n_0 : STD_LOGIC;
  signal derivative1_carry_i_2_n_0 : STD_LOGIC;
  signal derivative1_carry_i_3_n_0 : STD_LOGIC;
  signal derivative1_carry_i_4_n_0 : STD_LOGIC;
  signal derivative1_carry_n_0 : STD_LOGIC;
  signal derivative1_carry_n_1 : STD_LOGIC;
  signal derivative1_carry_n_2 : STD_LOGIC;
  signal derivative1_carry_n_3 : STD_LOGIC;
  signal error : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal error0 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \error0_carry__0_n_0\ : STD_LOGIC;
  signal \error0_carry__0_n_1\ : STD_LOGIC;
  signal \error0_carry__0_n_2\ : STD_LOGIC;
  signal \error0_carry__0_n_3\ : STD_LOGIC;
  signal \error0_carry__1_n_0\ : STD_LOGIC;
  signal \error0_carry__1_n_1\ : STD_LOGIC;
  signal \error0_carry__1_n_2\ : STD_LOGIC;
  signal \error0_carry__1_n_3\ : STD_LOGIC;
  signal \error0_carry__2_n_0\ : STD_LOGIC;
  signal \error0_carry__2_n_1\ : STD_LOGIC;
  signal \error0_carry__2_n_2\ : STD_LOGIC;
  signal \error0_carry__2_n_3\ : STD_LOGIC;
  signal \error0_carry__3_n_0\ : STD_LOGIC;
  signal \error0_carry__3_n_1\ : STD_LOGIC;
  signal \error0_carry__3_n_2\ : STD_LOGIC;
  signal \error0_carry__3_n_3\ : STD_LOGIC;
  signal \error0_carry__4_n_0\ : STD_LOGIC;
  signal \error0_carry__4_n_1\ : STD_LOGIC;
  signal \error0_carry__4_n_2\ : STD_LOGIC;
  signal \error0_carry__4_n_3\ : STD_LOGIC;
  signal \error0_carry__5_n_0\ : STD_LOGIC;
  signal \error0_carry__5_n_1\ : STD_LOGIC;
  signal \error0_carry__5_n_2\ : STD_LOGIC;
  signal \error0_carry__5_n_3\ : STD_LOGIC;
  signal \error0_carry__6_n_1\ : STD_LOGIC;
  signal \error0_carry__6_n_2\ : STD_LOGIC;
  signal \error0_carry__6_n_3\ : STD_LOGIC;
  signal \error0_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_1__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_1_n_0 : STD_LOGIC;
  signal \error0_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_2__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_2_n_0 : STD_LOGIC;
  signal \error0_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_3__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_3_n_0 : STD_LOGIC;
  signal \error0_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__2_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__3_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__4_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__5_n_0\ : STD_LOGIC;
  signal \error0_carry_i_4__6_n_0\ : STD_LOGIC;
  signal error0_carry_i_4_n_0 : STD_LOGIC;
  signal error0_carry_n_0 : STD_LOGIC;
  signal error0_carry_n_1 : STD_LOGIC;
  signal error0_carry_n_2 : STD_LOGIC;
  signal error0_carry_n_3 : STD_LOGIC;
  signal error_prev : STD_LOGIC_VECTOR ( 30 downto 0 );
  signal \i__carry_i_10__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_10__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_10_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_11__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_11_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_12__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_12_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_13__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_13_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_14__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_14_n_0\ : STD_LOGIC;
  signal \i__carry_i_15_n_0\ : STD_LOGIC;
  signal \i__carry_i_16_n_0\ : STD_LOGIC;
  signal \i__carry_i_17_n_0\ : STD_LOGIC;
  signal \i__carry_i_18_n_0\ : STD_LOGIC;
  signal \i__carry_i_19_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_1__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_20_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_3__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_4__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_4_n_3\ : STD_LOGIC;
  signal \i__carry_i_4_n_6\ : STD_LOGIC;
  signal \i__carry_i_4_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_1\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_2\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_3\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_4\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_5\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_6\ : STD_LOGIC;
  signal \i__carry_i_5__0_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_1\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_2\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_3\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_4\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_5\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_6\ : STD_LOGIC;
  signal \i__carry_i_5__1_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_1\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_2\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_3\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_4\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_5\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_6\ : STD_LOGIC;
  signal \i__carry_i_5__2_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_1\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_2\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_3\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_4\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_5\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_6\ : STD_LOGIC;
  signal \i__carry_i_5__3_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_1\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_2\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_3\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_4\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_5\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_6\ : STD_LOGIC;
  signal \i__carry_i_5__4_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_1\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_2\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_3\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_4\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_5\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_6\ : STD_LOGIC;
  signal \i__carry_i_5__5_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_1\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_2\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_3\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_4\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_5\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_6\ : STD_LOGIC;
  signal \i__carry_i_5__6_n_7\ : STD_LOGIC;
  signal \i__carry_i_5__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_5_n_0\ : STD_LOGIC;
  signal \i__carry_i_5_n_1\ : STD_LOGIC;
  signal \i__carry_i_5_n_2\ : STD_LOGIC;
  signal \i__carry_i_5_n_3\ : STD_LOGIC;
  signal \i__carry_i_5_n_4\ : STD_LOGIC;
  signal \i__carry_i_5_n_5\ : STD_LOGIC;
  signal \i__carry_i_5_n_6\ : STD_LOGIC;
  signal \i__carry_i_5_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_1\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_2\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_3\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_4\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_5\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_6\ : STD_LOGIC;
  signal \i__carry_i_6__0_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_1\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_2\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_3\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_4\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_5\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_6\ : STD_LOGIC;
  signal \i__carry_i_6__1_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_1\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_2\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_3\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_4\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_5\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_6\ : STD_LOGIC;
  signal \i__carry_i_6__2_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_1\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_2\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_3\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_4\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_5\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_6\ : STD_LOGIC;
  signal \i__carry_i_6__3_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_1\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_2\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_3\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_4\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_5\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_6\ : STD_LOGIC;
  signal \i__carry_i_6__4_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_1\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_2\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_3\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_4\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_5\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_6\ : STD_LOGIC;
  signal \i__carry_i_6__5_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_1\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_2\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_3\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_4\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_5\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_6\ : STD_LOGIC;
  signal \i__carry_i_6__6_n_7\ : STD_LOGIC;
  signal \i__carry_i_6__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_1\ : STD_LOGIC;
  signal \i__carry_i_6_n_2\ : STD_LOGIC;
  signal \i__carry_i_6_n_3\ : STD_LOGIC;
  signal \i__carry_i_6_n_4\ : STD_LOGIC;
  signal \i__carry_i_6_n_5\ : STD_LOGIC;
  signal \i__carry_i_6_n_6\ : STD_LOGIC;
  signal \i__carry_i_6_n_7\ : STD_LOGIC;
  signal \i__carry_i_7__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_7__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_1\ : STD_LOGIC;
  signal \i__carry_i_7_n_2\ : STD_LOGIC;
  signal \i__carry_i_7_n_3\ : STD_LOGIC;
  signal \i__carry_i_7_n_4\ : STD_LOGIC;
  signal \i__carry_i_7_n_5\ : STD_LOGIC;
  signal \i__carry_i_7_n_6\ : STD_LOGIC;
  signal \i__carry_i_7_n_7\ : STD_LOGIC;
  signal \i__carry_i_8__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_8__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_1\ : STD_LOGIC;
  signal \i__carry_i_8_n_2\ : STD_LOGIC;
  signal \i__carry_i_8_n_3\ : STD_LOGIC;
  signal \i__carry_i_9__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__1_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__2_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__3_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__4_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__5_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__6_n_0\ : STD_LOGIC;
  signal \i__carry_i_9__7_n_0\ : STD_LOGIC;
  signal \i__carry_i_9_n_0\ : STD_LOGIC;
  signal i_term0_n_100 : STD_LOGIC;
  signal i_term0_n_101 : STD_LOGIC;
  signal i_term0_n_102 : STD_LOGIC;
  signal i_term0_n_103 : STD_LOGIC;
  signal i_term0_n_104 : STD_LOGIC;
  signal i_term0_n_105 : STD_LOGIC;
  signal i_term0_n_106 : STD_LOGIC;
  signal i_term0_n_107 : STD_LOGIC;
  signal i_term0_n_108 : STD_LOGIC;
  signal i_term0_n_109 : STD_LOGIC;
  signal i_term0_n_110 : STD_LOGIC;
  signal i_term0_n_111 : STD_LOGIC;
  signal i_term0_n_112 : STD_LOGIC;
  signal i_term0_n_113 : STD_LOGIC;
  signal i_term0_n_114 : STD_LOGIC;
  signal i_term0_n_115 : STD_LOGIC;
  signal i_term0_n_116 : STD_LOGIC;
  signal i_term0_n_117 : STD_LOGIC;
  signal i_term0_n_118 : STD_LOGIC;
  signal i_term0_n_119 : STD_LOGIC;
  signal i_term0_n_120 : STD_LOGIC;
  signal i_term0_n_121 : STD_LOGIC;
  signal i_term0_n_122 : STD_LOGIC;
  signal i_term0_n_123 : STD_LOGIC;
  signal i_term0_n_124 : STD_LOGIC;
  signal i_term0_n_125 : STD_LOGIC;
  signal i_term0_n_126 : STD_LOGIC;
  signal i_term0_n_127 : STD_LOGIC;
  signal i_term0_n_128 : STD_LOGIC;
  signal i_term0_n_129 : STD_LOGIC;
  signal i_term0_n_130 : STD_LOGIC;
  signal i_term0_n_131 : STD_LOGIC;
  signal i_term0_n_132 : STD_LOGIC;
  signal i_term0_n_133 : STD_LOGIC;
  signal i_term0_n_134 : STD_LOGIC;
  signal i_term0_n_135 : STD_LOGIC;
  signal i_term0_n_136 : STD_LOGIC;
  signal i_term0_n_137 : STD_LOGIC;
  signal i_term0_n_138 : STD_LOGIC;
  signal i_term0_n_139 : STD_LOGIC;
  signal i_term0_n_140 : STD_LOGIC;
  signal i_term0_n_141 : STD_LOGIC;
  signal i_term0_n_142 : STD_LOGIC;
  signal i_term0_n_143 : STD_LOGIC;
  signal i_term0_n_144 : STD_LOGIC;
  signal i_term0_n_145 : STD_LOGIC;
  signal i_term0_n_146 : STD_LOGIC;
  signal i_term0_n_147 : STD_LOGIC;
  signal i_term0_n_148 : STD_LOGIC;
  signal i_term0_n_149 : STD_LOGIC;
  signal i_term0_n_150 : STD_LOGIC;
  signal i_term0_n_151 : STD_LOGIC;
  signal i_term0_n_152 : STD_LOGIC;
  signal i_term0_n_153 : STD_LOGIC;
  signal i_term0_n_58 : STD_LOGIC;
  signal i_term0_n_59 : STD_LOGIC;
  signal i_term0_n_60 : STD_LOGIC;
  signal i_term0_n_61 : STD_LOGIC;
  signal i_term0_n_62 : STD_LOGIC;
  signal i_term0_n_63 : STD_LOGIC;
  signal i_term0_n_64 : STD_LOGIC;
  signal i_term0_n_65 : STD_LOGIC;
  signal i_term0_n_66 : STD_LOGIC;
  signal i_term0_n_67 : STD_LOGIC;
  signal i_term0_n_68 : STD_LOGIC;
  signal i_term0_n_69 : STD_LOGIC;
  signal i_term0_n_70 : STD_LOGIC;
  signal i_term0_n_71 : STD_LOGIC;
  signal i_term0_n_72 : STD_LOGIC;
  signal i_term0_n_73 : STD_LOGIC;
  signal i_term0_n_74 : STD_LOGIC;
  signal i_term0_n_75 : STD_LOGIC;
  signal i_term0_n_76 : STD_LOGIC;
  signal i_term0_n_77 : STD_LOGIC;
  signal i_term0_n_78 : STD_LOGIC;
  signal i_term0_n_79 : STD_LOGIC;
  signal i_term0_n_80 : STD_LOGIC;
  signal i_term0_n_81 : STD_LOGIC;
  signal i_term0_n_82 : STD_LOGIC;
  signal i_term0_n_83 : STD_LOGIC;
  signal i_term0_n_84 : STD_LOGIC;
  signal i_term0_n_85 : STD_LOGIC;
  signal i_term0_n_86 : STD_LOGIC;
  signal i_term0_n_87 : STD_LOGIC;
  signal i_term0_n_88 : STD_LOGIC;
  signal i_term0_n_89 : STD_LOGIC;
  signal i_term0_n_90 : STD_LOGIC;
  signal i_term0_n_91 : STD_LOGIC;
  signal i_term0_n_92 : STD_LOGIC;
  signal i_term0_n_93 : STD_LOGIC;
  signal i_term0_n_94 : STD_LOGIC;
  signal i_term0_n_95 : STD_LOGIC;
  signal i_term0_n_96 : STD_LOGIC;
  signal i_term0_n_97 : STD_LOGIC;
  signal i_term0_n_98 : STD_LOGIC;
  signal i_term0_n_99 : STD_LOGIC;
  signal \^i_term_reg\ : STD_LOGIC_VECTOR ( 40 downto 0 );
  signal i_term_reg_n_58 : STD_LOGIC;
  signal i_term_reg_n_59 : STD_LOGIC;
  signal i_term_reg_n_60 : STD_LOGIC;
  signal i_term_reg_n_61 : STD_LOGIC;
  signal i_term_reg_n_62 : STD_LOGIC;
  signal i_term_reg_n_63 : STD_LOGIC;
  signal i_term_reg_n_64 : STD_LOGIC;
  signal i_term_reg_n_65 : STD_LOGIC;
  signal i_term_reg_n_66 : STD_LOGIC;
  signal i_term_reg_n_67 : STD_LOGIC;
  signal i_term_reg_n_68 : STD_LOGIC;
  signal i_term_reg_n_69 : STD_LOGIC;
  signal i_term_reg_n_70 : STD_LOGIC;
  signal i_term_reg_n_71 : STD_LOGIC;
  signal i_term_reg_n_72 : STD_LOGIC;
  signal i_term_reg_n_73 : STD_LOGIC;
  signal i_term_reg_n_74 : STD_LOGIC;
  signal i_term_reg_n_75 : STD_LOGIC;
  signal i_term_reg_n_76 : STD_LOGIC;
  signal i_term_reg_n_77 : STD_LOGIC;
  signal i_term_reg_n_78 : STD_LOGIC;
  signal i_term_reg_n_79 : STD_LOGIC;
  signal i_term_reg_n_80 : STD_LOGIC;
  signal i_term_reg_n_81 : STD_LOGIC;
  signal integral : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \integral[11]_i_10_n_0\ : STD_LOGIC;
  signal \integral[11]_i_11_n_0\ : STD_LOGIC;
  signal \integral[11]_i_12_n_0\ : STD_LOGIC;
  signal \integral[11]_i_13_n_0\ : STD_LOGIC;
  signal \integral[11]_i_14_n_0\ : STD_LOGIC;
  signal \integral[11]_i_15_n_0\ : STD_LOGIC;
  signal \integral[11]_i_19_n_0\ : STD_LOGIC;
  signal \integral[11]_i_20_n_0\ : STD_LOGIC;
  signal \integral[11]_i_21_n_0\ : STD_LOGIC;
  signal \integral[11]_i_22_n_0\ : STD_LOGIC;
  signal \integral[11]_i_23_n_0\ : STD_LOGIC;
  signal \integral[11]_i_24_n_0\ : STD_LOGIC;
  signal \integral[11]_i_25_n_0\ : STD_LOGIC;
  signal \integral[11]_i_26_n_0\ : STD_LOGIC;
  signal \integral[11]_i_27_n_0\ : STD_LOGIC;
  signal \integral[11]_i_28_n_0\ : STD_LOGIC;
  signal \integral[11]_i_29_n_0\ : STD_LOGIC;
  signal \integral[11]_i_2_n_0\ : STD_LOGIC;
  signal \integral[11]_i_30_n_0\ : STD_LOGIC;
  signal \integral[11]_i_31_n_0\ : STD_LOGIC;
  signal \integral[11]_i_32_n_0\ : STD_LOGIC;
  signal \integral[11]_i_33_n_0\ : STD_LOGIC;
  signal \integral[11]_i_34_n_0\ : STD_LOGIC;
  signal \integral[11]_i_35_n_0\ : STD_LOGIC;
  signal \integral[11]_i_36_n_0\ : STD_LOGIC;
  signal \integral[11]_i_37_n_0\ : STD_LOGIC;
  signal \integral[11]_i_38_n_0\ : STD_LOGIC;
  signal \integral[11]_i_39_n_0\ : STD_LOGIC;
  signal \integral[11]_i_3_n_0\ : STD_LOGIC;
  signal \integral[11]_i_40_n_0\ : STD_LOGIC;
  signal \integral[11]_i_41_n_0\ : STD_LOGIC;
  signal \integral[11]_i_42_n_0\ : STD_LOGIC;
  signal \integral[11]_i_45_n_0\ : STD_LOGIC;
  signal \integral[11]_i_46_n_0\ : STD_LOGIC;
  signal \integral[11]_i_47_n_0\ : STD_LOGIC;
  signal \integral[11]_i_48_n_0\ : STD_LOGIC;
  signal \integral[11]_i_49_n_0\ : STD_LOGIC;
  signal \integral[11]_i_4_n_0\ : STD_LOGIC;
  signal \integral[11]_i_50_n_0\ : STD_LOGIC;
  signal \integral[11]_i_51_n_0\ : STD_LOGIC;
  signal \integral[11]_i_5_n_0\ : STD_LOGIC;
  signal \integral[11]_i_8_n_0\ : STD_LOGIC;
  signal \integral[11]_i_9_n_0\ : STD_LOGIC;
  signal \integral[15]_i_10_n_0\ : STD_LOGIC;
  signal \integral[15]_i_11_n_0\ : STD_LOGIC;
  signal \integral[15]_i_12_n_0\ : STD_LOGIC;
  signal \integral[15]_i_13_n_0\ : STD_LOGIC;
  signal \integral[15]_i_14_n_0\ : STD_LOGIC;
  signal \integral[15]_i_15_n_0\ : STD_LOGIC;
  signal \integral[15]_i_19_n_0\ : STD_LOGIC;
  signal \integral[15]_i_20_n_0\ : STD_LOGIC;
  signal \integral[15]_i_21_n_0\ : STD_LOGIC;
  signal \integral[15]_i_22_n_0\ : STD_LOGIC;
  signal \integral[15]_i_23_n_0\ : STD_LOGIC;
  signal \integral[15]_i_24_n_0\ : STD_LOGIC;
  signal \integral[15]_i_25_n_0\ : STD_LOGIC;
  signal \integral[15]_i_26_n_0\ : STD_LOGIC;
  signal \integral[15]_i_27_n_0\ : STD_LOGIC;
  signal \integral[15]_i_28_n_0\ : STD_LOGIC;
  signal \integral[15]_i_29_n_0\ : STD_LOGIC;
  signal \integral[15]_i_2_n_0\ : STD_LOGIC;
  signal \integral[15]_i_30_n_0\ : STD_LOGIC;
  signal \integral[15]_i_31_n_0\ : STD_LOGIC;
  signal \integral[15]_i_32_n_0\ : STD_LOGIC;
  signal \integral[15]_i_33_n_0\ : STD_LOGIC;
  signal \integral[15]_i_34_n_0\ : STD_LOGIC;
  signal \integral[15]_i_35_n_0\ : STD_LOGIC;
  signal \integral[15]_i_36_n_0\ : STD_LOGIC;
  signal \integral[15]_i_37_n_0\ : STD_LOGIC;
  signal \integral[15]_i_38_n_0\ : STD_LOGIC;
  signal \integral[15]_i_39_n_0\ : STD_LOGIC;
  signal \integral[15]_i_3_n_0\ : STD_LOGIC;
  signal \integral[15]_i_40_n_0\ : STD_LOGIC;
  signal \integral[15]_i_41_n_0\ : STD_LOGIC;
  signal \integral[15]_i_42_n_0\ : STD_LOGIC;
  signal \integral[15]_i_44_n_0\ : STD_LOGIC;
  signal \integral[15]_i_45_n_0\ : STD_LOGIC;
  signal \integral[15]_i_46_n_0\ : STD_LOGIC;
  signal \integral[15]_i_47_n_0\ : STD_LOGIC;
  signal \integral[15]_i_4_n_0\ : STD_LOGIC;
  signal \integral[15]_i_5_n_0\ : STD_LOGIC;
  signal \integral[15]_i_8_n_0\ : STD_LOGIC;
  signal \integral[15]_i_9_n_0\ : STD_LOGIC;
  signal \integral[19]_i_10_n_0\ : STD_LOGIC;
  signal \integral[19]_i_11_n_0\ : STD_LOGIC;
  signal \integral[19]_i_12_n_0\ : STD_LOGIC;
  signal \integral[19]_i_13_n_0\ : STD_LOGIC;
  signal \integral[19]_i_14_n_0\ : STD_LOGIC;
  signal \integral[19]_i_15_n_0\ : STD_LOGIC;
  signal \integral[19]_i_19_n_0\ : STD_LOGIC;
  signal \integral[19]_i_20_n_0\ : STD_LOGIC;
  signal \integral[19]_i_21_n_0\ : STD_LOGIC;
  signal \integral[19]_i_22_n_0\ : STD_LOGIC;
  signal \integral[19]_i_23_n_0\ : STD_LOGIC;
  signal \integral[19]_i_24_n_0\ : STD_LOGIC;
  signal \integral[19]_i_25_n_0\ : STD_LOGIC;
  signal \integral[19]_i_26_n_0\ : STD_LOGIC;
  signal \integral[19]_i_27_n_0\ : STD_LOGIC;
  signal \integral[19]_i_28_n_0\ : STD_LOGIC;
  signal \integral[19]_i_29_n_0\ : STD_LOGIC;
  signal \integral[19]_i_2_n_0\ : STD_LOGIC;
  signal \integral[19]_i_30_n_0\ : STD_LOGIC;
  signal \integral[19]_i_31_n_0\ : STD_LOGIC;
  signal \integral[19]_i_32_n_0\ : STD_LOGIC;
  signal \integral[19]_i_33_n_0\ : STD_LOGIC;
  signal \integral[19]_i_34_n_0\ : STD_LOGIC;
  signal \integral[19]_i_35_n_0\ : STD_LOGIC;
  signal \integral[19]_i_36_n_0\ : STD_LOGIC;
  signal \integral[19]_i_37_n_0\ : STD_LOGIC;
  signal \integral[19]_i_38_n_0\ : STD_LOGIC;
  signal \integral[19]_i_39_n_0\ : STD_LOGIC;
  signal \integral[19]_i_3_n_0\ : STD_LOGIC;
  signal \integral[19]_i_40_n_0\ : STD_LOGIC;
  signal \integral[19]_i_41_n_0\ : STD_LOGIC;
  signal \integral[19]_i_42_n_0\ : STD_LOGIC;
  signal \integral[19]_i_4_n_0\ : STD_LOGIC;
  signal \integral[19]_i_5_n_0\ : STD_LOGIC;
  signal \integral[19]_i_8_n_0\ : STD_LOGIC;
  signal \integral[19]_i_9_n_0\ : STD_LOGIC;
  signal \integral[23]_i_10_n_0\ : STD_LOGIC;
  signal \integral[23]_i_11_n_0\ : STD_LOGIC;
  signal \integral[23]_i_12_n_0\ : STD_LOGIC;
  signal \integral[23]_i_13_n_0\ : STD_LOGIC;
  signal \integral[23]_i_14_n_0\ : STD_LOGIC;
  signal \integral[23]_i_15_n_0\ : STD_LOGIC;
  signal \integral[23]_i_18_n_0\ : STD_LOGIC;
  signal \integral[23]_i_19_n_0\ : STD_LOGIC;
  signal \integral[23]_i_20_n_0\ : STD_LOGIC;
  signal \integral[23]_i_21_n_0\ : STD_LOGIC;
  signal \integral[23]_i_22_n_0\ : STD_LOGIC;
  signal \integral[23]_i_23_n_0\ : STD_LOGIC;
  signal \integral[23]_i_24_n_0\ : STD_LOGIC;
  signal \integral[23]_i_25_n_0\ : STD_LOGIC;
  signal \integral[23]_i_26_n_0\ : STD_LOGIC;
  signal \integral[23]_i_27_n_0\ : STD_LOGIC;
  signal \integral[23]_i_28_n_0\ : STD_LOGIC;
  signal \integral[23]_i_29_n_0\ : STD_LOGIC;
  signal \integral[23]_i_2_n_0\ : STD_LOGIC;
  signal \integral[23]_i_30_n_0\ : STD_LOGIC;
  signal \integral[23]_i_31_n_0\ : STD_LOGIC;
  signal \integral[23]_i_32_n_0\ : STD_LOGIC;
  signal \integral[23]_i_3_n_0\ : STD_LOGIC;
  signal \integral[23]_i_4_n_0\ : STD_LOGIC;
  signal \integral[23]_i_5_n_0\ : STD_LOGIC;
  signal \integral[23]_i_8_n_0\ : STD_LOGIC;
  signal \integral[23]_i_9_n_0\ : STD_LOGIC;
  signal \integral[27]_i_100_n_0\ : STD_LOGIC;
  signal \integral[27]_i_101_n_0\ : STD_LOGIC;
  signal \integral[27]_i_102_n_0\ : STD_LOGIC;
  signal \integral[27]_i_103_n_0\ : STD_LOGIC;
  signal \integral[27]_i_104_n_0\ : STD_LOGIC;
  signal \integral[27]_i_105_n_0\ : STD_LOGIC;
  signal \integral[27]_i_106_n_0\ : STD_LOGIC;
  signal \integral[27]_i_108_n_0\ : STD_LOGIC;
  signal \integral[27]_i_109_n_0\ : STD_LOGIC;
  signal \integral[27]_i_10_n_0\ : STD_LOGIC;
  signal \integral[27]_i_110_n_0\ : STD_LOGIC;
  signal \integral[27]_i_111_n_0\ : STD_LOGIC;
  signal \integral[27]_i_112_n_0\ : STD_LOGIC;
  signal \integral[27]_i_113_n_0\ : STD_LOGIC;
  signal \integral[27]_i_114_n_0\ : STD_LOGIC;
  signal \integral[27]_i_115_n_0\ : STD_LOGIC;
  signal \integral[27]_i_116_n_0\ : STD_LOGIC;
  signal \integral[27]_i_117_n_0\ : STD_LOGIC;
  signal \integral[27]_i_118_n_0\ : STD_LOGIC;
  signal \integral[27]_i_11_n_0\ : STD_LOGIC;
  signal \integral[27]_i_120_n_0\ : STD_LOGIC;
  signal \integral[27]_i_121_n_0\ : STD_LOGIC;
  signal \integral[27]_i_122_n_0\ : STD_LOGIC;
  signal \integral[27]_i_123_n_0\ : STD_LOGIC;
  signal \integral[27]_i_124_n_0\ : STD_LOGIC;
  signal \integral[27]_i_125_n_0\ : STD_LOGIC;
  signal \integral[27]_i_126_n_0\ : STD_LOGIC;
  signal \integral[27]_i_127_n_0\ : STD_LOGIC;
  signal \integral[27]_i_129_n_0\ : STD_LOGIC;
  signal \integral[27]_i_12_n_0\ : STD_LOGIC;
  signal \integral[27]_i_130_n_0\ : STD_LOGIC;
  signal \integral[27]_i_131_n_0\ : STD_LOGIC;
  signal \integral[27]_i_132_n_0\ : STD_LOGIC;
  signal \integral[27]_i_133_n_0\ : STD_LOGIC;
  signal \integral[27]_i_134_n_0\ : STD_LOGIC;
  signal \integral[27]_i_135_n_0\ : STD_LOGIC;
  signal \integral[27]_i_136_n_0\ : STD_LOGIC;
  signal \integral[27]_i_137_n_0\ : STD_LOGIC;
  signal \integral[27]_i_138_n_0\ : STD_LOGIC;
  signal \integral[27]_i_139_n_0\ : STD_LOGIC;
  signal \integral[27]_i_13_n_0\ : STD_LOGIC;
  signal \integral[27]_i_140_n_0\ : STD_LOGIC;
  signal \integral[27]_i_141_n_0\ : STD_LOGIC;
  signal \integral[27]_i_142_n_0\ : STD_LOGIC;
  signal \integral[27]_i_143_n_0\ : STD_LOGIC;
  signal \integral[27]_i_145_n_0\ : STD_LOGIC;
  signal \integral[27]_i_146_n_0\ : STD_LOGIC;
  signal \integral[27]_i_147_n_0\ : STD_LOGIC;
  signal \integral[27]_i_148_n_0\ : STD_LOGIC;
  signal \integral[27]_i_149_n_0\ : STD_LOGIC;
  signal \integral[27]_i_14_n_0\ : STD_LOGIC;
  signal \integral[27]_i_150_n_0\ : STD_LOGIC;
  signal \integral[27]_i_151_n_0\ : STD_LOGIC;
  signal \integral[27]_i_152_n_0\ : STD_LOGIC;
  signal \integral[27]_i_153_n_0\ : STD_LOGIC;
  signal \integral[27]_i_154_n_0\ : STD_LOGIC;
  signal \integral[27]_i_155_n_0\ : STD_LOGIC;
  signal \integral[27]_i_156_n_0\ : STD_LOGIC;
  signal \integral[27]_i_157_n_0\ : STD_LOGIC;
  signal \integral[27]_i_158_n_0\ : STD_LOGIC;
  signal \integral[27]_i_159_n_0\ : STD_LOGIC;
  signal \integral[27]_i_15_n_0\ : STD_LOGIC;
  signal \integral[27]_i_160_n_0\ : STD_LOGIC;
  signal \integral[27]_i_16_n_0\ : STD_LOGIC;
  signal \integral[27]_i_18_n_0\ : STD_LOGIC;
  signal \integral[27]_i_19_n_0\ : STD_LOGIC;
  signal \integral[27]_i_20_n_0\ : STD_LOGIC;
  signal \integral[27]_i_21_n_0\ : STD_LOGIC;
  signal \integral[27]_i_22_n_0\ : STD_LOGIC;
  signal \integral[27]_i_23_n_0\ : STD_LOGIC;
  signal \integral[27]_i_24_n_0\ : STD_LOGIC;
  signal \integral[27]_i_25_n_0\ : STD_LOGIC;
  signal \integral[27]_i_26_n_0\ : STD_LOGIC;
  signal \integral[27]_i_28_n_0\ : STD_LOGIC;
  signal \integral[27]_i_29_n_0\ : STD_LOGIC;
  signal \integral[27]_i_2_n_0\ : STD_LOGIC;
  signal \integral[27]_i_30_n_0\ : STD_LOGIC;
  signal \integral[27]_i_31_n_0\ : STD_LOGIC;
  signal \integral[27]_i_32_n_0\ : STD_LOGIC;
  signal \integral[27]_i_33_n_0\ : STD_LOGIC;
  signal \integral[27]_i_34_n_0\ : STD_LOGIC;
  signal \integral[27]_i_35_n_0\ : STD_LOGIC;
  signal \integral[27]_i_37_n_0\ : STD_LOGIC;
  signal \integral[27]_i_38_n_0\ : STD_LOGIC;
  signal \integral[27]_i_39_n_0\ : STD_LOGIC;
  signal \integral[27]_i_3_n_0\ : STD_LOGIC;
  signal \integral[27]_i_40_n_0\ : STD_LOGIC;
  signal \integral[27]_i_41_n_0\ : STD_LOGIC;
  signal \integral[27]_i_42_n_0\ : STD_LOGIC;
  signal \integral[27]_i_43_n_0\ : STD_LOGIC;
  signal \integral[27]_i_44_n_0\ : STD_LOGIC;
  signal \integral[27]_i_49_n_0\ : STD_LOGIC;
  signal \integral[27]_i_4_n_0\ : STD_LOGIC;
  signal \integral[27]_i_50_n_0\ : STD_LOGIC;
  signal \integral[27]_i_51_n_0\ : STD_LOGIC;
  signal \integral[27]_i_52_n_0\ : STD_LOGIC;
  signal \integral[27]_i_53_n_0\ : STD_LOGIC;
  signal \integral[27]_i_54_n_0\ : STD_LOGIC;
  signal \integral[27]_i_55_n_0\ : STD_LOGIC;
  signal \integral[27]_i_56_n_0\ : STD_LOGIC;
  signal \integral[27]_i_58_n_0\ : STD_LOGIC;
  signal \integral[27]_i_59_n_0\ : STD_LOGIC;
  signal \integral[27]_i_60_n_0\ : STD_LOGIC;
  signal \integral[27]_i_61_n_0\ : STD_LOGIC;
  signal \integral[27]_i_62_n_0\ : STD_LOGIC;
  signal \integral[27]_i_63_n_0\ : STD_LOGIC;
  signal \integral[27]_i_64_n_0\ : STD_LOGIC;
  signal \integral[27]_i_65_n_0\ : STD_LOGIC;
  signal \integral[27]_i_66_n_0\ : STD_LOGIC;
  signal \integral[27]_i_67_n_0\ : STD_LOGIC;
  signal \integral[27]_i_68_n_0\ : STD_LOGIC;
  signal \integral[27]_i_69_n_0\ : STD_LOGIC;
  signal \integral[27]_i_70_n_0\ : STD_LOGIC;
  signal \integral[27]_i_71_n_0\ : STD_LOGIC;
  signal \integral[27]_i_72_n_0\ : STD_LOGIC;
  signal \integral[27]_i_73_n_0\ : STD_LOGIC;
  signal \integral[27]_i_74_n_0\ : STD_LOGIC;
  signal \integral[27]_i_75_n_0\ : STD_LOGIC;
  signal \integral[27]_i_76_n_0\ : STD_LOGIC;
  signal \integral[27]_i_77_n_0\ : STD_LOGIC;
  signal \integral[27]_i_78_n_0\ : STD_LOGIC;
  signal \integral[27]_i_80_n_0\ : STD_LOGIC;
  signal \integral[27]_i_81_n_0\ : STD_LOGIC;
  signal \integral[27]_i_82_n_0\ : STD_LOGIC;
  signal \integral[27]_i_83_n_0\ : STD_LOGIC;
  signal \integral[27]_i_84_n_0\ : STD_LOGIC;
  signal \integral[27]_i_85_n_0\ : STD_LOGIC;
  signal \integral[27]_i_86_n_0\ : STD_LOGIC;
  signal \integral[27]_i_87_n_0\ : STD_LOGIC;
  signal \integral[27]_i_89_n_0\ : STD_LOGIC;
  signal \integral[27]_i_90_n_0\ : STD_LOGIC;
  signal \integral[27]_i_91_n_0\ : STD_LOGIC;
  signal \integral[27]_i_92_n_0\ : STD_LOGIC;
  signal \integral[27]_i_93_n_0\ : STD_LOGIC;
  signal \integral[27]_i_94_n_0\ : STD_LOGIC;
  signal \integral[27]_i_95_n_0\ : STD_LOGIC;
  signal \integral[27]_i_96_n_0\ : STD_LOGIC;
  signal \integral[27]_i_99_n_0\ : STD_LOGIC;
  signal \integral[3]_i_100_n_0\ : STD_LOGIC;
  signal \integral[3]_i_101_n_0\ : STD_LOGIC;
  signal \integral[3]_i_104_n_0\ : STD_LOGIC;
  signal \integral[3]_i_105_n_0\ : STD_LOGIC;
  signal \integral[3]_i_106_n_0\ : STD_LOGIC;
  signal \integral[3]_i_107_n_0\ : STD_LOGIC;
  signal \integral[3]_i_108_n_0\ : STD_LOGIC;
  signal \integral[3]_i_109_n_0\ : STD_LOGIC;
  signal \integral[3]_i_10_n_0\ : STD_LOGIC;
  signal \integral[3]_i_110_n_0\ : STD_LOGIC;
  signal \integral[3]_i_111_n_0\ : STD_LOGIC;
  signal \integral[3]_i_116_n_0\ : STD_LOGIC;
  signal \integral[3]_i_117_n_0\ : STD_LOGIC;
  signal \integral[3]_i_118_n_0\ : STD_LOGIC;
  signal \integral[3]_i_119_n_0\ : STD_LOGIC;
  signal \integral[3]_i_11_n_0\ : STD_LOGIC;
  signal \integral[3]_i_120_n_0\ : STD_LOGIC;
  signal \integral[3]_i_121_n_0\ : STD_LOGIC;
  signal \integral[3]_i_122_n_0\ : STD_LOGIC;
  signal \integral[3]_i_123_n_0\ : STD_LOGIC;
  signal \integral[3]_i_124_n_0\ : STD_LOGIC;
  signal \integral[3]_i_125_n_0\ : STD_LOGIC;
  signal \integral[3]_i_126_n_0\ : STD_LOGIC;
  signal \integral[3]_i_127_n_0\ : STD_LOGIC;
  signal \integral[3]_i_128_n_0\ : STD_LOGIC;
  signal \integral[3]_i_129_n_0\ : STD_LOGIC;
  signal \integral[3]_i_12_n_0\ : STD_LOGIC;
  signal \integral[3]_i_130_n_0\ : STD_LOGIC;
  signal \integral[3]_i_131_n_0\ : STD_LOGIC;
  signal \integral[3]_i_132_n_0\ : STD_LOGIC;
  signal \integral[3]_i_133_n_0\ : STD_LOGIC;
  signal \integral[3]_i_135_n_0\ : STD_LOGIC;
  signal \integral[3]_i_136_n_0\ : STD_LOGIC;
  signal \integral[3]_i_137_n_0\ : STD_LOGIC;
  signal \integral[3]_i_138_n_0\ : STD_LOGIC;
  signal \integral[3]_i_139_n_0\ : STD_LOGIC;
  signal \integral[3]_i_13_n_0\ : STD_LOGIC;
  signal \integral[3]_i_140_n_0\ : STD_LOGIC;
  signal \integral[3]_i_141_n_0\ : STD_LOGIC;
  signal \integral[3]_i_142_n_0\ : STD_LOGIC;
  signal \integral[3]_i_143_n_0\ : STD_LOGIC;
  signal \integral[3]_i_144_n_0\ : STD_LOGIC;
  signal \integral[3]_i_145_n_0\ : STD_LOGIC;
  signal \integral[3]_i_146_n_0\ : STD_LOGIC;
  signal \integral[3]_i_14_n_0\ : STD_LOGIC;
  signal \integral[3]_i_150_n_0\ : STD_LOGIC;
  signal \integral[3]_i_151_n_0\ : STD_LOGIC;
  signal \integral[3]_i_152_n_0\ : STD_LOGIC;
  signal \integral[3]_i_153_n_0\ : STD_LOGIC;
  signal \integral[3]_i_154_n_0\ : STD_LOGIC;
  signal \integral[3]_i_155_n_0\ : STD_LOGIC;
  signal \integral[3]_i_156_n_0\ : STD_LOGIC;
  signal \integral[3]_i_157_n_0\ : STD_LOGIC;
  signal \integral[3]_i_158_n_0\ : STD_LOGIC;
  signal \integral[3]_i_159_n_0\ : STD_LOGIC;
  signal \integral[3]_i_15_n_0\ : STD_LOGIC;
  signal \integral[3]_i_160_n_0\ : STD_LOGIC;
  signal \integral[3]_i_161_n_0\ : STD_LOGIC;
  signal \integral[3]_i_162_n_0\ : STD_LOGIC;
  signal \integral[3]_i_163_n_0\ : STD_LOGIC;
  signal \integral[3]_i_164_n_0\ : STD_LOGIC;
  signal \integral[3]_i_165_n_0\ : STD_LOGIC;
  signal \integral[3]_i_166_n_0\ : STD_LOGIC;
  signal \integral[3]_i_167_n_0\ : STD_LOGIC;
  signal \integral[3]_i_168_n_0\ : STD_LOGIC;
  signal \integral[3]_i_169_n_0\ : STD_LOGIC;
  signal \integral[3]_i_16_n_0\ : STD_LOGIC;
  signal \integral[3]_i_170_n_0\ : STD_LOGIC;
  signal \integral[3]_i_171_n_0\ : STD_LOGIC;
  signal \integral[3]_i_173_n_0\ : STD_LOGIC;
  signal \integral[3]_i_174_n_0\ : STD_LOGIC;
  signal \integral[3]_i_175_n_0\ : STD_LOGIC;
  signal \integral[3]_i_176_n_0\ : STD_LOGIC;
  signal \integral[3]_i_179_n_0\ : STD_LOGIC;
  signal \integral[3]_i_17_n_0\ : STD_LOGIC;
  signal \integral[3]_i_180_n_0\ : STD_LOGIC;
  signal \integral[3]_i_181_n_0\ : STD_LOGIC;
  signal \integral[3]_i_182_n_0\ : STD_LOGIC;
  signal \integral[3]_i_183_n_0\ : STD_LOGIC;
  signal \integral[3]_i_184_n_0\ : STD_LOGIC;
  signal \integral[3]_i_185_n_0\ : STD_LOGIC;
  signal \integral[3]_i_186_n_0\ : STD_LOGIC;
  signal \integral[3]_i_187_n_0\ : STD_LOGIC;
  signal \integral[3]_i_188_n_0\ : STD_LOGIC;
  signal \integral[3]_i_189_n_0\ : STD_LOGIC;
  signal \integral[3]_i_190_n_0\ : STD_LOGIC;
  signal \integral[3]_i_191_n_0\ : STD_LOGIC;
  signal \integral[3]_i_192_n_0\ : STD_LOGIC;
  signal \integral[3]_i_193_n_0\ : STD_LOGIC;
  signal \integral[3]_i_195_n_0\ : STD_LOGIC;
  signal \integral[3]_i_196_n_0\ : STD_LOGIC;
  signal \integral[3]_i_197_n_0\ : STD_LOGIC;
  signal \integral[3]_i_198_n_0\ : STD_LOGIC;
  signal \integral[3]_i_19_n_0\ : STD_LOGIC;
  signal \integral[3]_i_200_n_0\ : STD_LOGIC;
  signal \integral[3]_i_201_n_0\ : STD_LOGIC;
  signal \integral[3]_i_202_n_0\ : STD_LOGIC;
  signal \integral[3]_i_203_n_0\ : STD_LOGIC;
  signal \integral[3]_i_204_n_0\ : STD_LOGIC;
  signal \integral[3]_i_205_n_0\ : STD_LOGIC;
  signal \integral[3]_i_206_n_0\ : STD_LOGIC;
  signal \integral[3]_i_207_n_0\ : STD_LOGIC;
  signal \integral[3]_i_208_n_0\ : STD_LOGIC;
  signal \integral[3]_i_209_n_0\ : STD_LOGIC;
  signal \integral[3]_i_20_n_0\ : STD_LOGIC;
  signal \integral[3]_i_210_n_0\ : STD_LOGIC;
  signal \integral[3]_i_211_n_0\ : STD_LOGIC;
  signal \integral[3]_i_212_n_0\ : STD_LOGIC;
  signal \integral[3]_i_213_n_0\ : STD_LOGIC;
  signal \integral[3]_i_214_n_0\ : STD_LOGIC;
  signal \integral[3]_i_215_n_0\ : STD_LOGIC;
  signal \integral[3]_i_217_n_0\ : STD_LOGIC;
  signal \integral[3]_i_218_n_0\ : STD_LOGIC;
  signal \integral[3]_i_219_n_0\ : STD_LOGIC;
  signal \integral[3]_i_21_n_0\ : STD_LOGIC;
  signal \integral[3]_i_220_n_0\ : STD_LOGIC;
  signal \integral[3]_i_221_n_0\ : STD_LOGIC;
  signal \integral[3]_i_222_n_0\ : STD_LOGIC;
  signal \integral[3]_i_223_n_0\ : STD_LOGIC;
  signal \integral[3]_i_224_n_0\ : STD_LOGIC;
  signal \integral[3]_i_226_n_0\ : STD_LOGIC;
  signal \integral[3]_i_227_n_0\ : STD_LOGIC;
  signal \integral[3]_i_228_n_0\ : STD_LOGIC;
  signal \integral[3]_i_229_n_0\ : STD_LOGIC;
  signal \integral[3]_i_22_n_0\ : STD_LOGIC;
  signal \integral[3]_i_230_n_0\ : STD_LOGIC;
  signal \integral[3]_i_231_n_0\ : STD_LOGIC;
  signal \integral[3]_i_232_n_0\ : STD_LOGIC;
  signal \integral[3]_i_233_n_0\ : STD_LOGIC;
  signal \integral[3]_i_234_n_0\ : STD_LOGIC;
  signal \integral[3]_i_235_n_0\ : STD_LOGIC;
  signal \integral[3]_i_236_n_0\ : STD_LOGIC;
  signal \integral[3]_i_23_n_0\ : STD_LOGIC;
  signal \integral[3]_i_24_n_0\ : STD_LOGIC;
  signal \integral[3]_i_25_n_0\ : STD_LOGIC;
  signal \integral[3]_i_26_n_0\ : STD_LOGIC;
  signal \integral[3]_i_2_n_0\ : STD_LOGIC;
  signal \integral[3]_i_31_n_0\ : STD_LOGIC;
  signal \integral[3]_i_32_n_0\ : STD_LOGIC;
  signal \integral[3]_i_33_n_0\ : STD_LOGIC;
  signal \integral[3]_i_34_n_0\ : STD_LOGIC;
  signal \integral[3]_i_35_n_0\ : STD_LOGIC;
  signal \integral[3]_i_36_n_0\ : STD_LOGIC;
  signal \integral[3]_i_37_n_0\ : STD_LOGIC;
  signal \integral[3]_i_38_n_0\ : STD_LOGIC;
  signal \integral[3]_i_3_n_0\ : STD_LOGIC;
  signal \integral[3]_i_42_n_0\ : STD_LOGIC;
  signal \integral[3]_i_43_n_0\ : STD_LOGIC;
  signal \integral[3]_i_44_n_0\ : STD_LOGIC;
  signal \integral[3]_i_45_n_0\ : STD_LOGIC;
  signal \integral[3]_i_46_n_0\ : STD_LOGIC;
  signal \integral[3]_i_47_n_0\ : STD_LOGIC;
  signal \integral[3]_i_48_n_0\ : STD_LOGIC;
  signal \integral[3]_i_49_n_0\ : STD_LOGIC;
  signal \integral[3]_i_4_n_0\ : STD_LOGIC;
  signal \integral[3]_i_50_n_0\ : STD_LOGIC;
  signal \integral[3]_i_51_n_0\ : STD_LOGIC;
  signal \integral[3]_i_52_n_0\ : STD_LOGIC;
  signal \integral[3]_i_53_n_0\ : STD_LOGIC;
  signal \integral[3]_i_54_n_0\ : STD_LOGIC;
  signal \integral[3]_i_55_n_0\ : STD_LOGIC;
  signal \integral[3]_i_56_n_0\ : STD_LOGIC;
  signal \integral[3]_i_57_n_0\ : STD_LOGIC;
  signal \integral[3]_i_58_n_0\ : STD_LOGIC;
  signal \integral[3]_i_59_n_0\ : STD_LOGIC;
  signal \integral[3]_i_5_n_0\ : STD_LOGIC;
  signal \integral[3]_i_60_n_0\ : STD_LOGIC;
  signal \integral[3]_i_61_n_0\ : STD_LOGIC;
  signal \integral[3]_i_62_n_0\ : STD_LOGIC;
  signal \integral[3]_i_63_n_0\ : STD_LOGIC;
  signal \integral[3]_i_64_n_0\ : STD_LOGIC;
  signal \integral[3]_i_65_n_0\ : STD_LOGIC;
  signal \integral[3]_i_67_n_0\ : STD_LOGIC;
  signal \integral[3]_i_68_n_0\ : STD_LOGIC;
  signal \integral[3]_i_69_n_0\ : STD_LOGIC;
  signal \integral[3]_i_70_n_0\ : STD_LOGIC;
  signal \integral[3]_i_71_n_0\ : STD_LOGIC;
  signal \integral[3]_i_72_n_0\ : STD_LOGIC;
  signal \integral[3]_i_73_n_0\ : STD_LOGIC;
  signal \integral[3]_i_74_n_0\ : STD_LOGIC;
  signal \integral[3]_i_78_n_0\ : STD_LOGIC;
  signal \integral[3]_i_79_n_0\ : STD_LOGIC;
  signal \integral[3]_i_80_n_0\ : STD_LOGIC;
  signal \integral[3]_i_81_n_0\ : STD_LOGIC;
  signal \integral[3]_i_82_n_0\ : STD_LOGIC;
  signal \integral[3]_i_83_n_0\ : STD_LOGIC;
  signal \integral[3]_i_84_n_0\ : STD_LOGIC;
  signal \integral[3]_i_85_n_0\ : STD_LOGIC;
  signal \integral[3]_i_86_n_0\ : STD_LOGIC;
  signal \integral[3]_i_87_n_0\ : STD_LOGIC;
  signal \integral[3]_i_88_n_0\ : STD_LOGIC;
  signal \integral[3]_i_89_n_0\ : STD_LOGIC;
  signal \integral[3]_i_8_n_0\ : STD_LOGIC;
  signal \integral[3]_i_90_n_0\ : STD_LOGIC;
  signal \integral[3]_i_91_n_0\ : STD_LOGIC;
  signal \integral[3]_i_92_n_0\ : STD_LOGIC;
  signal \integral[3]_i_93_n_0\ : STD_LOGIC;
  signal \integral[3]_i_94_n_0\ : STD_LOGIC;
  signal \integral[3]_i_95_n_0\ : STD_LOGIC;
  signal \integral[3]_i_96_n_0\ : STD_LOGIC;
  signal \integral[3]_i_97_n_0\ : STD_LOGIC;
  signal \integral[3]_i_98_n_0\ : STD_LOGIC;
  signal \integral[3]_i_99_n_0\ : STD_LOGIC;
  signal \integral[7]_i_10_n_0\ : STD_LOGIC;
  signal \integral[7]_i_11_n_0\ : STD_LOGIC;
  signal \integral[7]_i_12_n_0\ : STD_LOGIC;
  signal \integral[7]_i_13_n_0\ : STD_LOGIC;
  signal \integral[7]_i_14_n_0\ : STD_LOGIC;
  signal \integral[7]_i_15_n_0\ : STD_LOGIC;
  signal \integral[7]_i_19_n_0\ : STD_LOGIC;
  signal \integral[7]_i_20_n_0\ : STD_LOGIC;
  signal \integral[7]_i_21_n_0\ : STD_LOGIC;
  signal \integral[7]_i_22_n_0\ : STD_LOGIC;
  signal \integral[7]_i_23_n_0\ : STD_LOGIC;
  signal \integral[7]_i_24_n_0\ : STD_LOGIC;
  signal \integral[7]_i_25_n_0\ : STD_LOGIC;
  signal \integral[7]_i_26_n_0\ : STD_LOGIC;
  signal \integral[7]_i_27_n_0\ : STD_LOGIC;
  signal \integral[7]_i_28_n_0\ : STD_LOGIC;
  signal \integral[7]_i_29_n_0\ : STD_LOGIC;
  signal \integral[7]_i_2_n_0\ : STD_LOGIC;
  signal \integral[7]_i_30_n_0\ : STD_LOGIC;
  signal \integral[7]_i_31_n_0\ : STD_LOGIC;
  signal \integral[7]_i_32_n_0\ : STD_LOGIC;
  signal \integral[7]_i_33_n_0\ : STD_LOGIC;
  signal \integral[7]_i_34_n_0\ : STD_LOGIC;
  signal \integral[7]_i_35_n_0\ : STD_LOGIC;
  signal \integral[7]_i_36_n_0\ : STD_LOGIC;
  signal \integral[7]_i_37_n_0\ : STD_LOGIC;
  signal \integral[7]_i_38_n_0\ : STD_LOGIC;
  signal \integral[7]_i_39_n_0\ : STD_LOGIC;
  signal \integral[7]_i_3_n_0\ : STD_LOGIC;
  signal \integral[7]_i_40_n_0\ : STD_LOGIC;
  signal \integral[7]_i_41_n_0\ : STD_LOGIC;
  signal \integral[7]_i_42_n_0\ : STD_LOGIC;
  signal \integral[7]_i_45_n_0\ : STD_LOGIC;
  signal \integral[7]_i_46_n_0\ : STD_LOGIC;
  signal \integral[7]_i_47_n_0\ : STD_LOGIC;
  signal \integral[7]_i_48_n_0\ : STD_LOGIC;
  signal \integral[7]_i_49_n_0\ : STD_LOGIC;
  signal \integral[7]_i_4_n_0\ : STD_LOGIC;
  signal \integral[7]_i_50_n_0\ : STD_LOGIC;
  signal \integral[7]_i_51_n_0\ : STD_LOGIC;
  signal \integral[7]_i_52_n_0\ : STD_LOGIC;
  signal \integral[7]_i_53_n_0\ : STD_LOGIC;
  signal \integral[7]_i_54_n_0\ : STD_LOGIC;
  signal \integral[7]_i_55_n_0\ : STD_LOGIC;
  signal \integral[7]_i_56_n_0\ : STD_LOGIC;
  signal \integral[7]_i_5_n_0\ : STD_LOGIC;
  signal \integral[7]_i_8_n_0\ : STD_LOGIC;
  signal \integral[7]_i_9_n_0\ : STD_LOGIC;
  signal integral_prev : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \integral_reg[11]_i_16_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_16_n_1\ : STD_LOGIC;
  signal \integral_reg[11]_i_16_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_16_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_16_n_4\ : STD_LOGIC;
  signal \integral_reg[11]_i_16_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_16_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_16_n_7\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_1\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_4\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_17_n_7\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_1\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_4\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_18_n_7\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_1\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_4\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_43_n_7\ : STD_LOGIC;
  signal \integral_reg[11]_i_44_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_44_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_44_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_44_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_44_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_44_n_7\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_1\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_4\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_6_n_7\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_0\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_1\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_2\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_3\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_4\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_5\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_6\ : STD_LOGIC;
  signal \integral_reg[11]_i_7_n_7\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_0\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_1\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_2\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_3\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_4\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_5\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_6\ : STD_LOGIC;
  signal \integral_reg[15]_i_16_n_7\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_0\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_1\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_2\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_3\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_4\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_5\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_6\ : STD_LOGIC;
  signal \integral_reg[15]_i_17_n_7\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_0\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_1\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_2\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_3\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_4\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_5\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_6\ : STD_LOGIC;
  signal \integral_reg[15]_i_18_n_7\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[15]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_0\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_1\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_2\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_3\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_4\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_5\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_6\ : STD_LOGIC;
  signal \integral_reg[15]_i_43_n_7\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_0\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_1\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_2\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_3\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_4\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_5\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_6\ : STD_LOGIC;
  signal \integral_reg[15]_i_6_n_7\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_0\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_1\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_2\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_3\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_4\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_5\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_6\ : STD_LOGIC;
  signal \integral_reg[15]_i_7_n_7\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_0\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_1\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_2\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_3\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_4\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_5\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_6\ : STD_LOGIC;
  signal \integral_reg[19]_i_16_n_7\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_0\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_1\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_2\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_3\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_4\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_5\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_6\ : STD_LOGIC;
  signal \integral_reg[19]_i_17_n_7\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_0\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_1\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_2\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_3\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_4\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_5\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_6\ : STD_LOGIC;
  signal \integral_reg[19]_i_18_n_7\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[19]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_0\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_1\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_2\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_3\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_4\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_5\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_6\ : STD_LOGIC;
  signal \integral_reg[19]_i_6_n_7\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_0\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_1\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_2\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_3\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_4\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_5\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_6\ : STD_LOGIC;
  signal \integral_reg[19]_i_7_n_7\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_0\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_1\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_2\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_3\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_4\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_5\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_6\ : STD_LOGIC;
  signal \integral_reg[23]_i_16_n_7\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_0\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_1\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_2\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_3\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_4\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_5\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_6\ : STD_LOGIC;
  signal \integral_reg[23]_i_17_n_7\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[23]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_0\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_1\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_2\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_3\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_4\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_5\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_6\ : STD_LOGIC;
  signal \integral_reg[23]_i_6_n_7\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_0\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_1\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_2\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_3\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_4\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_5\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_6\ : STD_LOGIC;
  signal \integral_reg[23]_i_7_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_107_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_107_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_107_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_107_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_119_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_128_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_128_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_128_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_128_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_144_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_144_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_144_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_144_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_17_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_17_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_17_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_17_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_27_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_36_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_36_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_36_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_36_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_45_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_45_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_45_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_45_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_45_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_45_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_45_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_46_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_46_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_46_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_46_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_47_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_47_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_47_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_47_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_47_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_47_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_48_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_57_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_57_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_57_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_57_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_5_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_5_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_5_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_5_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_5_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_6_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_6_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_6_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_6_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_6_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_6_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_6_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_79_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_7_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_7_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_88_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_88_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_88_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_88_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_8_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_8_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_8_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_8_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_8_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_97_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_97_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_97_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_97_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_97_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_97_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_98_n_7\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_0\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_1\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_2\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_3\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_4\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_5\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_6\ : STD_LOGIC;
  signal \integral_reg[27]_i_9_n_7\ : STD_LOGIC;
  signal \integral_reg[31]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[31]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[31]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[31]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[31]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[31]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[31]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_102_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_103_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_112_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_113_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_113_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_113_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_113_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_113_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_113_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_113_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_114_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_115_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_134_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_147_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_148_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_149_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_172_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_177_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_177_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_177_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_177_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_178_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_18_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_18_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_18_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_18_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_194_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_199_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_216_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_216_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_216_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_216_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_225_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_225_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_225_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_225_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_27_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_28_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_29_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_30_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_30_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_30_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_30_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_39_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_40_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_41_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_66_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_66_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_66_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_66_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_6_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_75_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_76_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_77_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_3\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_4\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_5\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_6\ : STD_LOGIC;
  signal \integral_reg[3]_i_7_n_7\ : STD_LOGIC;
  signal \integral_reg[3]_i_9_n_0\ : STD_LOGIC;
  signal \integral_reg[3]_i_9_n_1\ : STD_LOGIC;
  signal \integral_reg[3]_i_9_n_2\ : STD_LOGIC;
  signal \integral_reg[3]_i_9_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_16_n_7\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_17_n_7\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_18_n_7\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_1_n_7\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_43_n_7\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_44_n_7\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_6_n_7\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_0\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_1\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_2\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_3\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_4\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_5\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_6\ : STD_LOGIC;
  signal \integral_reg[7]_i_7_n_7\ : STD_LOGIC;
  signal \interim_velocity[11]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[11]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[11]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[11]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[11]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[11]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[11]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[11]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[15]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[19]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[23]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[27]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[31]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[35]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[39]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity[3]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[3]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[3]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[3]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[3]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[3]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[3]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[72]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[72]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[72]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[72]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_2_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_3_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_4_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_5_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_6_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_7_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_8_n_0\ : STD_LOGIC;
  signal \interim_velocity[7]_i_9_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[11]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[15]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[19]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[23]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[27]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[31]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[35]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[39]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[72]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[72]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[72]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[72]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[72]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_4\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_5\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_6\ : STD_LOGIC;
  signal \interim_velocity_reg[7]_i_1_n_7\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[0]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[10]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[11]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[12]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[13]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[14]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[15]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[16]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[17]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[18]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[19]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[1]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[20]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[21]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[22]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[23]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[24]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[25]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[26]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[27]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[28]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[29]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[2]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[30]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[31]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[32]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[33]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[34]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[35]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[36]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[37]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[38]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[39]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[3]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[40]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[41]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[4]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[5]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[6]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[72]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[7]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[8]\ : STD_LOGIC;
  signal \interim_velocity_reg_n_0_[9]\ : STD_LOGIC;
  signal \^output_velocity\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal p_term0_n_100 : STD_LOGIC;
  signal p_term0_n_101 : STD_LOGIC;
  signal p_term0_n_102 : STD_LOGIC;
  signal p_term0_n_103 : STD_LOGIC;
  signal p_term0_n_104 : STD_LOGIC;
  signal p_term0_n_105 : STD_LOGIC;
  signal p_term0_n_106 : STD_LOGIC;
  signal p_term0_n_107 : STD_LOGIC;
  signal p_term0_n_108 : STD_LOGIC;
  signal p_term0_n_109 : STD_LOGIC;
  signal p_term0_n_110 : STD_LOGIC;
  signal p_term0_n_111 : STD_LOGIC;
  signal p_term0_n_112 : STD_LOGIC;
  signal p_term0_n_113 : STD_LOGIC;
  signal p_term0_n_114 : STD_LOGIC;
  signal p_term0_n_115 : STD_LOGIC;
  signal p_term0_n_116 : STD_LOGIC;
  signal p_term0_n_117 : STD_LOGIC;
  signal p_term0_n_118 : STD_LOGIC;
  signal p_term0_n_119 : STD_LOGIC;
  signal p_term0_n_120 : STD_LOGIC;
  signal p_term0_n_121 : STD_LOGIC;
  signal p_term0_n_122 : STD_LOGIC;
  signal p_term0_n_123 : STD_LOGIC;
  signal p_term0_n_124 : STD_LOGIC;
  signal p_term0_n_125 : STD_LOGIC;
  signal p_term0_n_126 : STD_LOGIC;
  signal p_term0_n_127 : STD_LOGIC;
  signal p_term0_n_128 : STD_LOGIC;
  signal p_term0_n_129 : STD_LOGIC;
  signal p_term0_n_130 : STD_LOGIC;
  signal p_term0_n_131 : STD_LOGIC;
  signal p_term0_n_132 : STD_LOGIC;
  signal p_term0_n_133 : STD_LOGIC;
  signal p_term0_n_134 : STD_LOGIC;
  signal p_term0_n_135 : STD_LOGIC;
  signal p_term0_n_136 : STD_LOGIC;
  signal p_term0_n_137 : STD_LOGIC;
  signal p_term0_n_138 : STD_LOGIC;
  signal p_term0_n_139 : STD_LOGIC;
  signal p_term0_n_140 : STD_LOGIC;
  signal p_term0_n_141 : STD_LOGIC;
  signal p_term0_n_142 : STD_LOGIC;
  signal p_term0_n_143 : STD_LOGIC;
  signal p_term0_n_144 : STD_LOGIC;
  signal p_term0_n_145 : STD_LOGIC;
  signal p_term0_n_146 : STD_LOGIC;
  signal p_term0_n_147 : STD_LOGIC;
  signal p_term0_n_148 : STD_LOGIC;
  signal p_term0_n_149 : STD_LOGIC;
  signal p_term0_n_150 : STD_LOGIC;
  signal p_term0_n_151 : STD_LOGIC;
  signal p_term0_n_152 : STD_LOGIC;
  signal p_term0_n_153 : STD_LOGIC;
  signal p_term0_n_58 : STD_LOGIC;
  signal p_term0_n_59 : STD_LOGIC;
  signal p_term0_n_60 : STD_LOGIC;
  signal p_term0_n_61 : STD_LOGIC;
  signal p_term0_n_62 : STD_LOGIC;
  signal p_term0_n_63 : STD_LOGIC;
  signal p_term0_n_64 : STD_LOGIC;
  signal p_term0_n_65 : STD_LOGIC;
  signal p_term0_n_66 : STD_LOGIC;
  signal p_term0_n_67 : STD_LOGIC;
  signal p_term0_n_68 : STD_LOGIC;
  signal p_term0_n_69 : STD_LOGIC;
  signal p_term0_n_70 : STD_LOGIC;
  signal p_term0_n_71 : STD_LOGIC;
  signal p_term0_n_72 : STD_LOGIC;
  signal p_term0_n_73 : STD_LOGIC;
  signal p_term0_n_74 : STD_LOGIC;
  signal p_term0_n_75 : STD_LOGIC;
  signal p_term0_n_76 : STD_LOGIC;
  signal p_term0_n_77 : STD_LOGIC;
  signal p_term0_n_78 : STD_LOGIC;
  signal p_term0_n_79 : STD_LOGIC;
  signal p_term0_n_80 : STD_LOGIC;
  signal p_term0_n_81 : STD_LOGIC;
  signal p_term0_n_82 : STD_LOGIC;
  signal p_term0_n_83 : STD_LOGIC;
  signal p_term0_n_84 : STD_LOGIC;
  signal p_term0_n_85 : STD_LOGIC;
  signal p_term0_n_86 : STD_LOGIC;
  signal p_term0_n_87 : STD_LOGIC;
  signal p_term0_n_88 : STD_LOGIC;
  signal p_term0_n_89 : STD_LOGIC;
  signal p_term0_n_90 : STD_LOGIC;
  signal p_term0_n_91 : STD_LOGIC;
  signal p_term0_n_92 : STD_LOGIC;
  signal p_term0_n_93 : STD_LOGIC;
  signal p_term0_n_94 : STD_LOGIC;
  signal p_term0_n_95 : STD_LOGIC;
  signal p_term0_n_96 : STD_LOGIC;
  signal p_term0_n_97 : STD_LOGIC;
  signal p_term0_n_98 : STD_LOGIC;
  signal p_term0_n_99 : STD_LOGIC;
  signal \^p_term_reg\ : STD_LOGIC_VECTOR ( 40 downto 0 );
  signal p_term_reg_n_58 : STD_LOGIC;
  signal p_term_reg_n_59 : STD_LOGIC;
  signal p_term_reg_n_60 : STD_LOGIC;
  signal p_term_reg_n_61 : STD_LOGIC;
  signal p_term_reg_n_62 : STD_LOGIC;
  signal p_term_reg_n_63 : STD_LOGIC;
  signal p_term_reg_n_64 : STD_LOGIC;
  signal p_term_reg_n_65 : STD_LOGIC;
  signal p_term_reg_n_66 : STD_LOGIC;
  signal p_term_reg_n_67 : STD_LOGIC;
  signal p_term_reg_n_68 : STD_LOGIC;
  signal p_term_reg_n_69 : STD_LOGIC;
  signal p_term_reg_n_70 : STD_LOGIC;
  signal p_term_reg_n_71 : STD_LOGIC;
  signal p_term_reg_n_72 : STD_LOGIC;
  signal p_term_reg_n_73 : STD_LOGIC;
  signal p_term_reg_n_74 : STD_LOGIC;
  signal p_term_reg_n_75 : STD_LOGIC;
  signal p_term_reg_n_76 : STD_LOGIC;
  signal p_term_reg_n_77 : STD_LOGIC;
  signal p_term_reg_n_78 : STD_LOGIC;
  signal p_term_reg_n_79 : STD_LOGIC;
  signal p_term_reg_n_80 : STD_LOGIC;
  signal p_term_reg_n_81 : STD_LOGIC;
  signal saved_target_angle : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \velocity1_carry__0_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__0_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__0_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__0_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__0_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__0_n_0\ : STD_LOGIC;
  signal \velocity1_carry__0_n_1\ : STD_LOGIC;
  signal \velocity1_carry__0_n_2\ : STD_LOGIC;
  signal \velocity1_carry__0_n_3\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__1_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__1_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__1_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__1_n_1\ : STD_LOGIC;
  signal \velocity1_carry__1_n_2\ : STD_LOGIC;
  signal \velocity1_carry__1_n_3\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__2_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__2_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__2_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__2_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__2_n_1\ : STD_LOGIC;
  signal \velocity1_carry__2_n_2\ : STD_LOGIC;
  signal \velocity1_carry__2_n_3\ : STD_LOGIC;
  signal \velocity1_carry__3_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__3_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__3_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__3_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__3_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__3_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__3_n_1\ : STD_LOGIC;
  signal \velocity1_carry__3_n_2\ : STD_LOGIC;
  signal \velocity1_carry__3_n_3\ : STD_LOGIC;
  signal \velocity1_carry__4_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__4_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__4_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__4_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__4_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__4_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__4_n_1\ : STD_LOGIC;
  signal \velocity1_carry__4_n_2\ : STD_LOGIC;
  signal \velocity1_carry__4_n_3\ : STD_LOGIC;
  signal \velocity1_carry__5_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__5_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__5_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__5_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__5_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__5_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__5_n_1\ : STD_LOGIC;
  signal \velocity1_carry__5_n_2\ : STD_LOGIC;
  signal \velocity1_carry__5_n_3\ : STD_LOGIC;
  signal \velocity1_carry__6_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__6_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__6_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__6_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__6_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__6_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__6_n_1\ : STD_LOGIC;
  signal \velocity1_carry__6_n_2\ : STD_LOGIC;
  signal \velocity1_carry__6_n_3\ : STD_LOGIC;
  signal \velocity1_carry__7_i_10_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_10_n_1\ : STD_LOGIC;
  signal \velocity1_carry__7_i_10_n_2\ : STD_LOGIC;
  signal \velocity1_carry__7_i_10_n_3\ : STD_LOGIC;
  signal \velocity1_carry__7_i_11_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_12_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_13_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_14_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_15_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_16_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_17_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_18_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_3_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_6_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_8_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_9_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_i_9_n_1\ : STD_LOGIC;
  signal \velocity1_carry__7_i_9_n_2\ : STD_LOGIC;
  signal \velocity1_carry__7_i_9_n_3\ : STD_LOGIC;
  signal \velocity1_carry__7_n_0\ : STD_LOGIC;
  signal \velocity1_carry__7_n_1\ : STD_LOGIC;
  signal \velocity1_carry__7_n_2\ : STD_LOGIC;
  signal \velocity1_carry__7_n_3\ : STD_LOGIC;
  signal \velocity1_carry__8_i_1_n_0\ : STD_LOGIC;
  signal \velocity1_carry__8_i_2_n_0\ : STD_LOGIC;
  signal \velocity1_carry__8_i_3_n_3\ : STD_LOGIC;
  signal \velocity1_carry__8_i_4_n_0\ : STD_LOGIC;
  signal \velocity1_carry__8_i_5_n_0\ : STD_LOGIC;
  signal \velocity1_carry__8_n_3\ : STD_LOGIC;
  signal velocity1_carry_i_10_n_0 : STD_LOGIC;
  signal velocity1_carry_i_11_n_0 : STD_LOGIC;
  signal velocity1_carry_i_12_n_0 : STD_LOGIC;
  signal velocity1_carry_i_13_n_0 : STD_LOGIC;
  signal velocity1_carry_i_14_n_0 : STD_LOGIC;
  signal velocity1_carry_i_15_n_0 : STD_LOGIC;
  signal velocity1_carry_i_16_n_0 : STD_LOGIC;
  signal velocity1_carry_i_17_n_0 : STD_LOGIC;
  signal velocity1_carry_i_1_n_0 : STD_LOGIC;
  signal velocity1_carry_i_2_n_0 : STD_LOGIC;
  signal velocity1_carry_i_2_n_1 : STD_LOGIC;
  signal velocity1_carry_i_2_n_2 : STD_LOGIC;
  signal velocity1_carry_i_2_n_3 : STD_LOGIC;
  signal velocity1_carry_i_3_n_0 : STD_LOGIC;
  signal velocity1_carry_i_4_n_0 : STD_LOGIC;
  signal velocity1_carry_i_5_n_0 : STD_LOGIC;
  signal velocity1_carry_i_6_n_0 : STD_LOGIC;
  signal velocity1_carry_i_7_n_0 : STD_LOGIC;
  signal velocity1_carry_i_8_n_0 : STD_LOGIC;
  signal velocity1_carry_i_9_n_0 : STD_LOGIC;
  signal velocity1_carry_i_9_n_1 : STD_LOGIC;
  signal velocity1_carry_i_9_n_2 : STD_LOGIC;
  signal velocity1_carry_i_9_n_3 : STD_LOGIC;
  signal velocity1_carry_n_0 : STD_LOGIC;
  signal velocity1_carry_n_1 : STD_LOGIC;
  signal velocity1_carry_n_2 : STD_LOGIC;
  signal velocity1_carry_n_3 : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__1_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__2_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__3_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__3_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__3_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__3_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__4_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__4_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__4_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__4_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__5_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__5_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__5_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__5_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__6_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__6_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__6_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__6_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__7_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__7_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry__7_n_3\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \velocity1_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal velocity2 : STD_LOGIC_VECTOR ( 73 downto 0 );
  signal \velocity[31]_i_1_n_0\ : STD_LOGIC;
  signal NLW_d_term0_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term0_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_d_term0_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_d_term0_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_d_term_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_d_term_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_d_term_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_d_term_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_d_term_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal \NLW_derivative0__0_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_derivative1_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative1_carry__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_error0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_i__carry_i_4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_i__carry_i_4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_i__carry_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_i_term0_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term0_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_i_term0_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_i_term0_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_i_term_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_i_term_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_i_term_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_i_term_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_i_term_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal \NLW_integral_reg[11]_i_44_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_integral_reg[11]_i_44_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[27]_i_107_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_128_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_144_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_17_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_36_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_45_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[27]_i_46_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_integral_reg[27]_i_46_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_integral_reg[27]_i_47_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_integral_reg[27]_i_47_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[27]_i_5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_integral_reg[27]_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[27]_i_57_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[27]_i_7_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_integral_reg[27]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_8_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_integral_reg[27]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[27]_i_88_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[27]_i_97_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_integral_reg[27]_i_97_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[31]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral_reg[3]_i_113_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_integral_reg[3]_i_177_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[3]_i_18_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[3]_i_216_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[3]_i_225_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[3]_i_30_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[3]_i_66_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral_reg[3]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_interim_velocity_reg[72]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_interim_velocity_reg[72]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_p_term0_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term0_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_p_term0_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_p_term0_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_p_term_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_p_term_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_p_term_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_p_term_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_p_term_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal NLW_velocity1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__8_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_velocity1_carry__8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_carry__8_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_velocity1_carry__8_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_velocity1_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1_inferred__0/i__carry__7_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_velocity1_inferred__0/i__carry__7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of d_term0 : label is "{SYNTH-11 {cell *THIS*}}";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \derivative0__0_carry\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative0__0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative0__0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative0__0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative0__0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative0__0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative0__0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of error0_carry : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__6\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_4\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5__0\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5__1\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5__2\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5__3\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5__4\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5__5\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_5__6\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6__0\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6__1\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6__2\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6__3\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6__4\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6__5\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_6__6\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_7\ : label is 35;
  attribute ADDER_THRESHOLD of \i__carry_i_8\ : label is 35;
  attribute METHODOLOGY_DRC_VIOS of i_term0 : label is "{SYNTH-11 {cell *THIS*}}";
  attribute HLUTNM : string;
  attribute HLUTNM of \integral[11]_i_10\ : label is "lutpair56";
  attribute HLUTNM of \integral[11]_i_11\ : label is "lutpair55";
  attribute HLUTNM of \integral[11]_i_12\ : label is "lutpair59";
  attribute HLUTNM of \integral[11]_i_13\ : label is "lutpair58";
  attribute HLUTNM of \integral[11]_i_14\ : label is "lutpair57";
  attribute HLUTNM of \integral[11]_i_15\ : label is "lutpair56";
  attribute HLUTNM of \integral[11]_i_8\ : label is "lutpair58";
  attribute HLUTNM of \integral[11]_i_9\ : label is "lutpair57";
  attribute HLUTNM of \integral[15]_i_10\ : label is "lutpair60";
  attribute HLUTNM of \integral[15]_i_11\ : label is "lutpair59";
  attribute HLUTNM of \integral[15]_i_12\ : label is "lutpair63";
  attribute HLUTNM of \integral[15]_i_13\ : label is "lutpair62";
  attribute HLUTNM of \integral[15]_i_14\ : label is "lutpair61";
  attribute HLUTNM of \integral[15]_i_15\ : label is "lutpair60";
  attribute HLUTNM of \integral[15]_i_8\ : label is "lutpair62";
  attribute HLUTNM of \integral[15]_i_9\ : label is "lutpair61";
  attribute HLUTNM of \integral[19]_i_10\ : label is "lutpair64";
  attribute HLUTNM of \integral[19]_i_11\ : label is "lutpair63";
  attribute HLUTNM of \integral[19]_i_12\ : label is "lutpair67";
  attribute HLUTNM of \integral[19]_i_13\ : label is "lutpair66";
  attribute HLUTNM of \integral[19]_i_14\ : label is "lutpair65";
  attribute HLUTNM of \integral[19]_i_15\ : label is "lutpair64";
  attribute HLUTNM of \integral[19]_i_8\ : label is "lutpair66";
  attribute HLUTNM of \integral[19]_i_9\ : label is "lutpair65";
  attribute HLUTNM of \integral[23]_i_10\ : label is "lutpair68";
  attribute HLUTNM of \integral[23]_i_11\ : label is "lutpair67";
  attribute HLUTNM of \integral[23]_i_12\ : label is "lutpair71";
  attribute HLUTNM of \integral[23]_i_13\ : label is "lutpair70";
  attribute HLUTNM of \integral[23]_i_14\ : label is "lutpair69";
  attribute HLUTNM of \integral[23]_i_15\ : label is "lutpair68";
  attribute HLUTNM of \integral[23]_i_8\ : label is "lutpair70";
  attribute HLUTNM of \integral[23]_i_9\ : label is "lutpair69";
  attribute HLUTNM of \integral[27]_i_22\ : label is "lutpair72";
  attribute HLUTNM of \integral[27]_i_23\ : label is "lutpair71";
  attribute HLUTNM of \integral[27]_i_26\ : label is "lutpair72";
  attribute HLUTNM of \integral[3]_i_10\ : label is "lutpair50";
  attribute HLUTNM of \integral[3]_i_104\ : label is "lutpair112";
  attribute HLUTNM of \integral[3]_i_108\ : label is "lutpair35";
  attribute HLUTNM of \integral[3]_i_109\ : label is "lutpair112";
  attribute HLUTNM of \integral[3]_i_11\ : label is "lutpair49";
  attribute HLUTNM of \integral[3]_i_12\ : label is "lutpair48";
  attribute HLUTNM of \integral[3]_i_13\ : label is "lutpair47";
  attribute HLUTNM of \integral[3]_i_139\ : label is "lutpair22";
  attribute HLUTNM of \integral[3]_i_14\ : label is "lutpair51";
  attribute HLUTNM of \integral[3]_i_140\ : label is "lutpair21";
  attribute HLUTNM of \integral[3]_i_141\ : label is "lutpair20";
  attribute HLUTNM of \integral[3]_i_142\ : label is "lutpair19";
  attribute HLUTNM of \integral[3]_i_143\ : label is "lutpair23";
  attribute HLUTNM of \integral[3]_i_144\ : label is "lutpair22";
  attribute HLUTNM of \integral[3]_i_145\ : label is "lutpair21";
  attribute HLUTNM of \integral[3]_i_146\ : label is "lutpair20";
  attribute HLUTNM of \integral[3]_i_15\ : label is "lutpair50";
  attribute HLUTNM of \integral[3]_i_16\ : label is "lutpair49";
  attribute HLUTNM of \integral[3]_i_164\ : label is "lutpair18";
  attribute HLUTNM of \integral[3]_i_165\ : label is "lutpair17";
  attribute HLUTNM of \integral[3]_i_166\ : label is "lutpair16";
  attribute HLUTNM of \integral[3]_i_167\ : label is "lutpair15";
  attribute HLUTNM of \integral[3]_i_168\ : label is "lutpair19";
  attribute HLUTNM of \integral[3]_i_169\ : label is "lutpair18";
  attribute HLUTNM of \integral[3]_i_17\ : label is "lutpair48";
  attribute HLUTNM of \integral[3]_i_170\ : label is "lutpair17";
  attribute HLUTNM of \integral[3]_i_171\ : label is "lutpair16";
  attribute HLUTNM of \integral[3]_i_186\ : label is "lutpair14";
  attribute HLUTNM of \integral[3]_i_187\ : label is "lutpair13";
  attribute HLUTNM of \integral[3]_i_188\ : label is "lutpair12";
  attribute HLUTNM of \integral[3]_i_189\ : label is "lutpair11";
  attribute HLUTNM of \integral[3]_i_19\ : label is "lutpair46";
  attribute HLUTNM of \integral[3]_i_190\ : label is "lutpair15";
  attribute HLUTNM of \integral[3]_i_191\ : label is "lutpair14";
  attribute HLUTNM of \integral[3]_i_192\ : label is "lutpair13";
  attribute HLUTNM of \integral[3]_i_193\ : label is "lutpair12";
  attribute HLUTNM of \integral[3]_i_20\ : label is "lutpair45";
  attribute HLUTNM of \integral[3]_i_204\ : label is "lutpair10";
  attribute HLUTNM of \integral[3]_i_205\ : label is "lutpair9";
  attribute HLUTNM of \integral[3]_i_206\ : label is "lutpair8";
  attribute HLUTNM of \integral[3]_i_207\ : label is "lutpair7";
  attribute HLUTNM of \integral[3]_i_208\ : label is "lutpair11";
  attribute HLUTNM of \integral[3]_i_209\ : label is "lutpair10";
  attribute HLUTNM of \integral[3]_i_21\ : label is "lutpair44";
  attribute HLUTNM of \integral[3]_i_210\ : label is "lutpair9";
  attribute HLUTNM of \integral[3]_i_211\ : label is "lutpair8";
  attribute HLUTNM of \integral[3]_i_217\ : label is "lutpair6";
  attribute HLUTNM of \integral[3]_i_218\ : label is "lutpair5";
  attribute HLUTNM of \integral[3]_i_219\ : label is "lutpair4";
  attribute HLUTNM of \integral[3]_i_22\ : label is "lutpair43";
  attribute HLUTNM of \integral[3]_i_220\ : label is "lutpair3";
  attribute HLUTNM of \integral[3]_i_221\ : label is "lutpair7";
  attribute HLUTNM of \integral[3]_i_222\ : label is "lutpair6";
  attribute HLUTNM of \integral[3]_i_223\ : label is "lutpair5";
  attribute HLUTNM of \integral[3]_i_224\ : label is "lutpair4";
  attribute HLUTNM of \integral[3]_i_226\ : label is "lutpair2";
  attribute HLUTNM of \integral[3]_i_227\ : label is "lutpair1";
  attribute HLUTNM of \integral[3]_i_228\ : label is "lutpair0";
  attribute HLUTNM of \integral[3]_i_23\ : label is "lutpair47";
  attribute HLUTNM of \integral[3]_i_230\ : label is "lutpair3";
  attribute HLUTNM of \integral[3]_i_231\ : label is "lutpair2";
  attribute HLUTNM of \integral[3]_i_232\ : label is "lutpair1";
  attribute HLUTNM of \integral[3]_i_233\ : label is "lutpair0";
  attribute HLUTNM of \integral[3]_i_24\ : label is "lutpair46";
  attribute HLUTNM of \integral[3]_i_25\ : label is "lutpair45";
  attribute HLUTNM of \integral[3]_i_26\ : label is "lutpair44";
  attribute HLUTNM of \integral[3]_i_31\ : label is "lutpair42";
  attribute HLUTNM of \integral[3]_i_32\ : label is "lutpair41";
  attribute HLUTNM of \integral[3]_i_33\ : label is "lutpair40";
  attribute HLUTNM of \integral[3]_i_34\ : label is "lutpair39";
  attribute HLUTNM of \integral[3]_i_35\ : label is "lutpair43";
  attribute HLUTNM of \integral[3]_i_36\ : label is "lutpair42";
  attribute HLUTNM of \integral[3]_i_37\ : label is "lutpair41";
  attribute HLUTNM of \integral[3]_i_38\ : label is "lutpair40";
  attribute HLUTNM of \integral[3]_i_42\ : label is "lutpair30";
  attribute HLUTNM of \integral[3]_i_43\ : label is "lutpair29";
  attribute HLUTNM of \integral[3]_i_44\ : label is "lutpair28";
  attribute HLUTNM of \integral[3]_i_45\ : label is "lutpair27";
  attribute HLUTNM of \integral[3]_i_46\ : label is "lutpair31";
  attribute HLUTNM of \integral[3]_i_47\ : label is "lutpair30";
  attribute HLUTNM of \integral[3]_i_48\ : label is "lutpair29";
  attribute HLUTNM of \integral[3]_i_49\ : label is "lutpair28";
  attribute HLUTNM of \integral[3]_i_67\ : label is "lutpair38";
  attribute HLUTNM of \integral[3]_i_68\ : label is "lutpair37";
  attribute HLUTNM of \integral[3]_i_69\ : label is "lutpair36";
  attribute HLUTNM of \integral[3]_i_70\ : label is "lutpair35";
  attribute HLUTNM of \integral[3]_i_71\ : label is "lutpair39";
  attribute HLUTNM of \integral[3]_i_72\ : label is "lutpair38";
  attribute HLUTNM of \integral[3]_i_73\ : label is "lutpair37";
  attribute HLUTNM of \integral[3]_i_74\ : label is "lutpair36";
  attribute HLUTNM of \integral[3]_i_78\ : label is "lutpair26";
  attribute HLUTNM of \integral[3]_i_79\ : label is "lutpair25";
  attribute HLUTNM of \integral[3]_i_80\ : label is "lutpair24";
  attribute HLUTNM of \integral[3]_i_82\ : label is "lutpair27";
  attribute HLUTNM of \integral[3]_i_83\ : label is "lutpair26";
  attribute HLUTNM of \integral[3]_i_84\ : label is "lutpair25";
  attribute HLUTNM of \integral[3]_i_85\ : label is "lutpair24";
  attribute HLUTNM of \integral[7]_i_10\ : label is "lutpair52";
  attribute HLUTNM of \integral[7]_i_11\ : label is "lutpair51";
  attribute HLUTNM of \integral[7]_i_12\ : label is "lutpair55";
  attribute HLUTNM of \integral[7]_i_13\ : label is "lutpair54";
  attribute HLUTNM of \integral[7]_i_14\ : label is "lutpair53";
  attribute HLUTNM of \integral[7]_i_15\ : label is "lutpair52";
  attribute HLUTNM of \integral[7]_i_19\ : label is "lutpair34";
  attribute HLUTNM of \integral[7]_i_20\ : label is "lutpair33";
  attribute HLUTNM of \integral[7]_i_21\ : label is "lutpair32";
  attribute HLUTNM of \integral[7]_i_22\ : label is "lutpair31";
  attribute HLUTNM of \integral[7]_i_24\ : label is "lutpair34";
  attribute HLUTNM of \integral[7]_i_25\ : label is "lutpair33";
  attribute HLUTNM of \integral[7]_i_26\ : label is "lutpair32";
  attribute HLUTNM of \integral[7]_i_52\ : label is "lutpair23";
  attribute HLUTNM of \integral[7]_i_8\ : label is "lutpair54";
  attribute HLUTNM of \integral[7]_i_9\ : label is "lutpair53";
  attribute ADDER_THRESHOLD of \integral_reg[11]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[11]_i_16\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[11]_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[11]_i_7\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[15]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[15]_i_16\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[15]_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[15]_i_7\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[19]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[19]_i_16\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[19]_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[19]_i_7\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[23]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[23]_i_16\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[23]_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[23]_i_7\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_107\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_119\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_128\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_144\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_17\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_27\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_36\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_45\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_48\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_5\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_57\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_7\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_79\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_8\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_88\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_9\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[27]_i_98\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[31]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_112\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_147\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_177\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_18\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_27\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_30\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_39\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_66\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_7\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_75\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[3]_i_9\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[7]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[7]_i_16\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[7]_i_6\ : label is 35;
  attribute ADDER_THRESHOLD of \integral_reg[7]_i_7\ : label is 35;
  attribute HLUTNM of \interim_velocity[11]_i_2\ : label is "lutpair83";
  attribute HLUTNM of \interim_velocity[11]_i_3\ : label is "lutpair82";
  attribute HLUTNM of \interim_velocity[11]_i_4\ : label is "lutpair81";
  attribute HLUTNM of \interim_velocity[11]_i_5\ : label is "lutpair80";
  attribute HLUTNM of \interim_velocity[11]_i_6\ : label is "lutpair84";
  attribute HLUTNM of \interim_velocity[11]_i_7\ : label is "lutpair83";
  attribute HLUTNM of \interim_velocity[11]_i_8\ : label is "lutpair82";
  attribute HLUTNM of \interim_velocity[11]_i_9\ : label is "lutpair81";
  attribute HLUTNM of \interim_velocity[15]_i_2\ : label is "lutpair87";
  attribute HLUTNM of \interim_velocity[15]_i_3\ : label is "lutpair86";
  attribute HLUTNM of \interim_velocity[15]_i_4\ : label is "lutpair85";
  attribute HLUTNM of \interim_velocity[15]_i_5\ : label is "lutpair84";
  attribute HLUTNM of \interim_velocity[15]_i_6\ : label is "lutpair88";
  attribute HLUTNM of \interim_velocity[15]_i_7\ : label is "lutpair87";
  attribute HLUTNM of \interim_velocity[15]_i_8\ : label is "lutpair86";
  attribute HLUTNM of \interim_velocity[15]_i_9\ : label is "lutpair85";
  attribute HLUTNM of \interim_velocity[19]_i_2\ : label is "lutpair91";
  attribute HLUTNM of \interim_velocity[19]_i_3\ : label is "lutpair90";
  attribute HLUTNM of \interim_velocity[19]_i_4\ : label is "lutpair89";
  attribute HLUTNM of \interim_velocity[19]_i_5\ : label is "lutpair88";
  attribute HLUTNM of \interim_velocity[19]_i_6\ : label is "lutpair92";
  attribute HLUTNM of \interim_velocity[19]_i_7\ : label is "lutpair91";
  attribute HLUTNM of \interim_velocity[19]_i_8\ : label is "lutpair90";
  attribute HLUTNM of \interim_velocity[19]_i_9\ : label is "lutpair89";
  attribute HLUTNM of \interim_velocity[23]_i_2\ : label is "lutpair95";
  attribute HLUTNM of \interim_velocity[23]_i_3\ : label is "lutpair94";
  attribute HLUTNM of \interim_velocity[23]_i_4\ : label is "lutpair93";
  attribute HLUTNM of \interim_velocity[23]_i_5\ : label is "lutpair92";
  attribute HLUTNM of \interim_velocity[23]_i_6\ : label is "lutpair96";
  attribute HLUTNM of \interim_velocity[23]_i_7\ : label is "lutpair95";
  attribute HLUTNM of \interim_velocity[23]_i_8\ : label is "lutpair94";
  attribute HLUTNM of \interim_velocity[23]_i_9\ : label is "lutpair93";
  attribute HLUTNM of \interim_velocity[27]_i_2\ : label is "lutpair99";
  attribute HLUTNM of \interim_velocity[27]_i_3\ : label is "lutpair98";
  attribute HLUTNM of \interim_velocity[27]_i_4\ : label is "lutpair97";
  attribute HLUTNM of \interim_velocity[27]_i_5\ : label is "lutpair96";
  attribute HLUTNM of \interim_velocity[27]_i_6\ : label is "lutpair100";
  attribute HLUTNM of \interim_velocity[27]_i_7\ : label is "lutpair99";
  attribute HLUTNM of \interim_velocity[27]_i_8\ : label is "lutpair98";
  attribute HLUTNM of \interim_velocity[27]_i_9\ : label is "lutpair97";
  attribute HLUTNM of \interim_velocity[31]_i_2\ : label is "lutpair103";
  attribute HLUTNM of \interim_velocity[31]_i_3\ : label is "lutpair102";
  attribute HLUTNM of \interim_velocity[31]_i_4\ : label is "lutpair101";
  attribute HLUTNM of \interim_velocity[31]_i_5\ : label is "lutpair100";
  attribute HLUTNM of \interim_velocity[31]_i_6\ : label is "lutpair104";
  attribute HLUTNM of \interim_velocity[31]_i_7\ : label is "lutpair103";
  attribute HLUTNM of \interim_velocity[31]_i_8\ : label is "lutpair102";
  attribute HLUTNM of \interim_velocity[31]_i_9\ : label is "lutpair101";
  attribute HLUTNM of \interim_velocity[35]_i_2\ : label is "lutpair107";
  attribute HLUTNM of \interim_velocity[35]_i_3\ : label is "lutpair106";
  attribute HLUTNM of \interim_velocity[35]_i_4\ : label is "lutpair105";
  attribute HLUTNM of \interim_velocity[35]_i_5\ : label is "lutpair104";
  attribute HLUTNM of \interim_velocity[35]_i_6\ : label is "lutpair108";
  attribute HLUTNM of \interim_velocity[35]_i_7\ : label is "lutpair107";
  attribute HLUTNM of \interim_velocity[35]_i_8\ : label is "lutpair106";
  attribute HLUTNM of \interim_velocity[35]_i_9\ : label is "lutpair105";
  attribute HLUTNM of \interim_velocity[39]_i_2\ : label is "lutpair111";
  attribute HLUTNM of \interim_velocity[39]_i_3\ : label is "lutpair110";
  attribute HLUTNM of \interim_velocity[39]_i_4\ : label is "lutpair109";
  attribute HLUTNM of \interim_velocity[39]_i_5\ : label is "lutpair108";
  attribute HLUTNM of \interim_velocity[39]_i_7\ : label is "lutpair111";
  attribute HLUTNM of \interim_velocity[39]_i_8\ : label is "lutpair110";
  attribute HLUTNM of \interim_velocity[39]_i_9\ : label is "lutpair109";
  attribute HLUTNM of \interim_velocity[3]_i_2\ : label is "lutpair75";
  attribute HLUTNM of \interim_velocity[3]_i_3\ : label is "lutpair74";
  attribute HLUTNM of \interim_velocity[3]_i_4\ : label is "lutpair73";
  attribute HLUTNM of \interim_velocity[3]_i_5\ : label is "lutpair76";
  attribute HLUTNM of \interim_velocity[3]_i_6\ : label is "lutpair75";
  attribute HLUTNM of \interim_velocity[3]_i_7\ : label is "lutpair74";
  attribute HLUTNM of \interim_velocity[3]_i_8\ : label is "lutpair73";
  attribute HLUTNM of \interim_velocity[7]_i_2\ : label is "lutpair79";
  attribute HLUTNM of \interim_velocity[7]_i_3\ : label is "lutpair78";
  attribute HLUTNM of \interim_velocity[7]_i_4\ : label is "lutpair77";
  attribute HLUTNM of \interim_velocity[7]_i_5\ : label is "lutpair76";
  attribute HLUTNM of \interim_velocity[7]_i_6\ : label is "lutpair80";
  attribute HLUTNM of \interim_velocity[7]_i_7\ : label is "lutpair79";
  attribute HLUTNM of \interim_velocity[7]_i_8\ : label is "lutpair78";
  attribute HLUTNM of \interim_velocity[7]_i_9\ : label is "lutpair77";
  attribute METHODOLOGY_DRC_VIOS of p_term0 : label is "{SYNTH-11 {cell *THIS*}}";
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of velocity1_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__0\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__0_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__0_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__1\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__1_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__1_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__2\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__2_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__2_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__3\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__3_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__3_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__4\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__4_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__4_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__5\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__5_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__5_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__6\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__6_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__6_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__7\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__7_i_10\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity1_carry__7_i_9\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_carry__8\ : label is 11;
  attribute ADDER_THRESHOLD of \velocity1_carry__8_i_3\ : label is 35;
  attribute ADDER_THRESHOLD of velocity1_carry_i_2 : label is 35;
  attribute ADDER_THRESHOLD of velocity1_carry_i_9 : label is 35;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__3\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__4\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__5\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__6\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \velocity1_inferred__0/i__carry__7\ : label is 11;
begin
  output_velocity(31 downto 0) <= \^output_velocity\(31 downto 0);
d_term0: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 1,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 1,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16) => \derivative0__0_carry__2_n_7\,
      A(15) => \derivative0__0_carry__1_n_4\,
      A(14) => \derivative0__0_carry__1_n_5\,
      A(13) => \derivative0__0_carry__1_n_6\,
      A(12) => \derivative0__0_carry__1_n_7\,
      A(11) => \derivative0__0_carry__0_n_4\,
      A(10) => \derivative0__0_carry__0_n_5\,
      A(9) => \derivative0__0_carry__0_n_6\,
      A(8) => \derivative0__0_carry__0_n_7\,
      A(7) => \derivative0__0_carry_n_4\,
      A(6) => \derivative0__0_carry_n_5\,
      A(5) => \derivative0__0_carry_n_6\,
      A(4) => \derivative0__0_carry_n_7\,
      A(3 downto 1) => derivative1(2 downto 0),
      A(0) => '0',
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_d_term0_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kd(8),
      B(16) => kd(8),
      B(15) => kd(8),
      B(14) => kd(8),
      B(13) => kd(8),
      B(12) => kd(8),
      B(11) => kd(8),
      B(10) => kd(8),
      B(9) => kd(8),
      B(8 downto 0) => kd(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_d_term0_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_d_term0_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_d_term0_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '1',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => clock(0),
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_d_term0_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_d_term0_OVERFLOW_UNCONNECTED,
      P(47) => d_term0_n_58,
      P(46) => d_term0_n_59,
      P(45) => d_term0_n_60,
      P(44) => d_term0_n_61,
      P(43) => d_term0_n_62,
      P(42) => d_term0_n_63,
      P(41) => d_term0_n_64,
      P(40) => d_term0_n_65,
      P(39) => d_term0_n_66,
      P(38) => d_term0_n_67,
      P(37) => d_term0_n_68,
      P(36) => d_term0_n_69,
      P(35) => d_term0_n_70,
      P(34) => d_term0_n_71,
      P(33) => d_term0_n_72,
      P(32) => d_term0_n_73,
      P(31) => d_term0_n_74,
      P(30) => d_term0_n_75,
      P(29) => d_term0_n_76,
      P(28) => d_term0_n_77,
      P(27) => d_term0_n_78,
      P(26) => d_term0_n_79,
      P(25) => d_term0_n_80,
      P(24) => d_term0_n_81,
      P(23) => d_term0_n_82,
      P(22) => d_term0_n_83,
      P(21) => d_term0_n_84,
      P(20) => d_term0_n_85,
      P(19) => d_term0_n_86,
      P(18) => d_term0_n_87,
      P(17) => d_term0_n_88,
      P(16) => d_term0_n_89,
      P(15) => d_term0_n_90,
      P(14) => d_term0_n_91,
      P(13) => d_term0_n_92,
      P(12) => d_term0_n_93,
      P(11) => d_term0_n_94,
      P(10) => d_term0_n_95,
      P(9) => d_term0_n_96,
      P(8) => d_term0_n_97,
      P(7) => d_term0_n_98,
      P(6) => d_term0_n_99,
      P(5) => d_term0_n_100,
      P(4) => d_term0_n_101,
      P(3) => d_term0_n_102,
      P(2) => d_term0_n_103,
      P(1) => d_term0_n_104,
      P(0) => d_term0_n_105,
      PATTERNBDETECT => NLW_d_term0_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_d_term0_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => d_term0_n_106,
      PCOUT(46) => d_term0_n_107,
      PCOUT(45) => d_term0_n_108,
      PCOUT(44) => d_term0_n_109,
      PCOUT(43) => d_term0_n_110,
      PCOUT(42) => d_term0_n_111,
      PCOUT(41) => d_term0_n_112,
      PCOUT(40) => d_term0_n_113,
      PCOUT(39) => d_term0_n_114,
      PCOUT(38) => d_term0_n_115,
      PCOUT(37) => d_term0_n_116,
      PCOUT(36) => d_term0_n_117,
      PCOUT(35) => d_term0_n_118,
      PCOUT(34) => d_term0_n_119,
      PCOUT(33) => d_term0_n_120,
      PCOUT(32) => d_term0_n_121,
      PCOUT(31) => d_term0_n_122,
      PCOUT(30) => d_term0_n_123,
      PCOUT(29) => d_term0_n_124,
      PCOUT(28) => d_term0_n_125,
      PCOUT(27) => d_term0_n_126,
      PCOUT(26) => d_term0_n_127,
      PCOUT(25) => d_term0_n_128,
      PCOUT(24) => d_term0_n_129,
      PCOUT(23) => d_term0_n_130,
      PCOUT(22) => d_term0_n_131,
      PCOUT(21) => d_term0_n_132,
      PCOUT(20) => d_term0_n_133,
      PCOUT(19) => d_term0_n_134,
      PCOUT(18) => d_term0_n_135,
      PCOUT(17) => d_term0_n_136,
      PCOUT(16) => d_term0_n_137,
      PCOUT(15) => d_term0_n_138,
      PCOUT(14) => d_term0_n_139,
      PCOUT(13) => d_term0_n_140,
      PCOUT(12) => d_term0_n_141,
      PCOUT(11) => d_term0_n_142,
      PCOUT(10) => d_term0_n_143,
      PCOUT(9) => d_term0_n_144,
      PCOUT(8) => d_term0_n_145,
      PCOUT(7) => d_term0_n_146,
      PCOUT(6) => d_term0_n_147,
      PCOUT(5) => d_term0_n_148,
      PCOUT(4) => d_term0_n_149,
      PCOUT(3) => d_term0_n_150,
      PCOUT(2) => d_term0_n_151,
      PCOUT(1) => d_term0_n_152,
      PCOUT(0) => d_term0_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_d_term0_UNDERFLOW_UNCONNECTED
    );
d_term_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 1,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 1,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => \derivative0__0_carry__5_n_4\,
      A(28) => \derivative0__0_carry__5_n_4\,
      A(27) => \derivative0__0_carry__5_n_4\,
      A(26) => \derivative0__0_carry__5_n_4\,
      A(25) => \derivative0__0_carry__5_n_4\,
      A(24) => \derivative0__0_carry__5_n_4\,
      A(23) => \derivative0__0_carry__5_n_4\,
      A(22) => \derivative0__0_carry__5_n_4\,
      A(21) => \derivative0__0_carry__5_n_4\,
      A(20) => \derivative0__0_carry__5_n_4\,
      A(19) => \derivative0__0_carry__5_n_4\,
      A(18) => \derivative0__0_carry__5_n_4\,
      A(17) => \derivative0__0_carry__5_n_4\,
      A(16) => \derivative0__0_carry__5_n_4\,
      A(15) => \derivative0__0_carry__5_n_4\,
      A(14) => \derivative0__0_carry__5_n_4\,
      A(13) => \derivative0__0_carry__5_n_5\,
      A(12) => \derivative0__0_carry__5_n_6\,
      A(11) => \derivative0__0_carry__5_n_7\,
      A(10) => \derivative0__0_carry__4_n_4\,
      A(9) => \derivative0__0_carry__4_n_5\,
      A(8) => \derivative0__0_carry__4_n_6\,
      A(7) => \derivative0__0_carry__4_n_7\,
      A(6) => \derivative0__0_carry__3_n_4\,
      A(5) => \derivative0__0_carry__3_n_5\,
      A(4) => \derivative0__0_carry__3_n_6\,
      A(3) => \derivative0__0_carry__3_n_7\,
      A(2) => \derivative0__0_carry__2_n_4\,
      A(1) => \derivative0__0_carry__2_n_5\,
      A(0) => \derivative0__0_carry__2_n_6\,
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_d_term_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kd(8),
      B(16) => kd(8),
      B(15) => kd(8),
      B(14) => kd(8),
      B(13) => kd(8),
      B(12) => kd(8),
      B(11) => kd(8),
      B(10) => kd(8),
      B(9) => kd(8),
      B(8 downto 0) => kd(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_d_term_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_d_term_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_d_term_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '1',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '1',
      CLK => clock(0),
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_d_term_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => NLW_d_term_reg_OVERFLOW_UNCONNECTED,
      P(47) => d_term_reg_n_58,
      P(46) => d_term_reg_n_59,
      P(45) => d_term_reg_n_60,
      P(44) => d_term_reg_n_61,
      P(43) => d_term_reg_n_62,
      P(42) => d_term_reg_n_63,
      P(41) => d_term_reg_n_64,
      P(40) => d_term_reg_n_65,
      P(39) => d_term_reg_n_66,
      P(38) => d_term_reg_n_67,
      P(37) => d_term_reg_n_68,
      P(36) => d_term_reg_n_69,
      P(35) => d_term_reg_n_70,
      P(34) => d_term_reg_n_71,
      P(33) => d_term_reg_n_72,
      P(32) => d_term_reg_n_73,
      P(31) => d_term_reg_n_74,
      P(30) => d_term_reg_n_75,
      P(29) => d_term_reg_n_76,
      P(28) => d_term_reg_n_77,
      P(27) => d_term_reg_n_78,
      P(26) => d_term_reg_n_79,
      P(25) => d_term_reg_n_80,
      P(24) => d_term_reg_n_81,
      P(23 downto 0) => \^d_term_reg\(40 downto 17),
      PATTERNBDETECT => NLW_d_term_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_d_term_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47) => d_term0_n_106,
      PCIN(46) => d_term0_n_107,
      PCIN(45) => d_term0_n_108,
      PCIN(44) => d_term0_n_109,
      PCIN(43) => d_term0_n_110,
      PCIN(42) => d_term0_n_111,
      PCIN(41) => d_term0_n_112,
      PCIN(40) => d_term0_n_113,
      PCIN(39) => d_term0_n_114,
      PCIN(38) => d_term0_n_115,
      PCIN(37) => d_term0_n_116,
      PCIN(36) => d_term0_n_117,
      PCIN(35) => d_term0_n_118,
      PCIN(34) => d_term0_n_119,
      PCIN(33) => d_term0_n_120,
      PCIN(32) => d_term0_n_121,
      PCIN(31) => d_term0_n_122,
      PCIN(30) => d_term0_n_123,
      PCIN(29) => d_term0_n_124,
      PCIN(28) => d_term0_n_125,
      PCIN(27) => d_term0_n_126,
      PCIN(26) => d_term0_n_127,
      PCIN(25) => d_term0_n_128,
      PCIN(24) => d_term0_n_129,
      PCIN(23) => d_term0_n_130,
      PCIN(22) => d_term0_n_131,
      PCIN(21) => d_term0_n_132,
      PCIN(20) => d_term0_n_133,
      PCIN(19) => d_term0_n_134,
      PCIN(18) => d_term0_n_135,
      PCIN(17) => d_term0_n_136,
      PCIN(16) => d_term0_n_137,
      PCIN(15) => d_term0_n_138,
      PCIN(14) => d_term0_n_139,
      PCIN(13) => d_term0_n_140,
      PCIN(12) => d_term0_n_141,
      PCIN(11) => d_term0_n_142,
      PCIN(10) => d_term0_n_143,
      PCIN(9) => d_term0_n_144,
      PCIN(8) => d_term0_n_145,
      PCIN(7) => d_term0_n_146,
      PCIN(6) => d_term0_n_147,
      PCIN(5) => d_term0_n_148,
      PCIN(4) => d_term0_n_149,
      PCIN(3) => d_term0_n_150,
      PCIN(2) => d_term0_n_151,
      PCIN(1) => d_term0_n_152,
      PCIN(0) => d_term0_n_153,
      PCOUT(47 downto 0) => NLW_d_term_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_d_term_reg_UNDERFLOW_UNCONNECTED
    );
\d_term_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_105,
      Q => \^d_term_reg\(0),
      R => '0'
    );
\d_term_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_95,
      Q => \^d_term_reg\(10),
      R => '0'
    );
\d_term_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_94,
      Q => \^d_term_reg\(11),
      R => '0'
    );
\d_term_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_93,
      Q => \^d_term_reg\(12),
      R => '0'
    );
\d_term_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_92,
      Q => \^d_term_reg\(13),
      R => '0'
    );
\d_term_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_91,
      Q => \^d_term_reg\(14),
      R => '0'
    );
\d_term_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_90,
      Q => \^d_term_reg\(15),
      R => '0'
    );
\d_term_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_89,
      Q => \^d_term_reg\(16),
      R => '0'
    );
\d_term_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_104,
      Q => \^d_term_reg\(1),
      R => '0'
    );
\d_term_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_103,
      Q => \^d_term_reg\(2),
      R => '0'
    );
\d_term_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_102,
      Q => \^d_term_reg\(3),
      R => '0'
    );
\d_term_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_101,
      Q => \^d_term_reg\(4),
      R => '0'
    );
\d_term_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_100,
      Q => \^d_term_reg\(5),
      R => '0'
    );
\d_term_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_99,
      Q => \^d_term_reg\(6),
      R => '0'
    );
\d_term_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_98,
      Q => \^d_term_reg\(7),
      R => '0'
    );
\d_term_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_97,
      Q => \^d_term_reg\(8),
      R => '0'
    );
\d_term_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => d_term0_n_96,
      Q => \^d_term_reg\(9),
      R => '0'
    );
\derivative0__0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative0__0_carry_n_0\,
      CO(2) => \derivative0__0_carry_n_1\,
      CO(1) => \derivative0__0_carry_n_2\,
      CO(0) => \derivative0__0_carry_n_3\,
      CYINIT => '0',
      DI(3) => \derivative0__0_carry_i_1_n_0\,
      DI(2) => \derivative0__0_carry_i_2_n_0\,
      DI(1) => \derivative0__0_carry_i_3__5_n_0\,
      DI(0) => '0',
      O(3) => \derivative0__0_carry_n_4\,
      O(2) => \derivative0__0_carry_n_5\,
      O(1) => \derivative0__0_carry_n_6\,
      O(0) => \derivative0__0_carry_n_7\,
      S(3) => \derivative0__0_carry_i_4__5_n_0\,
      S(2) => \derivative0__0_carry_i_5_n_0\,
      S(1) => \derivative0__0_carry_i_6_n_0\,
      S(0) => \derivative0__0_carry_i_7_n_0\
    );
\derivative0__0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative0__0_carry_n_0\,
      CO(3) => \derivative0__0_carry__0_n_0\,
      CO(2) => \derivative0__0_carry__0_n_1\,
      CO(1) => \derivative0__0_carry__0_n_2\,
      CO(0) => \derivative0__0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \derivative0__0_carry_i_1__0_n_0\,
      DI(2) => \derivative0__0_carry_i_2__0_n_0\,
      DI(1) => \derivative0__0_carry_i_3_n_0\,
      DI(0) => \derivative0__0_carry_i_4_n_0\,
      O(3) => \derivative0__0_carry__0_n_4\,
      O(2) => \derivative0__0_carry__0_n_5\,
      O(1) => \derivative0__0_carry__0_n_6\,
      O(0) => \derivative0__0_carry__0_n_7\,
      S(3) => \derivative0__0_carry_i_5__0_n_0\,
      S(2) => \derivative0__0_carry_i_6__0_n_0\,
      S(1) => \derivative0__0_carry_i_7__0_n_0\,
      S(0) => \derivative0__0_carry_i_8_n_0\
    );
\derivative0__0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative0__0_carry__0_n_0\,
      CO(3) => \derivative0__0_carry__1_n_0\,
      CO(2) => \derivative0__0_carry__1_n_1\,
      CO(1) => \derivative0__0_carry__1_n_2\,
      CO(0) => \derivative0__0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \derivative0__0_carry_i_1__1_n_0\,
      DI(2) => \derivative0__0_carry_i_2__1_n_0\,
      DI(1) => \derivative0__0_carry_i_3__0_n_0\,
      DI(0) => \derivative0__0_carry_i_4__0_n_0\,
      O(3) => \derivative0__0_carry__1_n_4\,
      O(2) => \derivative0__0_carry__1_n_5\,
      O(1) => \derivative0__0_carry__1_n_6\,
      O(0) => \derivative0__0_carry__1_n_7\,
      S(3) => \derivative0__0_carry_i_5__1_n_0\,
      S(2) => \derivative0__0_carry_i_6__1_n_0\,
      S(1) => \derivative0__0_carry_i_7__1_n_0\,
      S(0) => \derivative0__0_carry_i_8__0_n_0\
    );
\derivative0__0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative0__0_carry__1_n_0\,
      CO(3) => \derivative0__0_carry__2_n_0\,
      CO(2) => \derivative0__0_carry__2_n_1\,
      CO(1) => \derivative0__0_carry__2_n_2\,
      CO(0) => \derivative0__0_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative0__0_carry_i_1__2_n_0\,
      DI(2) => \derivative0__0_carry_i_2__2_n_0\,
      DI(1) => \derivative0__0_carry_i_3__1_n_0\,
      DI(0) => \derivative0__0_carry_i_4__1_n_0\,
      O(3) => \derivative0__0_carry__2_n_4\,
      O(2) => \derivative0__0_carry__2_n_5\,
      O(1) => \derivative0__0_carry__2_n_6\,
      O(0) => \derivative0__0_carry__2_n_7\,
      S(3) => \derivative0__0_carry_i_5__2_n_0\,
      S(2) => \derivative0__0_carry_i_6__2_n_0\,
      S(1) => \derivative0__0_carry_i_7__2_n_0\,
      S(0) => \derivative0__0_carry_i_8__1_n_0\
    );
\derivative0__0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative0__0_carry__2_n_0\,
      CO(3) => \derivative0__0_carry__3_n_0\,
      CO(2) => \derivative0__0_carry__3_n_1\,
      CO(1) => \derivative0__0_carry__3_n_2\,
      CO(0) => \derivative0__0_carry__3_n_3\,
      CYINIT => '0',
      DI(3) => \derivative0__0_carry_i_1__3_n_0\,
      DI(2) => \derivative0__0_carry_i_2__3_n_0\,
      DI(1) => \derivative0__0_carry_i_3__2_n_0\,
      DI(0) => \derivative0__0_carry_i_4__2_n_0\,
      O(3) => \derivative0__0_carry__3_n_4\,
      O(2) => \derivative0__0_carry__3_n_5\,
      O(1) => \derivative0__0_carry__3_n_6\,
      O(0) => \derivative0__0_carry__3_n_7\,
      S(3) => \derivative0__0_carry_i_5__3_n_0\,
      S(2) => \derivative0__0_carry_i_6__3_n_0\,
      S(1) => \derivative0__0_carry_i_7__3_n_0\,
      S(0) => \derivative0__0_carry_i_8__2_n_0\
    );
\derivative0__0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative0__0_carry__3_n_0\,
      CO(3) => \derivative0__0_carry__4_n_0\,
      CO(2) => \derivative0__0_carry__4_n_1\,
      CO(1) => \derivative0__0_carry__4_n_2\,
      CO(0) => \derivative0__0_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \derivative0__0_carry_i_1__4_n_0\,
      DI(2) => \derivative0__0_carry_i_2__4_n_0\,
      DI(1) => \derivative0__0_carry_i_3__3_n_0\,
      DI(0) => \derivative0__0_carry_i_4__3_n_0\,
      O(3) => \derivative0__0_carry__4_n_4\,
      O(2) => \derivative0__0_carry__4_n_5\,
      O(1) => \derivative0__0_carry__4_n_6\,
      O(0) => \derivative0__0_carry__4_n_7\,
      S(3) => \derivative0__0_carry_i_5__4_n_0\,
      S(2) => \derivative0__0_carry_i_6__4_n_0\,
      S(1) => \derivative0__0_carry_i_7__4_n_0\,
      S(0) => \derivative0__0_carry_i_8__3_n_0\
    );
\derivative0__0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative0__0_carry__4_n_0\,
      CO(3) => \NLW_derivative0__0_carry__5_CO_UNCONNECTED\(3),
      CO(2) => \derivative0__0_carry__5_n_1\,
      CO(1) => \derivative0__0_carry__5_n_2\,
      CO(0) => \derivative0__0_carry__5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \derivative0__0_carry_i_1__5_n_0\,
      DI(1) => \derivative0__0_carry_i_2__5_n_0\,
      DI(0) => \derivative0__0_carry_i_3__4_n_0\,
      O(3) => \derivative0__0_carry__5_n_4\,
      O(2) => \derivative0__0_carry__5_n_5\,
      O(1) => \derivative0__0_carry__5_n_6\,
      O(0) => \derivative0__0_carry__5_n_7\,
      S(3) => \derivative0__0_carry_i_4__4_n_0\,
      S(2) => \derivative0__0_carry_i_5__5_n_0\,
      S(1) => \derivative0__0_carry_i_6__5_n_0\,
      S(0) => \derivative0__0_carry_i_7__5_n_0\
    );
\derivative0__0_carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => derivative1(2),
      I1 => \derivative1__0\(5),
      I2 => derivative1(0),
      O => \derivative0__0_carry_i_1_n_0\
    );
\derivative0__0_carry_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(6),
      I1 => \derivative1__0\(9),
      I2 => \derivative1__0\(4),
      O => \derivative0__0_carry_i_1__0_n_0\
    );
\derivative0__0_carry_i_1__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(10),
      I1 => \derivative1__0\(13),
      I2 => \derivative1__0\(8),
      O => \derivative0__0_carry_i_1__1_n_0\
    );
\derivative0__0_carry_i_1__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(14),
      I1 => \derivative1__0\(17),
      I2 => \derivative1__0\(12),
      O => \derivative0__0_carry_i_1__2_n_0\
    );
\derivative0__0_carry_i_1__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(18),
      I1 => \derivative1__0\(21),
      I2 => \derivative1__0\(16),
      O => \derivative0__0_carry_i_1__3_n_0\
    );
\derivative0__0_carry_i_1__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(22),
      I1 => \derivative1__0\(25),
      I2 => \derivative1__0\(20),
      O => \derivative0__0_carry_i_1__4_n_0\
    );
\derivative0__0_carry_i_1__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(25),
      I1 => \derivative1__0\(28),
      I2 => \derivative1__0\(23),
      O => \derivative0__0_carry_i_1__5_n_0\
    );
\derivative0__0_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => derivative1(2),
      I1 => \derivative1__0\(5),
      I2 => derivative1(0),
      O => \derivative0__0_carry_i_2_n_0\
    );
\derivative0__0_carry_i_2__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(5),
      I1 => \derivative1__0\(8),
      I2 => \derivative1__0\(3),
      O => \derivative0__0_carry_i_2__0_n_0\
    );
\derivative0__0_carry_i_2__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(9),
      I1 => \derivative1__0\(12),
      I2 => \derivative1__0\(7),
      O => \derivative0__0_carry_i_2__1_n_0\
    );
\derivative0__0_carry_i_2__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(13),
      I1 => \derivative1__0\(16),
      I2 => \derivative1__0\(11),
      O => \derivative0__0_carry_i_2__2_n_0\
    );
\derivative0__0_carry_i_2__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(17),
      I1 => \derivative1__0\(20),
      I2 => \derivative1__0\(15),
      O => \derivative0__0_carry_i_2__3_n_0\
    );
\derivative0__0_carry_i_2__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(21),
      I1 => \derivative1__0\(24),
      I2 => \derivative1__0\(19),
      O => \derivative0__0_carry_i_2__4_n_0\
    );
\derivative0__0_carry_i_2__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(24),
      I1 => \derivative1__0\(27),
      I2 => \derivative1__0\(22),
      O => \derivative0__0_carry_i_2__5_n_0\
    );
\derivative0__0_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(4),
      I1 => \derivative1__0\(7),
      I2 => derivative1(2),
      O => \derivative0__0_carry_i_3_n_0\
    );
\derivative0__0_carry_i_3__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(8),
      I1 => \derivative1__0\(11),
      I2 => \derivative1__0\(6),
      O => \derivative0__0_carry_i_3__0_n_0\
    );
\derivative0__0_carry_i_3__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(12),
      I1 => \derivative1__0\(15),
      I2 => \derivative1__0\(10),
      O => \derivative0__0_carry_i_3__1_n_0\
    );
\derivative0__0_carry_i_3__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(16),
      I1 => \derivative1__0\(19),
      I2 => \derivative1__0\(14),
      O => \derivative0__0_carry_i_3__2_n_0\
    );
\derivative0__0_carry_i_3__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(20),
      I1 => \derivative1__0\(23),
      I2 => \derivative1__0\(18),
      O => \derivative0__0_carry_i_3__3_n_0\
    );
\derivative0__0_carry_i_3__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(23),
      I1 => \derivative1__0\(26),
      I2 => \derivative1__0\(21),
      O => \derivative0__0_carry_i_3__4_n_0\
    );
\derivative0__0_carry_i_3__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \derivative1__0\(3),
      I1 => derivative1(0),
      O => \derivative0__0_carry_i_3__5_n_0\
    );
\derivative0__0_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(3),
      I1 => \derivative1__0\(6),
      I2 => derivative1(1),
      O => \derivative0__0_carry_i_4_n_0\
    );
\derivative0__0_carry_i_4__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(7),
      I1 => \derivative1__0\(10),
      I2 => \derivative1__0\(5),
      O => \derivative0__0_carry_i_4__0_n_0\
    );
\derivative0__0_carry_i_4__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(11),
      I1 => \derivative1__0\(14),
      I2 => \derivative1__0\(9),
      O => \derivative0__0_carry_i_4__1_n_0\
    );
\derivative0__0_carry_i_4__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(15),
      I1 => \derivative1__0\(18),
      I2 => \derivative1__0\(13),
      O => \derivative0__0_carry_i_4__2_n_0\
    );
\derivative0__0_carry_i_4__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \derivative1__0\(19),
      I1 => \derivative1__0\(22),
      I2 => \derivative1__0\(17),
      O => \derivative0__0_carry_i_4__3_n_0\
    );
\derivative0__0_carry_i_4__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9669696996969669"
    )
        port map (
      I0 => \derivative1__0\(27),
      I1 => \derivative1__0\(25),
      I2 => \derivative1__0\(30),
      I3 => \derivative1__0\(24),
      I4 => \derivative1__0\(29),
      I5 => \derivative1__0\(26),
      O => \derivative0__0_carry_i_4__4_n_0\
    );
\derivative0__0_carry_i_4__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => derivative1(0),
      I1 => \derivative1__0\(5),
      I2 => derivative1(2),
      I3 => \derivative1__0\(3),
      I4 => \derivative1__0\(6),
      I5 => derivative1(1),
      O => \derivative0__0_carry_i_4__5_n_0\
    );
\derivative0__0_carry_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69966969"
    )
        port map (
      I0 => derivative1(2),
      I1 => \derivative1__0\(5),
      I2 => derivative1(0),
      I3 => derivative1(1),
      I4 => \derivative1__0\(4),
      O => \derivative0__0_carry_i_5_n_0\
    );
\derivative0__0_carry_i_5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(4),
      I1 => \derivative1__0\(9),
      I2 => \derivative1__0\(6),
      I3 => \derivative1__0\(7),
      I4 => \derivative1__0\(10),
      I5 => \derivative1__0\(5),
      O => \derivative0__0_carry_i_5__0_n_0\
    );
\derivative0__0_carry_i_5__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(8),
      I1 => \derivative1__0\(13),
      I2 => \derivative1__0\(10),
      I3 => \derivative1__0\(11),
      I4 => \derivative1__0\(14),
      I5 => \derivative1__0\(9),
      O => \derivative0__0_carry_i_5__1_n_0\
    );
\derivative0__0_carry_i_5__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(12),
      I1 => \derivative1__0\(17),
      I2 => \derivative1__0\(14),
      I3 => \derivative1__0\(15),
      I4 => \derivative1__0\(18),
      I5 => \derivative1__0\(13),
      O => \derivative0__0_carry_i_5__2_n_0\
    );
\derivative0__0_carry_i_5__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(16),
      I1 => \derivative1__0\(21),
      I2 => \derivative1__0\(18),
      I3 => \derivative1__0\(19),
      I4 => \derivative1__0\(22),
      I5 => \derivative1__0\(17),
      O => \derivative0__0_carry_i_5__3_n_0\
    );
\derivative0__0_carry_i_5__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(20),
      I1 => \derivative1__0\(25),
      I2 => \derivative1__0\(22),
      I3 => \derivative1__0\(23),
      I4 => \derivative1__0\(26),
      I5 => \derivative1__0\(21),
      O => \derivative0__0_carry_i_5__4_n_0\
    );
\derivative0__0_carry_i_5__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(23),
      I1 => \derivative1__0\(28),
      I2 => \derivative1__0\(25),
      I3 => \derivative1__0\(26),
      I4 => \derivative1__0\(29),
      I5 => \derivative1__0\(24),
      O => \derivative0__0_carry_i_5__5_n_0\
    );
\derivative0__0_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => derivative1(0),
      I1 => \derivative1__0\(3),
      I2 => \derivative1__0\(4),
      I3 => derivative1(1),
      O => \derivative0__0_carry_i_6_n_0\
    );
\derivative0__0_carry_i_6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(3),
      I1 => \derivative1__0\(8),
      I2 => \derivative1__0\(5),
      I3 => \derivative1__0\(6),
      I4 => \derivative1__0\(9),
      I5 => \derivative1__0\(4),
      O => \derivative0__0_carry_i_6__0_n_0\
    );
\derivative0__0_carry_i_6__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(7),
      I1 => \derivative1__0\(12),
      I2 => \derivative1__0\(9),
      I3 => \derivative1__0\(10),
      I4 => \derivative1__0\(13),
      I5 => \derivative1__0\(8),
      O => \derivative0__0_carry_i_6__1_n_0\
    );
\derivative0__0_carry_i_6__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(11),
      I1 => \derivative1__0\(16),
      I2 => \derivative1__0\(13),
      I3 => \derivative1__0\(14),
      I4 => \derivative1__0\(17),
      I5 => \derivative1__0\(12),
      O => \derivative0__0_carry_i_6__2_n_0\
    );
\derivative0__0_carry_i_6__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(15),
      I1 => \derivative1__0\(20),
      I2 => \derivative1__0\(17),
      I3 => \derivative1__0\(18),
      I4 => \derivative1__0\(21),
      I5 => \derivative1__0\(16),
      O => \derivative0__0_carry_i_6__3_n_0\
    );
\derivative0__0_carry_i_6__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(19),
      I1 => \derivative1__0\(24),
      I2 => \derivative1__0\(21),
      I3 => \derivative1__0\(22),
      I4 => \derivative1__0\(25),
      I5 => \derivative1__0\(20),
      O => \derivative0__0_carry_i_6__4_n_0\
    );
\derivative0__0_carry_i_6__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(22),
      I1 => \derivative1__0\(27),
      I2 => \derivative1__0\(24),
      I3 => \derivative1__0\(25),
      I4 => \derivative1__0\(28),
      I5 => \derivative1__0\(23),
      O => \derivative0__0_carry_i_6__5_n_0\
    );
\derivative0__0_carry_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => derivative1(0),
      I1 => \derivative1__0\(3),
      O => \derivative0__0_carry_i_7_n_0\
    );
\derivative0__0_carry_i_7__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => derivative1(2),
      I1 => \derivative1__0\(7),
      I2 => \derivative1__0\(4),
      I3 => \derivative1__0\(5),
      I4 => \derivative1__0\(8),
      I5 => \derivative1__0\(3),
      O => \derivative0__0_carry_i_7__0_n_0\
    );
\derivative0__0_carry_i_7__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(6),
      I1 => \derivative1__0\(11),
      I2 => \derivative1__0\(8),
      I3 => \derivative1__0\(9),
      I4 => \derivative1__0\(12),
      I5 => \derivative1__0\(7),
      O => \derivative0__0_carry_i_7__1_n_0\
    );
\derivative0__0_carry_i_7__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(10),
      I1 => \derivative1__0\(15),
      I2 => \derivative1__0\(12),
      I3 => \derivative1__0\(13),
      I4 => \derivative1__0\(16),
      I5 => \derivative1__0\(11),
      O => \derivative0__0_carry_i_7__2_n_0\
    );
\derivative0__0_carry_i_7__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(14),
      I1 => \derivative1__0\(19),
      I2 => \derivative1__0\(16),
      I3 => \derivative1__0\(17),
      I4 => \derivative1__0\(20),
      I5 => \derivative1__0\(15),
      O => \derivative0__0_carry_i_7__3_n_0\
    );
\derivative0__0_carry_i_7__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(18),
      I1 => \derivative1__0\(23),
      I2 => \derivative1__0\(20),
      I3 => \derivative1__0\(21),
      I4 => \derivative1__0\(24),
      I5 => \derivative1__0\(19),
      O => \derivative0__0_carry_i_7__4_n_0\
    );
\derivative0__0_carry_i_7__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(21),
      I1 => \derivative1__0\(26),
      I2 => \derivative1__0\(23),
      I3 => \derivative1__0\(24),
      I4 => \derivative1__0\(27),
      I5 => \derivative1__0\(22),
      O => \derivative0__0_carry_i_7__5_n_0\
    );
\derivative0__0_carry_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => derivative1(1),
      I1 => \derivative1__0\(6),
      I2 => \derivative1__0\(3),
      I3 => \derivative1__0\(4),
      I4 => \derivative1__0\(7),
      I5 => derivative1(2),
      O => \derivative0__0_carry_i_8_n_0\
    );
\derivative0__0_carry_i_8__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(5),
      I1 => \derivative1__0\(10),
      I2 => \derivative1__0\(7),
      I3 => \derivative1__0\(8),
      I4 => \derivative1__0\(11),
      I5 => \derivative1__0\(6),
      O => \derivative0__0_carry_i_8__0_n_0\
    );
\derivative0__0_carry_i_8__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(9),
      I1 => \derivative1__0\(14),
      I2 => \derivative1__0\(11),
      I3 => \derivative1__0\(12),
      I4 => \derivative1__0\(15),
      I5 => \derivative1__0\(10),
      O => \derivative0__0_carry_i_8__1_n_0\
    );
\derivative0__0_carry_i_8__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(13),
      I1 => \derivative1__0\(18),
      I2 => \derivative1__0\(15),
      I3 => \derivative1__0\(16),
      I4 => \derivative1__0\(19),
      I5 => \derivative1__0\(14),
      O => \derivative0__0_carry_i_8__2_n_0\
    );
\derivative0__0_carry_i_8__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \derivative1__0\(17),
      I1 => \derivative1__0\(22),
      I2 => \derivative1__0\(19),
      I3 => \derivative1__0\(20),
      I4 => \derivative1__0\(23),
      I5 => \derivative1__0\(18),
      O => \derivative0__0_carry_i_8__3_n_0\
    );
derivative1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => derivative1_carry_n_0,
      CO(2) => derivative1_carry_n_1,
      CO(1) => derivative1_carry_n_2,
      CO(0) => derivative1_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => error(3 downto 0),
      O(3) => \derivative1__0\(3),
      O(2 downto 0) => derivative1(2 downto 0),
      S(3) => derivative1_carry_i_1_n_0,
      S(2) => derivative1_carry_i_2_n_0,
      S(1) => derivative1_carry_i_3_n_0,
      S(0) => derivative1_carry_i_4_n_0
    );
\derivative1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => derivative1_carry_n_0,
      CO(3) => \derivative1_carry__0_n_0\,
      CO(2) => \derivative1_carry__0_n_1\,
      CO(1) => \derivative1_carry__0_n_2\,
      CO(0) => \derivative1_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(7 downto 4),
      O(3 downto 0) => \derivative1__0\(7 downto 4),
      S(3) => \derivative1_carry__0_i_1_n_0\,
      S(2) => \derivative1_carry__0_i_2_n_0\,
      S(1) => \derivative1_carry__0_i_3_n_0\,
      S(0) => \derivative1_carry__0_i_4_n_0\
    );
\derivative1_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(7),
      I1 => error_prev(7),
      O => \derivative1_carry__0_i_1_n_0\
    );
\derivative1_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(6),
      I1 => error_prev(6),
      O => \derivative1_carry__0_i_2_n_0\
    );
\derivative1_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(5),
      I1 => error_prev(5),
      O => \derivative1_carry__0_i_3_n_0\
    );
\derivative1_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(4),
      I1 => error_prev(4),
      O => \derivative1_carry__0_i_4_n_0\
    );
\derivative1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__0_n_0\,
      CO(3) => \derivative1_carry__1_n_0\,
      CO(2) => \derivative1_carry__1_n_1\,
      CO(1) => \derivative1_carry__1_n_2\,
      CO(0) => \derivative1_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(11 downto 8),
      O(3 downto 0) => \derivative1__0\(11 downto 8),
      S(3) => \derivative1_carry__1_i_1_n_0\,
      S(2) => \derivative1_carry__1_i_2_n_0\,
      S(1) => \derivative1_carry__1_i_3_n_0\,
      S(0) => \derivative1_carry__1_i_4_n_0\
    );
\derivative1_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(11),
      I1 => error_prev(11),
      O => \derivative1_carry__1_i_1_n_0\
    );
\derivative1_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(10),
      I1 => error_prev(10),
      O => \derivative1_carry__1_i_2_n_0\
    );
\derivative1_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(9),
      I1 => error_prev(9),
      O => \derivative1_carry__1_i_3_n_0\
    );
\derivative1_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(8),
      I1 => error_prev(8),
      O => \derivative1_carry__1_i_4_n_0\
    );
\derivative1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__1_n_0\,
      CO(3) => \derivative1_carry__2_n_0\,
      CO(2) => \derivative1_carry__2_n_1\,
      CO(1) => \derivative1_carry__2_n_2\,
      CO(0) => \derivative1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(15 downto 12),
      O(3 downto 0) => \derivative1__0\(15 downto 12),
      S(3) => \derivative1_carry__2_i_1_n_0\,
      S(2) => \derivative1_carry__2_i_2_n_0\,
      S(1) => \derivative1_carry__2_i_3_n_0\,
      S(0) => \derivative1_carry__2_i_4_n_0\
    );
\derivative1_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(15),
      I1 => error_prev(15),
      O => \derivative1_carry__2_i_1_n_0\
    );
\derivative1_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(14),
      I1 => error_prev(14),
      O => \derivative1_carry__2_i_2_n_0\
    );
\derivative1_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(13),
      I1 => error_prev(13),
      O => \derivative1_carry__2_i_3_n_0\
    );
\derivative1_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(12),
      I1 => error_prev(12),
      O => \derivative1_carry__2_i_4_n_0\
    );
\derivative1_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__2_n_0\,
      CO(3) => \derivative1_carry__3_n_0\,
      CO(2) => \derivative1_carry__3_n_1\,
      CO(1) => \derivative1_carry__3_n_2\,
      CO(0) => \derivative1_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(19 downto 16),
      O(3 downto 0) => \derivative1__0\(19 downto 16),
      S(3) => \derivative1_carry__3_i_1_n_0\,
      S(2) => \derivative1_carry__3_i_2_n_0\,
      S(1) => \derivative1_carry__3_i_3_n_0\,
      S(0) => \derivative1_carry__3_i_4_n_0\
    );
\derivative1_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(19),
      I1 => error_prev(19),
      O => \derivative1_carry__3_i_1_n_0\
    );
\derivative1_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(18),
      I1 => error_prev(18),
      O => \derivative1_carry__3_i_2_n_0\
    );
\derivative1_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(17),
      I1 => error_prev(17),
      O => \derivative1_carry__3_i_3_n_0\
    );
\derivative1_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(16),
      I1 => error_prev(16),
      O => \derivative1_carry__3_i_4_n_0\
    );
\derivative1_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__3_n_0\,
      CO(3) => \derivative1_carry__4_n_0\,
      CO(2) => \derivative1_carry__4_n_1\,
      CO(1) => \derivative1_carry__4_n_2\,
      CO(0) => \derivative1_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(23 downto 20),
      O(3 downto 0) => \derivative1__0\(23 downto 20),
      S(3) => \derivative1_carry__4_i_1_n_0\,
      S(2) => \derivative1_carry__4_i_2_n_0\,
      S(1) => \derivative1_carry__4_i_3_n_0\,
      S(0) => \derivative1_carry__4_i_4_n_0\
    );
\derivative1_carry__4_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(23),
      I1 => error_prev(23),
      O => \derivative1_carry__4_i_1_n_0\
    );
\derivative1_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(22),
      I1 => error_prev(22),
      O => \derivative1_carry__4_i_2_n_0\
    );
\derivative1_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(21),
      I1 => error_prev(21),
      O => \derivative1_carry__4_i_3_n_0\
    );
\derivative1_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(20),
      I1 => error_prev(20),
      O => \derivative1_carry__4_i_4_n_0\
    );
\derivative1_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__4_n_0\,
      CO(3) => \derivative1_carry__5_n_0\,
      CO(2) => \derivative1_carry__5_n_1\,
      CO(1) => \derivative1_carry__5_n_2\,
      CO(0) => \derivative1_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(27 downto 24),
      O(3 downto 0) => \derivative1__0\(27 downto 24),
      S(3) => \derivative1_carry__5_i_1_n_0\,
      S(2) => \derivative1_carry__5_i_2_n_0\,
      S(1) => \derivative1_carry__5_i_3_n_0\,
      S(0) => \derivative1_carry__5_i_4_n_0\
    );
\derivative1_carry__5_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(27),
      I1 => error_prev(27),
      O => \derivative1_carry__5_i_1_n_0\
    );
\derivative1_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(26),
      I1 => error_prev(26),
      O => \derivative1_carry__5_i_2_n_0\
    );
\derivative1_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(25),
      I1 => error_prev(25),
      O => \derivative1_carry__5_i_3_n_0\
    );
\derivative1_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(24),
      I1 => error_prev(24),
      O => \derivative1_carry__5_i_4_n_0\
    );
\derivative1_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1_carry__5_n_0\,
      CO(3 downto 2) => \NLW_derivative1_carry__6_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative1_carry__6_n_2\,
      CO(0) => \derivative1_carry__6_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => error(29 downto 28),
      O(3) => \NLW_derivative1_carry__6_O_UNCONNECTED\(3),
      O(2 downto 0) => \derivative1__0\(30 downto 28),
      S(3) => '0',
      S(2) => \derivative1_carry__6_i_1_n_0\,
      S(1) => \derivative1_carry__6_i_2_n_0\,
      S(0) => \derivative1_carry__6_i_3_n_0\
    );
\derivative1_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(30),
      I1 => error_prev(30),
      O => \derivative1_carry__6_i_1_n_0\
    );
\derivative1_carry__6_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(29),
      I1 => error_prev(29),
      O => \derivative1_carry__6_i_2_n_0\
    );
\derivative1_carry__6_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(28),
      I1 => error_prev(28),
      O => \derivative1_carry__6_i_3_n_0\
    );
derivative1_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(3),
      I1 => error_prev(3),
      O => derivative1_carry_i_1_n_0
    );
derivative1_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(2),
      I1 => error_prev(2),
      O => derivative1_carry_i_2_n_0
    );
derivative1_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(1),
      I1 => error_prev(1),
      O => derivative1_carry_i_3_n_0
    );
derivative1_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(0),
      I1 => error_prev(0),
      O => derivative1_carry_i_4_n_0
    );
error0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => error0_carry_n_0,
      CO(2) => error0_carry_n_1,
      CO(1) => error0_carry_n_2,
      CO(0) => error0_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => saved_target_angle(3 downto 0),
      O(3 downto 0) => error0(3 downto 0),
      S(3) => error0_carry_i_1_n_0,
      S(2) => error0_carry_i_2_n_0,
      S(1) => error0_carry_i_3_n_0,
      S(0) => error0_carry_i_4_n_0
    );
\error0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => error0_carry_n_0,
      CO(3) => \error0_carry__0_n_0\,
      CO(2) => \error0_carry__0_n_1\,
      CO(1) => \error0_carry__0_n_2\,
      CO(0) => \error0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(7 downto 4),
      O(3 downto 0) => error0(7 downto 4),
      S(3) => \error0_carry_i_1__0_n_0\,
      S(2) => \error0_carry_i_2__0_n_0\,
      S(1) => \error0_carry_i_3__0_n_0\,
      S(0) => \error0_carry_i_4__0_n_0\
    );
\error0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__0_n_0\,
      CO(3) => \error0_carry__1_n_0\,
      CO(2) => \error0_carry__1_n_1\,
      CO(1) => \error0_carry__1_n_2\,
      CO(0) => \error0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(11 downto 8),
      O(3 downto 0) => error0(11 downto 8),
      S(3) => \error0_carry_i_1__1_n_0\,
      S(2) => \error0_carry_i_2__1_n_0\,
      S(1) => \error0_carry_i_3__1_n_0\,
      S(0) => \error0_carry_i_4__1_n_0\
    );
\error0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__1_n_0\,
      CO(3) => \error0_carry__2_n_0\,
      CO(2) => \error0_carry__2_n_1\,
      CO(1) => \error0_carry__2_n_2\,
      CO(0) => \error0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(15 downto 12),
      O(3 downto 0) => error0(15 downto 12),
      S(3) => \error0_carry_i_1__2_n_0\,
      S(2) => \error0_carry_i_2__2_n_0\,
      S(1) => \error0_carry_i_3__2_n_0\,
      S(0) => \error0_carry_i_4__2_n_0\
    );
\error0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__2_n_0\,
      CO(3) => \error0_carry__3_n_0\,
      CO(2) => \error0_carry__3_n_1\,
      CO(1) => \error0_carry__3_n_2\,
      CO(0) => \error0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(19 downto 16),
      O(3 downto 0) => error0(19 downto 16),
      S(3) => \error0_carry_i_1__3_n_0\,
      S(2) => \error0_carry_i_2__3_n_0\,
      S(1) => \error0_carry_i_3__3_n_0\,
      S(0) => \error0_carry_i_4__3_n_0\
    );
\error0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__3_n_0\,
      CO(3) => \error0_carry__4_n_0\,
      CO(2) => \error0_carry__4_n_1\,
      CO(1) => \error0_carry__4_n_2\,
      CO(0) => \error0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(23 downto 20),
      O(3 downto 0) => error0(23 downto 20),
      S(3) => \error0_carry_i_1__4_n_0\,
      S(2) => \error0_carry_i_2__4_n_0\,
      S(1) => \error0_carry_i_3__4_n_0\,
      S(0) => \error0_carry_i_4__4_n_0\
    );
\error0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__4_n_0\,
      CO(3) => \error0_carry__5_n_0\,
      CO(2) => \error0_carry__5_n_1\,
      CO(1) => \error0_carry__5_n_2\,
      CO(0) => \error0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => saved_target_angle(27 downto 24),
      O(3 downto 0) => error0(27 downto 24),
      S(3) => \error0_carry_i_1__5_n_0\,
      S(2) => \error0_carry_i_2__5_n_0\,
      S(1) => \error0_carry_i_3__5_n_0\,
      S(0) => \error0_carry_i_4__5_n_0\
    );
\error0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__5_n_0\,
      CO(3) => \NLW_error0_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \error0_carry__6_n_1\,
      CO(1) => \error0_carry__6_n_2\,
      CO(0) => \error0_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => saved_target_angle(30 downto 28),
      O(3 downto 0) => error0(31 downto 28),
      S(3) => \error0_carry_i_1__6_n_0\,
      S(2) => \error0_carry_i_2__6_n_0\,
      S(1) => \error0_carry_i_3__6_n_0\,
      S(0) => \error0_carry_i_4__6_n_0\
    );
error0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(3),
      I1 => angle(3),
      O => error0_carry_i_1_n_0
    );
\error0_carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(7),
      I1 => angle(7),
      O => \error0_carry_i_1__0_n_0\
    );
\error0_carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(11),
      I1 => angle(11),
      O => \error0_carry_i_1__1_n_0\
    );
\error0_carry_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(15),
      I1 => angle(15),
      O => \error0_carry_i_1__2_n_0\
    );
\error0_carry_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(19),
      I1 => angle(19),
      O => \error0_carry_i_1__3_n_0\
    );
\error0_carry_i_1__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(23),
      I1 => angle(23),
      O => \error0_carry_i_1__4_n_0\
    );
\error0_carry_i_1__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(27),
      I1 => angle(27),
      O => \error0_carry_i_1__5_n_0\
    );
\error0_carry_i_1__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(31),
      I1 => angle(31),
      O => \error0_carry_i_1__6_n_0\
    );
error0_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(2),
      I1 => angle(2),
      O => error0_carry_i_2_n_0
    );
\error0_carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(6),
      I1 => angle(6),
      O => \error0_carry_i_2__0_n_0\
    );
\error0_carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(10),
      I1 => angle(10),
      O => \error0_carry_i_2__1_n_0\
    );
\error0_carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(14),
      I1 => angle(14),
      O => \error0_carry_i_2__2_n_0\
    );
\error0_carry_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(18),
      I1 => angle(18),
      O => \error0_carry_i_2__3_n_0\
    );
\error0_carry_i_2__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(22),
      I1 => angle(22),
      O => \error0_carry_i_2__4_n_0\
    );
\error0_carry_i_2__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(26),
      I1 => angle(26),
      O => \error0_carry_i_2__5_n_0\
    );
\error0_carry_i_2__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(30),
      I1 => angle(30),
      O => \error0_carry_i_2__6_n_0\
    );
error0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(1),
      I1 => angle(1),
      O => error0_carry_i_3_n_0
    );
\error0_carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(5),
      I1 => angle(5),
      O => \error0_carry_i_3__0_n_0\
    );
\error0_carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(9),
      I1 => angle(9),
      O => \error0_carry_i_3__1_n_0\
    );
\error0_carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(13),
      I1 => angle(13),
      O => \error0_carry_i_3__2_n_0\
    );
\error0_carry_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(17),
      I1 => angle(17),
      O => \error0_carry_i_3__3_n_0\
    );
\error0_carry_i_3__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(21),
      I1 => angle(21),
      O => \error0_carry_i_3__4_n_0\
    );
\error0_carry_i_3__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(25),
      I1 => angle(25),
      O => \error0_carry_i_3__5_n_0\
    );
\error0_carry_i_3__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(29),
      I1 => angle(29),
      O => \error0_carry_i_3__6_n_0\
    );
error0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(0),
      I1 => angle(0),
      O => error0_carry_i_4_n_0
    );
\error0_carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(4),
      I1 => angle(4),
      O => \error0_carry_i_4__0_n_0\
    );
\error0_carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(8),
      I1 => angle(8),
      O => \error0_carry_i_4__1_n_0\
    );
\error0_carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(12),
      I1 => angle(12),
      O => \error0_carry_i_4__2_n_0\
    );
\error0_carry_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(16),
      I1 => angle(16),
      O => \error0_carry_i_4__3_n_0\
    );
\error0_carry_i_4__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(20),
      I1 => angle(20),
      O => \error0_carry_i_4__4_n_0\
    );
\error0_carry_i_4__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(24),
      I1 => angle(24),
      O => \error0_carry_i_4__5_n_0\
    );
\error0_carry_i_4__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => saved_target_angle(28),
      I1 => angle(28),
      O => \error0_carry_i_4__6_n_0\
    );
\error_prev_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(0),
      Q => error_prev(0),
      R => '0'
    );
\error_prev_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(10),
      Q => error_prev(10),
      R => '0'
    );
\error_prev_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(11),
      Q => error_prev(11),
      R => '0'
    );
\error_prev_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(12),
      Q => error_prev(12),
      R => '0'
    );
\error_prev_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(13),
      Q => error_prev(13),
      R => '0'
    );
\error_prev_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(14),
      Q => error_prev(14),
      R => '0'
    );
\error_prev_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(15),
      Q => error_prev(15),
      R => '0'
    );
\error_prev_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(16),
      Q => error_prev(16),
      R => '0'
    );
\error_prev_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(17),
      Q => error_prev(17),
      R => '0'
    );
\error_prev_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(18),
      Q => error_prev(18),
      R => '0'
    );
\error_prev_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(19),
      Q => error_prev(19),
      R => '0'
    );
\error_prev_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(1),
      Q => error_prev(1),
      R => '0'
    );
\error_prev_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(20),
      Q => error_prev(20),
      R => '0'
    );
\error_prev_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(21),
      Q => error_prev(21),
      R => '0'
    );
\error_prev_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(22),
      Q => error_prev(22),
      R => '0'
    );
\error_prev_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(23),
      Q => error_prev(23),
      R => '0'
    );
\error_prev_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(24),
      Q => error_prev(24),
      R => '0'
    );
\error_prev_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(25),
      Q => error_prev(25),
      R => '0'
    );
\error_prev_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(26),
      Q => error_prev(26),
      R => '0'
    );
\error_prev_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(27),
      Q => error_prev(27),
      R => '0'
    );
\error_prev_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(28),
      Q => error_prev(28),
      R => '0'
    );
\error_prev_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(29),
      Q => error_prev(29),
      R => '0'
    );
\error_prev_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(2),
      Q => error_prev(2),
      R => '0'
    );
\error_prev_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(30),
      Q => error_prev(30),
      R => '0'
    );
\error_prev_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(3),
      Q => error_prev(3),
      R => '0'
    );
\error_prev_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(4),
      Q => error_prev(4),
      R => '0'
    );
\error_prev_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(5),
      Q => error_prev(5),
      R => '0'
    );
\error_prev_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(6),
      Q => error_prev(6),
      R => '0'
    );
\error_prev_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(7),
      Q => error_prev(7),
      R => '0'
    );
\error_prev_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(8),
      Q => error_prev(8),
      R => '0'
    );
\error_prev_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error(9),
      Q => error_prev(9),
      R => '0'
    );
\error_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(0),
      Q => error(0),
      R => '0'
    );
\error_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(10),
      Q => error(10),
      R => '0'
    );
\error_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(11),
      Q => error(11),
      R => '0'
    );
\error_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(12),
      Q => error(12),
      R => '0'
    );
\error_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(13),
      Q => error(13),
      R => '0'
    );
\error_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(14),
      Q => error(14),
      R => '0'
    );
\error_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(15),
      Q => error(15),
      R => '0'
    );
\error_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(16),
      Q => error(16),
      R => '0'
    );
\error_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(17),
      Q => error(17),
      R => '0'
    );
\error_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(18),
      Q => error(18),
      R => '0'
    );
\error_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(19),
      Q => error(19),
      R => '0'
    );
\error_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(1),
      Q => error(1),
      R => '0'
    );
\error_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(20),
      Q => error(20),
      R => '0'
    );
\error_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(21),
      Q => error(21),
      R => '0'
    );
\error_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(22),
      Q => error(22),
      R => '0'
    );
\error_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(23),
      Q => error(23),
      R => '0'
    );
\error_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(24),
      Q => error(24),
      R => '0'
    );
\error_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(25),
      Q => error(25),
      R => '0'
    );
\error_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(26),
      Q => error(26),
      R => '0'
    );
\error_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(27),
      Q => error(27),
      R => '0'
    );
\error_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(28),
      Q => error(28),
      R => '0'
    );
\error_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(29),
      Q => error(29),
      R => '0'
    );
\error_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(2),
      Q => error(2),
      R => '0'
    );
\error_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(30),
      Q => error(30),
      R => '0'
    );
\error_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(31),
      Q => error(31),
      R => '0'
    );
\error_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(3),
      Q => error(3),
      R => '0'
    );
\error_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(4),
      Q => error(4),
      R => '0'
    );
\error_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(5),
      Q => error(5),
      R => '0'
    );
\error_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(6),
      Q => error(6),
      R => '0'
    );
\error_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(7),
      Q => error(7),
      R => '0'
    );
\error_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(8),
      Q => error(8),
      R => '0'
    );
\error_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => error0(9),
      Q => error(9),
      R => '0'
    );
\i__carry_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_4_n_7\,
      I1 => \i__carry_i_4_n_6\,
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_10\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[40]\,
      O => \i__carry_i_10_n_0\
    );
\i__carry_i_10__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[32]\,
      O => \i__carry_i_10__0_n_0\
    );
\i__carry_i_10__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_10__1_n_0\
    );
\i__carry_i_10__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_10__2_n_0\
    );
\i__carry_i_10__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_10__3_n_0\
    );
\i__carry_i_10__4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_10__4_n_0\
    );
\i__carry_i_10__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(6),
      I1 => \interim_velocity_reg_n_0_[6]\,
      O => \i__carry_i_10__5_n_0\
    );
\i__carry_i_10__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(16),
      I1 => \interim_velocity_reg_n_0_[16]\,
      O => \i__carry_i_10__6_n_0\
    );
\i__carry_i_10__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(24),
      I1 => \interim_velocity_reg_n_0_[24]\,
      O => \i__carry_i_10__7_n_0\
    );
\i__carry_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[39]\,
      O => \i__carry_i_11_n_0\
    );
\i__carry_i_11__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_11__0_n_0\
    );
\i__carry_i_11__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_11__1_n_0\
    );
\i__carry_i_11__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_11__2_n_0\
    );
\i__carry_i_11__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_11__3_n_0\
    );
\i__carry_i_11__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(5),
      I1 => \interim_velocity_reg_n_0_[5]\,
      O => \i__carry_i_11__4_n_0\
    );
\i__carry_i_11__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(15),
      I1 => \interim_velocity_reg_n_0_[15]\,
      O => \i__carry_i_11__5_n_0\
    );
\i__carry_i_11__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(23),
      I1 => \interim_velocity_reg_n_0_[23]\,
      O => \i__carry_i_11__6_n_0\
    );
\i__carry_i_11__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(31),
      I1 => \interim_velocity_reg_n_0_[31]\,
      O => \i__carry_i_11__7_n_0\
    );
\i__carry_i_12\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[38]\,
      O => \i__carry_i_12_n_0\
    );
\i__carry_i_12__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_12__0_n_0\
    );
\i__carry_i_12__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_12__1_n_0\
    );
\i__carry_i_12__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_12__2_n_0\
    );
\i__carry_i_12__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(4),
      I1 => \interim_velocity_reg_n_0_[4]\,
      O => \i__carry_i_12__3_n_0\
    );
\i__carry_i_12__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(14),
      I1 => \interim_velocity_reg_n_0_[14]\,
      O => \i__carry_i_12__4_n_0\
    );
\i__carry_i_12__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(22),
      I1 => \interim_velocity_reg_n_0_[22]\,
      O => \i__carry_i_12__5_n_0\
    );
\i__carry_i_12__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(30),
      I1 => \interim_velocity_reg_n_0_[30]\,
      O => \i__carry_i_12__6_n_0\
    );
\i__carry_i_13\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[37]\,
      O => \i__carry_i_13_n_0\
    );
\i__carry_i_13__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_13__0_n_0\
    );
\i__carry_i_13__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_13__1_n_0\
    );
\i__carry_i_13__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_13__2_n_0\
    );
\i__carry_i_13__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(11),
      I1 => \interim_velocity_reg_n_0_[11]\,
      O => \i__carry_i_13__3_n_0\
    );
\i__carry_i_13__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(13),
      I1 => \interim_velocity_reg_n_0_[13]\,
      O => \i__carry_i_13__4_n_0\
    );
\i__carry_i_13__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(21),
      I1 => \interim_velocity_reg_n_0_[21]\,
      O => \i__carry_i_13__5_n_0\
    );
\i__carry_i_13__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(29),
      I1 => \interim_velocity_reg_n_0_[29]\,
      O => \i__carry_i_13__6_n_0\
    );
\i__carry_i_14\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[36]\,
      O => \i__carry_i_14_n_0\
    );
\i__carry_i_14__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_14__0_n_0\
    );
\i__carry_i_14__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_14__1_n_0\
    );
\i__carry_i_14__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_14__2_n_0\
    );
\i__carry_i_14__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(10),
      I1 => \interim_velocity_reg_n_0_[10]\,
      O => \i__carry_i_14__3_n_0\
    );
\i__carry_i_14__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(12),
      I1 => \interim_velocity_reg_n_0_[12]\,
      O => \i__carry_i_14__4_n_0\
    );
\i__carry_i_14__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(20),
      I1 => \interim_velocity_reg_n_0_[20]\,
      O => \i__carry_i_14__5_n_0\
    );
\i__carry_i_14__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(28),
      I1 => \interim_velocity_reg_n_0_[28]\,
      O => \i__carry_i_14__6_n_0\
    );
\i__carry_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(9),
      I1 => \interim_velocity_reg_n_0_[9]\,
      O => \i__carry_i_15_n_0\
    );
\i__carry_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(8),
      I1 => \interim_velocity_reg_n_0_[8]\,
      O => \i__carry_i_16_n_0\
    );
\i__carry_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(3),
      I1 => \interim_velocity_reg_n_0_[3]\,
      O => \i__carry_i_17_n_0\
    );
\i__carry_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(2),
      I1 => \interim_velocity_reg_n_0_[2]\,
      O => \i__carry_i_18_n_0\
    );
\i__carry_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(1),
      I1 => \interim_velocity_reg_n_0_[1]\,
      O => \i__carry_i_19_n_0\
    );
\i__carry_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__5_n_5\,
      I1 => \i__carry_i_5__5_n_4\,
      O => \i__carry_i_1__0_n_0\
    );
\i__carry_i_1__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__4_n_5\,
      I1 => \i__carry_i_5__4_n_4\,
      O => \i__carry_i_1__1_n_0\
    );
\i__carry_i_1__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__3_n_5\,
      I1 => \i__carry_i_5__3_n_4\,
      O => \i__carry_i_1__2_n_0\
    );
\i__carry_i_1__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__2_n_5\,
      I1 => \i__carry_i_5__2_n_4\,
      O => \i__carry_i_1__3_n_0\
    );
\i__carry_i_1__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__1_n_5\,
      I1 => \i__carry_i_5__1_n_4\,
      O => \i__carry_i_1__4_n_0\
    );
\i__carry_i_1__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__0_n_5\,
      I1 => \i__carry_i_5__0_n_4\,
      O => \i__carry_i_1__5_n_0\
    );
\i__carry_i_1__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5_n_5\,
      I1 => \i__carry_i_5_n_4\,
      O => \i__carry_i_1__6_n_0\
    );
\i__carry_i_1__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6_n_7\,
      I1 => \i__carry_i_6_n_6\,
      O => \i__carry_i_1__7_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__6_n_5\,
      I1 => \i__carry_i_5__6_n_4\,
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(0),
      I1 => \interim_velocity_reg_n_0_[0]\,
      O => \i__carry_i_20_n_0\
    );
\i__carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__5_n_7\,
      I1 => \i__carry_i_5__5_n_6\,
      O => \i__carry_i_2__0_n_0\
    );
\i__carry_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__4_n_7\,
      I1 => \i__carry_i_5__4_n_6\,
      O => \i__carry_i_2__1_n_0\
    );
\i__carry_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__3_n_7\,
      I1 => \i__carry_i_5__3_n_6\,
      O => \i__carry_i_2__2_n_0\
    );
\i__carry_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__2_n_7\,
      I1 => \i__carry_i_5__2_n_6\,
      O => \i__carry_i_2__3_n_0\
    );
\i__carry_i_2__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__1_n_7\,
      I1 => \i__carry_i_5__1_n_6\,
      O => \i__carry_i_2__4_n_0\
    );
\i__carry_i_2__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__0_n_7\,
      I1 => \i__carry_i_5__0_n_6\,
      O => \i__carry_i_2__5_n_0\
    );
\i__carry_i_2__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5_n_7\,
      I1 => \i__carry_i_5_n_6\,
      O => \i__carry_i_2__6_n_0\
    );
\i__carry_i_2__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_7_n_5\,
      I1 => \i__carry_i_7_n_4\,
      O => \i__carry_i_2__7_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_5__6_n_7\,
      I1 => \i__carry_i_5__6_n_6\,
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__6_n_5\,
      I1 => \i__carry_i_6__6_n_4\,
      O => \i__carry_i_3__0_n_0\
    );
\i__carry_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__5_n_5\,
      I1 => \i__carry_i_6__5_n_4\,
      O => \i__carry_i_3__1_n_0\
    );
\i__carry_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__4_n_5\,
      I1 => \i__carry_i_6__4_n_4\,
      O => \i__carry_i_3__2_n_0\
    );
\i__carry_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__3_n_5\,
      I1 => \i__carry_i_6__3_n_4\,
      O => \i__carry_i_3__3_n_0\
    );
\i__carry_i_3__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__2_n_5\,
      I1 => \i__carry_i_6__2_n_4\,
      O => \i__carry_i_3__4_n_0\
    );
\i__carry_i_3__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__1_n_5\,
      I1 => \i__carry_i_6__1_n_4\,
      O => \i__carry_i_3__5_n_0\
    );
\i__carry_i_3__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__0_n_5\,
      I1 => \i__carry_i_6__0_n_4\,
      O => \i__carry_i_3__6_n_0\
    );
\i__carry_i_3__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_7_n_7\,
      I1 => \i__carry_i_7_n_6\,
      O => \i__carry_i_3__7_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5__6_n_0\,
      CO(3 downto 1) => \NLW_i__carry_i_4_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \i__carry_i_4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_i__carry_i_4_O_UNCONNECTED\(3 downto 2),
      O(1) => \i__carry_i_4_n_6\,
      O(0) => \i__carry_i_4_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \i__carry_i_6__7_n_0\,
      S(0) => \i__carry_i_7__5_n_0\
    );
\i__carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__6_n_7\,
      I1 => \i__carry_i_6__6_n_6\,
      O => \i__carry_i_4__0_n_0\
    );
\i__carry_i_4__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__5_n_7\,
      I1 => \i__carry_i_6__5_n_6\,
      O => \i__carry_i_4__1_n_0\
    );
\i__carry_i_4__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__4_n_7\,
      I1 => \i__carry_i_6__4_n_6\,
      O => \i__carry_i_4__2_n_0\
    );
\i__carry_i_4__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__3_n_7\,
      I1 => \i__carry_i_6__3_n_6\,
      O => \i__carry_i_4__3_n_0\
    );
\i__carry_i_4__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__2_n_7\,
      I1 => \i__carry_i_6__2_n_6\,
      O => \i__carry_i_4__4_n_0\
    );
\i__carry_i_4__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__1_n_7\,
      I1 => \i__carry_i_6__1_n_6\,
      O => \i__carry_i_4__5_n_0\
    );
\i__carry_i_4__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6__0_n_7\,
      I1 => \i__carry_i_6__0_n_6\,
      O => \i__carry_i_4__6_n_0\
    );
\i__carry_i_4__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i__carry_i_6_n_5\,
      I1 => \i__carry_i_6_n_4\,
      O => \i__carry_i_4__7_n_0\
    );
\i__carry_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6__0_n_0\,
      CO(3) => \i__carry_i_5_n_0\,
      CO(2) => \i__carry_i_5_n_1\,
      CO(1) => \i__carry_i_5_n_2\,
      CO(0) => \i__carry_i_5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(19 downto 16),
      O(3) => \i__carry_i_5_n_4\,
      O(2) => \i__carry_i_5_n_5\,
      O(1) => \i__carry_i_5_n_6\,
      O(0) => \i__carry_i_5_n_7\,
      S(3) => \i__carry_i_7__6_n_0\,
      S(2) => \i__carry_i_8__6_n_0\,
      S(1) => \i__carry_i_9__6_n_0\,
      S(0) => \i__carry_i_10__6_n_0\
    );
\i__carry_i_5__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6__1_n_0\,
      CO(3) => \i__carry_i_5__0_n_0\,
      CO(2) => \i__carry_i_5__0_n_1\,
      CO(1) => \i__carry_i_5__0_n_2\,
      CO(0) => \i__carry_i_5__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(27 downto 24),
      O(3) => \i__carry_i_5__0_n_4\,
      O(2) => \i__carry_i_5__0_n_5\,
      O(1) => \i__carry_i_5__0_n_6\,
      O(0) => \i__carry_i_5__0_n_7\,
      S(3) => \i__carry_i_7__7_n_0\,
      S(2) => \i__carry_i_8__7_n_0\,
      S(1) => \i__carry_i_9__7_n_0\,
      S(0) => \i__carry_i_10__7_n_0\
    );
\i__carry_i_5__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6__2_n_0\,
      CO(3) => \i__carry_i_5__1_n_0\,
      CO(2) => \i__carry_i_5__1_n_1\,
      CO(1) => \i__carry_i_5__1_n_2\,
      CO(0) => \i__carry_i_5__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_5__1_n_4\,
      O(2) => \i__carry_i_5__1_n_5\,
      O(1) => \i__carry_i_5__1_n_6\,
      O(0) => \i__carry_i_5__1_n_7\,
      S(3) => \i__carry_i_7__0_n_0\,
      S(2) => \i__carry_i_8__0_n_0\,
      S(1) => \i__carry_i_9__0_n_0\,
      S(0) => \i__carry_i_10__0_n_0\
    );
\i__carry_i_5__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6__3_n_0\,
      CO(3) => \i__carry_i_5__2_n_0\,
      CO(2) => \i__carry_i_5__2_n_1\,
      CO(1) => \i__carry_i_5__2_n_2\,
      CO(0) => \i__carry_i_5__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_5__2_n_4\,
      O(2) => \i__carry_i_5__2_n_5\,
      O(1) => \i__carry_i_5__2_n_6\,
      O(0) => \i__carry_i_5__2_n_7\,
      S(3) => \i__carry_i_7__1_n_0\,
      S(2) => \i__carry_i_8__1_n_0\,
      S(1) => \i__carry_i_9_n_0\,
      S(0) => \i__carry_i_10_n_0\
    );
\i__carry_i_5__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6__4_n_0\,
      CO(3) => \i__carry_i_5__3_n_0\,
      CO(2) => \i__carry_i_5__3_n_1\,
      CO(1) => \i__carry_i_5__3_n_2\,
      CO(0) => \i__carry_i_5__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_5__3_n_4\,
      O(2) => \i__carry_i_5__3_n_5\,
      O(1) => \i__carry_i_5__3_n_6\,
      O(0) => \i__carry_i_5__3_n_7\,
      S(3) => \i__carry_i_7__2_n_0\,
      S(2) => \i__carry_i_8__2_n_0\,
      S(1) => \i__carry_i_9__1_n_0\,
      S(0) => \i__carry_i_10__1_n_0\
    );
\i__carry_i_5__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6__5_n_0\,
      CO(3) => \i__carry_i_5__4_n_0\,
      CO(2) => \i__carry_i_5__4_n_1\,
      CO(1) => \i__carry_i_5__4_n_2\,
      CO(0) => \i__carry_i_5__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_5__4_n_4\,
      O(2) => \i__carry_i_5__4_n_5\,
      O(1) => \i__carry_i_5__4_n_6\,
      O(0) => \i__carry_i_5__4_n_7\,
      S(3) => \i__carry_i_7__3_n_0\,
      S(2) => \i__carry_i_8__3_n_0\,
      S(1) => \i__carry_i_9__2_n_0\,
      S(0) => \i__carry_i_10__2_n_0\
    );
\i__carry_i_5__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6__6_n_0\,
      CO(3) => \i__carry_i_5__5_n_0\,
      CO(2) => \i__carry_i_5__5_n_1\,
      CO(1) => \i__carry_i_5__5_n_2\,
      CO(0) => \i__carry_i_5__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_5__5_n_4\,
      O(2) => \i__carry_i_5__5_n_5\,
      O(1) => \i__carry_i_5__5_n_6\,
      O(0) => \i__carry_i_5__5_n_7\,
      S(3) => \i__carry_i_7__4_n_0\,
      S(2) => \i__carry_i_8__4_n_0\,
      S(1) => \i__carry_i_9__3_n_0\,
      S(0) => \i__carry_i_10__3_n_0\
    );
\i__carry_i_5__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5__5_n_0\,
      CO(3) => \i__carry_i_5__6_n_0\,
      CO(2) => \i__carry_i_5__6_n_1\,
      CO(1) => \i__carry_i_5__6_n_2\,
      CO(0) => \i__carry_i_5__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_5__6_n_4\,
      O(2) => \i__carry_i_5__6_n_5\,
      O(1) => \i__carry_i_5__6_n_6\,
      O(0) => \i__carry_i_5__6_n_7\,
      S(3) => \i__carry_i_8__5_n_0\,
      S(2) => \i__carry_i_9__4_n_0\,
      S(1) => \i__carry_i_10__4_n_0\,
      S(0) => \i__carry_i_11__3_n_0\
    );
\i__carry_i_5__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \i__carry_i_6_n_7\,
      I1 => \i__carry_i_6_n_6\,
      O => \i__carry_i_5__7_n_0\
    );
\i__carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_8_n_0\,
      CO(3) => \i__carry_i_6_n_0\,
      CO(2) => \i__carry_i_6_n_1\,
      CO(1) => \i__carry_i_6_n_2\,
      CO(0) => \i__carry_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(7 downto 4),
      O(3) => \i__carry_i_6_n_4\,
      O(2) => \i__carry_i_6_n_5\,
      O(1) => \i__carry_i_6_n_6\,
      O(0) => \i__carry_i_6_n_7\,
      S(3) => \i__carry_i_9__5_n_0\,
      S(2) => \i__carry_i_10__5_n_0\,
      S(1) => \i__carry_i_11__4_n_0\,
      S(0) => \i__carry_i_12__3_n_0\
    );
\i__carry_i_6__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_7_n_0\,
      CO(3) => \i__carry_i_6__0_n_0\,
      CO(2) => \i__carry_i_6__0_n_1\,
      CO(1) => \i__carry_i_6__0_n_2\,
      CO(0) => \i__carry_i_6__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(15 downto 12),
      O(3) => \i__carry_i_6__0_n_4\,
      O(2) => \i__carry_i_6__0_n_5\,
      O(1) => \i__carry_i_6__0_n_6\,
      O(0) => \i__carry_i_6__0_n_7\,
      S(3) => \i__carry_i_11__5_n_0\,
      S(2) => \i__carry_i_12__4_n_0\,
      S(1) => \i__carry_i_13__4_n_0\,
      S(0) => \i__carry_i_14__4_n_0\
    );
\i__carry_i_6__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5_n_0\,
      CO(3) => \i__carry_i_6__1_n_0\,
      CO(2) => \i__carry_i_6__1_n_1\,
      CO(1) => \i__carry_i_6__1_n_2\,
      CO(0) => \i__carry_i_6__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(23 downto 20),
      O(3) => \i__carry_i_6__1_n_4\,
      O(2) => \i__carry_i_6__1_n_5\,
      O(1) => \i__carry_i_6__1_n_6\,
      O(0) => \i__carry_i_6__1_n_7\,
      S(3) => \i__carry_i_11__6_n_0\,
      S(2) => \i__carry_i_12__5_n_0\,
      S(1) => \i__carry_i_13__5_n_0\,
      S(0) => \i__carry_i_14__5_n_0\
    );
\i__carry_i_6__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5__0_n_0\,
      CO(3) => \i__carry_i_6__2_n_0\,
      CO(2) => \i__carry_i_6__2_n_1\,
      CO(1) => \i__carry_i_6__2_n_2\,
      CO(0) => \i__carry_i_6__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(31 downto 28),
      O(3) => \i__carry_i_6__2_n_4\,
      O(2) => \i__carry_i_6__2_n_5\,
      O(1) => \i__carry_i_6__2_n_6\,
      O(0) => \i__carry_i_6__2_n_7\,
      S(3) => \i__carry_i_11__7_n_0\,
      S(2) => \i__carry_i_12__6_n_0\,
      S(1) => \i__carry_i_13__6_n_0\,
      S(0) => \i__carry_i_14__6_n_0\
    );
\i__carry_i_6__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5__1_n_0\,
      CO(3) => \i__carry_i_6__3_n_0\,
      CO(2) => \i__carry_i_6__3_n_1\,
      CO(1) => \i__carry_i_6__3_n_2\,
      CO(0) => \i__carry_i_6__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_6__3_n_4\,
      O(2) => \i__carry_i_6__3_n_5\,
      O(1) => \i__carry_i_6__3_n_6\,
      O(0) => \i__carry_i_6__3_n_7\,
      S(3) => \i__carry_i_11_n_0\,
      S(2) => \i__carry_i_12_n_0\,
      S(1) => \i__carry_i_13_n_0\,
      S(0) => \i__carry_i_14_n_0\
    );
\i__carry_i_6__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5__2_n_0\,
      CO(3) => \i__carry_i_6__4_n_0\,
      CO(2) => \i__carry_i_6__4_n_1\,
      CO(1) => \i__carry_i_6__4_n_2\,
      CO(0) => \i__carry_i_6__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_6__4_n_4\,
      O(2) => \i__carry_i_6__4_n_5\,
      O(1) => \i__carry_i_6__4_n_6\,
      O(0) => \i__carry_i_6__4_n_7\,
      S(3) => \i__carry_i_11__0_n_0\,
      S(2) => \i__carry_i_12__0_n_0\,
      S(1) => \i__carry_i_13__0_n_0\,
      S(0) => \i__carry_i_14__0_n_0\
    );
\i__carry_i_6__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5__3_n_0\,
      CO(3) => \i__carry_i_6__5_n_0\,
      CO(2) => \i__carry_i_6__5_n_1\,
      CO(1) => \i__carry_i_6__5_n_2\,
      CO(0) => \i__carry_i_6__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_6__5_n_4\,
      O(2) => \i__carry_i_6__5_n_5\,
      O(1) => \i__carry_i_6__5_n_6\,
      O(0) => \i__carry_i_6__5_n_7\,
      S(3) => \i__carry_i_11__1_n_0\,
      S(2) => \i__carry_i_12__1_n_0\,
      S(1) => \i__carry_i_13__1_n_0\,
      S(0) => \i__carry_i_14__1_n_0\
    );
\i__carry_i_6__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_5__4_n_0\,
      CO(3) => \i__carry_i_6__6_n_0\,
      CO(2) => \i__carry_i_6__6_n_1\,
      CO(1) => \i__carry_i_6__6_n_2\,
      CO(0) => \i__carry_i_6__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \i__carry_i_6__6_n_4\,
      O(2) => \i__carry_i_6__6_n_5\,
      O(1) => \i__carry_i_6__6_n_6\,
      O(0) => \i__carry_i_6__6_n_7\,
      S(3) => \i__carry_i_11__2_n_0\,
      S(2) => \i__carry_i_12__2_n_0\,
      S(1) => \i__carry_i_13__2_n_0\,
      S(0) => \i__carry_i_14__2_n_0\
    );
\i__carry_i_6__7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_6__7_n_0\
    );
\i__carry_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \i__carry_i_6_n_0\,
      CO(3) => \i__carry_i_7_n_0\,
      CO(2) => \i__carry_i_7_n_1\,
      CO(1) => \i__carry_i_7_n_2\,
      CO(0) => \i__carry_i_7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^output_velocity\(11 downto 8),
      O(3) => \i__carry_i_7_n_4\,
      O(2) => \i__carry_i_7_n_5\,
      O(1) => \i__carry_i_7_n_6\,
      O(0) => \i__carry_i_7_n_7\,
      S(3) => \i__carry_i_13__3_n_0\,
      S(2) => \i__carry_i_14__3_n_0\,
      S(1) => \i__carry_i_15_n_0\,
      S(0) => \i__carry_i_16_n_0\
    );
\i__carry_i_7__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[35]\,
      O => \i__carry_i_7__0_n_0\
    );
\i__carry_i_7__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_7__1_n_0\
    );
\i__carry_i_7__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_7__2_n_0\
    );
\i__carry_i_7__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_7__3_n_0\
    );
\i__carry_i_7__4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_7__4_n_0\
    );
\i__carry_i_7__5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_7__5_n_0\
    );
\i__carry_i_7__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(19),
      I1 => \interim_velocity_reg_n_0_[19]\,
      O => \i__carry_i_7__6_n_0\
    );
\i__carry_i_7__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(27),
      I1 => \interim_velocity_reg_n_0_[27]\,
      O => \i__carry_i_7__7_n_0\
    );
\i__carry_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \i__carry_i_8_n_0\,
      CO(2) => \i__carry_i_8_n_1\,
      CO(1) => \i__carry_i_8_n_2\,
      CO(0) => \i__carry_i_8_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => \^output_velocity\(3 downto 0),
      O(3 downto 0) => \NLW_i__carry_i_8_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_17_n_0\,
      S(2) => \i__carry_i_18_n_0\,
      S(1) => \i__carry_i_19_n_0\,
      S(0) => \i__carry_i_20_n_0\
    );
\i__carry_i_8__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[34]\,
      O => \i__carry_i_8__0_n_0\
    );
\i__carry_i_8__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_8__1_n_0\
    );
\i__carry_i_8__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_8__2_n_0\
    );
\i__carry_i_8__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_8__3_n_0\
    );
\i__carry_i_8__4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_8__4_n_0\
    );
\i__carry_i_8__5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_8__5_n_0\
    );
\i__carry_i_8__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(18),
      I1 => \interim_velocity_reg_n_0_[18]\,
      O => \i__carry_i_8__6_n_0\
    );
\i__carry_i_8__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(26),
      I1 => \interim_velocity_reg_n_0_[26]\,
      O => \i__carry_i_8__7_n_0\
    );
\i__carry_i_9\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[41]\,
      O => \i__carry_i_9_n_0\
    );
\i__carry_i_9__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[33]\,
      O => \i__carry_i_9__0_n_0\
    );
\i__carry_i_9__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_9__1_n_0\
    );
\i__carry_i_9__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_9__2_n_0\
    );
\i__carry_i_9__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_9__3_n_0\
    );
\i__carry_i_9__4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \i__carry_i_9__4_n_0\
    );
\i__carry_i_9__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(7),
      I1 => \interim_velocity_reg_n_0_[7]\,
      O => \i__carry_i_9__5_n_0\
    );
\i__carry_i_9__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(17),
      I1 => \interim_velocity_reg_n_0_[17]\,
      O => \i__carry_i_9__6_n_0\
    );
\i__carry_i_9__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^output_velocity\(25),
      I1 => \interim_velocity_reg_n_0_[25]\,
      O => \i__carry_i_9__7_n_0\
    );
i_term0: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 1,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 1,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16) => \integral_reg[19]_i_1_n_7\,
      A(15) => \integral_reg[15]_i_1_n_4\,
      A(14) => \integral_reg[15]_i_1_n_5\,
      A(13) => \integral_reg[15]_i_1_n_6\,
      A(12) => \integral_reg[15]_i_1_n_7\,
      A(11) => \integral_reg[11]_i_1_n_4\,
      A(10) => \integral_reg[11]_i_1_n_5\,
      A(9) => \integral_reg[11]_i_1_n_6\,
      A(8) => \integral_reg[11]_i_1_n_7\,
      A(7) => \integral_reg[7]_i_1_n_4\,
      A(6) => \integral_reg[7]_i_1_n_5\,
      A(5) => \integral_reg[7]_i_1_n_6\,
      A(4) => \integral_reg[7]_i_1_n_7\,
      A(3) => \integral_reg[3]_i_1_n_4\,
      A(2) => \integral_reg[3]_i_1_n_5\,
      A(1) => \integral_reg[3]_i_1_n_6\,
      A(0) => \integral_reg[3]_i_1_n_7\,
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_i_term0_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => ki(8),
      B(16) => ki(8),
      B(15) => ki(8),
      B(14) => ki(8),
      B(13) => ki(8),
      B(12) => ki(8),
      B(11) => ki(8),
      B(10) => ki(8),
      B(9) => ki(8),
      B(8 downto 0) => ki(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_i_term0_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_i_term0_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_i_term0_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '1',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => clock(0),
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_i_term0_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_i_term0_OVERFLOW_UNCONNECTED,
      P(47) => i_term0_n_58,
      P(46) => i_term0_n_59,
      P(45) => i_term0_n_60,
      P(44) => i_term0_n_61,
      P(43) => i_term0_n_62,
      P(42) => i_term0_n_63,
      P(41) => i_term0_n_64,
      P(40) => i_term0_n_65,
      P(39) => i_term0_n_66,
      P(38) => i_term0_n_67,
      P(37) => i_term0_n_68,
      P(36) => i_term0_n_69,
      P(35) => i_term0_n_70,
      P(34) => i_term0_n_71,
      P(33) => i_term0_n_72,
      P(32) => i_term0_n_73,
      P(31) => i_term0_n_74,
      P(30) => i_term0_n_75,
      P(29) => i_term0_n_76,
      P(28) => i_term0_n_77,
      P(27) => i_term0_n_78,
      P(26) => i_term0_n_79,
      P(25) => i_term0_n_80,
      P(24) => i_term0_n_81,
      P(23) => i_term0_n_82,
      P(22) => i_term0_n_83,
      P(21) => i_term0_n_84,
      P(20) => i_term0_n_85,
      P(19) => i_term0_n_86,
      P(18) => i_term0_n_87,
      P(17) => i_term0_n_88,
      P(16) => i_term0_n_89,
      P(15) => i_term0_n_90,
      P(14) => i_term0_n_91,
      P(13) => i_term0_n_92,
      P(12) => i_term0_n_93,
      P(11) => i_term0_n_94,
      P(10) => i_term0_n_95,
      P(9) => i_term0_n_96,
      P(8) => i_term0_n_97,
      P(7) => i_term0_n_98,
      P(6) => i_term0_n_99,
      P(5) => i_term0_n_100,
      P(4) => i_term0_n_101,
      P(3) => i_term0_n_102,
      P(2) => i_term0_n_103,
      P(1) => i_term0_n_104,
      P(0) => i_term0_n_105,
      PATTERNBDETECT => NLW_i_term0_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_i_term0_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => i_term0_n_106,
      PCOUT(46) => i_term0_n_107,
      PCOUT(45) => i_term0_n_108,
      PCOUT(44) => i_term0_n_109,
      PCOUT(43) => i_term0_n_110,
      PCOUT(42) => i_term0_n_111,
      PCOUT(41) => i_term0_n_112,
      PCOUT(40) => i_term0_n_113,
      PCOUT(39) => i_term0_n_114,
      PCOUT(38) => i_term0_n_115,
      PCOUT(37) => i_term0_n_116,
      PCOUT(36) => i_term0_n_117,
      PCOUT(35) => i_term0_n_118,
      PCOUT(34) => i_term0_n_119,
      PCOUT(33) => i_term0_n_120,
      PCOUT(32) => i_term0_n_121,
      PCOUT(31) => i_term0_n_122,
      PCOUT(30) => i_term0_n_123,
      PCOUT(29) => i_term0_n_124,
      PCOUT(28) => i_term0_n_125,
      PCOUT(27) => i_term0_n_126,
      PCOUT(26) => i_term0_n_127,
      PCOUT(25) => i_term0_n_128,
      PCOUT(24) => i_term0_n_129,
      PCOUT(23) => i_term0_n_130,
      PCOUT(22) => i_term0_n_131,
      PCOUT(21) => i_term0_n_132,
      PCOUT(20) => i_term0_n_133,
      PCOUT(19) => i_term0_n_134,
      PCOUT(18) => i_term0_n_135,
      PCOUT(17) => i_term0_n_136,
      PCOUT(16) => i_term0_n_137,
      PCOUT(15) => i_term0_n_138,
      PCOUT(14) => i_term0_n_139,
      PCOUT(13) => i_term0_n_140,
      PCOUT(12) => i_term0_n_141,
      PCOUT(11) => i_term0_n_142,
      PCOUT(10) => i_term0_n_143,
      PCOUT(9) => i_term0_n_144,
      PCOUT(8) => i_term0_n_145,
      PCOUT(7) => i_term0_n_146,
      PCOUT(6) => i_term0_n_147,
      PCOUT(5) => i_term0_n_148,
      PCOUT(4) => i_term0_n_149,
      PCOUT(3) => i_term0_n_150,
      PCOUT(2) => i_term0_n_151,
      PCOUT(1) => i_term0_n_152,
      PCOUT(0) => i_term0_n_153,
      RSTA => new_target_angle_available(0),
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_i_term0_UNDERFLOW_UNCONNECTED
    );
i_term_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 1,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 1,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => \integral_reg[31]_i_1_n_4\,
      A(28) => \integral_reg[31]_i_1_n_4\,
      A(27) => \integral_reg[31]_i_1_n_4\,
      A(26) => \integral_reg[31]_i_1_n_4\,
      A(25) => \integral_reg[31]_i_1_n_4\,
      A(24) => \integral_reg[31]_i_1_n_4\,
      A(23) => \integral_reg[31]_i_1_n_4\,
      A(22) => \integral_reg[31]_i_1_n_4\,
      A(21) => \integral_reg[31]_i_1_n_4\,
      A(20) => \integral_reg[31]_i_1_n_4\,
      A(19) => \integral_reg[31]_i_1_n_4\,
      A(18) => \integral_reg[31]_i_1_n_4\,
      A(17) => \integral_reg[31]_i_1_n_4\,
      A(16) => \integral_reg[31]_i_1_n_4\,
      A(15) => \integral_reg[31]_i_1_n_4\,
      A(14) => \integral_reg[31]_i_1_n_4\,
      A(13) => \integral_reg[31]_i_1_n_5\,
      A(12) => \integral_reg[31]_i_1_n_6\,
      A(11) => \integral_reg[31]_i_1_n_7\,
      A(10) => \integral_reg[27]_i_1_n_4\,
      A(9) => \integral_reg[27]_i_1_n_5\,
      A(8) => \integral_reg[27]_i_1_n_6\,
      A(7) => \integral_reg[27]_i_1_n_7\,
      A(6) => \integral_reg[23]_i_1_n_4\,
      A(5) => \integral_reg[23]_i_1_n_5\,
      A(4) => \integral_reg[23]_i_1_n_6\,
      A(3) => \integral_reg[23]_i_1_n_7\,
      A(2) => \integral_reg[19]_i_1_n_4\,
      A(1) => \integral_reg[19]_i_1_n_5\,
      A(0) => \integral_reg[19]_i_1_n_6\,
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_i_term_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => ki(8),
      B(16) => ki(8),
      B(15) => ki(8),
      B(14) => ki(8),
      B(13) => ki(8),
      B(12) => ki(8),
      B(11) => ki(8),
      B(10) => ki(8),
      B(9) => ki(8),
      B(8 downto 0) => ki(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_i_term_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_i_term_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_i_term_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '1',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '1',
      CLK => clock(0),
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_i_term_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => NLW_i_term_reg_OVERFLOW_UNCONNECTED,
      P(47) => i_term_reg_n_58,
      P(46) => i_term_reg_n_59,
      P(45) => i_term_reg_n_60,
      P(44) => i_term_reg_n_61,
      P(43) => i_term_reg_n_62,
      P(42) => i_term_reg_n_63,
      P(41) => i_term_reg_n_64,
      P(40) => i_term_reg_n_65,
      P(39) => i_term_reg_n_66,
      P(38) => i_term_reg_n_67,
      P(37) => i_term_reg_n_68,
      P(36) => i_term_reg_n_69,
      P(35) => i_term_reg_n_70,
      P(34) => i_term_reg_n_71,
      P(33) => i_term_reg_n_72,
      P(32) => i_term_reg_n_73,
      P(31) => i_term_reg_n_74,
      P(30) => i_term_reg_n_75,
      P(29) => i_term_reg_n_76,
      P(28) => i_term_reg_n_77,
      P(27) => i_term_reg_n_78,
      P(26) => i_term_reg_n_79,
      P(25) => i_term_reg_n_80,
      P(24) => i_term_reg_n_81,
      P(23 downto 0) => \^i_term_reg\(40 downto 17),
      PATTERNBDETECT => NLW_i_term_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_i_term_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47) => i_term0_n_106,
      PCIN(46) => i_term0_n_107,
      PCIN(45) => i_term0_n_108,
      PCIN(44) => i_term0_n_109,
      PCIN(43) => i_term0_n_110,
      PCIN(42) => i_term0_n_111,
      PCIN(41) => i_term0_n_112,
      PCIN(40) => i_term0_n_113,
      PCIN(39) => i_term0_n_114,
      PCIN(38) => i_term0_n_115,
      PCIN(37) => i_term0_n_116,
      PCIN(36) => i_term0_n_117,
      PCIN(35) => i_term0_n_118,
      PCIN(34) => i_term0_n_119,
      PCIN(33) => i_term0_n_120,
      PCIN(32) => i_term0_n_121,
      PCIN(31) => i_term0_n_122,
      PCIN(30) => i_term0_n_123,
      PCIN(29) => i_term0_n_124,
      PCIN(28) => i_term0_n_125,
      PCIN(27) => i_term0_n_126,
      PCIN(26) => i_term0_n_127,
      PCIN(25) => i_term0_n_128,
      PCIN(24) => i_term0_n_129,
      PCIN(23) => i_term0_n_130,
      PCIN(22) => i_term0_n_131,
      PCIN(21) => i_term0_n_132,
      PCIN(20) => i_term0_n_133,
      PCIN(19) => i_term0_n_134,
      PCIN(18) => i_term0_n_135,
      PCIN(17) => i_term0_n_136,
      PCIN(16) => i_term0_n_137,
      PCIN(15) => i_term0_n_138,
      PCIN(14) => i_term0_n_139,
      PCIN(13) => i_term0_n_140,
      PCIN(12) => i_term0_n_141,
      PCIN(11) => i_term0_n_142,
      PCIN(10) => i_term0_n_143,
      PCIN(9) => i_term0_n_144,
      PCIN(8) => i_term0_n_145,
      PCIN(7) => i_term0_n_146,
      PCIN(6) => i_term0_n_147,
      PCIN(5) => i_term0_n_148,
      PCIN(4) => i_term0_n_149,
      PCIN(3) => i_term0_n_150,
      PCIN(2) => i_term0_n_151,
      PCIN(1) => i_term0_n_152,
      PCIN(0) => i_term0_n_153,
      PCOUT(47 downto 0) => NLW_i_term_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => new_target_angle_available(0),
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_i_term_reg_UNDERFLOW_UNCONNECTED
    );
\i_term_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_105,
      Q => \^i_term_reg\(0),
      R => '0'
    );
\i_term_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_95,
      Q => \^i_term_reg\(10),
      R => '0'
    );
\i_term_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_94,
      Q => \^i_term_reg\(11),
      R => '0'
    );
\i_term_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_93,
      Q => \^i_term_reg\(12),
      R => '0'
    );
\i_term_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_92,
      Q => \^i_term_reg\(13),
      R => '0'
    );
\i_term_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_91,
      Q => \^i_term_reg\(14),
      R => '0'
    );
\i_term_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_90,
      Q => \^i_term_reg\(15),
      R => '0'
    );
\i_term_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_89,
      Q => \^i_term_reg\(16),
      R => '0'
    );
\i_term_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_104,
      Q => \^i_term_reg\(1),
      R => '0'
    );
\i_term_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_103,
      Q => \^i_term_reg\(2),
      R => '0'
    );
\i_term_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_102,
      Q => \^i_term_reg\(3),
      R => '0'
    );
\i_term_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_101,
      Q => \^i_term_reg\(4),
      R => '0'
    );
\i_term_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_100,
      Q => \^i_term_reg\(5),
      R => '0'
    );
\i_term_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_99,
      Q => \^i_term_reg\(6),
      R => '0'
    );
\i_term_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_98,
      Q => \^i_term_reg\(7),
      R => '0'
    );
\i_term_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_97,
      Q => \^i_term_reg\(8),
      R => '0'
    );
\i_term_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => i_term0_n_96,
      Q => \^i_term_reg\(9),
      R => '0'
    );
\integral[11]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_6\,
      I1 => \integral_reg[11]_i_17_n_6\,
      I2 => \integral_reg[11]_i_18_n_4\,
      O => \integral[11]_i_10_n_0\
    );
\integral[11]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_7\,
      I1 => \integral_reg[11]_i_17_n_7\,
      I2 => \integral_reg[11]_i_18_n_5\,
      O => \integral[11]_i_11_n_0\
    );
\integral[11]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_7\,
      I1 => \integral_reg[15]_i_17_n_7\,
      I2 => \integral_reg[15]_i_18_n_5\,
      I3 => \integral[11]_i_8_n_0\,
      O => \integral[11]_i_12_n_0\
    );
\integral[11]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_4\,
      I1 => \integral_reg[11]_i_17_n_4\,
      I2 => \integral_reg[15]_i_18_n_6\,
      I3 => \integral[11]_i_9_n_0\,
      O => \integral[11]_i_13_n_0\
    );
\integral[11]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_5\,
      I1 => \integral_reg[11]_i_17_n_5\,
      I2 => \integral_reg[15]_i_18_n_7\,
      I3 => \integral[11]_i_10_n_0\,
      O => \integral[11]_i_14_n_0\
    );
\integral[11]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_6\,
      I1 => \integral_reg[11]_i_17_n_6\,
      I2 => \integral_reg[11]_i_18_n_4\,
      I3 => \integral[11]_i_11_n_0\,
      O => \integral[11]_i_15_n_0\
    );
\integral[11]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(15),
      I1 => \integral_reg[15]_i_43_n_5\,
      O => \integral[11]_i_19_n_0\
    );
\integral[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(11),
      I1 => \integral_reg[11]_i_6_n_4\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[11]_i_7_n_4\,
      O => \integral[11]_i_2_n_0\
    );
\integral[11]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(14),
      I1 => \integral_reg[15]_i_43_n_6\,
      O => \integral[11]_i_20_n_0\
    );
\integral[11]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(13),
      I1 => \integral_reg[15]_i_43_n_7\,
      O => \integral[11]_i_21_n_0\
    );
\integral[11]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_43_n_4\,
      I1 => \integral_reg[11]_i_44_n_0\,
      I2 => error(12),
      O => \integral[11]_i_22_n_0\
    );
\integral[11]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(15),
      I1 => \integral_reg[15]_i_43_n_5\,
      I2 => \integral_reg[15]_i_43_n_4\,
      I3 => error(16),
      O => \integral[11]_i_23_n_0\
    );
\integral[11]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(14),
      I1 => \integral_reg[15]_i_43_n_6\,
      I2 => \integral_reg[15]_i_43_n_5\,
      I3 => error(15),
      O => \integral[11]_i_24_n_0\
    );
\integral[11]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(13),
      I1 => \integral_reg[15]_i_43_n_7\,
      I2 => \integral_reg[15]_i_43_n_6\,
      I3 => error(14),
      O => \integral[11]_i_25_n_0\
    );
\integral[11]_i_26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E81717E8"
    )
        port map (
      I0 => error(12),
      I1 => \integral_reg[11]_i_44_n_0\,
      I2 => \integral_reg[11]_i_43_n_4\,
      I3 => \integral_reg[15]_i_43_n_7\,
      I4 => error(13),
      O => \integral[11]_i_26_n_0\
    );
\integral[11]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(22),
      I1 => error(17),
      I2 => error(20),
      O => \integral[11]_i_27_n_0\
    );
\integral[11]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(21),
      I1 => error(16),
      I2 => error(19),
      O => \integral[11]_i_28_n_0\
    );
\integral[11]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(20),
      I1 => error(15),
      I2 => error(18),
      O => \integral[11]_i_29_n_0\
    );
\integral[11]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(10),
      I1 => \integral_reg[11]_i_6_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[11]_i_7_n_5\,
      O => \integral[11]_i_3_n_0\
    );
\integral[11]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(19),
      I1 => error(14),
      I2 => error(17),
      O => \integral[11]_i_30_n_0\
    );
\integral[11]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(20),
      I1 => error(17),
      I2 => error(22),
      I3 => error(23),
      I4 => error(18),
      I5 => error(21),
      O => \integral[11]_i_31_n_0\
    );
\integral[11]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(19),
      I1 => error(16),
      I2 => error(21),
      I3 => error(22),
      I4 => error(17),
      I5 => error(20),
      O => \integral[11]_i_32_n_0\
    );
\integral[11]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(18),
      I1 => error(15),
      I2 => error(20),
      I3 => error(21),
      I4 => error(16),
      I5 => error(19),
      O => \integral[11]_i_33_n_0\
    );
\integral[11]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(17),
      I1 => error(14),
      I2 => error(19),
      I3 => error(20),
      I4 => error(15),
      I5 => error(18),
      O => \integral[11]_i_34_n_0\
    );
\integral[11]_i_35\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(22),
      I1 => error(20),
      I2 => error(24),
      O => \integral[11]_i_35_n_0\
    );
\integral[11]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(21),
      I1 => error(19),
      I2 => error(23),
      O => \integral[11]_i_36_n_0\
    );
\integral[11]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(20),
      I1 => error(18),
      I2 => error(22),
      O => \integral[11]_i_37_n_0\
    );
\integral[11]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(19),
      I1 => error(17),
      I2 => error(21),
      O => \integral[11]_i_38_n_0\
    );
\integral[11]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(24),
      I1 => error(20),
      I2 => error(22),
      I3 => error(21),
      I4 => error(23),
      I5 => error(25),
      O => \integral[11]_i_39_n_0\
    );
\integral[11]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(9),
      I1 => \integral_reg[11]_i_6_n_6\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[11]_i_7_n_6\,
      O => \integral[11]_i_4_n_0\
    );
\integral[11]_i_40\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(23),
      I1 => error(19),
      I2 => error(21),
      I3 => error(20),
      I4 => error(22),
      I5 => error(24),
      O => \integral[11]_i_40_n_0\
    );
\integral[11]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(22),
      I1 => error(18),
      I2 => error(20),
      I3 => error(19),
      I4 => error(21),
      I5 => error(23),
      O => \integral[11]_i_41_n_0\
    );
\integral[11]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(21),
      I1 => error(17),
      I2 => error(19),
      I3 => error(18),
      I4 => error(20),
      I5 => error(22),
      O => \integral[11]_i_42_n_0\
    );
\integral[11]_i_45\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(24),
      I1 => error(27),
      O => \integral[11]_i_45_n_0\
    );
\integral[11]_i_46\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(23),
      I1 => error(26),
      O => \integral[11]_i_46_n_0\
    );
\integral[11]_i_47\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(22),
      I1 => error(25),
      O => \integral[11]_i_47_n_0\
    );
\integral[11]_i_48\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(21),
      I1 => error(24),
      O => \integral[11]_i_48_n_0\
    );
\integral[11]_i_49\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(28),
      I1 => error(30),
      O => \integral[11]_i_49_n_0\
    );
\integral[11]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(8),
      I1 => \integral_reg[11]_i_6_n_7\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[11]_i_7_n_7\,
      O => \integral[11]_i_5_n_0\
    );
\integral[11]_i_50\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => error(31),
      I1 => error(29),
      I2 => error(30),
      O => \integral[11]_i_50_n_0\
    );
\integral[11]_i_51\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(30),
      I1 => error(28),
      I2 => error(29),
      I3 => error(31),
      O => \integral[11]_i_51_n_0\
    );
\integral[11]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_4\,
      I1 => \integral_reg[11]_i_17_n_4\,
      I2 => \integral_reg[15]_i_18_n_6\,
      O => \integral[11]_i_8_n_0\
    );
\integral[11]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_5\,
      I1 => \integral_reg[11]_i_17_n_5\,
      I2 => \integral_reg[15]_i_18_n_7\,
      O => \integral[11]_i_9_n_0\
    );
\integral[15]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_6\,
      I1 => \integral_reg[15]_i_17_n_6\,
      I2 => \integral_reg[15]_i_18_n_4\,
      O => \integral[15]_i_10_n_0\
    );
\integral[15]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_7\,
      I1 => \integral_reg[15]_i_17_n_7\,
      I2 => \integral_reg[15]_i_18_n_5\,
      O => \integral[15]_i_11_n_0\
    );
\integral[15]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_7\,
      I1 => \integral_reg[19]_i_17_n_7\,
      I2 => \integral_reg[19]_i_18_n_5\,
      I3 => \integral[15]_i_8_n_0\,
      O => \integral[15]_i_12_n_0\
    );
\integral[15]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_4\,
      I1 => \integral_reg[15]_i_17_n_4\,
      I2 => \integral_reg[19]_i_18_n_6\,
      I3 => \integral[15]_i_9_n_0\,
      O => \integral[15]_i_13_n_0\
    );
\integral[15]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_5\,
      I1 => \integral_reg[15]_i_17_n_5\,
      I2 => \integral_reg[19]_i_18_n_7\,
      I3 => \integral[15]_i_10_n_0\,
      O => \integral[15]_i_14_n_0\
    );
\integral[15]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_6\,
      I1 => \integral_reg[15]_i_17_n_6\,
      I2 => \integral_reg[15]_i_18_n_4\,
      I3 => \integral[15]_i_11_n_0\,
      O => \integral[15]_i_15_n_0\
    );
\integral[15]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(19),
      I1 => \integral_reg[27]_i_97_n_5\,
      O => \integral[15]_i_19_n_0\
    );
\integral[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(15),
      I1 => \integral_reg[15]_i_6_n_4\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[15]_i_7_n_4\,
      O => \integral[15]_i_2_n_0\
    );
\integral[15]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(18),
      I1 => \integral_reg[27]_i_97_n_6\,
      O => \integral[15]_i_20_n_0\
    );
\integral[15]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(17),
      I1 => \integral_reg[27]_i_97_n_7\,
      O => \integral[15]_i_21_n_0\
    );
\integral[15]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(16),
      I1 => \integral_reg[15]_i_43_n_4\,
      O => \integral[15]_i_22_n_0\
    );
\integral[15]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7887"
    )
        port map (
      I0 => error(19),
      I1 => \integral_reg[27]_i_97_n_5\,
      I2 => \integral_reg[27]_i_97_n_0\,
      I3 => error(20),
      O => \integral[15]_i_23_n_0\
    );
\integral[15]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(18),
      I1 => \integral_reg[27]_i_97_n_6\,
      I2 => \integral_reg[27]_i_97_n_5\,
      I3 => error(19),
      O => \integral[15]_i_24_n_0\
    );
\integral[15]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(17),
      I1 => \integral_reg[27]_i_97_n_7\,
      I2 => \integral_reg[27]_i_97_n_6\,
      I3 => error(18),
      O => \integral[15]_i_25_n_0\
    );
\integral[15]_i_26\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(16),
      I1 => \integral_reg[15]_i_43_n_4\,
      I2 => \integral_reg[27]_i_97_n_7\,
      I3 => error(17),
      O => \integral[15]_i_26_n_0\
    );
\integral[15]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(26),
      I1 => error(21),
      I2 => error(24),
      O => \integral[15]_i_27_n_0\
    );
\integral[15]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(25),
      I1 => error(20),
      I2 => error(23),
      O => \integral[15]_i_28_n_0\
    );
\integral[15]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(24),
      I1 => error(19),
      I2 => error(22),
      O => \integral[15]_i_29_n_0\
    );
\integral[15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(14),
      I1 => \integral_reg[15]_i_6_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[15]_i_7_n_5\,
      O => \integral[15]_i_3_n_0\
    );
\integral[15]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(23),
      I1 => error(18),
      I2 => error(21),
      O => \integral[15]_i_30_n_0\
    );
\integral[15]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(24),
      I1 => error(21),
      I2 => error(26),
      I3 => error(27),
      I4 => error(22),
      I5 => error(25),
      O => \integral[15]_i_31_n_0\
    );
\integral[15]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(23),
      I1 => error(20),
      I2 => error(25),
      I3 => error(26),
      I4 => error(21),
      I5 => error(24),
      O => \integral[15]_i_32_n_0\
    );
\integral[15]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(22),
      I1 => error(19),
      I2 => error(24),
      I3 => error(25),
      I4 => error(20),
      I5 => error(23),
      O => \integral[15]_i_33_n_0\
    );
\integral[15]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(21),
      I1 => error(18),
      I2 => error(23),
      I3 => error(24),
      I4 => error(19),
      I5 => error(22),
      O => \integral[15]_i_34_n_0\
    );
\integral[15]_i_35\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(26),
      I1 => error(24),
      I2 => error(28),
      O => \integral[15]_i_35_n_0\
    );
\integral[15]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(25),
      I1 => error(23),
      I2 => error(27),
      O => \integral[15]_i_36_n_0\
    );
\integral[15]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(24),
      I1 => error(22),
      I2 => error(26),
      O => \integral[15]_i_37_n_0\
    );
\integral[15]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(23),
      I1 => error(21),
      I2 => error(25),
      O => \integral[15]_i_38_n_0\
    );
\integral[15]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(28),
      I1 => error(24),
      I2 => error(26),
      I3 => error(25),
      I4 => error(27),
      I5 => error(29),
      O => \integral[15]_i_39_n_0\
    );
\integral[15]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(13),
      I1 => \integral_reg[15]_i_6_n_6\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[15]_i_7_n_6\,
      O => \integral[15]_i_4_n_0\
    );
\integral[15]_i_40\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(27),
      I1 => error(23),
      I2 => error(25),
      I3 => error(24),
      I4 => error(26),
      I5 => error(28),
      O => \integral[15]_i_40_n_0\
    );
\integral[15]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(26),
      I1 => error(22),
      I2 => error(24),
      I3 => error(23),
      I4 => error(25),
      I5 => error(27),
      O => \integral[15]_i_41_n_0\
    );
\integral[15]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(25),
      I1 => error(21),
      I2 => error(23),
      I3 => error(22),
      I4 => error(24),
      I5 => error(26),
      O => \integral[15]_i_42_n_0\
    );
\integral[15]_i_44\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(28),
      I1 => error(31),
      O => \integral[15]_i_44_n_0\
    );
\integral[15]_i_45\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(27),
      I1 => error(30),
      O => \integral[15]_i_45_n_0\
    );
\integral[15]_i_46\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(26),
      I1 => error(29),
      O => \integral[15]_i_46_n_0\
    );
\integral[15]_i_47\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(25),
      I1 => error(28),
      O => \integral[15]_i_47_n_0\
    );
\integral[15]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(12),
      I1 => \integral_reg[15]_i_6_n_7\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[15]_i_7_n_7\,
      O => \integral[15]_i_5_n_0\
    );
\integral[15]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_4\,
      I1 => \integral_reg[15]_i_17_n_4\,
      I2 => \integral_reg[19]_i_18_n_6\,
      O => \integral[15]_i_8_n_0\
    );
\integral[15]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[15]_i_16_n_5\,
      I1 => \integral_reg[15]_i_17_n_5\,
      I2 => \integral_reg[19]_i_18_n_7\,
      O => \integral[15]_i_9_n_0\
    );
\integral[19]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_6\,
      I1 => \integral_reg[19]_i_17_n_6\,
      I2 => \integral_reg[19]_i_18_n_4\,
      O => \integral[19]_i_10_n_0\
    );
\integral[19]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_7\,
      I1 => \integral_reg[19]_i_17_n_7\,
      I2 => \integral_reg[19]_i_18_n_5\,
      O => \integral[19]_i_11_n_0\
    );
\integral[19]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_7\,
      I1 => \integral_reg[23]_i_17_n_7\,
      I2 => \integral_reg[27]_i_47_n_5\,
      I3 => \integral[19]_i_8_n_0\,
      O => \integral[19]_i_12_n_0\
    );
\integral[19]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_4\,
      I1 => \integral_reg[19]_i_17_n_4\,
      I2 => \integral_reg[27]_i_47_n_6\,
      I3 => \integral[19]_i_9_n_0\,
      O => \integral[19]_i_13_n_0\
    );
\integral[19]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_5\,
      I1 => \integral_reg[19]_i_17_n_5\,
      I2 => \integral_reg[27]_i_47_n_7\,
      I3 => \integral[19]_i_10_n_0\,
      O => \integral[19]_i_14_n_0\
    );
\integral[19]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_6\,
      I1 => \integral_reg[19]_i_17_n_6\,
      I2 => \integral_reg[19]_i_18_n_4\,
      I3 => \integral[19]_i_11_n_0\,
      O => \integral[19]_i_15_n_0\
    );
\integral[19]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(23),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[19]_i_19_n_0\
    );
\integral[19]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(19),
      I1 => \integral_reg[19]_i_6_n_4\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[19]_i_7_n_4\,
      O => \integral[19]_i_2_n_0\
    );
\integral[19]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(22),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[19]_i_20_n_0\
    );
\integral[19]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(21),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[19]_i_21_n_0\
    );
\integral[19]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(20),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[19]_i_22_n_0\
    );
\integral[19]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(23),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(24),
      O => \integral[19]_i_23_n_0\
    );
\integral[19]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(22),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(23),
      O => \integral[19]_i_24_n_0\
    );
\integral[19]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(21),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(22),
      O => \integral[19]_i_25_n_0\
    );
\integral[19]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(20),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(21),
      O => \integral[19]_i_26_n_0\
    );
\integral[19]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(30),
      I1 => error(25),
      I2 => error(28),
      O => \integral[19]_i_27_n_0\
    );
\integral[19]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(29),
      I1 => error(24),
      I2 => error(27),
      O => \integral[19]_i_28_n_0\
    );
\integral[19]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(28),
      I1 => error(23),
      I2 => error(26),
      O => \integral[19]_i_29_n_0\
    );
\integral[19]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(18),
      I1 => \integral_reg[19]_i_6_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[19]_i_7_n_5\,
      O => \integral[19]_i_3_n_0\
    );
\integral[19]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(27),
      I1 => error(22),
      I2 => error(25),
      O => \integral[19]_i_30_n_0\
    );
\integral[19]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(28),
      I1 => error(25),
      I2 => error(30),
      I3 => error(31),
      I4 => error(26),
      I5 => error(29),
      O => \integral[19]_i_31_n_0\
    );
\integral[19]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(27),
      I1 => error(24),
      I2 => error(29),
      I3 => error(30),
      I4 => error(25),
      I5 => error(28),
      O => \integral[19]_i_32_n_0\
    );
\integral[19]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(26),
      I1 => error(23),
      I2 => error(28),
      I3 => error(29),
      I4 => error(24),
      I5 => error(27),
      O => \integral[19]_i_33_n_0\
    );
\integral[19]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(25),
      I1 => error(22),
      I2 => error(27),
      I3 => error(28),
      I4 => error(23),
      I5 => error(26),
      O => \integral[19]_i_34_n_0\
    );
\integral[19]_i_35\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(28),
      I1 => error(30),
      O => \integral[19]_i_35_n_0\
    );
\integral[19]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(29),
      I1 => error(27),
      I2 => error(31),
      O => \integral[19]_i_36_n_0\
    );
\integral[19]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(28),
      I1 => error(26),
      I2 => error(30),
      O => \integral[19]_i_37_n_0\
    );
\integral[19]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(27),
      I1 => error(25),
      I2 => error(29),
      O => \integral[19]_i_38_n_0\
    );
\integral[19]_i_39\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(30),
      I1 => error(28),
      I2 => error(31),
      I3 => error(29),
      O => \integral[19]_i_39_n_0\
    );
\integral[19]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(17),
      I1 => \integral_reg[19]_i_6_n_6\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[19]_i_7_n_6\,
      O => \integral[19]_i_4_n_0\
    );
\integral[19]_i_40\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"718E8E71"
    )
        port map (
      I0 => error(31),
      I1 => error(27),
      I2 => error(29),
      I3 => error(30),
      I4 => error(28),
      O => \integral[19]_i_40_n_0\
    );
\integral[19]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(30),
      I1 => error(26),
      I2 => error(28),
      I3 => error(27),
      I4 => error(29),
      I5 => error(31),
      O => \integral[19]_i_41_n_0\
    );
\integral[19]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(29),
      I1 => error(25),
      I2 => error(27),
      I3 => error(26),
      I4 => error(28),
      I5 => error(30),
      O => \integral[19]_i_42_n_0\
    );
\integral[19]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(16),
      I1 => \integral_reg[19]_i_6_n_7\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[19]_i_7_n_7\,
      O => \integral[19]_i_5_n_0\
    );
\integral[19]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_4\,
      I1 => \integral_reg[19]_i_17_n_4\,
      I2 => \integral_reg[27]_i_47_n_6\,
      O => \integral[19]_i_8_n_0\
    );
\integral[19]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[19]_i_16_n_5\,
      I1 => \integral_reg[19]_i_17_n_5\,
      I2 => \integral_reg[27]_i_47_n_7\,
      O => \integral[19]_i_9_n_0\
    );
\integral[23]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_6\,
      I1 => \integral_reg[23]_i_17_n_6\,
      I2 => \integral_reg[27]_i_47_n_0\,
      O => \integral[23]_i_10_n_0\
    );
\integral[23]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_7\,
      I1 => \integral_reg[23]_i_17_n_7\,
      I2 => \integral_reg[27]_i_47_n_5\,
      O => \integral[23]_i_11_n_0\
    );
\integral[23]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \integral_reg[27]_i_45_n_7\,
      I1 => \integral_reg[27]_i_46_n_7\,
      I2 => \integral_reg[27]_i_47_n_0\,
      I3 => \integral[23]_i_8_n_0\,
      O => \integral[23]_i_12_n_0\
    );
\integral[23]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_4\,
      I1 => \integral_reg[23]_i_17_n_4\,
      I2 => \integral_reg[27]_i_47_n_0\,
      I3 => \integral[23]_i_9_n_0\,
      O => \integral[23]_i_13_n_0\
    );
\integral[23]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_5\,
      I1 => \integral_reg[23]_i_17_n_5\,
      I2 => \integral_reg[27]_i_47_n_0\,
      I3 => \integral[23]_i_10_n_0\,
      O => \integral[23]_i_14_n_0\
    );
\integral[23]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_6\,
      I1 => \integral_reg[23]_i_17_n_6\,
      I2 => \integral_reg[27]_i_47_n_0\,
      I3 => \integral[23]_i_11_n_0\,
      O => \integral[23]_i_15_n_0\
    );
\integral[23]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(27),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[23]_i_18_n_0\
    );
\integral[23]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(26),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[23]_i_19_n_0\
    );
\integral[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(23),
      I1 => \integral_reg[23]_i_6_n_4\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[23]_i_7_n_4\,
      O => \integral[23]_i_2_n_0\
    );
\integral[23]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(25),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[23]_i_20_n_0\
    );
\integral[23]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(24),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[23]_i_21_n_0\
    );
\integral[23]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(27),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(28),
      O => \integral[23]_i_22_n_0\
    );
\integral[23]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(26),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(27),
      O => \integral[23]_i_23_n_0\
    );
\integral[23]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(25),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(26),
      O => \integral[23]_i_24_n_0\
    );
\integral[23]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(24),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(25),
      O => \integral[23]_i_25_n_0\
    );
\integral[23]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => error(31),
      I1 => error(28),
      O => \integral[23]_i_26_n_0\
    );
\integral[23]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => error(30),
      I1 => error(27),
      O => \integral[23]_i_27_n_0\
    );
\integral[23]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(31),
      I1 => error(26),
      I2 => error(29),
      O => \integral[23]_i_28_n_0\
    );
\integral[23]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(29),
      I1 => error(30),
      O => \integral[23]_i_29_n_0\
    );
\integral[23]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(22),
      I1 => \integral_reg[23]_i_6_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[23]_i_7_n_5\,
      O => \integral[23]_i_3_n_0\
    );
\integral[23]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(28),
      I1 => error(31),
      I2 => error(29),
      O => \integral[23]_i_30_n_0\
    );
\integral[23]_i_31\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1EE1"
    )
        port map (
      I0 => error(27),
      I1 => error(30),
      I2 => error(28),
      I3 => error(31),
      O => \integral[23]_i_31_n_0\
    );
\integral[23]_i_32\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"718E8E71"
    )
        port map (
      I0 => error(29),
      I1 => error(26),
      I2 => error(31),
      I3 => error(27),
      I4 => error(30),
      O => \integral[23]_i_32_n_0\
    );
\integral[23]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(21),
      I1 => \integral_reg[23]_i_6_n_6\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[23]_i_7_n_6\,
      O => \integral[23]_i_4_n_0\
    );
\integral[23]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(20),
      I1 => \integral_reg[23]_i_6_n_7\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[23]_i_7_n_7\,
      O => \integral[23]_i_5_n_0\
    );
\integral[23]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_4\,
      I1 => \integral_reg[23]_i_17_n_4\,
      I2 => \integral_reg[27]_i_47_n_0\,
      O => \integral[23]_i_8_n_0\
    );
\integral[23]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \integral_reg[23]_i_16_n_5\,
      I1 => \integral_reg[23]_i_17_n_5\,
      I2 => \integral_reg[27]_i_47_n_0\,
      O => \integral[23]_i_9_n_0\
    );
\integral[27]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_4\,
      I1 => \integral_reg[27]_i_8_n_6\,
      O => \integral[27]_i_10_n_0\
    );
\integral[27]_i_100\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_6\,
      I1 => \integral_reg[7]_i_7_n_4\,
      I2 => \integral_reg[15]_i_7_n_7\,
      O => \integral[27]_i_100_n_0\
    );
\integral[27]_i_101\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_7\,
      I1 => \integral_reg[7]_i_7_n_5\,
      I2 => \integral_reg[11]_i_7_n_4\,
      O => \integral[27]_i_101_n_0\
    );
\integral[27]_i_102\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[7]_i_7_n_4\,
      I1 => \integral_reg[7]_i_7_n_6\,
      I2 => \integral_reg[11]_i_7_n_5\,
      O => \integral[27]_i_102_n_0\
    );
\integral[27]_i_103\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_6\,
      I1 => \integral_reg[11]_i_7_n_7\,
      I2 => \integral_reg[11]_i_7_n_5\,
      I3 => \integral_reg[11]_i_7_n_6\,
      I4 => \integral_reg[11]_i_7_n_4\,
      I5 => \integral_reg[15]_i_7_n_5\,
      O => \integral[27]_i_103_n_0\
    );
\integral[27]_i_104\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_7\,
      I1 => \integral_reg[7]_i_7_n_4\,
      I2 => \integral_reg[11]_i_7_n_6\,
      I3 => \integral_reg[11]_i_7_n_7\,
      I4 => \integral_reg[11]_i_7_n_5\,
      I5 => \integral_reg[15]_i_7_n_6\,
      O => \integral[27]_i_104_n_0\
    );
\integral[27]_i_105\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_4\,
      I1 => \integral_reg[7]_i_7_n_5\,
      I2 => \integral_reg[11]_i_7_n_7\,
      I3 => \integral_reg[7]_i_7_n_4\,
      I4 => \integral_reg[11]_i_7_n_6\,
      I5 => \integral_reg[15]_i_7_n_7\,
      O => \integral[27]_i_105_n_0\
    );
\integral[27]_i_106\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_5\,
      I1 => \integral_reg[7]_i_7_n_6\,
      I2 => \integral_reg[7]_i_7_n_4\,
      I3 => \integral_reg[7]_i_7_n_5\,
      I4 => \integral_reg[11]_i_7_n_7\,
      I5 => \integral_reg[11]_i_7_n_4\,
      O => \integral[27]_i_106_n_0\
    );
\integral[27]_i_108\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_48_n_7\,
      I1 => error(16),
      O => \integral[27]_i_108_n_0\
    );
\integral[27]_i_109\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_79_n_4\,
      I1 => error(15),
      O => \integral[27]_i_109_n_0\
    );
\integral[27]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_5\,
      I1 => \integral_reg[27]_i_8_n_7\,
      O => \integral[27]_i_11_n_0\
    );
\integral[27]_i_110\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_79_n_5\,
      I1 => error(14),
      O => \integral[27]_i_110_n_0\
    );
\integral[27]_i_111\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_79_n_6\,
      I1 => error(13),
      O => \integral[27]_i_111_n_0\
    );
\integral[27]_i_112\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(16),
      I1 => \integral_reg[27]_i_48_n_7\,
      I2 => \integral_reg[27]_i_48_n_6\,
      I3 => error(17),
      O => \integral[27]_i_112_n_0\
    );
\integral[27]_i_113\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(15),
      I1 => \integral_reg[27]_i_79_n_4\,
      I2 => \integral_reg[27]_i_48_n_7\,
      I3 => error(16),
      O => \integral[27]_i_113_n_0\
    );
\integral[27]_i_114\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(14),
      I1 => \integral_reg[27]_i_79_n_5\,
      I2 => \integral_reg[27]_i_79_n_4\,
      I3 => error(15),
      O => \integral[27]_i_114_n_0\
    );
\integral[27]_i_115\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(13),
      I1 => \integral_reg[27]_i_79_n_6\,
      I2 => \integral_reg[27]_i_79_n_5\,
      I3 => error(14),
      O => \integral[27]_i_115_n_0\
    );
\integral[27]_i_116\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(31),
      O => \integral[27]_i_116_n_0\
    );
\integral[27]_i_117\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(30),
      O => \integral[27]_i_117_n_0\
    );
\integral[27]_i_118\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(29),
      O => \integral[27]_i_118_n_0\
    );
\integral[27]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_4\,
      I1 => \integral_reg[23]_i_7_n_6\,
      I2 => \integral_reg[27]_i_8_n_5\,
      O => \integral[27]_i_12_n_0\
    );
\integral[27]_i_120\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[7]_i_7_n_5\,
      I1 => \integral_reg[7]_i_7_n_7\,
      I2 => \integral_reg[11]_i_7_n_6\,
      O => \integral[27]_i_120_n_0\
    );
\integral[27]_i_121\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[7]_i_7_n_6\,
      I1 => \integral_reg[3]_i_7_n_4\,
      I2 => \integral_reg[11]_i_7_n_7\,
      O => \integral[27]_i_121_n_0\
    );
\integral[27]_i_122\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[7]_i_7_n_7\,
      I1 => \integral_reg[3]_i_7_n_5\,
      I2 => \integral_reg[7]_i_7_n_4\,
      O => \integral[27]_i_122_n_0\
    );
\integral[27]_i_123\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_4\,
      I1 => \integral_reg[3]_i_7_n_6\,
      I2 => \integral_reg[7]_i_7_n_5\,
      O => \integral[27]_i_123_n_0\
    );
\integral[27]_i_124\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_6\,
      I1 => \integral_reg[7]_i_7_n_7\,
      I2 => \integral_reg[7]_i_7_n_5\,
      I3 => \integral_reg[7]_i_7_n_6\,
      I4 => \integral_reg[7]_i_7_n_4\,
      I5 => \integral_reg[11]_i_7_n_5\,
      O => \integral[27]_i_124_n_0\
    );
\integral[27]_i_125\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_7\,
      I1 => \integral_reg[3]_i_7_n_4\,
      I2 => \integral_reg[7]_i_7_n_6\,
      I3 => \integral_reg[7]_i_7_n_7\,
      I4 => \integral_reg[7]_i_7_n_5\,
      I5 => \integral_reg[11]_i_7_n_6\,
      O => \integral[27]_i_125_n_0\
    );
\integral[27]_i_126\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[7]_i_7_n_4\,
      I1 => \integral_reg[3]_i_7_n_5\,
      I2 => \integral_reg[7]_i_7_n_7\,
      I3 => \integral_reg[3]_i_7_n_4\,
      I4 => \integral_reg[7]_i_7_n_6\,
      I5 => \integral_reg[11]_i_7_n_7\,
      O => \integral[27]_i_126_n_0\
    );
\integral[27]_i_127\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[7]_i_7_n_5\,
      I1 => \integral_reg[3]_i_7_n_6\,
      I2 => \integral_reg[3]_i_7_n_4\,
      I3 => \integral_reg[3]_i_7_n_5\,
      I4 => \integral_reg[7]_i_7_n_7\,
      I5 => \integral_reg[7]_i_7_n_4\,
      O => \integral[27]_i_127_n_0\
    );
\integral[27]_i_129\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_79_n_7\,
      I1 => error(12),
      O => \integral[27]_i_129_n_0\
    );
\integral[27]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4B"
    )
        port map (
      I0 => \integral_reg[27]_i_8_n_5\,
      I1 => \integral_reg[27]_i_8_n_7\,
      I2 => \integral_reg[27]_i_8_n_6\,
      O => \integral[27]_i_13_n_0\
    );
\integral[27]_i_130\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_98_n_4\,
      I1 => error(11),
      O => \integral[27]_i_130_n_0\
    );
\integral[27]_i_131\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_98_n_5\,
      I1 => error(10),
      O => \integral[27]_i_131_n_0\
    );
\integral[27]_i_132\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_98_n_6\,
      I1 => error(9),
      O => \integral[27]_i_132_n_0\
    );
\integral[27]_i_133\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(12),
      I1 => \integral_reg[27]_i_79_n_7\,
      I2 => \integral_reg[27]_i_79_n_6\,
      I3 => error(13),
      O => \integral[27]_i_133_n_0\
    );
\integral[27]_i_134\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(11),
      I1 => \integral_reg[27]_i_98_n_4\,
      I2 => \integral_reg[27]_i_79_n_7\,
      I3 => error(12),
      O => \integral[27]_i_134_n_0\
    );
\integral[27]_i_135\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(10),
      I1 => \integral_reg[27]_i_98_n_5\,
      I2 => \integral_reg[27]_i_98_n_4\,
      I3 => error(11),
      O => \integral[27]_i_135_n_0\
    );
\integral[27]_i_136\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(9),
      I1 => \integral_reg[27]_i_98_n_6\,
      I2 => \integral_reg[27]_i_98_n_5\,
      I3 => error(10),
      O => \integral[27]_i_136_n_0\
    );
\integral[27]_i_137\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_5\,
      I1 => \integral_reg[3]_i_7_n_7\,
      I2 => \integral_reg[7]_i_7_n_6\,
      O => \integral[27]_i_137_n_0\
    );
\integral[27]_i_138\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_7\,
      I1 => \integral_reg[3]_i_7_n_5\,
      I2 => \integral_reg[7]_i_7_n_6\,
      O => \integral[27]_i_138_n_0\
    );
\integral[27]_i_139\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_4\,
      I1 => \integral_reg[3]_i_7_n_7\,
      O => \integral[27]_i_139_n_0\
    );
\integral[27]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => \integral_reg[27]_i_8_n_6\,
      I1 => \integral_reg[23]_i_7_n_4\,
      I2 => \integral_reg[27]_i_8_n_5\,
      I3 => \integral_reg[27]_i_8_n_7\,
      O => \integral[27]_i_14_n_0\
    );
\integral[27]_i_140\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[7]_i_7_n_6\,
      I1 => \integral_reg[3]_i_7_n_7\,
      I2 => \integral_reg[3]_i_7_n_5\,
      I3 => \integral_reg[3]_i_7_n_6\,
      I4 => \integral_reg[3]_i_7_n_4\,
      I5 => \integral_reg[7]_i_7_n_5\,
      O => \integral[27]_i_140_n_0\
    );
\integral[27]_i_141\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69966969"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_7\,
      I1 => \integral_reg[3]_i_7_n_5\,
      I2 => \integral_reg[7]_i_7_n_6\,
      I3 => \integral_reg[3]_i_7_n_6\,
      I4 => \integral_reg[7]_i_7_n_7\,
      O => \integral[27]_i_141_n_0\
    );
\integral[27]_i_142\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_7\,
      I1 => \integral_reg[3]_i_7_n_4\,
      I2 => \integral_reg[3]_i_7_n_6\,
      I3 => \integral_reg[7]_i_7_n_7\,
      O => \integral[27]_i_142_n_0\
    );
\integral[27]_i_143\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_4\,
      I1 => \integral_reg[3]_i_7_n_7\,
      O => \integral[27]_i_143_n_0\
    );
\integral[27]_i_145\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_98_n_7\,
      I1 => error(8),
      O => \integral[27]_i_145_n_0\
    );
\integral[27]_i_146\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_119_n_4\,
      I1 => error(7),
      O => \integral[27]_i_146_n_0\
    );
\integral[27]_i_147\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_119_n_5\,
      I1 => error(6),
      O => \integral[27]_i_147_n_0\
    );
\integral[27]_i_148\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \integral_reg[27]_i_119_n_6\,
      I1 => error(5),
      O => \integral[27]_i_148_n_0\
    );
\integral[27]_i_149\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(8),
      I1 => \integral_reg[27]_i_98_n_7\,
      I2 => \integral_reg[27]_i_98_n_6\,
      I3 => error(9),
      O => \integral[27]_i_149_n_0\
    );
\integral[27]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => \integral_reg[27]_i_8_n_7\,
      I1 => \integral_reg[23]_i_7_n_5\,
      I2 => \integral_reg[27]_i_8_n_6\,
      I3 => \integral_reg[23]_i_7_n_4\,
      O => \integral[27]_i_15_n_0\
    );
\integral[27]_i_150\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(7),
      I1 => \integral_reg[27]_i_119_n_4\,
      I2 => \integral_reg[27]_i_98_n_7\,
      I3 => error(8),
      O => \integral[27]_i_150_n_0\
    );
\integral[27]_i_151\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(6),
      I1 => \integral_reg[27]_i_119_n_5\,
      I2 => \integral_reg[27]_i_119_n_4\,
      I3 => error(7),
      O => \integral[27]_i_151_n_0\
    );
\integral[27]_i_152\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => error(5),
      I1 => \integral_reg[27]_i_119_n_6\,
      I2 => \integral_reg[27]_i_119_n_5\,
      I3 => error(6),
      O => \integral[27]_i_152_n_0\
    );
\integral[27]_i_153\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \integral_reg[27]_i_119_n_7\,
      I1 => error(4),
      O => \integral[27]_i_153_n_0\
    );
\integral[27]_i_154\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_5\,
      I1 => error(3),
      O => \integral[27]_i_154_n_0\
    );
\integral[27]_i_155\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_6\,
      I1 => error(2),
      O => \integral[27]_i_155_n_0\
    );
\integral[27]_i_156\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_7\,
      I1 => error(1),
      O => \integral[27]_i_156_n_0\
    );
\integral[27]_i_157\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D22D"
    )
        port map (
      I0 => error(4),
      I1 => \integral_reg[27]_i_119_n_7\,
      I2 => \integral_reg[27]_i_119_n_6\,
      I3 => error(5),
      O => \integral[27]_i_157_n_0\
    );
\integral[27]_i_158\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4BB4"
    )
        port map (
      I0 => error(3),
      I1 => \integral_reg[3]_i_7_n_5\,
      I2 => \integral_reg[27]_i_119_n_7\,
      I3 => error(4),
      O => \integral[27]_i_158_n_0\
    );
\integral[27]_i_159\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(2),
      I1 => \integral_reg[3]_i_7_n_6\,
      I2 => \integral_reg[3]_i_7_n_5\,
      I3 => error(3),
      O => \integral[27]_i_159_n_0\
    );
\integral[27]_i_16\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"718E8E71"
    )
        port map (
      I0 => \integral_reg[27]_i_8_n_5\,
      I1 => \integral_reg[23]_i_7_n_6\,
      I2 => \integral_reg[23]_i_7_n_4\,
      I3 => \integral_reg[27]_i_8_n_7\,
      I4 => \integral_reg[23]_i_7_n_5\,
      O => \integral[27]_i_16_n_0\
    );
\integral[27]_i_160\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => error(1),
      I1 => \integral_reg[3]_i_7_n_7\,
      I2 => \integral_reg[3]_i_7_n_6\,
      I3 => error(2),
      O => \integral[27]_i_160_n_0\
    );
\integral[27]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_6_n_5\,
      I1 => error(30),
      O => \integral[27]_i_18_n_0\
    );
\integral[27]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_6_n_6\,
      I1 => error(29),
      O => \integral[27]_i_19_n_0\
    );
\integral[27]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(26),
      I1 => \integral_reg[27]_i_5_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[27]_i_8_n_5\,
      O => \integral[27]_i_2_n_0\
    );
\integral[27]_i_20\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(30),
      I1 => \integral_reg[27]_i_6_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      O => \integral[27]_i_20_n_0\
    );
\integral[27]_i_21\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(29),
      I1 => \integral_reg[27]_i_6_n_6\,
      I2 => \integral_reg[27]_i_6_n_5\,
      I3 => error(30),
      O => \integral[27]_i_21_n_0\
    );
\integral[27]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \integral_reg[27]_i_45_n_6\,
      I1 => \integral_reg[27]_i_46_n_6\,
      I2 => \integral_reg[27]_i_47_n_0\,
      O => \integral[27]_i_22_n_0\
    );
\integral[27]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \integral_reg[27]_i_45_n_7\,
      I1 => \integral_reg[27]_i_46_n_7\,
      I2 => \integral_reg[27]_i_47_n_0\,
      O => \integral[27]_i_23_n_0\
    );
\integral[27]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E187"
    )
        port map (
      I0 => \integral_reg[27]_i_45_n_5\,
      I1 => \integral_reg[27]_i_46_n_1\,
      I2 => \integral_reg[27]_i_45_n_4\,
      I3 => \integral_reg[27]_i_47_n_0\,
      O => \integral[27]_i_24_n_0\
    );
\integral[27]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral[27]_i_22_n_0\,
      I1 => \integral_reg[27]_i_46_n_1\,
      I2 => \integral_reg[27]_i_45_n_5\,
      I3 => \integral_reg[27]_i_47_n_0\,
      O => \integral[27]_i_25_n_0\
    );
\integral[27]_i_26\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \integral_reg[27]_i_45_n_6\,
      I1 => \integral_reg[27]_i_46_n_6\,
      I2 => \integral_reg[27]_i_47_n_0\,
      I3 => \integral[27]_i_23_n_0\,
      O => \integral[27]_i_26_n_0\
    );
\integral[27]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_5\,
      I1 => \integral_reg[23]_i_7_n_7\,
      I2 => \integral_reg[27]_i_8_n_6\,
      O => \integral[27]_i_28_n_0\
    );
\integral[27]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_6\,
      I1 => \integral_reg[19]_i_7_n_4\,
      I2 => \integral_reg[27]_i_8_n_7\,
      O => \integral[27]_i_29_n_0\
    );
\integral[27]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(25),
      I1 => \integral_reg[27]_i_5_n_6\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[27]_i_8_n_6\,
      O => \integral[27]_i_3_n_0\
    );
\integral[27]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_7\,
      I1 => \integral_reg[19]_i_7_n_5\,
      I2 => \integral_reg[23]_i_7_n_4\,
      O => \integral[27]_i_30_n_0\
    );
\integral[27]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_4\,
      I1 => \integral_reg[19]_i_7_n_6\,
      I2 => \integral_reg[23]_i_7_n_5\,
      O => \integral[27]_i_31_n_0\
    );
\integral[27]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[27]_i_8_n_6\,
      I1 => \integral_reg[23]_i_7_n_7\,
      I2 => \integral_reg[23]_i_7_n_5\,
      I3 => \integral_reg[23]_i_7_n_6\,
      I4 => \integral_reg[23]_i_7_n_4\,
      I5 => \integral_reg[27]_i_8_n_5\,
      O => \integral[27]_i_32_n_0\
    );
\integral[27]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[27]_i_8_n_7\,
      I1 => \integral_reg[19]_i_7_n_4\,
      I2 => \integral_reg[23]_i_7_n_6\,
      I3 => \integral_reg[23]_i_7_n_7\,
      I4 => \integral_reg[23]_i_7_n_5\,
      I5 => \integral_reg[27]_i_8_n_6\,
      O => \integral[27]_i_33_n_0\
    );
\integral[27]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_4\,
      I1 => \integral_reg[19]_i_7_n_5\,
      I2 => \integral_reg[23]_i_7_n_7\,
      I3 => \integral_reg[19]_i_7_n_4\,
      I4 => \integral_reg[23]_i_7_n_6\,
      I5 => \integral_reg[27]_i_8_n_7\,
      O => \integral[27]_i_34_n_0\
    );
\integral[27]_i_35\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_5\,
      I1 => \integral_reg[19]_i_7_n_6\,
      I2 => \integral_reg[19]_i_7_n_4\,
      I3 => \integral_reg[19]_i_7_n_5\,
      I4 => \integral_reg[23]_i_7_n_7\,
      I5 => \integral_reg[23]_i_7_n_4\,
      O => \integral[27]_i_35_n_0\
    );
\integral[27]_i_37\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_6_n_7\,
      I1 => error(28),
      O => \integral[27]_i_37_n_0\
    );
\integral[27]_i_38\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_9_n_4\,
      I1 => error(27),
      O => \integral[27]_i_38_n_0\
    );
\integral[27]_i_39\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_9_n_5\,
      I1 => error(26),
      O => \integral[27]_i_39_n_0\
    );
\integral[27]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(24),
      I1 => \integral_reg[27]_i_5_n_7\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[27]_i_8_n_7\,
      O => \integral[27]_i_4_n_0\
    );
\integral[27]_i_40\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_9_n_6\,
      I1 => error(25),
      O => \integral[27]_i_40_n_0\
    );
\integral[27]_i_41\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(28),
      I1 => \integral_reg[27]_i_6_n_7\,
      I2 => \integral_reg[27]_i_6_n_6\,
      I3 => error(29),
      O => \integral[27]_i_41_n_0\
    );
\integral[27]_i_42\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(27),
      I1 => \integral_reg[27]_i_9_n_4\,
      I2 => \integral_reg[27]_i_6_n_7\,
      I3 => error(28),
      O => \integral[27]_i_42_n_0\
    );
\integral[27]_i_43\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(26),
      I1 => \integral_reg[27]_i_9_n_5\,
      I2 => \integral_reg[27]_i_9_n_4\,
      I3 => error(27),
      O => \integral[27]_i_43_n_0\
    );
\integral[27]_i_44\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(25),
      I1 => \integral_reg[27]_i_9_n_6\,
      I2 => \integral_reg[27]_i_9_n_5\,
      I3 => error(26),
      O => \integral[27]_i_44_n_0\
    );
\integral[27]_i_49\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_5\,
      I1 => \integral_reg[19]_i_7_n_7\,
      I2 => \integral_reg[23]_i_7_n_6\,
      O => \integral[27]_i_49_n_0\
    );
\integral[27]_i_50\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_6\,
      I1 => \integral_reg[15]_i_7_n_4\,
      I2 => \integral_reg[23]_i_7_n_7\,
      O => \integral[27]_i_50_n_0\
    );
\integral[27]_i_51\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_7\,
      I1 => \integral_reg[15]_i_7_n_5\,
      I2 => \integral_reg[19]_i_7_n_4\,
      O => \integral[27]_i_51_n_0\
    );
\integral[27]_i_52\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_4\,
      I1 => \integral_reg[15]_i_7_n_6\,
      I2 => \integral_reg[19]_i_7_n_5\,
      O => \integral[27]_i_52_n_0\
    );
\integral[27]_i_53\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_6\,
      I1 => \integral_reg[19]_i_7_n_7\,
      I2 => \integral_reg[19]_i_7_n_5\,
      I3 => \integral_reg[19]_i_7_n_6\,
      I4 => \integral_reg[19]_i_7_n_4\,
      I5 => \integral_reg[23]_i_7_n_5\,
      O => \integral[27]_i_53_n_0\
    );
\integral[27]_i_54\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[23]_i_7_n_7\,
      I1 => \integral_reg[15]_i_7_n_4\,
      I2 => \integral_reg[19]_i_7_n_6\,
      I3 => \integral_reg[19]_i_7_n_7\,
      I4 => \integral_reg[19]_i_7_n_5\,
      I5 => \integral_reg[23]_i_7_n_6\,
      O => \integral[27]_i_54_n_0\
    );
\integral[27]_i_55\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_4\,
      I1 => \integral_reg[15]_i_7_n_5\,
      I2 => \integral_reg[19]_i_7_n_7\,
      I3 => \integral_reg[15]_i_7_n_4\,
      I4 => \integral_reg[19]_i_7_n_6\,
      I5 => \integral_reg[23]_i_7_n_7\,
      O => \integral[27]_i_55_n_0\
    );
\integral[27]_i_56\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_5\,
      I1 => \integral_reg[15]_i_7_n_6\,
      I2 => \integral_reg[15]_i_7_n_4\,
      I3 => \integral_reg[15]_i_7_n_5\,
      I4 => \integral_reg[19]_i_7_n_7\,
      I5 => \integral_reg[19]_i_7_n_4\,
      O => \integral[27]_i_56_n_0\
    );
\integral[27]_i_58\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_9_n_7\,
      I1 => error(24),
      O => \integral[27]_i_58_n_0\
    );
\integral[27]_i_59\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_27_n_4\,
      I1 => error(23),
      O => \integral[27]_i_59_n_0\
    );
\integral[27]_i_60\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_27_n_5\,
      I1 => error(22),
      O => \integral[27]_i_60_n_0\
    );
\integral[27]_i_61\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_27_n_6\,
      I1 => error(21),
      O => \integral[27]_i_61_n_0\
    );
\integral[27]_i_62\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(24),
      I1 => \integral_reg[27]_i_9_n_7\,
      I2 => \integral_reg[27]_i_9_n_6\,
      I3 => error(25),
      O => \integral[27]_i_62_n_0\
    );
\integral[27]_i_63\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(23),
      I1 => \integral_reg[27]_i_27_n_4\,
      I2 => \integral_reg[27]_i_9_n_7\,
      I3 => error(24),
      O => \integral[27]_i_63_n_0\
    );
\integral[27]_i_64\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(22),
      I1 => \integral_reg[27]_i_27_n_5\,
      I2 => \integral_reg[27]_i_27_n_4\,
      I3 => error(23),
      O => \integral[27]_i_64_n_0\
    );
\integral[27]_i_65\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(21),
      I1 => \integral_reg[27]_i_27_n_6\,
      I2 => \integral_reg[27]_i_27_n_5\,
      I3 => error(22),
      O => \integral[27]_i_65_n_0\
    );
\integral[27]_i_66\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(30),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[27]_i_66_n_0\
    );
\integral[27]_i_67\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(29),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[27]_i_67_n_0\
    );
\integral[27]_i_68\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(28),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[27]_i_68_n_0\
    );
\integral[27]_i_69\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(31),
      I1 => \integral_reg[27]_i_97_n_0\,
      O => \integral[27]_i_69_n_0\
    );
\integral[27]_i_70\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(30),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(31),
      O => \integral[27]_i_70_n_0\
    );
\integral[27]_i_71\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(29),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(30),
      O => \integral[27]_i_71_n_0\
    );
\integral[27]_i_72\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => error(28),
      I1 => \integral_reg[27]_i_97_n_0\,
      I2 => error(29),
      O => \integral[27]_i_72_n_0\
    );
\integral[27]_i_73\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(31),
      O => \integral[27]_i_73_n_0\
    );
\integral[27]_i_74\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(30),
      I1 => error(31),
      O => \integral[27]_i_74_n_0\
    );
\integral[27]_i_75\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => error(29),
      I1 => error(31),
      O => \integral[27]_i_75_n_0\
    );
\integral[27]_i_76\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(31),
      O => \integral[27]_i_76_n_0\
    );
\integral[27]_i_77\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(30),
      I1 => error(31),
      O => \integral[27]_i_77_n_0\
    );
\integral[27]_i_78\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4B"
    )
        port map (
      I0 => error(31),
      I1 => error(29),
      I2 => error(30),
      O => \integral[27]_i_78_n_0\
    );
\integral[27]_i_80\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_5\,
      I1 => \integral_reg[15]_i_7_n_7\,
      I2 => \integral_reg[19]_i_7_n_6\,
      O => \integral[27]_i_80_n_0\
    );
\integral[27]_i_81\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_6\,
      I1 => \integral_reg[11]_i_7_n_4\,
      I2 => \integral_reg[19]_i_7_n_7\,
      O => \integral[27]_i_81_n_0\
    );
\integral[27]_i_82\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_7\,
      I1 => \integral_reg[11]_i_7_n_5\,
      I2 => \integral_reg[15]_i_7_n_4\,
      O => \integral[27]_i_82_n_0\
    );
\integral[27]_i_83\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_4\,
      I1 => \integral_reg[11]_i_7_n_6\,
      I2 => \integral_reg[15]_i_7_n_5\,
      O => \integral[27]_i_83_n_0\
    );
\integral[27]_i_84\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_6\,
      I1 => \integral_reg[15]_i_7_n_7\,
      I2 => \integral_reg[15]_i_7_n_5\,
      I3 => \integral_reg[15]_i_7_n_6\,
      I4 => \integral_reg[15]_i_7_n_4\,
      I5 => \integral_reg[19]_i_7_n_5\,
      O => \integral[27]_i_84_n_0\
    );
\integral[27]_i_85\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[19]_i_7_n_7\,
      I1 => \integral_reg[11]_i_7_n_4\,
      I2 => \integral_reg[15]_i_7_n_6\,
      I3 => \integral_reg[15]_i_7_n_7\,
      I4 => \integral_reg[15]_i_7_n_5\,
      I5 => \integral_reg[19]_i_7_n_6\,
      O => \integral[27]_i_85_n_0\
    );
\integral[27]_i_86\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_4\,
      I1 => \integral_reg[11]_i_7_n_5\,
      I2 => \integral_reg[15]_i_7_n_7\,
      I3 => \integral_reg[11]_i_7_n_4\,
      I4 => \integral_reg[15]_i_7_n_6\,
      I5 => \integral_reg[19]_i_7_n_7\,
      O => \integral[27]_i_86_n_0\
    );
\integral[27]_i_87\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => \integral_reg[15]_i_7_n_5\,
      I1 => \integral_reg[11]_i_7_n_6\,
      I2 => \integral_reg[11]_i_7_n_4\,
      I3 => \integral_reg[11]_i_7_n_5\,
      I4 => \integral_reg[15]_i_7_n_7\,
      I5 => \integral_reg[15]_i_7_n_4\,
      O => \integral[27]_i_87_n_0\
    );
\integral[27]_i_89\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_27_n_7\,
      I1 => error(20),
      O => \integral[27]_i_89_n_0\
    );
\integral[27]_i_90\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_48_n_4\,
      I1 => error(19),
      O => \integral[27]_i_90_n_0\
    );
\integral[27]_i_91\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_48_n_5\,
      I1 => error(18),
      O => \integral[27]_i_91_n_0\
    );
\integral[27]_i_92\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \integral_reg[27]_i_48_n_6\,
      I1 => error(17),
      O => \integral[27]_i_92_n_0\
    );
\integral[27]_i_93\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(20),
      I1 => \integral_reg[27]_i_27_n_7\,
      I2 => \integral_reg[27]_i_27_n_6\,
      I3 => error(21),
      O => \integral[27]_i_93_n_0\
    );
\integral[27]_i_94\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(19),
      I1 => \integral_reg[27]_i_48_n_4\,
      I2 => \integral_reg[27]_i_27_n_7\,
      I3 => error(20),
      O => \integral[27]_i_94_n_0\
    );
\integral[27]_i_95\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(18),
      I1 => \integral_reg[27]_i_48_n_5\,
      I2 => \integral_reg[27]_i_48_n_4\,
      I3 => error(19),
      O => \integral[27]_i_95_n_0\
    );
\integral[27]_i_96\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => error(17),
      I1 => \integral_reg[27]_i_48_n_6\,
      I2 => \integral_reg[27]_i_48_n_5\,
      I3 => error(18),
      O => \integral[27]_i_96_n_0\
    );
\integral[27]_i_99\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => \integral_reg[11]_i_7_n_5\,
      I1 => \integral_reg[11]_i_7_n_7\,
      I2 => \integral_reg[15]_i_7_n_6\,
      O => \integral[27]_i_99_n_0\
    );
\integral[3]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_4\,
      I1 => \integral_reg[3]_i_28_n_4\,
      I2 => \integral_reg[7]_i_18_n_6\,
      O => \integral[3]_i_10_n_0\
    );
\integral[3]_i_100\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(10),
      I1 => error(6),
      I2 => error(8),
      I3 => error(7),
      I4 => error(9),
      I5 => error(11),
      O => \integral[3]_i_100_n_0\
    );
\integral[3]_i_101\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(9),
      I1 => error(5),
      I2 => error(7),
      I3 => error(6),
      I4 => error(8),
      I5 => error(10),
      O => \integral[3]_i_101_n_0\
    );
\integral[3]_i_104\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \integral_reg[3]_i_147_n_4\,
      I1 => \integral_reg[3]_i_114_n_6\,
      O => \integral[3]_i_104_n_0\
    );
\integral[3]_i_105\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \integral_reg[3]_i_114_n_7\,
      I1 => \integral_reg[3]_i_147_n_5\,
      O => \integral[3]_i_105_n_0\
    );
\integral[3]_i_106\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(1),
      I1 => \integral_reg[3]_i_147_n_6\,
      O => \integral[3]_i_106_n_0\
    );
\integral[3]_i_107\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \integral_reg[3]_i_148_n_7\,
      I1 => \integral_reg[3]_i_147_n_7\,
      O => \integral[3]_i_107_n_0\
    );
\integral[3]_i_108\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_7\,
      I1 => error(0),
      I2 => \integral_reg[3]_i_114_n_5\,
      I3 => \integral[3]_i_104_n_0\,
      O => \integral[3]_i_108_n_0\
    );
\integral[3]_i_109\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9666"
    )
        port map (
      I0 => \integral_reg[3]_i_147_n_4\,
      I1 => \integral_reg[3]_i_114_n_6\,
      I2 => \integral_reg[3]_i_114_n_7\,
      I3 => \integral_reg[3]_i_147_n_5\,
      O => \integral[3]_i_109_n_0\
    );
\integral[3]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_5\,
      I1 => \integral_reg[3]_i_28_n_5\,
      I2 => \integral_reg[7]_i_18_n_7\,
      O => \integral[3]_i_11_n_0\
    );
\integral[3]_i_110\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(1),
      I1 => \integral_reg[3]_i_147_n_6\,
      I2 => \integral_reg[3]_i_147_n_5\,
      I3 => \integral_reg[3]_i_114_n_7\,
      O => \integral[3]_i_110_n_0\
    );
\integral[3]_i_111\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => \integral_reg[3]_i_148_n_7\,
      I1 => \integral_reg[3]_i_147_n_7\,
      I2 => \integral_reg[3]_i_147_n_6\,
      I3 => error(1),
      O => \integral[3]_i_111_n_0\
    );
\integral[3]_i_116\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \integral_reg[3]_i_134_n_4\,
      I1 => \integral_reg[3]_i_115_n_4\,
      I2 => error(0),
      O => \integral[3]_i_116_n_0\
    );
\integral[3]_i_117\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_115_n_5\,
      I1 => \integral_reg[3]_i_134_n_5\,
      O => \integral[3]_i_117_n_0\
    );
\integral[3]_i_118\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_115_n_6\,
      I1 => \integral_reg[3]_i_134_n_6\,
      O => \integral[3]_i_118_n_0\
    );
\integral[3]_i_119\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_115_n_7\,
      I1 => \integral_reg[3]_i_134_n_7\,
      O => \integral[3]_i_119_n_0\
    );
\integral[3]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_6\,
      I1 => \integral_reg[3]_i_28_n_6\,
      I2 => \integral_reg[3]_i_29_n_4\,
      O => \integral[3]_i_12_n_0\
    );
\integral[3]_i_120\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(6),
      I1 => error(1),
      I2 => error(4),
      O => \integral[3]_i_120_n_0\
    );
\integral[3]_i_121\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => error(6),
      I1 => error(1),
      I2 => error(4),
      O => \integral[3]_i_121_n_0\
    );
\integral[3]_i_122\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(4),
      I1 => error(1),
      I2 => error(6),
      I3 => error(7),
      I4 => error(2),
      I5 => error(5),
      O => \integral[3]_i_122_n_0\
    );
\integral[3]_i_123\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69966969"
    )
        port map (
      I0 => error(6),
      I1 => error(1),
      I2 => error(4),
      I3 => error(5),
      I4 => error(0),
      O => \integral[3]_i_123_n_0\
    );
\integral[3]_i_124\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => error(0),
      I1 => error(5),
      I2 => error(3),
      O => \integral[3]_i_124_n_0\
    );
\integral[3]_i_125\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(2),
      I1 => error(4),
      O => \integral[3]_i_125_n_0\
    );
\integral[3]_i_126\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(6),
      I1 => error(4),
      I2 => error(8),
      O => \integral[3]_i_126_n_0\
    );
\integral[3]_i_127\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(5),
      I1 => error(3),
      I2 => error(7),
      O => \integral[3]_i_127_n_0\
    );
\integral[3]_i_128\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(4),
      I1 => error(2),
      I2 => error(6),
      O => \integral[3]_i_128_n_0\
    );
\integral[3]_i_129\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(3),
      I1 => error(1),
      I2 => error(5),
      O => \integral[3]_i_129_n_0\
    );
\integral[3]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_7\,
      I1 => \integral_reg[3]_i_28_n_7\,
      I2 => \integral_reg[3]_i_29_n_5\,
      O => \integral[3]_i_13_n_0\
    );
\integral[3]_i_130\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(8),
      I1 => error(4),
      I2 => error(6),
      I3 => error(5),
      I4 => error(7),
      I5 => error(9),
      O => \integral[3]_i_130_n_0\
    );
\integral[3]_i_131\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(7),
      I1 => error(3),
      I2 => error(5),
      I3 => error(4),
      I4 => error(6),
      I5 => error(8),
      O => \integral[3]_i_131_n_0\
    );
\integral[3]_i_132\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(6),
      I1 => error(2),
      I2 => error(4),
      I3 => error(3),
      I4 => error(5),
      I5 => error(7),
      O => \integral[3]_i_132_n_0\
    );
\integral[3]_i_133\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(5),
      I1 => error(1),
      I2 => error(3),
      I3 => error(4),
      I4 => error(2),
      I5 => error(6),
      O => \integral[3]_i_133_n_0\
    );
\integral[3]_i_135\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(16),
      I1 => error(19),
      O => \integral[3]_i_135_n_0\
    );
\integral[3]_i_136\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(15),
      I1 => error(18),
      O => \integral[3]_i_136_n_0\
    );
\integral[3]_i_137\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(14),
      I1 => error(17),
      O => \integral[3]_i_137_n_0\
    );
\integral[3]_i_138\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(13),
      I1 => error(16),
      O => \integral[3]_i_138_n_0\
    );
\integral[3]_i_139\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(23),
      I1 => error(25),
      I2 => error(29),
      O => \integral[3]_i_139_n_0\
    );
\integral[3]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_7\,
      I1 => \integral_reg[7]_i_17_n_7\,
      I2 => \integral_reg[7]_i_18_n_5\,
      I3 => \integral[3]_i_10_n_0\,
      O => \integral[3]_i_14_n_0\
    );
\integral[3]_i_140\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(22),
      I1 => error(24),
      I2 => error(28),
      O => \integral[3]_i_140_n_0\
    );
\integral[3]_i_141\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(21),
      I1 => error(23),
      I2 => error(27),
      O => \integral[3]_i_141_n_0\
    );
\integral[3]_i_142\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(20),
      I1 => error(22),
      I2 => error(26),
      O => \integral[3]_i_142_n_0\
    );
\integral[3]_i_143\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(24),
      I1 => error(26),
      I2 => error(30),
      I3 => \integral[3]_i_139_n_0\,
      O => \integral[3]_i_143_n_0\
    );
\integral[3]_i_144\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(23),
      I1 => error(25),
      I2 => error(29),
      I3 => \integral[3]_i_140_n_0\,
      O => \integral[3]_i_144_n_0\
    );
\integral[3]_i_145\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(22),
      I1 => error(24),
      I2 => error(28),
      I3 => \integral[3]_i_141_n_0\,
      O => \integral[3]_i_145_n_0\
    );
\integral[3]_i_146\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(21),
      I1 => error(23),
      I2 => error(27),
      I3 => \integral[3]_i_142_n_0\,
      O => \integral[3]_i_146_n_0\
    );
\integral[3]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_4\,
      I1 => \integral_reg[3]_i_28_n_4\,
      I2 => \integral_reg[7]_i_18_n_6\,
      I3 => \integral[3]_i_11_n_0\,
      O => \integral[3]_i_15_n_0\
    );
\integral[3]_i_150\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_149_n_4\,
      I1 => \integral_reg[3]_i_172_n_4\,
      O => \integral[3]_i_150_n_0\
    );
\integral[3]_i_151\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_149_n_5\,
      I1 => \integral_reg[3]_i_172_n_5\,
      O => \integral[3]_i_151_n_0\
    );
\integral[3]_i_152\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_149_n_6\,
      I1 => \integral_reg[3]_i_172_n_6\,
      O => \integral[3]_i_152_n_0\
    );
\integral[3]_i_153\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_149_n_7\,
      I1 => \integral_reg[3]_i_172_n_7\,
      O => \integral[3]_i_153_n_0\
    );
\integral[3]_i_154\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(1),
      I1 => error(3),
      O => \integral[3]_i_154_n_0\
    );
\integral[3]_i_155\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(0),
      I1 => error(2),
      O => \integral[3]_i_155_n_0\
    );
\integral[3]_i_156\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(1),
      O => \integral[3]_i_156_n_0\
    );
\integral[3]_i_157\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(2),
      I1 => error(0),
      I2 => error(4),
      O => \integral[3]_i_157_n_0\
    );
\integral[3]_i_158\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => error(2),
      I1 => error(0),
      I2 => error(4),
      O => \integral[3]_i_158_n_0\
    );
\integral[3]_i_159\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => error(2),
      I1 => error(0),
      O => \integral[3]_i_159_n_0\
    );
\integral[3]_i_16\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_5\,
      I1 => \integral_reg[3]_i_28_n_5\,
      I2 => \integral_reg[7]_i_18_n_7\,
      I3 => \integral[3]_i_12_n_0\,
      O => \integral[3]_i_16_n_0\
    );
\integral[3]_i_160\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(4),
      I1 => error(0),
      I2 => error(2),
      I3 => error(3),
      I4 => error(1),
      I5 => error(5),
      O => \integral[3]_i_160_n_0\
    );
\integral[3]_i_161\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69966969"
    )
        port map (
      I0 => error(2),
      I1 => error(0),
      I2 => error(4),
      I3 => error(1),
      I4 => error(3),
      O => \integral[3]_i_161_n_0\
    );
\integral[3]_i_162\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2DD2"
    )
        port map (
      I0 => error(0),
      I1 => error(2),
      I2 => error(1),
      I3 => error(3),
      O => \integral[3]_i_162_n_0\
    );
\integral[3]_i_163\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => error(2),
      I1 => error(0),
      O => \integral[3]_i_163_n_0\
    );
\integral[3]_i_164\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(19),
      I1 => error(21),
      I2 => error(25),
      O => \integral[3]_i_164_n_0\
    );
\integral[3]_i_165\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(18),
      I1 => error(20),
      I2 => error(24),
      O => \integral[3]_i_165_n_0\
    );
\integral[3]_i_166\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(17),
      I1 => error(19),
      I2 => error(23),
      O => \integral[3]_i_166_n_0\
    );
\integral[3]_i_167\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(16),
      I1 => error(18),
      I2 => error(22),
      O => \integral[3]_i_167_n_0\
    );
\integral[3]_i_168\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(20),
      I1 => error(22),
      I2 => error(26),
      I3 => \integral[3]_i_164_n_0\,
      O => \integral[3]_i_168_n_0\
    );
\integral[3]_i_169\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(19),
      I1 => error(21),
      I2 => error(25),
      I3 => \integral[3]_i_165_n_0\,
      O => \integral[3]_i_169_n_0\
    );
\integral[3]_i_17\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_6\,
      I1 => \integral_reg[3]_i_28_n_6\,
      I2 => \integral_reg[3]_i_29_n_4\,
      I3 => \integral[3]_i_13_n_0\,
      O => \integral[3]_i_17_n_0\
    );
\integral[3]_i_170\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(18),
      I1 => error(20),
      I2 => error(24),
      I3 => \integral[3]_i_166_n_0\,
      O => \integral[3]_i_170_n_0\
    );
\integral[3]_i_171\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(17),
      I1 => error(19),
      I2 => error(23),
      I3 => \integral[3]_i_167_n_0\,
      O => \integral[3]_i_171_n_0\
    );
\integral[3]_i_173\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(12),
      I1 => error(15),
      O => \integral[3]_i_173_n_0\
    );
\integral[3]_i_174\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(11),
      I1 => error(14),
      O => \integral[3]_i_174_n_0\
    );
\integral[3]_i_175\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(10),
      I1 => error(13),
      O => \integral[3]_i_175_n_0\
    );
\integral[3]_i_176\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(9),
      I1 => error(12),
      O => \integral[3]_i_176_n_0\
    );
\integral[3]_i_179\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_178_n_4\,
      I1 => \integral_reg[3]_i_194_n_4\,
      O => \integral[3]_i_179_n_0\
    );
\integral[3]_i_180\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_178_n_5\,
      I1 => \integral_reg[3]_i_194_n_5\,
      O => \integral[3]_i_180_n_0\
    );
\integral[3]_i_181\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_178_n_6\,
      I1 => \integral_reg[3]_i_194_n_6\,
      O => \integral[3]_i_181_n_0\
    );
\integral[3]_i_182\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_178_n_7\,
      I1 => \integral_reg[3]_i_194_n_7\,
      O => \integral[3]_i_182_n_0\
    );
\integral[3]_i_183\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(0),
      I1 => error(3),
      O => \integral[3]_i_183_n_0\
    );
\integral[3]_i_184\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(2),
      O => \integral[3]_i_184_n_0\
    );
\integral[3]_i_185\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => error(1),
      O => \integral[3]_i_185_n_0\
    );
\integral[3]_i_186\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(15),
      I1 => error(17),
      I2 => error(21),
      O => \integral[3]_i_186_n_0\
    );
\integral[3]_i_187\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(14),
      I1 => error(16),
      I2 => error(20),
      O => \integral[3]_i_187_n_0\
    );
\integral[3]_i_188\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(13),
      I1 => error(15),
      I2 => error(19),
      O => \integral[3]_i_188_n_0\
    );
\integral[3]_i_189\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(12),
      I1 => error(14),
      I2 => error(18),
      O => \integral[3]_i_189_n_0\
    );
\integral[3]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_4\,
      I1 => \integral_reg[3]_i_40_n_4\,
      I2 => \integral_reg[3]_i_29_n_6\,
      O => \integral[3]_i_19_n_0\
    );
\integral[3]_i_190\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(16),
      I1 => error(18),
      I2 => error(22),
      I3 => \integral[3]_i_186_n_0\,
      O => \integral[3]_i_190_n_0\
    );
\integral[3]_i_191\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(15),
      I1 => error(17),
      I2 => error(21),
      I3 => \integral[3]_i_187_n_0\,
      O => \integral[3]_i_191_n_0\
    );
\integral[3]_i_192\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(14),
      I1 => error(16),
      I2 => error(20),
      I3 => \integral[3]_i_188_n_0\,
      O => \integral[3]_i_192_n_0\
    );
\integral[3]_i_193\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(13),
      I1 => error(15),
      I2 => error(19),
      I3 => \integral[3]_i_189_n_0\,
      O => \integral[3]_i_193_n_0\
    );
\integral[3]_i_195\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(8),
      I1 => error(11),
      O => \integral[3]_i_195_n_0\
    );
\integral[3]_i_196\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(7),
      I1 => error(10),
      O => \integral[3]_i_196_n_0\
    );
\integral[3]_i_197\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(6),
      I1 => error(9),
      O => \integral[3]_i_197_n_0\
    );
\integral[3]_i_198\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(5),
      I1 => error(8),
      O => \integral[3]_i_198_n_0\
    );
\integral[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(3),
      I1 => \integral_reg[3]_i_6_n_4\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[3]_i_7_n_4\,
      O => \integral[3]_i_2_n_0\
    );
\integral[3]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_5\,
      I1 => \integral_reg[3]_i_40_n_5\,
      I2 => \integral_reg[3]_i_29_n_7\,
      O => \integral[3]_i_20_n_0\
    );
\integral[3]_i_200\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_199_n_4\,
      I1 => \integral_reg[3]_i_148_n_4\,
      O => \integral[3]_i_200_n_0\
    );
\integral[3]_i_201\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_199_n_5\,
      I1 => \integral_reg[3]_i_148_n_5\,
      O => \integral[3]_i_201_n_0\
    );
\integral[3]_i_202\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_199_n_6\,
      I1 => \integral_reg[3]_i_148_n_6\,
      O => \integral[3]_i_202_n_0\
    );
\integral[3]_i_203\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral_reg[3]_i_199_n_7\,
      I1 => error(0),
      O => \integral[3]_i_203_n_0\
    );
\integral[3]_i_204\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(11),
      I1 => error(13),
      I2 => error(17),
      O => \integral[3]_i_204_n_0\
    );
\integral[3]_i_205\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(10),
      I1 => error(12),
      I2 => error(16),
      O => \integral[3]_i_205_n_0\
    );
\integral[3]_i_206\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(9),
      I1 => error(11),
      I2 => error(15),
      O => \integral[3]_i_206_n_0\
    );
\integral[3]_i_207\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(8),
      I1 => error(10),
      I2 => error(14),
      O => \integral[3]_i_207_n_0\
    );
\integral[3]_i_208\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(12),
      I1 => error(14),
      I2 => error(18),
      I3 => \integral[3]_i_204_n_0\,
      O => \integral[3]_i_208_n_0\
    );
\integral[3]_i_209\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(11),
      I1 => error(13),
      I2 => error(17),
      I3 => \integral[3]_i_205_n_0\,
      O => \integral[3]_i_209_n_0\
    );
\integral[3]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_6\,
      I1 => \integral_reg[3]_i_40_n_6\,
      I2 => \integral_reg[3]_i_41_n_4\,
      O => \integral[3]_i_21_n_0\
    );
\integral[3]_i_210\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(10),
      I1 => error(12),
      I2 => error(16),
      I3 => \integral[3]_i_206_n_0\,
      O => \integral[3]_i_210_n_0\
    );
\integral[3]_i_211\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(9),
      I1 => error(11),
      I2 => error(15),
      I3 => \integral[3]_i_207_n_0\,
      O => \integral[3]_i_211_n_0\
    );
\integral[3]_i_212\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(4),
      I1 => error(7),
      O => \integral[3]_i_212_n_0\
    );
\integral[3]_i_213\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(3),
      I1 => error(6),
      O => \integral[3]_i_213_n_0\
    );
\integral[3]_i_214\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(2),
      I1 => error(5),
      O => \integral[3]_i_214_n_0\
    );
\integral[3]_i_215\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(1),
      I1 => error(4),
      O => \integral[3]_i_215_n_0\
    );
\integral[3]_i_217\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(7),
      I1 => error(9),
      I2 => error(13),
      O => \integral[3]_i_217_n_0\
    );
\integral[3]_i_218\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(6),
      I1 => error(8),
      I2 => error(12),
      O => \integral[3]_i_218_n_0\
    );
\integral[3]_i_219\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(5),
      I1 => error(7),
      I2 => error(11),
      O => \integral[3]_i_219_n_0\
    );
\integral[3]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_7\,
      I1 => \integral_reg[3]_i_40_n_7\,
      I2 => \integral_reg[3]_i_41_n_5\,
      O => \integral[3]_i_22_n_0\
    );
\integral[3]_i_220\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(4),
      I1 => error(6),
      I2 => error(10),
      O => \integral[3]_i_220_n_0\
    );
\integral[3]_i_221\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(8),
      I1 => error(10),
      I2 => error(14),
      I3 => \integral[3]_i_217_n_0\,
      O => \integral[3]_i_221_n_0\
    );
\integral[3]_i_222\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(7),
      I1 => error(9),
      I2 => error(13),
      I3 => \integral[3]_i_218_n_0\,
      O => \integral[3]_i_222_n_0\
    );
\integral[3]_i_223\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(6),
      I1 => error(8),
      I2 => error(12),
      I3 => \integral[3]_i_219_n_0\,
      O => \integral[3]_i_223_n_0\
    );
\integral[3]_i_224\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(5),
      I1 => error(7),
      I2 => error(11),
      I3 => \integral[3]_i_220_n_0\,
      O => \integral[3]_i_224_n_0\
    );
\integral[3]_i_226\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(3),
      I1 => error(5),
      I2 => error(9),
      O => \integral[3]_i_226_n_0\
    );
\integral[3]_i_227\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(2),
      I1 => error(4),
      I2 => error(8),
      O => \integral[3]_i_227_n_0\
    );
\integral[3]_i_228\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(1),
      I1 => error(3),
      I2 => error(7),
      O => \integral[3]_i_228_n_0\
    );
\integral[3]_i_229\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => error(7),
      I1 => error(1),
      I2 => error(3),
      O => \integral[3]_i_229_n_0\
    );
\integral[3]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_27_n_7\,
      I1 => \integral_reg[3]_i_28_n_7\,
      I2 => \integral_reg[3]_i_29_n_5\,
      I3 => \integral[3]_i_19_n_0\,
      O => \integral[3]_i_23_n_0\
    );
\integral[3]_i_230\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(4),
      I1 => error(6),
      I2 => error(10),
      I3 => \integral[3]_i_226_n_0\,
      O => \integral[3]_i_230_n_0\
    );
\integral[3]_i_231\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(3),
      I1 => error(5),
      I2 => error(9),
      I3 => \integral[3]_i_227_n_0\,
      O => \integral[3]_i_231_n_0\
    );
\integral[3]_i_232\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => error(2),
      I1 => error(4),
      I2 => error(8),
      I3 => \integral[3]_i_228_n_0\,
      O => \integral[3]_i_232_n_0\
    );
\integral[3]_i_233\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969696"
    )
        port map (
      I0 => error(1),
      I1 => error(3),
      I2 => error(7),
      I3 => error(2),
      I4 => error(0),
      O => \integral[3]_i_233_n_0\
    );
\integral[3]_i_234\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => error(0),
      I1 => error(2),
      I2 => error(6),
      O => \integral[3]_i_234_n_0\
    );
\integral[3]_i_235\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => error(5),
      I1 => error(1),
      O => \integral[3]_i_235_n_0\
    );
\integral[3]_i_236\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => error(4),
      I1 => error(0),
      O => \integral[3]_i_236_n_0\
    );
\integral[3]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_4\,
      I1 => \integral_reg[3]_i_40_n_4\,
      I2 => \integral_reg[3]_i_29_n_6\,
      I3 => \integral[3]_i_20_n_0\,
      O => \integral[3]_i_24_n_0\
    );
\integral[3]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_5\,
      I1 => \integral_reg[3]_i_40_n_5\,
      I2 => \integral_reg[3]_i_29_n_7\,
      I3 => \integral[3]_i_21_n_0\,
      O => \integral[3]_i_25_n_0\
    );
\integral[3]_i_26\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_6\,
      I1 => \integral_reg[3]_i_40_n_6\,
      I2 => \integral_reg[3]_i_41_n_4\,
      I3 => \integral[3]_i_22_n_0\,
      O => \integral[3]_i_26_n_0\
    );
\integral[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(2),
      I1 => \integral_reg[3]_i_6_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[3]_i_7_n_5\,
      O => \integral[3]_i_3_n_0\
    );
\integral[3]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_4\,
      I1 => \integral_reg[3]_i_76_n_4\,
      I2 => \integral_reg[3]_i_41_n_6\,
      O => \integral[3]_i_31_n_0\
    );
\integral[3]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_5\,
      I1 => \integral_reg[3]_i_76_n_5\,
      I2 => \integral_reg[3]_i_41_n_7\,
      O => \integral[3]_i_32_n_0\
    );
\integral[3]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_6\,
      I1 => \integral_reg[3]_i_76_n_6\,
      I2 => \integral_reg[3]_i_77_n_4\,
      O => \integral[3]_i_33_n_0\
    );
\integral[3]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_7\,
      I1 => \integral_reg[3]_i_76_n_7\,
      I2 => \integral_reg[3]_i_77_n_5\,
      O => \integral[3]_i_34_n_0\
    );
\integral[3]_i_35\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_39_n_7\,
      I1 => \integral_reg[3]_i_40_n_7\,
      I2 => \integral_reg[3]_i_41_n_5\,
      I3 => \integral[3]_i_31_n_0\,
      O => \integral[3]_i_35_n_0\
    );
\integral[3]_i_36\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_4\,
      I1 => \integral_reg[3]_i_76_n_4\,
      I2 => \integral_reg[3]_i_41_n_6\,
      I3 => \integral[3]_i_32_n_0\,
      O => \integral[3]_i_36_n_0\
    );
\integral[3]_i_37\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_5\,
      I1 => \integral_reg[3]_i_76_n_5\,
      I2 => \integral_reg[3]_i_41_n_7\,
      I3 => \integral[3]_i_33_n_0\,
      O => \integral[3]_i_37_n_0\
    );
\integral[3]_i_38\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_6\,
      I1 => \integral_reg[3]_i_76_n_6\,
      I2 => \integral_reg[3]_i_77_n_4\,
      I3 => \integral[3]_i_34_n_0\,
      O => \integral[3]_i_38_n_0\
    );
\integral[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(1),
      I1 => \integral_reg[3]_i_6_n_6\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[3]_i_7_n_6\,
      O => \integral[3]_i_4_n_0\
    );
\integral[3]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_5\,
      I1 => \integral_reg[7]_i_44_n_5\,
      I2 => error(7),
      O => \integral[3]_i_42_n_0\
    );
\integral[3]_i_43\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_6\,
      I1 => \integral_reg[7]_i_44_n_6\,
      I2 => error(6),
      O => \integral[3]_i_43_n_0\
    );
\integral[3]_i_44\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_7\,
      I1 => \integral_reg[7]_i_44_n_7\,
      I2 => error(5),
      O => \integral[3]_i_44_n_0\
    );
\integral[3]_i_45\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_4\,
      I1 => \integral_reg[3]_i_103_n_4\,
      I2 => error(4),
      O => \integral[3]_i_45_n_0\
    );
\integral[3]_i_46\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_4\,
      I1 => \integral_reg[7]_i_44_n_4\,
      I2 => error(8),
      I3 => \integral[3]_i_42_n_0\,
      O => \integral[3]_i_46_n_0\
    );
\integral[3]_i_47\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_5\,
      I1 => \integral_reg[7]_i_44_n_5\,
      I2 => error(7),
      I3 => \integral[3]_i_43_n_0\,
      O => \integral[3]_i_47_n_0\
    );
\integral[3]_i_48\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_6\,
      I1 => \integral_reg[7]_i_44_n_6\,
      I2 => error(6),
      I3 => \integral[3]_i_44_n_0\,
      O => \integral[3]_i_48_n_0\
    );
\integral[3]_i_49\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_7\,
      I1 => \integral_reg[7]_i_44_n_7\,
      I2 => error(5),
      I3 => \integral[3]_i_45_n_0\,
      O => \integral[3]_i_49_n_0\
    );
\integral[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(0),
      I1 => \integral_reg[3]_i_6_n_7\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[3]_i_7_n_7\,
      O => \integral[3]_i_5_n_0\
    );
\integral[3]_i_50\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(14),
      I1 => error(9),
      I2 => error(12),
      O => \integral[3]_i_50_n_0\
    );
\integral[3]_i_51\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(13),
      I1 => error(8),
      I2 => error(11),
      O => \integral[3]_i_51_n_0\
    );
\integral[3]_i_52\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(12),
      I1 => error(7),
      I2 => error(10),
      O => \integral[3]_i_52_n_0\
    );
\integral[3]_i_53\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(11),
      I1 => error(6),
      I2 => error(9),
      O => \integral[3]_i_53_n_0\
    );
\integral[3]_i_54\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(12),
      I1 => error(9),
      I2 => error(14),
      I3 => error(15),
      I4 => error(10),
      I5 => error(13),
      O => \integral[3]_i_54_n_0\
    );
\integral[3]_i_55\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(11),
      I1 => error(8),
      I2 => error(13),
      I3 => error(14),
      I4 => error(9),
      I5 => error(12),
      O => \integral[3]_i_55_n_0\
    );
\integral[3]_i_56\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(10),
      I1 => error(7),
      I2 => error(12),
      I3 => error(13),
      I4 => error(8),
      I5 => error(11),
      O => \integral[3]_i_56_n_0\
    );
\integral[3]_i_57\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(9),
      I1 => error(6),
      I2 => error(11),
      I3 => error(12),
      I4 => error(7),
      I5 => error(10),
      O => \integral[3]_i_57_n_0\
    );
\integral[3]_i_58\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(14),
      I1 => error(12),
      I2 => error(16),
      O => \integral[3]_i_58_n_0\
    );
\integral[3]_i_59\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(13),
      I1 => error(11),
      I2 => error(15),
      O => \integral[3]_i_59_n_0\
    );
\integral[3]_i_60\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(12),
      I1 => error(10),
      I2 => error(14),
      O => \integral[3]_i_60_n_0\
    );
\integral[3]_i_61\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(11),
      I1 => error(9),
      I2 => error(13),
      O => \integral[3]_i_61_n_0\
    );
\integral[3]_i_62\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(16),
      I1 => error(12),
      I2 => error(14),
      I3 => error(13),
      I4 => error(15),
      I5 => error(17),
      O => \integral[3]_i_62_n_0\
    );
\integral[3]_i_63\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(15),
      I1 => error(11),
      I2 => error(13),
      I3 => error(12),
      I4 => error(14),
      I5 => error(16),
      O => \integral[3]_i_63_n_0\
    );
\integral[3]_i_64\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(14),
      I1 => error(10),
      I2 => error(12),
      I3 => error(11),
      I4 => error(13),
      I5 => error(15),
      O => \integral[3]_i_64_n_0\
    );
\integral[3]_i_65\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(13),
      I1 => error(9),
      I2 => error(11),
      I3 => error(10),
      I4 => error(12),
      I5 => error(14),
      O => \integral[3]_i_65_n_0\
    );
\integral[3]_i_67\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_4\,
      I1 => \integral_reg[3]_i_113_n_4\,
      I2 => \integral_reg[3]_i_77_n_6\,
      O => \integral[3]_i_67_n_0\
    );
\integral[3]_i_68\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_5\,
      I1 => \integral_reg[3]_i_113_n_5\,
      I2 => \integral_reg[3]_i_77_n_7\,
      O => \integral[3]_i_68_n_0\
    );
\integral[3]_i_69\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_6\,
      I1 => \integral_reg[3]_i_113_n_6\,
      I2 => \integral_reg[3]_i_114_n_4\,
      O => \integral[3]_i_69_n_0\
    );
\integral[3]_i_70\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_7\,
      I1 => error(0),
      I2 => \integral_reg[3]_i_114_n_5\,
      O => \integral[3]_i_70_n_0\
    );
\integral[3]_i_71\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_75_n_7\,
      I1 => \integral_reg[3]_i_76_n_7\,
      I2 => \integral_reg[3]_i_77_n_5\,
      I3 => \integral[3]_i_67_n_0\,
      O => \integral[3]_i_71_n_0\
    );
\integral[3]_i_72\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_4\,
      I1 => \integral_reg[3]_i_113_n_4\,
      I2 => \integral_reg[3]_i_77_n_6\,
      I3 => \integral[3]_i_68_n_0\,
      O => \integral[3]_i_72_n_0\
    );
\integral[3]_i_73\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_5\,
      I1 => \integral_reg[3]_i_113_n_5\,
      I2 => \integral_reg[3]_i_77_n_7\,
      I3 => \integral[3]_i_69_n_0\,
      O => \integral[3]_i_73_n_0\
    );
\integral[3]_i_74\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_112_n_6\,
      I1 => \integral_reg[3]_i_113_n_6\,
      I2 => \integral_reg[3]_i_114_n_4\,
      I3 => \integral[3]_i_70_n_0\,
      O => \integral[3]_i_74_n_0\
    );
\integral[3]_i_78\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_5\,
      I1 => \integral_reg[3]_i_103_n_5\,
      I2 => error(3),
      O => \integral[3]_i_78_n_0\
    );
\integral[3]_i_79\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_6\,
      I1 => \integral_reg[3]_i_103_n_6\,
      I2 => error(2),
      O => \integral[3]_i_79_n_0\
    );
\integral[3]_i_8\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \integral_reg[3]_i_7_n_7\,
      O => \integral[3]_i_8_n_0\
    );
\integral[3]_i_80\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_7\,
      I1 => \integral_reg[3]_i_103_n_7\,
      I2 => error(1),
      O => \integral[3]_i_80_n_0\
    );
\integral[3]_i_81\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => error(1),
      I1 => \integral_reg[3]_i_102_n_7\,
      I2 => \integral_reg[3]_i_103_n_7\,
      O => \integral[3]_i_81_n_0\
    );
\integral[3]_i_82\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_4\,
      I1 => \integral_reg[3]_i_103_n_4\,
      I2 => error(4),
      I3 => \integral[3]_i_78_n_0\,
      O => \integral[3]_i_82_n_0\
    );
\integral[3]_i_83\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_5\,
      I1 => \integral_reg[3]_i_103_n_5\,
      I2 => error(3),
      I3 => \integral[3]_i_79_n_0\,
      O => \integral[3]_i_83_n_0\
    );
\integral[3]_i_84\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_6\,
      I1 => \integral_reg[3]_i_103_n_6\,
      I2 => error(2),
      I3 => \integral[3]_i_80_n_0\,
      O => \integral[3]_i_84_n_0\
    );
\integral[3]_i_85\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969696"
    )
        port map (
      I0 => \integral_reg[3]_i_102_n_7\,
      I1 => \integral_reg[3]_i_103_n_7\,
      I2 => error(1),
      I3 => \integral_reg[3]_i_115_n_4\,
      I4 => \integral_reg[3]_i_134_n_4\,
      O => \integral[3]_i_85_n_0\
    );
\integral[3]_i_86\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(10),
      I1 => error(5),
      I2 => error(8),
      O => \integral[3]_i_86_n_0\
    );
\integral[3]_i_87\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(9),
      I1 => error(4),
      I2 => error(7),
      O => \integral[3]_i_87_n_0\
    );
\integral[3]_i_88\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(8),
      I1 => error(3),
      I2 => error(6),
      O => \integral[3]_i_88_n_0\
    );
\integral[3]_i_89\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(7),
      I1 => error(2),
      I2 => error(5),
      O => \integral[3]_i_89_n_0\
    );
\integral[3]_i_90\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(8),
      I1 => error(5),
      I2 => error(10),
      I3 => error(11),
      I4 => error(6),
      I5 => error(9),
      O => \integral[3]_i_90_n_0\
    );
\integral[3]_i_91\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(7),
      I1 => error(4),
      I2 => error(9),
      I3 => error(10),
      I4 => error(5),
      I5 => error(8),
      O => \integral[3]_i_91_n_0\
    );
\integral[3]_i_92\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(6),
      I1 => error(3),
      I2 => error(8),
      I3 => error(9),
      I4 => error(4),
      I5 => error(7),
      O => \integral[3]_i_92_n_0\
    );
\integral[3]_i_93\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(5),
      I1 => error(2),
      I2 => error(7),
      I3 => error(8),
      I4 => error(3),
      I5 => error(6),
      O => \integral[3]_i_93_n_0\
    );
\integral[3]_i_94\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(10),
      I1 => error(8),
      I2 => error(12),
      O => \integral[3]_i_94_n_0\
    );
\integral[3]_i_95\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(9),
      I1 => error(7),
      I2 => error(11),
      O => \integral[3]_i_95_n_0\
    );
\integral[3]_i_96\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(8),
      I1 => error(6),
      I2 => error(10),
      O => \integral[3]_i_96_n_0\
    );
\integral[3]_i_97\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(7),
      I1 => error(5),
      I2 => error(9),
      O => \integral[3]_i_97_n_0\
    );
\integral[3]_i_98\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(12),
      I1 => error(8),
      I2 => error(10),
      I3 => error(9),
      I4 => error(11),
      I5 => error(13),
      O => \integral[3]_i_98_n_0\
    );
\integral[3]_i_99\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(11),
      I1 => error(7),
      I2 => error(9),
      I3 => error(8),
      I4 => error(10),
      I5 => error(12),
      O => \integral[3]_i_99_n_0\
    );
\integral[7]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_6\,
      I1 => \integral_reg[7]_i_17_n_6\,
      I2 => \integral_reg[7]_i_18_n_4\,
      O => \integral[7]_i_10_n_0\
    );
\integral[7]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_7\,
      I1 => \integral_reg[7]_i_17_n_7\,
      I2 => \integral_reg[7]_i_18_n_5\,
      O => \integral[7]_i_11_n_0\
    );
\integral[7]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[11]_i_16_n_7\,
      I1 => \integral_reg[11]_i_17_n_7\,
      I2 => \integral_reg[11]_i_18_n_5\,
      I3 => \integral[7]_i_8_n_0\,
      O => \integral[7]_i_12_n_0\
    );
\integral[7]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_4\,
      I1 => \integral_reg[7]_i_17_n_4\,
      I2 => \integral_reg[11]_i_18_n_6\,
      I3 => \integral[7]_i_9_n_0\,
      O => \integral[7]_i_13_n_0\
    );
\integral[7]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_5\,
      I1 => \integral_reg[7]_i_17_n_5\,
      I2 => \integral_reg[11]_i_18_n_7\,
      I3 => \integral[7]_i_10_n_0\,
      O => \integral[7]_i_14_n_0\
    );
\integral[7]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_6\,
      I1 => \integral_reg[7]_i_17_n_6\,
      I2 => \integral_reg[7]_i_18_n_4\,
      I3 => \integral[7]_i_11_n_0\,
      O => \integral[7]_i_15_n_0\
    );
\integral[7]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_43_n_5\,
      I1 => \integral_reg[11]_i_44_n_5\,
      I2 => error(11),
      O => \integral[7]_i_19_n_0\
    );
\integral[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(7),
      I1 => \integral_reg[7]_i_6_n_4\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[7]_i_7_n_4\,
      O => \integral[7]_i_2_n_0\
    );
\integral[7]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_43_n_6\,
      I1 => \integral_reg[11]_i_44_n_6\,
      I2 => error(10),
      O => \integral[7]_i_20_n_0\
    );
\integral[7]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[11]_i_43_n_7\,
      I1 => \integral_reg[11]_i_44_n_7\,
      I2 => error(9),
      O => \integral[7]_i_21_n_0\
    );
\integral[7]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_43_n_4\,
      I1 => \integral_reg[7]_i_44_n_4\,
      I2 => error(8),
      O => \integral[7]_i_22_n_0\
    );
\integral[7]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral[7]_i_19_n_0\,
      I1 => \integral_reg[11]_i_44_n_0\,
      I2 => \integral_reg[11]_i_43_n_4\,
      I3 => error(12),
      O => \integral[7]_i_23_n_0\
    );
\integral[7]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[11]_i_43_n_5\,
      I1 => \integral_reg[11]_i_44_n_5\,
      I2 => error(11),
      I3 => \integral[7]_i_20_n_0\,
      O => \integral[7]_i_24_n_0\
    );
\integral[7]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[11]_i_43_n_6\,
      I1 => \integral_reg[11]_i_44_n_6\,
      I2 => error(10),
      I3 => \integral[7]_i_21_n_0\,
      O => \integral[7]_i_25_n_0\
    );
\integral[7]_i_26\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral_reg[11]_i_43_n_7\,
      I1 => \integral_reg[11]_i_44_n_7\,
      I2 => error(9),
      I3 => \integral[7]_i_22_n_0\,
      O => \integral[7]_i_26_n_0\
    );
\integral[7]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(18),
      I1 => error(13),
      I2 => error(16),
      O => \integral[7]_i_27_n_0\
    );
\integral[7]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(17),
      I1 => error(12),
      I2 => error(15),
      O => \integral[7]_i_28_n_0\
    );
\integral[7]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(16),
      I1 => error(11),
      I2 => error(14),
      O => \integral[7]_i_29_n_0\
    );
\integral[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(6),
      I1 => \integral_reg[7]_i_6_n_5\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[7]_i_7_n_5\,
      O => \integral[7]_i_3_n_0\
    );
\integral[7]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(15),
      I1 => error(10),
      I2 => error(13),
      O => \integral[7]_i_30_n_0\
    );
\integral[7]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(16),
      I1 => error(13),
      I2 => error(18),
      I3 => error(19),
      I4 => error(14),
      I5 => error(17),
      O => \integral[7]_i_31_n_0\
    );
\integral[7]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(15),
      I1 => error(12),
      I2 => error(17),
      I3 => error(18),
      I4 => error(13),
      I5 => error(16),
      O => \integral[7]_i_32_n_0\
    );
\integral[7]_i_33\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(14),
      I1 => error(11),
      I2 => error(16),
      I3 => error(17),
      I4 => error(12),
      I5 => error(15),
      O => \integral[7]_i_33_n_0\
    );
\integral[7]_i_34\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(13),
      I1 => error(10),
      I2 => error(15),
      I3 => error(16),
      I4 => error(11),
      I5 => error(14),
      O => \integral[7]_i_34_n_0\
    );
\integral[7]_i_35\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(18),
      I1 => error(16),
      I2 => error(20),
      O => \integral[7]_i_35_n_0\
    );
\integral[7]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(17),
      I1 => error(15),
      I2 => error(19),
      O => \integral[7]_i_36_n_0\
    );
\integral[7]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(16),
      I1 => error(14),
      I2 => error(18),
      O => \integral[7]_i_37_n_0\
    );
\integral[7]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => error(15),
      I1 => error(13),
      I2 => error(17),
      O => \integral[7]_i_38_n_0\
    );
\integral[7]_i_39\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(20),
      I1 => error(16),
      I2 => error(18),
      I3 => error(17),
      I4 => error(19),
      I5 => error(21),
      O => \integral[7]_i_39_n_0\
    );
\integral[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(5),
      I1 => \integral_reg[7]_i_6_n_6\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[7]_i_7_n_6\,
      O => \integral[7]_i_4_n_0\
    );
\integral[7]_i_40\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(19),
      I1 => error(15),
      I2 => error(17),
      I3 => error(16),
      I4 => error(18),
      I5 => error(20),
      O => \integral[7]_i_40_n_0\
    );
\integral[7]_i_41\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(18),
      I1 => error(14),
      I2 => error(16),
      I3 => error(15),
      I4 => error(17),
      I5 => error(19),
      O => \integral[7]_i_41_n_0\
    );
\integral[7]_i_42\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8E71718E718E8E71"
    )
        port map (
      I0 => error(17),
      I1 => error(13),
      I2 => error(15),
      I3 => error(14),
      I4 => error(16),
      I5 => error(18),
      O => \integral[7]_i_42_n_0\
    );
\integral[7]_i_45\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(20),
      I1 => error(23),
      O => \integral[7]_i_45_n_0\
    );
\integral[7]_i_46\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(19),
      I1 => error(22),
      O => \integral[7]_i_46_n_0\
    );
\integral[7]_i_47\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(18),
      I1 => error(21),
      O => \integral[7]_i_47_n_0\
    );
\integral[7]_i_48\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => error(17),
      I1 => error(20),
      O => \integral[7]_i_48_n_0\
    );
\integral[7]_i_49\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(27),
      I1 => error(29),
      O => \integral[7]_i_49_n_0\
    );
\integral[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55556656AAAA66A6"
    )
        port map (
      I0 => integral_prev(4),
      I1 => \integral_reg[7]_i_6_n_7\,
      I2 => \integral_reg[27]_i_6_n_4\,
      I3 => error(31),
      I4 => \integral_reg[27]_i_7_n_2\,
      I5 => \integral_reg[7]_i_7_n_7\,
      O => \integral[7]_i_5_n_0\
    );
\integral[7]_i_50\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => error(26),
      I1 => error(28),
      O => \integral[7]_i_50_n_0\
    );
\integral[7]_i_51\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(25),
      I1 => error(27),
      I2 => error(31),
      O => \integral[7]_i_51_n_0\
    );
\integral[7]_i_52\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => error(24),
      I1 => error(26),
      I2 => error(30),
      O => \integral[7]_i_52_n_0\
    );
\integral[7]_i_53\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(29),
      I1 => error(27),
      I2 => error(28),
      I3 => error(30),
      O => \integral[7]_i_53_n_0\
    );
\integral[7]_i_54\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => error(28),
      I1 => error(26),
      I2 => error(27),
      I3 => error(29),
      O => \integral[7]_i_54_n_0\
    );
\integral[7]_i_55\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E81717E8"
    )
        port map (
      I0 => error(31),
      I1 => error(27),
      I2 => error(25),
      I3 => error(26),
      I4 => error(28),
      O => \integral[7]_i_55_n_0\
    );
\integral[7]_i_56\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \integral[7]_i_52_n_0\,
      I1 => error(27),
      I2 => error(25),
      I3 => error(31),
      O => \integral[7]_i_56_n_0\
    );
\integral[7]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_4\,
      I1 => \integral_reg[7]_i_17_n_4\,
      I2 => \integral_reg[11]_i_18_n_6\,
      O => \integral[7]_i_8_n_0\
    );
\integral[7]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \integral_reg[7]_i_16_n_5\,
      I1 => \integral_reg[7]_i_17_n_5\,
      I2 => \integral_reg[11]_i_18_n_7\,
      O => \integral[7]_i_9_n_0\
    );
\integral_prev_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(0),
      Q => integral_prev(0),
      R => '0'
    );
\integral_prev_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(10),
      Q => integral_prev(10),
      R => '0'
    );
\integral_prev_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(11),
      Q => integral_prev(11),
      R => '0'
    );
\integral_prev_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(12),
      Q => integral_prev(12),
      R => '0'
    );
\integral_prev_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(13),
      Q => integral_prev(13),
      R => '0'
    );
\integral_prev_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(14),
      Q => integral_prev(14),
      R => '0'
    );
\integral_prev_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(15),
      Q => integral_prev(15),
      R => '0'
    );
\integral_prev_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(16),
      Q => integral_prev(16),
      R => '0'
    );
\integral_prev_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(17),
      Q => integral_prev(17),
      R => '0'
    );
\integral_prev_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(18),
      Q => integral_prev(18),
      R => '0'
    );
\integral_prev_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(19),
      Q => integral_prev(19),
      R => '0'
    );
\integral_prev_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(1),
      Q => integral_prev(1),
      R => '0'
    );
\integral_prev_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(20),
      Q => integral_prev(20),
      R => '0'
    );
\integral_prev_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(21),
      Q => integral_prev(21),
      R => '0'
    );
\integral_prev_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(22),
      Q => integral_prev(22),
      R => '0'
    );
\integral_prev_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(23),
      Q => integral_prev(23),
      R => '0'
    );
\integral_prev_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(24),
      Q => integral_prev(24),
      R => '0'
    );
\integral_prev_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(25),
      Q => integral_prev(25),
      R => '0'
    );
\integral_prev_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(26),
      Q => integral_prev(26),
      R => '0'
    );
\integral_prev_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(27),
      Q => integral_prev(27),
      R => '0'
    );
\integral_prev_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(28),
      Q => integral_prev(28),
      R => '0'
    );
\integral_prev_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(29),
      Q => integral_prev(29),
      R => '0'
    );
\integral_prev_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(2),
      Q => integral_prev(2),
      R => '0'
    );
\integral_prev_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(30),
      Q => integral_prev(30),
      R => '0'
    );
\integral_prev_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(31),
      Q => integral_prev(31),
      R => '0'
    );
\integral_prev_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(3),
      Q => integral_prev(3),
      R => '0'
    );
\integral_prev_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(4),
      Q => integral_prev(4),
      R => '0'
    );
\integral_prev_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(5),
      Q => integral_prev(5),
      R => '0'
    );
\integral_prev_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(6),
      Q => integral_prev(6),
      R => '0'
    );
\integral_prev_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(7),
      Q => integral_prev(7),
      R => '0'
    );
\integral_prev_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(8),
      Q => integral_prev(8),
      R => '0'
    );
\integral_prev_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => integral(9),
      Q => integral_prev(9),
      R => '0'
    );
\integral_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[3]_i_1_n_7\,
      Q => integral(0),
      R => new_target_angle_available(0)
    );
\integral_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[11]_i_1_n_5\,
      Q => integral(10),
      R => new_target_angle_available(0)
    );
\integral_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[11]_i_1_n_4\,
      Q => integral(11),
      R => new_target_angle_available(0)
    );
\integral_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_1_n_0\,
      CO(3) => \integral_reg[11]_i_1_n_0\,
      CO(2) => \integral_reg[11]_i_1_n_1\,
      CO(1) => \integral_reg[11]_i_1_n_2\,
      CO(0) => \integral_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_prev(11 downto 8),
      O(3) => \integral_reg[11]_i_1_n_4\,
      O(2) => \integral_reg[11]_i_1_n_5\,
      O(1) => \integral_reg[11]_i_1_n_6\,
      O(0) => \integral_reg[11]_i_1_n_7\,
      S(3) => \integral[11]_i_2_n_0\,
      S(2) => \integral[11]_i_3_n_0\,
      S(1) => \integral[11]_i_4_n_0\,
      S(0) => \integral[11]_i_5_n_0\
    );
\integral_reg[11]_i_16\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_16_n_0\,
      CO(3) => \integral_reg[11]_i_16_n_0\,
      CO(2) => \integral_reg[11]_i_16_n_1\,
      CO(1) => \integral_reg[11]_i_16_n_2\,
      CO(0) => \integral_reg[11]_i_16_n_3\,
      CYINIT => '0',
      DI(3) => \integral[11]_i_19_n_0\,
      DI(2) => \integral[11]_i_20_n_0\,
      DI(1) => \integral[11]_i_21_n_0\,
      DI(0) => \integral[11]_i_22_n_0\,
      O(3) => \integral_reg[11]_i_16_n_4\,
      O(2) => \integral_reg[11]_i_16_n_5\,
      O(1) => \integral_reg[11]_i_16_n_6\,
      O(0) => \integral_reg[11]_i_16_n_7\,
      S(3) => \integral[11]_i_23_n_0\,
      S(2) => \integral[11]_i_24_n_0\,
      S(1) => \integral[11]_i_25_n_0\,
      S(0) => \integral[11]_i_26_n_0\
    );
\integral_reg[11]_i_17\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_17_n_0\,
      CO(3) => \integral_reg[11]_i_17_n_0\,
      CO(2) => \integral_reg[11]_i_17_n_1\,
      CO(1) => \integral_reg[11]_i_17_n_2\,
      CO(0) => \integral_reg[11]_i_17_n_3\,
      CYINIT => '0',
      DI(3) => \integral[11]_i_27_n_0\,
      DI(2) => \integral[11]_i_28_n_0\,
      DI(1) => \integral[11]_i_29_n_0\,
      DI(0) => \integral[11]_i_30_n_0\,
      O(3) => \integral_reg[11]_i_17_n_4\,
      O(2) => \integral_reg[11]_i_17_n_5\,
      O(1) => \integral_reg[11]_i_17_n_6\,
      O(0) => \integral_reg[11]_i_17_n_7\,
      S(3) => \integral[11]_i_31_n_0\,
      S(2) => \integral[11]_i_32_n_0\,
      S(1) => \integral[11]_i_33_n_0\,
      S(0) => \integral[11]_i_34_n_0\
    );
\integral_reg[11]_i_18\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_18_n_0\,
      CO(3) => \integral_reg[11]_i_18_n_0\,
      CO(2) => \integral_reg[11]_i_18_n_1\,
      CO(1) => \integral_reg[11]_i_18_n_2\,
      CO(0) => \integral_reg[11]_i_18_n_3\,
      CYINIT => '0',
      DI(3) => \integral[11]_i_35_n_0\,
      DI(2) => \integral[11]_i_36_n_0\,
      DI(1) => \integral[11]_i_37_n_0\,
      DI(0) => \integral[11]_i_38_n_0\,
      O(3) => \integral_reg[11]_i_18_n_4\,
      O(2) => \integral_reg[11]_i_18_n_5\,
      O(1) => \integral_reg[11]_i_18_n_6\,
      O(0) => \integral_reg[11]_i_18_n_7\,
      S(3) => \integral[11]_i_39_n_0\,
      S(2) => \integral[11]_i_40_n_0\,
      S(1) => \integral[11]_i_41_n_0\,
      S(0) => \integral[11]_i_42_n_0\
    );
\integral_reg[11]_i_43\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_43_n_0\,
      CO(3) => \integral_reg[11]_i_43_n_0\,
      CO(2) => \integral_reg[11]_i_43_n_1\,
      CO(1) => \integral_reg[11]_i_43_n_2\,
      CO(0) => \integral_reg[11]_i_43_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(24 downto 21),
      O(3) => \integral_reg[11]_i_43_n_4\,
      O(2) => \integral_reg[11]_i_43_n_5\,
      O(1) => \integral_reg[11]_i_43_n_6\,
      O(0) => \integral_reg[11]_i_43_n_7\,
      S(3) => \integral[11]_i_45_n_0\,
      S(2) => \integral[11]_i_46_n_0\,
      S(1) => \integral[11]_i_47_n_0\,
      S(0) => \integral[11]_i_48_n_0\
    );
\integral_reg[11]_i_44\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_44_n_0\,
      CO(3) => \integral_reg[11]_i_44_n_0\,
      CO(2) => \NLW_integral_reg[11]_i_44_CO_UNCONNECTED\(2),
      CO(1) => \integral_reg[11]_i_44_n_2\,
      CO(0) => \integral_reg[11]_i_44_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => error(30),
      DI(0) => \integral[11]_i_49_n_0\,
      O(3) => \NLW_integral_reg[11]_i_44_O_UNCONNECTED\(3),
      O(2) => \integral_reg[11]_i_44_n_5\,
      O(1) => \integral_reg[11]_i_44_n_6\,
      O(0) => \integral_reg[11]_i_44_n_7\,
      S(3) => '1',
      S(2) => error(31),
      S(1) => \integral[11]_i_50_n_0\,
      S(0) => \integral[11]_i_51_n_0\
    );
\integral_reg[11]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_6_n_0\,
      CO(3) => \integral_reg[11]_i_6_n_0\,
      CO(2) => \integral_reg[11]_i_6_n_1\,
      CO(1) => \integral_reg[11]_i_6_n_2\,
      CO(0) => \integral_reg[11]_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \integral_reg[11]_i_6_n_4\,
      O(2) => \integral_reg[11]_i_6_n_5\,
      O(1) => \integral_reg[11]_i_6_n_6\,
      O(0) => \integral_reg[11]_i_6_n_7\,
      S(3) => \integral_reg[11]_i_7_n_4\,
      S(2) => \integral_reg[11]_i_7_n_5\,
      S(1) => \integral_reg[11]_i_7_n_6\,
      S(0) => \integral_reg[11]_i_7_n_7\
    );
\integral_reg[11]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[7]_i_7_n_0\,
      CO(3) => \integral_reg[11]_i_7_n_0\,
      CO(2) => \integral_reg[11]_i_7_n_1\,
      CO(1) => \integral_reg[11]_i_7_n_2\,
      CO(0) => \integral_reg[11]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => \integral[11]_i_8_n_0\,
      DI(2) => \integral[11]_i_9_n_0\,
      DI(1) => \integral[11]_i_10_n_0\,
      DI(0) => \integral[11]_i_11_n_0\,
      O(3) => \integral_reg[11]_i_7_n_4\,
      O(2) => \integral_reg[11]_i_7_n_5\,
      O(1) => \integral_reg[11]_i_7_n_6\,
      O(0) => \integral_reg[11]_i_7_n_7\,
      S(3) => \integral[11]_i_12_n_0\,
      S(2) => \integral[11]_i_13_n_0\,
      S(1) => \integral[11]_i_14_n_0\,
      S(0) => \integral[11]_i_15_n_0\
    );
\integral_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[15]_i_1_n_7\,
      Q => integral(12),
      R => new_target_angle_available(0)
    );
\integral_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[15]_i_1_n_6\,
      Q => integral(13),
      R => new_target_angle_available(0)
    );
\integral_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[15]_i_1_n_5\,
      Q => integral(14),
      R => new_target_angle_available(0)
    );
\integral_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[15]_i_1_n_4\,
      Q => integral(15),
      R => new_target_angle_available(0)
    );
\integral_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[11]_i_1_n_0\,
      CO(3) => \integral_reg[15]_i_1_n_0\,
      CO(2) => \integral_reg[15]_i_1_n_1\,
      CO(1) => \integral_reg[15]_i_1_n_2\,
      CO(0) => \integral_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_prev(15 downto 12),
      O(3) => \integral_reg[15]_i_1_n_4\,
      O(2) => \integral_reg[15]_i_1_n_5\,
      O(1) => \integral_reg[15]_i_1_n_6\,
      O(0) => \integral_reg[15]_i_1_n_7\,
      S(3) => \integral[15]_i_2_n_0\,
      S(2) => \integral[15]_i_3_n_0\,
      S(1) => \integral[15]_i_4_n_0\,
      S(0) => \integral[15]_i_5_n_0\
    );
\integral_reg[15]_i_16\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[11]_i_16_n_0\,
      CO(3) => \integral_reg[15]_i_16_n_0\,
      CO(2) => \integral_reg[15]_i_16_n_1\,
      CO(1) => \integral_reg[15]_i_16_n_2\,
      CO(0) => \integral_reg[15]_i_16_n_3\,
      CYINIT => '0',
      DI(3) => \integral[15]_i_19_n_0\,
      DI(2) => \integral[15]_i_20_n_0\,
      DI(1) => \integral[15]_i_21_n_0\,
      DI(0) => \integral[15]_i_22_n_0\,
      O(3) => \integral_reg[15]_i_16_n_4\,
      O(2) => \integral_reg[15]_i_16_n_5\,
      O(1) => \integral_reg[15]_i_16_n_6\,
      O(0) => \integral_reg[15]_i_16_n_7\,
      S(3) => \integral[15]_i_23_n_0\,
      S(2) => \integral[15]_i_24_n_0\,
      S(1) => \integral[15]_i_25_n_0\,
      S(0) => \integral[15]_i_26_n_0\
    );
\integral_reg[15]_i_17\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[11]_i_17_n_0\,
      CO(3) => \integral_reg[15]_i_17_n_0\,
      CO(2) => \integral_reg[15]_i_17_n_1\,
      CO(1) => \integral_reg[15]_i_17_n_2\,
      CO(0) => \integral_reg[15]_i_17_n_3\,
      CYINIT => '0',
      DI(3) => \integral[15]_i_27_n_0\,
      DI(2) => \integral[15]_i_28_n_0\,
      DI(1) => \integral[15]_i_29_n_0\,
      DI(0) => \integral[15]_i_30_n_0\,
      O(3) => \integral_reg[15]_i_17_n_4\,
      O(2) => \integral_reg[15]_i_17_n_5\,
      O(1) => \integral_reg[15]_i_17_n_6\,
      O(0) => \integral_reg[15]_i_17_n_7\,
      S(3) => \integral[15]_i_31_n_0\,
      S(2) => \integral[15]_i_32_n_0\,
      S(1) => \integral[15]_i_33_n_0\,
      S(0) => \integral[15]_i_34_n_0\
    );
\integral_reg[15]_i_18\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[11]_i_18_n_0\,
      CO(3) => \integral_reg[15]_i_18_n_0\,
      CO(2) => \integral_reg[15]_i_18_n_1\,
      CO(1) => \integral_reg[15]_i_18_n_2\,
      CO(0) => \integral_reg[15]_i_18_n_3\,
      CYINIT => '0',
      DI(3) => \integral[15]_i_35_n_0\,
      DI(2) => \integral[15]_i_36_n_0\,
      DI(1) => \integral[15]_i_37_n_0\,
      DI(0) => \integral[15]_i_38_n_0\,
      O(3) => \integral_reg[15]_i_18_n_4\,
      O(2) => \integral_reg[15]_i_18_n_5\,
      O(1) => \integral_reg[15]_i_18_n_6\,
      O(0) => \integral_reg[15]_i_18_n_7\,
      S(3) => \integral[15]_i_39_n_0\,
      S(2) => \integral[15]_i_40_n_0\,
      S(1) => \integral[15]_i_41_n_0\,
      S(0) => \integral[15]_i_42_n_0\
    );
\integral_reg[15]_i_43\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[11]_i_43_n_0\,
      CO(3) => \integral_reg[15]_i_43_n_0\,
      CO(2) => \integral_reg[15]_i_43_n_1\,
      CO(1) => \integral_reg[15]_i_43_n_2\,
      CO(0) => \integral_reg[15]_i_43_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(28 downto 25),
      O(3) => \integral_reg[15]_i_43_n_4\,
      O(2) => \integral_reg[15]_i_43_n_5\,
      O(1) => \integral_reg[15]_i_43_n_6\,
      O(0) => \integral_reg[15]_i_43_n_7\,
      S(3) => \integral[15]_i_44_n_0\,
      S(2) => \integral[15]_i_45_n_0\,
      S(1) => \integral[15]_i_46_n_0\,
      S(0) => \integral[15]_i_47_n_0\
    );
\integral_reg[15]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[11]_i_6_n_0\,
      CO(3) => \integral_reg[15]_i_6_n_0\,
      CO(2) => \integral_reg[15]_i_6_n_1\,
      CO(1) => \integral_reg[15]_i_6_n_2\,
      CO(0) => \integral_reg[15]_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \integral_reg[15]_i_6_n_4\,
      O(2) => \integral_reg[15]_i_6_n_5\,
      O(1) => \integral_reg[15]_i_6_n_6\,
      O(0) => \integral_reg[15]_i_6_n_7\,
      S(3) => \integral_reg[15]_i_7_n_4\,
      S(2) => \integral_reg[15]_i_7_n_5\,
      S(1) => \integral_reg[15]_i_7_n_6\,
      S(0) => \integral_reg[15]_i_7_n_7\
    );
\integral_reg[15]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[11]_i_7_n_0\,
      CO(3) => \integral_reg[15]_i_7_n_0\,
      CO(2) => \integral_reg[15]_i_7_n_1\,
      CO(1) => \integral_reg[15]_i_7_n_2\,
      CO(0) => \integral_reg[15]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => \integral[15]_i_8_n_0\,
      DI(2) => \integral[15]_i_9_n_0\,
      DI(1) => \integral[15]_i_10_n_0\,
      DI(0) => \integral[15]_i_11_n_0\,
      O(3) => \integral_reg[15]_i_7_n_4\,
      O(2) => \integral_reg[15]_i_7_n_5\,
      O(1) => \integral_reg[15]_i_7_n_6\,
      O(0) => \integral_reg[15]_i_7_n_7\,
      S(3) => \integral[15]_i_12_n_0\,
      S(2) => \integral[15]_i_13_n_0\,
      S(1) => \integral[15]_i_14_n_0\,
      S(0) => \integral[15]_i_15_n_0\
    );
\integral_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[19]_i_1_n_7\,
      Q => integral(16),
      R => new_target_angle_available(0)
    );
\integral_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[19]_i_1_n_6\,
      Q => integral(17),
      R => new_target_angle_available(0)
    );
\integral_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[19]_i_1_n_5\,
      Q => integral(18),
      R => new_target_angle_available(0)
    );
\integral_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[19]_i_1_n_4\,
      Q => integral(19),
      R => new_target_angle_available(0)
    );
\integral_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[15]_i_1_n_0\,
      CO(3) => \integral_reg[19]_i_1_n_0\,
      CO(2) => \integral_reg[19]_i_1_n_1\,
      CO(1) => \integral_reg[19]_i_1_n_2\,
      CO(0) => \integral_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_prev(19 downto 16),
      O(3) => \integral_reg[19]_i_1_n_4\,
      O(2) => \integral_reg[19]_i_1_n_5\,
      O(1) => \integral_reg[19]_i_1_n_6\,
      O(0) => \integral_reg[19]_i_1_n_7\,
      S(3) => \integral[19]_i_2_n_0\,
      S(2) => \integral[19]_i_3_n_0\,
      S(1) => \integral[19]_i_4_n_0\,
      S(0) => \integral[19]_i_5_n_0\
    );
\integral_reg[19]_i_16\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[15]_i_16_n_0\,
      CO(3) => \integral_reg[19]_i_16_n_0\,
      CO(2) => \integral_reg[19]_i_16_n_1\,
      CO(1) => \integral_reg[19]_i_16_n_2\,
      CO(0) => \integral_reg[19]_i_16_n_3\,
      CYINIT => '0',
      DI(3) => \integral[19]_i_19_n_0\,
      DI(2) => \integral[19]_i_20_n_0\,
      DI(1) => \integral[19]_i_21_n_0\,
      DI(0) => \integral[19]_i_22_n_0\,
      O(3) => \integral_reg[19]_i_16_n_4\,
      O(2) => \integral_reg[19]_i_16_n_5\,
      O(1) => \integral_reg[19]_i_16_n_6\,
      O(0) => \integral_reg[19]_i_16_n_7\,
      S(3) => \integral[19]_i_23_n_0\,
      S(2) => \integral[19]_i_24_n_0\,
      S(1) => \integral[19]_i_25_n_0\,
      S(0) => \integral[19]_i_26_n_0\
    );
\integral_reg[19]_i_17\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[15]_i_17_n_0\,
      CO(3) => \integral_reg[19]_i_17_n_0\,
      CO(2) => \integral_reg[19]_i_17_n_1\,
      CO(1) => \integral_reg[19]_i_17_n_2\,
      CO(0) => \integral_reg[19]_i_17_n_3\,
      CYINIT => '0',
      DI(3) => \integral[19]_i_27_n_0\,
      DI(2) => \integral[19]_i_28_n_0\,
      DI(1) => \integral[19]_i_29_n_0\,
      DI(0) => \integral[19]_i_30_n_0\,
      O(3) => \integral_reg[19]_i_17_n_4\,
      O(2) => \integral_reg[19]_i_17_n_5\,
      O(1) => \integral_reg[19]_i_17_n_6\,
      O(0) => \integral_reg[19]_i_17_n_7\,
      S(3) => \integral[19]_i_31_n_0\,
      S(2) => \integral[19]_i_32_n_0\,
      S(1) => \integral[19]_i_33_n_0\,
      S(0) => \integral[19]_i_34_n_0\
    );
\integral_reg[19]_i_18\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[15]_i_18_n_0\,
      CO(3) => \integral_reg[19]_i_18_n_0\,
      CO(2) => \integral_reg[19]_i_18_n_1\,
      CO(1) => \integral_reg[19]_i_18_n_2\,
      CO(0) => \integral_reg[19]_i_18_n_3\,
      CYINIT => '0',
      DI(3) => \integral[19]_i_35_n_0\,
      DI(2) => \integral[19]_i_36_n_0\,
      DI(1) => \integral[19]_i_37_n_0\,
      DI(0) => \integral[19]_i_38_n_0\,
      O(3) => \integral_reg[19]_i_18_n_4\,
      O(2) => \integral_reg[19]_i_18_n_5\,
      O(1) => \integral_reg[19]_i_18_n_6\,
      O(0) => \integral_reg[19]_i_18_n_7\,
      S(3) => \integral[19]_i_39_n_0\,
      S(2) => \integral[19]_i_40_n_0\,
      S(1) => \integral[19]_i_41_n_0\,
      S(0) => \integral[19]_i_42_n_0\
    );
\integral_reg[19]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[15]_i_6_n_0\,
      CO(3) => \integral_reg[19]_i_6_n_0\,
      CO(2) => \integral_reg[19]_i_6_n_1\,
      CO(1) => \integral_reg[19]_i_6_n_2\,
      CO(0) => \integral_reg[19]_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \integral_reg[19]_i_6_n_4\,
      O(2) => \integral_reg[19]_i_6_n_5\,
      O(1) => \integral_reg[19]_i_6_n_6\,
      O(0) => \integral_reg[19]_i_6_n_7\,
      S(3) => \integral_reg[19]_i_7_n_4\,
      S(2) => \integral_reg[19]_i_7_n_5\,
      S(1) => \integral_reg[19]_i_7_n_6\,
      S(0) => \integral_reg[19]_i_7_n_7\
    );
\integral_reg[19]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[15]_i_7_n_0\,
      CO(3) => \integral_reg[19]_i_7_n_0\,
      CO(2) => \integral_reg[19]_i_7_n_1\,
      CO(1) => \integral_reg[19]_i_7_n_2\,
      CO(0) => \integral_reg[19]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => \integral[19]_i_8_n_0\,
      DI(2) => \integral[19]_i_9_n_0\,
      DI(1) => \integral[19]_i_10_n_0\,
      DI(0) => \integral[19]_i_11_n_0\,
      O(3) => \integral_reg[19]_i_7_n_4\,
      O(2) => \integral_reg[19]_i_7_n_5\,
      O(1) => \integral_reg[19]_i_7_n_6\,
      O(0) => \integral_reg[19]_i_7_n_7\,
      S(3) => \integral[19]_i_12_n_0\,
      S(2) => \integral[19]_i_13_n_0\,
      S(1) => \integral[19]_i_14_n_0\,
      S(0) => \integral[19]_i_15_n_0\
    );
\integral_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[3]_i_1_n_6\,
      Q => integral(1),
      R => new_target_angle_available(0)
    );
\integral_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[23]_i_1_n_7\,
      Q => integral(20),
      R => new_target_angle_available(0)
    );
\integral_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[23]_i_1_n_6\,
      Q => integral(21),
      R => new_target_angle_available(0)
    );
\integral_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[23]_i_1_n_5\,
      Q => integral(22),
      R => new_target_angle_available(0)
    );
\integral_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[23]_i_1_n_4\,
      Q => integral(23),
      R => new_target_angle_available(0)
    );
\integral_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[19]_i_1_n_0\,
      CO(3) => \integral_reg[23]_i_1_n_0\,
      CO(2) => \integral_reg[23]_i_1_n_1\,
      CO(1) => \integral_reg[23]_i_1_n_2\,
      CO(0) => \integral_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_prev(23 downto 20),
      O(3) => \integral_reg[23]_i_1_n_4\,
      O(2) => \integral_reg[23]_i_1_n_5\,
      O(1) => \integral_reg[23]_i_1_n_6\,
      O(0) => \integral_reg[23]_i_1_n_7\,
      S(3) => \integral[23]_i_2_n_0\,
      S(2) => \integral[23]_i_3_n_0\,
      S(1) => \integral[23]_i_4_n_0\,
      S(0) => \integral[23]_i_5_n_0\
    );
\integral_reg[23]_i_16\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[19]_i_16_n_0\,
      CO(3) => \integral_reg[23]_i_16_n_0\,
      CO(2) => \integral_reg[23]_i_16_n_1\,
      CO(1) => \integral_reg[23]_i_16_n_2\,
      CO(0) => \integral_reg[23]_i_16_n_3\,
      CYINIT => '0',
      DI(3) => \integral[23]_i_18_n_0\,
      DI(2) => \integral[23]_i_19_n_0\,
      DI(1) => \integral[23]_i_20_n_0\,
      DI(0) => \integral[23]_i_21_n_0\,
      O(3) => \integral_reg[23]_i_16_n_4\,
      O(2) => \integral_reg[23]_i_16_n_5\,
      O(1) => \integral_reg[23]_i_16_n_6\,
      O(0) => \integral_reg[23]_i_16_n_7\,
      S(3) => \integral[23]_i_22_n_0\,
      S(2) => \integral[23]_i_23_n_0\,
      S(1) => \integral[23]_i_24_n_0\,
      S(0) => \integral[23]_i_25_n_0\
    );
\integral_reg[23]_i_17\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[19]_i_17_n_0\,
      CO(3) => \integral_reg[23]_i_17_n_0\,
      CO(2) => \integral_reg[23]_i_17_n_1\,
      CO(1) => \integral_reg[23]_i_17_n_2\,
      CO(0) => \integral_reg[23]_i_17_n_3\,
      CYINIT => '0',
      DI(3) => error(29),
      DI(2) => \integral[23]_i_26_n_0\,
      DI(1) => \integral[23]_i_27_n_0\,
      DI(0) => \integral[23]_i_28_n_0\,
      O(3) => \integral_reg[23]_i_17_n_4\,
      O(2) => \integral_reg[23]_i_17_n_5\,
      O(1) => \integral_reg[23]_i_17_n_6\,
      O(0) => \integral_reg[23]_i_17_n_7\,
      S(3) => \integral[23]_i_29_n_0\,
      S(2) => \integral[23]_i_30_n_0\,
      S(1) => \integral[23]_i_31_n_0\,
      S(0) => \integral[23]_i_32_n_0\
    );
\integral_reg[23]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[19]_i_6_n_0\,
      CO(3) => \integral_reg[23]_i_6_n_0\,
      CO(2) => \integral_reg[23]_i_6_n_1\,
      CO(1) => \integral_reg[23]_i_6_n_2\,
      CO(0) => \integral_reg[23]_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \integral_reg[23]_i_6_n_4\,
      O(2) => \integral_reg[23]_i_6_n_5\,
      O(1) => \integral_reg[23]_i_6_n_6\,
      O(0) => \integral_reg[23]_i_6_n_7\,
      S(3) => \integral_reg[23]_i_7_n_4\,
      S(2) => \integral_reg[23]_i_7_n_5\,
      S(1) => \integral_reg[23]_i_7_n_6\,
      S(0) => \integral_reg[23]_i_7_n_7\
    );
\integral_reg[23]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[19]_i_7_n_0\,
      CO(3) => \integral_reg[23]_i_7_n_0\,
      CO(2) => \integral_reg[23]_i_7_n_1\,
      CO(1) => \integral_reg[23]_i_7_n_2\,
      CO(0) => \integral_reg[23]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => \integral[23]_i_8_n_0\,
      DI(2) => \integral[23]_i_9_n_0\,
      DI(1) => \integral[23]_i_10_n_0\,
      DI(0) => \integral[23]_i_11_n_0\,
      O(3) => \integral_reg[23]_i_7_n_4\,
      O(2) => \integral_reg[23]_i_7_n_5\,
      O(1) => \integral_reg[23]_i_7_n_6\,
      O(0) => \integral_reg[23]_i_7_n_7\,
      S(3) => \integral[23]_i_12_n_0\,
      S(2) => \integral[23]_i_13_n_0\,
      S(1) => \integral[23]_i_14_n_0\,
      S(0) => \integral[23]_i_15_n_0\
    );
\integral_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[27]_i_1_n_7\,
      Q => integral(24),
      R => new_target_angle_available(0)
    );
\integral_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[27]_i_1_n_6\,
      Q => integral(25),
      R => new_target_angle_available(0)
    );
\integral_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[27]_i_1_n_5\,
      Q => integral(26),
      R => new_target_angle_available(0)
    );
\integral_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[27]_i_1_n_4\,
      Q => integral(27),
      R => new_target_angle_available(0)
    );
\integral_reg[27]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[23]_i_1_n_0\,
      CO(3) => \integral_reg[27]_i_1_n_0\,
      CO(2) => \integral_reg[27]_i_1_n_1\,
      CO(1) => \integral_reg[27]_i_1_n_2\,
      CO(0) => \integral_reg[27]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => integral_prev(26 downto 24),
      O(3) => \integral_reg[27]_i_1_n_4\,
      O(2) => \integral_reg[27]_i_1_n_5\,
      O(1) => \integral_reg[27]_i_1_n_6\,
      O(0) => \integral_reg[27]_i_1_n_7\,
      S(3) => integral_prev(27),
      S(2) => \integral[27]_i_2_n_0\,
      S(1) => \integral[27]_i_3_n_0\,
      S(0) => \integral[27]_i_4_n_0\
    );
\integral_reg[27]_i_107\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_128_n_0\,
      CO(3) => \integral_reg[27]_i_107_n_0\,
      CO(2) => \integral_reg[27]_i_107_n_1\,
      CO(1) => \integral_reg[27]_i_107_n_2\,
      CO(0) => \integral_reg[27]_i_107_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_129_n_0\,
      DI(2) => \integral[27]_i_130_n_0\,
      DI(1) => \integral[27]_i_131_n_0\,
      DI(0) => \integral[27]_i_132_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_107_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[27]_i_133_n_0\,
      S(2) => \integral[27]_i_134_n_0\,
      S(1) => \integral[27]_i_135_n_0\,
      S(0) => \integral[27]_i_136_n_0\
    );
\integral_reg[27]_i_119\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[27]_i_119_n_0\,
      CO(2) => \integral_reg[27]_i_119_n_1\,
      CO(1) => \integral_reg[27]_i_119_n_2\,
      CO(0) => \integral_reg[27]_i_119_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_137_n_0\,
      DI(2) => \integral[27]_i_138_n_0\,
      DI(1) => \integral[27]_i_139_n_0\,
      DI(0) => '0',
      O(3) => \integral_reg[27]_i_119_n_4\,
      O(2) => \integral_reg[27]_i_119_n_5\,
      O(1) => \integral_reg[27]_i_119_n_6\,
      O(0) => \integral_reg[27]_i_119_n_7\,
      S(3) => \integral[27]_i_140_n_0\,
      S(2) => \integral[27]_i_141_n_0\,
      S(1) => \integral[27]_i_142_n_0\,
      S(0) => \integral[27]_i_143_n_0\
    );
\integral_reg[27]_i_128\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_144_n_0\,
      CO(3) => \integral_reg[27]_i_128_n_0\,
      CO(2) => \integral_reg[27]_i_128_n_1\,
      CO(1) => \integral_reg[27]_i_128_n_2\,
      CO(0) => \integral_reg[27]_i_128_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_145_n_0\,
      DI(2) => \integral[27]_i_146_n_0\,
      DI(1) => \integral[27]_i_147_n_0\,
      DI(0) => \integral[27]_i_148_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_128_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[27]_i_149_n_0\,
      S(2) => \integral[27]_i_150_n_0\,
      S(1) => \integral[27]_i_151_n_0\,
      S(0) => \integral[27]_i_152_n_0\
    );
\integral_reg[27]_i_144\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[27]_i_144_n_0\,
      CO(2) => \integral_reg[27]_i_144_n_1\,
      CO(1) => \integral_reg[27]_i_144_n_2\,
      CO(0) => \integral_reg[27]_i_144_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_153_n_0\,
      DI(2) => \integral[27]_i_154_n_0\,
      DI(1) => \integral[27]_i_155_n_0\,
      DI(0) => \integral[27]_i_156_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_144_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[27]_i_157_n_0\,
      S(2) => \integral[27]_i_158_n_0\,
      S(1) => \integral[27]_i_159_n_0\,
      S(0) => \integral[27]_i_160_n_0\
    );
\integral_reg[27]_i_17\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_36_n_0\,
      CO(3) => \integral_reg[27]_i_17_n_0\,
      CO(2) => \integral_reg[27]_i_17_n_1\,
      CO(1) => \integral_reg[27]_i_17_n_2\,
      CO(0) => \integral_reg[27]_i_17_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_37_n_0\,
      DI(2) => \integral[27]_i_38_n_0\,
      DI(1) => \integral[27]_i_39_n_0\,
      DI(0) => \integral[27]_i_40_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_17_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[27]_i_41_n_0\,
      S(2) => \integral[27]_i_42_n_0\,
      S(1) => \integral[27]_i_43_n_0\,
      S(0) => \integral[27]_i_44_n_0\
    );
\integral_reg[27]_i_27\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_48_n_0\,
      CO(3) => \integral_reg[27]_i_27_n_0\,
      CO(2) => \integral_reg[27]_i_27_n_1\,
      CO(1) => \integral_reg[27]_i_27_n_2\,
      CO(0) => \integral_reg[27]_i_27_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_49_n_0\,
      DI(2) => \integral[27]_i_50_n_0\,
      DI(1) => \integral[27]_i_51_n_0\,
      DI(0) => \integral[27]_i_52_n_0\,
      O(3) => \integral_reg[27]_i_27_n_4\,
      O(2) => \integral_reg[27]_i_27_n_5\,
      O(1) => \integral_reg[27]_i_27_n_6\,
      O(0) => \integral_reg[27]_i_27_n_7\,
      S(3) => \integral[27]_i_53_n_0\,
      S(2) => \integral[27]_i_54_n_0\,
      S(1) => \integral[27]_i_55_n_0\,
      S(0) => \integral[27]_i_56_n_0\
    );
\integral_reg[27]_i_36\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_57_n_0\,
      CO(3) => \integral_reg[27]_i_36_n_0\,
      CO(2) => \integral_reg[27]_i_36_n_1\,
      CO(1) => \integral_reg[27]_i_36_n_2\,
      CO(0) => \integral_reg[27]_i_36_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_58_n_0\,
      DI(2) => \integral[27]_i_59_n_0\,
      DI(1) => \integral[27]_i_60_n_0\,
      DI(0) => \integral[27]_i_61_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_36_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[27]_i_62_n_0\,
      S(2) => \integral[27]_i_63_n_0\,
      S(1) => \integral[27]_i_64_n_0\,
      S(0) => \integral[27]_i_65_n_0\
    );
\integral_reg[27]_i_45\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[23]_i_16_n_0\,
      CO(3) => \NLW_integral_reg[27]_i_45_CO_UNCONNECTED\(3),
      CO(2) => \integral_reg[27]_i_45_n_1\,
      CO(1) => \integral_reg[27]_i_45_n_2\,
      CO(0) => \integral_reg[27]_i_45_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \integral[27]_i_66_n_0\,
      DI(1) => \integral[27]_i_67_n_0\,
      DI(0) => \integral[27]_i_68_n_0\,
      O(3) => \integral_reg[27]_i_45_n_4\,
      O(2) => \integral_reg[27]_i_45_n_5\,
      O(1) => \integral_reg[27]_i_45_n_6\,
      O(0) => \integral_reg[27]_i_45_n_7\,
      S(3) => \integral[27]_i_69_n_0\,
      S(2) => \integral[27]_i_70_n_0\,
      S(1) => \integral[27]_i_71_n_0\,
      S(0) => \integral[27]_i_72_n_0\
    );
\integral_reg[27]_i_46\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[23]_i_17_n_0\,
      CO(3) => \NLW_integral_reg[27]_i_46_CO_UNCONNECTED\(3),
      CO(2) => \integral_reg[27]_i_46_n_1\,
      CO(1) => \NLW_integral_reg[27]_i_46_CO_UNCONNECTED\(1),
      CO(0) => \integral_reg[27]_i_46_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => error(31 downto 30),
      O(3 downto 2) => \NLW_integral_reg[27]_i_46_O_UNCONNECTED\(3 downto 2),
      O(1) => \integral_reg[27]_i_46_n_6\,
      O(0) => \integral_reg[27]_i_46_n_7\,
      S(3 downto 2) => B"01",
      S(1) => \integral[27]_i_73_n_0\,
      S(0) => \integral[27]_i_74_n_0\
    );
\integral_reg[27]_i_47\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[19]_i_18_n_0\,
      CO(3) => \integral_reg[27]_i_47_n_0\,
      CO(2) => \NLW_integral_reg[27]_i_47_CO_UNCONNECTED\(2),
      CO(1) => \integral_reg[27]_i_47_n_2\,
      CO(0) => \integral_reg[27]_i_47_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 1) => error(31 downto 30),
      DI(0) => \integral[27]_i_75_n_0\,
      O(3) => \NLW_integral_reg[27]_i_47_O_UNCONNECTED\(3),
      O(2) => \integral_reg[27]_i_47_n_5\,
      O(1) => \integral_reg[27]_i_47_n_6\,
      O(0) => \integral_reg[27]_i_47_n_7\,
      S(3) => '1',
      S(2) => \integral[27]_i_76_n_0\,
      S(1) => \integral[27]_i_77_n_0\,
      S(0) => \integral[27]_i_78_n_0\
    );
\integral_reg[27]_i_48\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_79_n_0\,
      CO(3) => \integral_reg[27]_i_48_n_0\,
      CO(2) => \integral_reg[27]_i_48_n_1\,
      CO(1) => \integral_reg[27]_i_48_n_2\,
      CO(0) => \integral_reg[27]_i_48_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_80_n_0\,
      DI(2) => \integral[27]_i_81_n_0\,
      DI(1) => \integral[27]_i_82_n_0\,
      DI(0) => \integral[27]_i_83_n_0\,
      O(3) => \integral_reg[27]_i_48_n_4\,
      O(2) => \integral_reg[27]_i_48_n_5\,
      O(1) => \integral_reg[27]_i_48_n_6\,
      O(0) => \integral_reg[27]_i_48_n_7\,
      S(3) => \integral[27]_i_84_n_0\,
      S(2) => \integral[27]_i_85_n_0\,
      S(1) => \integral[27]_i_86_n_0\,
      S(0) => \integral[27]_i_87_n_0\
    );
\integral_reg[27]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[23]_i_6_n_0\,
      CO(3 downto 2) => \NLW_integral_reg[27]_i_5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \integral_reg[27]_i_5_n_2\,
      CO(0) => \integral_reg[27]_i_5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_integral_reg[27]_i_5_O_UNCONNECTED\(3),
      O(2) => \integral_reg[27]_i_5_n_5\,
      O(1) => \integral_reg[27]_i_5_n_6\,
      O(0) => \integral_reg[27]_i_5_n_7\,
      S(3) => '0',
      S(2) => \integral_reg[27]_i_8_n_5\,
      S(1) => \integral_reg[27]_i_8_n_6\,
      S(0) => \integral_reg[27]_i_8_n_7\
    );
\integral_reg[27]_i_57\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_88_n_0\,
      CO(3) => \integral_reg[27]_i_57_n_0\,
      CO(2) => \integral_reg[27]_i_57_n_1\,
      CO(1) => \integral_reg[27]_i_57_n_2\,
      CO(0) => \integral_reg[27]_i_57_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_89_n_0\,
      DI(2) => \integral[27]_i_90_n_0\,
      DI(1) => \integral[27]_i_91_n_0\,
      DI(0) => \integral[27]_i_92_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_57_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[27]_i_93_n_0\,
      S(2) => \integral[27]_i_94_n_0\,
      S(1) => \integral[27]_i_95_n_0\,
      S(0) => \integral[27]_i_96_n_0\
    );
\integral_reg[27]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_9_n_0\,
      CO(3) => \NLW_integral_reg[27]_i_6_CO_UNCONNECTED\(3),
      CO(2) => \integral_reg[27]_i_6_n_1\,
      CO(1) => \integral_reg[27]_i_6_n_2\,
      CO(0) => \integral_reg[27]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \integral[27]_i_10_n_0\,
      DI(1) => \integral[27]_i_11_n_0\,
      DI(0) => \integral[27]_i_12_n_0\,
      O(3) => \integral_reg[27]_i_6_n_4\,
      O(2) => \integral_reg[27]_i_6_n_5\,
      O(1) => \integral_reg[27]_i_6_n_6\,
      O(0) => \integral_reg[27]_i_6_n_7\,
      S(3) => \integral[27]_i_13_n_0\,
      S(2) => \integral[27]_i_14_n_0\,
      S(1) => \integral[27]_i_15_n_0\,
      S(0) => \integral[27]_i_16_n_0\
    );
\integral_reg[27]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_17_n_0\,
      CO(3 downto 2) => \NLW_integral_reg[27]_i_7_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \integral_reg[27]_i_7_n_2\,
      CO(0) => \integral_reg[27]_i_7_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \integral[27]_i_18_n_0\,
      DI(0) => \integral[27]_i_19_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_7_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \integral[27]_i_20_n_0\,
      S(0) => \integral[27]_i_21_n_0\
    );
\integral_reg[27]_i_79\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_98_n_0\,
      CO(3) => \integral_reg[27]_i_79_n_0\,
      CO(2) => \integral_reg[27]_i_79_n_1\,
      CO(1) => \integral_reg[27]_i_79_n_2\,
      CO(0) => \integral_reg[27]_i_79_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_99_n_0\,
      DI(2) => \integral[27]_i_100_n_0\,
      DI(1) => \integral[27]_i_101_n_0\,
      DI(0) => \integral[27]_i_102_n_0\,
      O(3) => \integral_reg[27]_i_79_n_4\,
      O(2) => \integral_reg[27]_i_79_n_5\,
      O(1) => \integral_reg[27]_i_79_n_6\,
      O(0) => \integral_reg[27]_i_79_n_7\,
      S(3) => \integral[27]_i_103_n_0\,
      S(2) => \integral[27]_i_104_n_0\,
      S(1) => \integral[27]_i_105_n_0\,
      S(0) => \integral[27]_i_106_n_0\
    );
\integral_reg[27]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[23]_i_7_n_0\,
      CO(3 downto 2) => \NLW_integral_reg[27]_i_8_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \integral_reg[27]_i_8_n_2\,
      CO(0) => \integral_reg[27]_i_8_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \integral[27]_i_22_n_0\,
      DI(0) => \integral[27]_i_23_n_0\,
      O(3) => \NLW_integral_reg[27]_i_8_O_UNCONNECTED\(3),
      O(2) => \integral_reg[27]_i_8_n_5\,
      O(1) => \integral_reg[27]_i_8_n_6\,
      O(0) => \integral_reg[27]_i_8_n_7\,
      S(3) => '0',
      S(2) => \integral[27]_i_24_n_0\,
      S(1) => \integral[27]_i_25_n_0\,
      S(0) => \integral[27]_i_26_n_0\
    );
\integral_reg[27]_i_88\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_107_n_0\,
      CO(3) => \integral_reg[27]_i_88_n_0\,
      CO(2) => \integral_reg[27]_i_88_n_1\,
      CO(1) => \integral_reg[27]_i_88_n_2\,
      CO(0) => \integral_reg[27]_i_88_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_108_n_0\,
      DI(2) => \integral[27]_i_109_n_0\,
      DI(1) => \integral[27]_i_110_n_0\,
      DI(0) => \integral[27]_i_111_n_0\,
      O(3 downto 0) => \NLW_integral_reg[27]_i_88_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[27]_i_112_n_0\,
      S(2) => \integral[27]_i_113_n_0\,
      S(1) => \integral[27]_i_114_n_0\,
      S(0) => \integral[27]_i_115_n_0\
    );
\integral_reg[27]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_27_n_0\,
      CO(3) => \integral_reg[27]_i_9_n_0\,
      CO(2) => \integral_reg[27]_i_9_n_1\,
      CO(1) => \integral_reg[27]_i_9_n_2\,
      CO(0) => \integral_reg[27]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_28_n_0\,
      DI(2) => \integral[27]_i_29_n_0\,
      DI(1) => \integral[27]_i_30_n_0\,
      DI(0) => \integral[27]_i_31_n_0\,
      O(3) => \integral_reg[27]_i_9_n_4\,
      O(2) => \integral_reg[27]_i_9_n_5\,
      O(1) => \integral_reg[27]_i_9_n_6\,
      O(0) => \integral_reg[27]_i_9_n_7\,
      S(3) => \integral[27]_i_32_n_0\,
      S(2) => \integral[27]_i_33_n_0\,
      S(1) => \integral[27]_i_34_n_0\,
      S(0) => \integral[27]_i_35_n_0\
    );
\integral_reg[27]_i_97\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[15]_i_43_n_0\,
      CO(3) => \integral_reg[27]_i_97_n_0\,
      CO(2) => \NLW_integral_reg[27]_i_97_CO_UNCONNECTED\(2),
      CO(1) => \integral_reg[27]_i_97_n_2\,
      CO(0) => \integral_reg[27]_i_97_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => error(31 downto 29),
      O(3) => \NLW_integral_reg[27]_i_97_O_UNCONNECTED\(3),
      O(2) => \integral_reg[27]_i_97_n_5\,
      O(1) => \integral_reg[27]_i_97_n_6\,
      O(0) => \integral_reg[27]_i_97_n_7\,
      S(3) => '1',
      S(2) => \integral[27]_i_116_n_0\,
      S(1) => \integral[27]_i_117_n_0\,
      S(0) => \integral[27]_i_118_n_0\
    );
\integral_reg[27]_i_98\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_119_n_0\,
      CO(3) => \integral_reg[27]_i_98_n_0\,
      CO(2) => \integral_reg[27]_i_98_n_1\,
      CO(1) => \integral_reg[27]_i_98_n_2\,
      CO(0) => \integral_reg[27]_i_98_n_3\,
      CYINIT => '0',
      DI(3) => \integral[27]_i_120_n_0\,
      DI(2) => \integral[27]_i_121_n_0\,
      DI(1) => \integral[27]_i_122_n_0\,
      DI(0) => \integral[27]_i_123_n_0\,
      O(3) => \integral_reg[27]_i_98_n_4\,
      O(2) => \integral_reg[27]_i_98_n_5\,
      O(1) => \integral_reg[27]_i_98_n_6\,
      O(0) => \integral_reg[27]_i_98_n_7\,
      S(3) => \integral[27]_i_124_n_0\,
      S(2) => \integral[27]_i_125_n_0\,
      S(1) => \integral[27]_i_126_n_0\,
      S(0) => \integral[27]_i_127_n_0\
    );
\integral_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[31]_i_1_n_7\,
      Q => integral(28),
      R => new_target_angle_available(0)
    );
\integral_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[31]_i_1_n_6\,
      Q => integral(29),
      R => new_target_angle_available(0)
    );
\integral_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[3]_i_1_n_5\,
      Q => integral(2),
      R => new_target_angle_available(0)
    );
\integral_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[31]_i_1_n_5\,
      Q => integral(30),
      R => new_target_angle_available(0)
    );
\integral_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[31]_i_1_n_4\,
      Q => integral(31),
      R => new_target_angle_available(0)
    );
\integral_reg[31]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[27]_i_1_n_0\,
      CO(3) => \NLW_integral_reg[31]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \integral_reg[31]_i_1_n_1\,
      CO(1) => \integral_reg[31]_i_1_n_2\,
      CO(0) => \integral_reg[31]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \integral_reg[31]_i_1_n_4\,
      O(2) => \integral_reg[31]_i_1_n_5\,
      O(1) => \integral_reg[31]_i_1_n_6\,
      O(0) => \integral_reg[31]_i_1_n_7\,
      S(3 downto 0) => integral_prev(31 downto 28)
    );
\integral_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[3]_i_1_n_4\,
      Q => integral(3),
      R => new_target_angle_available(0)
    );
\integral_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_1_n_0\,
      CO(2) => \integral_reg[3]_i_1_n_1\,
      CO(1) => \integral_reg[3]_i_1_n_2\,
      CO(0) => \integral_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_prev(3 downto 0),
      O(3) => \integral_reg[3]_i_1_n_4\,
      O(2) => \integral_reg[3]_i_1_n_5\,
      O(1) => \integral_reg[3]_i_1_n_6\,
      O(0) => \integral_reg[3]_i_1_n_7\,
      S(3) => \integral[3]_i_2_n_0\,
      S(2) => \integral[3]_i_3_n_0\,
      S(1) => \integral[3]_i_4_n_0\,
      S(0) => \integral[3]_i_5_n_0\
    );
\integral_reg[3]_i_102\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_134_n_0\,
      CO(3) => \integral_reg[3]_i_102_n_0\,
      CO(2) => \integral_reg[3]_i_102_n_1\,
      CO(1) => \integral_reg[3]_i_102_n_2\,
      CO(0) => \integral_reg[3]_i_102_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(16 downto 13),
      O(3) => \integral_reg[3]_i_102_n_4\,
      O(2) => \integral_reg[3]_i_102_n_5\,
      O(1) => \integral_reg[3]_i_102_n_6\,
      O(0) => \integral_reg[3]_i_102_n_7\,
      S(3) => \integral[3]_i_135_n_0\,
      S(2) => \integral[3]_i_136_n_0\,
      S(1) => \integral[3]_i_137_n_0\,
      S(0) => \integral[3]_i_138_n_0\
    );
\integral_reg[3]_i_103\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_115_n_0\,
      CO(3) => \integral_reg[3]_i_103_n_0\,
      CO(2) => \integral_reg[3]_i_103_n_1\,
      CO(1) => \integral_reg[3]_i_103_n_2\,
      CO(0) => \integral_reg[3]_i_103_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_139_n_0\,
      DI(2) => \integral[3]_i_140_n_0\,
      DI(1) => \integral[3]_i_141_n_0\,
      DI(0) => \integral[3]_i_142_n_0\,
      O(3) => \integral_reg[3]_i_103_n_4\,
      O(2) => \integral_reg[3]_i_103_n_5\,
      O(1) => \integral_reg[3]_i_103_n_6\,
      O(0) => \integral_reg[3]_i_103_n_7\,
      S(3) => \integral[3]_i_143_n_0\,
      S(2) => \integral[3]_i_144_n_0\,
      S(1) => \integral[3]_i_145_n_0\,
      S(0) => \integral[3]_i_146_n_0\
    );
\integral_reg[3]_i_112\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_147_n_0\,
      CO(3) => \integral_reg[3]_i_112_n_0\,
      CO(2) => \integral_reg[3]_i_112_n_1\,
      CO(1) => \integral_reg[3]_i_112_n_2\,
      CO(0) => \integral_reg[3]_i_112_n_3\,
      CYINIT => '0',
      DI(3) => \integral_reg[3]_i_149_n_4\,
      DI(2) => \integral_reg[3]_i_149_n_5\,
      DI(1) => \integral_reg[3]_i_149_n_6\,
      DI(0) => \integral_reg[3]_i_149_n_7\,
      O(3) => \integral_reg[3]_i_112_n_4\,
      O(2) => \integral_reg[3]_i_112_n_5\,
      O(1) => \integral_reg[3]_i_112_n_6\,
      O(0) => \integral_reg[3]_i_112_n_7\,
      S(3) => \integral[3]_i_150_n_0\,
      S(2) => \integral[3]_i_151_n_0\,
      S(1) => \integral[3]_i_152_n_0\,
      S(0) => \integral[3]_i_153_n_0\
    );
\integral_reg[3]_i_113\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_113_n_0\,
      CO(2) => \integral_reg[3]_i_113_n_1\,
      CO(1) => \integral_reg[3]_i_113_n_2\,
      CO(0) => \integral_reg[3]_i_113_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => error(1 downto 0),
      DI(1 downto 0) => B"01",
      O(3) => \integral_reg[3]_i_113_n_4\,
      O(2) => \integral_reg[3]_i_113_n_5\,
      O(1) => \integral_reg[3]_i_113_n_6\,
      O(0) => \NLW_integral_reg[3]_i_113_O_UNCONNECTED\(0),
      S(3) => \integral[3]_i_154_n_0\,
      S(2) => \integral[3]_i_155_n_0\,
      S(1) => \integral[3]_i_156_n_0\,
      S(0) => error(0)
    );
\integral_reg[3]_i_114\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_114_n_0\,
      CO(2) => \integral_reg[3]_i_114_n_1\,
      CO(1) => \integral_reg[3]_i_114_n_2\,
      CO(0) => \integral_reg[3]_i_114_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_157_n_0\,
      DI(2) => \integral[3]_i_158_n_0\,
      DI(1) => \integral[3]_i_159_n_0\,
      DI(0) => '0',
      O(3) => \integral_reg[3]_i_114_n_4\,
      O(2) => \integral_reg[3]_i_114_n_5\,
      O(1) => \integral_reg[3]_i_114_n_6\,
      O(0) => \integral_reg[3]_i_114_n_7\,
      S(3) => \integral[3]_i_160_n_0\,
      S(2) => \integral[3]_i_161_n_0\,
      S(1) => \integral[3]_i_162_n_0\,
      S(0) => \integral[3]_i_163_n_0\
    );
\integral_reg[3]_i_115\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_149_n_0\,
      CO(3) => \integral_reg[3]_i_115_n_0\,
      CO(2) => \integral_reg[3]_i_115_n_1\,
      CO(1) => \integral_reg[3]_i_115_n_2\,
      CO(0) => \integral_reg[3]_i_115_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_164_n_0\,
      DI(2) => \integral[3]_i_165_n_0\,
      DI(1) => \integral[3]_i_166_n_0\,
      DI(0) => \integral[3]_i_167_n_0\,
      O(3) => \integral_reg[3]_i_115_n_4\,
      O(2) => \integral_reg[3]_i_115_n_5\,
      O(1) => \integral_reg[3]_i_115_n_6\,
      O(0) => \integral_reg[3]_i_115_n_7\,
      S(3) => \integral[3]_i_168_n_0\,
      S(2) => \integral[3]_i_169_n_0\,
      S(1) => \integral[3]_i_170_n_0\,
      S(0) => \integral[3]_i_171_n_0\
    );
\integral_reg[3]_i_134\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_172_n_0\,
      CO(3) => \integral_reg[3]_i_134_n_0\,
      CO(2) => \integral_reg[3]_i_134_n_1\,
      CO(1) => \integral_reg[3]_i_134_n_2\,
      CO(0) => \integral_reg[3]_i_134_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(12 downto 9),
      O(3) => \integral_reg[3]_i_134_n_4\,
      O(2) => \integral_reg[3]_i_134_n_5\,
      O(1) => \integral_reg[3]_i_134_n_6\,
      O(0) => \integral_reg[3]_i_134_n_7\,
      S(3) => \integral[3]_i_173_n_0\,
      S(2) => \integral[3]_i_174_n_0\,
      S(1) => \integral[3]_i_175_n_0\,
      S(0) => \integral[3]_i_176_n_0\
    );
\integral_reg[3]_i_147\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_177_n_0\,
      CO(3) => \integral_reg[3]_i_147_n_0\,
      CO(2) => \integral_reg[3]_i_147_n_1\,
      CO(1) => \integral_reg[3]_i_147_n_2\,
      CO(0) => \integral_reg[3]_i_147_n_3\,
      CYINIT => '0',
      DI(3) => \integral_reg[3]_i_178_n_4\,
      DI(2) => \integral_reg[3]_i_178_n_5\,
      DI(1) => \integral_reg[3]_i_178_n_6\,
      DI(0) => \integral_reg[3]_i_178_n_7\,
      O(3) => \integral_reg[3]_i_147_n_4\,
      O(2) => \integral_reg[3]_i_147_n_5\,
      O(1) => \integral_reg[3]_i_147_n_6\,
      O(0) => \integral_reg[3]_i_147_n_7\,
      S(3) => \integral[3]_i_179_n_0\,
      S(2) => \integral[3]_i_180_n_0\,
      S(1) => \integral[3]_i_181_n_0\,
      S(0) => \integral[3]_i_182_n_0\
    );
\integral_reg[3]_i_148\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_148_n_0\,
      CO(2) => \integral_reg[3]_i_148_n_1\,
      CO(1) => \integral_reg[3]_i_148_n_2\,
      CO(0) => \integral_reg[3]_i_148_n_3\,
      CYINIT => '0',
      DI(3) => error(0),
      DI(2 downto 0) => B"001",
      O(3) => \integral_reg[3]_i_148_n_4\,
      O(2) => \integral_reg[3]_i_148_n_5\,
      O(1) => \integral_reg[3]_i_148_n_6\,
      O(0) => \integral_reg[3]_i_148_n_7\,
      S(3) => \integral[3]_i_183_n_0\,
      S(2) => \integral[3]_i_184_n_0\,
      S(1) => \integral[3]_i_185_n_0\,
      S(0) => error(0)
    );
\integral_reg[3]_i_149\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_178_n_0\,
      CO(3) => \integral_reg[3]_i_149_n_0\,
      CO(2) => \integral_reg[3]_i_149_n_1\,
      CO(1) => \integral_reg[3]_i_149_n_2\,
      CO(0) => \integral_reg[3]_i_149_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_186_n_0\,
      DI(2) => \integral[3]_i_187_n_0\,
      DI(1) => \integral[3]_i_188_n_0\,
      DI(0) => \integral[3]_i_189_n_0\,
      O(3) => \integral_reg[3]_i_149_n_4\,
      O(2) => \integral_reg[3]_i_149_n_5\,
      O(1) => \integral_reg[3]_i_149_n_6\,
      O(0) => \integral_reg[3]_i_149_n_7\,
      S(3) => \integral[3]_i_190_n_0\,
      S(2) => \integral[3]_i_191_n_0\,
      S(1) => \integral[3]_i_192_n_0\,
      S(0) => \integral[3]_i_193_n_0\
    );
\integral_reg[3]_i_172\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_194_n_0\,
      CO(3) => \integral_reg[3]_i_172_n_0\,
      CO(2) => \integral_reg[3]_i_172_n_1\,
      CO(1) => \integral_reg[3]_i_172_n_2\,
      CO(0) => \integral_reg[3]_i_172_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(8 downto 5),
      O(3) => \integral_reg[3]_i_172_n_4\,
      O(2) => \integral_reg[3]_i_172_n_5\,
      O(1) => \integral_reg[3]_i_172_n_6\,
      O(0) => \integral_reg[3]_i_172_n_7\,
      S(3) => \integral[3]_i_195_n_0\,
      S(2) => \integral[3]_i_196_n_0\,
      S(1) => \integral[3]_i_197_n_0\,
      S(0) => \integral[3]_i_198_n_0\
    );
\integral_reg[3]_i_177\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_177_n_0\,
      CO(2) => \integral_reg[3]_i_177_n_1\,
      CO(1) => \integral_reg[3]_i_177_n_2\,
      CO(0) => \integral_reg[3]_i_177_n_3\,
      CYINIT => '0',
      DI(3) => \integral_reg[3]_i_199_n_4\,
      DI(2) => \integral_reg[3]_i_199_n_5\,
      DI(1) => \integral_reg[3]_i_199_n_6\,
      DI(0) => \integral_reg[3]_i_199_n_7\,
      O(3 downto 0) => \NLW_integral_reg[3]_i_177_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[3]_i_200_n_0\,
      S(2) => \integral[3]_i_201_n_0\,
      S(1) => \integral[3]_i_202_n_0\,
      S(0) => \integral[3]_i_203_n_0\
    );
\integral_reg[3]_i_178\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_199_n_0\,
      CO(3) => \integral_reg[3]_i_178_n_0\,
      CO(2) => \integral_reg[3]_i_178_n_1\,
      CO(1) => \integral_reg[3]_i_178_n_2\,
      CO(0) => \integral_reg[3]_i_178_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_204_n_0\,
      DI(2) => \integral[3]_i_205_n_0\,
      DI(1) => \integral[3]_i_206_n_0\,
      DI(0) => \integral[3]_i_207_n_0\,
      O(3) => \integral_reg[3]_i_178_n_4\,
      O(2) => \integral_reg[3]_i_178_n_5\,
      O(1) => \integral_reg[3]_i_178_n_6\,
      O(0) => \integral_reg[3]_i_178_n_7\,
      S(3) => \integral[3]_i_208_n_0\,
      S(2) => \integral[3]_i_209_n_0\,
      S(1) => \integral[3]_i_210_n_0\,
      S(0) => \integral[3]_i_211_n_0\
    );
\integral_reg[3]_i_18\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_30_n_0\,
      CO(3) => \integral_reg[3]_i_18_n_0\,
      CO(2) => \integral_reg[3]_i_18_n_1\,
      CO(1) => \integral_reg[3]_i_18_n_2\,
      CO(0) => \integral_reg[3]_i_18_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_31_n_0\,
      DI(2) => \integral[3]_i_32_n_0\,
      DI(1) => \integral[3]_i_33_n_0\,
      DI(0) => \integral[3]_i_34_n_0\,
      O(3 downto 0) => \NLW_integral_reg[3]_i_18_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[3]_i_35_n_0\,
      S(2) => \integral[3]_i_36_n_0\,
      S(1) => \integral[3]_i_37_n_0\,
      S(0) => \integral[3]_i_38_n_0\
    );
\integral_reg[3]_i_194\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_148_n_0\,
      CO(3) => \integral_reg[3]_i_194_n_0\,
      CO(2) => \integral_reg[3]_i_194_n_1\,
      CO(1) => \integral_reg[3]_i_194_n_2\,
      CO(0) => \integral_reg[3]_i_194_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(4 downto 1),
      O(3) => \integral_reg[3]_i_194_n_4\,
      O(2) => \integral_reg[3]_i_194_n_5\,
      O(1) => \integral_reg[3]_i_194_n_6\,
      O(0) => \integral_reg[3]_i_194_n_7\,
      S(3) => \integral[3]_i_212_n_0\,
      S(2) => \integral[3]_i_213_n_0\,
      S(1) => \integral[3]_i_214_n_0\,
      S(0) => \integral[3]_i_215_n_0\
    );
\integral_reg[3]_i_199\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_216_n_0\,
      CO(3) => \integral_reg[3]_i_199_n_0\,
      CO(2) => \integral_reg[3]_i_199_n_1\,
      CO(1) => \integral_reg[3]_i_199_n_2\,
      CO(0) => \integral_reg[3]_i_199_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_217_n_0\,
      DI(2) => \integral[3]_i_218_n_0\,
      DI(1) => \integral[3]_i_219_n_0\,
      DI(0) => \integral[3]_i_220_n_0\,
      O(3) => \integral_reg[3]_i_199_n_4\,
      O(2) => \integral_reg[3]_i_199_n_5\,
      O(1) => \integral_reg[3]_i_199_n_6\,
      O(0) => \integral_reg[3]_i_199_n_7\,
      S(3) => \integral[3]_i_221_n_0\,
      S(2) => \integral[3]_i_222_n_0\,
      S(1) => \integral[3]_i_223_n_0\,
      S(0) => \integral[3]_i_224_n_0\
    );
\integral_reg[3]_i_216\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_225_n_0\,
      CO(3) => \integral_reg[3]_i_216_n_0\,
      CO(2) => \integral_reg[3]_i_216_n_1\,
      CO(1) => \integral_reg[3]_i_216_n_2\,
      CO(0) => \integral_reg[3]_i_216_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_226_n_0\,
      DI(2) => \integral[3]_i_227_n_0\,
      DI(1) => \integral[3]_i_228_n_0\,
      DI(0) => \integral[3]_i_229_n_0\,
      O(3 downto 0) => \NLW_integral_reg[3]_i_216_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[3]_i_230_n_0\,
      S(2) => \integral[3]_i_231_n_0\,
      S(1) => \integral[3]_i_232_n_0\,
      S(0) => \integral[3]_i_233_n_0\
    );
\integral_reg[3]_i_225\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_225_n_0\,
      CO(2) => \integral_reg[3]_i_225_n_1\,
      CO(1) => \integral_reg[3]_i_225_n_2\,
      CO(0) => \integral_reg[3]_i_225_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => error(6 downto 4),
      DI(0) => '0',
      O(3 downto 0) => \NLW_integral_reg[3]_i_225_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[3]_i_234_n_0\,
      S(2) => \integral[3]_i_235_n_0\,
      S(1) => \integral[3]_i_236_n_0\,
      S(0) => error(3)
    );
\integral_reg[3]_i_27\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_39_n_0\,
      CO(3) => \integral_reg[3]_i_27_n_0\,
      CO(2) => \integral_reg[3]_i_27_n_1\,
      CO(1) => \integral_reg[3]_i_27_n_2\,
      CO(0) => \integral_reg[3]_i_27_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_42_n_0\,
      DI(2) => \integral[3]_i_43_n_0\,
      DI(1) => \integral[3]_i_44_n_0\,
      DI(0) => \integral[3]_i_45_n_0\,
      O(3) => \integral_reg[3]_i_27_n_4\,
      O(2) => \integral_reg[3]_i_27_n_5\,
      O(1) => \integral_reg[3]_i_27_n_6\,
      O(0) => \integral_reg[3]_i_27_n_7\,
      S(3) => \integral[3]_i_46_n_0\,
      S(2) => \integral[3]_i_47_n_0\,
      S(1) => \integral[3]_i_48_n_0\,
      S(0) => \integral[3]_i_49_n_0\
    );
\integral_reg[3]_i_28\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_40_n_0\,
      CO(3) => \integral_reg[3]_i_28_n_0\,
      CO(2) => \integral_reg[3]_i_28_n_1\,
      CO(1) => \integral_reg[3]_i_28_n_2\,
      CO(0) => \integral_reg[3]_i_28_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_50_n_0\,
      DI(2) => \integral[3]_i_51_n_0\,
      DI(1) => \integral[3]_i_52_n_0\,
      DI(0) => \integral[3]_i_53_n_0\,
      O(3) => \integral_reg[3]_i_28_n_4\,
      O(2) => \integral_reg[3]_i_28_n_5\,
      O(1) => \integral_reg[3]_i_28_n_6\,
      O(0) => \integral_reg[3]_i_28_n_7\,
      S(3) => \integral[3]_i_54_n_0\,
      S(2) => \integral[3]_i_55_n_0\,
      S(1) => \integral[3]_i_56_n_0\,
      S(0) => \integral[3]_i_57_n_0\
    );
\integral_reg[3]_i_29\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_41_n_0\,
      CO(3) => \integral_reg[3]_i_29_n_0\,
      CO(2) => \integral_reg[3]_i_29_n_1\,
      CO(1) => \integral_reg[3]_i_29_n_2\,
      CO(0) => \integral_reg[3]_i_29_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_58_n_0\,
      DI(2) => \integral[3]_i_59_n_0\,
      DI(1) => \integral[3]_i_60_n_0\,
      DI(0) => \integral[3]_i_61_n_0\,
      O(3) => \integral_reg[3]_i_29_n_4\,
      O(2) => \integral_reg[3]_i_29_n_5\,
      O(1) => \integral_reg[3]_i_29_n_6\,
      O(0) => \integral_reg[3]_i_29_n_7\,
      S(3) => \integral[3]_i_62_n_0\,
      S(2) => \integral[3]_i_63_n_0\,
      S(1) => \integral[3]_i_64_n_0\,
      S(0) => \integral[3]_i_65_n_0\
    );
\integral_reg[3]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_66_n_0\,
      CO(3) => \integral_reg[3]_i_30_n_0\,
      CO(2) => \integral_reg[3]_i_30_n_1\,
      CO(1) => \integral_reg[3]_i_30_n_2\,
      CO(0) => \integral_reg[3]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_67_n_0\,
      DI(2) => \integral[3]_i_68_n_0\,
      DI(1) => \integral[3]_i_69_n_0\,
      DI(0) => \integral[3]_i_70_n_0\,
      O(3 downto 0) => \NLW_integral_reg[3]_i_30_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[3]_i_71_n_0\,
      S(2) => \integral[3]_i_72_n_0\,
      S(1) => \integral[3]_i_73_n_0\,
      S(0) => \integral[3]_i_74_n_0\
    );
\integral_reg[3]_i_39\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_75_n_0\,
      CO(3) => \integral_reg[3]_i_39_n_0\,
      CO(2) => \integral_reg[3]_i_39_n_1\,
      CO(1) => \integral_reg[3]_i_39_n_2\,
      CO(0) => \integral_reg[3]_i_39_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_78_n_0\,
      DI(2) => \integral[3]_i_79_n_0\,
      DI(1) => \integral[3]_i_80_n_0\,
      DI(0) => \integral[3]_i_81_n_0\,
      O(3) => \integral_reg[3]_i_39_n_4\,
      O(2) => \integral_reg[3]_i_39_n_5\,
      O(1) => \integral_reg[3]_i_39_n_6\,
      O(0) => \integral_reg[3]_i_39_n_7\,
      S(3) => \integral[3]_i_82_n_0\,
      S(2) => \integral[3]_i_83_n_0\,
      S(1) => \integral[3]_i_84_n_0\,
      S(0) => \integral[3]_i_85_n_0\
    );
\integral_reg[3]_i_40\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_76_n_0\,
      CO(3) => \integral_reg[3]_i_40_n_0\,
      CO(2) => \integral_reg[3]_i_40_n_1\,
      CO(1) => \integral_reg[3]_i_40_n_2\,
      CO(0) => \integral_reg[3]_i_40_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_86_n_0\,
      DI(2) => \integral[3]_i_87_n_0\,
      DI(1) => \integral[3]_i_88_n_0\,
      DI(0) => \integral[3]_i_89_n_0\,
      O(3) => \integral_reg[3]_i_40_n_4\,
      O(2) => \integral_reg[3]_i_40_n_5\,
      O(1) => \integral_reg[3]_i_40_n_6\,
      O(0) => \integral_reg[3]_i_40_n_7\,
      S(3) => \integral[3]_i_90_n_0\,
      S(2) => \integral[3]_i_91_n_0\,
      S(1) => \integral[3]_i_92_n_0\,
      S(0) => \integral[3]_i_93_n_0\
    );
\integral_reg[3]_i_41\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_77_n_0\,
      CO(3) => \integral_reg[3]_i_41_n_0\,
      CO(2) => \integral_reg[3]_i_41_n_1\,
      CO(1) => \integral_reg[3]_i_41_n_2\,
      CO(0) => \integral_reg[3]_i_41_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_94_n_0\,
      DI(2) => \integral[3]_i_95_n_0\,
      DI(1) => \integral[3]_i_96_n_0\,
      DI(0) => \integral[3]_i_97_n_0\,
      O(3) => \integral_reg[3]_i_41_n_4\,
      O(2) => \integral_reg[3]_i_41_n_5\,
      O(1) => \integral_reg[3]_i_41_n_6\,
      O(0) => \integral_reg[3]_i_41_n_7\,
      S(3) => \integral[3]_i_98_n_0\,
      S(2) => \integral[3]_i_99_n_0\,
      S(1) => \integral[3]_i_100_n_0\,
      S(0) => \integral[3]_i_101_n_0\
    );
\integral_reg[3]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_6_n_0\,
      CO(2) => \integral_reg[3]_i_6_n_1\,
      CO(1) => \integral_reg[3]_i_6_n_2\,
      CO(0) => \integral_reg[3]_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \integral_reg[3]_i_6_n_4\,
      O(2) => \integral_reg[3]_i_6_n_5\,
      O(1) => \integral_reg[3]_i_6_n_6\,
      O(0) => \integral_reg[3]_i_6_n_7\,
      S(3) => \integral_reg[3]_i_7_n_4\,
      S(2) => \integral_reg[3]_i_7_n_5\,
      S(1) => \integral_reg[3]_i_7_n_6\,
      S(0) => \integral[3]_i_8_n_0\
    );
\integral_reg[3]_i_66\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \integral_reg[3]_i_66_n_0\,
      CO(2) => \integral_reg[3]_i_66_n_1\,
      CO(1) => \integral_reg[3]_i_66_n_2\,
      CO(0) => \integral_reg[3]_i_66_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_104_n_0\,
      DI(2) => \integral[3]_i_105_n_0\,
      DI(1) => \integral[3]_i_106_n_0\,
      DI(0) => \integral[3]_i_107_n_0\,
      O(3 downto 0) => \NLW_integral_reg[3]_i_66_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[3]_i_108_n_0\,
      S(2) => \integral[3]_i_109_n_0\,
      S(1) => \integral[3]_i_110_n_0\,
      S(0) => \integral[3]_i_111_n_0\
    );
\integral_reg[3]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_9_n_0\,
      CO(3) => \integral_reg[3]_i_7_n_0\,
      CO(2) => \integral_reg[3]_i_7_n_1\,
      CO(1) => \integral_reg[3]_i_7_n_2\,
      CO(0) => \integral_reg[3]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_10_n_0\,
      DI(2) => \integral[3]_i_11_n_0\,
      DI(1) => \integral[3]_i_12_n_0\,
      DI(0) => \integral[3]_i_13_n_0\,
      O(3) => \integral_reg[3]_i_7_n_4\,
      O(2) => \integral_reg[3]_i_7_n_5\,
      O(1) => \integral_reg[3]_i_7_n_6\,
      O(0) => \integral_reg[3]_i_7_n_7\,
      S(3) => \integral[3]_i_14_n_0\,
      S(2) => \integral[3]_i_15_n_0\,
      S(1) => \integral[3]_i_16_n_0\,
      S(0) => \integral[3]_i_17_n_0\
    );
\integral_reg[3]_i_75\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_112_n_0\,
      CO(3) => \integral_reg[3]_i_75_n_0\,
      CO(2) => \integral_reg[3]_i_75_n_1\,
      CO(1) => \integral_reg[3]_i_75_n_2\,
      CO(0) => \integral_reg[3]_i_75_n_3\,
      CYINIT => '0',
      DI(3) => error(0),
      DI(2) => \integral_reg[3]_i_115_n_5\,
      DI(1) => \integral_reg[3]_i_115_n_6\,
      DI(0) => \integral_reg[3]_i_115_n_7\,
      O(3) => \integral_reg[3]_i_75_n_4\,
      O(2) => \integral_reg[3]_i_75_n_5\,
      O(1) => \integral_reg[3]_i_75_n_6\,
      O(0) => \integral_reg[3]_i_75_n_7\,
      S(3) => \integral[3]_i_116_n_0\,
      S(2) => \integral[3]_i_117_n_0\,
      S(1) => \integral[3]_i_118_n_0\,
      S(0) => \integral[3]_i_119_n_0\
    );
\integral_reg[3]_i_76\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_113_n_0\,
      CO(3) => \integral_reg[3]_i_76_n_0\,
      CO(2) => \integral_reg[3]_i_76_n_1\,
      CO(1) => \integral_reg[3]_i_76_n_2\,
      CO(0) => \integral_reg[3]_i_76_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_120_n_0\,
      DI(2) => \integral[3]_i_121_n_0\,
      DI(1 downto 0) => error(3 downto 2),
      O(3) => \integral_reg[3]_i_76_n_4\,
      O(2) => \integral_reg[3]_i_76_n_5\,
      O(1) => \integral_reg[3]_i_76_n_6\,
      O(0) => \integral_reg[3]_i_76_n_7\,
      S(3) => \integral[3]_i_122_n_0\,
      S(2) => \integral[3]_i_123_n_0\,
      S(1) => \integral[3]_i_124_n_0\,
      S(0) => \integral[3]_i_125_n_0\
    );
\integral_reg[3]_i_77\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_114_n_0\,
      CO(3) => \integral_reg[3]_i_77_n_0\,
      CO(2) => \integral_reg[3]_i_77_n_1\,
      CO(1) => \integral_reg[3]_i_77_n_2\,
      CO(0) => \integral_reg[3]_i_77_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_126_n_0\,
      DI(2) => \integral[3]_i_127_n_0\,
      DI(1) => \integral[3]_i_128_n_0\,
      DI(0) => \integral[3]_i_129_n_0\,
      O(3) => \integral_reg[3]_i_77_n_4\,
      O(2) => \integral_reg[3]_i_77_n_5\,
      O(1) => \integral_reg[3]_i_77_n_6\,
      O(0) => \integral_reg[3]_i_77_n_7\,
      S(3) => \integral[3]_i_130_n_0\,
      S(2) => \integral[3]_i_131_n_0\,
      S(1) => \integral[3]_i_132_n_0\,
      S(0) => \integral[3]_i_133_n_0\
    );
\integral_reg[3]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_18_n_0\,
      CO(3) => \integral_reg[3]_i_9_n_0\,
      CO(2) => \integral_reg[3]_i_9_n_1\,
      CO(1) => \integral_reg[3]_i_9_n_2\,
      CO(0) => \integral_reg[3]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \integral[3]_i_19_n_0\,
      DI(2) => \integral[3]_i_20_n_0\,
      DI(1) => \integral[3]_i_21_n_0\,
      DI(0) => \integral[3]_i_22_n_0\,
      O(3 downto 0) => \NLW_integral_reg[3]_i_9_O_UNCONNECTED\(3 downto 0),
      S(3) => \integral[3]_i_23_n_0\,
      S(2) => \integral[3]_i_24_n_0\,
      S(1) => \integral[3]_i_25_n_0\,
      S(0) => \integral[3]_i_26_n_0\
    );
\integral_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[7]_i_1_n_7\,
      Q => integral(4),
      R => new_target_angle_available(0)
    );
\integral_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[7]_i_1_n_6\,
      Q => integral(5),
      R => new_target_angle_available(0)
    );
\integral_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[7]_i_1_n_5\,
      Q => integral(6),
      R => new_target_angle_available(0)
    );
\integral_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[7]_i_1_n_4\,
      Q => integral(7),
      R => new_target_angle_available(0)
    );
\integral_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_1_n_0\,
      CO(3) => \integral_reg[7]_i_1_n_0\,
      CO(2) => \integral_reg[7]_i_1_n_1\,
      CO(1) => \integral_reg[7]_i_1_n_2\,
      CO(0) => \integral_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_prev(7 downto 4),
      O(3) => \integral_reg[7]_i_1_n_4\,
      O(2) => \integral_reg[7]_i_1_n_5\,
      O(1) => \integral_reg[7]_i_1_n_6\,
      O(0) => \integral_reg[7]_i_1_n_7\,
      S(3) => \integral[7]_i_2_n_0\,
      S(2) => \integral[7]_i_3_n_0\,
      S(1) => \integral[7]_i_4_n_0\,
      S(0) => \integral[7]_i_5_n_0\
    );
\integral_reg[7]_i_16\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_27_n_0\,
      CO(3) => \integral_reg[7]_i_16_n_0\,
      CO(2) => \integral_reg[7]_i_16_n_1\,
      CO(1) => \integral_reg[7]_i_16_n_2\,
      CO(0) => \integral_reg[7]_i_16_n_3\,
      CYINIT => '0',
      DI(3) => \integral[7]_i_19_n_0\,
      DI(2) => \integral[7]_i_20_n_0\,
      DI(1) => \integral[7]_i_21_n_0\,
      DI(0) => \integral[7]_i_22_n_0\,
      O(3) => \integral_reg[7]_i_16_n_4\,
      O(2) => \integral_reg[7]_i_16_n_5\,
      O(1) => \integral_reg[7]_i_16_n_6\,
      O(0) => \integral_reg[7]_i_16_n_7\,
      S(3) => \integral[7]_i_23_n_0\,
      S(2) => \integral[7]_i_24_n_0\,
      S(1) => \integral[7]_i_25_n_0\,
      S(0) => \integral[7]_i_26_n_0\
    );
\integral_reg[7]_i_17\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_28_n_0\,
      CO(3) => \integral_reg[7]_i_17_n_0\,
      CO(2) => \integral_reg[7]_i_17_n_1\,
      CO(1) => \integral_reg[7]_i_17_n_2\,
      CO(0) => \integral_reg[7]_i_17_n_3\,
      CYINIT => '0',
      DI(3) => \integral[7]_i_27_n_0\,
      DI(2) => \integral[7]_i_28_n_0\,
      DI(1) => \integral[7]_i_29_n_0\,
      DI(0) => \integral[7]_i_30_n_0\,
      O(3) => \integral_reg[7]_i_17_n_4\,
      O(2) => \integral_reg[7]_i_17_n_5\,
      O(1) => \integral_reg[7]_i_17_n_6\,
      O(0) => \integral_reg[7]_i_17_n_7\,
      S(3) => \integral[7]_i_31_n_0\,
      S(2) => \integral[7]_i_32_n_0\,
      S(1) => \integral[7]_i_33_n_0\,
      S(0) => \integral[7]_i_34_n_0\
    );
\integral_reg[7]_i_18\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_29_n_0\,
      CO(3) => \integral_reg[7]_i_18_n_0\,
      CO(2) => \integral_reg[7]_i_18_n_1\,
      CO(1) => \integral_reg[7]_i_18_n_2\,
      CO(0) => \integral_reg[7]_i_18_n_3\,
      CYINIT => '0',
      DI(3) => \integral[7]_i_35_n_0\,
      DI(2) => \integral[7]_i_36_n_0\,
      DI(1) => \integral[7]_i_37_n_0\,
      DI(0) => \integral[7]_i_38_n_0\,
      O(3) => \integral_reg[7]_i_18_n_4\,
      O(2) => \integral_reg[7]_i_18_n_5\,
      O(1) => \integral_reg[7]_i_18_n_6\,
      O(0) => \integral_reg[7]_i_18_n_7\,
      S(3) => \integral[7]_i_39_n_0\,
      S(2) => \integral[7]_i_40_n_0\,
      S(1) => \integral[7]_i_41_n_0\,
      S(0) => \integral[7]_i_42_n_0\
    );
\integral_reg[7]_i_43\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_102_n_0\,
      CO(3) => \integral_reg[7]_i_43_n_0\,
      CO(2) => \integral_reg[7]_i_43_n_1\,
      CO(1) => \integral_reg[7]_i_43_n_2\,
      CO(0) => \integral_reg[7]_i_43_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => error(20 downto 17),
      O(3) => \integral_reg[7]_i_43_n_4\,
      O(2) => \integral_reg[7]_i_43_n_5\,
      O(1) => \integral_reg[7]_i_43_n_6\,
      O(0) => \integral_reg[7]_i_43_n_7\,
      S(3) => \integral[7]_i_45_n_0\,
      S(2) => \integral[7]_i_46_n_0\,
      S(1) => \integral[7]_i_47_n_0\,
      S(0) => \integral[7]_i_48_n_0\
    );
\integral_reg[7]_i_44\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_103_n_0\,
      CO(3) => \integral_reg[7]_i_44_n_0\,
      CO(2) => \integral_reg[7]_i_44_n_1\,
      CO(1) => \integral_reg[7]_i_44_n_2\,
      CO(0) => \integral_reg[7]_i_44_n_3\,
      CYINIT => '0',
      DI(3) => \integral[7]_i_49_n_0\,
      DI(2) => \integral[7]_i_50_n_0\,
      DI(1) => \integral[7]_i_51_n_0\,
      DI(0) => \integral[7]_i_52_n_0\,
      O(3) => \integral_reg[7]_i_44_n_4\,
      O(2) => \integral_reg[7]_i_44_n_5\,
      O(1) => \integral_reg[7]_i_44_n_6\,
      O(0) => \integral_reg[7]_i_44_n_7\,
      S(3) => \integral[7]_i_53_n_0\,
      S(2) => \integral[7]_i_54_n_0\,
      S(1) => \integral[7]_i_55_n_0\,
      S(0) => \integral[7]_i_56_n_0\
    );
\integral_reg[7]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_6_n_0\,
      CO(3) => \integral_reg[7]_i_6_n_0\,
      CO(2) => \integral_reg[7]_i_6_n_1\,
      CO(1) => \integral_reg[7]_i_6_n_2\,
      CO(0) => \integral_reg[7]_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \integral_reg[7]_i_6_n_4\,
      O(2) => \integral_reg[7]_i_6_n_5\,
      O(1) => \integral_reg[7]_i_6_n_6\,
      O(0) => \integral_reg[7]_i_6_n_7\,
      S(3) => \integral_reg[7]_i_7_n_4\,
      S(2) => \integral_reg[7]_i_7_n_5\,
      S(1) => \integral_reg[7]_i_7_n_6\,
      S(0) => \integral_reg[7]_i_7_n_7\
    );
\integral_reg[7]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral_reg[3]_i_7_n_0\,
      CO(3) => \integral_reg[7]_i_7_n_0\,
      CO(2) => \integral_reg[7]_i_7_n_1\,
      CO(1) => \integral_reg[7]_i_7_n_2\,
      CO(0) => \integral_reg[7]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => \integral[7]_i_8_n_0\,
      DI(2) => \integral[7]_i_9_n_0\,
      DI(1) => \integral[7]_i_10_n_0\,
      DI(0) => \integral[7]_i_11_n_0\,
      O(3) => \integral_reg[7]_i_7_n_4\,
      O(2) => \integral_reg[7]_i_7_n_5\,
      O(1) => \integral_reg[7]_i_7_n_6\,
      O(0) => \integral_reg[7]_i_7_n_7\,
      S(3) => \integral[7]_i_12_n_0\,
      S(2) => \integral[7]_i_13_n_0\,
      S(1) => \integral[7]_i_14_n_0\,
      S(0) => \integral[7]_i_15_n_0\
    );
\integral_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[11]_i_1_n_7\,
      Q => integral(8),
      R => new_target_angle_available(0)
    );
\integral_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \integral_reg[11]_i_1_n_6\,
      Q => integral(9),
      R => new_target_angle_available(0)
    );
\interim_velocity[11]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(10),
      I1 => \^d_term_reg\(10),
      I2 => \^p_term_reg\(10),
      O => \interim_velocity[11]_i_2_n_0\
    );
\interim_velocity[11]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(9),
      I1 => \^d_term_reg\(9),
      I2 => \^p_term_reg\(9),
      O => \interim_velocity[11]_i_3_n_0\
    );
\interim_velocity[11]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(8),
      I1 => \^d_term_reg\(8),
      I2 => \^p_term_reg\(8),
      O => \interim_velocity[11]_i_4_n_0\
    );
\interim_velocity[11]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(7),
      I1 => \^d_term_reg\(7),
      I2 => \^p_term_reg\(7),
      O => \interim_velocity[11]_i_5_n_0\
    );
\interim_velocity[11]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(11),
      I1 => \^d_term_reg\(11),
      I2 => \^p_term_reg\(11),
      I3 => \interim_velocity[11]_i_2_n_0\,
      O => \interim_velocity[11]_i_6_n_0\
    );
\interim_velocity[11]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(10),
      I1 => \^d_term_reg\(10),
      I2 => \^p_term_reg\(10),
      I3 => \interim_velocity[11]_i_3_n_0\,
      O => \interim_velocity[11]_i_7_n_0\
    );
\interim_velocity[11]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(9),
      I1 => \^d_term_reg\(9),
      I2 => \^p_term_reg\(9),
      I3 => \interim_velocity[11]_i_4_n_0\,
      O => \interim_velocity[11]_i_8_n_0\
    );
\interim_velocity[11]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(8),
      I1 => \^d_term_reg\(8),
      I2 => \^p_term_reg\(8),
      I3 => \interim_velocity[11]_i_5_n_0\,
      O => \interim_velocity[11]_i_9_n_0\
    );
\interim_velocity[15]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(14),
      I1 => \^d_term_reg\(14),
      I2 => \^p_term_reg\(14),
      O => \interim_velocity[15]_i_2_n_0\
    );
\interim_velocity[15]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(13),
      I1 => \^d_term_reg\(13),
      I2 => \^p_term_reg\(13),
      O => \interim_velocity[15]_i_3_n_0\
    );
\interim_velocity[15]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(12),
      I1 => \^d_term_reg\(12),
      I2 => \^p_term_reg\(12),
      O => \interim_velocity[15]_i_4_n_0\
    );
\interim_velocity[15]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(11),
      I1 => \^d_term_reg\(11),
      I2 => \^p_term_reg\(11),
      O => \interim_velocity[15]_i_5_n_0\
    );
\interim_velocity[15]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(15),
      I1 => \^d_term_reg\(15),
      I2 => \^p_term_reg\(15),
      I3 => \interim_velocity[15]_i_2_n_0\,
      O => \interim_velocity[15]_i_6_n_0\
    );
\interim_velocity[15]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(14),
      I1 => \^d_term_reg\(14),
      I2 => \^p_term_reg\(14),
      I3 => \interim_velocity[15]_i_3_n_0\,
      O => \interim_velocity[15]_i_7_n_0\
    );
\interim_velocity[15]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(13),
      I1 => \^d_term_reg\(13),
      I2 => \^p_term_reg\(13),
      I3 => \interim_velocity[15]_i_4_n_0\,
      O => \interim_velocity[15]_i_8_n_0\
    );
\interim_velocity[15]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(12),
      I1 => \^d_term_reg\(12),
      I2 => \^p_term_reg\(12),
      I3 => \interim_velocity[15]_i_5_n_0\,
      O => \interim_velocity[15]_i_9_n_0\
    );
\interim_velocity[19]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(18),
      I1 => \^d_term_reg\(18),
      I2 => \^p_term_reg\(18),
      O => \interim_velocity[19]_i_2_n_0\
    );
\interim_velocity[19]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(17),
      I1 => \^d_term_reg\(17),
      I2 => \^p_term_reg\(17),
      O => \interim_velocity[19]_i_3_n_0\
    );
\interim_velocity[19]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(16),
      I1 => \^d_term_reg\(16),
      I2 => \^p_term_reg\(16),
      O => \interim_velocity[19]_i_4_n_0\
    );
\interim_velocity[19]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(15),
      I1 => \^d_term_reg\(15),
      I2 => \^p_term_reg\(15),
      O => \interim_velocity[19]_i_5_n_0\
    );
\interim_velocity[19]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(19),
      I1 => \^d_term_reg\(19),
      I2 => \^p_term_reg\(19),
      I3 => \interim_velocity[19]_i_2_n_0\,
      O => \interim_velocity[19]_i_6_n_0\
    );
\interim_velocity[19]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(18),
      I1 => \^d_term_reg\(18),
      I2 => \^p_term_reg\(18),
      I3 => \interim_velocity[19]_i_3_n_0\,
      O => \interim_velocity[19]_i_7_n_0\
    );
\interim_velocity[19]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(17),
      I1 => \^d_term_reg\(17),
      I2 => \^p_term_reg\(17),
      I3 => \interim_velocity[19]_i_4_n_0\,
      O => \interim_velocity[19]_i_8_n_0\
    );
\interim_velocity[19]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(16),
      I1 => \^d_term_reg\(16),
      I2 => \^p_term_reg\(16),
      I3 => \interim_velocity[19]_i_5_n_0\,
      O => \interim_velocity[19]_i_9_n_0\
    );
\interim_velocity[23]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(22),
      I1 => \^d_term_reg\(22),
      I2 => \^p_term_reg\(22),
      O => \interim_velocity[23]_i_2_n_0\
    );
\interim_velocity[23]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(21),
      I1 => \^d_term_reg\(21),
      I2 => \^p_term_reg\(21),
      O => \interim_velocity[23]_i_3_n_0\
    );
\interim_velocity[23]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(20),
      I1 => \^d_term_reg\(20),
      I2 => \^p_term_reg\(20),
      O => \interim_velocity[23]_i_4_n_0\
    );
\interim_velocity[23]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(19),
      I1 => \^d_term_reg\(19),
      I2 => \^p_term_reg\(19),
      O => \interim_velocity[23]_i_5_n_0\
    );
\interim_velocity[23]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(23),
      I1 => \^d_term_reg\(23),
      I2 => \^p_term_reg\(23),
      I3 => \interim_velocity[23]_i_2_n_0\,
      O => \interim_velocity[23]_i_6_n_0\
    );
\interim_velocity[23]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(22),
      I1 => \^d_term_reg\(22),
      I2 => \^p_term_reg\(22),
      I3 => \interim_velocity[23]_i_3_n_0\,
      O => \interim_velocity[23]_i_7_n_0\
    );
\interim_velocity[23]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(21),
      I1 => \^d_term_reg\(21),
      I2 => \^p_term_reg\(21),
      I3 => \interim_velocity[23]_i_4_n_0\,
      O => \interim_velocity[23]_i_8_n_0\
    );
\interim_velocity[23]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(20),
      I1 => \^d_term_reg\(20),
      I2 => \^p_term_reg\(20),
      I3 => \interim_velocity[23]_i_5_n_0\,
      O => \interim_velocity[23]_i_9_n_0\
    );
\interim_velocity[27]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(26),
      I1 => \^d_term_reg\(26),
      I2 => \^p_term_reg\(26),
      O => \interim_velocity[27]_i_2_n_0\
    );
\interim_velocity[27]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(25),
      I1 => \^d_term_reg\(25),
      I2 => \^p_term_reg\(25),
      O => \interim_velocity[27]_i_3_n_0\
    );
\interim_velocity[27]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(24),
      I1 => \^d_term_reg\(24),
      I2 => \^p_term_reg\(24),
      O => \interim_velocity[27]_i_4_n_0\
    );
\interim_velocity[27]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(23),
      I1 => \^d_term_reg\(23),
      I2 => \^p_term_reg\(23),
      O => \interim_velocity[27]_i_5_n_0\
    );
\interim_velocity[27]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(27),
      I1 => \^d_term_reg\(27),
      I2 => \^p_term_reg\(27),
      I3 => \interim_velocity[27]_i_2_n_0\,
      O => \interim_velocity[27]_i_6_n_0\
    );
\interim_velocity[27]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(26),
      I1 => \^d_term_reg\(26),
      I2 => \^p_term_reg\(26),
      I3 => \interim_velocity[27]_i_3_n_0\,
      O => \interim_velocity[27]_i_7_n_0\
    );
\interim_velocity[27]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(25),
      I1 => \^d_term_reg\(25),
      I2 => \^p_term_reg\(25),
      I3 => \interim_velocity[27]_i_4_n_0\,
      O => \interim_velocity[27]_i_8_n_0\
    );
\interim_velocity[27]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(24),
      I1 => \^d_term_reg\(24),
      I2 => \^p_term_reg\(24),
      I3 => \interim_velocity[27]_i_5_n_0\,
      O => \interim_velocity[27]_i_9_n_0\
    );
\interim_velocity[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(30),
      I1 => \^d_term_reg\(30),
      I2 => \^p_term_reg\(30),
      O => \interim_velocity[31]_i_2_n_0\
    );
\interim_velocity[31]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(29),
      I1 => \^d_term_reg\(29),
      I2 => \^p_term_reg\(29),
      O => \interim_velocity[31]_i_3_n_0\
    );
\interim_velocity[31]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(28),
      I1 => \^d_term_reg\(28),
      I2 => \^p_term_reg\(28),
      O => \interim_velocity[31]_i_4_n_0\
    );
\interim_velocity[31]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(27),
      I1 => \^d_term_reg\(27),
      I2 => \^p_term_reg\(27),
      O => \interim_velocity[31]_i_5_n_0\
    );
\interim_velocity[31]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(31),
      I1 => \^d_term_reg\(31),
      I2 => \^p_term_reg\(31),
      I3 => \interim_velocity[31]_i_2_n_0\,
      O => \interim_velocity[31]_i_6_n_0\
    );
\interim_velocity[31]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(30),
      I1 => \^d_term_reg\(30),
      I2 => \^p_term_reg\(30),
      I3 => \interim_velocity[31]_i_3_n_0\,
      O => \interim_velocity[31]_i_7_n_0\
    );
\interim_velocity[31]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(29),
      I1 => \^d_term_reg\(29),
      I2 => \^p_term_reg\(29),
      I3 => \interim_velocity[31]_i_4_n_0\,
      O => \interim_velocity[31]_i_8_n_0\
    );
\interim_velocity[31]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(28),
      I1 => \^d_term_reg\(28),
      I2 => \^p_term_reg\(28),
      I3 => \interim_velocity[31]_i_5_n_0\,
      O => \interim_velocity[31]_i_9_n_0\
    );
\interim_velocity[35]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(34),
      I1 => \^d_term_reg\(34),
      I2 => \^p_term_reg\(34),
      O => \interim_velocity[35]_i_2_n_0\
    );
\interim_velocity[35]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(33),
      I1 => \^d_term_reg\(33),
      I2 => \^p_term_reg\(33),
      O => \interim_velocity[35]_i_3_n_0\
    );
\interim_velocity[35]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(32),
      I1 => \^d_term_reg\(32),
      I2 => \^p_term_reg\(32),
      O => \interim_velocity[35]_i_4_n_0\
    );
\interim_velocity[35]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(31),
      I1 => \^d_term_reg\(31),
      I2 => \^p_term_reg\(31),
      O => \interim_velocity[35]_i_5_n_0\
    );
\interim_velocity[35]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(35),
      I1 => \^d_term_reg\(35),
      I2 => \^p_term_reg\(35),
      I3 => \interim_velocity[35]_i_2_n_0\,
      O => \interim_velocity[35]_i_6_n_0\
    );
\interim_velocity[35]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(34),
      I1 => \^d_term_reg\(34),
      I2 => \^p_term_reg\(34),
      I3 => \interim_velocity[35]_i_3_n_0\,
      O => \interim_velocity[35]_i_7_n_0\
    );
\interim_velocity[35]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(33),
      I1 => \^d_term_reg\(33),
      I2 => \^p_term_reg\(33),
      I3 => \interim_velocity[35]_i_4_n_0\,
      O => \interim_velocity[35]_i_8_n_0\
    );
\interim_velocity[35]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(32),
      I1 => \^d_term_reg\(32),
      I2 => \^p_term_reg\(32),
      I3 => \interim_velocity[35]_i_5_n_0\,
      O => \interim_velocity[35]_i_9_n_0\
    );
\interim_velocity[39]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(38),
      I1 => \^d_term_reg\(38),
      I2 => \^p_term_reg\(38),
      O => \interim_velocity[39]_i_2_n_0\
    );
\interim_velocity[39]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(37),
      I1 => \^d_term_reg\(37),
      I2 => \^p_term_reg\(37),
      O => \interim_velocity[39]_i_3_n_0\
    );
\interim_velocity[39]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(36),
      I1 => \^d_term_reg\(36),
      I2 => \^p_term_reg\(36),
      O => \interim_velocity[39]_i_4_n_0\
    );
\interim_velocity[39]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(35),
      I1 => \^d_term_reg\(35),
      I2 => \^p_term_reg\(35),
      O => \interim_velocity[39]_i_5_n_0\
    );
\interim_velocity[39]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \interim_velocity[39]_i_2_n_0\,
      I1 => \^d_term_reg\(39),
      I2 => \^i_term_reg\(39),
      I3 => \^p_term_reg\(39),
      O => \interim_velocity[39]_i_6_n_0\
    );
\interim_velocity[39]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(38),
      I1 => \^d_term_reg\(38),
      I2 => \^p_term_reg\(38),
      I3 => \interim_velocity[39]_i_3_n_0\,
      O => \interim_velocity[39]_i_7_n_0\
    );
\interim_velocity[39]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(37),
      I1 => \^d_term_reg\(37),
      I2 => \^p_term_reg\(37),
      I3 => \interim_velocity[39]_i_4_n_0\,
      O => \interim_velocity[39]_i_8_n_0\
    );
\interim_velocity[39]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(36),
      I1 => \^d_term_reg\(36),
      I2 => \^p_term_reg\(36),
      I3 => \interim_velocity[39]_i_5_n_0\,
      O => \interim_velocity[39]_i_9_n_0\
    );
\interim_velocity[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(2),
      I1 => \^d_term_reg\(2),
      I2 => \^p_term_reg\(2),
      O => \interim_velocity[3]_i_2_n_0\
    );
\interim_velocity[3]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(1),
      I1 => \^d_term_reg\(1),
      I2 => \^p_term_reg\(1),
      O => \interim_velocity[3]_i_3_n_0\
    );
\interim_velocity[3]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(0),
      I1 => \^d_term_reg\(0),
      I2 => \^p_term_reg\(0),
      O => \interim_velocity[3]_i_4_n_0\
    );
\interim_velocity[3]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(3),
      I1 => \^d_term_reg\(3),
      I2 => \^p_term_reg\(3),
      I3 => \interim_velocity[3]_i_2_n_0\,
      O => \interim_velocity[3]_i_5_n_0\
    );
\interim_velocity[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(2),
      I1 => \^d_term_reg\(2),
      I2 => \^p_term_reg\(2),
      I3 => \interim_velocity[3]_i_3_n_0\,
      O => \interim_velocity[3]_i_6_n_0\
    );
\interim_velocity[3]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(1),
      I1 => \^d_term_reg\(1),
      I2 => \^p_term_reg\(1),
      I3 => \interim_velocity[3]_i_4_n_0\,
      O => \interim_velocity[3]_i_7_n_0\
    );
\interim_velocity[3]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^i_term_reg\(0),
      I1 => \^d_term_reg\(0),
      I2 => \^p_term_reg\(0),
      O => \interim_velocity[3]_i_8_n_0\
    );
\interim_velocity[72]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"09"
    )
        port map (
      I0 => \^i_term_reg\(40),
      I1 => \^d_term_reg\(40),
      I2 => \^p_term_reg\(40),
      O => \interim_velocity[72]_i_2_n_0\
    );
\interim_velocity[72]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^p_term_reg\(40),
      I1 => \^d_term_reg\(40),
      I2 => \^i_term_reg\(40),
      O => \interim_velocity[72]_i_3_n_0\
    );
\interim_velocity[72]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7E"
    )
        port map (
      I0 => \^p_term_reg\(40),
      I1 => \^i_term_reg\(40),
      I2 => \^d_term_reg\(40),
      O => \interim_velocity[72]_i_4_n_0\
    );
\interim_velocity[72]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969699669969696"
    )
        port map (
      I0 => \^p_term_reg\(40),
      I1 => \^d_term_reg\(40),
      I2 => \^i_term_reg\(40),
      I3 => \^p_term_reg\(39),
      I4 => \^d_term_reg\(39),
      I5 => \^i_term_reg\(39),
      O => \interim_velocity[72]_i_5_n_0\
    );
\interim_velocity[7]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(6),
      I1 => \^d_term_reg\(6),
      I2 => \^p_term_reg\(6),
      O => \interim_velocity[7]_i_2_n_0\
    );
\interim_velocity[7]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(5),
      I1 => \^d_term_reg\(5),
      I2 => \^p_term_reg\(5),
      O => \interim_velocity[7]_i_3_n_0\
    );
\interim_velocity[7]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(4),
      I1 => \^d_term_reg\(4),
      I2 => \^p_term_reg\(4),
      O => \interim_velocity[7]_i_4_n_0\
    );
\interim_velocity[7]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \^i_term_reg\(3),
      I1 => \^d_term_reg\(3),
      I2 => \^p_term_reg\(3),
      O => \interim_velocity[7]_i_5_n_0\
    );
\interim_velocity[7]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(7),
      I1 => \^d_term_reg\(7),
      I2 => \^p_term_reg\(7),
      I3 => \interim_velocity[7]_i_2_n_0\,
      O => \interim_velocity[7]_i_6_n_0\
    );
\interim_velocity[7]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(6),
      I1 => \^d_term_reg\(6),
      I2 => \^p_term_reg\(6),
      I3 => \interim_velocity[7]_i_3_n_0\,
      O => \interim_velocity[7]_i_7_n_0\
    );
\interim_velocity[7]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(5),
      I1 => \^d_term_reg\(5),
      I2 => \^p_term_reg\(5),
      I3 => \interim_velocity[7]_i_4_n_0\,
      O => \interim_velocity[7]_i_8_n_0\
    );
\interim_velocity[7]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \^i_term_reg\(4),
      I1 => \^d_term_reg\(4),
      I2 => \^p_term_reg\(4),
      I3 => \interim_velocity[7]_i_5_n_0\,
      O => \interim_velocity[7]_i_9_n_0\
    );
\interim_velocity_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[3]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[0]\,
      R => '0'
    );
\interim_velocity_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[11]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[10]\,
      R => '0'
    );
\interim_velocity_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[11]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[11]\,
      R => '0'
    );
\interim_velocity_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[7]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[11]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[11]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[11]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[11]_i_2_n_0\,
      DI(2) => \interim_velocity[11]_i_3_n_0\,
      DI(1) => \interim_velocity[11]_i_4_n_0\,
      DI(0) => \interim_velocity[11]_i_5_n_0\,
      O(3) => \interim_velocity_reg[11]_i_1_n_4\,
      O(2) => \interim_velocity_reg[11]_i_1_n_5\,
      O(1) => \interim_velocity_reg[11]_i_1_n_6\,
      O(0) => \interim_velocity_reg[11]_i_1_n_7\,
      S(3) => \interim_velocity[11]_i_6_n_0\,
      S(2) => \interim_velocity[11]_i_7_n_0\,
      S(1) => \interim_velocity[11]_i_8_n_0\,
      S(0) => \interim_velocity[11]_i_9_n_0\
    );
\interim_velocity_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[15]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[12]\,
      R => '0'
    );
\interim_velocity_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[15]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[13]\,
      R => '0'
    );
\interim_velocity_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[15]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[14]\,
      R => '0'
    );
\interim_velocity_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[15]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[15]\,
      R => '0'
    );
\interim_velocity_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[11]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[15]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[15]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[15]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[15]_i_2_n_0\,
      DI(2) => \interim_velocity[15]_i_3_n_0\,
      DI(1) => \interim_velocity[15]_i_4_n_0\,
      DI(0) => \interim_velocity[15]_i_5_n_0\,
      O(3) => \interim_velocity_reg[15]_i_1_n_4\,
      O(2) => \interim_velocity_reg[15]_i_1_n_5\,
      O(1) => \interim_velocity_reg[15]_i_1_n_6\,
      O(0) => \interim_velocity_reg[15]_i_1_n_7\,
      S(3) => \interim_velocity[15]_i_6_n_0\,
      S(2) => \interim_velocity[15]_i_7_n_0\,
      S(1) => \interim_velocity[15]_i_8_n_0\,
      S(0) => \interim_velocity[15]_i_9_n_0\
    );
\interim_velocity_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[19]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[16]\,
      R => '0'
    );
\interim_velocity_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[19]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[17]\,
      R => '0'
    );
\interim_velocity_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[19]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[18]\,
      R => '0'
    );
\interim_velocity_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[19]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[19]\,
      R => '0'
    );
\interim_velocity_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[15]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[19]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[19]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[19]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[19]_i_2_n_0\,
      DI(2) => \interim_velocity[19]_i_3_n_0\,
      DI(1) => \interim_velocity[19]_i_4_n_0\,
      DI(0) => \interim_velocity[19]_i_5_n_0\,
      O(3) => \interim_velocity_reg[19]_i_1_n_4\,
      O(2) => \interim_velocity_reg[19]_i_1_n_5\,
      O(1) => \interim_velocity_reg[19]_i_1_n_6\,
      O(0) => \interim_velocity_reg[19]_i_1_n_7\,
      S(3) => \interim_velocity[19]_i_6_n_0\,
      S(2) => \interim_velocity[19]_i_7_n_0\,
      S(1) => \interim_velocity[19]_i_8_n_0\,
      S(0) => \interim_velocity[19]_i_9_n_0\
    );
\interim_velocity_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[3]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[1]\,
      R => '0'
    );
\interim_velocity_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[23]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[20]\,
      R => '0'
    );
\interim_velocity_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[23]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[21]\,
      R => '0'
    );
\interim_velocity_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[23]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[22]\,
      R => '0'
    );
\interim_velocity_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[23]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[23]\,
      R => '0'
    );
\interim_velocity_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[19]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[23]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[23]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[23]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[23]_i_2_n_0\,
      DI(2) => \interim_velocity[23]_i_3_n_0\,
      DI(1) => \interim_velocity[23]_i_4_n_0\,
      DI(0) => \interim_velocity[23]_i_5_n_0\,
      O(3) => \interim_velocity_reg[23]_i_1_n_4\,
      O(2) => \interim_velocity_reg[23]_i_1_n_5\,
      O(1) => \interim_velocity_reg[23]_i_1_n_6\,
      O(0) => \interim_velocity_reg[23]_i_1_n_7\,
      S(3) => \interim_velocity[23]_i_6_n_0\,
      S(2) => \interim_velocity[23]_i_7_n_0\,
      S(1) => \interim_velocity[23]_i_8_n_0\,
      S(0) => \interim_velocity[23]_i_9_n_0\
    );
\interim_velocity_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[27]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[24]\,
      R => '0'
    );
\interim_velocity_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[27]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[25]\,
      R => '0'
    );
\interim_velocity_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[27]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[26]\,
      R => '0'
    );
\interim_velocity_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[27]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[27]\,
      R => '0'
    );
\interim_velocity_reg[27]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[23]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[27]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[27]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[27]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[27]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[27]_i_2_n_0\,
      DI(2) => \interim_velocity[27]_i_3_n_0\,
      DI(1) => \interim_velocity[27]_i_4_n_0\,
      DI(0) => \interim_velocity[27]_i_5_n_0\,
      O(3) => \interim_velocity_reg[27]_i_1_n_4\,
      O(2) => \interim_velocity_reg[27]_i_1_n_5\,
      O(1) => \interim_velocity_reg[27]_i_1_n_6\,
      O(0) => \interim_velocity_reg[27]_i_1_n_7\,
      S(3) => \interim_velocity[27]_i_6_n_0\,
      S(2) => \interim_velocity[27]_i_7_n_0\,
      S(1) => \interim_velocity[27]_i_8_n_0\,
      S(0) => \interim_velocity[27]_i_9_n_0\
    );
\interim_velocity_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[31]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[28]\,
      R => '0'
    );
\interim_velocity_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[31]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[29]\,
      R => '0'
    );
\interim_velocity_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[3]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[2]\,
      R => '0'
    );
\interim_velocity_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[31]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[30]\,
      R => '0'
    );
\interim_velocity_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[31]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[31]\,
      R => '0'
    );
\interim_velocity_reg[31]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[27]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[31]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[31]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[31]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[31]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[31]_i_2_n_0\,
      DI(2) => \interim_velocity[31]_i_3_n_0\,
      DI(1) => \interim_velocity[31]_i_4_n_0\,
      DI(0) => \interim_velocity[31]_i_5_n_0\,
      O(3) => \interim_velocity_reg[31]_i_1_n_4\,
      O(2) => \interim_velocity_reg[31]_i_1_n_5\,
      O(1) => \interim_velocity_reg[31]_i_1_n_6\,
      O(0) => \interim_velocity_reg[31]_i_1_n_7\,
      S(3) => \interim_velocity[31]_i_6_n_0\,
      S(2) => \interim_velocity[31]_i_7_n_0\,
      S(1) => \interim_velocity[31]_i_8_n_0\,
      S(0) => \interim_velocity[31]_i_9_n_0\
    );
\interim_velocity_reg[32]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[35]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[32]\,
      R => '0'
    );
\interim_velocity_reg[33]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[35]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[33]\,
      R => '0'
    );
\interim_velocity_reg[34]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[35]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[34]\,
      R => '0'
    );
\interim_velocity_reg[35]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[35]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[35]\,
      R => '0'
    );
\interim_velocity_reg[35]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[31]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[35]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[35]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[35]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[35]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[35]_i_2_n_0\,
      DI(2) => \interim_velocity[35]_i_3_n_0\,
      DI(1) => \interim_velocity[35]_i_4_n_0\,
      DI(0) => \interim_velocity[35]_i_5_n_0\,
      O(3) => \interim_velocity_reg[35]_i_1_n_4\,
      O(2) => \interim_velocity_reg[35]_i_1_n_5\,
      O(1) => \interim_velocity_reg[35]_i_1_n_6\,
      O(0) => \interim_velocity_reg[35]_i_1_n_7\,
      S(3) => \interim_velocity[35]_i_6_n_0\,
      S(2) => \interim_velocity[35]_i_7_n_0\,
      S(1) => \interim_velocity[35]_i_8_n_0\,
      S(0) => \interim_velocity[35]_i_9_n_0\
    );
\interim_velocity_reg[36]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[39]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[36]\,
      R => '0'
    );
\interim_velocity_reg[37]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[39]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[37]\,
      R => '0'
    );
\interim_velocity_reg[38]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[39]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[38]\,
      R => '0'
    );
\interim_velocity_reg[39]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[39]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[39]\,
      R => '0'
    );
\interim_velocity_reg[39]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[35]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[39]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[39]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[39]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[39]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[39]_i_2_n_0\,
      DI(2) => \interim_velocity[39]_i_3_n_0\,
      DI(1) => \interim_velocity[39]_i_4_n_0\,
      DI(0) => \interim_velocity[39]_i_5_n_0\,
      O(3) => \interim_velocity_reg[39]_i_1_n_4\,
      O(2) => \interim_velocity_reg[39]_i_1_n_5\,
      O(1) => \interim_velocity_reg[39]_i_1_n_6\,
      O(0) => \interim_velocity_reg[39]_i_1_n_7\,
      S(3) => \interim_velocity[39]_i_6_n_0\,
      S(2) => \interim_velocity[39]_i_7_n_0\,
      S(1) => \interim_velocity[39]_i_8_n_0\,
      S(0) => \interim_velocity[39]_i_9_n_0\
    );
\interim_velocity_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[3]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[3]\,
      R => '0'
    );
\interim_velocity_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \interim_velocity_reg[3]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[3]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[3]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[3]_i_2_n_0\,
      DI(2) => \interim_velocity[3]_i_3_n_0\,
      DI(1) => \interim_velocity[3]_i_4_n_0\,
      DI(0) => '0',
      O(3) => \interim_velocity_reg[3]_i_1_n_4\,
      O(2) => \interim_velocity_reg[3]_i_1_n_5\,
      O(1) => \interim_velocity_reg[3]_i_1_n_6\,
      O(0) => \interim_velocity_reg[3]_i_1_n_7\,
      S(3) => \interim_velocity[3]_i_5_n_0\,
      S(2) => \interim_velocity[3]_i_6_n_0\,
      S(1) => \interim_velocity[3]_i_7_n_0\,
      S(0) => \interim_velocity[3]_i_8_n_0\
    );
\interim_velocity_reg[40]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[72]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[40]\,
      R => '0'
    );
\interim_velocity_reg[41]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[72]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[41]\,
      R => '0'
    );
\interim_velocity_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[7]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[4]\,
      R => '0'
    );
\interim_velocity_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[7]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[5]\,
      R => '0'
    );
\interim_velocity_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[7]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[6]\,
      R => '0'
    );
\interim_velocity_reg[72]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[72]_i_1_n_5\,
      Q => \interim_velocity_reg_n_0_[72]\,
      R => '0'
    );
\interim_velocity_reg[72]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[39]_i_1_n_0\,
      CO(3 downto 2) => \NLW_interim_velocity_reg[72]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \interim_velocity_reg[72]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[72]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \interim_velocity[72]_i_2_n_0\,
      DI(0) => \interim_velocity[72]_i_3_n_0\,
      O(3) => \NLW_interim_velocity_reg[72]_i_1_O_UNCONNECTED\(3),
      O(2) => \interim_velocity_reg[72]_i_1_n_5\,
      O(1) => \interim_velocity_reg[72]_i_1_n_6\,
      O(0) => \interim_velocity_reg[72]_i_1_n_7\,
      S(3 downto 2) => B"01",
      S(1) => \interim_velocity[72]_i_4_n_0\,
      S(0) => \interim_velocity[72]_i_5_n_0\
    );
\interim_velocity_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[7]_i_1_n_4\,
      Q => \interim_velocity_reg_n_0_[7]\,
      R => '0'
    );
\interim_velocity_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_velocity_reg[3]_i_1_n_0\,
      CO(3) => \interim_velocity_reg[7]_i_1_n_0\,
      CO(2) => \interim_velocity_reg[7]_i_1_n_1\,
      CO(1) => \interim_velocity_reg[7]_i_1_n_2\,
      CO(0) => \interim_velocity_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity[7]_i_2_n_0\,
      DI(2) => \interim_velocity[7]_i_3_n_0\,
      DI(1) => \interim_velocity[7]_i_4_n_0\,
      DI(0) => \interim_velocity[7]_i_5_n_0\,
      O(3) => \interim_velocity_reg[7]_i_1_n_4\,
      O(2) => \interim_velocity_reg[7]_i_1_n_5\,
      O(1) => \interim_velocity_reg[7]_i_1_n_6\,
      O(0) => \interim_velocity_reg[7]_i_1_n_7\,
      S(3) => \interim_velocity[7]_i_6_n_0\,
      S(2) => \interim_velocity[7]_i_7_n_0\,
      S(1) => \interim_velocity[7]_i_8_n_0\,
      S(0) => \interim_velocity[7]_i_9_n_0\
    );
\interim_velocity_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[11]_i_1_n_7\,
      Q => \interim_velocity_reg_n_0_[8]\,
      R => '0'
    );
\interim_velocity_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \interim_velocity_reg[11]_i_1_n_6\,
      Q => \interim_velocity_reg_n_0_[9]\,
      R => '0'
    );
\nv_flag_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \velocity[31]_i_1_n_0\,
      Q => new_velocity_available(0),
      R => '0'
    );
p_term0: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 1,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 1,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => error0(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_p_term0_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kp(8),
      B(16) => kp(8),
      B(15) => kp(8),
      B(14) => kp(8),
      B(13) => kp(8),
      B(12) => kp(8),
      B(11) => kp(8),
      B(10) => kp(8),
      B(9) => kp(8),
      B(8 downto 0) => kp(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_p_term0_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_p_term0_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_p_term0_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '1',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => clock(0),
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_p_term0_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_p_term0_OVERFLOW_UNCONNECTED,
      P(47) => p_term0_n_58,
      P(46) => p_term0_n_59,
      P(45) => p_term0_n_60,
      P(44) => p_term0_n_61,
      P(43) => p_term0_n_62,
      P(42) => p_term0_n_63,
      P(41) => p_term0_n_64,
      P(40) => p_term0_n_65,
      P(39) => p_term0_n_66,
      P(38) => p_term0_n_67,
      P(37) => p_term0_n_68,
      P(36) => p_term0_n_69,
      P(35) => p_term0_n_70,
      P(34) => p_term0_n_71,
      P(33) => p_term0_n_72,
      P(32) => p_term0_n_73,
      P(31) => p_term0_n_74,
      P(30) => p_term0_n_75,
      P(29) => p_term0_n_76,
      P(28) => p_term0_n_77,
      P(27) => p_term0_n_78,
      P(26) => p_term0_n_79,
      P(25) => p_term0_n_80,
      P(24) => p_term0_n_81,
      P(23) => p_term0_n_82,
      P(22) => p_term0_n_83,
      P(21) => p_term0_n_84,
      P(20) => p_term0_n_85,
      P(19) => p_term0_n_86,
      P(18) => p_term0_n_87,
      P(17) => p_term0_n_88,
      P(16) => p_term0_n_89,
      P(15) => p_term0_n_90,
      P(14) => p_term0_n_91,
      P(13) => p_term0_n_92,
      P(12) => p_term0_n_93,
      P(11) => p_term0_n_94,
      P(10) => p_term0_n_95,
      P(9) => p_term0_n_96,
      P(8) => p_term0_n_97,
      P(7) => p_term0_n_98,
      P(6) => p_term0_n_99,
      P(5) => p_term0_n_100,
      P(4) => p_term0_n_101,
      P(3) => p_term0_n_102,
      P(2) => p_term0_n_103,
      P(1) => p_term0_n_104,
      P(0) => p_term0_n_105,
      PATTERNBDETECT => NLW_p_term0_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_p_term0_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => p_term0_n_106,
      PCOUT(46) => p_term0_n_107,
      PCOUT(45) => p_term0_n_108,
      PCOUT(44) => p_term0_n_109,
      PCOUT(43) => p_term0_n_110,
      PCOUT(42) => p_term0_n_111,
      PCOUT(41) => p_term0_n_112,
      PCOUT(40) => p_term0_n_113,
      PCOUT(39) => p_term0_n_114,
      PCOUT(38) => p_term0_n_115,
      PCOUT(37) => p_term0_n_116,
      PCOUT(36) => p_term0_n_117,
      PCOUT(35) => p_term0_n_118,
      PCOUT(34) => p_term0_n_119,
      PCOUT(33) => p_term0_n_120,
      PCOUT(32) => p_term0_n_121,
      PCOUT(31) => p_term0_n_122,
      PCOUT(30) => p_term0_n_123,
      PCOUT(29) => p_term0_n_124,
      PCOUT(28) => p_term0_n_125,
      PCOUT(27) => p_term0_n_126,
      PCOUT(26) => p_term0_n_127,
      PCOUT(25) => p_term0_n_128,
      PCOUT(24) => p_term0_n_129,
      PCOUT(23) => p_term0_n_130,
      PCOUT(22) => p_term0_n_131,
      PCOUT(21) => p_term0_n_132,
      PCOUT(20) => p_term0_n_133,
      PCOUT(19) => p_term0_n_134,
      PCOUT(18) => p_term0_n_135,
      PCOUT(17) => p_term0_n_136,
      PCOUT(16) => p_term0_n_137,
      PCOUT(15) => p_term0_n_138,
      PCOUT(14) => p_term0_n_139,
      PCOUT(13) => p_term0_n_140,
      PCOUT(12) => p_term0_n_141,
      PCOUT(11) => p_term0_n_142,
      PCOUT(10) => p_term0_n_143,
      PCOUT(9) => p_term0_n_144,
      PCOUT(8) => p_term0_n_145,
      PCOUT(7) => p_term0_n_146,
      PCOUT(6) => p_term0_n_147,
      PCOUT(5) => p_term0_n_148,
      PCOUT(4) => p_term0_n_149,
      PCOUT(3) => p_term0_n_150,
      PCOUT(2) => p_term0_n_151,
      PCOUT(1) => p_term0_n_152,
      PCOUT(0) => p_term0_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_p_term0_UNDERFLOW_UNCONNECTED
    );
p_term_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 1,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 1,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => error0(31),
      A(28) => error0(31),
      A(27) => error0(31),
      A(26) => error0(31),
      A(25) => error0(31),
      A(24) => error0(31),
      A(23) => error0(31),
      A(22) => error0(31),
      A(21) => error0(31),
      A(20) => error0(31),
      A(19) => error0(31),
      A(18) => error0(31),
      A(17) => error0(31),
      A(16) => error0(31),
      A(15) => error0(31),
      A(14 downto 0) => error0(31 downto 17),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_p_term_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => kp(8),
      B(16) => kp(8),
      B(15) => kp(8),
      B(14) => kp(8),
      B(13) => kp(8),
      B(12) => kp(8),
      B(11) => kp(8),
      B(10) => kp(8),
      B(9) => kp(8),
      B(8 downto 0) => kp(8 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_p_term_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_p_term_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_p_term_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '1',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '1',
      CLK => clock(0),
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_p_term_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => NLW_p_term_reg_OVERFLOW_UNCONNECTED,
      P(47) => p_term_reg_n_58,
      P(46) => p_term_reg_n_59,
      P(45) => p_term_reg_n_60,
      P(44) => p_term_reg_n_61,
      P(43) => p_term_reg_n_62,
      P(42) => p_term_reg_n_63,
      P(41) => p_term_reg_n_64,
      P(40) => p_term_reg_n_65,
      P(39) => p_term_reg_n_66,
      P(38) => p_term_reg_n_67,
      P(37) => p_term_reg_n_68,
      P(36) => p_term_reg_n_69,
      P(35) => p_term_reg_n_70,
      P(34) => p_term_reg_n_71,
      P(33) => p_term_reg_n_72,
      P(32) => p_term_reg_n_73,
      P(31) => p_term_reg_n_74,
      P(30) => p_term_reg_n_75,
      P(29) => p_term_reg_n_76,
      P(28) => p_term_reg_n_77,
      P(27) => p_term_reg_n_78,
      P(26) => p_term_reg_n_79,
      P(25) => p_term_reg_n_80,
      P(24) => p_term_reg_n_81,
      P(23 downto 0) => \^p_term_reg\(40 downto 17),
      PATTERNBDETECT => NLW_p_term_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_p_term_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47) => p_term0_n_106,
      PCIN(46) => p_term0_n_107,
      PCIN(45) => p_term0_n_108,
      PCIN(44) => p_term0_n_109,
      PCIN(43) => p_term0_n_110,
      PCIN(42) => p_term0_n_111,
      PCIN(41) => p_term0_n_112,
      PCIN(40) => p_term0_n_113,
      PCIN(39) => p_term0_n_114,
      PCIN(38) => p_term0_n_115,
      PCIN(37) => p_term0_n_116,
      PCIN(36) => p_term0_n_117,
      PCIN(35) => p_term0_n_118,
      PCIN(34) => p_term0_n_119,
      PCIN(33) => p_term0_n_120,
      PCIN(32) => p_term0_n_121,
      PCIN(31) => p_term0_n_122,
      PCIN(30) => p_term0_n_123,
      PCIN(29) => p_term0_n_124,
      PCIN(28) => p_term0_n_125,
      PCIN(27) => p_term0_n_126,
      PCIN(26) => p_term0_n_127,
      PCIN(25) => p_term0_n_128,
      PCIN(24) => p_term0_n_129,
      PCIN(23) => p_term0_n_130,
      PCIN(22) => p_term0_n_131,
      PCIN(21) => p_term0_n_132,
      PCIN(20) => p_term0_n_133,
      PCIN(19) => p_term0_n_134,
      PCIN(18) => p_term0_n_135,
      PCIN(17) => p_term0_n_136,
      PCIN(16) => p_term0_n_137,
      PCIN(15) => p_term0_n_138,
      PCIN(14) => p_term0_n_139,
      PCIN(13) => p_term0_n_140,
      PCIN(12) => p_term0_n_141,
      PCIN(11) => p_term0_n_142,
      PCIN(10) => p_term0_n_143,
      PCIN(9) => p_term0_n_144,
      PCIN(8) => p_term0_n_145,
      PCIN(7) => p_term0_n_146,
      PCIN(6) => p_term0_n_147,
      PCIN(5) => p_term0_n_148,
      PCIN(4) => p_term0_n_149,
      PCIN(3) => p_term0_n_150,
      PCIN(2) => p_term0_n_151,
      PCIN(1) => p_term0_n_152,
      PCIN(0) => p_term0_n_153,
      PCOUT(47 downto 0) => NLW_p_term_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_p_term_reg_UNDERFLOW_UNCONNECTED
    );
\p_term_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_105,
      Q => \^p_term_reg\(0),
      R => '0'
    );
\p_term_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_95,
      Q => \^p_term_reg\(10),
      R => '0'
    );
\p_term_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_94,
      Q => \^p_term_reg\(11),
      R => '0'
    );
\p_term_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_93,
      Q => \^p_term_reg\(12),
      R => '0'
    );
\p_term_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_92,
      Q => \^p_term_reg\(13),
      R => '0'
    );
\p_term_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_91,
      Q => \^p_term_reg\(14),
      R => '0'
    );
\p_term_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_90,
      Q => \^p_term_reg\(15),
      R => '0'
    );
\p_term_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_89,
      Q => \^p_term_reg\(16),
      R => '0'
    );
\p_term_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_104,
      Q => \^p_term_reg\(1),
      R => '0'
    );
\p_term_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_103,
      Q => \^p_term_reg\(2),
      R => '0'
    );
\p_term_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_102,
      Q => \^p_term_reg\(3),
      R => '0'
    );
\p_term_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_101,
      Q => \^p_term_reg\(4),
      R => '0'
    );
\p_term_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_100,
      Q => \^p_term_reg\(5),
      R => '0'
    );
\p_term_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_99,
      Q => \^p_term_reg\(6),
      R => '0'
    );
\p_term_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_98,
      Q => \^p_term_reg\(7),
      R => '0'
    );
\p_term_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_97,
      Q => \^p_term_reg\(8),
      R => '0'
    );
\p_term_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => p_term0_n_96,
      Q => \^p_term_reg\(9),
      R => '0'
    );
\saved_target_angle_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(0),
      Q => saved_target_angle(0),
      R => '0'
    );
\saved_target_angle_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(10),
      Q => saved_target_angle(10),
      R => '0'
    );
\saved_target_angle_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(11),
      Q => saved_target_angle(11),
      R => '0'
    );
\saved_target_angle_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(12),
      Q => saved_target_angle(12),
      R => '0'
    );
\saved_target_angle_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(13),
      Q => saved_target_angle(13),
      R => '0'
    );
\saved_target_angle_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(14),
      Q => saved_target_angle(14),
      R => '0'
    );
\saved_target_angle_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(15),
      Q => saved_target_angle(15),
      R => '0'
    );
\saved_target_angle_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(16),
      Q => saved_target_angle(16),
      R => '0'
    );
\saved_target_angle_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(17),
      Q => saved_target_angle(17),
      R => '0'
    );
\saved_target_angle_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(18),
      Q => saved_target_angle(18),
      R => '0'
    );
\saved_target_angle_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(19),
      Q => saved_target_angle(19),
      R => '0'
    );
\saved_target_angle_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(1),
      Q => saved_target_angle(1),
      R => '0'
    );
\saved_target_angle_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(20),
      Q => saved_target_angle(20),
      R => '0'
    );
\saved_target_angle_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(21),
      Q => saved_target_angle(21),
      R => '0'
    );
\saved_target_angle_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(22),
      Q => saved_target_angle(22),
      R => '0'
    );
\saved_target_angle_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(23),
      Q => saved_target_angle(23),
      R => '0'
    );
\saved_target_angle_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(24),
      Q => saved_target_angle(24),
      R => '0'
    );
\saved_target_angle_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(25),
      Q => saved_target_angle(25),
      R => '0'
    );
\saved_target_angle_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(26),
      Q => saved_target_angle(26),
      R => '0'
    );
\saved_target_angle_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(27),
      Q => saved_target_angle(27),
      R => '0'
    );
\saved_target_angle_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(28),
      Q => saved_target_angle(28),
      R => '0'
    );
\saved_target_angle_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(29),
      Q => saved_target_angle(29),
      R => '0'
    );
\saved_target_angle_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(2),
      Q => saved_target_angle(2),
      R => '0'
    );
\saved_target_angle_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(30),
      Q => saved_target_angle(30),
      R => '0'
    );
\saved_target_angle_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(31),
      Q => saved_target_angle(31),
      R => '0'
    );
\saved_target_angle_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(3),
      Q => saved_target_angle(3),
      R => '0'
    );
\saved_target_angle_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(4),
      Q => saved_target_angle(4),
      R => '0'
    );
\saved_target_angle_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(5),
      Q => saved_target_angle(5),
      R => '0'
    );
\saved_target_angle_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(6),
      Q => saved_target_angle(6),
      R => '0'
    );
\saved_target_angle_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(7),
      Q => saved_target_angle(7),
      R => '0'
    );
\saved_target_angle_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(8),
      Q => saved_target_angle(8),
      R => '0'
    );
\saved_target_angle_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => new_target_angle_available(0),
      D => target_angle(9),
      Q => saved_target_angle(9),
      R => '0'
    );
velocity1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => velocity1_carry_n_0,
      CO(2) => velocity1_carry_n_1,
      CO(1) => velocity1_carry_n_2,
      CO(0) => velocity1_carry_n_3,
      CYINIT => '0',
      DI(3) => velocity1_carry_i_1_n_0,
      DI(2) => velocity2(5),
      DI(1) => velocity1_carry_i_3_n_0,
      DI(0) => velocity1_carry_i_4_n_0,
      O(3 downto 0) => NLW_velocity1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => velocity1_carry_i_5_n_0,
      S(2) => velocity1_carry_i_6_n_0,
      S(1) => velocity1_carry_i_7_n_0,
      S(0) => velocity1_carry_i_8_n_0
    );
\velocity1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => velocity1_carry_n_0,
      CO(3) => \velocity1_carry__0_n_0\,
      CO(2) => \velocity1_carry__0_n_1\,
      CO(1) => \velocity1_carry__0_n_2\,
      CO(0) => \velocity1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__0_i_1_n_0\,
      DI(2) => \velocity1_carry__0_i_2_n_0\,
      DI(1) => \velocity1_carry__0_i_3_n_0\,
      DI(0) => \velocity1_carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__0_i_5_n_0\,
      S(2) => \velocity1_carry__0_i_6_n_0\,
      S(1) => \velocity1_carry__0_i_7_n_0\,
      S(0) => \velocity1_carry__0_i_8_n_0\
    );
\velocity1_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(14),
      I1 => velocity2(15),
      O => \velocity1_carry__0_i_1_n_0\
    );
\velocity1_carry__0_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => velocity1_carry_i_2_n_0,
      CO(3) => \velocity1_carry__0_i_10_n_0\,
      CO(2) => \velocity1_carry__0_i_10_n_1\,
      CO(1) => \velocity1_carry__0_i_10_n_2\,
      CO(0) => \velocity1_carry__0_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[11]\,
      DI(2) => \interim_velocity_reg_n_0_[10]\,
      DI(1) => \interim_velocity_reg_n_0_[9]\,
      DI(0) => \interim_velocity_reg_n_0_[8]\,
      O(3 downto 0) => velocity2(11 downto 8),
      S(3) => \velocity1_carry__0_i_15_n_0\,
      S(2) => \velocity1_carry__0_i_16_n_0\,
      S(1) => \velocity1_carry__0_i_17_n_0\,
      S(0) => \velocity1_carry__0_i_18_n_0\
    );
\velocity1_carry__0_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[15]\,
      I1 => \^output_velocity\(15),
      O => \velocity1_carry__0_i_11_n_0\
    );
\velocity1_carry__0_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[14]\,
      I1 => \^output_velocity\(14),
      O => \velocity1_carry__0_i_12_n_0\
    );
\velocity1_carry__0_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[13]\,
      I1 => \^output_velocity\(13),
      O => \velocity1_carry__0_i_13_n_0\
    );
\velocity1_carry__0_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[12]\,
      I1 => \^output_velocity\(12),
      O => \velocity1_carry__0_i_14_n_0\
    );
\velocity1_carry__0_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[11]\,
      I1 => \^output_velocity\(11),
      O => \velocity1_carry__0_i_15_n_0\
    );
\velocity1_carry__0_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[10]\,
      I1 => \^output_velocity\(10),
      O => \velocity1_carry__0_i_16_n_0\
    );
\velocity1_carry__0_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[9]\,
      I1 => \^output_velocity\(9),
      O => \velocity1_carry__0_i_17_n_0\
    );
\velocity1_carry__0_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[8]\,
      I1 => \^output_velocity\(8),
      O => \velocity1_carry__0_i_18_n_0\
    );
\velocity1_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(12),
      I1 => velocity2(13),
      O => \velocity1_carry__0_i_2_n_0\
    );
\velocity1_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(10),
      I1 => velocity2(11),
      O => \velocity1_carry__0_i_3_n_0\
    );
\velocity1_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(8),
      I1 => velocity2(9),
      O => \velocity1_carry__0_i_4_n_0\
    );
\velocity1_carry__0_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(14),
      I1 => velocity2(15),
      O => \velocity1_carry__0_i_5_n_0\
    );
\velocity1_carry__0_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(12),
      I1 => velocity2(13),
      O => \velocity1_carry__0_i_6_n_0\
    );
\velocity1_carry__0_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(10),
      I1 => velocity2(11),
      O => \velocity1_carry__0_i_7_n_0\
    );
\velocity1_carry__0_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(8),
      I1 => velocity2(9),
      O => \velocity1_carry__0_i_8_n_0\
    );
\velocity1_carry__0_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__0_i_10_n_0\,
      CO(3) => \velocity1_carry__0_i_9_n_0\,
      CO(2) => \velocity1_carry__0_i_9_n_1\,
      CO(1) => \velocity1_carry__0_i_9_n_2\,
      CO(0) => \velocity1_carry__0_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[15]\,
      DI(2) => \interim_velocity_reg_n_0_[14]\,
      DI(1) => \interim_velocity_reg_n_0_[13]\,
      DI(0) => \interim_velocity_reg_n_0_[12]\,
      O(3 downto 0) => velocity2(15 downto 12),
      S(3) => \velocity1_carry__0_i_11_n_0\,
      S(2) => \velocity1_carry__0_i_12_n_0\,
      S(1) => \velocity1_carry__0_i_13_n_0\,
      S(0) => \velocity1_carry__0_i_14_n_0\
    );
\velocity1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__0_n_0\,
      CO(3) => \velocity1_carry__1_n_0\,
      CO(2) => \velocity1_carry__1_n_1\,
      CO(1) => \velocity1_carry__1_n_2\,
      CO(0) => \velocity1_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__1_i_1_n_0\,
      DI(2) => \velocity1_carry__1_i_2_n_0\,
      DI(1) => \velocity1_carry__1_i_3_n_0\,
      DI(0) => \velocity1_carry__1_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__1_i_5_n_0\,
      S(2) => \velocity1_carry__1_i_6_n_0\,
      S(1) => \velocity1_carry__1_i_7_n_0\,
      S(0) => \velocity1_carry__1_i_8_n_0\
    );
\velocity1_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(22),
      I1 => velocity2(23),
      O => \velocity1_carry__1_i_1_n_0\
    );
\velocity1_carry__1_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__0_i_9_n_0\,
      CO(3) => \velocity1_carry__1_i_10_n_0\,
      CO(2) => \velocity1_carry__1_i_10_n_1\,
      CO(1) => \velocity1_carry__1_i_10_n_2\,
      CO(0) => \velocity1_carry__1_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[19]\,
      DI(2) => \interim_velocity_reg_n_0_[18]\,
      DI(1) => \interim_velocity_reg_n_0_[17]\,
      DI(0) => \interim_velocity_reg_n_0_[16]\,
      O(3 downto 0) => velocity2(19 downto 16),
      S(3) => \velocity1_carry__1_i_15_n_0\,
      S(2) => \velocity1_carry__1_i_16_n_0\,
      S(1) => \velocity1_carry__1_i_17_n_0\,
      S(0) => \velocity1_carry__1_i_18_n_0\
    );
\velocity1_carry__1_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[23]\,
      I1 => \^output_velocity\(23),
      O => \velocity1_carry__1_i_11_n_0\
    );
\velocity1_carry__1_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[22]\,
      I1 => \^output_velocity\(22),
      O => \velocity1_carry__1_i_12_n_0\
    );
\velocity1_carry__1_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[21]\,
      I1 => \^output_velocity\(21),
      O => \velocity1_carry__1_i_13_n_0\
    );
\velocity1_carry__1_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[20]\,
      I1 => \^output_velocity\(20),
      O => \velocity1_carry__1_i_14_n_0\
    );
\velocity1_carry__1_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[19]\,
      I1 => \^output_velocity\(19),
      O => \velocity1_carry__1_i_15_n_0\
    );
\velocity1_carry__1_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[18]\,
      I1 => \^output_velocity\(18),
      O => \velocity1_carry__1_i_16_n_0\
    );
\velocity1_carry__1_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[17]\,
      I1 => \^output_velocity\(17),
      O => \velocity1_carry__1_i_17_n_0\
    );
\velocity1_carry__1_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[16]\,
      I1 => \^output_velocity\(16),
      O => \velocity1_carry__1_i_18_n_0\
    );
\velocity1_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(20),
      I1 => velocity2(21),
      O => \velocity1_carry__1_i_2_n_0\
    );
\velocity1_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(18),
      I1 => velocity2(19),
      O => \velocity1_carry__1_i_3_n_0\
    );
\velocity1_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(16),
      I1 => velocity2(17),
      O => \velocity1_carry__1_i_4_n_0\
    );
\velocity1_carry__1_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(22),
      I1 => velocity2(23),
      O => \velocity1_carry__1_i_5_n_0\
    );
\velocity1_carry__1_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(20),
      I1 => velocity2(21),
      O => \velocity1_carry__1_i_6_n_0\
    );
\velocity1_carry__1_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(18),
      I1 => velocity2(19),
      O => \velocity1_carry__1_i_7_n_0\
    );
\velocity1_carry__1_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(16),
      I1 => velocity2(17),
      O => \velocity1_carry__1_i_8_n_0\
    );
\velocity1_carry__1_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__1_i_10_n_0\,
      CO(3) => \velocity1_carry__1_i_9_n_0\,
      CO(2) => \velocity1_carry__1_i_9_n_1\,
      CO(1) => \velocity1_carry__1_i_9_n_2\,
      CO(0) => \velocity1_carry__1_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[23]\,
      DI(2) => \interim_velocity_reg_n_0_[22]\,
      DI(1) => \interim_velocity_reg_n_0_[21]\,
      DI(0) => \interim_velocity_reg_n_0_[20]\,
      O(3 downto 0) => velocity2(23 downto 20),
      S(3) => \velocity1_carry__1_i_11_n_0\,
      S(2) => \velocity1_carry__1_i_12_n_0\,
      S(1) => \velocity1_carry__1_i_13_n_0\,
      S(0) => \velocity1_carry__1_i_14_n_0\
    );
\velocity1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__1_n_0\,
      CO(3) => \velocity1_carry__2_n_0\,
      CO(2) => \velocity1_carry__2_n_1\,
      CO(1) => \velocity1_carry__2_n_2\,
      CO(0) => \velocity1_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__2_i_1_n_0\,
      DI(2) => \velocity1_carry__2_i_2_n_0\,
      DI(1) => \velocity1_carry__2_i_3_n_0\,
      DI(0) => \velocity1_carry__2_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__2_i_5_n_0\,
      S(2) => \velocity1_carry__2_i_6_n_0\,
      S(1) => \velocity1_carry__2_i_7_n_0\,
      S(0) => \velocity1_carry__2_i_8_n_0\
    );
\velocity1_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(30),
      I1 => velocity2(31),
      O => \velocity1_carry__2_i_1_n_0\
    );
\velocity1_carry__2_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__1_i_9_n_0\,
      CO(3) => \velocity1_carry__2_i_10_n_0\,
      CO(2) => \velocity1_carry__2_i_10_n_1\,
      CO(1) => \velocity1_carry__2_i_10_n_2\,
      CO(0) => \velocity1_carry__2_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[27]\,
      DI(2) => \interim_velocity_reg_n_0_[26]\,
      DI(1) => \interim_velocity_reg_n_0_[25]\,
      DI(0) => \interim_velocity_reg_n_0_[24]\,
      O(3 downto 0) => velocity2(27 downto 24),
      S(3) => \velocity1_carry__2_i_15_n_0\,
      S(2) => \velocity1_carry__2_i_16_n_0\,
      S(1) => \velocity1_carry__2_i_17_n_0\,
      S(0) => \velocity1_carry__2_i_18_n_0\
    );
\velocity1_carry__2_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[31]\,
      I1 => \^output_velocity\(31),
      O => \velocity1_carry__2_i_11_n_0\
    );
\velocity1_carry__2_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[30]\,
      I1 => \^output_velocity\(30),
      O => \velocity1_carry__2_i_12_n_0\
    );
\velocity1_carry__2_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[29]\,
      I1 => \^output_velocity\(29),
      O => \velocity1_carry__2_i_13_n_0\
    );
\velocity1_carry__2_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[28]\,
      I1 => \^output_velocity\(28),
      O => \velocity1_carry__2_i_14_n_0\
    );
\velocity1_carry__2_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[27]\,
      I1 => \^output_velocity\(27),
      O => \velocity1_carry__2_i_15_n_0\
    );
\velocity1_carry__2_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[26]\,
      I1 => \^output_velocity\(26),
      O => \velocity1_carry__2_i_16_n_0\
    );
\velocity1_carry__2_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[25]\,
      I1 => \^output_velocity\(25),
      O => \velocity1_carry__2_i_17_n_0\
    );
\velocity1_carry__2_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[24]\,
      I1 => \^output_velocity\(24),
      O => \velocity1_carry__2_i_18_n_0\
    );
\velocity1_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(28),
      I1 => velocity2(29),
      O => \velocity1_carry__2_i_2_n_0\
    );
\velocity1_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(26),
      I1 => velocity2(27),
      O => \velocity1_carry__2_i_3_n_0\
    );
\velocity1_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(24),
      I1 => velocity2(25),
      O => \velocity1_carry__2_i_4_n_0\
    );
\velocity1_carry__2_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(30),
      I1 => velocity2(31),
      O => \velocity1_carry__2_i_5_n_0\
    );
\velocity1_carry__2_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(28),
      I1 => velocity2(29),
      O => \velocity1_carry__2_i_6_n_0\
    );
\velocity1_carry__2_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(26),
      I1 => velocity2(27),
      O => \velocity1_carry__2_i_7_n_0\
    );
\velocity1_carry__2_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(24),
      I1 => velocity2(25),
      O => \velocity1_carry__2_i_8_n_0\
    );
\velocity1_carry__2_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__2_i_10_n_0\,
      CO(3) => \velocity1_carry__2_i_9_n_0\,
      CO(2) => \velocity1_carry__2_i_9_n_1\,
      CO(1) => \velocity1_carry__2_i_9_n_2\,
      CO(0) => \velocity1_carry__2_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[31]\,
      DI(2) => \interim_velocity_reg_n_0_[30]\,
      DI(1) => \interim_velocity_reg_n_0_[29]\,
      DI(0) => \interim_velocity_reg_n_0_[28]\,
      O(3 downto 0) => velocity2(31 downto 28),
      S(3) => \velocity1_carry__2_i_11_n_0\,
      S(2) => \velocity1_carry__2_i_12_n_0\,
      S(1) => \velocity1_carry__2_i_13_n_0\,
      S(0) => \velocity1_carry__2_i_14_n_0\
    );
\velocity1_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__2_n_0\,
      CO(3) => \velocity1_carry__3_n_0\,
      CO(2) => \velocity1_carry__3_n_1\,
      CO(1) => \velocity1_carry__3_n_2\,
      CO(0) => \velocity1_carry__3_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__3_i_1_n_0\,
      DI(2) => \velocity1_carry__3_i_2_n_0\,
      DI(1) => \velocity1_carry__3_i_3_n_0\,
      DI(0) => \velocity1_carry__3_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__3_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__3_i_5_n_0\,
      S(2) => \velocity1_carry__3_i_6_n_0\,
      S(1) => \velocity1_carry__3_i_7_n_0\,
      S(0) => \velocity1_carry__3_i_8_n_0\
    );
\velocity1_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(38),
      I1 => velocity2(39),
      O => \velocity1_carry__3_i_1_n_0\
    );
\velocity1_carry__3_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__2_i_9_n_0\,
      CO(3) => \velocity1_carry__3_i_10_n_0\,
      CO(2) => \velocity1_carry__3_i_10_n_1\,
      CO(1) => \velocity1_carry__3_i_10_n_2\,
      CO(0) => \velocity1_carry__3_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[35]\,
      DI(2) => \interim_velocity_reg_n_0_[34]\,
      DI(1) => \interim_velocity_reg_n_0_[33]\,
      DI(0) => \interim_velocity_reg_n_0_[32]\,
      O(3 downto 0) => velocity2(35 downto 32),
      S(3) => \velocity1_carry__3_i_15_n_0\,
      S(2) => \velocity1_carry__3_i_16_n_0\,
      S(1) => \velocity1_carry__3_i_17_n_0\,
      S(0) => \velocity1_carry__3_i_18_n_0\
    );
\velocity1_carry__3_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[39]\,
      O => \velocity1_carry__3_i_11_n_0\
    );
\velocity1_carry__3_i_12\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[38]\,
      O => \velocity1_carry__3_i_12_n_0\
    );
\velocity1_carry__3_i_13\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[37]\,
      O => \velocity1_carry__3_i_13_n_0\
    );
\velocity1_carry__3_i_14\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[36]\,
      O => \velocity1_carry__3_i_14_n_0\
    );
\velocity1_carry__3_i_15\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[35]\,
      O => \velocity1_carry__3_i_15_n_0\
    );
\velocity1_carry__3_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[34]\,
      O => \velocity1_carry__3_i_16_n_0\
    );
\velocity1_carry__3_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[33]\,
      O => \velocity1_carry__3_i_17_n_0\
    );
\velocity1_carry__3_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[32]\,
      O => \velocity1_carry__3_i_18_n_0\
    );
\velocity1_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(36),
      I1 => velocity2(37),
      O => \velocity1_carry__3_i_2_n_0\
    );
\velocity1_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(34),
      I1 => velocity2(35),
      O => \velocity1_carry__3_i_3_n_0\
    );
\velocity1_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(32),
      I1 => velocity2(33),
      O => \velocity1_carry__3_i_4_n_0\
    );
\velocity1_carry__3_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(38),
      I1 => velocity2(39),
      O => \velocity1_carry__3_i_5_n_0\
    );
\velocity1_carry__3_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(36),
      I1 => velocity2(37),
      O => \velocity1_carry__3_i_6_n_0\
    );
\velocity1_carry__3_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(34),
      I1 => velocity2(35),
      O => \velocity1_carry__3_i_7_n_0\
    );
\velocity1_carry__3_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(32),
      I1 => velocity2(33),
      O => \velocity1_carry__3_i_8_n_0\
    );
\velocity1_carry__3_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__3_i_10_n_0\,
      CO(3) => \velocity1_carry__3_i_9_n_0\,
      CO(2) => \velocity1_carry__3_i_9_n_1\,
      CO(1) => \velocity1_carry__3_i_9_n_2\,
      CO(0) => \velocity1_carry__3_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[39]\,
      DI(2) => \interim_velocity_reg_n_0_[38]\,
      DI(1) => \interim_velocity_reg_n_0_[37]\,
      DI(0) => \interim_velocity_reg_n_0_[36]\,
      O(3 downto 0) => velocity2(39 downto 36),
      S(3) => \velocity1_carry__3_i_11_n_0\,
      S(2) => \velocity1_carry__3_i_12_n_0\,
      S(1) => \velocity1_carry__3_i_13_n_0\,
      S(0) => \velocity1_carry__3_i_14_n_0\
    );
\velocity1_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__3_n_0\,
      CO(3) => \velocity1_carry__4_n_0\,
      CO(2) => \velocity1_carry__4_n_1\,
      CO(1) => \velocity1_carry__4_n_2\,
      CO(0) => \velocity1_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__4_i_1_n_0\,
      DI(2) => \velocity1_carry__4_i_2_n_0\,
      DI(1) => \velocity1_carry__4_i_3_n_0\,
      DI(0) => \velocity1_carry__4_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__4_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__4_i_5_n_0\,
      S(2) => \velocity1_carry__4_i_6_n_0\,
      S(1) => \velocity1_carry__4_i_7_n_0\,
      S(0) => \velocity1_carry__4_i_8_n_0\
    );
\velocity1_carry__4_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(46),
      I1 => velocity2(47),
      O => \velocity1_carry__4_i_1_n_0\
    );
\velocity1_carry__4_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__3_i_9_n_0\,
      CO(3) => \velocity1_carry__4_i_10_n_0\,
      CO(2) => \velocity1_carry__4_i_10_n_1\,
      CO(1) => \velocity1_carry__4_i_10_n_2\,
      CO(0) => \velocity1_carry__4_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[41]\,
      DI(0) => \interim_velocity_reg_n_0_[40]\,
      O(3 downto 0) => velocity2(43 downto 40),
      S(3) => \velocity1_carry__4_i_15_n_0\,
      S(2) => \velocity1_carry__4_i_16_n_0\,
      S(1) => \velocity1_carry__4_i_17_n_0\,
      S(0) => \velocity1_carry__4_i_18_n_0\
    );
\velocity1_carry__4_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__4_i_11_n_0\
    );
\velocity1_carry__4_i_12\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__4_i_12_n_0\
    );
\velocity1_carry__4_i_13\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__4_i_13_n_0\
    );
\velocity1_carry__4_i_14\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__4_i_14_n_0\
    );
\velocity1_carry__4_i_15\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__4_i_15_n_0\
    );
\velocity1_carry__4_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__4_i_16_n_0\
    );
\velocity1_carry__4_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[41]\,
      O => \velocity1_carry__4_i_17_n_0\
    );
\velocity1_carry__4_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[40]\,
      O => \velocity1_carry__4_i_18_n_0\
    );
\velocity1_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(44),
      I1 => velocity2(45),
      O => \velocity1_carry__4_i_2_n_0\
    );
\velocity1_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(42),
      I1 => velocity2(43),
      O => \velocity1_carry__4_i_3_n_0\
    );
\velocity1_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(40),
      I1 => velocity2(41),
      O => \velocity1_carry__4_i_4_n_0\
    );
\velocity1_carry__4_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(46),
      I1 => velocity2(47),
      O => \velocity1_carry__4_i_5_n_0\
    );
\velocity1_carry__4_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(44),
      I1 => velocity2(45),
      O => \velocity1_carry__4_i_6_n_0\
    );
\velocity1_carry__4_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(42),
      I1 => velocity2(43),
      O => \velocity1_carry__4_i_7_n_0\
    );
\velocity1_carry__4_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(40),
      I1 => velocity2(41),
      O => \velocity1_carry__4_i_8_n_0\
    );
\velocity1_carry__4_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__4_i_10_n_0\,
      CO(3) => \velocity1_carry__4_i_9_n_0\,
      CO(2) => \velocity1_carry__4_i_9_n_1\,
      CO(1) => \velocity1_carry__4_i_9_n_2\,
      CO(0) => \velocity1_carry__4_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[72]\,
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 0) => velocity2(47 downto 44),
      S(3) => \velocity1_carry__4_i_11_n_0\,
      S(2) => \velocity1_carry__4_i_12_n_0\,
      S(1) => \velocity1_carry__4_i_13_n_0\,
      S(0) => \velocity1_carry__4_i_14_n_0\
    );
\velocity1_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__4_n_0\,
      CO(3) => \velocity1_carry__5_n_0\,
      CO(2) => \velocity1_carry__5_n_1\,
      CO(1) => \velocity1_carry__5_n_2\,
      CO(0) => \velocity1_carry__5_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__5_i_1_n_0\,
      DI(2) => \velocity1_carry__5_i_2_n_0\,
      DI(1) => \velocity1_carry__5_i_3_n_0\,
      DI(0) => \velocity1_carry__5_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__5_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__5_i_5_n_0\,
      S(2) => \velocity1_carry__5_i_6_n_0\,
      S(1) => \velocity1_carry__5_i_7_n_0\,
      S(0) => \velocity1_carry__5_i_8_n_0\
    );
\velocity1_carry__5_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(54),
      I1 => velocity2(55),
      O => \velocity1_carry__5_i_1_n_0\
    );
\velocity1_carry__5_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__4_i_9_n_0\,
      CO(3) => \velocity1_carry__5_i_10_n_0\,
      CO(2) => \velocity1_carry__5_i_10_n_1\,
      CO(1) => \velocity1_carry__5_i_10_n_2\,
      CO(0) => \velocity1_carry__5_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[72]\,
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 0) => velocity2(51 downto 48),
      S(3) => \velocity1_carry__5_i_15_n_0\,
      S(2) => \velocity1_carry__5_i_16_n_0\,
      S(1) => \velocity1_carry__5_i_17_n_0\,
      S(0) => \velocity1_carry__5_i_18_n_0\
    );
\velocity1_carry__5_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_11_n_0\
    );
\velocity1_carry__5_i_12\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_12_n_0\
    );
\velocity1_carry__5_i_13\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_13_n_0\
    );
\velocity1_carry__5_i_14\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_14_n_0\
    );
\velocity1_carry__5_i_15\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_15_n_0\
    );
\velocity1_carry__5_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_16_n_0\
    );
\velocity1_carry__5_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_17_n_0\
    );
\velocity1_carry__5_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__5_i_18_n_0\
    );
\velocity1_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(52),
      I1 => velocity2(53),
      O => \velocity1_carry__5_i_2_n_0\
    );
\velocity1_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(50),
      I1 => velocity2(51),
      O => \velocity1_carry__5_i_3_n_0\
    );
\velocity1_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(48),
      I1 => velocity2(49),
      O => \velocity1_carry__5_i_4_n_0\
    );
\velocity1_carry__5_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(54),
      I1 => velocity2(55),
      O => \velocity1_carry__5_i_5_n_0\
    );
\velocity1_carry__5_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(52),
      I1 => velocity2(53),
      O => \velocity1_carry__5_i_6_n_0\
    );
\velocity1_carry__5_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(50),
      I1 => velocity2(51),
      O => \velocity1_carry__5_i_7_n_0\
    );
\velocity1_carry__5_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(48),
      I1 => velocity2(49),
      O => \velocity1_carry__5_i_8_n_0\
    );
\velocity1_carry__5_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__5_i_10_n_0\,
      CO(3) => \velocity1_carry__5_i_9_n_0\,
      CO(2) => \velocity1_carry__5_i_9_n_1\,
      CO(1) => \velocity1_carry__5_i_9_n_2\,
      CO(0) => \velocity1_carry__5_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[72]\,
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 0) => velocity2(55 downto 52),
      S(3) => \velocity1_carry__5_i_11_n_0\,
      S(2) => \velocity1_carry__5_i_12_n_0\,
      S(1) => \velocity1_carry__5_i_13_n_0\,
      S(0) => \velocity1_carry__5_i_14_n_0\
    );
\velocity1_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__5_n_0\,
      CO(3) => \velocity1_carry__6_n_0\,
      CO(2) => \velocity1_carry__6_n_1\,
      CO(1) => \velocity1_carry__6_n_2\,
      CO(0) => \velocity1_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__6_i_1_n_0\,
      DI(2) => \velocity1_carry__6_i_2_n_0\,
      DI(1) => \velocity1_carry__6_i_3_n_0\,
      DI(0) => \velocity1_carry__6_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__6_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__6_i_5_n_0\,
      S(2) => \velocity1_carry__6_i_6_n_0\,
      S(1) => \velocity1_carry__6_i_7_n_0\,
      S(0) => \velocity1_carry__6_i_8_n_0\
    );
\velocity1_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(62),
      I1 => velocity2(63),
      O => \velocity1_carry__6_i_1_n_0\
    );
\velocity1_carry__6_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__5_i_9_n_0\,
      CO(3) => \velocity1_carry__6_i_10_n_0\,
      CO(2) => \velocity1_carry__6_i_10_n_1\,
      CO(1) => \velocity1_carry__6_i_10_n_2\,
      CO(0) => \velocity1_carry__6_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[72]\,
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 0) => velocity2(59 downto 56),
      S(3) => \velocity1_carry__6_i_15_n_0\,
      S(2) => \velocity1_carry__6_i_16_n_0\,
      S(1) => \velocity1_carry__6_i_17_n_0\,
      S(0) => \velocity1_carry__6_i_18_n_0\
    );
\velocity1_carry__6_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_11_n_0\
    );
\velocity1_carry__6_i_12\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_12_n_0\
    );
\velocity1_carry__6_i_13\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_13_n_0\
    );
\velocity1_carry__6_i_14\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_14_n_0\
    );
\velocity1_carry__6_i_15\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_15_n_0\
    );
\velocity1_carry__6_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_16_n_0\
    );
\velocity1_carry__6_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_17_n_0\
    );
\velocity1_carry__6_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__6_i_18_n_0\
    );
\velocity1_carry__6_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(60),
      I1 => velocity2(61),
      O => \velocity1_carry__6_i_2_n_0\
    );
\velocity1_carry__6_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(58),
      I1 => velocity2(59),
      O => \velocity1_carry__6_i_3_n_0\
    );
\velocity1_carry__6_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(56),
      I1 => velocity2(57),
      O => \velocity1_carry__6_i_4_n_0\
    );
\velocity1_carry__6_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(62),
      I1 => velocity2(63),
      O => \velocity1_carry__6_i_5_n_0\
    );
\velocity1_carry__6_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(60),
      I1 => velocity2(61),
      O => \velocity1_carry__6_i_6_n_0\
    );
\velocity1_carry__6_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(58),
      I1 => velocity2(59),
      O => \velocity1_carry__6_i_7_n_0\
    );
\velocity1_carry__6_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(56),
      I1 => velocity2(57),
      O => \velocity1_carry__6_i_8_n_0\
    );
\velocity1_carry__6_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__6_i_10_n_0\,
      CO(3) => \velocity1_carry__6_i_9_n_0\,
      CO(2) => \velocity1_carry__6_i_9_n_1\,
      CO(1) => \velocity1_carry__6_i_9_n_2\,
      CO(0) => \velocity1_carry__6_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[72]\,
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 0) => velocity2(63 downto 60),
      S(3) => \velocity1_carry__6_i_11_n_0\,
      S(2) => \velocity1_carry__6_i_12_n_0\,
      S(1) => \velocity1_carry__6_i_13_n_0\,
      S(0) => \velocity1_carry__6_i_14_n_0\
    );
\velocity1_carry__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__6_n_0\,
      CO(3) => \velocity1_carry__7_n_0\,
      CO(2) => \velocity1_carry__7_n_1\,
      CO(1) => \velocity1_carry__7_n_2\,
      CO(0) => \velocity1_carry__7_n_3\,
      CYINIT => '0',
      DI(3) => \velocity1_carry__7_i_1_n_0\,
      DI(2) => \velocity1_carry__7_i_2_n_0\,
      DI(1) => \velocity1_carry__7_i_3_n_0\,
      DI(0) => \velocity1_carry__7_i_4_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__7_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity1_carry__7_i_5_n_0\,
      S(2) => \velocity1_carry__7_i_6_n_0\,
      S(1) => \velocity1_carry__7_i_7_n_0\,
      S(0) => \velocity1_carry__7_i_8_n_0\
    );
\velocity1_carry__7_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(70),
      I1 => velocity2(71),
      O => \velocity1_carry__7_i_1_n_0\
    );
\velocity1_carry__7_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__6_i_9_n_0\,
      CO(3) => \velocity1_carry__7_i_10_n_0\,
      CO(2) => \velocity1_carry__7_i_10_n_1\,
      CO(1) => \velocity1_carry__7_i_10_n_2\,
      CO(0) => \velocity1_carry__7_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[72]\,
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 0) => velocity2(67 downto 64),
      S(3) => \velocity1_carry__7_i_15_n_0\,
      S(2) => \velocity1_carry__7_i_16_n_0\,
      S(1) => \velocity1_carry__7_i_17_n_0\,
      S(0) => \velocity1_carry__7_i_18_n_0\
    );
\velocity1_carry__7_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_11_n_0\
    );
\velocity1_carry__7_i_12\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_12_n_0\
    );
\velocity1_carry__7_i_13\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_13_n_0\
    );
\velocity1_carry__7_i_14\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_14_n_0\
    );
\velocity1_carry__7_i_15\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_15_n_0\
    );
\velocity1_carry__7_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_16_n_0\
    );
\velocity1_carry__7_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_17_n_0\
    );
\velocity1_carry__7_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__7_i_18_n_0\
    );
\velocity1_carry__7_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(68),
      I1 => velocity2(69),
      O => \velocity1_carry__7_i_2_n_0\
    );
\velocity1_carry__7_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(66),
      I1 => velocity2(67),
      O => \velocity1_carry__7_i_3_n_0\
    );
\velocity1_carry__7_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(64),
      I1 => velocity2(65),
      O => \velocity1_carry__7_i_4_n_0\
    );
\velocity1_carry__7_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(70),
      I1 => velocity2(71),
      O => \velocity1_carry__7_i_5_n_0\
    );
\velocity1_carry__7_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(68),
      I1 => velocity2(69),
      O => \velocity1_carry__7_i_6_n_0\
    );
\velocity1_carry__7_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(66),
      I1 => velocity2(67),
      O => \velocity1_carry__7_i_7_n_0\
    );
\velocity1_carry__7_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(64),
      I1 => velocity2(65),
      O => \velocity1_carry__7_i_8_n_0\
    );
\velocity1_carry__7_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__7_i_10_n_0\,
      CO(3) => \velocity1_carry__7_i_9_n_0\,
      CO(2) => \velocity1_carry__7_i_9_n_1\,
      CO(1) => \velocity1_carry__7_i_9_n_2\,
      CO(0) => \velocity1_carry__7_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[72]\,
      DI(2) => \interim_velocity_reg_n_0_[72]\,
      DI(1) => \interim_velocity_reg_n_0_[72]\,
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 0) => velocity2(71 downto 68),
      S(3) => \velocity1_carry__7_i_11_n_0\,
      S(2) => \velocity1_carry__7_i_12_n_0\,
      S(1) => \velocity1_carry__7_i_13_n_0\,
      S(0) => \velocity1_carry__7_i_14_n_0\
    );
\velocity1_carry__8\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__7_n_0\,
      CO(3 downto 1) => \NLW_velocity1_carry__8_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \velocity1_carry__8_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \velocity1_carry__8_i_1_n_0\,
      O(3 downto 0) => \NLW_velocity1_carry__8_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \velocity1_carry__8_i_2_n_0\
    );
\velocity1_carry__8_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(72),
      I1 => velocity2(73),
      O => \velocity1_carry__8_i_1_n_0\
    );
\velocity1_carry__8_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(72),
      I1 => velocity2(73),
      O => \velocity1_carry__8_i_2_n_0\
    );
\velocity1_carry__8_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_carry__7_i_9_n_0\,
      CO(3 downto 1) => \NLW_velocity1_carry__8_i_3_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \velocity1_carry__8_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \interim_velocity_reg_n_0_[72]\,
      O(3 downto 2) => \NLW_velocity1_carry__8_i_3_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => velocity2(73 downto 72),
      S(3 downto 2) => B"00",
      S(1) => \velocity1_carry__8_i_4_n_0\,
      S(0) => \velocity1_carry__8_i_5_n_0\
    );
\velocity1_carry__8_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__8_i_4_n_0\
    );
\velocity1_carry__8_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[72]\,
      O => \velocity1_carry__8_i_5_n_0\
    );
velocity1_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(6),
      I1 => velocity2(7),
      O => velocity1_carry_i_1_n_0
    );
velocity1_carry_i_10: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[7]\,
      I1 => \^output_velocity\(7),
      O => velocity1_carry_i_10_n_0
    );
velocity1_carry_i_11: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[6]\,
      I1 => \^output_velocity\(6),
      O => velocity1_carry_i_11_n_0
    );
velocity1_carry_i_12: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[5]\,
      I1 => \^output_velocity\(5),
      O => velocity1_carry_i_12_n_0
    );
velocity1_carry_i_13: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[4]\,
      I1 => \^output_velocity\(4),
      O => velocity1_carry_i_13_n_0
    );
velocity1_carry_i_14: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[3]\,
      I1 => \^output_velocity\(3),
      O => velocity1_carry_i_14_n_0
    );
velocity1_carry_i_15: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[2]\,
      I1 => \^output_velocity\(2),
      O => velocity1_carry_i_15_n_0
    );
velocity1_carry_i_16: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[1]\,
      I1 => \^output_velocity\(1),
      O => velocity1_carry_i_16_n_0
    );
velocity1_carry_i_17: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \interim_velocity_reg_n_0_[0]\,
      I1 => \^output_velocity\(0),
      O => velocity1_carry_i_17_n_0
    );
velocity1_carry_i_2: unisim.vcomponents.CARRY4
     port map (
      CI => velocity1_carry_i_9_n_0,
      CO(3) => velocity1_carry_i_2_n_0,
      CO(2) => velocity1_carry_i_2_n_1,
      CO(1) => velocity1_carry_i_2_n_2,
      CO(0) => velocity1_carry_i_2_n_3,
      CYINIT => '0',
      DI(3) => \interim_velocity_reg_n_0_[7]\,
      DI(2) => \interim_velocity_reg_n_0_[6]\,
      DI(1) => \interim_velocity_reg_n_0_[5]\,
      DI(0) => \interim_velocity_reg_n_0_[4]\,
      O(3 downto 0) => velocity2(7 downto 4),
      S(3) => velocity1_carry_i_10_n_0,
      S(2) => velocity1_carry_i_11_n_0,
      S(1) => velocity1_carry_i_12_n_0,
      S(0) => velocity1_carry_i_13_n_0
    );
velocity1_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(2),
      I1 => velocity2(3),
      O => velocity1_carry_i_3_n_0
    );
velocity1_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => velocity2(0),
      I1 => velocity2(1),
      O => velocity1_carry_i_4_n_0
    );
velocity1_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(6),
      I1 => velocity2(7),
      O => velocity1_carry_i_5_n_0
    );
velocity1_carry_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => velocity2(4),
      I1 => velocity2(5),
      O => velocity1_carry_i_6_n_0
    );
velocity1_carry_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(2),
      I1 => velocity2(3),
      O => velocity1_carry_i_7_n_0
    );
velocity1_carry_i_8: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => velocity2(0),
      I1 => velocity2(1),
      O => velocity1_carry_i_8_n_0
    );
velocity1_carry_i_9: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => velocity1_carry_i_9_n_0,
      CO(2) => velocity1_carry_i_9_n_1,
      CO(1) => velocity1_carry_i_9_n_2,
      CO(0) => velocity1_carry_i_9_n_3,
      CYINIT => '1',
      DI(3) => \interim_velocity_reg_n_0_[3]\,
      DI(2) => \interim_velocity_reg_n_0_[2]\,
      DI(1) => \interim_velocity_reg_n_0_[1]\,
      DI(0) => \interim_velocity_reg_n_0_[0]\,
      O(3 downto 0) => velocity2(3 downto 0),
      S(3) => velocity1_carry_i_14_n_0,
      S(2) => velocity1_carry_i_15_n_0,
      S(1) => velocity1_carry_i_16_n_0,
      S(0) => velocity1_carry_i_17_n_0
    );
\velocity1_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \velocity1_inferred__0/i__carry_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \i__carry_i_1__7_n_0\,
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_2__7_n_0\,
      S(2) => \i__carry_i_3__7_n_0\,
      S(1) => \i__carry_i_4__7_n_0\,
      S(0) => \i__carry_i_5__7_n_0\
    );
\velocity1_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__0_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__0_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__0_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_1__6_n_0\,
      S(2) => \i__carry_i_2__6_n_0\,
      S(1) => \i__carry_i_3__6_n_0\,
      S(0) => \i__carry_i_4__6_n_0\
    );
\velocity1_inferred__0/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__0_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__1_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__1_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__1_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_1__5_n_0\,
      S(2) => \i__carry_i_2__5_n_0\,
      S(1) => \i__carry_i_3__5_n_0\,
      S(0) => \i__carry_i_4__5_n_0\
    );
\velocity1_inferred__0/i__carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__1_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__2_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__2_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__2_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__2_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_1__4_n_0\,
      S(2) => \i__carry_i_2__4_n_0\,
      S(1) => \i__carry_i_3__4_n_0\,
      S(0) => \i__carry_i_4__4_n_0\
    );
\velocity1_inferred__0/i__carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__2_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__3_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__3_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__3_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__3_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_1__3_n_0\,
      S(2) => \i__carry_i_2__3_n_0\,
      S(1) => \i__carry_i_3__3_n_0\,
      S(0) => \i__carry_i_4__3_n_0\
    );
\velocity1_inferred__0/i__carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__3_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__4_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__4_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__4_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__4_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_1__2_n_0\,
      S(2) => \i__carry_i_2__2_n_0\,
      S(1) => \i__carry_i_3__2_n_0\,
      S(0) => \i__carry_i_4__2_n_0\
    );
\velocity1_inferred__0/i__carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__4_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__5_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__5_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__5_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__5_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_1__1_n_0\,
      S(2) => \i__carry_i_2__1_n_0\,
      S(1) => \i__carry_i_3__1_n_0\,
      S(0) => \i__carry_i_4__1_n_0\
    );
\velocity1_inferred__0/i__carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__5_n_0\,
      CO(3) => \velocity1_inferred__0/i__carry__6_n_0\,
      CO(2) => \velocity1_inferred__0/i__carry__6_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__6_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__6_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_1__0_n_0\,
      S(2) => \i__carry_i_2__0_n_0\,
      S(1) => \i__carry_i_3__0_n_0\,
      S(0) => \i__carry_i_4__0_n_0\
    );
\velocity1_inferred__0/i__carry__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity1_inferred__0/i__carry__6_n_0\,
      CO(3) => \NLW_velocity1_inferred__0/i__carry__7_CO_UNCONNECTED\(3),
      CO(2) => \velocity1_inferred__0/i__carry__7_n_1\,
      CO(1) => \velocity1_inferred__0/i__carry__7_n_2\,
      CO(0) => \velocity1_inferred__0/i__carry__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_velocity1_inferred__0/i__carry__7_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \i__carry_i_1_n_0\,
      S(1) => \i__carry_i_2_n_0\,
      S(0) => \i__carry_i_3_n_0\
    );
\velocity[31]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \velocity1_inferred__0/i__carry__7_n_1\,
      I1 => \velocity1_carry__8_n_3\,
      O => \velocity[31]_i_1_n_0\
    );
\velocity_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[0]\,
      Q => \^output_velocity\(0),
      R => '0'
    );
\velocity_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[10]\,
      Q => \^output_velocity\(10),
      R => '0'
    );
\velocity_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[11]\,
      Q => \^output_velocity\(11),
      R => '0'
    );
\velocity_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[12]\,
      Q => \^output_velocity\(12),
      R => '0'
    );
\velocity_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[13]\,
      Q => \^output_velocity\(13),
      R => '0'
    );
\velocity_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[14]\,
      Q => \^output_velocity\(14),
      R => '0'
    );
\velocity_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[15]\,
      Q => \^output_velocity\(15),
      R => '0'
    );
\velocity_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[16]\,
      Q => \^output_velocity\(16),
      R => '0'
    );
\velocity_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[17]\,
      Q => \^output_velocity\(17),
      R => '0'
    );
\velocity_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[18]\,
      Q => \^output_velocity\(18),
      R => '0'
    );
\velocity_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[19]\,
      Q => \^output_velocity\(19),
      R => '0'
    );
\velocity_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[1]\,
      Q => \^output_velocity\(1),
      R => '0'
    );
\velocity_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[20]\,
      Q => \^output_velocity\(20),
      R => '0'
    );
\velocity_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[21]\,
      Q => \^output_velocity\(21),
      R => '0'
    );
\velocity_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[22]\,
      Q => \^output_velocity\(22),
      R => '0'
    );
\velocity_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[23]\,
      Q => \^output_velocity\(23),
      R => '0'
    );
\velocity_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[24]\,
      Q => \^output_velocity\(24),
      R => '0'
    );
\velocity_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[25]\,
      Q => \^output_velocity\(25),
      R => '0'
    );
\velocity_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[26]\,
      Q => \^output_velocity\(26),
      R => '0'
    );
\velocity_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[27]\,
      Q => \^output_velocity\(27),
      R => '0'
    );
\velocity_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[28]\,
      Q => \^output_velocity\(28),
      R => '0'
    );
\velocity_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[29]\,
      Q => \^output_velocity\(29),
      R => '0'
    );
\velocity_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[2]\,
      Q => \^output_velocity\(2),
      R => '0'
    );
\velocity_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[30]\,
      Q => \^output_velocity\(30),
      R => '0'
    );
\velocity_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[31]\,
      Q => \^output_velocity\(31),
      R => '0'
    );
\velocity_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[3]\,
      Q => \^output_velocity\(3),
      R => '0'
    );
\velocity_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[4]\,
      Q => \^output_velocity\(4),
      R => '0'
    );
\velocity_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[5]\,
      Q => \^output_velocity\(5),
      R => '0'
    );
\velocity_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[6]\,
      Q => \^output_velocity\(6),
      R => '0'
    );
\velocity_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[7]\,
      Q => \^output_velocity\(7),
      R => '0'
    );
\velocity_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[8]\,
      Q => \^output_velocity\(8),
      R => '0'
    );
\velocity_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity[31]_i_1_n_0\,
      D => \interim_velocity_reg_n_0_[9]\,
      Q => \^output_velocity\(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    target_angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    new_target_angle_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "pid_compressed_pid_calc_0_0,pid_calc,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "pid_calc,Vivado 2021.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_compressed_clock_0, INSERT_VIP 0";
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_pid_calc
     port map (
      angle(31 downto 0) => angle(31 downto 0),
      clock(0) => clock(0),
      kd(8 downto 0) => kd(8 downto 0),
      ki(8 downto 0) => ki(8 downto 0),
      kp(8 downto 0) => kp(8 downto 0),
      new_target_angle_available(0) => new_target_angle_available(0),
      new_velocity_available(0) => new_velocity_available(0),
      output_velocity(31 downto 0) => output_velocity(31 downto 0),
      target_angle(31 downto 0) => target_angle(31 downto 0)
    );
end STRUCTURE;
