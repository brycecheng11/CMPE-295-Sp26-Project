`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/25/2026 12:01:55 AM
// Design Name: 
// Module Name: pid_calc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pid_calc(
    input            [0:0]  clock,
    input   signed  [31:0]  angle,
    
    input   signed  [31:0]  target_angle, 
    input            [0:0]  new_target_angle_available,
    
    input   signed   [8:0]  kp,
    input   signed   [8:0]  ki,
    input   signed   [8:0]  kd,
    
    output  signed  [31:0]  output_velocity
    
    );
    
    // pre calculation registers 
    reg     signed  [31:0]  error;
    reg     signed  [31:0]  error_prev;
    reg     signed  [31:0]  integral; 
    reg     signed  [31:0]  integral_prev; 
    reg     signed  [31:0]  derivative;
    reg     signed  [31:0]  saved_target_angle; 
    // term calculation registers 
    reg     signed  [31:0]  p_term; 
    reg     signed  [31:0]  i_term; 
    reg     signed  [31:0]  d_term; 
    // velocity calculation registers 
    reg     signed  [31:0]  interim_velocity; 
    reg     signed  [31:0]  velocity; 
    
    
    // wire assignments 
    assign output_velocity = velocity; 
    
    // initialization 
    initial begin 
        error <= 0; 
        error_prev <= 0; 
        integral <= 0; 
        integral_prev <= 0; 
        derivative <= 0; 
        saved_target_angle <= 0; 
        p_term <= 0; 
        i_term <= 0; 
        d_term <= 0; 
        interim_velocity <= 0;
        velocity <= 0; 
    end
    
    always @(posedge clock) begin 
        // initial math 
        if (new_target_angle_available == 1) begin 
            saved_target_angle <= target_angle; 
            integral <= 0;
            error <= saved_target_angle - angle; 
        end 
        else begin 
            error <= saved_target_angle - angle; 
            integral <= integral_prev + error * 200e-3; 
        end 
        derivative <= (error - error_prev) / 200e-3; 
        error_prev <= error; 
        integral_prev <= integral; 
    
        // term calculation 
        p_term <= ((kp * error) >>> 10); 
        i_term <= ((ki * integral) >>> 10); 
        d_term <= ((kd * derivative) >>> 10); 
        
        // velocity calculation 
        interim_velocity <= p_term + i_term + d_term; 
        if (velocity != interim_velocity) begin 
            velocity <= interim_velocity; 
        end 
    
    end 
    
    
endmodule
