`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 04:59:40 PM
// Design Name: 
// Module Name: initial_math
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module initial_math(
    input            [0:0]  clock,
    input   signed  [31:0]  angle,
//    input            [0:0]  new_angle_available,
    input   signed  [31:0]  target_angle, 
    input            [0:0]  new_target_angle_available,
//    input    [0:0]  new_target_velocity_available,
//    input   [31:0]  target_velocity,
//    input   [31:0]  velocity_in,
    
    input   signed  [63:0]  dt,
    input   signed  [31:0]  error_in,
    input   signed  [31:0]  integral_in,
    
    output  signed  [31:0]  error_out,
    output  signed  [31:0]  integral_out, 
    output  signed  [31:0]  derivative_out
    );
    
    reg     signed  [31:0]  error;
    reg     signed  [31:0]  integral; 
    reg     signed  [31:0]  derivative;
    
    reg     signed  [31:0]  saved_target_angle; 
    
    assign error_out = error; 
    assign integral_out = integral; 
    assign derivative_out = derivative; 
    
    initial begin 
        error <= 0; 
        integral <= 0; 
        derivative <= 0; 
        saved_target_angle <= target_angle;
    end 
    
    always @ (posedge clock) begin 
//        error = target_velocity - velocity_in; 
        if (new_target_angle_available == 1) begin 
            saved_target_angle <= target_angle; 
            integral <= 0;
            error <= saved_target_angle - angle; 
        end 
        else begin 
            error <= saved_target_angle - angle; 
            integral <= integral_in + error * dt; 
        end 
        if (dt == 0) begin 
            derivative <= 0;
        end 
        else begin 
            derivative <= (error - error_in) / dt; 
        end 
    end
    
    
    
endmodule
