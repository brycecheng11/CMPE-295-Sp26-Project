`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 04:59:40 PM
// Design Name: 
// Module Name: term_calculation
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module term_calculation(
    input            [0:0]  clock, 
    input   signed  [31:0]  error,
    input   signed  [31:0]  integral, 
    input   signed  [31:0]  derivative, 
    
    input   signed   [8:0]  kp,
    input   signed   [8:0]  ki,
    input   signed   [8:0]  kd,

    output          [31:0]  p_term, 
    output          [31:0]  i_term,
    output          [31:0]  d_term
    );
    
    reg     signed  [31:0]  p_term_interim; 
    reg     signed  [31:0]  i_term_interim; 
    reg     signed  [31:0]  d_term_interim; 
    
    assign p_term = p_term_interim; 
    assign i_term = i_term_interim; 
    assign d_term = d_term_interim;
    
    initial begin 
        p_term_interim <= 0; 
        i_term_interim <= 0; 
        d_term_interim <= 0; 
    end
    
    always @ (posedge clock) begin 
        p_term_interim <= ((kp * error) >>> 10); 
        i_term_interim <= ((ki * integral) >>> 10); 
        d_term_interim <= ((kd * derivative) >>> 10); 
        
    end
    
endmodule
