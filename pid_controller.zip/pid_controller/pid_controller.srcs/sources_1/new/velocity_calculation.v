`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 07:39:45 PM
// Design Name: 
// Module Name: velocity_calculation
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module velocity_calculation(
    input            [0:0]  clock,
    input   signed  [31:0]  p_term,
    input   signed  [31:0]  i_term,
    input   signed  [31:0]  d_term,
    output  signed  [31:0]  output_velocity,
    output           [0:0]  new_velocity_available
    );
    
    reg     signed  [31:0]  interim; 
    reg     signed  [31:0]  velocity; 
    reg              [0:0]  new_velocity; 
    
    assign output_velocity = velocity; 
    assign new_velocity_available = new_velocity; 
    
    initial begin 
        interim = 0; 
        velocity = 0; 
        new_velocity = 0; 
    end 
    
    always @(posedge clock) begin 
        interim <= p_term + i_term + d_term; 
        if (velocity != interim) begin 
            velocity <= interim; 
            new_velocity <= 1'b1; 
        end 
        else begin 
            new_velocity <= 1'b0; 
        end
    
   end 
    
endmodule
