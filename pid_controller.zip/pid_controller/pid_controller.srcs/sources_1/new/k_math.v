`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 07:13:18 PM
// Design Name: 
// Module Name: k_math
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module k_math(
    input            [0:0]  clock,
    input           [11:0]  kp_in,
    input           [11:0]  ki_in,
    input           [11:0]  kd_in,
    output  signed   [8:0]  kp_out,
    output  signed   [8:0]  ki_out,
    output  signed   [8:0]  kd_out 
    );
    
    reg     signed   [8:0]  kp_signed; 
    reg     signed   [8:0]  ki_signed; 
    reg     signed   [8:0]  kd_signed; 
    
    assign kp_out = kp_signed; 
    assign ki_out = ki_signed; 
    assign kd_out = kd_signed; 
    
    always @ (posedge clock) begin 
        kp_signed <= $signed({1'b0, (kp_in >> 4)});  
        ki_signed <= $signed({1'b0, (ki_in >> 4)});  
        kd_signed <= $signed({1'b0, (kd_in >> 4)}); 
    end
    
    
endmodule
