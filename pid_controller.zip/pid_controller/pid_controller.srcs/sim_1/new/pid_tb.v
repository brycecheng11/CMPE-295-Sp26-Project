`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/16/2026 07:53:54 PM
// Design Name: 
// Module Name: pid_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pid_tb;

    // Testbench Inputs (Registers) matching design_1 ports
    reg [31:0] angle_0;
    reg [11:0] k_d_0;
    reg [11:0] k_i_0;
    reg [11:0] k_p_0;
    reg [0:0]  new_target_angle_available_0;
    reg        reset_rtl;
    reg        sys_clock;
    reg [31:0] target_angle_0;
    reg [63:0] time_curr_0;

    // Testbench Outputs (Wires)
    wire [0:0]  new_velocity_available_0;
    wire [31:0] output_velocity_0;

    // Instantiate the Unit Under Test (UUT)
    design_1 uut (
        .angle_0(angle_0),
        .k_d_0(k_d_0),
        .k_i_0(k_i_0),
        .k_p_0(k_p_0),
        .new_target_angle_available_0(new_target_angle_available_0),
        .new_velocity_available_0(new_velocity_available_0),
        .output_velocity_0(output_velocity_0),
        .reset_rtl(reset_rtl),
        .sys_clock(sys_clock),
        .target_angle_0(target_angle_0),
        .time_curr_0(time_curr_0)
    );

    // Clock Generation for 125 MHz (Period = 8000 ps = 8 ns)
    always #4000 sys_clock = ~sys_clock;

    // Stimulus Sequence
    initial begin
        // Initialize Signals
        sys_clock = 0;
        reset_rtl = 1;            // Active-high reset as defined in design wrapper
        angle_0 = 32'd0;
        target_angle_0 = 32'd0;
        k_p_0 = 12'd100;          // Sample Proportional gain
        k_i_0 = 12'd10;           // Sample Integral gain
        k_d_0 = 12'd25;           // Sample Derivative gain
        new_target_angle_available_0 = 1'b0;
        time_curr_0 = 64'd0;

        // Hold reset for 50 ns (50000 ps)
        #50000;
        reset_rtl = 0;            // Release reset
        #20000;

        // 1. Set a Target Angle
        @(posedge sys_clock);
        target_angle_0 = 32'sd90; // Target: 90 degrees
        new_target_angle_available_0 = 1'b1;
        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b0;

        // 2. Simulate incoming sensor readings (angle updates over time)
        repeat (15) begin
            #50000; // Wait 50 ns between sensor updates
            
            // Increment time (e.g., by 50,000 ps / 50 ms step)
            time_curr_0 = time_curr_0 + 64'd50000; 

            // Mock plant behavior: move current angle closer to target
            if (angle_0 < target_angle_0)
                angle_0 = angle_0 + 32'sd5;
        end

        // 3. Change Target Angle dynamically
        @(posedge sys_clock);
        target_angle_0 = 32'sd30; // New Target: 30 degrees
        new_target_angle_available_0 = 1'b1;
        @(posedge sys_clock);
        new_target_angle_available_0 = 1'b0;

        // 4. Continue feeding angle updates
        repeat (15) begin
            #10000;
            time_curr_0 = time_curr_0 + 64'd50000;

            if (angle_0 > target_angle_0)
                angle_0 = angle_0 - 32'sd4;

        end

        // Finish simulation
        #100000;
        $finish;
    end

    // Monitor to print activity to the simulation console
    initial begin
        $monitor("Time=%0t ps | CurrentTime=%0d | Target=%0d | Angle=%0d | VelAvail=%b | OutputVel=%0d", 
                 $time, time_curr_0, target_angle_0, angle_0, new_velocity_available_0, output_velocity_0);
    end

endmodule
