// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep 21 22:23:07 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top design_1_term_calculation_0_1 -prefix
//               design_1_term_calculation_0_1_ design_1_term_calculation_0_1_sim_netlist.v
// Design      : design_1_term_calculation_0_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_term_calculation_0_1,term_calculation,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "term_calculation,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module design_1_term_calculation_0_1
   (clock,
    error,
    integral,
    derivative,
    kp,
    ki,
    kd,
    p_term,
    i_term,
    d_term);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN design_1_sys_clock, INSERT_VIP 0" *) input [0:0]clock;
  input [31:0]error;
  input [31:0]integral;
  input [31:0]derivative;
  input [8:0]kp;
  input [8:0]ki;
  input [8:0]kd;
  output [31:0]p_term;
  output [31:0]i_term;
  output [31:0]d_term;

  wire \<const0> ;
  wire [0:0]clock;
  wire [21:0]\^d_term ;
  wire [31:0]derivative;
  wire [31:0]error;
  wire [21:0]\^i_term ;
  wire [31:0]integral;
  wire [8:0]kd;
  wire [8:0]ki;
  wire [8:0]kp;
  wire [21:0]\^p_term ;

  assign d_term[31] = \<const0> ;
  assign d_term[30] = \<const0> ;
  assign d_term[29] = \<const0> ;
  assign d_term[28] = \<const0> ;
  assign d_term[27] = \<const0> ;
  assign d_term[26] = \<const0> ;
  assign d_term[25] = \<const0> ;
  assign d_term[24] = \<const0> ;
  assign d_term[23] = \<const0> ;
  assign d_term[22] = \<const0> ;
  assign d_term[21:0] = \^d_term [21:0];
  assign i_term[31] = \<const0> ;
  assign i_term[30] = \<const0> ;
  assign i_term[29] = \<const0> ;
  assign i_term[28] = \<const0> ;
  assign i_term[27] = \<const0> ;
  assign i_term[26] = \<const0> ;
  assign i_term[25] = \<const0> ;
  assign i_term[24] = \<const0> ;
  assign i_term[23] = \<const0> ;
  assign i_term[22] = \<const0> ;
  assign i_term[21:0] = \^i_term [21:0];
  assign p_term[31] = \<const0> ;
  assign p_term[30] = \<const0> ;
  assign p_term[29] = \<const0> ;
  assign p_term[28] = \<const0> ;
  assign p_term[27] = \<const0> ;
  assign p_term[26] = \<const0> ;
  assign p_term[25] = \<const0> ;
  assign p_term[24] = \<const0> ;
  assign p_term[23] = \<const0> ;
  assign p_term[22] = \<const0> ;
  assign p_term[21:0] = \^p_term [21:0];
  GND GND
       (.G(\<const0> ));
  design_1_term_calculation_0_1_term_calculation inst
       (.clock(clock),
        .d_term(\^d_term ),
        .derivative(derivative),
        .error(error),
        .i_term(\^i_term ),
        .integral(integral),
        .kd(kd),
        .ki(ki),
        .kp(kp),
        .p_term(\^p_term ));
endmodule

module design_1_term_calculation_0_1_term_calculation
   (p_term,
    i_term,
    d_term,
    kp,
    error,
    clock,
    ki,
    integral,
    kd,
    derivative);
  output [21:0]p_term;
  output [21:0]i_term;
  output [21:0]d_term;
  input [8:0]kp;
  input [31:0]error;
  input [0:0]clock;
  input [8:0]ki;
  input [31:0]integral;
  input [8:0]kd;
  input [31:0]derivative;

  wire [0:0]clock;
  wire [21:0]d_term;
  wire d_term1_n_100;
  wire d_term1_n_101;
  wire d_term1_n_102;
  wire d_term1_n_103;
  wire d_term1_n_104;
  wire d_term1_n_105;
  wire d_term1_n_106;
  wire d_term1_n_107;
  wire d_term1_n_108;
  wire d_term1_n_109;
  wire d_term1_n_110;
  wire d_term1_n_111;
  wire d_term1_n_112;
  wire d_term1_n_113;
  wire d_term1_n_114;
  wire d_term1_n_115;
  wire d_term1_n_116;
  wire d_term1_n_117;
  wire d_term1_n_118;
  wire d_term1_n_119;
  wire d_term1_n_120;
  wire d_term1_n_121;
  wire d_term1_n_122;
  wire d_term1_n_123;
  wire d_term1_n_124;
  wire d_term1_n_125;
  wire d_term1_n_126;
  wire d_term1_n_127;
  wire d_term1_n_128;
  wire d_term1_n_129;
  wire d_term1_n_130;
  wire d_term1_n_131;
  wire d_term1_n_132;
  wire d_term1_n_133;
  wire d_term1_n_134;
  wire d_term1_n_135;
  wire d_term1_n_136;
  wire d_term1_n_137;
  wire d_term1_n_138;
  wire d_term1_n_139;
  wire d_term1_n_140;
  wire d_term1_n_141;
  wire d_term1_n_142;
  wire d_term1_n_143;
  wire d_term1_n_144;
  wire d_term1_n_145;
  wire d_term1_n_146;
  wire d_term1_n_147;
  wire d_term1_n_148;
  wire d_term1_n_149;
  wire d_term1_n_150;
  wire d_term1_n_151;
  wire d_term1_n_152;
  wire d_term1_n_153;
  wire d_term1_n_58;
  wire d_term1_n_59;
  wire d_term1_n_60;
  wire d_term1_n_61;
  wire d_term1_n_62;
  wire d_term1_n_63;
  wire d_term1_n_64;
  wire d_term1_n_65;
  wire d_term1_n_66;
  wire d_term1_n_67;
  wire d_term1_n_68;
  wire d_term1_n_69;
  wire d_term1_n_70;
  wire d_term1_n_71;
  wire d_term1_n_72;
  wire d_term1_n_73;
  wire d_term1_n_74;
  wire d_term1_n_75;
  wire d_term1_n_76;
  wire d_term1_n_77;
  wire d_term1_n_78;
  wire d_term1_n_79;
  wire d_term1_n_80;
  wire d_term1_n_81;
  wire d_term1_n_82;
  wire d_term1_n_83;
  wire d_term1_n_84;
  wire d_term1_n_85;
  wire d_term1_n_86;
  wire d_term1_n_87;
  wire d_term1_n_88;
  wire d_term1_n_89;
  wire d_term1_n_90;
  wire d_term1_n_91;
  wire d_term1_n_92;
  wire d_term1_n_93;
  wire d_term1_n_94;
  wire d_term1_n_95;
  wire d_term1_n_96;
  wire d_term1_n_97;
  wire d_term1_n_98;
  wire d_term1_n_99;
  wire d_term_interim_reg_n_58;
  wire d_term_interim_reg_n_59;
  wire d_term_interim_reg_n_60;
  wire d_term_interim_reg_n_61;
  wire d_term_interim_reg_n_62;
  wire d_term_interim_reg_n_63;
  wire d_term_interim_reg_n_64;
  wire d_term_interim_reg_n_65;
  wire d_term_interim_reg_n_66;
  wire d_term_interim_reg_n_67;
  wire d_term_interim_reg_n_68;
  wire d_term_interim_reg_n_69;
  wire d_term_interim_reg_n_70;
  wire d_term_interim_reg_n_71;
  wire d_term_interim_reg_n_72;
  wire d_term_interim_reg_n_73;
  wire d_term_interim_reg_n_74;
  wire d_term_interim_reg_n_75;
  wire d_term_interim_reg_n_76;
  wire d_term_interim_reg_n_77;
  wire d_term_interim_reg_n_78;
  wire d_term_interim_reg_n_79;
  wire d_term_interim_reg_n_80;
  wire d_term_interim_reg_n_81;
  wire d_term_interim_reg_n_82;
  wire d_term_interim_reg_n_83;
  wire d_term_interim_reg_n_84;
  wire d_term_interim_reg_n_85;
  wire d_term_interim_reg_n_86;
  wire d_term_interim_reg_n_87;
  wire d_term_interim_reg_n_88;
  wire d_term_interim_reg_n_89;
  wire d_term_interim_reg_n_90;
  wire [31:0]derivative;
  wire [31:0]error;
  wire [21:0]i_term;
  wire i_term1_n_100;
  wire i_term1_n_101;
  wire i_term1_n_102;
  wire i_term1_n_103;
  wire i_term1_n_104;
  wire i_term1_n_105;
  wire i_term1_n_106;
  wire i_term1_n_107;
  wire i_term1_n_108;
  wire i_term1_n_109;
  wire i_term1_n_110;
  wire i_term1_n_111;
  wire i_term1_n_112;
  wire i_term1_n_113;
  wire i_term1_n_114;
  wire i_term1_n_115;
  wire i_term1_n_116;
  wire i_term1_n_117;
  wire i_term1_n_118;
  wire i_term1_n_119;
  wire i_term1_n_120;
  wire i_term1_n_121;
  wire i_term1_n_122;
  wire i_term1_n_123;
  wire i_term1_n_124;
  wire i_term1_n_125;
  wire i_term1_n_126;
  wire i_term1_n_127;
  wire i_term1_n_128;
  wire i_term1_n_129;
  wire i_term1_n_130;
  wire i_term1_n_131;
  wire i_term1_n_132;
  wire i_term1_n_133;
  wire i_term1_n_134;
  wire i_term1_n_135;
  wire i_term1_n_136;
  wire i_term1_n_137;
  wire i_term1_n_138;
  wire i_term1_n_139;
  wire i_term1_n_140;
  wire i_term1_n_141;
  wire i_term1_n_142;
  wire i_term1_n_143;
  wire i_term1_n_144;
  wire i_term1_n_145;
  wire i_term1_n_146;
  wire i_term1_n_147;
  wire i_term1_n_148;
  wire i_term1_n_149;
  wire i_term1_n_150;
  wire i_term1_n_151;
  wire i_term1_n_152;
  wire i_term1_n_153;
  wire i_term1_n_58;
  wire i_term1_n_59;
  wire i_term1_n_60;
  wire i_term1_n_61;
  wire i_term1_n_62;
  wire i_term1_n_63;
  wire i_term1_n_64;
  wire i_term1_n_65;
  wire i_term1_n_66;
  wire i_term1_n_67;
  wire i_term1_n_68;
  wire i_term1_n_69;
  wire i_term1_n_70;
  wire i_term1_n_71;
  wire i_term1_n_72;
  wire i_term1_n_73;
  wire i_term1_n_74;
  wire i_term1_n_75;
  wire i_term1_n_76;
  wire i_term1_n_77;
  wire i_term1_n_78;
  wire i_term1_n_79;
  wire i_term1_n_80;
  wire i_term1_n_81;
  wire i_term1_n_82;
  wire i_term1_n_83;
  wire i_term1_n_84;
  wire i_term1_n_85;
  wire i_term1_n_86;
  wire i_term1_n_87;
  wire i_term1_n_88;
  wire i_term1_n_89;
  wire i_term1_n_90;
  wire i_term1_n_91;
  wire i_term1_n_92;
  wire i_term1_n_93;
  wire i_term1_n_94;
  wire i_term1_n_95;
  wire i_term1_n_96;
  wire i_term1_n_97;
  wire i_term1_n_98;
  wire i_term1_n_99;
  wire i_term_interim_reg_n_58;
  wire i_term_interim_reg_n_59;
  wire i_term_interim_reg_n_60;
  wire i_term_interim_reg_n_61;
  wire i_term_interim_reg_n_62;
  wire i_term_interim_reg_n_63;
  wire i_term_interim_reg_n_64;
  wire i_term_interim_reg_n_65;
  wire i_term_interim_reg_n_66;
  wire i_term_interim_reg_n_67;
  wire i_term_interim_reg_n_68;
  wire i_term_interim_reg_n_69;
  wire i_term_interim_reg_n_70;
  wire i_term_interim_reg_n_71;
  wire i_term_interim_reg_n_72;
  wire i_term_interim_reg_n_73;
  wire i_term_interim_reg_n_74;
  wire i_term_interim_reg_n_75;
  wire i_term_interim_reg_n_76;
  wire i_term_interim_reg_n_77;
  wire i_term_interim_reg_n_78;
  wire i_term_interim_reg_n_79;
  wire i_term_interim_reg_n_80;
  wire i_term_interim_reg_n_81;
  wire i_term_interim_reg_n_82;
  wire i_term_interim_reg_n_83;
  wire i_term_interim_reg_n_84;
  wire i_term_interim_reg_n_85;
  wire i_term_interim_reg_n_86;
  wire i_term_interim_reg_n_87;
  wire i_term_interim_reg_n_88;
  wire i_term_interim_reg_n_89;
  wire i_term_interim_reg_n_90;
  wire [31:0]integral;
  wire [8:0]kd;
  wire [8:0]ki;
  wire [8:0]kp;
  wire [21:0]p_term;
  wire p_term1_n_100;
  wire p_term1_n_101;
  wire p_term1_n_102;
  wire p_term1_n_103;
  wire p_term1_n_104;
  wire p_term1_n_105;
  wire p_term1_n_106;
  wire p_term1_n_107;
  wire p_term1_n_108;
  wire p_term1_n_109;
  wire p_term1_n_110;
  wire p_term1_n_111;
  wire p_term1_n_112;
  wire p_term1_n_113;
  wire p_term1_n_114;
  wire p_term1_n_115;
  wire p_term1_n_116;
  wire p_term1_n_117;
  wire p_term1_n_118;
  wire p_term1_n_119;
  wire p_term1_n_120;
  wire p_term1_n_121;
  wire p_term1_n_122;
  wire p_term1_n_123;
  wire p_term1_n_124;
  wire p_term1_n_125;
  wire p_term1_n_126;
  wire p_term1_n_127;
  wire p_term1_n_128;
  wire p_term1_n_129;
  wire p_term1_n_130;
  wire p_term1_n_131;
  wire p_term1_n_132;
  wire p_term1_n_133;
  wire p_term1_n_134;
  wire p_term1_n_135;
  wire p_term1_n_136;
  wire p_term1_n_137;
  wire p_term1_n_138;
  wire p_term1_n_139;
  wire p_term1_n_140;
  wire p_term1_n_141;
  wire p_term1_n_142;
  wire p_term1_n_143;
  wire p_term1_n_144;
  wire p_term1_n_145;
  wire p_term1_n_146;
  wire p_term1_n_147;
  wire p_term1_n_148;
  wire p_term1_n_149;
  wire p_term1_n_150;
  wire p_term1_n_151;
  wire p_term1_n_152;
  wire p_term1_n_153;
  wire p_term1_n_58;
  wire p_term1_n_59;
  wire p_term1_n_60;
  wire p_term1_n_61;
  wire p_term1_n_62;
  wire p_term1_n_63;
  wire p_term1_n_64;
  wire p_term1_n_65;
  wire p_term1_n_66;
  wire p_term1_n_67;
  wire p_term1_n_68;
  wire p_term1_n_69;
  wire p_term1_n_70;
  wire p_term1_n_71;
  wire p_term1_n_72;
  wire p_term1_n_73;
  wire p_term1_n_74;
  wire p_term1_n_75;
  wire p_term1_n_76;
  wire p_term1_n_77;
  wire p_term1_n_78;
  wire p_term1_n_79;
  wire p_term1_n_80;
  wire p_term1_n_81;
  wire p_term1_n_82;
  wire p_term1_n_83;
  wire p_term1_n_84;
  wire p_term1_n_85;
  wire p_term1_n_86;
  wire p_term1_n_87;
  wire p_term1_n_88;
  wire p_term1_n_89;
  wire p_term1_n_90;
  wire p_term1_n_91;
  wire p_term1_n_92;
  wire p_term1_n_93;
  wire p_term1_n_94;
  wire p_term1_n_95;
  wire p_term1_n_96;
  wire p_term1_n_97;
  wire p_term1_n_98;
  wire p_term1_n_99;
  wire p_term_interim_reg_n_58;
  wire p_term_interim_reg_n_59;
  wire p_term_interim_reg_n_60;
  wire p_term_interim_reg_n_61;
  wire p_term_interim_reg_n_62;
  wire p_term_interim_reg_n_63;
  wire p_term_interim_reg_n_64;
  wire p_term_interim_reg_n_65;
  wire p_term_interim_reg_n_66;
  wire p_term_interim_reg_n_67;
  wire p_term_interim_reg_n_68;
  wire p_term_interim_reg_n_69;
  wire p_term_interim_reg_n_70;
  wire p_term_interim_reg_n_71;
  wire p_term_interim_reg_n_72;
  wire p_term_interim_reg_n_73;
  wire p_term_interim_reg_n_74;
  wire p_term_interim_reg_n_75;
  wire p_term_interim_reg_n_76;
  wire p_term_interim_reg_n_77;
  wire p_term_interim_reg_n_78;
  wire p_term_interim_reg_n_79;
  wire p_term_interim_reg_n_80;
  wire p_term_interim_reg_n_81;
  wire p_term_interim_reg_n_82;
  wire p_term_interim_reg_n_83;
  wire p_term_interim_reg_n_84;
  wire p_term_interim_reg_n_85;
  wire p_term_interim_reg_n_86;
  wire p_term_interim_reg_n_87;
  wire p_term_interim_reg_n_88;
  wire p_term_interim_reg_n_89;
  wire p_term_interim_reg_n_90;
  wire NLW_d_term1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_d_term1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_d_term1_OVERFLOW_UNCONNECTED;
  wire NLW_d_term1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_d_term1_PATTERNDETECT_UNCONNECTED;
  wire NLW_d_term1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_d_term1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_d_term1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_d_term1_CARRYOUT_UNCONNECTED;
  wire NLW_d_term_interim_reg_CARRYCASCOUT_UNCONNECTED;
  wire NLW_d_term_interim_reg_MULTSIGNOUT_UNCONNECTED;
  wire NLW_d_term_interim_reg_OVERFLOW_UNCONNECTED;
  wire NLW_d_term_interim_reg_PATTERNBDETECT_UNCONNECTED;
  wire NLW_d_term_interim_reg_PATTERNDETECT_UNCONNECTED;
  wire NLW_d_term_interim_reg_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_d_term_interim_reg_ACOUT_UNCONNECTED;
  wire [17:0]NLW_d_term_interim_reg_BCOUT_UNCONNECTED;
  wire [3:0]NLW_d_term_interim_reg_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_d_term_interim_reg_PCOUT_UNCONNECTED;
  wire NLW_i_term1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_i_term1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_i_term1_OVERFLOW_UNCONNECTED;
  wire NLW_i_term1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_i_term1_PATTERNDETECT_UNCONNECTED;
  wire NLW_i_term1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_i_term1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_i_term1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_i_term1_CARRYOUT_UNCONNECTED;
  wire NLW_i_term_interim_reg_CARRYCASCOUT_UNCONNECTED;
  wire NLW_i_term_interim_reg_MULTSIGNOUT_UNCONNECTED;
  wire NLW_i_term_interim_reg_OVERFLOW_UNCONNECTED;
  wire NLW_i_term_interim_reg_PATTERNBDETECT_UNCONNECTED;
  wire NLW_i_term_interim_reg_PATTERNDETECT_UNCONNECTED;
  wire NLW_i_term_interim_reg_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_i_term_interim_reg_ACOUT_UNCONNECTED;
  wire [17:0]NLW_i_term_interim_reg_BCOUT_UNCONNECTED;
  wire [3:0]NLW_i_term_interim_reg_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_i_term_interim_reg_PCOUT_UNCONNECTED;
  wire NLW_p_term1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_p_term1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_p_term1_OVERFLOW_UNCONNECTED;
  wire NLW_p_term1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_p_term1_PATTERNDETECT_UNCONNECTED;
  wire NLW_p_term1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_p_term1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_p_term1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_p_term1_CARRYOUT_UNCONNECTED;
  wire NLW_p_term_interim_reg_CARRYCASCOUT_UNCONNECTED;
  wire NLW_p_term_interim_reg_MULTSIGNOUT_UNCONNECTED;
  wire NLW_p_term_interim_reg_OVERFLOW_UNCONNECTED;
  wire NLW_p_term_interim_reg_PATTERNBDETECT_UNCONNECTED;
  wire NLW_p_term_interim_reg_PATTERNDETECT_UNCONNECTED;
  wire NLW_p_term_interim_reg_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_p_term_interim_reg_ACOUT_UNCONNECTED;
  wire [17:0]NLW_p_term_interim_reg_BCOUT_UNCONNECTED;
  wire [3:0]NLW_p_term_interim_reg_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_p_term_interim_reg_PCOUT_UNCONNECTED;

  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    d_term1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,derivative[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_d_term1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_d_term1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_d_term1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_d_term1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_d_term1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_d_term1_OVERFLOW_UNCONNECTED),
        .P({d_term1_n_58,d_term1_n_59,d_term1_n_60,d_term1_n_61,d_term1_n_62,d_term1_n_63,d_term1_n_64,d_term1_n_65,d_term1_n_66,d_term1_n_67,d_term1_n_68,d_term1_n_69,d_term1_n_70,d_term1_n_71,d_term1_n_72,d_term1_n_73,d_term1_n_74,d_term1_n_75,d_term1_n_76,d_term1_n_77,d_term1_n_78,d_term1_n_79,d_term1_n_80,d_term1_n_81,d_term1_n_82,d_term1_n_83,d_term1_n_84,d_term1_n_85,d_term1_n_86,d_term1_n_87,d_term1_n_88,d_term1_n_89,d_term1_n_90,d_term1_n_91,d_term1_n_92,d_term1_n_93,d_term1_n_94,d_term1_n_95,d_term1_n_96,d_term1_n_97,d_term1_n_98,d_term1_n_99,d_term1_n_100,d_term1_n_101,d_term1_n_102,d_term1_n_103,d_term1_n_104,d_term1_n_105}),
        .PATTERNBDETECT(NLW_d_term1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_d_term1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({d_term1_n_106,d_term1_n_107,d_term1_n_108,d_term1_n_109,d_term1_n_110,d_term1_n_111,d_term1_n_112,d_term1_n_113,d_term1_n_114,d_term1_n_115,d_term1_n_116,d_term1_n_117,d_term1_n_118,d_term1_n_119,d_term1_n_120,d_term1_n_121,d_term1_n_122,d_term1_n_123,d_term1_n_124,d_term1_n_125,d_term1_n_126,d_term1_n_127,d_term1_n_128,d_term1_n_129,d_term1_n_130,d_term1_n_131,d_term1_n_132,d_term1_n_133,d_term1_n_134,d_term1_n_135,d_term1_n_136,d_term1_n_137,d_term1_n_138,d_term1_n_139,d_term1_n_140,d_term1_n_141,d_term1_n_142,d_term1_n_143,d_term1_n_144,d_term1_n_145,d_term1_n_146,d_term1_n_147,d_term1_n_148,d_term1_n_149,d_term1_n_150,d_term1_n_151,d_term1_n_152,d_term1_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_d_term1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-12 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    d_term_interim_reg
       (.A({derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31],derivative[31:17]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_d_term_interim_reg_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd[8],kd}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_d_term_interim_reg_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_d_term_interim_reg_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_d_term_interim_reg_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b1),
        .CLK(clock),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_d_term_interim_reg_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_d_term_interim_reg_OVERFLOW_UNCONNECTED),
        .P({d_term_interim_reg_n_58,d_term_interim_reg_n_59,d_term_interim_reg_n_60,d_term_interim_reg_n_61,d_term_interim_reg_n_62,d_term_interim_reg_n_63,d_term_interim_reg_n_64,d_term_interim_reg_n_65,d_term_interim_reg_n_66,d_term_interim_reg_n_67,d_term_interim_reg_n_68,d_term_interim_reg_n_69,d_term_interim_reg_n_70,d_term_interim_reg_n_71,d_term_interim_reg_n_72,d_term_interim_reg_n_73,d_term_interim_reg_n_74,d_term_interim_reg_n_75,d_term_interim_reg_n_76,d_term_interim_reg_n_77,d_term_interim_reg_n_78,d_term_interim_reg_n_79,d_term_interim_reg_n_80,d_term_interim_reg_n_81,d_term_interim_reg_n_82,d_term_interim_reg_n_83,d_term_interim_reg_n_84,d_term_interim_reg_n_85,d_term_interim_reg_n_86,d_term_interim_reg_n_87,d_term_interim_reg_n_88,d_term_interim_reg_n_89,d_term_interim_reg_n_90,d_term[21:7]}),
        .PATTERNBDETECT(NLW_d_term_interim_reg_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_d_term_interim_reg_PATTERNDETECT_UNCONNECTED),
        .PCIN({d_term1_n_106,d_term1_n_107,d_term1_n_108,d_term1_n_109,d_term1_n_110,d_term1_n_111,d_term1_n_112,d_term1_n_113,d_term1_n_114,d_term1_n_115,d_term1_n_116,d_term1_n_117,d_term1_n_118,d_term1_n_119,d_term1_n_120,d_term1_n_121,d_term1_n_122,d_term1_n_123,d_term1_n_124,d_term1_n_125,d_term1_n_126,d_term1_n_127,d_term1_n_128,d_term1_n_129,d_term1_n_130,d_term1_n_131,d_term1_n_132,d_term1_n_133,d_term1_n_134,d_term1_n_135,d_term1_n_136,d_term1_n_137,d_term1_n_138,d_term1_n_139,d_term1_n_140,d_term1_n_141,d_term1_n_142,d_term1_n_143,d_term1_n_144,d_term1_n_145,d_term1_n_146,d_term1_n_147,d_term1_n_148,d_term1_n_149,d_term1_n_150,d_term1_n_151,d_term1_n_152,d_term1_n_153}),
        .PCOUT(NLW_d_term_interim_reg_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_d_term_interim_reg_UNDERFLOW_UNCONNECTED));
  FDRE \d_term_interim_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(d_term1_n_95),
        .Q(d_term[0]),
        .R(1'b0));
  FDRE \d_term_interim_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(d_term1_n_94),
        .Q(d_term[1]),
        .R(1'b0));
  FDRE \d_term_interim_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(d_term1_n_93),
        .Q(d_term[2]),
        .R(1'b0));
  FDRE \d_term_interim_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(d_term1_n_92),
        .Q(d_term[3]),
        .R(1'b0));
  FDRE \d_term_interim_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(d_term1_n_91),
        .Q(d_term[4]),
        .R(1'b0));
  FDRE \d_term_interim_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(d_term1_n_90),
        .Q(d_term[5]),
        .R(1'b0));
  FDRE \d_term_interim_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(d_term1_n_89),
        .Q(d_term[6]),
        .R(1'b0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    i_term1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,integral[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_i_term1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_i_term1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_i_term1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_i_term1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_i_term1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_i_term1_OVERFLOW_UNCONNECTED),
        .P({i_term1_n_58,i_term1_n_59,i_term1_n_60,i_term1_n_61,i_term1_n_62,i_term1_n_63,i_term1_n_64,i_term1_n_65,i_term1_n_66,i_term1_n_67,i_term1_n_68,i_term1_n_69,i_term1_n_70,i_term1_n_71,i_term1_n_72,i_term1_n_73,i_term1_n_74,i_term1_n_75,i_term1_n_76,i_term1_n_77,i_term1_n_78,i_term1_n_79,i_term1_n_80,i_term1_n_81,i_term1_n_82,i_term1_n_83,i_term1_n_84,i_term1_n_85,i_term1_n_86,i_term1_n_87,i_term1_n_88,i_term1_n_89,i_term1_n_90,i_term1_n_91,i_term1_n_92,i_term1_n_93,i_term1_n_94,i_term1_n_95,i_term1_n_96,i_term1_n_97,i_term1_n_98,i_term1_n_99,i_term1_n_100,i_term1_n_101,i_term1_n_102,i_term1_n_103,i_term1_n_104,i_term1_n_105}),
        .PATTERNBDETECT(NLW_i_term1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_i_term1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({i_term1_n_106,i_term1_n_107,i_term1_n_108,i_term1_n_109,i_term1_n_110,i_term1_n_111,i_term1_n_112,i_term1_n_113,i_term1_n_114,i_term1_n_115,i_term1_n_116,i_term1_n_117,i_term1_n_118,i_term1_n_119,i_term1_n_120,i_term1_n_121,i_term1_n_122,i_term1_n_123,i_term1_n_124,i_term1_n_125,i_term1_n_126,i_term1_n_127,i_term1_n_128,i_term1_n_129,i_term1_n_130,i_term1_n_131,i_term1_n_132,i_term1_n_133,i_term1_n_134,i_term1_n_135,i_term1_n_136,i_term1_n_137,i_term1_n_138,i_term1_n_139,i_term1_n_140,i_term1_n_141,i_term1_n_142,i_term1_n_143,i_term1_n_144,i_term1_n_145,i_term1_n_146,i_term1_n_147,i_term1_n_148,i_term1_n_149,i_term1_n_150,i_term1_n_151,i_term1_n_152,i_term1_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_i_term1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-12 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    i_term_interim_reg
       (.A({integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31],integral[31:17]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_i_term_interim_reg_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki[8],ki}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_i_term_interim_reg_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_i_term_interim_reg_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_i_term_interim_reg_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b1),
        .CLK(clock),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_i_term_interim_reg_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_i_term_interim_reg_OVERFLOW_UNCONNECTED),
        .P({i_term_interim_reg_n_58,i_term_interim_reg_n_59,i_term_interim_reg_n_60,i_term_interim_reg_n_61,i_term_interim_reg_n_62,i_term_interim_reg_n_63,i_term_interim_reg_n_64,i_term_interim_reg_n_65,i_term_interim_reg_n_66,i_term_interim_reg_n_67,i_term_interim_reg_n_68,i_term_interim_reg_n_69,i_term_interim_reg_n_70,i_term_interim_reg_n_71,i_term_interim_reg_n_72,i_term_interim_reg_n_73,i_term_interim_reg_n_74,i_term_interim_reg_n_75,i_term_interim_reg_n_76,i_term_interim_reg_n_77,i_term_interim_reg_n_78,i_term_interim_reg_n_79,i_term_interim_reg_n_80,i_term_interim_reg_n_81,i_term_interim_reg_n_82,i_term_interim_reg_n_83,i_term_interim_reg_n_84,i_term_interim_reg_n_85,i_term_interim_reg_n_86,i_term_interim_reg_n_87,i_term_interim_reg_n_88,i_term_interim_reg_n_89,i_term_interim_reg_n_90,i_term[21:7]}),
        .PATTERNBDETECT(NLW_i_term_interim_reg_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_i_term_interim_reg_PATTERNDETECT_UNCONNECTED),
        .PCIN({i_term1_n_106,i_term1_n_107,i_term1_n_108,i_term1_n_109,i_term1_n_110,i_term1_n_111,i_term1_n_112,i_term1_n_113,i_term1_n_114,i_term1_n_115,i_term1_n_116,i_term1_n_117,i_term1_n_118,i_term1_n_119,i_term1_n_120,i_term1_n_121,i_term1_n_122,i_term1_n_123,i_term1_n_124,i_term1_n_125,i_term1_n_126,i_term1_n_127,i_term1_n_128,i_term1_n_129,i_term1_n_130,i_term1_n_131,i_term1_n_132,i_term1_n_133,i_term1_n_134,i_term1_n_135,i_term1_n_136,i_term1_n_137,i_term1_n_138,i_term1_n_139,i_term1_n_140,i_term1_n_141,i_term1_n_142,i_term1_n_143,i_term1_n_144,i_term1_n_145,i_term1_n_146,i_term1_n_147,i_term1_n_148,i_term1_n_149,i_term1_n_150,i_term1_n_151,i_term1_n_152,i_term1_n_153}),
        .PCOUT(NLW_i_term_interim_reg_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_i_term_interim_reg_UNDERFLOW_UNCONNECTED));
  FDRE \i_term_interim_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(i_term1_n_95),
        .Q(i_term[0]),
        .R(1'b0));
  FDRE \i_term_interim_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(i_term1_n_94),
        .Q(i_term[1]),
        .R(1'b0));
  FDRE \i_term_interim_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(i_term1_n_93),
        .Q(i_term[2]),
        .R(1'b0));
  FDRE \i_term_interim_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(i_term1_n_92),
        .Q(i_term[3]),
        .R(1'b0));
  FDRE \i_term_interim_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(i_term1_n_91),
        .Q(i_term[4]),
        .R(1'b0));
  FDRE \i_term_interim_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(i_term1_n_90),
        .Q(i_term[5]),
        .R(1'b0));
  FDRE \i_term_interim_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(i_term1_n_89),
        .Q(i_term[6]),
        .R(1'b0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_term1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,error[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_p_term1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_p_term1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_p_term1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_p_term1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_p_term1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_p_term1_OVERFLOW_UNCONNECTED),
        .P({p_term1_n_58,p_term1_n_59,p_term1_n_60,p_term1_n_61,p_term1_n_62,p_term1_n_63,p_term1_n_64,p_term1_n_65,p_term1_n_66,p_term1_n_67,p_term1_n_68,p_term1_n_69,p_term1_n_70,p_term1_n_71,p_term1_n_72,p_term1_n_73,p_term1_n_74,p_term1_n_75,p_term1_n_76,p_term1_n_77,p_term1_n_78,p_term1_n_79,p_term1_n_80,p_term1_n_81,p_term1_n_82,p_term1_n_83,p_term1_n_84,p_term1_n_85,p_term1_n_86,p_term1_n_87,p_term1_n_88,p_term1_n_89,p_term1_n_90,p_term1_n_91,p_term1_n_92,p_term1_n_93,p_term1_n_94,p_term1_n_95,p_term1_n_96,p_term1_n_97,p_term1_n_98,p_term1_n_99,p_term1_n_100,p_term1_n_101,p_term1_n_102,p_term1_n_103,p_term1_n_104,p_term1_n_105}),
        .PATTERNBDETECT(NLW_p_term1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_p_term1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({p_term1_n_106,p_term1_n_107,p_term1_n_108,p_term1_n_109,p_term1_n_110,p_term1_n_111,p_term1_n_112,p_term1_n_113,p_term1_n_114,p_term1_n_115,p_term1_n_116,p_term1_n_117,p_term1_n_118,p_term1_n_119,p_term1_n_120,p_term1_n_121,p_term1_n_122,p_term1_n_123,p_term1_n_124,p_term1_n_125,p_term1_n_126,p_term1_n_127,p_term1_n_128,p_term1_n_129,p_term1_n_130,p_term1_n_131,p_term1_n_132,p_term1_n_133,p_term1_n_134,p_term1_n_135,p_term1_n_136,p_term1_n_137,p_term1_n_138,p_term1_n_139,p_term1_n_140,p_term1_n_141,p_term1_n_142,p_term1_n_143,p_term1_n_144,p_term1_n_145,p_term1_n_146,p_term1_n_147,p_term1_n_148,p_term1_n_149,p_term1_n_150,p_term1_n_151,p_term1_n_152,p_term1_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_p_term1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-12 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_term_interim_reg
       (.A({error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31],error[31:17]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_p_term_interim_reg_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp[8],kp}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_p_term_interim_reg_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_p_term_interim_reg_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_p_term_interim_reg_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b1),
        .CLK(clock),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_p_term_interim_reg_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_p_term_interim_reg_OVERFLOW_UNCONNECTED),
        .P({p_term_interim_reg_n_58,p_term_interim_reg_n_59,p_term_interim_reg_n_60,p_term_interim_reg_n_61,p_term_interim_reg_n_62,p_term_interim_reg_n_63,p_term_interim_reg_n_64,p_term_interim_reg_n_65,p_term_interim_reg_n_66,p_term_interim_reg_n_67,p_term_interim_reg_n_68,p_term_interim_reg_n_69,p_term_interim_reg_n_70,p_term_interim_reg_n_71,p_term_interim_reg_n_72,p_term_interim_reg_n_73,p_term_interim_reg_n_74,p_term_interim_reg_n_75,p_term_interim_reg_n_76,p_term_interim_reg_n_77,p_term_interim_reg_n_78,p_term_interim_reg_n_79,p_term_interim_reg_n_80,p_term_interim_reg_n_81,p_term_interim_reg_n_82,p_term_interim_reg_n_83,p_term_interim_reg_n_84,p_term_interim_reg_n_85,p_term_interim_reg_n_86,p_term_interim_reg_n_87,p_term_interim_reg_n_88,p_term_interim_reg_n_89,p_term_interim_reg_n_90,p_term[21:7]}),
        .PATTERNBDETECT(NLW_p_term_interim_reg_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_p_term_interim_reg_PATTERNDETECT_UNCONNECTED),
        .PCIN({p_term1_n_106,p_term1_n_107,p_term1_n_108,p_term1_n_109,p_term1_n_110,p_term1_n_111,p_term1_n_112,p_term1_n_113,p_term1_n_114,p_term1_n_115,p_term1_n_116,p_term1_n_117,p_term1_n_118,p_term1_n_119,p_term1_n_120,p_term1_n_121,p_term1_n_122,p_term1_n_123,p_term1_n_124,p_term1_n_125,p_term1_n_126,p_term1_n_127,p_term1_n_128,p_term1_n_129,p_term1_n_130,p_term1_n_131,p_term1_n_132,p_term1_n_133,p_term1_n_134,p_term1_n_135,p_term1_n_136,p_term1_n_137,p_term1_n_138,p_term1_n_139,p_term1_n_140,p_term1_n_141,p_term1_n_142,p_term1_n_143,p_term1_n_144,p_term1_n_145,p_term1_n_146,p_term1_n_147,p_term1_n_148,p_term1_n_149,p_term1_n_150,p_term1_n_151,p_term1_n_152,p_term1_n_153}),
        .PCOUT(NLW_p_term_interim_reg_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_p_term_interim_reg_UNDERFLOW_UNCONNECTED));
  FDRE \p_term_interim_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(p_term1_n_95),
        .Q(p_term[0]),
        .R(1'b0));
  FDRE \p_term_interim_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(p_term1_n_94),
        .Q(p_term[1]),
        .R(1'b0));
  FDRE \p_term_interim_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(p_term1_n_93),
        .Q(p_term[2]),
        .R(1'b0));
  FDRE \p_term_interim_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(p_term1_n_92),
        .Q(p_term[3]),
        .R(1'b0));
  FDRE \p_term_interim_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(p_term1_n_91),
        .Q(p_term[4]),
        .R(1'b0));
  FDRE \p_term_interim_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(p_term1_n_90),
        .Q(p_term[5]),
        .R(1'b0));
  FDRE \p_term_interim_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(p_term1_n_89),
        .Q(p_term[6]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
