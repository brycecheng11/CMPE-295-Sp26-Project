// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Wed Sep 16 22:11:41 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Xilinx/Projects/pid_controller/pid_controller.gen/sources_1/bd/design_1/ip/design_1_time_calc_0_0/design_1_time_calc_0_0_sim_netlist.v
// Design      : design_1_time_calc_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_time_calc_0_0,time_calc,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "time_calc,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module design_1_time_calc_0_0
   (clock,
    time_curr,
    time_prev,
    dt_out,
    new_time_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input [0:0]clock;
  input [63:0]time_curr;
  input [63:0]time_prev;
  output [63:0]dt_out;
  output [63:0]new_time_out;

  wire [0:0]clock;
  wire [63:0]dt_out;
  wire [63:0]new_time_out;
  wire [63:0]time_curr;
  wire [63:0]time_prev;

  design_1_time_calc_0_0_time_calc inst
       (.clock(clock),
        .dt_out(dt_out),
        .new_time_out(new_time_out),
        .time_curr(time_curr),
        .time_prev(time_prev));
endmodule

(* ORIG_REF_NAME = "time_calc" *) 
module design_1_time_calc_0_0_time_calc
   (dt_out,
    new_time_out,
    time_curr,
    time_prev,
    clock);
  output [63:0]dt_out;
  output [63:0]new_time_out;
  input [63:0]time_curr;
  input [63:0]time_prev;
  input [0:0]clock;

  wire [0:0]clock;
  wire [63:0]dt0;
  wire dt0_carry__0_i_1_n_0;
  wire dt0_carry__0_i_2_n_0;
  wire dt0_carry__0_i_3_n_0;
  wire dt0_carry__0_i_4_n_0;
  wire dt0_carry__0_n_0;
  wire dt0_carry__0_n_1;
  wire dt0_carry__0_n_2;
  wire dt0_carry__0_n_3;
  wire dt0_carry__10_i_1_n_0;
  wire dt0_carry__10_i_2_n_0;
  wire dt0_carry__10_i_3_n_0;
  wire dt0_carry__10_i_4_n_0;
  wire dt0_carry__10_n_0;
  wire dt0_carry__10_n_1;
  wire dt0_carry__10_n_2;
  wire dt0_carry__10_n_3;
  wire dt0_carry__11_i_1_n_0;
  wire dt0_carry__11_i_2_n_0;
  wire dt0_carry__11_i_3_n_0;
  wire dt0_carry__11_i_4_n_0;
  wire dt0_carry__11_n_0;
  wire dt0_carry__11_n_1;
  wire dt0_carry__11_n_2;
  wire dt0_carry__11_n_3;
  wire dt0_carry__12_i_1_n_0;
  wire dt0_carry__12_i_2_n_0;
  wire dt0_carry__12_i_3_n_0;
  wire dt0_carry__12_i_4_n_0;
  wire dt0_carry__12_n_0;
  wire dt0_carry__12_n_1;
  wire dt0_carry__12_n_2;
  wire dt0_carry__12_n_3;
  wire dt0_carry__13_i_1_n_0;
  wire dt0_carry__13_i_2_n_0;
  wire dt0_carry__13_i_3_n_0;
  wire dt0_carry__13_i_4_n_0;
  wire dt0_carry__13_n_0;
  wire dt0_carry__13_n_1;
  wire dt0_carry__13_n_2;
  wire dt0_carry__13_n_3;
  wire dt0_carry__14_i_1_n_0;
  wire dt0_carry__14_i_2_n_0;
  wire dt0_carry__14_i_3_n_0;
  wire dt0_carry__14_i_4_n_0;
  wire dt0_carry__14_n_1;
  wire dt0_carry__14_n_2;
  wire dt0_carry__14_n_3;
  wire dt0_carry__1_i_1_n_0;
  wire dt0_carry__1_i_2_n_0;
  wire dt0_carry__1_i_3_n_0;
  wire dt0_carry__1_i_4_n_0;
  wire dt0_carry__1_n_0;
  wire dt0_carry__1_n_1;
  wire dt0_carry__1_n_2;
  wire dt0_carry__1_n_3;
  wire dt0_carry__2_i_1_n_0;
  wire dt0_carry__2_i_2_n_0;
  wire dt0_carry__2_i_3_n_0;
  wire dt0_carry__2_i_4_n_0;
  wire dt0_carry__2_n_0;
  wire dt0_carry__2_n_1;
  wire dt0_carry__2_n_2;
  wire dt0_carry__2_n_3;
  wire dt0_carry__3_i_1_n_0;
  wire dt0_carry__3_i_2_n_0;
  wire dt0_carry__3_i_3_n_0;
  wire dt0_carry__3_i_4_n_0;
  wire dt0_carry__3_n_0;
  wire dt0_carry__3_n_1;
  wire dt0_carry__3_n_2;
  wire dt0_carry__3_n_3;
  wire dt0_carry__4_i_1_n_0;
  wire dt0_carry__4_i_2_n_0;
  wire dt0_carry__4_i_3_n_0;
  wire dt0_carry__4_i_4_n_0;
  wire dt0_carry__4_n_0;
  wire dt0_carry__4_n_1;
  wire dt0_carry__4_n_2;
  wire dt0_carry__4_n_3;
  wire dt0_carry__5_i_1_n_0;
  wire dt0_carry__5_i_2_n_0;
  wire dt0_carry__5_i_3_n_0;
  wire dt0_carry__5_i_4_n_0;
  wire dt0_carry__5_n_0;
  wire dt0_carry__5_n_1;
  wire dt0_carry__5_n_2;
  wire dt0_carry__5_n_3;
  wire dt0_carry__6_i_1_n_0;
  wire dt0_carry__6_i_2_n_0;
  wire dt0_carry__6_i_3_n_0;
  wire dt0_carry__6_i_4_n_0;
  wire dt0_carry__6_n_0;
  wire dt0_carry__6_n_1;
  wire dt0_carry__6_n_2;
  wire dt0_carry__6_n_3;
  wire dt0_carry__7_i_1_n_0;
  wire dt0_carry__7_i_2_n_0;
  wire dt0_carry__7_i_3_n_0;
  wire dt0_carry__7_i_4_n_0;
  wire dt0_carry__7_n_0;
  wire dt0_carry__7_n_1;
  wire dt0_carry__7_n_2;
  wire dt0_carry__7_n_3;
  wire dt0_carry__8_i_1_n_0;
  wire dt0_carry__8_i_2_n_0;
  wire dt0_carry__8_i_3_n_0;
  wire dt0_carry__8_i_4_n_0;
  wire dt0_carry__8_n_0;
  wire dt0_carry__8_n_1;
  wire dt0_carry__8_n_2;
  wire dt0_carry__8_n_3;
  wire dt0_carry__9_i_1_n_0;
  wire dt0_carry__9_i_2_n_0;
  wire dt0_carry__9_i_3_n_0;
  wire dt0_carry__9_i_4_n_0;
  wire dt0_carry__9_n_0;
  wire dt0_carry__9_n_1;
  wire dt0_carry__9_n_2;
  wire dt0_carry__9_n_3;
  wire dt0_carry_i_1_n_0;
  wire dt0_carry_i_2_n_0;
  wire dt0_carry_i_3_n_0;
  wire dt0_carry_i_4_n_0;
  wire dt0_carry_n_0;
  wire dt0_carry_n_1;
  wire dt0_carry_n_2;
  wire dt0_carry_n_3;
  wire [63:0]dt_out;
  wire [63:0]new_time_out;
  wire [63:0]time_curr;
  wire [63:0]time_prev;
  wire [3:3]NLW_dt0_carry__14_CO_UNCONNECTED;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry
       (.CI(1'b0),
        .CO({dt0_carry_n_0,dt0_carry_n_1,dt0_carry_n_2,dt0_carry_n_3}),
        .CYINIT(1'b1),
        .DI(time_curr[3:0]),
        .O(dt0[3:0]),
        .S({dt0_carry_i_1_n_0,dt0_carry_i_2_n_0,dt0_carry_i_3_n_0,dt0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__0
       (.CI(dt0_carry_n_0),
        .CO({dt0_carry__0_n_0,dt0_carry__0_n_1,dt0_carry__0_n_2,dt0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[7:4]),
        .O(dt0[7:4]),
        .S({dt0_carry__0_i_1_n_0,dt0_carry__0_i_2_n_0,dt0_carry__0_i_3_n_0,dt0_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_1
       (.I0(time_curr[7]),
        .I1(time_prev[7]),
        .O(dt0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_2
       (.I0(time_curr[6]),
        .I1(time_prev[6]),
        .O(dt0_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_3
       (.I0(time_curr[5]),
        .I1(time_prev[5]),
        .O(dt0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_4
       (.I0(time_curr[4]),
        .I1(time_prev[4]),
        .O(dt0_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__1
       (.CI(dt0_carry__0_n_0),
        .CO({dt0_carry__1_n_0,dt0_carry__1_n_1,dt0_carry__1_n_2,dt0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[11:8]),
        .O(dt0[11:8]),
        .S({dt0_carry__1_i_1_n_0,dt0_carry__1_i_2_n_0,dt0_carry__1_i_3_n_0,dt0_carry__1_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__10
       (.CI(dt0_carry__9_n_0),
        .CO({dt0_carry__10_n_0,dt0_carry__10_n_1,dt0_carry__10_n_2,dt0_carry__10_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[47:44]),
        .O(dt0[47:44]),
        .S({dt0_carry__10_i_1_n_0,dt0_carry__10_i_2_n_0,dt0_carry__10_i_3_n_0,dt0_carry__10_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__10_i_1
       (.I0(time_curr[47]),
        .I1(time_prev[47]),
        .O(dt0_carry__10_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__10_i_2
       (.I0(time_curr[46]),
        .I1(time_prev[46]),
        .O(dt0_carry__10_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__10_i_3
       (.I0(time_curr[45]),
        .I1(time_prev[45]),
        .O(dt0_carry__10_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__10_i_4
       (.I0(time_curr[44]),
        .I1(time_prev[44]),
        .O(dt0_carry__10_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__11
       (.CI(dt0_carry__10_n_0),
        .CO({dt0_carry__11_n_0,dt0_carry__11_n_1,dt0_carry__11_n_2,dt0_carry__11_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[51:48]),
        .O(dt0[51:48]),
        .S({dt0_carry__11_i_1_n_0,dt0_carry__11_i_2_n_0,dt0_carry__11_i_3_n_0,dt0_carry__11_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__11_i_1
       (.I0(time_curr[51]),
        .I1(time_prev[51]),
        .O(dt0_carry__11_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__11_i_2
       (.I0(time_curr[50]),
        .I1(time_prev[50]),
        .O(dt0_carry__11_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__11_i_3
       (.I0(time_curr[49]),
        .I1(time_prev[49]),
        .O(dt0_carry__11_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__11_i_4
       (.I0(time_curr[48]),
        .I1(time_prev[48]),
        .O(dt0_carry__11_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__12
       (.CI(dt0_carry__11_n_0),
        .CO({dt0_carry__12_n_0,dt0_carry__12_n_1,dt0_carry__12_n_2,dt0_carry__12_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[55:52]),
        .O(dt0[55:52]),
        .S({dt0_carry__12_i_1_n_0,dt0_carry__12_i_2_n_0,dt0_carry__12_i_3_n_0,dt0_carry__12_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__12_i_1
       (.I0(time_curr[55]),
        .I1(time_prev[55]),
        .O(dt0_carry__12_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__12_i_2
       (.I0(time_curr[54]),
        .I1(time_prev[54]),
        .O(dt0_carry__12_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__12_i_3
       (.I0(time_curr[53]),
        .I1(time_prev[53]),
        .O(dt0_carry__12_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__12_i_4
       (.I0(time_curr[52]),
        .I1(time_prev[52]),
        .O(dt0_carry__12_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__13
       (.CI(dt0_carry__12_n_0),
        .CO({dt0_carry__13_n_0,dt0_carry__13_n_1,dt0_carry__13_n_2,dt0_carry__13_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[59:56]),
        .O(dt0[59:56]),
        .S({dt0_carry__13_i_1_n_0,dt0_carry__13_i_2_n_0,dt0_carry__13_i_3_n_0,dt0_carry__13_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__13_i_1
       (.I0(time_curr[59]),
        .I1(time_prev[59]),
        .O(dt0_carry__13_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__13_i_2
       (.I0(time_curr[58]),
        .I1(time_prev[58]),
        .O(dt0_carry__13_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__13_i_3
       (.I0(time_curr[57]),
        .I1(time_prev[57]),
        .O(dt0_carry__13_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__13_i_4
       (.I0(time_curr[56]),
        .I1(time_prev[56]),
        .O(dt0_carry__13_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__14
       (.CI(dt0_carry__13_n_0),
        .CO({NLW_dt0_carry__14_CO_UNCONNECTED[3],dt0_carry__14_n_1,dt0_carry__14_n_2,dt0_carry__14_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,time_curr[62:60]}),
        .O(dt0[63:60]),
        .S({dt0_carry__14_i_1_n_0,dt0_carry__14_i_2_n_0,dt0_carry__14_i_3_n_0,dt0_carry__14_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__14_i_1
       (.I0(time_curr[63]),
        .I1(time_prev[63]),
        .O(dt0_carry__14_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__14_i_2
       (.I0(time_curr[62]),
        .I1(time_prev[62]),
        .O(dt0_carry__14_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__14_i_3
       (.I0(time_curr[61]),
        .I1(time_prev[61]),
        .O(dt0_carry__14_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__14_i_4
       (.I0(time_curr[60]),
        .I1(time_prev[60]),
        .O(dt0_carry__14_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_1
       (.I0(time_curr[11]),
        .I1(time_prev[11]),
        .O(dt0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_2
       (.I0(time_curr[10]),
        .I1(time_prev[10]),
        .O(dt0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_3
       (.I0(time_curr[9]),
        .I1(time_prev[9]),
        .O(dt0_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_4
       (.I0(time_curr[8]),
        .I1(time_prev[8]),
        .O(dt0_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__2
       (.CI(dt0_carry__1_n_0),
        .CO({dt0_carry__2_n_0,dt0_carry__2_n_1,dt0_carry__2_n_2,dt0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[15:12]),
        .O(dt0[15:12]),
        .S({dt0_carry__2_i_1_n_0,dt0_carry__2_i_2_n_0,dt0_carry__2_i_3_n_0,dt0_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_1
       (.I0(time_curr[15]),
        .I1(time_prev[15]),
        .O(dt0_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_2
       (.I0(time_curr[14]),
        .I1(time_prev[14]),
        .O(dt0_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_3
       (.I0(time_curr[13]),
        .I1(time_prev[13]),
        .O(dt0_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_4
       (.I0(time_curr[12]),
        .I1(time_prev[12]),
        .O(dt0_carry__2_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__3
       (.CI(dt0_carry__2_n_0),
        .CO({dt0_carry__3_n_0,dt0_carry__3_n_1,dt0_carry__3_n_2,dt0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[19:16]),
        .O(dt0[19:16]),
        .S({dt0_carry__3_i_1_n_0,dt0_carry__3_i_2_n_0,dt0_carry__3_i_3_n_0,dt0_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_1
       (.I0(time_curr[19]),
        .I1(time_prev[19]),
        .O(dt0_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_2
       (.I0(time_curr[18]),
        .I1(time_prev[18]),
        .O(dt0_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_3
       (.I0(time_curr[17]),
        .I1(time_prev[17]),
        .O(dt0_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_4
       (.I0(time_curr[16]),
        .I1(time_prev[16]),
        .O(dt0_carry__3_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__4
       (.CI(dt0_carry__3_n_0),
        .CO({dt0_carry__4_n_0,dt0_carry__4_n_1,dt0_carry__4_n_2,dt0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[23:20]),
        .O(dt0[23:20]),
        .S({dt0_carry__4_i_1_n_0,dt0_carry__4_i_2_n_0,dt0_carry__4_i_3_n_0,dt0_carry__4_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_1
       (.I0(time_curr[23]),
        .I1(time_prev[23]),
        .O(dt0_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_2
       (.I0(time_curr[22]),
        .I1(time_prev[22]),
        .O(dt0_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_3
       (.I0(time_curr[21]),
        .I1(time_prev[21]),
        .O(dt0_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_4
       (.I0(time_curr[20]),
        .I1(time_prev[20]),
        .O(dt0_carry__4_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__5
       (.CI(dt0_carry__4_n_0),
        .CO({dt0_carry__5_n_0,dt0_carry__5_n_1,dt0_carry__5_n_2,dt0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[27:24]),
        .O(dt0[27:24]),
        .S({dt0_carry__5_i_1_n_0,dt0_carry__5_i_2_n_0,dt0_carry__5_i_3_n_0,dt0_carry__5_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_1
       (.I0(time_curr[27]),
        .I1(time_prev[27]),
        .O(dt0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_2
       (.I0(time_curr[26]),
        .I1(time_prev[26]),
        .O(dt0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_3
       (.I0(time_curr[25]),
        .I1(time_prev[25]),
        .O(dt0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_4
       (.I0(time_curr[24]),
        .I1(time_prev[24]),
        .O(dt0_carry__5_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__6
       (.CI(dt0_carry__5_n_0),
        .CO({dt0_carry__6_n_0,dt0_carry__6_n_1,dt0_carry__6_n_2,dt0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[31:28]),
        .O(dt0[31:28]),
        .S({dt0_carry__6_i_1_n_0,dt0_carry__6_i_2_n_0,dt0_carry__6_i_3_n_0,dt0_carry__6_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_1
       (.I0(time_curr[31]),
        .I1(time_prev[31]),
        .O(dt0_carry__6_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_2
       (.I0(time_curr[30]),
        .I1(time_prev[30]),
        .O(dt0_carry__6_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_3
       (.I0(time_curr[29]),
        .I1(time_prev[29]),
        .O(dt0_carry__6_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_4
       (.I0(time_curr[28]),
        .I1(time_prev[28]),
        .O(dt0_carry__6_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__7
       (.CI(dt0_carry__6_n_0),
        .CO({dt0_carry__7_n_0,dt0_carry__7_n_1,dt0_carry__7_n_2,dt0_carry__7_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[35:32]),
        .O(dt0[35:32]),
        .S({dt0_carry__7_i_1_n_0,dt0_carry__7_i_2_n_0,dt0_carry__7_i_3_n_0,dt0_carry__7_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__7_i_1
       (.I0(time_curr[35]),
        .I1(time_prev[35]),
        .O(dt0_carry__7_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__7_i_2
       (.I0(time_curr[34]),
        .I1(time_prev[34]),
        .O(dt0_carry__7_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__7_i_3
       (.I0(time_curr[33]),
        .I1(time_prev[33]),
        .O(dt0_carry__7_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__7_i_4
       (.I0(time_curr[32]),
        .I1(time_prev[32]),
        .O(dt0_carry__7_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__8
       (.CI(dt0_carry__7_n_0),
        .CO({dt0_carry__8_n_0,dt0_carry__8_n_1,dt0_carry__8_n_2,dt0_carry__8_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[39:36]),
        .O(dt0[39:36]),
        .S({dt0_carry__8_i_1_n_0,dt0_carry__8_i_2_n_0,dt0_carry__8_i_3_n_0,dt0_carry__8_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__8_i_1
       (.I0(time_curr[39]),
        .I1(time_prev[39]),
        .O(dt0_carry__8_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__8_i_2
       (.I0(time_curr[38]),
        .I1(time_prev[38]),
        .O(dt0_carry__8_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__8_i_3
       (.I0(time_curr[37]),
        .I1(time_prev[37]),
        .O(dt0_carry__8_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__8_i_4
       (.I0(time_curr[36]),
        .I1(time_prev[36]),
        .O(dt0_carry__8_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__9
       (.CI(dt0_carry__8_n_0),
        .CO({dt0_carry__9_n_0,dt0_carry__9_n_1,dt0_carry__9_n_2,dt0_carry__9_n_3}),
        .CYINIT(1'b0),
        .DI(time_curr[43:40]),
        .O(dt0[43:40]),
        .S({dt0_carry__9_i_1_n_0,dt0_carry__9_i_2_n_0,dt0_carry__9_i_3_n_0,dt0_carry__9_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__9_i_1
       (.I0(time_curr[43]),
        .I1(time_prev[43]),
        .O(dt0_carry__9_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__9_i_2
       (.I0(time_curr[42]),
        .I1(time_prev[42]),
        .O(dt0_carry__9_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__9_i_3
       (.I0(time_curr[41]),
        .I1(time_prev[41]),
        .O(dt0_carry__9_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__9_i_4
       (.I0(time_curr[40]),
        .I1(time_prev[40]),
        .O(dt0_carry__9_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_1
       (.I0(time_curr[3]),
        .I1(time_prev[3]),
        .O(dt0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_2
       (.I0(time_curr[2]),
        .I1(time_prev[2]),
        .O(dt0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_3
       (.I0(time_curr[1]),
        .I1(time_prev[1]),
        .O(dt0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_4
       (.I0(time_curr[0]),
        .I1(time_prev[0]),
        .O(dt0_carry_i_4_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[0]),
        .Q(dt_out[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[10]),
        .Q(dt_out[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[11]),
        .Q(dt_out[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[12]),
        .Q(dt_out[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[13]),
        .Q(dt_out[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[14]),
        .Q(dt_out[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[15]),
        .Q(dt_out[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[16]),
        .Q(dt_out[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[17]),
        .Q(dt_out[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[18]),
        .Q(dt_out[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[19]),
        .Q(dt_out[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[1]),
        .Q(dt_out[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[20]),
        .Q(dt_out[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[21]),
        .Q(dt_out[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[22]),
        .Q(dt_out[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[23]),
        .Q(dt_out[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[24]),
        .Q(dt_out[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[25]),
        .Q(dt_out[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[26]),
        .Q(dt_out[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[27]),
        .Q(dt_out[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[28]),
        .Q(dt_out[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[29]),
        .Q(dt_out[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[2]),
        .Q(dt_out[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[30]),
        .Q(dt_out[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[31]),
        .Q(dt_out[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[32] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[32]),
        .Q(dt_out[32]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[33] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[33]),
        .Q(dt_out[33]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[34] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[34]),
        .Q(dt_out[34]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[35] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[35]),
        .Q(dt_out[35]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[36] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[36]),
        .Q(dt_out[36]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[37] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[37]),
        .Q(dt_out[37]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[38] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[38]),
        .Q(dt_out[38]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[39] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[39]),
        .Q(dt_out[39]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[3]),
        .Q(dt_out[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[40] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[40]),
        .Q(dt_out[40]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[41] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[41]),
        .Q(dt_out[41]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[42] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[42]),
        .Q(dt_out[42]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[43] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[43]),
        .Q(dt_out[43]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[44] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[44]),
        .Q(dt_out[44]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[45] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[45]),
        .Q(dt_out[45]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[46] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[46]),
        .Q(dt_out[46]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[47] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[47]),
        .Q(dt_out[47]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[48] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[48]),
        .Q(dt_out[48]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[49] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[49]),
        .Q(dt_out[49]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[4]),
        .Q(dt_out[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[50] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[50]),
        .Q(dt_out[50]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[51] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[51]),
        .Q(dt_out[51]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[52] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[52]),
        .Q(dt_out[52]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[53] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[53]),
        .Q(dt_out[53]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[54] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[54]),
        .Q(dt_out[54]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[55] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[55]),
        .Q(dt_out[55]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[56] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[56]),
        .Q(dt_out[56]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[57] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[57]),
        .Q(dt_out[57]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[58] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[58]),
        .Q(dt_out[58]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[59] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[59]),
        .Q(dt_out[59]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[5]),
        .Q(dt_out[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[60] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[60]),
        .Q(dt_out[60]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[61] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[61]),
        .Q(dt_out[61]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[62] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[62]),
        .Q(dt_out[62]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[63] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[63]),
        .Q(dt_out[63]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[6]),
        .Q(dt_out[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[7]),
        .Q(dt_out[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[8]),
        .Q(dt_out[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \dt_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(dt0[9]),
        .Q(dt_out[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[0]),
        .Q(new_time_out[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[10]),
        .Q(new_time_out[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[11]),
        .Q(new_time_out[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[12]),
        .Q(new_time_out[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[13]),
        .Q(new_time_out[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[14]),
        .Q(new_time_out[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[15]),
        .Q(new_time_out[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[16]),
        .Q(new_time_out[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[17]),
        .Q(new_time_out[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[18]),
        .Q(new_time_out[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[19]),
        .Q(new_time_out[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[1]),
        .Q(new_time_out[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[20]),
        .Q(new_time_out[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[21]),
        .Q(new_time_out[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[22]),
        .Q(new_time_out[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[23]),
        .Q(new_time_out[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[24]),
        .Q(new_time_out[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[25]),
        .Q(new_time_out[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[26]),
        .Q(new_time_out[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[27]),
        .Q(new_time_out[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[28]),
        .Q(new_time_out[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[29]),
        .Q(new_time_out[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[2]),
        .Q(new_time_out[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[30]),
        .Q(new_time_out[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[31]),
        .Q(new_time_out[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[32] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[32]),
        .Q(new_time_out[32]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[33] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[33]),
        .Q(new_time_out[33]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[34] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[34]),
        .Q(new_time_out[34]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[35] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[35]),
        .Q(new_time_out[35]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[36] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[36]),
        .Q(new_time_out[36]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[37] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[37]),
        .Q(new_time_out[37]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[38] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[38]),
        .Q(new_time_out[38]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[39] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[39]),
        .Q(new_time_out[39]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[3]),
        .Q(new_time_out[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[40] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[40]),
        .Q(new_time_out[40]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[41] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[41]),
        .Q(new_time_out[41]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[42] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[42]),
        .Q(new_time_out[42]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[43] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[43]),
        .Q(new_time_out[43]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[44] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[44]),
        .Q(new_time_out[44]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[45] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[45]),
        .Q(new_time_out[45]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[46] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[46]),
        .Q(new_time_out[46]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[47] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[47]),
        .Q(new_time_out[47]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[48] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[48]),
        .Q(new_time_out[48]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[49] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[49]),
        .Q(new_time_out[49]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[4]),
        .Q(new_time_out[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[50] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[50]),
        .Q(new_time_out[50]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[51] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[51]),
        .Q(new_time_out[51]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[52] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[52]),
        .Q(new_time_out[52]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[53] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[53]),
        .Q(new_time_out[53]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[54] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[54]),
        .Q(new_time_out[54]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[55] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[55]),
        .Q(new_time_out[55]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[56] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[56]),
        .Q(new_time_out[56]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[57] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[57]),
        .Q(new_time_out[57]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[58] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[58]),
        .Q(new_time_out[58]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[59] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[59]),
        .Q(new_time_out[59]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[5]),
        .Q(new_time_out[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[60] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[60]),
        .Q(new_time_out[60]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[61] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[61]),
        .Q(new_time_out[61]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[62] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[62]),
        .Q(new_time_out[62]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[63] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[63]),
        .Q(new_time_out[63]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[6]),
        .Q(new_time_out[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[7]),
        .Q(new_time_out[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[8]),
        .Q(new_time_out[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_time_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(time_curr[9]),
        .Q(new_time_out[9]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
