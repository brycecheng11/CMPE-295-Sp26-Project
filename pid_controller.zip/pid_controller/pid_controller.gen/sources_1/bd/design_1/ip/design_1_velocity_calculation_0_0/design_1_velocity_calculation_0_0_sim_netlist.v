// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep 21 22:24:09 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top design_1_velocity_calculation_0_0 -prefix
//               design_1_velocity_calculation_0_0_ design_1_velocity_calculation_0_0_sim_netlist.v
// Design      : design_1_velocity_calculation_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_velocity_calculation_0_0,velocity_calculation,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "velocity_calculation,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module design_1_velocity_calculation_0_0
   (clock,
    p_term,
    i_term,
    d_term,
    output_velocity,
    new_velocity_available);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN design_1_sys_clock, INSERT_VIP 0" *) input [0:0]clock;
  input [31:0]p_term;
  input [31:0]i_term;
  input [31:0]d_term;
  output [31:0]output_velocity;
  output [0:0]new_velocity_available;

  wire [0:0]clock;
  wire [31:0]d_term;
  wire [31:0]i_term;
  wire [0:0]new_velocity_available;
  wire [31:0]output_velocity;
  wire [31:0]p_term;

  design_1_velocity_calculation_0_0_velocity_calculation inst
       (.clock(clock),
        .d_term(d_term),
        .i_term(i_term),
        .new_velocity_available(new_velocity_available),
        .output_velocity(output_velocity),
        .p_term(p_term));
endmodule

module design_1_velocity_calculation_0_0_velocity_calculation
   (output_velocity,
    new_velocity_available,
    d_term,
    i_term,
    p_term,
    clock);
  output [31:0]output_velocity;
  output [0:0]new_velocity_available;
  input [31:0]d_term;
  input [31:0]i_term;
  input [31:0]p_term;
  input [0:0]clock;

  wire [0:0]clock;
  wire [31:0]d_term;
  wire [31:0]i_term;
  wire [31:0]interim;
  wire \interim[11]_i_2_n_0 ;
  wire \interim[11]_i_3_n_0 ;
  wire \interim[11]_i_4_n_0 ;
  wire \interim[11]_i_5_n_0 ;
  wire \interim[11]_i_6_n_0 ;
  wire \interim[11]_i_7_n_0 ;
  wire \interim[11]_i_8_n_0 ;
  wire \interim[11]_i_9_n_0 ;
  wire \interim[15]_i_2_n_0 ;
  wire \interim[15]_i_3_n_0 ;
  wire \interim[15]_i_4_n_0 ;
  wire \interim[15]_i_5_n_0 ;
  wire \interim[15]_i_6_n_0 ;
  wire \interim[15]_i_7_n_0 ;
  wire \interim[15]_i_8_n_0 ;
  wire \interim[15]_i_9_n_0 ;
  wire \interim[19]_i_2_n_0 ;
  wire \interim[19]_i_3_n_0 ;
  wire \interim[19]_i_4_n_0 ;
  wire \interim[19]_i_5_n_0 ;
  wire \interim[19]_i_6_n_0 ;
  wire \interim[19]_i_7_n_0 ;
  wire \interim[19]_i_8_n_0 ;
  wire \interim[19]_i_9_n_0 ;
  wire \interim[23]_i_2_n_0 ;
  wire \interim[23]_i_3_n_0 ;
  wire \interim[23]_i_4_n_0 ;
  wire \interim[23]_i_5_n_0 ;
  wire \interim[23]_i_6_n_0 ;
  wire \interim[23]_i_7_n_0 ;
  wire \interim[23]_i_8_n_0 ;
  wire \interim[23]_i_9_n_0 ;
  wire \interim[27]_i_2_n_0 ;
  wire \interim[27]_i_3_n_0 ;
  wire \interim[27]_i_4_n_0 ;
  wire \interim[27]_i_5_n_0 ;
  wire \interim[27]_i_6_n_0 ;
  wire \interim[27]_i_7_n_0 ;
  wire \interim[27]_i_8_n_0 ;
  wire \interim[27]_i_9_n_0 ;
  wire \interim[31]_i_2_n_0 ;
  wire \interim[31]_i_3_n_0 ;
  wire \interim[31]_i_4_n_0 ;
  wire \interim[31]_i_5_n_0 ;
  wire \interim[31]_i_6_n_0 ;
  wire \interim[31]_i_7_n_0 ;
  wire \interim[31]_i_8_n_0 ;
  wire \interim[3]_i_2_n_0 ;
  wire \interim[3]_i_3_n_0 ;
  wire \interim[3]_i_4_n_0 ;
  wire \interim[3]_i_5_n_0 ;
  wire \interim[3]_i_6_n_0 ;
  wire \interim[3]_i_7_n_0 ;
  wire \interim[3]_i_8_n_0 ;
  wire \interim[7]_i_2_n_0 ;
  wire \interim[7]_i_3_n_0 ;
  wire \interim[7]_i_4_n_0 ;
  wire \interim[7]_i_5_n_0 ;
  wire \interim[7]_i_6_n_0 ;
  wire \interim[7]_i_7_n_0 ;
  wire \interim[7]_i_8_n_0 ;
  wire \interim[7]_i_9_n_0 ;
  wire \interim_reg[11]_i_1_n_0 ;
  wire \interim_reg[11]_i_1_n_1 ;
  wire \interim_reg[11]_i_1_n_2 ;
  wire \interim_reg[11]_i_1_n_3 ;
  wire \interim_reg[15]_i_1_n_0 ;
  wire \interim_reg[15]_i_1_n_1 ;
  wire \interim_reg[15]_i_1_n_2 ;
  wire \interim_reg[15]_i_1_n_3 ;
  wire \interim_reg[19]_i_1_n_0 ;
  wire \interim_reg[19]_i_1_n_1 ;
  wire \interim_reg[19]_i_1_n_2 ;
  wire \interim_reg[19]_i_1_n_3 ;
  wire \interim_reg[23]_i_1_n_0 ;
  wire \interim_reg[23]_i_1_n_1 ;
  wire \interim_reg[23]_i_1_n_2 ;
  wire \interim_reg[23]_i_1_n_3 ;
  wire \interim_reg[27]_i_1_n_0 ;
  wire \interim_reg[27]_i_1_n_1 ;
  wire \interim_reg[27]_i_1_n_2 ;
  wire \interim_reg[27]_i_1_n_3 ;
  wire \interim_reg[31]_i_1_n_1 ;
  wire \interim_reg[31]_i_1_n_2 ;
  wire \interim_reg[31]_i_1_n_3 ;
  wire \interim_reg[3]_i_1_n_0 ;
  wire \interim_reg[3]_i_1_n_1 ;
  wire \interim_reg[3]_i_1_n_2 ;
  wire \interim_reg[3]_i_1_n_3 ;
  wire \interim_reg[7]_i_1_n_0 ;
  wire \interim_reg[7]_i_1_n_1 ;
  wire \interim_reg[7]_i_1_n_2 ;
  wire \interim_reg[7]_i_1_n_3 ;
  wire [0:0]new_velocity_available;
  wire [31:0]output_velocity;
  wire [31:0]p_0_in;
  wire [31:0]p_term;
  wire \velocity[31]_i_10_n_0 ;
  wire \velocity[31]_i_11_n_0 ;
  wire \velocity[31]_i_12_n_0 ;
  wire \velocity[31]_i_13_n_0 ;
  wire \velocity[31]_i_14_n_0 ;
  wire \velocity[31]_i_3_n_0 ;
  wire \velocity[31]_i_4_n_0 ;
  wire \velocity[31]_i_5_n_0 ;
  wire \velocity[31]_i_7_n_0 ;
  wire \velocity[31]_i_8_n_0 ;
  wire \velocity[31]_i_9_n_0 ;
  wire \velocity_reg[31]_i_1_n_1 ;
  wire \velocity_reg[31]_i_1_n_2 ;
  wire \velocity_reg[31]_i_1_n_3 ;
  wire \velocity_reg[31]_i_2_n_0 ;
  wire \velocity_reg[31]_i_2_n_1 ;
  wire \velocity_reg[31]_i_2_n_2 ;
  wire \velocity_reg[31]_i_2_n_3 ;
  wire \velocity_reg[31]_i_6_n_0 ;
  wire \velocity_reg[31]_i_6_n_1 ;
  wire \velocity_reg[31]_i_6_n_2 ;
  wire \velocity_reg[31]_i_6_n_3 ;
  wire [3:3]\NLW_interim_reg[31]_i_1_CO_UNCONNECTED ;
  wire [3:3]\NLW_velocity_reg[31]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_velocity_reg[31]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_velocity_reg[31]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_velocity_reg[31]_i_6_O_UNCONNECTED ;

  (* HLUTNM = "lutpair10" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[11]_i_2 
       (.I0(i_term[10]),
        .I1(d_term[10]),
        .I2(p_term[10]),
        .O(\interim[11]_i_2_n_0 ));
  (* HLUTNM = "lutpair9" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[11]_i_3 
       (.I0(i_term[9]),
        .I1(d_term[9]),
        .I2(p_term[9]),
        .O(\interim[11]_i_3_n_0 ));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[11]_i_4 
       (.I0(i_term[8]),
        .I1(d_term[8]),
        .I2(p_term[8]),
        .O(\interim[11]_i_4_n_0 ));
  (* HLUTNM = "lutpair7" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[11]_i_5 
       (.I0(i_term[7]),
        .I1(d_term[7]),
        .I2(p_term[7]),
        .O(\interim[11]_i_5_n_0 ));
  (* HLUTNM = "lutpair11" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[11]_i_6 
       (.I0(i_term[11]),
        .I1(d_term[11]),
        .I2(p_term[11]),
        .I3(\interim[11]_i_2_n_0 ),
        .O(\interim[11]_i_6_n_0 ));
  (* HLUTNM = "lutpair10" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[11]_i_7 
       (.I0(i_term[10]),
        .I1(d_term[10]),
        .I2(p_term[10]),
        .I3(\interim[11]_i_3_n_0 ),
        .O(\interim[11]_i_7_n_0 ));
  (* HLUTNM = "lutpair9" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[11]_i_8 
       (.I0(i_term[9]),
        .I1(d_term[9]),
        .I2(p_term[9]),
        .I3(\interim[11]_i_4_n_0 ),
        .O(\interim[11]_i_8_n_0 ));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[11]_i_9 
       (.I0(i_term[8]),
        .I1(d_term[8]),
        .I2(p_term[8]),
        .I3(\interim[11]_i_5_n_0 ),
        .O(\interim[11]_i_9_n_0 ));
  (* HLUTNM = "lutpair14" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[15]_i_2 
       (.I0(i_term[14]),
        .I1(d_term[14]),
        .I2(p_term[14]),
        .O(\interim[15]_i_2_n_0 ));
  (* HLUTNM = "lutpair13" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[15]_i_3 
       (.I0(i_term[13]),
        .I1(d_term[13]),
        .I2(p_term[13]),
        .O(\interim[15]_i_3_n_0 ));
  (* HLUTNM = "lutpair12" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[15]_i_4 
       (.I0(i_term[12]),
        .I1(d_term[12]),
        .I2(p_term[12]),
        .O(\interim[15]_i_4_n_0 ));
  (* HLUTNM = "lutpair11" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[15]_i_5 
       (.I0(i_term[11]),
        .I1(d_term[11]),
        .I2(p_term[11]),
        .O(\interim[15]_i_5_n_0 ));
  (* HLUTNM = "lutpair15" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[15]_i_6 
       (.I0(i_term[15]),
        .I1(d_term[15]),
        .I2(p_term[15]),
        .I3(\interim[15]_i_2_n_0 ),
        .O(\interim[15]_i_6_n_0 ));
  (* HLUTNM = "lutpair14" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[15]_i_7 
       (.I0(i_term[14]),
        .I1(d_term[14]),
        .I2(p_term[14]),
        .I3(\interim[15]_i_3_n_0 ),
        .O(\interim[15]_i_7_n_0 ));
  (* HLUTNM = "lutpair13" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[15]_i_8 
       (.I0(i_term[13]),
        .I1(d_term[13]),
        .I2(p_term[13]),
        .I3(\interim[15]_i_4_n_0 ),
        .O(\interim[15]_i_8_n_0 ));
  (* HLUTNM = "lutpair12" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[15]_i_9 
       (.I0(i_term[12]),
        .I1(d_term[12]),
        .I2(p_term[12]),
        .I3(\interim[15]_i_5_n_0 ),
        .O(\interim[15]_i_9_n_0 ));
  (* HLUTNM = "lutpair18" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[19]_i_2 
       (.I0(i_term[18]),
        .I1(d_term[18]),
        .I2(p_term[18]),
        .O(\interim[19]_i_2_n_0 ));
  (* HLUTNM = "lutpair17" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[19]_i_3 
       (.I0(i_term[17]),
        .I1(d_term[17]),
        .I2(p_term[17]),
        .O(\interim[19]_i_3_n_0 ));
  (* HLUTNM = "lutpair16" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[19]_i_4 
       (.I0(i_term[16]),
        .I1(d_term[16]),
        .I2(p_term[16]),
        .O(\interim[19]_i_4_n_0 ));
  (* HLUTNM = "lutpair15" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[19]_i_5 
       (.I0(i_term[15]),
        .I1(d_term[15]),
        .I2(p_term[15]),
        .O(\interim[19]_i_5_n_0 ));
  (* HLUTNM = "lutpair19" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[19]_i_6 
       (.I0(i_term[19]),
        .I1(d_term[19]),
        .I2(p_term[19]),
        .I3(\interim[19]_i_2_n_0 ),
        .O(\interim[19]_i_6_n_0 ));
  (* HLUTNM = "lutpair18" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[19]_i_7 
       (.I0(i_term[18]),
        .I1(d_term[18]),
        .I2(p_term[18]),
        .I3(\interim[19]_i_3_n_0 ),
        .O(\interim[19]_i_7_n_0 ));
  (* HLUTNM = "lutpair17" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[19]_i_8 
       (.I0(i_term[17]),
        .I1(d_term[17]),
        .I2(p_term[17]),
        .I3(\interim[19]_i_4_n_0 ),
        .O(\interim[19]_i_8_n_0 ));
  (* HLUTNM = "lutpair16" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[19]_i_9 
       (.I0(i_term[16]),
        .I1(d_term[16]),
        .I2(p_term[16]),
        .I3(\interim[19]_i_5_n_0 ),
        .O(\interim[19]_i_9_n_0 ));
  (* HLUTNM = "lutpair22" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[23]_i_2 
       (.I0(i_term[22]),
        .I1(d_term[22]),
        .I2(p_term[22]),
        .O(\interim[23]_i_2_n_0 ));
  (* HLUTNM = "lutpair21" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[23]_i_3 
       (.I0(i_term[21]),
        .I1(d_term[21]),
        .I2(p_term[21]),
        .O(\interim[23]_i_3_n_0 ));
  (* HLUTNM = "lutpair20" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[23]_i_4 
       (.I0(i_term[20]),
        .I1(d_term[20]),
        .I2(p_term[20]),
        .O(\interim[23]_i_4_n_0 ));
  (* HLUTNM = "lutpair19" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[23]_i_5 
       (.I0(i_term[19]),
        .I1(d_term[19]),
        .I2(p_term[19]),
        .O(\interim[23]_i_5_n_0 ));
  (* HLUTNM = "lutpair23" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[23]_i_6 
       (.I0(i_term[23]),
        .I1(d_term[23]),
        .I2(p_term[23]),
        .I3(\interim[23]_i_2_n_0 ),
        .O(\interim[23]_i_6_n_0 ));
  (* HLUTNM = "lutpair22" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[23]_i_7 
       (.I0(i_term[22]),
        .I1(d_term[22]),
        .I2(p_term[22]),
        .I3(\interim[23]_i_3_n_0 ),
        .O(\interim[23]_i_7_n_0 ));
  (* HLUTNM = "lutpair21" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[23]_i_8 
       (.I0(i_term[21]),
        .I1(d_term[21]),
        .I2(p_term[21]),
        .I3(\interim[23]_i_4_n_0 ),
        .O(\interim[23]_i_8_n_0 ));
  (* HLUTNM = "lutpair20" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[23]_i_9 
       (.I0(i_term[20]),
        .I1(d_term[20]),
        .I2(p_term[20]),
        .I3(\interim[23]_i_5_n_0 ),
        .O(\interim[23]_i_9_n_0 ));
  (* HLUTNM = "lutpair26" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[27]_i_2 
       (.I0(i_term[26]),
        .I1(d_term[26]),
        .I2(p_term[26]),
        .O(\interim[27]_i_2_n_0 ));
  (* HLUTNM = "lutpair25" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[27]_i_3 
       (.I0(i_term[25]),
        .I1(d_term[25]),
        .I2(p_term[25]),
        .O(\interim[27]_i_3_n_0 ));
  (* HLUTNM = "lutpair24" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[27]_i_4 
       (.I0(i_term[24]),
        .I1(d_term[24]),
        .I2(p_term[24]),
        .O(\interim[27]_i_4_n_0 ));
  (* HLUTNM = "lutpair23" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[27]_i_5 
       (.I0(i_term[23]),
        .I1(d_term[23]),
        .I2(p_term[23]),
        .O(\interim[27]_i_5_n_0 ));
  (* HLUTNM = "lutpair27" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[27]_i_6 
       (.I0(i_term[27]),
        .I1(d_term[27]),
        .I2(p_term[27]),
        .I3(\interim[27]_i_2_n_0 ),
        .O(\interim[27]_i_6_n_0 ));
  (* HLUTNM = "lutpair26" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[27]_i_7 
       (.I0(i_term[26]),
        .I1(d_term[26]),
        .I2(p_term[26]),
        .I3(\interim[27]_i_3_n_0 ),
        .O(\interim[27]_i_7_n_0 ));
  (* HLUTNM = "lutpair25" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[27]_i_8 
       (.I0(i_term[25]),
        .I1(d_term[25]),
        .I2(p_term[25]),
        .I3(\interim[27]_i_4_n_0 ),
        .O(\interim[27]_i_8_n_0 ));
  (* HLUTNM = "lutpair24" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[27]_i_9 
       (.I0(i_term[24]),
        .I1(d_term[24]),
        .I2(p_term[24]),
        .I3(\interim[27]_i_5_n_0 ),
        .O(\interim[27]_i_9_n_0 ));
  (* HLUTNM = "lutpair29" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[31]_i_2 
       (.I0(i_term[29]),
        .I1(d_term[29]),
        .I2(p_term[29]),
        .O(\interim[31]_i_2_n_0 ));
  (* HLUTNM = "lutpair28" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[31]_i_3 
       (.I0(i_term[28]),
        .I1(d_term[28]),
        .I2(p_term[28]),
        .O(\interim[31]_i_3_n_0 ));
  (* HLUTNM = "lutpair27" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[31]_i_4 
       (.I0(i_term[27]),
        .I1(d_term[27]),
        .I2(p_term[27]),
        .O(\interim[31]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    \interim[31]_i_5 
       (.I0(p_term[30]),
        .I1(d_term[30]),
        .I2(i_term[30]),
        .I3(d_term[31]),
        .I4(i_term[31]),
        .I5(p_term[31]),
        .O(\interim[31]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[31]_i_6 
       (.I0(\interim[31]_i_2_n_0 ),
        .I1(d_term[30]),
        .I2(i_term[30]),
        .I3(p_term[30]),
        .O(\interim[31]_i_6_n_0 ));
  (* HLUTNM = "lutpair29" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[31]_i_7 
       (.I0(i_term[29]),
        .I1(d_term[29]),
        .I2(p_term[29]),
        .I3(\interim[31]_i_3_n_0 ),
        .O(\interim[31]_i_7_n_0 ));
  (* HLUTNM = "lutpair28" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[31]_i_8 
       (.I0(i_term[28]),
        .I1(d_term[28]),
        .I2(p_term[28]),
        .I3(\interim[31]_i_4_n_0 ),
        .O(\interim[31]_i_8_n_0 ));
  (* HLUTNM = "lutpair2" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[3]_i_2 
       (.I0(i_term[2]),
        .I1(d_term[2]),
        .I2(p_term[2]),
        .O(\interim[3]_i_2_n_0 ));
  (* HLUTNM = "lutpair1" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[3]_i_3 
       (.I0(i_term[1]),
        .I1(d_term[1]),
        .I2(p_term[1]),
        .O(\interim[3]_i_3_n_0 ));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[3]_i_4 
       (.I0(i_term[0]),
        .I1(d_term[0]),
        .I2(p_term[0]),
        .O(\interim[3]_i_4_n_0 ));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[3]_i_5 
       (.I0(i_term[3]),
        .I1(d_term[3]),
        .I2(p_term[3]),
        .I3(\interim[3]_i_2_n_0 ),
        .O(\interim[3]_i_5_n_0 ));
  (* HLUTNM = "lutpair2" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[3]_i_6 
       (.I0(i_term[2]),
        .I1(d_term[2]),
        .I2(p_term[2]),
        .I3(\interim[3]_i_3_n_0 ),
        .O(\interim[3]_i_6_n_0 ));
  (* HLUTNM = "lutpair1" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[3]_i_7 
       (.I0(i_term[1]),
        .I1(d_term[1]),
        .I2(p_term[1]),
        .I3(\interim[3]_i_4_n_0 ),
        .O(\interim[3]_i_7_n_0 ));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \interim[3]_i_8 
       (.I0(i_term[0]),
        .I1(d_term[0]),
        .I2(p_term[0]),
        .O(\interim[3]_i_8_n_0 ));
  (* HLUTNM = "lutpair6" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[7]_i_2 
       (.I0(i_term[6]),
        .I1(d_term[6]),
        .I2(p_term[6]),
        .O(\interim[7]_i_2_n_0 ));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[7]_i_3 
       (.I0(i_term[5]),
        .I1(d_term[5]),
        .I2(p_term[5]),
        .O(\interim[7]_i_3_n_0 ));
  (* HLUTNM = "lutpair4" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[7]_i_4 
       (.I0(i_term[4]),
        .I1(d_term[4]),
        .I2(p_term[4]),
        .O(\interim[7]_i_4_n_0 ));
  (* HLUTNM = "lutpair3" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \interim[7]_i_5 
       (.I0(i_term[3]),
        .I1(d_term[3]),
        .I2(p_term[3]),
        .O(\interim[7]_i_5_n_0 ));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[7]_i_6 
       (.I0(i_term[7]),
        .I1(d_term[7]),
        .I2(p_term[7]),
        .I3(\interim[7]_i_2_n_0 ),
        .O(\interim[7]_i_6_n_0 ));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[7]_i_7 
       (.I0(i_term[6]),
        .I1(d_term[6]),
        .I2(p_term[6]),
        .I3(\interim[7]_i_3_n_0 ),
        .O(\interim[7]_i_7_n_0 ));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[7]_i_8 
       (.I0(i_term[5]),
        .I1(d_term[5]),
        .I2(p_term[5]),
        .I3(\interim[7]_i_4_n_0 ),
        .O(\interim[7]_i_8_n_0 ));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \interim[7]_i_9 
       (.I0(i_term[4]),
        .I1(d_term[4]),
        .I2(p_term[4]),
        .I3(\interim[7]_i_5_n_0 ),
        .O(\interim[7]_i_9_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(interim[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[10]),
        .Q(interim[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[11]),
        .Q(interim[11]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[11]_i_1 
       (.CI(\interim_reg[7]_i_1_n_0 ),
        .CO({\interim_reg[11]_i_1_n_0 ,\interim_reg[11]_i_1_n_1 ,\interim_reg[11]_i_1_n_2 ,\interim_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[11]_i_2_n_0 ,\interim[11]_i_3_n_0 ,\interim[11]_i_4_n_0 ,\interim[11]_i_5_n_0 }),
        .O(p_0_in[11:8]),
        .S({\interim[11]_i_6_n_0 ,\interim[11]_i_7_n_0 ,\interim[11]_i_8_n_0 ,\interim[11]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[12]),
        .Q(interim[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[13]),
        .Q(interim[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[14]),
        .Q(interim[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[15]),
        .Q(interim[15]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[15]_i_1 
       (.CI(\interim_reg[11]_i_1_n_0 ),
        .CO({\interim_reg[15]_i_1_n_0 ,\interim_reg[15]_i_1_n_1 ,\interim_reg[15]_i_1_n_2 ,\interim_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[15]_i_2_n_0 ,\interim[15]_i_3_n_0 ,\interim[15]_i_4_n_0 ,\interim[15]_i_5_n_0 }),
        .O(p_0_in[15:12]),
        .S({\interim[15]_i_6_n_0 ,\interim[15]_i_7_n_0 ,\interim[15]_i_8_n_0 ,\interim[15]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[16]),
        .Q(interim[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[17]),
        .Q(interim[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[18]),
        .Q(interim[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[19]),
        .Q(interim[19]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[19]_i_1 
       (.CI(\interim_reg[15]_i_1_n_0 ),
        .CO({\interim_reg[19]_i_1_n_0 ,\interim_reg[19]_i_1_n_1 ,\interim_reg[19]_i_1_n_2 ,\interim_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[19]_i_2_n_0 ,\interim[19]_i_3_n_0 ,\interim[19]_i_4_n_0 ,\interim[19]_i_5_n_0 }),
        .O(p_0_in[19:16]),
        .S({\interim[19]_i_6_n_0 ,\interim[19]_i_7_n_0 ,\interim[19]_i_8_n_0 ,\interim[19]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(interim[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[20]),
        .Q(interim[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[21]),
        .Q(interim[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[22]),
        .Q(interim[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[23]),
        .Q(interim[23]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[23]_i_1 
       (.CI(\interim_reg[19]_i_1_n_0 ),
        .CO({\interim_reg[23]_i_1_n_0 ,\interim_reg[23]_i_1_n_1 ,\interim_reg[23]_i_1_n_2 ,\interim_reg[23]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[23]_i_2_n_0 ,\interim[23]_i_3_n_0 ,\interim[23]_i_4_n_0 ,\interim[23]_i_5_n_0 }),
        .O(p_0_in[23:20]),
        .S({\interim[23]_i_6_n_0 ,\interim[23]_i_7_n_0 ,\interim[23]_i_8_n_0 ,\interim[23]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[24]),
        .Q(interim[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[25]),
        .Q(interim[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[26]),
        .Q(interim[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[27]),
        .Q(interim[27]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[27]_i_1 
       (.CI(\interim_reg[23]_i_1_n_0 ),
        .CO({\interim_reg[27]_i_1_n_0 ,\interim_reg[27]_i_1_n_1 ,\interim_reg[27]_i_1_n_2 ,\interim_reg[27]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[27]_i_2_n_0 ,\interim[27]_i_3_n_0 ,\interim[27]_i_4_n_0 ,\interim[27]_i_5_n_0 }),
        .O(p_0_in[27:24]),
        .S({\interim[27]_i_6_n_0 ,\interim[27]_i_7_n_0 ,\interim[27]_i_8_n_0 ,\interim[27]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[28]),
        .Q(interim[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[29]),
        .Q(interim[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(interim[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[30]),
        .Q(interim[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[31]),
        .Q(interim[31]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[31]_i_1 
       (.CI(\interim_reg[27]_i_1_n_0 ),
        .CO({\NLW_interim_reg[31]_i_1_CO_UNCONNECTED [3],\interim_reg[31]_i_1_n_1 ,\interim_reg[31]_i_1_n_2 ,\interim_reg[31]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\interim[31]_i_2_n_0 ,\interim[31]_i_3_n_0 ,\interim[31]_i_4_n_0 }),
        .O(p_0_in[31:28]),
        .S({\interim[31]_i_5_n_0 ,\interim[31]_i_6_n_0 ,\interim[31]_i_7_n_0 ,\interim[31]_i_8_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(interim[3]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\interim_reg[3]_i_1_n_0 ,\interim_reg[3]_i_1_n_1 ,\interim_reg[3]_i_1_n_2 ,\interim_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[3]_i_2_n_0 ,\interim[3]_i_3_n_0 ,\interim[3]_i_4_n_0 ,1'b0}),
        .O(p_0_in[3:0]),
        .S({\interim[3]_i_5_n_0 ,\interim[3]_i_6_n_0 ,\interim[3]_i_7_n_0 ,\interim[3]_i_8_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(interim[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[5]),
        .Q(interim[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[6]),
        .Q(interim[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[7]),
        .Q(interim[7]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \interim_reg[7]_i_1 
       (.CI(\interim_reg[3]_i_1_n_0 ),
        .CO({\interim_reg[7]_i_1_n_0 ,\interim_reg[7]_i_1_n_1 ,\interim_reg[7]_i_1_n_2 ,\interim_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\interim[7]_i_2_n_0 ,\interim[7]_i_3_n_0 ,\interim[7]_i_4_n_0 ,\interim[7]_i_5_n_0 }),
        .O(p_0_in[7:4]),
        .S({\interim[7]_i_6_n_0 ,\interim[7]_i_7_n_0 ,\interim[7]_i_8_n_0 ,\interim[7]_i_9_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[8]),
        .Q(interim[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \interim_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in[9]),
        .Q(interim[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \new_velocity_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(\velocity_reg[31]_i_1_n_1 ),
        .Q(new_velocity_available),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_10 
       (.I0(output_velocity[12]),
        .I1(interim[12]),
        .I2(interim[14]),
        .I3(output_velocity[14]),
        .I4(interim[13]),
        .I5(output_velocity[13]),
        .O(\velocity[31]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_11 
       (.I0(output_velocity[9]),
        .I1(interim[9]),
        .I2(interim[11]),
        .I3(output_velocity[11]),
        .I4(interim[10]),
        .I5(output_velocity[10]),
        .O(\velocity[31]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_12 
       (.I0(output_velocity[6]),
        .I1(interim[6]),
        .I2(interim[8]),
        .I3(output_velocity[8]),
        .I4(interim[7]),
        .I5(output_velocity[7]),
        .O(\velocity[31]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_13 
       (.I0(output_velocity[3]),
        .I1(interim[3]),
        .I2(interim[5]),
        .I3(output_velocity[5]),
        .I4(interim[4]),
        .I5(output_velocity[4]),
        .O(\velocity[31]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_14 
       (.I0(output_velocity[0]),
        .I1(interim[0]),
        .I2(interim[2]),
        .I3(output_velocity[2]),
        .I4(interim[1]),
        .I5(output_velocity[1]),
        .O(\velocity[31]_i_14_n_0 ));
  LUT4 #(
    .INIT(16'h9009)) 
    \velocity[31]_i_3 
       (.I0(output_velocity[30]),
        .I1(interim[30]),
        .I2(output_velocity[31]),
        .I3(interim[31]),
        .O(\velocity[31]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_4 
       (.I0(output_velocity[27]),
        .I1(interim[27]),
        .I2(interim[29]),
        .I3(output_velocity[29]),
        .I4(interim[28]),
        .I5(output_velocity[28]),
        .O(\velocity[31]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_5 
       (.I0(output_velocity[24]),
        .I1(interim[24]),
        .I2(interim[26]),
        .I3(output_velocity[26]),
        .I4(interim[25]),
        .I5(output_velocity[25]),
        .O(\velocity[31]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_7 
       (.I0(output_velocity[21]),
        .I1(interim[21]),
        .I2(interim[23]),
        .I3(output_velocity[23]),
        .I4(interim[22]),
        .I5(output_velocity[22]),
        .O(\velocity[31]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_8 
       (.I0(output_velocity[18]),
        .I1(interim[18]),
        .I2(interim[20]),
        .I3(output_velocity[20]),
        .I4(interim[19]),
        .I5(output_velocity[19]),
        .O(\velocity[31]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \velocity[31]_i_9 
       (.I0(output_velocity[15]),
        .I1(interim[15]),
        .I2(interim[17]),
        .I3(output_velocity[17]),
        .I4(interim[16]),
        .I5(output_velocity[16]),
        .O(\velocity[31]_i_9_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[0] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[0]),
        .Q(output_velocity[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[10] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[10]),
        .Q(output_velocity[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[11] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[11]),
        .Q(output_velocity[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[12] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[12]),
        .Q(output_velocity[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[13] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[13]),
        .Q(output_velocity[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[14] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[14]),
        .Q(output_velocity[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[15] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[15]),
        .Q(output_velocity[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[16] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[16]),
        .Q(output_velocity[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[17] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[17]),
        .Q(output_velocity[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[18] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[18]),
        .Q(output_velocity[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[19] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[19]),
        .Q(output_velocity[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[1] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[1]),
        .Q(output_velocity[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[20] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[20]),
        .Q(output_velocity[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[21] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[21]),
        .Q(output_velocity[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[22] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[22]),
        .Q(output_velocity[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[23] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[23]),
        .Q(output_velocity[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[24] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[24]),
        .Q(output_velocity[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[25] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[25]),
        .Q(output_velocity[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[26] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[26]),
        .Q(output_velocity[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[27] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[27]),
        .Q(output_velocity[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[28] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[28]),
        .Q(output_velocity[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[29] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[29]),
        .Q(output_velocity[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[2] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[2]),
        .Q(output_velocity[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[30] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[30]),
        .Q(output_velocity[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[31] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[31]),
        .Q(output_velocity[31]),
        .R(1'b0));
  CARRY4 \velocity_reg[31]_i_1 
       (.CI(\velocity_reg[31]_i_2_n_0 ),
        .CO({\NLW_velocity_reg[31]_i_1_CO_UNCONNECTED [3],\velocity_reg[31]_i_1_n_1 ,\velocity_reg[31]_i_1_n_2 ,\velocity_reg[31]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b1,1'b1,1'b1}),
        .O(\NLW_velocity_reg[31]_i_1_O_UNCONNECTED [3:0]),
        .S({1'b0,\velocity[31]_i_3_n_0 ,\velocity[31]_i_4_n_0 ,\velocity[31]_i_5_n_0 }));
  CARRY4 \velocity_reg[31]_i_2 
       (.CI(\velocity_reg[31]_i_6_n_0 ),
        .CO({\velocity_reg[31]_i_2_n_0 ,\velocity_reg[31]_i_2_n_1 ,\velocity_reg[31]_i_2_n_2 ,\velocity_reg[31]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O(\NLW_velocity_reg[31]_i_2_O_UNCONNECTED [3:0]),
        .S({\velocity[31]_i_7_n_0 ,\velocity[31]_i_8_n_0 ,\velocity[31]_i_9_n_0 ,\velocity[31]_i_10_n_0 }));
  CARRY4 \velocity_reg[31]_i_6 
       (.CI(1'b0),
        .CO({\velocity_reg[31]_i_6_n_0 ,\velocity_reg[31]_i_6_n_1 ,\velocity_reg[31]_i_6_n_2 ,\velocity_reg[31]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O(\NLW_velocity_reg[31]_i_6_O_UNCONNECTED [3:0]),
        .S({\velocity[31]_i_11_n_0 ,\velocity[31]_i_12_n_0 ,\velocity[31]_i_13_n_0 ,\velocity[31]_i_14_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[3] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[3]),
        .Q(output_velocity[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[4] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[4]),
        .Q(output_velocity[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[5] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[5]),
        .Q(output_velocity[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[6] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[6]),
        .Q(output_velocity[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[7] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[7]),
        .Q(output_velocity[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[8] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[8]),
        .Q(output_velocity[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[9] 
       (.C(clock),
        .CE(\velocity_reg[31]_i_1_n_1 ),
        .D(interim[9]),
        .Q(output_velocity[9]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
