-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Mon Sep 21 22:24:09 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top design_1_velocity_calculation_0_0 -prefix
--               design_1_velocity_calculation_0_0_ design_1_velocity_calculation_0_0_stub.vhdl
-- Design      : design_1_velocity_calculation_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_velocity_calculation_0_0 is
  Port ( 
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    p_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 )
  );

end design_1_velocity_calculation_0_0;

architecture stub of design_1_velocity_calculation_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock[0:0],p_term[31:0],i_term[31:0],d_term[31:0],output_velocity[31:0],new_velocity_available[0:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "velocity_calculation,Vivado 2021.1";
begin
end;
