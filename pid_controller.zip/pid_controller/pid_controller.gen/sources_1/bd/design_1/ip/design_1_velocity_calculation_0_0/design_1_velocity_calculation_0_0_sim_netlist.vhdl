-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Mon Sep 21 22:24:09 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top design_1_velocity_calculation_0_0 -prefix
--               design_1_velocity_calculation_0_0_ design_1_velocity_calculation_0_0_sim_netlist.vhdl
-- Design      : design_1_velocity_calculation_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_velocity_calculation_0_0_velocity_calculation is
  port (
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 );
    d_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    p_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clock : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
end design_1_velocity_calculation_0_0_velocity_calculation;

architecture STRUCTURE of design_1_velocity_calculation_0_0_velocity_calculation is
  signal interim : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \interim[11]_i_2_n_0\ : STD_LOGIC;
  signal \interim[11]_i_3_n_0\ : STD_LOGIC;
  signal \interim[11]_i_4_n_0\ : STD_LOGIC;
  signal \interim[11]_i_5_n_0\ : STD_LOGIC;
  signal \interim[11]_i_6_n_0\ : STD_LOGIC;
  signal \interim[11]_i_7_n_0\ : STD_LOGIC;
  signal \interim[11]_i_8_n_0\ : STD_LOGIC;
  signal \interim[11]_i_9_n_0\ : STD_LOGIC;
  signal \interim[15]_i_2_n_0\ : STD_LOGIC;
  signal \interim[15]_i_3_n_0\ : STD_LOGIC;
  signal \interim[15]_i_4_n_0\ : STD_LOGIC;
  signal \interim[15]_i_5_n_0\ : STD_LOGIC;
  signal \interim[15]_i_6_n_0\ : STD_LOGIC;
  signal \interim[15]_i_7_n_0\ : STD_LOGIC;
  signal \interim[15]_i_8_n_0\ : STD_LOGIC;
  signal \interim[15]_i_9_n_0\ : STD_LOGIC;
  signal \interim[19]_i_2_n_0\ : STD_LOGIC;
  signal \interim[19]_i_3_n_0\ : STD_LOGIC;
  signal \interim[19]_i_4_n_0\ : STD_LOGIC;
  signal \interim[19]_i_5_n_0\ : STD_LOGIC;
  signal \interim[19]_i_6_n_0\ : STD_LOGIC;
  signal \interim[19]_i_7_n_0\ : STD_LOGIC;
  signal \interim[19]_i_8_n_0\ : STD_LOGIC;
  signal \interim[19]_i_9_n_0\ : STD_LOGIC;
  signal \interim[23]_i_2_n_0\ : STD_LOGIC;
  signal \interim[23]_i_3_n_0\ : STD_LOGIC;
  signal \interim[23]_i_4_n_0\ : STD_LOGIC;
  signal \interim[23]_i_5_n_0\ : STD_LOGIC;
  signal \interim[23]_i_6_n_0\ : STD_LOGIC;
  signal \interim[23]_i_7_n_0\ : STD_LOGIC;
  signal \interim[23]_i_8_n_0\ : STD_LOGIC;
  signal \interim[23]_i_9_n_0\ : STD_LOGIC;
  signal \interim[27]_i_2_n_0\ : STD_LOGIC;
  signal \interim[27]_i_3_n_0\ : STD_LOGIC;
  signal \interim[27]_i_4_n_0\ : STD_LOGIC;
  signal \interim[27]_i_5_n_0\ : STD_LOGIC;
  signal \interim[27]_i_6_n_0\ : STD_LOGIC;
  signal \interim[27]_i_7_n_0\ : STD_LOGIC;
  signal \interim[27]_i_8_n_0\ : STD_LOGIC;
  signal \interim[27]_i_9_n_0\ : STD_LOGIC;
  signal \interim[31]_i_2_n_0\ : STD_LOGIC;
  signal \interim[31]_i_3_n_0\ : STD_LOGIC;
  signal \interim[31]_i_4_n_0\ : STD_LOGIC;
  signal \interim[31]_i_5_n_0\ : STD_LOGIC;
  signal \interim[31]_i_6_n_0\ : STD_LOGIC;
  signal \interim[31]_i_7_n_0\ : STD_LOGIC;
  signal \interim[31]_i_8_n_0\ : STD_LOGIC;
  signal \interim[3]_i_2_n_0\ : STD_LOGIC;
  signal \interim[3]_i_3_n_0\ : STD_LOGIC;
  signal \interim[3]_i_4_n_0\ : STD_LOGIC;
  signal \interim[3]_i_5_n_0\ : STD_LOGIC;
  signal \interim[3]_i_6_n_0\ : STD_LOGIC;
  signal \interim[3]_i_7_n_0\ : STD_LOGIC;
  signal \interim[3]_i_8_n_0\ : STD_LOGIC;
  signal \interim[7]_i_2_n_0\ : STD_LOGIC;
  signal \interim[7]_i_3_n_0\ : STD_LOGIC;
  signal \interim[7]_i_4_n_0\ : STD_LOGIC;
  signal \interim[7]_i_5_n_0\ : STD_LOGIC;
  signal \interim[7]_i_6_n_0\ : STD_LOGIC;
  signal \interim[7]_i_7_n_0\ : STD_LOGIC;
  signal \interim[7]_i_8_n_0\ : STD_LOGIC;
  signal \interim[7]_i_9_n_0\ : STD_LOGIC;
  signal \interim_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[23]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[27]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[27]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[27]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[27]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[31]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[31]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[31]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \interim_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \interim_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \interim_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \interim_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \^output_velocity\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal p_0_in : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \velocity[31]_i_10_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_11_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_12_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_13_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_14_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_3_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_4_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_5_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_7_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_8_n_0\ : STD_LOGIC;
  signal \velocity[31]_i_9_n_0\ : STD_LOGIC;
  signal \velocity_reg[31]_i_1_n_1\ : STD_LOGIC;
  signal \velocity_reg[31]_i_1_n_2\ : STD_LOGIC;
  signal \velocity_reg[31]_i_1_n_3\ : STD_LOGIC;
  signal \velocity_reg[31]_i_2_n_0\ : STD_LOGIC;
  signal \velocity_reg[31]_i_2_n_1\ : STD_LOGIC;
  signal \velocity_reg[31]_i_2_n_2\ : STD_LOGIC;
  signal \velocity_reg[31]_i_2_n_3\ : STD_LOGIC;
  signal \velocity_reg[31]_i_6_n_0\ : STD_LOGIC;
  signal \velocity_reg[31]_i_6_n_1\ : STD_LOGIC;
  signal \velocity_reg[31]_i_6_n_2\ : STD_LOGIC;
  signal \velocity_reg[31]_i_6_n_3\ : STD_LOGIC;
  signal \NLW_interim_reg[31]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_velocity_reg[31]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_velocity_reg[31]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity_reg[31]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity_reg[31]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute HLUTNM : string;
  attribute HLUTNM of \interim[11]_i_2\ : label is "lutpair10";
  attribute HLUTNM of \interim[11]_i_3\ : label is "lutpair9";
  attribute HLUTNM of \interim[11]_i_4\ : label is "lutpair8";
  attribute HLUTNM of \interim[11]_i_5\ : label is "lutpair7";
  attribute HLUTNM of \interim[11]_i_6\ : label is "lutpair11";
  attribute HLUTNM of \interim[11]_i_7\ : label is "lutpair10";
  attribute HLUTNM of \interim[11]_i_8\ : label is "lutpair9";
  attribute HLUTNM of \interim[11]_i_9\ : label is "lutpair8";
  attribute HLUTNM of \interim[15]_i_2\ : label is "lutpair14";
  attribute HLUTNM of \interim[15]_i_3\ : label is "lutpair13";
  attribute HLUTNM of \interim[15]_i_4\ : label is "lutpair12";
  attribute HLUTNM of \interim[15]_i_5\ : label is "lutpair11";
  attribute HLUTNM of \interim[15]_i_6\ : label is "lutpair15";
  attribute HLUTNM of \interim[15]_i_7\ : label is "lutpair14";
  attribute HLUTNM of \interim[15]_i_8\ : label is "lutpair13";
  attribute HLUTNM of \interim[15]_i_9\ : label is "lutpair12";
  attribute HLUTNM of \interim[19]_i_2\ : label is "lutpair18";
  attribute HLUTNM of \interim[19]_i_3\ : label is "lutpair17";
  attribute HLUTNM of \interim[19]_i_4\ : label is "lutpair16";
  attribute HLUTNM of \interim[19]_i_5\ : label is "lutpair15";
  attribute HLUTNM of \interim[19]_i_6\ : label is "lutpair19";
  attribute HLUTNM of \interim[19]_i_7\ : label is "lutpair18";
  attribute HLUTNM of \interim[19]_i_8\ : label is "lutpair17";
  attribute HLUTNM of \interim[19]_i_9\ : label is "lutpair16";
  attribute HLUTNM of \interim[23]_i_2\ : label is "lutpair22";
  attribute HLUTNM of \interim[23]_i_3\ : label is "lutpair21";
  attribute HLUTNM of \interim[23]_i_4\ : label is "lutpair20";
  attribute HLUTNM of \interim[23]_i_5\ : label is "lutpair19";
  attribute HLUTNM of \interim[23]_i_6\ : label is "lutpair23";
  attribute HLUTNM of \interim[23]_i_7\ : label is "lutpair22";
  attribute HLUTNM of \interim[23]_i_8\ : label is "lutpair21";
  attribute HLUTNM of \interim[23]_i_9\ : label is "lutpair20";
  attribute HLUTNM of \interim[27]_i_2\ : label is "lutpair26";
  attribute HLUTNM of \interim[27]_i_3\ : label is "lutpair25";
  attribute HLUTNM of \interim[27]_i_4\ : label is "lutpair24";
  attribute HLUTNM of \interim[27]_i_5\ : label is "lutpair23";
  attribute HLUTNM of \interim[27]_i_6\ : label is "lutpair27";
  attribute HLUTNM of \interim[27]_i_7\ : label is "lutpair26";
  attribute HLUTNM of \interim[27]_i_8\ : label is "lutpair25";
  attribute HLUTNM of \interim[27]_i_9\ : label is "lutpair24";
  attribute HLUTNM of \interim[31]_i_2\ : label is "lutpair29";
  attribute HLUTNM of \interim[31]_i_3\ : label is "lutpair28";
  attribute HLUTNM of \interim[31]_i_4\ : label is "lutpair27";
  attribute HLUTNM of \interim[31]_i_7\ : label is "lutpair29";
  attribute HLUTNM of \interim[31]_i_8\ : label is "lutpair28";
  attribute HLUTNM of \interim[3]_i_2\ : label is "lutpair2";
  attribute HLUTNM of \interim[3]_i_3\ : label is "lutpair1";
  attribute HLUTNM of \interim[3]_i_4\ : label is "lutpair0";
  attribute HLUTNM of \interim[3]_i_5\ : label is "lutpair3";
  attribute HLUTNM of \interim[3]_i_6\ : label is "lutpair2";
  attribute HLUTNM of \interim[3]_i_7\ : label is "lutpair1";
  attribute HLUTNM of \interim[3]_i_8\ : label is "lutpair0";
  attribute HLUTNM of \interim[7]_i_2\ : label is "lutpair6";
  attribute HLUTNM of \interim[7]_i_3\ : label is "lutpair5";
  attribute HLUTNM of \interim[7]_i_4\ : label is "lutpair4";
  attribute HLUTNM of \interim[7]_i_5\ : label is "lutpair3";
  attribute HLUTNM of \interim[7]_i_6\ : label is "lutpair7";
  attribute HLUTNM of \interim[7]_i_7\ : label is "lutpair6";
  attribute HLUTNM of \interim[7]_i_8\ : label is "lutpair5";
  attribute HLUTNM of \interim[7]_i_9\ : label is "lutpair4";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \interim_reg[11]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[15]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[19]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[23]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[27]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[31]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[3]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \interim_reg[7]_i_1\ : label is 35;
begin
  output_velocity(31 downto 0) <= \^output_velocity\(31 downto 0);
\interim[11]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(10),
      I1 => d_term(10),
      I2 => p_term(10),
      O => \interim[11]_i_2_n_0\
    );
\interim[11]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(9),
      I1 => d_term(9),
      I2 => p_term(9),
      O => \interim[11]_i_3_n_0\
    );
\interim[11]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(8),
      I1 => d_term(8),
      I2 => p_term(8),
      O => \interim[11]_i_4_n_0\
    );
\interim[11]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(7),
      I1 => d_term(7),
      I2 => p_term(7),
      O => \interim[11]_i_5_n_0\
    );
\interim[11]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(11),
      I1 => d_term(11),
      I2 => p_term(11),
      I3 => \interim[11]_i_2_n_0\,
      O => \interim[11]_i_6_n_0\
    );
\interim[11]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(10),
      I1 => d_term(10),
      I2 => p_term(10),
      I3 => \interim[11]_i_3_n_0\,
      O => \interim[11]_i_7_n_0\
    );
\interim[11]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(9),
      I1 => d_term(9),
      I2 => p_term(9),
      I3 => \interim[11]_i_4_n_0\,
      O => \interim[11]_i_8_n_0\
    );
\interim[11]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(8),
      I1 => d_term(8),
      I2 => p_term(8),
      I3 => \interim[11]_i_5_n_0\,
      O => \interim[11]_i_9_n_0\
    );
\interim[15]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(14),
      I1 => d_term(14),
      I2 => p_term(14),
      O => \interim[15]_i_2_n_0\
    );
\interim[15]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(13),
      I1 => d_term(13),
      I2 => p_term(13),
      O => \interim[15]_i_3_n_0\
    );
\interim[15]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(12),
      I1 => d_term(12),
      I2 => p_term(12),
      O => \interim[15]_i_4_n_0\
    );
\interim[15]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(11),
      I1 => d_term(11),
      I2 => p_term(11),
      O => \interim[15]_i_5_n_0\
    );
\interim[15]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(15),
      I1 => d_term(15),
      I2 => p_term(15),
      I3 => \interim[15]_i_2_n_0\,
      O => \interim[15]_i_6_n_0\
    );
\interim[15]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(14),
      I1 => d_term(14),
      I2 => p_term(14),
      I3 => \interim[15]_i_3_n_0\,
      O => \interim[15]_i_7_n_0\
    );
\interim[15]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(13),
      I1 => d_term(13),
      I2 => p_term(13),
      I3 => \interim[15]_i_4_n_0\,
      O => \interim[15]_i_8_n_0\
    );
\interim[15]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(12),
      I1 => d_term(12),
      I2 => p_term(12),
      I3 => \interim[15]_i_5_n_0\,
      O => \interim[15]_i_9_n_0\
    );
\interim[19]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(18),
      I1 => d_term(18),
      I2 => p_term(18),
      O => \interim[19]_i_2_n_0\
    );
\interim[19]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(17),
      I1 => d_term(17),
      I2 => p_term(17),
      O => \interim[19]_i_3_n_0\
    );
\interim[19]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(16),
      I1 => d_term(16),
      I2 => p_term(16),
      O => \interim[19]_i_4_n_0\
    );
\interim[19]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(15),
      I1 => d_term(15),
      I2 => p_term(15),
      O => \interim[19]_i_5_n_0\
    );
\interim[19]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(19),
      I1 => d_term(19),
      I2 => p_term(19),
      I3 => \interim[19]_i_2_n_0\,
      O => \interim[19]_i_6_n_0\
    );
\interim[19]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(18),
      I1 => d_term(18),
      I2 => p_term(18),
      I3 => \interim[19]_i_3_n_0\,
      O => \interim[19]_i_7_n_0\
    );
\interim[19]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(17),
      I1 => d_term(17),
      I2 => p_term(17),
      I3 => \interim[19]_i_4_n_0\,
      O => \interim[19]_i_8_n_0\
    );
\interim[19]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(16),
      I1 => d_term(16),
      I2 => p_term(16),
      I3 => \interim[19]_i_5_n_0\,
      O => \interim[19]_i_9_n_0\
    );
\interim[23]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(22),
      I1 => d_term(22),
      I2 => p_term(22),
      O => \interim[23]_i_2_n_0\
    );
\interim[23]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(21),
      I1 => d_term(21),
      I2 => p_term(21),
      O => \interim[23]_i_3_n_0\
    );
\interim[23]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(20),
      I1 => d_term(20),
      I2 => p_term(20),
      O => \interim[23]_i_4_n_0\
    );
\interim[23]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(19),
      I1 => d_term(19),
      I2 => p_term(19),
      O => \interim[23]_i_5_n_0\
    );
\interim[23]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(23),
      I1 => d_term(23),
      I2 => p_term(23),
      I3 => \interim[23]_i_2_n_0\,
      O => \interim[23]_i_6_n_0\
    );
\interim[23]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(22),
      I1 => d_term(22),
      I2 => p_term(22),
      I3 => \interim[23]_i_3_n_0\,
      O => \interim[23]_i_7_n_0\
    );
\interim[23]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(21),
      I1 => d_term(21),
      I2 => p_term(21),
      I3 => \interim[23]_i_4_n_0\,
      O => \interim[23]_i_8_n_0\
    );
\interim[23]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(20),
      I1 => d_term(20),
      I2 => p_term(20),
      I3 => \interim[23]_i_5_n_0\,
      O => \interim[23]_i_9_n_0\
    );
\interim[27]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(26),
      I1 => d_term(26),
      I2 => p_term(26),
      O => \interim[27]_i_2_n_0\
    );
\interim[27]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(25),
      I1 => d_term(25),
      I2 => p_term(25),
      O => \interim[27]_i_3_n_0\
    );
\interim[27]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(24),
      I1 => d_term(24),
      I2 => p_term(24),
      O => \interim[27]_i_4_n_0\
    );
\interim[27]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(23),
      I1 => d_term(23),
      I2 => p_term(23),
      O => \interim[27]_i_5_n_0\
    );
\interim[27]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(27),
      I1 => d_term(27),
      I2 => p_term(27),
      I3 => \interim[27]_i_2_n_0\,
      O => \interim[27]_i_6_n_0\
    );
\interim[27]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(26),
      I1 => d_term(26),
      I2 => p_term(26),
      I3 => \interim[27]_i_3_n_0\,
      O => \interim[27]_i_7_n_0\
    );
\interim[27]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(25),
      I1 => d_term(25),
      I2 => p_term(25),
      I3 => \interim[27]_i_4_n_0\,
      O => \interim[27]_i_8_n_0\
    );
\interim[27]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(24),
      I1 => d_term(24),
      I2 => p_term(24),
      I3 => \interim[27]_i_5_n_0\,
      O => \interim[27]_i_9_n_0\
    );
\interim[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(29),
      I1 => d_term(29),
      I2 => p_term(29),
      O => \interim[31]_i_2_n_0\
    );
\interim[31]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(28),
      I1 => d_term(28),
      I2 => p_term(28),
      O => \interim[31]_i_3_n_0\
    );
\interim[31]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(27),
      I1 => d_term(27),
      I2 => p_term(27),
      O => \interim[31]_i_4_n_0\
    );
\interim[31]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => p_term(30),
      I1 => d_term(30),
      I2 => i_term(30),
      I3 => d_term(31),
      I4 => i_term(31),
      I5 => p_term(31),
      O => \interim[31]_i_5_n_0\
    );
\interim[31]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \interim[31]_i_2_n_0\,
      I1 => d_term(30),
      I2 => i_term(30),
      I3 => p_term(30),
      O => \interim[31]_i_6_n_0\
    );
\interim[31]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(29),
      I1 => d_term(29),
      I2 => p_term(29),
      I3 => \interim[31]_i_3_n_0\,
      O => \interim[31]_i_7_n_0\
    );
\interim[31]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(28),
      I1 => d_term(28),
      I2 => p_term(28),
      I3 => \interim[31]_i_4_n_0\,
      O => \interim[31]_i_8_n_0\
    );
\interim[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(2),
      I1 => d_term(2),
      I2 => p_term(2),
      O => \interim[3]_i_2_n_0\
    );
\interim[3]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(1),
      I1 => d_term(1),
      I2 => p_term(1),
      O => \interim[3]_i_3_n_0\
    );
\interim[3]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(0),
      I1 => d_term(0),
      I2 => p_term(0),
      O => \interim[3]_i_4_n_0\
    );
\interim[3]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(3),
      I1 => d_term(3),
      I2 => p_term(3),
      I3 => \interim[3]_i_2_n_0\,
      O => \interim[3]_i_5_n_0\
    );
\interim[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(2),
      I1 => d_term(2),
      I2 => p_term(2),
      I3 => \interim[3]_i_3_n_0\,
      O => \interim[3]_i_6_n_0\
    );
\interim[3]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(1),
      I1 => d_term(1),
      I2 => p_term(1),
      I3 => \interim[3]_i_4_n_0\,
      O => \interim[3]_i_7_n_0\
    );
\interim[3]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => i_term(0),
      I1 => d_term(0),
      I2 => p_term(0),
      O => \interim[3]_i_8_n_0\
    );
\interim[7]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(6),
      I1 => d_term(6),
      I2 => p_term(6),
      O => \interim[7]_i_2_n_0\
    );
\interim[7]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(5),
      I1 => d_term(5),
      I2 => p_term(5),
      O => \interim[7]_i_3_n_0\
    );
\interim[7]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(4),
      I1 => d_term(4),
      I2 => p_term(4),
      O => \interim[7]_i_4_n_0\
    );
\interim[7]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => i_term(3),
      I1 => d_term(3),
      I2 => p_term(3),
      O => \interim[7]_i_5_n_0\
    );
\interim[7]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(7),
      I1 => d_term(7),
      I2 => p_term(7),
      I3 => \interim[7]_i_2_n_0\,
      O => \interim[7]_i_6_n_0\
    );
\interim[7]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(6),
      I1 => d_term(6),
      I2 => p_term(6),
      I3 => \interim[7]_i_3_n_0\,
      O => \interim[7]_i_7_n_0\
    );
\interim[7]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(5),
      I1 => d_term(5),
      I2 => p_term(5),
      I3 => \interim[7]_i_4_n_0\,
      O => \interim[7]_i_8_n_0\
    );
\interim[7]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => i_term(4),
      I1 => d_term(4),
      I2 => p_term(4),
      I3 => \interim[7]_i_5_n_0\,
      O => \interim[7]_i_9_n_0\
    );
\interim_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(0),
      Q => interim(0),
      R => '0'
    );
\interim_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(10),
      Q => interim(10),
      R => '0'
    );
\interim_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(11),
      Q => interim(11),
      R => '0'
    );
\interim_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[7]_i_1_n_0\,
      CO(3) => \interim_reg[11]_i_1_n_0\,
      CO(2) => \interim_reg[11]_i_1_n_1\,
      CO(1) => \interim_reg[11]_i_1_n_2\,
      CO(0) => \interim_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[11]_i_2_n_0\,
      DI(2) => \interim[11]_i_3_n_0\,
      DI(1) => \interim[11]_i_4_n_0\,
      DI(0) => \interim[11]_i_5_n_0\,
      O(3 downto 0) => p_0_in(11 downto 8),
      S(3) => \interim[11]_i_6_n_0\,
      S(2) => \interim[11]_i_7_n_0\,
      S(1) => \interim[11]_i_8_n_0\,
      S(0) => \interim[11]_i_9_n_0\
    );
\interim_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(12),
      Q => interim(12),
      R => '0'
    );
\interim_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(13),
      Q => interim(13),
      R => '0'
    );
\interim_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(14),
      Q => interim(14),
      R => '0'
    );
\interim_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(15),
      Q => interim(15),
      R => '0'
    );
\interim_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[11]_i_1_n_0\,
      CO(3) => \interim_reg[15]_i_1_n_0\,
      CO(2) => \interim_reg[15]_i_1_n_1\,
      CO(1) => \interim_reg[15]_i_1_n_2\,
      CO(0) => \interim_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[15]_i_2_n_0\,
      DI(2) => \interim[15]_i_3_n_0\,
      DI(1) => \interim[15]_i_4_n_0\,
      DI(0) => \interim[15]_i_5_n_0\,
      O(3 downto 0) => p_0_in(15 downto 12),
      S(3) => \interim[15]_i_6_n_0\,
      S(2) => \interim[15]_i_7_n_0\,
      S(1) => \interim[15]_i_8_n_0\,
      S(0) => \interim[15]_i_9_n_0\
    );
\interim_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(16),
      Q => interim(16),
      R => '0'
    );
\interim_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(17),
      Q => interim(17),
      R => '0'
    );
\interim_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(18),
      Q => interim(18),
      R => '0'
    );
\interim_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(19),
      Q => interim(19),
      R => '0'
    );
\interim_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[15]_i_1_n_0\,
      CO(3) => \interim_reg[19]_i_1_n_0\,
      CO(2) => \interim_reg[19]_i_1_n_1\,
      CO(1) => \interim_reg[19]_i_1_n_2\,
      CO(0) => \interim_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[19]_i_2_n_0\,
      DI(2) => \interim[19]_i_3_n_0\,
      DI(1) => \interim[19]_i_4_n_0\,
      DI(0) => \interim[19]_i_5_n_0\,
      O(3 downto 0) => p_0_in(19 downto 16),
      S(3) => \interim[19]_i_6_n_0\,
      S(2) => \interim[19]_i_7_n_0\,
      S(1) => \interim[19]_i_8_n_0\,
      S(0) => \interim[19]_i_9_n_0\
    );
\interim_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(1),
      Q => interim(1),
      R => '0'
    );
\interim_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(20),
      Q => interim(20),
      R => '0'
    );
\interim_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(21),
      Q => interim(21),
      R => '0'
    );
\interim_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(22),
      Q => interim(22),
      R => '0'
    );
\interim_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(23),
      Q => interim(23),
      R => '0'
    );
\interim_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[19]_i_1_n_0\,
      CO(3) => \interim_reg[23]_i_1_n_0\,
      CO(2) => \interim_reg[23]_i_1_n_1\,
      CO(1) => \interim_reg[23]_i_1_n_2\,
      CO(0) => \interim_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[23]_i_2_n_0\,
      DI(2) => \interim[23]_i_3_n_0\,
      DI(1) => \interim[23]_i_4_n_0\,
      DI(0) => \interim[23]_i_5_n_0\,
      O(3 downto 0) => p_0_in(23 downto 20),
      S(3) => \interim[23]_i_6_n_0\,
      S(2) => \interim[23]_i_7_n_0\,
      S(1) => \interim[23]_i_8_n_0\,
      S(0) => \interim[23]_i_9_n_0\
    );
\interim_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(24),
      Q => interim(24),
      R => '0'
    );
\interim_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(25),
      Q => interim(25),
      R => '0'
    );
\interim_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(26),
      Q => interim(26),
      R => '0'
    );
\interim_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(27),
      Q => interim(27),
      R => '0'
    );
\interim_reg[27]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[23]_i_1_n_0\,
      CO(3) => \interim_reg[27]_i_1_n_0\,
      CO(2) => \interim_reg[27]_i_1_n_1\,
      CO(1) => \interim_reg[27]_i_1_n_2\,
      CO(0) => \interim_reg[27]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[27]_i_2_n_0\,
      DI(2) => \interim[27]_i_3_n_0\,
      DI(1) => \interim[27]_i_4_n_0\,
      DI(0) => \interim[27]_i_5_n_0\,
      O(3 downto 0) => p_0_in(27 downto 24),
      S(3) => \interim[27]_i_6_n_0\,
      S(2) => \interim[27]_i_7_n_0\,
      S(1) => \interim[27]_i_8_n_0\,
      S(0) => \interim[27]_i_9_n_0\
    );
\interim_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(28),
      Q => interim(28),
      R => '0'
    );
\interim_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(29),
      Q => interim(29),
      R => '0'
    );
\interim_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(2),
      Q => interim(2),
      R => '0'
    );
\interim_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(30),
      Q => interim(30),
      R => '0'
    );
\interim_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(31),
      Q => interim(31),
      R => '0'
    );
\interim_reg[31]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[27]_i_1_n_0\,
      CO(3) => \NLW_interim_reg[31]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \interim_reg[31]_i_1_n_1\,
      CO(1) => \interim_reg[31]_i_1_n_2\,
      CO(0) => \interim_reg[31]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \interim[31]_i_2_n_0\,
      DI(1) => \interim[31]_i_3_n_0\,
      DI(0) => \interim[31]_i_4_n_0\,
      O(3 downto 0) => p_0_in(31 downto 28),
      S(3) => \interim[31]_i_5_n_0\,
      S(2) => \interim[31]_i_6_n_0\,
      S(1) => \interim[31]_i_7_n_0\,
      S(0) => \interim[31]_i_8_n_0\
    );
\interim_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(3),
      Q => interim(3),
      R => '0'
    );
\interim_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \interim_reg[3]_i_1_n_0\,
      CO(2) => \interim_reg[3]_i_1_n_1\,
      CO(1) => \interim_reg[3]_i_1_n_2\,
      CO(0) => \interim_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[3]_i_2_n_0\,
      DI(2) => \interim[3]_i_3_n_0\,
      DI(1) => \interim[3]_i_4_n_0\,
      DI(0) => '0',
      O(3 downto 0) => p_0_in(3 downto 0),
      S(3) => \interim[3]_i_5_n_0\,
      S(2) => \interim[3]_i_6_n_0\,
      S(1) => \interim[3]_i_7_n_0\,
      S(0) => \interim[3]_i_8_n_0\
    );
\interim_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(4),
      Q => interim(4),
      R => '0'
    );
\interim_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(5),
      Q => interim(5),
      R => '0'
    );
\interim_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(6),
      Q => interim(6),
      R => '0'
    );
\interim_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(7),
      Q => interim(7),
      R => '0'
    );
\interim_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \interim_reg[3]_i_1_n_0\,
      CO(3) => \interim_reg[7]_i_1_n_0\,
      CO(2) => \interim_reg[7]_i_1_n_1\,
      CO(1) => \interim_reg[7]_i_1_n_2\,
      CO(0) => \interim_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \interim[7]_i_2_n_0\,
      DI(2) => \interim[7]_i_3_n_0\,
      DI(1) => \interim[7]_i_4_n_0\,
      DI(0) => \interim[7]_i_5_n_0\,
      O(3 downto 0) => p_0_in(7 downto 4),
      S(3) => \interim[7]_i_6_n_0\,
      S(2) => \interim[7]_i_7_n_0\,
      S(1) => \interim[7]_i_8_n_0\,
      S(0) => \interim[7]_i_9_n_0\
    );
\interim_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(8),
      Q => interim(8),
      R => '0'
    );
\interim_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in(9),
      Q => interim(9),
      R => '0'
    );
\new_velocity_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => \velocity_reg[31]_i_1_n_1\,
      Q => new_velocity_available(0),
      R => '0'
    );
\velocity[31]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(12),
      I1 => interim(12),
      I2 => interim(14),
      I3 => \^output_velocity\(14),
      I4 => interim(13),
      I5 => \^output_velocity\(13),
      O => \velocity[31]_i_10_n_0\
    );
\velocity[31]_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(9),
      I1 => interim(9),
      I2 => interim(11),
      I3 => \^output_velocity\(11),
      I4 => interim(10),
      I5 => \^output_velocity\(10),
      O => \velocity[31]_i_11_n_0\
    );
\velocity[31]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(6),
      I1 => interim(6),
      I2 => interim(8),
      I3 => \^output_velocity\(8),
      I4 => interim(7),
      I5 => \^output_velocity\(7),
      O => \velocity[31]_i_12_n_0\
    );
\velocity[31]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(3),
      I1 => interim(3),
      I2 => interim(5),
      I3 => \^output_velocity\(5),
      I4 => interim(4),
      I5 => \^output_velocity\(4),
      O => \velocity[31]_i_13_n_0\
    );
\velocity[31]_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(0),
      I1 => interim(0),
      I2 => interim(2),
      I3 => \^output_velocity\(2),
      I4 => interim(1),
      I5 => \^output_velocity\(1),
      O => \velocity[31]_i_14_n_0\
    );
\velocity[31]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \^output_velocity\(30),
      I1 => interim(30),
      I2 => \^output_velocity\(31),
      I3 => interim(31),
      O => \velocity[31]_i_3_n_0\
    );
\velocity[31]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(27),
      I1 => interim(27),
      I2 => interim(29),
      I3 => \^output_velocity\(29),
      I4 => interim(28),
      I5 => \^output_velocity\(28),
      O => \velocity[31]_i_4_n_0\
    );
\velocity[31]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(24),
      I1 => interim(24),
      I2 => interim(26),
      I3 => \^output_velocity\(26),
      I4 => interim(25),
      I5 => \^output_velocity\(25),
      O => \velocity[31]_i_5_n_0\
    );
\velocity[31]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(21),
      I1 => interim(21),
      I2 => interim(23),
      I3 => \^output_velocity\(23),
      I4 => interim(22),
      I5 => \^output_velocity\(22),
      O => \velocity[31]_i_7_n_0\
    );
\velocity[31]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(18),
      I1 => interim(18),
      I2 => interim(20),
      I3 => \^output_velocity\(20),
      I4 => interim(19),
      I5 => \^output_velocity\(19),
      O => \velocity[31]_i_8_n_0\
    );
\velocity[31]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(15),
      I1 => interim(15),
      I2 => interim(17),
      I3 => \^output_velocity\(17),
      I4 => interim(16),
      I5 => \^output_velocity\(16),
      O => \velocity[31]_i_9_n_0\
    );
\velocity_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(0),
      Q => \^output_velocity\(0),
      R => '0'
    );
\velocity_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(10),
      Q => \^output_velocity\(10),
      R => '0'
    );
\velocity_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(11),
      Q => \^output_velocity\(11),
      R => '0'
    );
\velocity_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(12),
      Q => \^output_velocity\(12),
      R => '0'
    );
\velocity_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(13),
      Q => \^output_velocity\(13),
      R => '0'
    );
\velocity_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(14),
      Q => \^output_velocity\(14),
      R => '0'
    );
\velocity_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(15),
      Q => \^output_velocity\(15),
      R => '0'
    );
\velocity_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(16),
      Q => \^output_velocity\(16),
      R => '0'
    );
\velocity_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(17),
      Q => \^output_velocity\(17),
      R => '0'
    );
\velocity_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(18),
      Q => \^output_velocity\(18),
      R => '0'
    );
\velocity_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(19),
      Q => \^output_velocity\(19),
      R => '0'
    );
\velocity_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(1),
      Q => \^output_velocity\(1),
      R => '0'
    );
\velocity_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(20),
      Q => \^output_velocity\(20),
      R => '0'
    );
\velocity_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(21),
      Q => \^output_velocity\(21),
      R => '0'
    );
\velocity_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(22),
      Q => \^output_velocity\(22),
      R => '0'
    );
\velocity_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(23),
      Q => \^output_velocity\(23),
      R => '0'
    );
\velocity_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(24),
      Q => \^output_velocity\(24),
      R => '0'
    );
\velocity_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(25),
      Q => \^output_velocity\(25),
      R => '0'
    );
\velocity_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(26),
      Q => \^output_velocity\(26),
      R => '0'
    );
\velocity_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(27),
      Q => \^output_velocity\(27),
      R => '0'
    );
\velocity_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(28),
      Q => \^output_velocity\(28),
      R => '0'
    );
\velocity_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(29),
      Q => \^output_velocity\(29),
      R => '0'
    );
\velocity_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(2),
      Q => \^output_velocity\(2),
      R => '0'
    );
\velocity_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(30),
      Q => \^output_velocity\(30),
      R => '0'
    );
\velocity_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(31),
      Q => \^output_velocity\(31),
      R => '0'
    );
\velocity_reg[31]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity_reg[31]_i_2_n_0\,
      CO(3) => \NLW_velocity_reg[31]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \velocity_reg[31]_i_1_n_1\,
      CO(1) => \velocity_reg[31]_i_1_n_2\,
      CO(0) => \velocity_reg[31]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0111",
      O(3 downto 0) => \NLW_velocity_reg[31]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \velocity[31]_i_3_n_0\,
      S(1) => \velocity[31]_i_4_n_0\,
      S(0) => \velocity[31]_i_5_n_0\
    );
\velocity_reg[31]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity_reg[31]_i_6_n_0\,
      CO(3) => \velocity_reg[31]_i_2_n_0\,
      CO(2) => \velocity_reg[31]_i_2_n_1\,
      CO(1) => \velocity_reg[31]_i_2_n_2\,
      CO(0) => \velocity_reg[31]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3 downto 0) => \NLW_velocity_reg[31]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity[31]_i_7_n_0\,
      S(2) => \velocity[31]_i_8_n_0\,
      S(1) => \velocity[31]_i_9_n_0\,
      S(0) => \velocity[31]_i_10_n_0\
    );
\velocity_reg[31]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \velocity_reg[31]_i_6_n_0\,
      CO(2) => \velocity_reg[31]_i_6_n_1\,
      CO(1) => \velocity_reg[31]_i_6_n_2\,
      CO(0) => \velocity_reg[31]_i_6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3 downto 0) => \NLW_velocity_reg[31]_i_6_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity[31]_i_11_n_0\,
      S(2) => \velocity[31]_i_12_n_0\,
      S(1) => \velocity[31]_i_13_n_0\,
      S(0) => \velocity[31]_i_14_n_0\
    );
\velocity_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(3),
      Q => \^output_velocity\(3),
      R => '0'
    );
\velocity_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(4),
      Q => \^output_velocity\(4),
      R => '0'
    );
\velocity_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(5),
      Q => \^output_velocity\(5),
      R => '0'
    );
\velocity_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(6),
      Q => \^output_velocity\(6),
      R => '0'
    );
\velocity_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(7),
      Q => \^output_velocity\(7),
      R => '0'
    );
\velocity_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(8),
      Q => \^output_velocity\(8),
      R => '0'
    );
\velocity_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => \velocity_reg[31]_i_1_n_1\,
      D => interim(9),
      Q => \^output_velocity\(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_velocity_calculation_0_0 is
  port (
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    p_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_velocity_calculation_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_velocity_calculation_0_0 : entity is "design_1_velocity_calculation_0_0,velocity_calculation,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_velocity_calculation_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_velocity_calculation_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_1_velocity_calculation_0_0 : entity is "velocity_calculation,Vivado 2021.1";
end design_1_velocity_calculation_0_0;

architecture STRUCTURE of design_1_velocity_calculation_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN design_1_sys_clock, INSERT_VIP 0";
begin
inst: entity work.design_1_velocity_calculation_0_0_velocity_calculation
     port map (
      clock(0) => clock(0),
      d_term(31 downto 0) => d_term(31 downto 0),
      i_term(31 downto 0) => i_term(31 downto 0),
      new_velocity_available(0) => new_velocity_available(0),
      output_velocity(31 downto 0) => output_velocity(31 downto 0),
      p_term(31 downto 0) => p_term(31 downto 0)
    );
end STRUCTURE;
