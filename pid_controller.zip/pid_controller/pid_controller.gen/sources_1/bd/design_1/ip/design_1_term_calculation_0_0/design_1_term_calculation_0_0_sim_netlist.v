// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep 14 17:10:15 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Xilinx/Projects/pid_controller/pid_controller.gen/sources_1/bd/design_1/ip/design_1_term_calculation_0_0/design_1_term_calculation_0_0_sim_netlist.v
// Design      : design_1_term_calculation_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_term_calculation_0_0,term_calculation,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "term_calculation,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module design_1_term_calculation_0_0
   (clock,
    error,
    integral,
    derivative,
    k_p,
    k_i,
    k_d,
    output_velocity,
    new_velocity_available);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input [0:0]clock;
  input [31:0]error;
  input [31:0]integral;
  input [31:0]derivative;
  input [11:0]k_p;
  input [11:0]k_i;
  input [11:0]k_d;
  output [31:0]output_velocity;
  output [0:0]new_velocity_available;

  wire [0:0]clock;
  wire [31:0]derivative;
  wire [31:0]error;
  wire [31:0]integral;
  wire [11:0]k_d;
  wire [11:0]k_i;
  wire [11:0]k_p;
  wire [0:0]new_velocity_available;
  wire [31:0]output_velocity;

  design_1_term_calculation_0_0_term_calculation inst
       (.clock(clock),
        .derivative(derivative),
        .error(error),
        .integral(integral),
        .k_d(k_d),
        .k_i(k_i),
        .k_p(k_p),
        .new_velocity_available(new_velocity_available),
        .output_velocity(output_velocity));
endmodule

(* ORIG_REF_NAME = "term_calculation" *) 
module design_1_term_calculation_0_0_term_calculation
   (output_velocity,
    new_velocity_available,
    k_i,
    integral,
    k_d,
    derivative,
    k_p,
    error,
    clock);
  output [31:0]output_velocity;
  output [0:0]new_velocity_available;
  input [11:0]k_i;
  input [31:0]integral;
  input [11:0]k_d;
  input [31:0]derivative;
  input [11:0]k_p;
  input [31:0]error;
  input [0:0]clock;

  wire [0:0]clock;
  wire [31:0]derivative;
  wire [31:0]error;
  wire [31:0]integral;
  wire [11:0]k_d;
  wire [11:0]k_i;
  wire [11:0]k_p;
  wire [0:0]new_velocity_available;
  wire [31:0]output_velocity;
  wire p_0_in;
  wire [31:0]p_1_in;
  wire velocity0__0_carry__0_i_1_n_0;
  wire velocity0__0_carry__0_i_2_n_0;
  wire velocity0__0_carry__0_i_3_n_0;
  wire velocity0__0_carry__0_i_4_n_0;
  wire velocity0__0_carry__0_i_5_n_0;
  wire velocity0__0_carry__0_i_6_n_0;
  wire velocity0__0_carry__0_i_7_n_0;
  wire velocity0__0_carry__0_i_8_n_0;
  wire velocity0__0_carry__0_n_0;
  wire velocity0__0_carry__0_n_1;
  wire velocity0__0_carry__0_n_2;
  wire velocity0__0_carry__0_n_3;
  wire velocity0__0_carry__1_i_1_n_0;
  wire velocity0__0_carry__1_i_2_n_0;
  wire velocity0__0_carry__1_i_3_n_0;
  wire velocity0__0_carry__1_i_4_n_0;
  wire velocity0__0_carry__1_i_5_n_0;
  wire velocity0__0_carry__1_i_6_n_0;
  wire velocity0__0_carry__1_i_7_n_0;
  wire velocity0__0_carry__1_i_8_n_0;
  wire velocity0__0_carry__1_n_0;
  wire velocity0__0_carry__1_n_1;
  wire velocity0__0_carry__1_n_2;
  wire velocity0__0_carry__1_n_3;
  wire velocity0__0_carry__2_i_1_n_0;
  wire velocity0__0_carry__2_i_2_n_0;
  wire velocity0__0_carry__2_i_3_n_0;
  wire velocity0__0_carry__2_i_4_n_0;
  wire velocity0__0_carry__2_i_5_n_0;
  wire velocity0__0_carry__2_i_6_n_0;
  wire velocity0__0_carry__2_i_7_n_0;
  wire velocity0__0_carry__2_i_8_n_0;
  wire velocity0__0_carry__2_n_0;
  wire velocity0__0_carry__2_n_1;
  wire velocity0__0_carry__2_n_2;
  wire velocity0__0_carry__2_n_3;
  wire velocity0__0_carry__3_i_1_n_0;
  wire velocity0__0_carry__3_i_2_n_0;
  wire velocity0__0_carry__3_i_3_n_0;
  wire velocity0__0_carry__3_i_4_n_0;
  wire velocity0__0_carry__3_i_5_n_0;
  wire velocity0__0_carry__3_i_6_n_0;
  wire velocity0__0_carry__3_i_7_n_0;
  wire velocity0__0_carry__3_i_8_n_0;
  wire velocity0__0_carry__3_n_0;
  wire velocity0__0_carry__3_n_1;
  wire velocity0__0_carry__3_n_2;
  wire velocity0__0_carry__3_n_3;
  wire velocity0__0_carry__4_i_1_n_0;
  wire velocity0__0_carry__4_i_2_n_0;
  wire velocity0__0_carry__4_i_3_n_0;
  wire velocity0__0_carry__4_i_4_n_0;
  wire velocity0__0_carry__4_i_5_n_0;
  wire velocity0__0_carry__4_i_6_n_0;
  wire velocity0__0_carry__4_i_7_n_0;
  wire velocity0__0_carry__4_i_8_n_0;
  wire velocity0__0_carry__4_n_0;
  wire velocity0__0_carry__4_n_1;
  wire velocity0__0_carry__4_n_2;
  wire velocity0__0_carry__4_n_3;
  wire velocity0__0_carry__5_i_1_n_0;
  wire velocity0__0_carry__5_i_2_n_0;
  wire velocity0__0_carry__5_i_3_n_0;
  wire velocity0__0_carry__5_i_4_n_0;
  wire velocity0__0_carry__5_i_5_n_0;
  wire velocity0__0_carry__5_i_6_n_0;
  wire velocity0__0_carry__5_i_7_n_0;
  wire velocity0__0_carry__5_i_8_n_0;
  wire velocity0__0_carry__5_n_0;
  wire velocity0__0_carry__5_n_1;
  wire velocity0__0_carry__5_n_2;
  wire velocity0__0_carry__5_n_3;
  wire velocity0__0_carry__6_i_1_n_0;
  wire velocity0__0_carry__6_i_2_n_0;
  wire velocity0__0_carry__6_i_3_n_0;
  wire velocity0__0_carry__6_i_4_n_0;
  wire velocity0__0_carry__6_i_5_n_0;
  wire velocity0__0_carry__6_i_6_n_0;
  wire velocity0__0_carry__6_i_7_n_0;
  wire velocity0__0_carry__6_n_1;
  wire velocity0__0_carry__6_n_2;
  wire velocity0__0_carry__6_n_3;
  wire velocity0__0_carry_i_1_n_0;
  wire velocity0__0_carry_i_2_n_0;
  wire velocity0__0_carry_i_3_n_0;
  wire velocity0__0_carry_i_4_n_0;
  wire velocity0__0_carry_i_5_n_0;
  wire velocity0__0_carry_i_6_n_0;
  wire velocity0__0_carry_i_7_n_0;
  wire velocity0__0_carry_n_0;
  wire velocity0__0_carry_n_1;
  wire velocity0__0_carry_n_2;
  wire velocity0__0_carry_n_3;
  wire velocity0__93_carry__0_i_1_n_0;
  wire velocity0__93_carry__0_i_2_n_0;
  wire velocity0__93_carry__0_i_3_n_0;
  wire velocity0__93_carry__0_i_4_n_0;
  wire velocity0__93_carry__0_n_0;
  wire velocity0__93_carry__0_n_1;
  wire velocity0__93_carry__0_n_2;
  wire velocity0__93_carry__0_n_3;
  wire velocity0__93_carry__1_i_1_n_0;
  wire velocity0__93_carry__1_i_2_n_0;
  wire velocity0__93_carry__1_i_3_n_0;
  wire velocity0__93_carry__1_n_2;
  wire velocity0__93_carry__1_n_3;
  wire velocity0__93_carry_i_1_n_0;
  wire velocity0__93_carry_i_2_n_0;
  wire velocity0__93_carry_i_3_n_0;
  wire velocity0__93_carry_i_4_n_0;
  wire velocity0__93_carry_n_0;
  wire velocity0__93_carry_n_1;
  wire velocity0__93_carry_n_2;
  wire velocity0__93_carry_n_3;
  wire velocity1__0_n_100;
  wire velocity1__0_n_101;
  wire velocity1__0_n_102;
  wire velocity1__0_n_103;
  wire velocity1__0_n_104;
  wire velocity1__0_n_105;
  wire velocity1__0_n_58;
  wire velocity1__0_n_59;
  wire velocity1__0_n_60;
  wire velocity1__0_n_61;
  wire velocity1__0_n_62;
  wire velocity1__0_n_63;
  wire velocity1__0_n_64;
  wire velocity1__0_n_65;
  wire velocity1__0_n_66;
  wire velocity1__0_n_67;
  wire velocity1__0_n_68;
  wire velocity1__0_n_69;
  wire velocity1__0_n_70;
  wire velocity1__0_n_71;
  wire velocity1__0_n_72;
  wire velocity1__0_n_73;
  wire velocity1__0_n_74;
  wire velocity1__0_n_75;
  wire velocity1__0_n_76;
  wire velocity1__0_n_77;
  wire velocity1__0_n_78;
  wire velocity1__0_n_79;
  wire velocity1__0_n_80;
  wire velocity1__0_n_81;
  wire velocity1__0_n_82;
  wire velocity1__0_n_83;
  wire velocity1__0_n_84;
  wire velocity1__0_n_85;
  wire velocity1__0_n_86;
  wire velocity1__0_n_87;
  wire velocity1__0_n_88;
  wire velocity1__0_n_89;
  wire velocity1__0_n_90;
  wire velocity1__0_n_91;
  wire velocity1__0_n_92;
  wire velocity1__0_n_93;
  wire velocity1__0_n_94;
  wire velocity1__0_n_95;
  wire velocity1__0_n_96;
  wire velocity1__0_n_97;
  wire velocity1__0_n_98;
  wire velocity1__0_n_99;
  wire velocity1_n_10;
  wire velocity1_n_100;
  wire velocity1_n_101;
  wire velocity1_n_102;
  wire velocity1_n_103;
  wire velocity1_n_104;
  wire velocity1_n_105;
  wire velocity1_n_106;
  wire velocity1_n_107;
  wire velocity1_n_108;
  wire velocity1_n_109;
  wire velocity1_n_11;
  wire velocity1_n_110;
  wire velocity1_n_111;
  wire velocity1_n_112;
  wire velocity1_n_113;
  wire velocity1_n_114;
  wire velocity1_n_115;
  wire velocity1_n_116;
  wire velocity1_n_117;
  wire velocity1_n_118;
  wire velocity1_n_119;
  wire velocity1_n_12;
  wire velocity1_n_120;
  wire velocity1_n_121;
  wire velocity1_n_122;
  wire velocity1_n_123;
  wire velocity1_n_124;
  wire velocity1_n_125;
  wire velocity1_n_126;
  wire velocity1_n_127;
  wire velocity1_n_128;
  wire velocity1_n_129;
  wire velocity1_n_13;
  wire velocity1_n_130;
  wire velocity1_n_131;
  wire velocity1_n_132;
  wire velocity1_n_133;
  wire velocity1_n_134;
  wire velocity1_n_135;
  wire velocity1_n_136;
  wire velocity1_n_137;
  wire velocity1_n_138;
  wire velocity1_n_139;
  wire velocity1_n_14;
  wire velocity1_n_140;
  wire velocity1_n_141;
  wire velocity1_n_142;
  wire velocity1_n_143;
  wire velocity1_n_144;
  wire velocity1_n_145;
  wire velocity1_n_146;
  wire velocity1_n_147;
  wire velocity1_n_148;
  wire velocity1_n_149;
  wire velocity1_n_15;
  wire velocity1_n_150;
  wire velocity1_n_151;
  wire velocity1_n_152;
  wire velocity1_n_153;
  wire velocity1_n_16;
  wire velocity1_n_17;
  wire velocity1_n_18;
  wire velocity1_n_19;
  wire velocity1_n_20;
  wire velocity1_n_21;
  wire velocity1_n_22;
  wire velocity1_n_23;
  wire velocity1_n_58;
  wire velocity1_n_59;
  wire velocity1_n_6;
  wire velocity1_n_60;
  wire velocity1_n_61;
  wire velocity1_n_62;
  wire velocity1_n_63;
  wire velocity1_n_64;
  wire velocity1_n_65;
  wire velocity1_n_66;
  wire velocity1_n_67;
  wire velocity1_n_68;
  wire velocity1_n_69;
  wire velocity1_n_7;
  wire velocity1_n_70;
  wire velocity1_n_71;
  wire velocity1_n_72;
  wire velocity1_n_73;
  wire velocity1_n_74;
  wire velocity1_n_75;
  wire velocity1_n_76;
  wire velocity1_n_77;
  wire velocity1_n_78;
  wire velocity1_n_79;
  wire velocity1_n_8;
  wire velocity1_n_80;
  wire velocity1_n_81;
  wire velocity1_n_82;
  wire velocity1_n_83;
  wire velocity1_n_84;
  wire velocity1_n_85;
  wire velocity1_n_86;
  wire velocity1_n_87;
  wire velocity1_n_88;
  wire velocity1_n_89;
  wire velocity1_n_9;
  wire velocity1_n_90;
  wire velocity1_n_91;
  wire velocity1_n_92;
  wire velocity1_n_93;
  wire velocity1_n_94;
  wire velocity1_n_95;
  wire velocity1_n_96;
  wire velocity1_n_97;
  wire velocity1_n_98;
  wire velocity1_n_99;
  wire velocity2__0_n_100;
  wire velocity2__0_n_101;
  wire velocity2__0_n_102;
  wire velocity2__0_n_103;
  wire velocity2__0_n_104;
  wire velocity2__0_n_105;
  wire velocity2__0_n_58;
  wire velocity2__0_n_59;
  wire velocity2__0_n_60;
  wire velocity2__0_n_61;
  wire velocity2__0_n_62;
  wire velocity2__0_n_63;
  wire velocity2__0_n_64;
  wire velocity2__0_n_65;
  wire velocity2__0_n_66;
  wire velocity2__0_n_67;
  wire velocity2__0_n_68;
  wire velocity2__0_n_69;
  wire velocity2__0_n_70;
  wire velocity2__0_n_71;
  wire velocity2__0_n_72;
  wire velocity2__0_n_73;
  wire velocity2__0_n_74;
  wire velocity2__0_n_75;
  wire velocity2__0_n_76;
  wire velocity2__0_n_77;
  wire velocity2__0_n_78;
  wire velocity2__0_n_79;
  wire velocity2__0_n_80;
  wire velocity2__0_n_81;
  wire velocity2__0_n_82;
  wire velocity2__0_n_83;
  wire velocity2__0_n_84;
  wire velocity2__0_n_85;
  wire velocity2__0_n_86;
  wire velocity2__0_n_87;
  wire velocity2__0_n_88;
  wire velocity2__0_n_89;
  wire velocity2__0_n_90;
  wire velocity2__0_n_91;
  wire velocity2__0_n_92;
  wire velocity2__0_n_93;
  wire velocity2__0_n_94;
  wire velocity2__0_n_95;
  wire velocity2__0_n_96;
  wire velocity2__0_n_97;
  wire velocity2__0_n_98;
  wire velocity2__0_n_99;
  wire velocity2__1_n_10;
  wire velocity2__1_n_100;
  wire velocity2__1_n_101;
  wire velocity2__1_n_102;
  wire velocity2__1_n_103;
  wire velocity2__1_n_104;
  wire velocity2__1_n_105;
  wire velocity2__1_n_106;
  wire velocity2__1_n_107;
  wire velocity2__1_n_108;
  wire velocity2__1_n_109;
  wire velocity2__1_n_11;
  wire velocity2__1_n_110;
  wire velocity2__1_n_111;
  wire velocity2__1_n_112;
  wire velocity2__1_n_113;
  wire velocity2__1_n_114;
  wire velocity2__1_n_115;
  wire velocity2__1_n_116;
  wire velocity2__1_n_117;
  wire velocity2__1_n_118;
  wire velocity2__1_n_119;
  wire velocity2__1_n_12;
  wire velocity2__1_n_120;
  wire velocity2__1_n_121;
  wire velocity2__1_n_122;
  wire velocity2__1_n_123;
  wire velocity2__1_n_124;
  wire velocity2__1_n_125;
  wire velocity2__1_n_126;
  wire velocity2__1_n_127;
  wire velocity2__1_n_128;
  wire velocity2__1_n_129;
  wire velocity2__1_n_13;
  wire velocity2__1_n_130;
  wire velocity2__1_n_131;
  wire velocity2__1_n_132;
  wire velocity2__1_n_133;
  wire velocity2__1_n_134;
  wire velocity2__1_n_135;
  wire velocity2__1_n_136;
  wire velocity2__1_n_137;
  wire velocity2__1_n_138;
  wire velocity2__1_n_139;
  wire velocity2__1_n_14;
  wire velocity2__1_n_140;
  wire velocity2__1_n_141;
  wire velocity2__1_n_142;
  wire velocity2__1_n_143;
  wire velocity2__1_n_144;
  wire velocity2__1_n_145;
  wire velocity2__1_n_146;
  wire velocity2__1_n_147;
  wire velocity2__1_n_148;
  wire velocity2__1_n_149;
  wire velocity2__1_n_15;
  wire velocity2__1_n_150;
  wire velocity2__1_n_151;
  wire velocity2__1_n_152;
  wire velocity2__1_n_153;
  wire velocity2__1_n_16;
  wire velocity2__1_n_17;
  wire velocity2__1_n_18;
  wire velocity2__1_n_19;
  wire velocity2__1_n_20;
  wire velocity2__1_n_21;
  wire velocity2__1_n_22;
  wire velocity2__1_n_23;
  wire velocity2__1_n_58;
  wire velocity2__1_n_59;
  wire velocity2__1_n_6;
  wire velocity2__1_n_60;
  wire velocity2__1_n_61;
  wire velocity2__1_n_62;
  wire velocity2__1_n_63;
  wire velocity2__1_n_64;
  wire velocity2__1_n_65;
  wire velocity2__1_n_66;
  wire velocity2__1_n_67;
  wire velocity2__1_n_68;
  wire velocity2__1_n_69;
  wire velocity2__1_n_7;
  wire velocity2__1_n_70;
  wire velocity2__1_n_71;
  wire velocity2__1_n_72;
  wire velocity2__1_n_73;
  wire velocity2__1_n_74;
  wire velocity2__1_n_75;
  wire velocity2__1_n_76;
  wire velocity2__1_n_77;
  wire velocity2__1_n_78;
  wire velocity2__1_n_79;
  wire velocity2__1_n_8;
  wire velocity2__1_n_80;
  wire velocity2__1_n_81;
  wire velocity2__1_n_82;
  wire velocity2__1_n_83;
  wire velocity2__1_n_84;
  wire velocity2__1_n_85;
  wire velocity2__1_n_86;
  wire velocity2__1_n_87;
  wire velocity2__1_n_88;
  wire velocity2__1_n_89;
  wire velocity2__1_n_9;
  wire velocity2__1_n_90;
  wire velocity2__1_n_91;
  wire velocity2__1_n_92;
  wire velocity2__1_n_93;
  wire velocity2__1_n_94;
  wire velocity2__1_n_95;
  wire velocity2__1_n_96;
  wire velocity2__1_n_97;
  wire velocity2__1_n_98;
  wire velocity2__1_n_99;
  wire velocity2__2_n_100;
  wire velocity2__2_n_101;
  wire velocity2__2_n_102;
  wire velocity2__2_n_103;
  wire velocity2__2_n_104;
  wire velocity2__2_n_105;
  wire velocity2__2_n_58;
  wire velocity2__2_n_59;
  wire velocity2__2_n_60;
  wire velocity2__2_n_61;
  wire velocity2__2_n_62;
  wire velocity2__2_n_63;
  wire velocity2__2_n_64;
  wire velocity2__2_n_65;
  wire velocity2__2_n_66;
  wire velocity2__2_n_67;
  wire velocity2__2_n_68;
  wire velocity2__2_n_69;
  wire velocity2__2_n_70;
  wire velocity2__2_n_71;
  wire velocity2__2_n_72;
  wire velocity2__2_n_73;
  wire velocity2__2_n_74;
  wire velocity2__2_n_75;
  wire velocity2__2_n_76;
  wire velocity2__2_n_77;
  wire velocity2__2_n_78;
  wire velocity2__2_n_79;
  wire velocity2__2_n_80;
  wire velocity2__2_n_81;
  wire velocity2__2_n_82;
  wire velocity2__2_n_83;
  wire velocity2__2_n_84;
  wire velocity2__2_n_85;
  wire velocity2__2_n_86;
  wire velocity2__2_n_87;
  wire velocity2__2_n_88;
  wire velocity2__2_n_89;
  wire velocity2__2_n_90;
  wire velocity2__2_n_91;
  wire velocity2__2_n_92;
  wire velocity2__2_n_93;
  wire velocity2__2_n_94;
  wire velocity2__2_n_95;
  wire velocity2__2_n_96;
  wire velocity2__2_n_97;
  wire velocity2__2_n_98;
  wire velocity2__2_n_99;
  wire velocity2_n_10;
  wire velocity2_n_100;
  wire velocity2_n_101;
  wire velocity2_n_102;
  wire velocity2_n_103;
  wire velocity2_n_104;
  wire velocity2_n_105;
  wire velocity2_n_106;
  wire velocity2_n_107;
  wire velocity2_n_108;
  wire velocity2_n_109;
  wire velocity2_n_11;
  wire velocity2_n_110;
  wire velocity2_n_111;
  wire velocity2_n_112;
  wire velocity2_n_113;
  wire velocity2_n_114;
  wire velocity2_n_115;
  wire velocity2_n_116;
  wire velocity2_n_117;
  wire velocity2_n_118;
  wire velocity2_n_119;
  wire velocity2_n_12;
  wire velocity2_n_120;
  wire velocity2_n_121;
  wire velocity2_n_122;
  wire velocity2_n_123;
  wire velocity2_n_124;
  wire velocity2_n_125;
  wire velocity2_n_126;
  wire velocity2_n_127;
  wire velocity2_n_128;
  wire velocity2_n_129;
  wire velocity2_n_13;
  wire velocity2_n_130;
  wire velocity2_n_131;
  wire velocity2_n_132;
  wire velocity2_n_133;
  wire velocity2_n_134;
  wire velocity2_n_135;
  wire velocity2_n_136;
  wire velocity2_n_137;
  wire velocity2_n_138;
  wire velocity2_n_139;
  wire velocity2_n_14;
  wire velocity2_n_140;
  wire velocity2_n_141;
  wire velocity2_n_142;
  wire velocity2_n_143;
  wire velocity2_n_144;
  wire velocity2_n_145;
  wire velocity2_n_146;
  wire velocity2_n_147;
  wire velocity2_n_148;
  wire velocity2_n_149;
  wire velocity2_n_15;
  wire velocity2_n_150;
  wire velocity2_n_151;
  wire velocity2_n_152;
  wire velocity2_n_153;
  wire velocity2_n_16;
  wire velocity2_n_17;
  wire velocity2_n_18;
  wire velocity2_n_19;
  wire velocity2_n_20;
  wire velocity2_n_21;
  wire velocity2_n_22;
  wire velocity2_n_23;
  wire velocity2_n_58;
  wire velocity2_n_59;
  wire velocity2_n_6;
  wire velocity2_n_60;
  wire velocity2_n_61;
  wire velocity2_n_62;
  wire velocity2_n_63;
  wire velocity2_n_64;
  wire velocity2_n_65;
  wire velocity2_n_66;
  wire velocity2_n_67;
  wire velocity2_n_68;
  wire velocity2_n_69;
  wire velocity2_n_7;
  wire velocity2_n_70;
  wire velocity2_n_71;
  wire velocity2_n_72;
  wire velocity2_n_73;
  wire velocity2_n_74;
  wire velocity2_n_75;
  wire velocity2_n_76;
  wire velocity2_n_77;
  wire velocity2_n_78;
  wire velocity2_n_79;
  wire velocity2_n_8;
  wire velocity2_n_80;
  wire velocity2_n_81;
  wire velocity2_n_82;
  wire velocity2_n_83;
  wire velocity2_n_84;
  wire velocity2_n_85;
  wire velocity2_n_86;
  wire velocity2_n_87;
  wire velocity2_n_88;
  wire velocity2_n_89;
  wire velocity2_n_9;
  wire velocity2_n_90;
  wire velocity2_n_91;
  wire velocity2_n_92;
  wire velocity2_n_93;
  wire velocity2_n_94;
  wire velocity2_n_95;
  wire velocity2_n_96;
  wire velocity2_n_97;
  wire velocity2_n_98;
  wire velocity2_n_99;
  wire [3:3]NLW_velocity0__0_carry__6_CO_UNCONNECTED;
  wire [3:0]NLW_velocity0__93_carry_O_UNCONNECTED;
  wire [3:0]NLW_velocity0__93_carry__0_O_UNCONNECTED;
  wire [3:3]NLW_velocity0__93_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_velocity0__93_carry__1_O_UNCONNECTED;
  wire NLW_velocity1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_velocity1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_velocity1_OVERFLOW_UNCONNECTED;
  wire NLW_velocity1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_velocity1_PATTERNDETECT_UNCONNECTED;
  wire NLW_velocity1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_velocity1_ACOUT_UNCONNECTED;
  wire [3:0]NLW_velocity1_CARRYOUT_UNCONNECTED;
  wire NLW_velocity1__0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_velocity1__0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_velocity1__0_OVERFLOW_UNCONNECTED;
  wire NLW_velocity1__0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_velocity1__0_PATTERNDETECT_UNCONNECTED;
  wire NLW_velocity1__0_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_velocity1__0_ACOUT_UNCONNECTED;
  wire [17:0]NLW_velocity1__0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_velocity1__0_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_velocity1__0_PCOUT_UNCONNECTED;
  wire NLW_velocity2_CARRYCASCOUT_UNCONNECTED;
  wire NLW_velocity2_MULTSIGNOUT_UNCONNECTED;
  wire NLW_velocity2_OVERFLOW_UNCONNECTED;
  wire NLW_velocity2_PATTERNBDETECT_UNCONNECTED;
  wire NLW_velocity2_PATTERNDETECT_UNCONNECTED;
  wire NLW_velocity2_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_velocity2_ACOUT_UNCONNECTED;
  wire [3:0]NLW_velocity2_CARRYOUT_UNCONNECTED;
  wire NLW_velocity2__0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_velocity2__0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_velocity2__0_OVERFLOW_UNCONNECTED;
  wire NLW_velocity2__0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_velocity2__0_PATTERNDETECT_UNCONNECTED;
  wire NLW_velocity2__0_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_velocity2__0_ACOUT_UNCONNECTED;
  wire [17:0]NLW_velocity2__0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_velocity2__0_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_velocity2__0_PCOUT_UNCONNECTED;
  wire NLW_velocity2__1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_velocity2__1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_velocity2__1_OVERFLOW_UNCONNECTED;
  wire NLW_velocity2__1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_velocity2__1_PATTERNDETECT_UNCONNECTED;
  wire NLW_velocity2__1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_velocity2__1_ACOUT_UNCONNECTED;
  wire [3:0]NLW_velocity2__1_CARRYOUT_UNCONNECTED;
  wire NLW_velocity2__2_CARRYCASCOUT_UNCONNECTED;
  wire NLW_velocity2__2_MULTSIGNOUT_UNCONNECTED;
  wire NLW_velocity2__2_OVERFLOW_UNCONNECTED;
  wire NLW_velocity2__2_PATTERNBDETECT_UNCONNECTED;
  wire NLW_velocity2__2_PATTERNDETECT_UNCONNECTED;
  wire NLW_velocity2__2_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_velocity2__2_ACOUT_UNCONNECTED;
  wire [17:0]NLW_velocity2__2_BCOUT_UNCONNECTED;
  wire [3:0]NLW_velocity2__2_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_velocity2__2_PCOUT_UNCONNECTED;

  FDRE #(
    .INIT(1'b0)) 
    \new_velocity_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(p_0_in),
        .Q(new_velocity_available),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry
       (.CI(1'b0),
        .CO({velocity0__0_carry_n_0,velocity0__0_carry_n_1,velocity0__0_carry_n_2,velocity0__0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({velocity0__0_carry_i_1_n_0,velocity0__0_carry_i_2_n_0,velocity0__0_carry_i_3_n_0,1'b0}),
        .O(p_1_in[3:0]),
        .S({velocity0__0_carry_i_4_n_0,velocity0__0_carry_i_5_n_0,velocity0__0_carry_i_6_n_0,velocity0__0_carry_i_7_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry__0
       (.CI(velocity0__0_carry_n_0),
        .CO({velocity0__0_carry__0_n_0,velocity0__0_carry__0_n_1,velocity0__0_carry__0_n_2,velocity0__0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({velocity0__0_carry__0_i_1_n_0,velocity0__0_carry__0_i_2_n_0,velocity0__0_carry__0_i_3_n_0,velocity0__0_carry__0_i_4_n_0}),
        .O(p_1_in[7:4]),
        .S({velocity0__0_carry__0_i_5_n_0,velocity0__0_carry__0_i_6_n_0,velocity0__0_carry__0_i_7_n_0,velocity0__0_carry__0_i_8_n_0}));
  (* HLUTNM = "lutpair6" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__0_i_1
       (.I0(velocity2_n_99),
        .I1(velocity1_n_99),
        .I2(velocity2__1_n_99),
        .O(velocity0__0_carry__0_i_1_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__0_i_2
       (.I0(velocity2_n_100),
        .I1(velocity1_n_100),
        .I2(velocity2__1_n_100),
        .O(velocity0__0_carry__0_i_2_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__0_i_3
       (.I0(velocity2_n_101),
        .I1(velocity1_n_101),
        .I2(velocity2__1_n_101),
        .O(velocity0__0_carry__0_i_3_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__0_i_4
       (.I0(velocity2_n_102),
        .I1(velocity1_n_102),
        .I2(velocity2__1_n_102),
        .O(velocity0__0_carry__0_i_4_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__0_i_5
       (.I0(velocity2_n_98),
        .I1(velocity1_n_98),
        .I2(velocity2__1_n_98),
        .I3(velocity0__0_carry__0_i_1_n_0),
        .O(velocity0__0_carry__0_i_5_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__0_i_6
       (.I0(velocity2_n_99),
        .I1(velocity1_n_99),
        .I2(velocity2__1_n_99),
        .I3(velocity0__0_carry__0_i_2_n_0),
        .O(velocity0__0_carry__0_i_6_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__0_i_7
       (.I0(velocity2_n_100),
        .I1(velocity1_n_100),
        .I2(velocity2__1_n_100),
        .I3(velocity0__0_carry__0_i_3_n_0),
        .O(velocity0__0_carry__0_i_7_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__0_i_8
       (.I0(velocity2_n_101),
        .I1(velocity1_n_101),
        .I2(velocity2__1_n_101),
        .I3(velocity0__0_carry__0_i_4_n_0),
        .O(velocity0__0_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry__1
       (.CI(velocity0__0_carry__0_n_0),
        .CO({velocity0__0_carry__1_n_0,velocity0__0_carry__1_n_1,velocity0__0_carry__1_n_2,velocity0__0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({velocity0__0_carry__1_i_1_n_0,velocity0__0_carry__1_i_2_n_0,velocity0__0_carry__1_i_3_n_0,velocity0__0_carry__1_i_4_n_0}),
        .O(p_1_in[11:8]),
        .S({velocity0__0_carry__1_i_5_n_0,velocity0__0_carry__1_i_6_n_0,velocity0__0_carry__1_i_7_n_0,velocity0__0_carry__1_i_8_n_0}));
  (* HLUTNM = "lutpair10" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__1_i_1
       (.I0(velocity2_n_95),
        .I1(velocity1_n_95),
        .I2(velocity2__1_n_95),
        .O(velocity0__0_carry__1_i_1_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__1_i_2
       (.I0(velocity2_n_96),
        .I1(velocity1_n_96),
        .I2(velocity2__1_n_96),
        .O(velocity0__0_carry__1_i_2_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__1_i_3
       (.I0(velocity2_n_97),
        .I1(velocity1_n_97),
        .I2(velocity2__1_n_97),
        .O(velocity0__0_carry__1_i_3_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__1_i_4
       (.I0(velocity2_n_98),
        .I1(velocity1_n_98),
        .I2(velocity2__1_n_98),
        .O(velocity0__0_carry__1_i_4_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__1_i_5
       (.I0(velocity2_n_94),
        .I1(velocity1_n_94),
        .I2(velocity2__1_n_94),
        .I3(velocity0__0_carry__1_i_1_n_0),
        .O(velocity0__0_carry__1_i_5_n_0));
  (* HLUTNM = "lutpair10" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__1_i_6
       (.I0(velocity2_n_95),
        .I1(velocity1_n_95),
        .I2(velocity2__1_n_95),
        .I3(velocity0__0_carry__1_i_2_n_0),
        .O(velocity0__0_carry__1_i_6_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__1_i_7
       (.I0(velocity2_n_96),
        .I1(velocity1_n_96),
        .I2(velocity2__1_n_96),
        .I3(velocity0__0_carry__1_i_3_n_0),
        .O(velocity0__0_carry__1_i_7_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__1_i_8
       (.I0(velocity2_n_97),
        .I1(velocity1_n_97),
        .I2(velocity2__1_n_97),
        .I3(velocity0__0_carry__1_i_4_n_0),
        .O(velocity0__0_carry__1_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry__2
       (.CI(velocity0__0_carry__1_n_0),
        .CO({velocity0__0_carry__2_n_0,velocity0__0_carry__2_n_1,velocity0__0_carry__2_n_2,velocity0__0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({velocity0__0_carry__2_i_1_n_0,velocity0__0_carry__2_i_2_n_0,velocity0__0_carry__2_i_3_n_0,velocity0__0_carry__2_i_4_n_0}),
        .O(p_1_in[15:12]),
        .S({velocity0__0_carry__2_i_5_n_0,velocity0__0_carry__2_i_6_n_0,velocity0__0_carry__2_i_7_n_0,velocity0__0_carry__2_i_8_n_0}));
  (* HLUTNM = "lutpair14" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__2_i_1
       (.I0(velocity2_n_91),
        .I1(velocity1_n_91),
        .I2(velocity2__1_n_91),
        .O(velocity0__0_carry__2_i_1_n_0));
  (* HLUTNM = "lutpair13" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__2_i_2
       (.I0(velocity2_n_92),
        .I1(velocity1_n_92),
        .I2(velocity2__1_n_92),
        .O(velocity0__0_carry__2_i_2_n_0));
  (* HLUTNM = "lutpair12" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__2_i_3
       (.I0(velocity2_n_93),
        .I1(velocity1_n_93),
        .I2(velocity2__1_n_93),
        .O(velocity0__0_carry__2_i_3_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__2_i_4
       (.I0(velocity2_n_94),
        .I1(velocity1_n_94),
        .I2(velocity2__1_n_94),
        .O(velocity0__0_carry__2_i_4_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__2_i_5
       (.I0(velocity2_n_90),
        .I1(velocity1_n_90),
        .I2(velocity2__1_n_90),
        .I3(velocity0__0_carry__2_i_1_n_0),
        .O(velocity0__0_carry__2_i_5_n_0));
  (* HLUTNM = "lutpair14" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__2_i_6
       (.I0(velocity2_n_91),
        .I1(velocity1_n_91),
        .I2(velocity2__1_n_91),
        .I3(velocity0__0_carry__2_i_2_n_0),
        .O(velocity0__0_carry__2_i_6_n_0));
  (* HLUTNM = "lutpair13" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__2_i_7
       (.I0(velocity2_n_92),
        .I1(velocity1_n_92),
        .I2(velocity2__1_n_92),
        .I3(velocity0__0_carry__2_i_3_n_0),
        .O(velocity0__0_carry__2_i_7_n_0));
  (* HLUTNM = "lutpair12" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__2_i_8
       (.I0(velocity2_n_93),
        .I1(velocity1_n_93),
        .I2(velocity2__1_n_93),
        .I3(velocity0__0_carry__2_i_4_n_0),
        .O(velocity0__0_carry__2_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry__3
       (.CI(velocity0__0_carry__2_n_0),
        .CO({velocity0__0_carry__3_n_0,velocity0__0_carry__3_n_1,velocity0__0_carry__3_n_2,velocity0__0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({velocity0__0_carry__3_i_1_n_0,velocity0__0_carry__3_i_2_n_0,velocity0__0_carry__3_i_3_n_0,velocity0__0_carry__3_i_4_n_0}),
        .O(p_1_in[19:16]),
        .S({velocity0__0_carry__3_i_5_n_0,velocity0__0_carry__3_i_6_n_0,velocity0__0_carry__3_i_7_n_0,velocity0__0_carry__3_i_8_n_0}));
  (* HLUTNM = "lutpair18" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__3_i_1
       (.I0(velocity2__0_n_104),
        .I1(velocity1__0_n_104),
        .I2(velocity2__2_n_104),
        .O(velocity0__0_carry__3_i_1_n_0));
  (* HLUTNM = "lutpair17" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__3_i_2
       (.I0(velocity2__0_n_105),
        .I1(velocity1__0_n_105),
        .I2(velocity2__2_n_105),
        .O(velocity0__0_carry__3_i_2_n_0));
  (* HLUTNM = "lutpair16" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__3_i_3
       (.I0(velocity2_n_89),
        .I1(velocity1_n_89),
        .I2(velocity2__1_n_89),
        .O(velocity0__0_carry__3_i_3_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__3_i_4
       (.I0(velocity2_n_90),
        .I1(velocity1_n_90),
        .I2(velocity2__1_n_90),
        .O(velocity0__0_carry__3_i_4_n_0));
  (* HLUTNM = "lutpair19" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__3_i_5
       (.I0(velocity2__0_n_103),
        .I1(velocity1__0_n_103),
        .I2(velocity2__2_n_103),
        .I3(velocity0__0_carry__3_i_1_n_0),
        .O(velocity0__0_carry__3_i_5_n_0));
  (* HLUTNM = "lutpair18" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__3_i_6
       (.I0(velocity2__0_n_104),
        .I1(velocity1__0_n_104),
        .I2(velocity2__2_n_104),
        .I3(velocity0__0_carry__3_i_2_n_0),
        .O(velocity0__0_carry__3_i_6_n_0));
  (* HLUTNM = "lutpair17" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__3_i_7
       (.I0(velocity2__0_n_105),
        .I1(velocity1__0_n_105),
        .I2(velocity2__2_n_105),
        .I3(velocity0__0_carry__3_i_3_n_0),
        .O(velocity0__0_carry__3_i_7_n_0));
  (* HLUTNM = "lutpair16" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__3_i_8
       (.I0(velocity2_n_89),
        .I1(velocity1_n_89),
        .I2(velocity2__1_n_89),
        .I3(velocity0__0_carry__3_i_4_n_0),
        .O(velocity0__0_carry__3_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry__4
       (.CI(velocity0__0_carry__3_n_0),
        .CO({velocity0__0_carry__4_n_0,velocity0__0_carry__4_n_1,velocity0__0_carry__4_n_2,velocity0__0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({velocity0__0_carry__4_i_1_n_0,velocity0__0_carry__4_i_2_n_0,velocity0__0_carry__4_i_3_n_0,velocity0__0_carry__4_i_4_n_0}),
        .O(p_1_in[23:20]),
        .S({velocity0__0_carry__4_i_5_n_0,velocity0__0_carry__4_i_6_n_0,velocity0__0_carry__4_i_7_n_0,velocity0__0_carry__4_i_8_n_0}));
  (* HLUTNM = "lutpair22" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__4_i_1
       (.I0(velocity2__0_n_100),
        .I1(velocity1__0_n_100),
        .I2(velocity2__2_n_100),
        .O(velocity0__0_carry__4_i_1_n_0));
  (* HLUTNM = "lutpair21" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__4_i_2
       (.I0(velocity2__0_n_101),
        .I1(velocity1__0_n_101),
        .I2(velocity2__2_n_101),
        .O(velocity0__0_carry__4_i_2_n_0));
  (* HLUTNM = "lutpair20" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__4_i_3
       (.I0(velocity2__0_n_102),
        .I1(velocity1__0_n_102),
        .I2(velocity2__2_n_102),
        .O(velocity0__0_carry__4_i_3_n_0));
  (* HLUTNM = "lutpair19" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__4_i_4
       (.I0(velocity2__0_n_103),
        .I1(velocity1__0_n_103),
        .I2(velocity2__2_n_103),
        .O(velocity0__0_carry__4_i_4_n_0));
  (* HLUTNM = "lutpair23" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__4_i_5
       (.I0(velocity2__0_n_99),
        .I1(velocity1__0_n_99),
        .I2(velocity2__2_n_99),
        .I3(velocity0__0_carry__4_i_1_n_0),
        .O(velocity0__0_carry__4_i_5_n_0));
  (* HLUTNM = "lutpair22" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__4_i_6
       (.I0(velocity2__0_n_100),
        .I1(velocity1__0_n_100),
        .I2(velocity2__2_n_100),
        .I3(velocity0__0_carry__4_i_2_n_0),
        .O(velocity0__0_carry__4_i_6_n_0));
  (* HLUTNM = "lutpair21" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__4_i_7
       (.I0(velocity2__0_n_101),
        .I1(velocity1__0_n_101),
        .I2(velocity2__2_n_101),
        .I3(velocity0__0_carry__4_i_3_n_0),
        .O(velocity0__0_carry__4_i_7_n_0));
  (* HLUTNM = "lutpair20" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__4_i_8
       (.I0(velocity2__0_n_102),
        .I1(velocity1__0_n_102),
        .I2(velocity2__2_n_102),
        .I3(velocity0__0_carry__4_i_4_n_0),
        .O(velocity0__0_carry__4_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry__5
       (.CI(velocity0__0_carry__4_n_0),
        .CO({velocity0__0_carry__5_n_0,velocity0__0_carry__5_n_1,velocity0__0_carry__5_n_2,velocity0__0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({velocity0__0_carry__5_i_1_n_0,velocity0__0_carry__5_i_2_n_0,velocity0__0_carry__5_i_3_n_0,velocity0__0_carry__5_i_4_n_0}),
        .O(p_1_in[27:24]),
        .S({velocity0__0_carry__5_i_5_n_0,velocity0__0_carry__5_i_6_n_0,velocity0__0_carry__5_i_7_n_0,velocity0__0_carry__5_i_8_n_0}));
  (* HLUTNM = "lutpair26" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__5_i_1
       (.I0(velocity2__0_n_96),
        .I1(velocity1__0_n_96),
        .I2(velocity2__2_n_96),
        .O(velocity0__0_carry__5_i_1_n_0));
  (* HLUTNM = "lutpair25" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__5_i_2
       (.I0(velocity2__0_n_97),
        .I1(velocity1__0_n_97),
        .I2(velocity2__2_n_97),
        .O(velocity0__0_carry__5_i_2_n_0));
  (* HLUTNM = "lutpair24" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__5_i_3
       (.I0(velocity2__0_n_98),
        .I1(velocity1__0_n_98),
        .I2(velocity2__2_n_98),
        .O(velocity0__0_carry__5_i_3_n_0));
  (* HLUTNM = "lutpair23" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__5_i_4
       (.I0(velocity2__0_n_99),
        .I1(velocity1__0_n_99),
        .I2(velocity2__2_n_99),
        .O(velocity0__0_carry__5_i_4_n_0));
  (* HLUTNM = "lutpair27" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__5_i_5
       (.I0(velocity2__0_n_95),
        .I1(velocity1__0_n_95),
        .I2(velocity2__2_n_95),
        .I3(velocity0__0_carry__5_i_1_n_0),
        .O(velocity0__0_carry__5_i_5_n_0));
  (* HLUTNM = "lutpair26" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__5_i_6
       (.I0(velocity2__0_n_96),
        .I1(velocity1__0_n_96),
        .I2(velocity2__2_n_96),
        .I3(velocity0__0_carry__5_i_2_n_0),
        .O(velocity0__0_carry__5_i_6_n_0));
  (* HLUTNM = "lutpair25" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__5_i_7
       (.I0(velocity2__0_n_97),
        .I1(velocity1__0_n_97),
        .I2(velocity2__2_n_97),
        .I3(velocity0__0_carry__5_i_3_n_0),
        .O(velocity0__0_carry__5_i_7_n_0));
  (* HLUTNM = "lutpair24" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__5_i_8
       (.I0(velocity2__0_n_98),
        .I1(velocity1__0_n_98),
        .I2(velocity2__2_n_98),
        .I3(velocity0__0_carry__5_i_4_n_0),
        .O(velocity0__0_carry__5_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 velocity0__0_carry__6
       (.CI(velocity0__0_carry__5_n_0),
        .CO({NLW_velocity0__0_carry__6_CO_UNCONNECTED[3],velocity0__0_carry__6_n_1,velocity0__0_carry__6_n_2,velocity0__0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,velocity0__0_carry__6_i_1_n_0,velocity0__0_carry__6_i_2_n_0,velocity0__0_carry__6_i_3_n_0}),
        .O(p_1_in[31:28]),
        .S({velocity0__0_carry__6_i_4_n_0,velocity0__0_carry__6_i_5_n_0,velocity0__0_carry__6_i_6_n_0,velocity0__0_carry__6_i_7_n_0}));
  (* HLUTNM = "lutpair29" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__6_i_1
       (.I0(velocity2__0_n_93),
        .I1(velocity1__0_n_93),
        .I2(velocity2__2_n_93),
        .O(velocity0__0_carry__6_i_1_n_0));
  (* HLUTNM = "lutpair28" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__6_i_2
       (.I0(velocity2__0_n_94),
        .I1(velocity1__0_n_94),
        .I2(velocity2__2_n_94),
        .O(velocity0__0_carry__6_i_2_n_0));
  (* HLUTNM = "lutpair27" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry__6_i_3
       (.I0(velocity2__0_n_95),
        .I1(velocity1__0_n_95),
        .I2(velocity2__2_n_95),
        .O(velocity0__0_carry__6_i_3_n_0));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    velocity0__0_carry__6_i_4
       (.I0(velocity2__2_n_92),
        .I1(velocity1__0_n_92),
        .I2(velocity2__0_n_92),
        .I3(velocity1__0_n_91),
        .I4(velocity2__0_n_91),
        .I5(velocity2__2_n_91),
        .O(velocity0__0_carry__6_i_4_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__6_i_5
       (.I0(velocity0__0_carry__6_i_1_n_0),
        .I1(velocity1__0_n_92),
        .I2(velocity2__0_n_92),
        .I3(velocity2__2_n_92),
        .O(velocity0__0_carry__6_i_5_n_0));
  (* HLUTNM = "lutpair29" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__6_i_6
       (.I0(velocity2__0_n_93),
        .I1(velocity1__0_n_93),
        .I2(velocity2__2_n_93),
        .I3(velocity0__0_carry__6_i_2_n_0),
        .O(velocity0__0_carry__6_i_6_n_0));
  (* HLUTNM = "lutpair28" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry__6_i_7
       (.I0(velocity2__0_n_94),
        .I1(velocity1__0_n_94),
        .I2(velocity2__2_n_94),
        .I3(velocity0__0_carry__6_i_3_n_0),
        .O(velocity0__0_carry__6_i_7_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry_i_1
       (.I0(velocity2_n_103),
        .I1(velocity1_n_103),
        .I2(velocity2__1_n_103),
        .O(velocity0__0_carry_i_1_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry_i_2
       (.I0(velocity2_n_104),
        .I1(velocity1_n_104),
        .I2(velocity2__1_n_104),
        .O(velocity0__0_carry_i_2_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    velocity0__0_carry_i_3
       (.I0(velocity2_n_105),
        .I1(velocity1_n_105),
        .I2(velocity2__1_n_105),
        .O(velocity0__0_carry_i_3_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry_i_4
       (.I0(velocity2_n_102),
        .I1(velocity1_n_102),
        .I2(velocity2__1_n_102),
        .I3(velocity0__0_carry_i_1_n_0),
        .O(velocity0__0_carry_i_4_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry_i_5
       (.I0(velocity2_n_103),
        .I1(velocity1_n_103),
        .I2(velocity2__1_n_103),
        .I3(velocity0__0_carry_i_2_n_0),
        .O(velocity0__0_carry_i_5_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    velocity0__0_carry_i_6
       (.I0(velocity2_n_104),
        .I1(velocity1_n_104),
        .I2(velocity2__1_n_104),
        .I3(velocity0__0_carry_i_3_n_0),
        .O(velocity0__0_carry_i_6_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'h96)) 
    velocity0__0_carry_i_7
       (.I0(velocity2_n_105),
        .I1(velocity1_n_105),
        .I2(velocity2__1_n_105),
        .O(velocity0__0_carry_i_7_n_0));
  CARRY4 velocity0__93_carry
       (.CI(1'b0),
        .CO({velocity0__93_carry_n_0,velocity0__93_carry_n_1,velocity0__93_carry_n_2,velocity0__93_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O(NLW_velocity0__93_carry_O_UNCONNECTED[3:0]),
        .S({velocity0__93_carry_i_1_n_0,velocity0__93_carry_i_2_n_0,velocity0__93_carry_i_3_n_0,velocity0__93_carry_i_4_n_0}));
  CARRY4 velocity0__93_carry__0
       (.CI(velocity0__93_carry_n_0),
        .CO({velocity0__93_carry__0_n_0,velocity0__93_carry__0_n_1,velocity0__93_carry__0_n_2,velocity0__93_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b1,1'b1,1'b1,1'b1}),
        .O(NLW_velocity0__93_carry__0_O_UNCONNECTED[3:0]),
        .S({velocity0__93_carry__0_i_1_n_0,velocity0__93_carry__0_i_2_n_0,velocity0__93_carry__0_i_3_n_0,velocity0__93_carry__0_i_4_n_0}));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry__0_i_1
       (.I0(output_velocity[21]),
        .I1(p_1_in[21]),
        .I2(p_1_in[23]),
        .I3(output_velocity[23]),
        .I4(p_1_in[22]),
        .I5(output_velocity[22]),
        .O(velocity0__93_carry__0_i_1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry__0_i_2
       (.I0(output_velocity[18]),
        .I1(p_1_in[18]),
        .I2(p_1_in[20]),
        .I3(output_velocity[20]),
        .I4(p_1_in[19]),
        .I5(output_velocity[19]),
        .O(velocity0__93_carry__0_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry__0_i_3
       (.I0(output_velocity[15]),
        .I1(p_1_in[15]),
        .I2(p_1_in[17]),
        .I3(output_velocity[17]),
        .I4(p_1_in[16]),
        .I5(output_velocity[16]),
        .O(velocity0__93_carry__0_i_3_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry__0_i_4
       (.I0(output_velocity[12]),
        .I1(p_1_in[12]),
        .I2(p_1_in[14]),
        .I3(output_velocity[14]),
        .I4(p_1_in[13]),
        .I5(output_velocity[13]),
        .O(velocity0__93_carry__0_i_4_n_0));
  CARRY4 velocity0__93_carry__1
       (.CI(velocity0__93_carry__0_n_0),
        .CO({NLW_velocity0__93_carry__1_CO_UNCONNECTED[3],p_0_in,velocity0__93_carry__1_n_2,velocity0__93_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b1,1'b1,1'b1}),
        .O(NLW_velocity0__93_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,velocity0__93_carry__1_i_1_n_0,velocity0__93_carry__1_i_2_n_0,velocity0__93_carry__1_i_3_n_0}));
  LUT4 #(
    .INIT(16'h9009)) 
    velocity0__93_carry__1_i_1
       (.I0(output_velocity[30]),
        .I1(p_1_in[30]),
        .I2(output_velocity[31]),
        .I3(p_1_in[31]),
        .O(velocity0__93_carry__1_i_1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry__1_i_2
       (.I0(output_velocity[27]),
        .I1(p_1_in[27]),
        .I2(p_1_in[29]),
        .I3(output_velocity[29]),
        .I4(p_1_in[28]),
        .I5(output_velocity[28]),
        .O(velocity0__93_carry__1_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry__1_i_3
       (.I0(output_velocity[24]),
        .I1(p_1_in[24]),
        .I2(p_1_in[26]),
        .I3(output_velocity[26]),
        .I4(p_1_in[25]),
        .I5(output_velocity[25]),
        .O(velocity0__93_carry__1_i_3_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry_i_1
       (.I0(output_velocity[9]),
        .I1(p_1_in[9]),
        .I2(p_1_in[11]),
        .I3(output_velocity[11]),
        .I4(p_1_in[10]),
        .I5(output_velocity[10]),
        .O(velocity0__93_carry_i_1_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry_i_2
       (.I0(output_velocity[6]),
        .I1(p_1_in[6]),
        .I2(p_1_in[8]),
        .I3(output_velocity[8]),
        .I4(p_1_in[7]),
        .I5(output_velocity[7]),
        .O(velocity0__93_carry_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry_i_3
       (.I0(output_velocity[3]),
        .I1(p_1_in[3]),
        .I2(p_1_in[5]),
        .I3(output_velocity[5]),
        .I4(p_1_in[4]),
        .I5(output_velocity[4]),
        .O(velocity0__93_carry_i_3_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    velocity0__93_carry_i_4
       (.I0(output_velocity[0]),
        .I1(p_1_in[0]),
        .I2(p_1_in[2]),
        .I3(output_velocity[2]),
        .I4(p_1_in[1]),
        .I5(output_velocity[1]),
        .O(velocity0__93_carry_i_4_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    velocity1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,derivative[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_velocity1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,k_d}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT({velocity1_n_6,velocity1_n_7,velocity1_n_8,velocity1_n_9,velocity1_n_10,velocity1_n_11,velocity1_n_12,velocity1_n_13,velocity1_n_14,velocity1_n_15,velocity1_n_16,velocity1_n_17,velocity1_n_18,velocity1_n_19,velocity1_n_20,velocity1_n_21,velocity1_n_22,velocity1_n_23}),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_velocity1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_velocity1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_velocity1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_velocity1_OVERFLOW_UNCONNECTED),
        .P({velocity1_n_58,velocity1_n_59,velocity1_n_60,velocity1_n_61,velocity1_n_62,velocity1_n_63,velocity1_n_64,velocity1_n_65,velocity1_n_66,velocity1_n_67,velocity1_n_68,velocity1_n_69,velocity1_n_70,velocity1_n_71,velocity1_n_72,velocity1_n_73,velocity1_n_74,velocity1_n_75,velocity1_n_76,velocity1_n_77,velocity1_n_78,velocity1_n_79,velocity1_n_80,velocity1_n_81,velocity1_n_82,velocity1_n_83,velocity1_n_84,velocity1_n_85,velocity1_n_86,velocity1_n_87,velocity1_n_88,velocity1_n_89,velocity1_n_90,velocity1_n_91,velocity1_n_92,velocity1_n_93,velocity1_n_94,velocity1_n_95,velocity1_n_96,velocity1_n_97,velocity1_n_98,velocity1_n_99,velocity1_n_100,velocity1_n_101,velocity1_n_102,velocity1_n_103,velocity1_n_104,velocity1_n_105}),
        .PATTERNBDETECT(NLW_velocity1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_velocity1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({velocity1_n_106,velocity1_n_107,velocity1_n_108,velocity1_n_109,velocity1_n_110,velocity1_n_111,velocity1_n_112,velocity1_n_113,velocity1_n_114,velocity1_n_115,velocity1_n_116,velocity1_n_117,velocity1_n_118,velocity1_n_119,velocity1_n_120,velocity1_n_121,velocity1_n_122,velocity1_n_123,velocity1_n_124,velocity1_n_125,velocity1_n_126,velocity1_n_127,velocity1_n_128,velocity1_n_129,velocity1_n_130,velocity1_n_131,velocity1_n_132,velocity1_n_133,velocity1_n_134,velocity1_n_135,velocity1_n_136,velocity1_n_137,velocity1_n_138,velocity1_n_139,velocity1_n_140,velocity1_n_141,velocity1_n_142,velocity1_n_143,velocity1_n_144,velocity1_n_145,velocity1_n_146,velocity1_n_147,velocity1_n_148,velocity1_n_149,velocity1_n_150,velocity1_n_151,velocity1_n_152,velocity1_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_velocity1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("CASCADE"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    velocity1__0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,derivative[31:17]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_velocity1__0_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCIN({velocity1_n_6,velocity1_n_7,velocity1_n_8,velocity1_n_9,velocity1_n_10,velocity1_n_11,velocity1_n_12,velocity1_n_13,velocity1_n_14,velocity1_n_15,velocity1_n_16,velocity1_n_17,velocity1_n_18,velocity1_n_19,velocity1_n_20,velocity1_n_21,velocity1_n_22,velocity1_n_23}),
        .BCOUT(NLW_velocity1__0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_velocity1__0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_velocity1__0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_velocity1__0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_velocity1__0_OVERFLOW_UNCONNECTED),
        .P({velocity1__0_n_58,velocity1__0_n_59,velocity1__0_n_60,velocity1__0_n_61,velocity1__0_n_62,velocity1__0_n_63,velocity1__0_n_64,velocity1__0_n_65,velocity1__0_n_66,velocity1__0_n_67,velocity1__0_n_68,velocity1__0_n_69,velocity1__0_n_70,velocity1__0_n_71,velocity1__0_n_72,velocity1__0_n_73,velocity1__0_n_74,velocity1__0_n_75,velocity1__0_n_76,velocity1__0_n_77,velocity1__0_n_78,velocity1__0_n_79,velocity1__0_n_80,velocity1__0_n_81,velocity1__0_n_82,velocity1__0_n_83,velocity1__0_n_84,velocity1__0_n_85,velocity1__0_n_86,velocity1__0_n_87,velocity1__0_n_88,velocity1__0_n_89,velocity1__0_n_90,velocity1__0_n_91,velocity1__0_n_92,velocity1__0_n_93,velocity1__0_n_94,velocity1__0_n_95,velocity1__0_n_96,velocity1__0_n_97,velocity1__0_n_98,velocity1__0_n_99,velocity1__0_n_100,velocity1__0_n_101,velocity1__0_n_102,velocity1__0_n_103,velocity1__0_n_104,velocity1__0_n_105}),
        .PATTERNBDETECT(NLW_velocity1__0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_velocity1__0_PATTERNDETECT_UNCONNECTED),
        .PCIN({velocity1_n_106,velocity1_n_107,velocity1_n_108,velocity1_n_109,velocity1_n_110,velocity1_n_111,velocity1_n_112,velocity1_n_113,velocity1_n_114,velocity1_n_115,velocity1_n_116,velocity1_n_117,velocity1_n_118,velocity1_n_119,velocity1_n_120,velocity1_n_121,velocity1_n_122,velocity1_n_123,velocity1_n_124,velocity1_n_125,velocity1_n_126,velocity1_n_127,velocity1_n_128,velocity1_n_129,velocity1_n_130,velocity1_n_131,velocity1_n_132,velocity1_n_133,velocity1_n_134,velocity1_n_135,velocity1_n_136,velocity1_n_137,velocity1_n_138,velocity1_n_139,velocity1_n_140,velocity1_n_141,velocity1_n_142,velocity1_n_143,velocity1_n_144,velocity1_n_145,velocity1_n_146,velocity1_n_147,velocity1_n_148,velocity1_n_149,velocity1_n_150,velocity1_n_151,velocity1_n_152,velocity1_n_153}),
        .PCOUT(NLW_velocity1__0_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_velocity1__0_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    velocity2
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,integral[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_velocity2_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,k_i}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT({velocity2_n_6,velocity2_n_7,velocity2_n_8,velocity2_n_9,velocity2_n_10,velocity2_n_11,velocity2_n_12,velocity2_n_13,velocity2_n_14,velocity2_n_15,velocity2_n_16,velocity2_n_17,velocity2_n_18,velocity2_n_19,velocity2_n_20,velocity2_n_21,velocity2_n_22,velocity2_n_23}),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_velocity2_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_velocity2_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_velocity2_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_velocity2_OVERFLOW_UNCONNECTED),
        .P({velocity2_n_58,velocity2_n_59,velocity2_n_60,velocity2_n_61,velocity2_n_62,velocity2_n_63,velocity2_n_64,velocity2_n_65,velocity2_n_66,velocity2_n_67,velocity2_n_68,velocity2_n_69,velocity2_n_70,velocity2_n_71,velocity2_n_72,velocity2_n_73,velocity2_n_74,velocity2_n_75,velocity2_n_76,velocity2_n_77,velocity2_n_78,velocity2_n_79,velocity2_n_80,velocity2_n_81,velocity2_n_82,velocity2_n_83,velocity2_n_84,velocity2_n_85,velocity2_n_86,velocity2_n_87,velocity2_n_88,velocity2_n_89,velocity2_n_90,velocity2_n_91,velocity2_n_92,velocity2_n_93,velocity2_n_94,velocity2_n_95,velocity2_n_96,velocity2_n_97,velocity2_n_98,velocity2_n_99,velocity2_n_100,velocity2_n_101,velocity2_n_102,velocity2_n_103,velocity2_n_104,velocity2_n_105}),
        .PATTERNBDETECT(NLW_velocity2_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_velocity2_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({velocity2_n_106,velocity2_n_107,velocity2_n_108,velocity2_n_109,velocity2_n_110,velocity2_n_111,velocity2_n_112,velocity2_n_113,velocity2_n_114,velocity2_n_115,velocity2_n_116,velocity2_n_117,velocity2_n_118,velocity2_n_119,velocity2_n_120,velocity2_n_121,velocity2_n_122,velocity2_n_123,velocity2_n_124,velocity2_n_125,velocity2_n_126,velocity2_n_127,velocity2_n_128,velocity2_n_129,velocity2_n_130,velocity2_n_131,velocity2_n_132,velocity2_n_133,velocity2_n_134,velocity2_n_135,velocity2_n_136,velocity2_n_137,velocity2_n_138,velocity2_n_139,velocity2_n_140,velocity2_n_141,velocity2_n_142,velocity2_n_143,velocity2_n_144,velocity2_n_145,velocity2_n_146,velocity2_n_147,velocity2_n_148,velocity2_n_149,velocity2_n_150,velocity2_n_151,velocity2_n_152,velocity2_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_velocity2_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("CASCADE"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    velocity2__0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,integral[31:17]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_velocity2__0_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCIN({velocity2_n_6,velocity2_n_7,velocity2_n_8,velocity2_n_9,velocity2_n_10,velocity2_n_11,velocity2_n_12,velocity2_n_13,velocity2_n_14,velocity2_n_15,velocity2_n_16,velocity2_n_17,velocity2_n_18,velocity2_n_19,velocity2_n_20,velocity2_n_21,velocity2_n_22,velocity2_n_23}),
        .BCOUT(NLW_velocity2__0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_velocity2__0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_velocity2__0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_velocity2__0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_velocity2__0_OVERFLOW_UNCONNECTED),
        .P({velocity2__0_n_58,velocity2__0_n_59,velocity2__0_n_60,velocity2__0_n_61,velocity2__0_n_62,velocity2__0_n_63,velocity2__0_n_64,velocity2__0_n_65,velocity2__0_n_66,velocity2__0_n_67,velocity2__0_n_68,velocity2__0_n_69,velocity2__0_n_70,velocity2__0_n_71,velocity2__0_n_72,velocity2__0_n_73,velocity2__0_n_74,velocity2__0_n_75,velocity2__0_n_76,velocity2__0_n_77,velocity2__0_n_78,velocity2__0_n_79,velocity2__0_n_80,velocity2__0_n_81,velocity2__0_n_82,velocity2__0_n_83,velocity2__0_n_84,velocity2__0_n_85,velocity2__0_n_86,velocity2__0_n_87,velocity2__0_n_88,velocity2__0_n_89,velocity2__0_n_90,velocity2__0_n_91,velocity2__0_n_92,velocity2__0_n_93,velocity2__0_n_94,velocity2__0_n_95,velocity2__0_n_96,velocity2__0_n_97,velocity2__0_n_98,velocity2__0_n_99,velocity2__0_n_100,velocity2__0_n_101,velocity2__0_n_102,velocity2__0_n_103,velocity2__0_n_104,velocity2__0_n_105}),
        .PATTERNBDETECT(NLW_velocity2__0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_velocity2__0_PATTERNDETECT_UNCONNECTED),
        .PCIN({velocity2_n_106,velocity2_n_107,velocity2_n_108,velocity2_n_109,velocity2_n_110,velocity2_n_111,velocity2_n_112,velocity2_n_113,velocity2_n_114,velocity2_n_115,velocity2_n_116,velocity2_n_117,velocity2_n_118,velocity2_n_119,velocity2_n_120,velocity2_n_121,velocity2_n_122,velocity2_n_123,velocity2_n_124,velocity2_n_125,velocity2_n_126,velocity2_n_127,velocity2_n_128,velocity2_n_129,velocity2_n_130,velocity2_n_131,velocity2_n_132,velocity2_n_133,velocity2_n_134,velocity2_n_135,velocity2_n_136,velocity2_n_137,velocity2_n_138,velocity2_n_139,velocity2_n_140,velocity2_n_141,velocity2_n_142,velocity2_n_143,velocity2_n_144,velocity2_n_145,velocity2_n_146,velocity2_n_147,velocity2_n_148,velocity2_n_149,velocity2_n_150,velocity2_n_151,velocity2_n_152,velocity2_n_153}),
        .PCOUT(NLW_velocity2__0_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_velocity2__0_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    velocity2__1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,error[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_velocity2__1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,k_p}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT({velocity2__1_n_6,velocity2__1_n_7,velocity2__1_n_8,velocity2__1_n_9,velocity2__1_n_10,velocity2__1_n_11,velocity2__1_n_12,velocity2__1_n_13,velocity2__1_n_14,velocity2__1_n_15,velocity2__1_n_16,velocity2__1_n_17,velocity2__1_n_18,velocity2__1_n_19,velocity2__1_n_20,velocity2__1_n_21,velocity2__1_n_22,velocity2__1_n_23}),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_velocity2__1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_velocity2__1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_velocity2__1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_velocity2__1_OVERFLOW_UNCONNECTED),
        .P({velocity2__1_n_58,velocity2__1_n_59,velocity2__1_n_60,velocity2__1_n_61,velocity2__1_n_62,velocity2__1_n_63,velocity2__1_n_64,velocity2__1_n_65,velocity2__1_n_66,velocity2__1_n_67,velocity2__1_n_68,velocity2__1_n_69,velocity2__1_n_70,velocity2__1_n_71,velocity2__1_n_72,velocity2__1_n_73,velocity2__1_n_74,velocity2__1_n_75,velocity2__1_n_76,velocity2__1_n_77,velocity2__1_n_78,velocity2__1_n_79,velocity2__1_n_80,velocity2__1_n_81,velocity2__1_n_82,velocity2__1_n_83,velocity2__1_n_84,velocity2__1_n_85,velocity2__1_n_86,velocity2__1_n_87,velocity2__1_n_88,velocity2__1_n_89,velocity2__1_n_90,velocity2__1_n_91,velocity2__1_n_92,velocity2__1_n_93,velocity2__1_n_94,velocity2__1_n_95,velocity2__1_n_96,velocity2__1_n_97,velocity2__1_n_98,velocity2__1_n_99,velocity2__1_n_100,velocity2__1_n_101,velocity2__1_n_102,velocity2__1_n_103,velocity2__1_n_104,velocity2__1_n_105}),
        .PATTERNBDETECT(NLW_velocity2__1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_velocity2__1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({velocity2__1_n_106,velocity2__1_n_107,velocity2__1_n_108,velocity2__1_n_109,velocity2__1_n_110,velocity2__1_n_111,velocity2__1_n_112,velocity2__1_n_113,velocity2__1_n_114,velocity2__1_n_115,velocity2__1_n_116,velocity2__1_n_117,velocity2__1_n_118,velocity2__1_n_119,velocity2__1_n_120,velocity2__1_n_121,velocity2__1_n_122,velocity2__1_n_123,velocity2__1_n_124,velocity2__1_n_125,velocity2__1_n_126,velocity2__1_n_127,velocity2__1_n_128,velocity2__1_n_129,velocity2__1_n_130,velocity2__1_n_131,velocity2__1_n_132,velocity2__1_n_133,velocity2__1_n_134,velocity2__1_n_135,velocity2__1_n_136,velocity2__1_n_137,velocity2__1_n_138,velocity2__1_n_139,velocity2__1_n_140,velocity2__1_n_141,velocity2__1_n_142,velocity2__1_n_143,velocity2__1_n_144,velocity2__1_n_145,velocity2__1_n_146,velocity2__1_n_147,velocity2__1_n_148,velocity2__1_n_149,velocity2__1_n_150,velocity2__1_n_151,velocity2__1_n_152,velocity2__1_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_velocity2__1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("CASCADE"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    velocity2__2
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,error[31:17]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_velocity2__2_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCIN({velocity2__1_n_6,velocity2__1_n_7,velocity2__1_n_8,velocity2__1_n_9,velocity2__1_n_10,velocity2__1_n_11,velocity2__1_n_12,velocity2__1_n_13,velocity2__1_n_14,velocity2__1_n_15,velocity2__1_n_16,velocity2__1_n_17,velocity2__1_n_18,velocity2__1_n_19,velocity2__1_n_20,velocity2__1_n_21,velocity2__1_n_22,velocity2__1_n_23}),
        .BCOUT(NLW_velocity2__2_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_velocity2__2_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_velocity2__2_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_velocity2__2_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_velocity2__2_OVERFLOW_UNCONNECTED),
        .P({velocity2__2_n_58,velocity2__2_n_59,velocity2__2_n_60,velocity2__2_n_61,velocity2__2_n_62,velocity2__2_n_63,velocity2__2_n_64,velocity2__2_n_65,velocity2__2_n_66,velocity2__2_n_67,velocity2__2_n_68,velocity2__2_n_69,velocity2__2_n_70,velocity2__2_n_71,velocity2__2_n_72,velocity2__2_n_73,velocity2__2_n_74,velocity2__2_n_75,velocity2__2_n_76,velocity2__2_n_77,velocity2__2_n_78,velocity2__2_n_79,velocity2__2_n_80,velocity2__2_n_81,velocity2__2_n_82,velocity2__2_n_83,velocity2__2_n_84,velocity2__2_n_85,velocity2__2_n_86,velocity2__2_n_87,velocity2__2_n_88,velocity2__2_n_89,velocity2__2_n_90,velocity2__2_n_91,velocity2__2_n_92,velocity2__2_n_93,velocity2__2_n_94,velocity2__2_n_95,velocity2__2_n_96,velocity2__2_n_97,velocity2__2_n_98,velocity2__2_n_99,velocity2__2_n_100,velocity2__2_n_101,velocity2__2_n_102,velocity2__2_n_103,velocity2__2_n_104,velocity2__2_n_105}),
        .PATTERNBDETECT(NLW_velocity2__2_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_velocity2__2_PATTERNDETECT_UNCONNECTED),
        .PCIN({velocity2__1_n_106,velocity2__1_n_107,velocity2__1_n_108,velocity2__1_n_109,velocity2__1_n_110,velocity2__1_n_111,velocity2__1_n_112,velocity2__1_n_113,velocity2__1_n_114,velocity2__1_n_115,velocity2__1_n_116,velocity2__1_n_117,velocity2__1_n_118,velocity2__1_n_119,velocity2__1_n_120,velocity2__1_n_121,velocity2__1_n_122,velocity2__1_n_123,velocity2__1_n_124,velocity2__1_n_125,velocity2__1_n_126,velocity2__1_n_127,velocity2__1_n_128,velocity2__1_n_129,velocity2__1_n_130,velocity2__1_n_131,velocity2__1_n_132,velocity2__1_n_133,velocity2__1_n_134,velocity2__1_n_135,velocity2__1_n_136,velocity2__1_n_137,velocity2__1_n_138,velocity2__1_n_139,velocity2__1_n_140,velocity2__1_n_141,velocity2__1_n_142,velocity2__1_n_143,velocity2__1_n_144,velocity2__1_n_145,velocity2__1_n_146,velocity2__1_n_147,velocity2__1_n_148,velocity2__1_n_149,velocity2__1_n_150,velocity2__1_n_151,velocity2__1_n_152,velocity2__1_n_153}),
        .PCOUT(NLW_velocity2__2_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_velocity2__2_UNDERFLOW_UNCONNECTED));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[0] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[0]),
        .Q(output_velocity[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[10] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[10]),
        .Q(output_velocity[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[11] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[11]),
        .Q(output_velocity[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[12] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[12]),
        .Q(output_velocity[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[13] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[13]),
        .Q(output_velocity[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[14] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[14]),
        .Q(output_velocity[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[15] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[15]),
        .Q(output_velocity[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[16] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[16]),
        .Q(output_velocity[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[17] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[17]),
        .Q(output_velocity[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[18] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[18]),
        .Q(output_velocity[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[19] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[19]),
        .Q(output_velocity[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[1] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[1]),
        .Q(output_velocity[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[20] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[20]),
        .Q(output_velocity[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[21] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[21]),
        .Q(output_velocity[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[22] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[22]),
        .Q(output_velocity[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[23] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[23]),
        .Q(output_velocity[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[24] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[24]),
        .Q(output_velocity[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[25] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[25]),
        .Q(output_velocity[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[26] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[26]),
        .Q(output_velocity[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[27] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[27]),
        .Q(output_velocity[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[28] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[28]),
        .Q(output_velocity[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[29] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[29]),
        .Q(output_velocity[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[2] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[2]),
        .Q(output_velocity[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[30] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[30]),
        .Q(output_velocity[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[31] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[31]),
        .Q(output_velocity[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[3] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[3]),
        .Q(output_velocity[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[4] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[4]),
        .Q(output_velocity[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[5] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[5]),
        .Q(output_velocity[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[6] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[6]),
        .Q(output_velocity[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[7] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[7]),
        .Q(output_velocity[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[8] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[8]),
        .Q(output_velocity[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \velocity_reg[9] 
       (.C(clock),
        .CE(p_0_in),
        .D(p_1_in[9]),
        .Q(output_velocity[9]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
