// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep 14 17:10:15 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Xilinx/Projects/pid_controller/pid_controller.gen/sources_1/bd/design_1/ip/design_1_term_calculation_0_0/design_1_term_calculation_0_0_stub.v
// Design      : design_1_term_calculation_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "term_calculation,Vivado 2021.1" *)
module design_1_term_calculation_0_0(clock, error, integral, derivative, k_p, k_i, k_d, 
  output_velocity, new_velocity_available)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],error[31:0],integral[31:0],derivative[31:0],k_p[11:0],k_i[11:0],k_d[11:0],output_velocity[31:0],new_velocity_available[0:0]" */;
  input [0:0]clock;
  input [31:0]error;
  input [31:0]integral;
  input [31:0]derivative;
  input [11:0]k_p;
  input [11:0]k_i;
  input [11:0]k_d;
  output [31:0]output_velocity;
  output [0:0]new_velocity_available;
endmodule
