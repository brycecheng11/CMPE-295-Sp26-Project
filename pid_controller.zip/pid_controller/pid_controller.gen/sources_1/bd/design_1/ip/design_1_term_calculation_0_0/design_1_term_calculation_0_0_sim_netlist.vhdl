-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Mon Sep 14 17:10:15 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top design_1_term_calculation_0_0 -prefix
--               design_1_term_calculation_0_0_ design_1_term_calculation_0_0_sim_netlist.vhdl
-- Design      : design_1_term_calculation_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_term_calculation_0_0_term_calculation is
  port (
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 );
    k_i : in STD_LOGIC_VECTOR ( 11 downto 0 );
    integral : in STD_LOGIC_VECTOR ( 31 downto 0 );
    k_d : in STD_LOGIC_VECTOR ( 11 downto 0 );
    derivative : in STD_LOGIC_VECTOR ( 31 downto 0 );
    k_p : in STD_LOGIC_VECTOR ( 11 downto 0 );
    error : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clock : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
end design_1_term_calculation_0_0_term_calculation;

architecture STRUCTURE of design_1_term_calculation_0_0_term_calculation is
  signal \^output_velocity\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal p_0_in : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \velocity0__0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__0_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry__0_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry__0_n_3\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__1_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry__1_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry__1_n_3\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__2_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry__2_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry__2_n_3\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_i_8_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__3_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry__3_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry__3_n_3\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_i_8_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__4_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry__4_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry__4_n_3\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_i_8_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__5_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry__5_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry__5_n_3\ : STD_LOGIC;
  signal \velocity0__0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__6_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__6_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__6_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__6_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__6_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__6_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry__6_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry__6_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry__6_n_3\ : STD_LOGIC;
  signal \velocity0__0_carry_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_i_5_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_i_6_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_i_7_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_n_0\ : STD_LOGIC;
  signal \velocity0__0_carry_n_1\ : STD_LOGIC;
  signal \velocity0__0_carry_n_2\ : STD_LOGIC;
  signal \velocity0__0_carry_n_3\ : STD_LOGIC;
  signal \velocity0__93_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__0_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__0_n_1\ : STD_LOGIC;
  signal \velocity0__93_carry__0_n_2\ : STD_LOGIC;
  signal \velocity0__93_carry__0_n_3\ : STD_LOGIC;
  signal \velocity0__93_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry__1_n_2\ : STD_LOGIC;
  signal \velocity0__93_carry__1_n_3\ : STD_LOGIC;
  signal \velocity0__93_carry_i_1_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry_i_2_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry_i_3_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry_i_4_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry_n_0\ : STD_LOGIC;
  signal \velocity0__93_carry_n_1\ : STD_LOGIC;
  signal \velocity0__93_carry_n_2\ : STD_LOGIC;
  signal \velocity0__93_carry_n_3\ : STD_LOGIC;
  signal \velocity1__0_n_100\ : STD_LOGIC;
  signal \velocity1__0_n_101\ : STD_LOGIC;
  signal \velocity1__0_n_102\ : STD_LOGIC;
  signal \velocity1__0_n_103\ : STD_LOGIC;
  signal \velocity1__0_n_104\ : STD_LOGIC;
  signal \velocity1__0_n_105\ : STD_LOGIC;
  signal \velocity1__0_n_58\ : STD_LOGIC;
  signal \velocity1__0_n_59\ : STD_LOGIC;
  signal \velocity1__0_n_60\ : STD_LOGIC;
  signal \velocity1__0_n_61\ : STD_LOGIC;
  signal \velocity1__0_n_62\ : STD_LOGIC;
  signal \velocity1__0_n_63\ : STD_LOGIC;
  signal \velocity1__0_n_64\ : STD_LOGIC;
  signal \velocity1__0_n_65\ : STD_LOGIC;
  signal \velocity1__0_n_66\ : STD_LOGIC;
  signal \velocity1__0_n_67\ : STD_LOGIC;
  signal \velocity1__0_n_68\ : STD_LOGIC;
  signal \velocity1__0_n_69\ : STD_LOGIC;
  signal \velocity1__0_n_70\ : STD_LOGIC;
  signal \velocity1__0_n_71\ : STD_LOGIC;
  signal \velocity1__0_n_72\ : STD_LOGIC;
  signal \velocity1__0_n_73\ : STD_LOGIC;
  signal \velocity1__0_n_74\ : STD_LOGIC;
  signal \velocity1__0_n_75\ : STD_LOGIC;
  signal \velocity1__0_n_76\ : STD_LOGIC;
  signal \velocity1__0_n_77\ : STD_LOGIC;
  signal \velocity1__0_n_78\ : STD_LOGIC;
  signal \velocity1__0_n_79\ : STD_LOGIC;
  signal \velocity1__0_n_80\ : STD_LOGIC;
  signal \velocity1__0_n_81\ : STD_LOGIC;
  signal \velocity1__0_n_82\ : STD_LOGIC;
  signal \velocity1__0_n_83\ : STD_LOGIC;
  signal \velocity1__0_n_84\ : STD_LOGIC;
  signal \velocity1__0_n_85\ : STD_LOGIC;
  signal \velocity1__0_n_86\ : STD_LOGIC;
  signal \velocity1__0_n_87\ : STD_LOGIC;
  signal \velocity1__0_n_88\ : STD_LOGIC;
  signal \velocity1__0_n_89\ : STD_LOGIC;
  signal \velocity1__0_n_90\ : STD_LOGIC;
  signal \velocity1__0_n_91\ : STD_LOGIC;
  signal \velocity1__0_n_92\ : STD_LOGIC;
  signal \velocity1__0_n_93\ : STD_LOGIC;
  signal \velocity1__0_n_94\ : STD_LOGIC;
  signal \velocity1__0_n_95\ : STD_LOGIC;
  signal \velocity1__0_n_96\ : STD_LOGIC;
  signal \velocity1__0_n_97\ : STD_LOGIC;
  signal \velocity1__0_n_98\ : STD_LOGIC;
  signal \velocity1__0_n_99\ : STD_LOGIC;
  signal velocity1_n_10 : STD_LOGIC;
  signal velocity1_n_100 : STD_LOGIC;
  signal velocity1_n_101 : STD_LOGIC;
  signal velocity1_n_102 : STD_LOGIC;
  signal velocity1_n_103 : STD_LOGIC;
  signal velocity1_n_104 : STD_LOGIC;
  signal velocity1_n_105 : STD_LOGIC;
  signal velocity1_n_106 : STD_LOGIC;
  signal velocity1_n_107 : STD_LOGIC;
  signal velocity1_n_108 : STD_LOGIC;
  signal velocity1_n_109 : STD_LOGIC;
  signal velocity1_n_11 : STD_LOGIC;
  signal velocity1_n_110 : STD_LOGIC;
  signal velocity1_n_111 : STD_LOGIC;
  signal velocity1_n_112 : STD_LOGIC;
  signal velocity1_n_113 : STD_LOGIC;
  signal velocity1_n_114 : STD_LOGIC;
  signal velocity1_n_115 : STD_LOGIC;
  signal velocity1_n_116 : STD_LOGIC;
  signal velocity1_n_117 : STD_LOGIC;
  signal velocity1_n_118 : STD_LOGIC;
  signal velocity1_n_119 : STD_LOGIC;
  signal velocity1_n_12 : STD_LOGIC;
  signal velocity1_n_120 : STD_LOGIC;
  signal velocity1_n_121 : STD_LOGIC;
  signal velocity1_n_122 : STD_LOGIC;
  signal velocity1_n_123 : STD_LOGIC;
  signal velocity1_n_124 : STD_LOGIC;
  signal velocity1_n_125 : STD_LOGIC;
  signal velocity1_n_126 : STD_LOGIC;
  signal velocity1_n_127 : STD_LOGIC;
  signal velocity1_n_128 : STD_LOGIC;
  signal velocity1_n_129 : STD_LOGIC;
  signal velocity1_n_13 : STD_LOGIC;
  signal velocity1_n_130 : STD_LOGIC;
  signal velocity1_n_131 : STD_LOGIC;
  signal velocity1_n_132 : STD_LOGIC;
  signal velocity1_n_133 : STD_LOGIC;
  signal velocity1_n_134 : STD_LOGIC;
  signal velocity1_n_135 : STD_LOGIC;
  signal velocity1_n_136 : STD_LOGIC;
  signal velocity1_n_137 : STD_LOGIC;
  signal velocity1_n_138 : STD_LOGIC;
  signal velocity1_n_139 : STD_LOGIC;
  signal velocity1_n_14 : STD_LOGIC;
  signal velocity1_n_140 : STD_LOGIC;
  signal velocity1_n_141 : STD_LOGIC;
  signal velocity1_n_142 : STD_LOGIC;
  signal velocity1_n_143 : STD_LOGIC;
  signal velocity1_n_144 : STD_LOGIC;
  signal velocity1_n_145 : STD_LOGIC;
  signal velocity1_n_146 : STD_LOGIC;
  signal velocity1_n_147 : STD_LOGIC;
  signal velocity1_n_148 : STD_LOGIC;
  signal velocity1_n_149 : STD_LOGIC;
  signal velocity1_n_15 : STD_LOGIC;
  signal velocity1_n_150 : STD_LOGIC;
  signal velocity1_n_151 : STD_LOGIC;
  signal velocity1_n_152 : STD_LOGIC;
  signal velocity1_n_153 : STD_LOGIC;
  signal velocity1_n_16 : STD_LOGIC;
  signal velocity1_n_17 : STD_LOGIC;
  signal velocity1_n_18 : STD_LOGIC;
  signal velocity1_n_19 : STD_LOGIC;
  signal velocity1_n_20 : STD_LOGIC;
  signal velocity1_n_21 : STD_LOGIC;
  signal velocity1_n_22 : STD_LOGIC;
  signal velocity1_n_23 : STD_LOGIC;
  signal velocity1_n_58 : STD_LOGIC;
  signal velocity1_n_59 : STD_LOGIC;
  signal velocity1_n_6 : STD_LOGIC;
  signal velocity1_n_60 : STD_LOGIC;
  signal velocity1_n_61 : STD_LOGIC;
  signal velocity1_n_62 : STD_LOGIC;
  signal velocity1_n_63 : STD_LOGIC;
  signal velocity1_n_64 : STD_LOGIC;
  signal velocity1_n_65 : STD_LOGIC;
  signal velocity1_n_66 : STD_LOGIC;
  signal velocity1_n_67 : STD_LOGIC;
  signal velocity1_n_68 : STD_LOGIC;
  signal velocity1_n_69 : STD_LOGIC;
  signal velocity1_n_7 : STD_LOGIC;
  signal velocity1_n_70 : STD_LOGIC;
  signal velocity1_n_71 : STD_LOGIC;
  signal velocity1_n_72 : STD_LOGIC;
  signal velocity1_n_73 : STD_LOGIC;
  signal velocity1_n_74 : STD_LOGIC;
  signal velocity1_n_75 : STD_LOGIC;
  signal velocity1_n_76 : STD_LOGIC;
  signal velocity1_n_77 : STD_LOGIC;
  signal velocity1_n_78 : STD_LOGIC;
  signal velocity1_n_79 : STD_LOGIC;
  signal velocity1_n_8 : STD_LOGIC;
  signal velocity1_n_80 : STD_LOGIC;
  signal velocity1_n_81 : STD_LOGIC;
  signal velocity1_n_82 : STD_LOGIC;
  signal velocity1_n_83 : STD_LOGIC;
  signal velocity1_n_84 : STD_LOGIC;
  signal velocity1_n_85 : STD_LOGIC;
  signal velocity1_n_86 : STD_LOGIC;
  signal velocity1_n_87 : STD_LOGIC;
  signal velocity1_n_88 : STD_LOGIC;
  signal velocity1_n_89 : STD_LOGIC;
  signal velocity1_n_9 : STD_LOGIC;
  signal velocity1_n_90 : STD_LOGIC;
  signal velocity1_n_91 : STD_LOGIC;
  signal velocity1_n_92 : STD_LOGIC;
  signal velocity1_n_93 : STD_LOGIC;
  signal velocity1_n_94 : STD_LOGIC;
  signal velocity1_n_95 : STD_LOGIC;
  signal velocity1_n_96 : STD_LOGIC;
  signal velocity1_n_97 : STD_LOGIC;
  signal velocity1_n_98 : STD_LOGIC;
  signal velocity1_n_99 : STD_LOGIC;
  signal \velocity2__0_n_100\ : STD_LOGIC;
  signal \velocity2__0_n_101\ : STD_LOGIC;
  signal \velocity2__0_n_102\ : STD_LOGIC;
  signal \velocity2__0_n_103\ : STD_LOGIC;
  signal \velocity2__0_n_104\ : STD_LOGIC;
  signal \velocity2__0_n_105\ : STD_LOGIC;
  signal \velocity2__0_n_58\ : STD_LOGIC;
  signal \velocity2__0_n_59\ : STD_LOGIC;
  signal \velocity2__0_n_60\ : STD_LOGIC;
  signal \velocity2__0_n_61\ : STD_LOGIC;
  signal \velocity2__0_n_62\ : STD_LOGIC;
  signal \velocity2__0_n_63\ : STD_LOGIC;
  signal \velocity2__0_n_64\ : STD_LOGIC;
  signal \velocity2__0_n_65\ : STD_LOGIC;
  signal \velocity2__0_n_66\ : STD_LOGIC;
  signal \velocity2__0_n_67\ : STD_LOGIC;
  signal \velocity2__0_n_68\ : STD_LOGIC;
  signal \velocity2__0_n_69\ : STD_LOGIC;
  signal \velocity2__0_n_70\ : STD_LOGIC;
  signal \velocity2__0_n_71\ : STD_LOGIC;
  signal \velocity2__0_n_72\ : STD_LOGIC;
  signal \velocity2__0_n_73\ : STD_LOGIC;
  signal \velocity2__0_n_74\ : STD_LOGIC;
  signal \velocity2__0_n_75\ : STD_LOGIC;
  signal \velocity2__0_n_76\ : STD_LOGIC;
  signal \velocity2__0_n_77\ : STD_LOGIC;
  signal \velocity2__0_n_78\ : STD_LOGIC;
  signal \velocity2__0_n_79\ : STD_LOGIC;
  signal \velocity2__0_n_80\ : STD_LOGIC;
  signal \velocity2__0_n_81\ : STD_LOGIC;
  signal \velocity2__0_n_82\ : STD_LOGIC;
  signal \velocity2__0_n_83\ : STD_LOGIC;
  signal \velocity2__0_n_84\ : STD_LOGIC;
  signal \velocity2__0_n_85\ : STD_LOGIC;
  signal \velocity2__0_n_86\ : STD_LOGIC;
  signal \velocity2__0_n_87\ : STD_LOGIC;
  signal \velocity2__0_n_88\ : STD_LOGIC;
  signal \velocity2__0_n_89\ : STD_LOGIC;
  signal \velocity2__0_n_90\ : STD_LOGIC;
  signal \velocity2__0_n_91\ : STD_LOGIC;
  signal \velocity2__0_n_92\ : STD_LOGIC;
  signal \velocity2__0_n_93\ : STD_LOGIC;
  signal \velocity2__0_n_94\ : STD_LOGIC;
  signal \velocity2__0_n_95\ : STD_LOGIC;
  signal \velocity2__0_n_96\ : STD_LOGIC;
  signal \velocity2__0_n_97\ : STD_LOGIC;
  signal \velocity2__0_n_98\ : STD_LOGIC;
  signal \velocity2__0_n_99\ : STD_LOGIC;
  signal \velocity2__1_n_10\ : STD_LOGIC;
  signal \velocity2__1_n_100\ : STD_LOGIC;
  signal \velocity2__1_n_101\ : STD_LOGIC;
  signal \velocity2__1_n_102\ : STD_LOGIC;
  signal \velocity2__1_n_103\ : STD_LOGIC;
  signal \velocity2__1_n_104\ : STD_LOGIC;
  signal \velocity2__1_n_105\ : STD_LOGIC;
  signal \velocity2__1_n_106\ : STD_LOGIC;
  signal \velocity2__1_n_107\ : STD_LOGIC;
  signal \velocity2__1_n_108\ : STD_LOGIC;
  signal \velocity2__1_n_109\ : STD_LOGIC;
  signal \velocity2__1_n_11\ : STD_LOGIC;
  signal \velocity2__1_n_110\ : STD_LOGIC;
  signal \velocity2__1_n_111\ : STD_LOGIC;
  signal \velocity2__1_n_112\ : STD_LOGIC;
  signal \velocity2__1_n_113\ : STD_LOGIC;
  signal \velocity2__1_n_114\ : STD_LOGIC;
  signal \velocity2__1_n_115\ : STD_LOGIC;
  signal \velocity2__1_n_116\ : STD_LOGIC;
  signal \velocity2__1_n_117\ : STD_LOGIC;
  signal \velocity2__1_n_118\ : STD_LOGIC;
  signal \velocity2__1_n_119\ : STD_LOGIC;
  signal \velocity2__1_n_12\ : STD_LOGIC;
  signal \velocity2__1_n_120\ : STD_LOGIC;
  signal \velocity2__1_n_121\ : STD_LOGIC;
  signal \velocity2__1_n_122\ : STD_LOGIC;
  signal \velocity2__1_n_123\ : STD_LOGIC;
  signal \velocity2__1_n_124\ : STD_LOGIC;
  signal \velocity2__1_n_125\ : STD_LOGIC;
  signal \velocity2__1_n_126\ : STD_LOGIC;
  signal \velocity2__1_n_127\ : STD_LOGIC;
  signal \velocity2__1_n_128\ : STD_LOGIC;
  signal \velocity2__1_n_129\ : STD_LOGIC;
  signal \velocity2__1_n_13\ : STD_LOGIC;
  signal \velocity2__1_n_130\ : STD_LOGIC;
  signal \velocity2__1_n_131\ : STD_LOGIC;
  signal \velocity2__1_n_132\ : STD_LOGIC;
  signal \velocity2__1_n_133\ : STD_LOGIC;
  signal \velocity2__1_n_134\ : STD_LOGIC;
  signal \velocity2__1_n_135\ : STD_LOGIC;
  signal \velocity2__1_n_136\ : STD_LOGIC;
  signal \velocity2__1_n_137\ : STD_LOGIC;
  signal \velocity2__1_n_138\ : STD_LOGIC;
  signal \velocity2__1_n_139\ : STD_LOGIC;
  signal \velocity2__1_n_14\ : STD_LOGIC;
  signal \velocity2__1_n_140\ : STD_LOGIC;
  signal \velocity2__1_n_141\ : STD_LOGIC;
  signal \velocity2__1_n_142\ : STD_LOGIC;
  signal \velocity2__1_n_143\ : STD_LOGIC;
  signal \velocity2__1_n_144\ : STD_LOGIC;
  signal \velocity2__1_n_145\ : STD_LOGIC;
  signal \velocity2__1_n_146\ : STD_LOGIC;
  signal \velocity2__1_n_147\ : STD_LOGIC;
  signal \velocity2__1_n_148\ : STD_LOGIC;
  signal \velocity2__1_n_149\ : STD_LOGIC;
  signal \velocity2__1_n_15\ : STD_LOGIC;
  signal \velocity2__1_n_150\ : STD_LOGIC;
  signal \velocity2__1_n_151\ : STD_LOGIC;
  signal \velocity2__1_n_152\ : STD_LOGIC;
  signal \velocity2__1_n_153\ : STD_LOGIC;
  signal \velocity2__1_n_16\ : STD_LOGIC;
  signal \velocity2__1_n_17\ : STD_LOGIC;
  signal \velocity2__1_n_18\ : STD_LOGIC;
  signal \velocity2__1_n_19\ : STD_LOGIC;
  signal \velocity2__1_n_20\ : STD_LOGIC;
  signal \velocity2__1_n_21\ : STD_LOGIC;
  signal \velocity2__1_n_22\ : STD_LOGIC;
  signal \velocity2__1_n_23\ : STD_LOGIC;
  signal \velocity2__1_n_58\ : STD_LOGIC;
  signal \velocity2__1_n_59\ : STD_LOGIC;
  signal \velocity2__1_n_6\ : STD_LOGIC;
  signal \velocity2__1_n_60\ : STD_LOGIC;
  signal \velocity2__1_n_61\ : STD_LOGIC;
  signal \velocity2__1_n_62\ : STD_LOGIC;
  signal \velocity2__1_n_63\ : STD_LOGIC;
  signal \velocity2__1_n_64\ : STD_LOGIC;
  signal \velocity2__1_n_65\ : STD_LOGIC;
  signal \velocity2__1_n_66\ : STD_LOGIC;
  signal \velocity2__1_n_67\ : STD_LOGIC;
  signal \velocity2__1_n_68\ : STD_LOGIC;
  signal \velocity2__1_n_69\ : STD_LOGIC;
  signal \velocity2__1_n_7\ : STD_LOGIC;
  signal \velocity2__1_n_70\ : STD_LOGIC;
  signal \velocity2__1_n_71\ : STD_LOGIC;
  signal \velocity2__1_n_72\ : STD_LOGIC;
  signal \velocity2__1_n_73\ : STD_LOGIC;
  signal \velocity2__1_n_74\ : STD_LOGIC;
  signal \velocity2__1_n_75\ : STD_LOGIC;
  signal \velocity2__1_n_76\ : STD_LOGIC;
  signal \velocity2__1_n_77\ : STD_LOGIC;
  signal \velocity2__1_n_78\ : STD_LOGIC;
  signal \velocity2__1_n_79\ : STD_LOGIC;
  signal \velocity2__1_n_8\ : STD_LOGIC;
  signal \velocity2__1_n_80\ : STD_LOGIC;
  signal \velocity2__1_n_81\ : STD_LOGIC;
  signal \velocity2__1_n_82\ : STD_LOGIC;
  signal \velocity2__1_n_83\ : STD_LOGIC;
  signal \velocity2__1_n_84\ : STD_LOGIC;
  signal \velocity2__1_n_85\ : STD_LOGIC;
  signal \velocity2__1_n_86\ : STD_LOGIC;
  signal \velocity2__1_n_87\ : STD_LOGIC;
  signal \velocity2__1_n_88\ : STD_LOGIC;
  signal \velocity2__1_n_89\ : STD_LOGIC;
  signal \velocity2__1_n_9\ : STD_LOGIC;
  signal \velocity2__1_n_90\ : STD_LOGIC;
  signal \velocity2__1_n_91\ : STD_LOGIC;
  signal \velocity2__1_n_92\ : STD_LOGIC;
  signal \velocity2__1_n_93\ : STD_LOGIC;
  signal \velocity2__1_n_94\ : STD_LOGIC;
  signal \velocity2__1_n_95\ : STD_LOGIC;
  signal \velocity2__1_n_96\ : STD_LOGIC;
  signal \velocity2__1_n_97\ : STD_LOGIC;
  signal \velocity2__1_n_98\ : STD_LOGIC;
  signal \velocity2__1_n_99\ : STD_LOGIC;
  signal \velocity2__2_n_100\ : STD_LOGIC;
  signal \velocity2__2_n_101\ : STD_LOGIC;
  signal \velocity2__2_n_102\ : STD_LOGIC;
  signal \velocity2__2_n_103\ : STD_LOGIC;
  signal \velocity2__2_n_104\ : STD_LOGIC;
  signal \velocity2__2_n_105\ : STD_LOGIC;
  signal \velocity2__2_n_58\ : STD_LOGIC;
  signal \velocity2__2_n_59\ : STD_LOGIC;
  signal \velocity2__2_n_60\ : STD_LOGIC;
  signal \velocity2__2_n_61\ : STD_LOGIC;
  signal \velocity2__2_n_62\ : STD_LOGIC;
  signal \velocity2__2_n_63\ : STD_LOGIC;
  signal \velocity2__2_n_64\ : STD_LOGIC;
  signal \velocity2__2_n_65\ : STD_LOGIC;
  signal \velocity2__2_n_66\ : STD_LOGIC;
  signal \velocity2__2_n_67\ : STD_LOGIC;
  signal \velocity2__2_n_68\ : STD_LOGIC;
  signal \velocity2__2_n_69\ : STD_LOGIC;
  signal \velocity2__2_n_70\ : STD_LOGIC;
  signal \velocity2__2_n_71\ : STD_LOGIC;
  signal \velocity2__2_n_72\ : STD_LOGIC;
  signal \velocity2__2_n_73\ : STD_LOGIC;
  signal \velocity2__2_n_74\ : STD_LOGIC;
  signal \velocity2__2_n_75\ : STD_LOGIC;
  signal \velocity2__2_n_76\ : STD_LOGIC;
  signal \velocity2__2_n_77\ : STD_LOGIC;
  signal \velocity2__2_n_78\ : STD_LOGIC;
  signal \velocity2__2_n_79\ : STD_LOGIC;
  signal \velocity2__2_n_80\ : STD_LOGIC;
  signal \velocity2__2_n_81\ : STD_LOGIC;
  signal \velocity2__2_n_82\ : STD_LOGIC;
  signal \velocity2__2_n_83\ : STD_LOGIC;
  signal \velocity2__2_n_84\ : STD_LOGIC;
  signal \velocity2__2_n_85\ : STD_LOGIC;
  signal \velocity2__2_n_86\ : STD_LOGIC;
  signal \velocity2__2_n_87\ : STD_LOGIC;
  signal \velocity2__2_n_88\ : STD_LOGIC;
  signal \velocity2__2_n_89\ : STD_LOGIC;
  signal \velocity2__2_n_90\ : STD_LOGIC;
  signal \velocity2__2_n_91\ : STD_LOGIC;
  signal \velocity2__2_n_92\ : STD_LOGIC;
  signal \velocity2__2_n_93\ : STD_LOGIC;
  signal \velocity2__2_n_94\ : STD_LOGIC;
  signal \velocity2__2_n_95\ : STD_LOGIC;
  signal \velocity2__2_n_96\ : STD_LOGIC;
  signal \velocity2__2_n_97\ : STD_LOGIC;
  signal \velocity2__2_n_98\ : STD_LOGIC;
  signal \velocity2__2_n_99\ : STD_LOGIC;
  signal velocity2_n_10 : STD_LOGIC;
  signal velocity2_n_100 : STD_LOGIC;
  signal velocity2_n_101 : STD_LOGIC;
  signal velocity2_n_102 : STD_LOGIC;
  signal velocity2_n_103 : STD_LOGIC;
  signal velocity2_n_104 : STD_LOGIC;
  signal velocity2_n_105 : STD_LOGIC;
  signal velocity2_n_106 : STD_LOGIC;
  signal velocity2_n_107 : STD_LOGIC;
  signal velocity2_n_108 : STD_LOGIC;
  signal velocity2_n_109 : STD_LOGIC;
  signal velocity2_n_11 : STD_LOGIC;
  signal velocity2_n_110 : STD_LOGIC;
  signal velocity2_n_111 : STD_LOGIC;
  signal velocity2_n_112 : STD_LOGIC;
  signal velocity2_n_113 : STD_LOGIC;
  signal velocity2_n_114 : STD_LOGIC;
  signal velocity2_n_115 : STD_LOGIC;
  signal velocity2_n_116 : STD_LOGIC;
  signal velocity2_n_117 : STD_LOGIC;
  signal velocity2_n_118 : STD_LOGIC;
  signal velocity2_n_119 : STD_LOGIC;
  signal velocity2_n_12 : STD_LOGIC;
  signal velocity2_n_120 : STD_LOGIC;
  signal velocity2_n_121 : STD_LOGIC;
  signal velocity2_n_122 : STD_LOGIC;
  signal velocity2_n_123 : STD_LOGIC;
  signal velocity2_n_124 : STD_LOGIC;
  signal velocity2_n_125 : STD_LOGIC;
  signal velocity2_n_126 : STD_LOGIC;
  signal velocity2_n_127 : STD_LOGIC;
  signal velocity2_n_128 : STD_LOGIC;
  signal velocity2_n_129 : STD_LOGIC;
  signal velocity2_n_13 : STD_LOGIC;
  signal velocity2_n_130 : STD_LOGIC;
  signal velocity2_n_131 : STD_LOGIC;
  signal velocity2_n_132 : STD_LOGIC;
  signal velocity2_n_133 : STD_LOGIC;
  signal velocity2_n_134 : STD_LOGIC;
  signal velocity2_n_135 : STD_LOGIC;
  signal velocity2_n_136 : STD_LOGIC;
  signal velocity2_n_137 : STD_LOGIC;
  signal velocity2_n_138 : STD_LOGIC;
  signal velocity2_n_139 : STD_LOGIC;
  signal velocity2_n_14 : STD_LOGIC;
  signal velocity2_n_140 : STD_LOGIC;
  signal velocity2_n_141 : STD_LOGIC;
  signal velocity2_n_142 : STD_LOGIC;
  signal velocity2_n_143 : STD_LOGIC;
  signal velocity2_n_144 : STD_LOGIC;
  signal velocity2_n_145 : STD_LOGIC;
  signal velocity2_n_146 : STD_LOGIC;
  signal velocity2_n_147 : STD_LOGIC;
  signal velocity2_n_148 : STD_LOGIC;
  signal velocity2_n_149 : STD_LOGIC;
  signal velocity2_n_15 : STD_LOGIC;
  signal velocity2_n_150 : STD_LOGIC;
  signal velocity2_n_151 : STD_LOGIC;
  signal velocity2_n_152 : STD_LOGIC;
  signal velocity2_n_153 : STD_LOGIC;
  signal velocity2_n_16 : STD_LOGIC;
  signal velocity2_n_17 : STD_LOGIC;
  signal velocity2_n_18 : STD_LOGIC;
  signal velocity2_n_19 : STD_LOGIC;
  signal velocity2_n_20 : STD_LOGIC;
  signal velocity2_n_21 : STD_LOGIC;
  signal velocity2_n_22 : STD_LOGIC;
  signal velocity2_n_23 : STD_LOGIC;
  signal velocity2_n_58 : STD_LOGIC;
  signal velocity2_n_59 : STD_LOGIC;
  signal velocity2_n_6 : STD_LOGIC;
  signal velocity2_n_60 : STD_LOGIC;
  signal velocity2_n_61 : STD_LOGIC;
  signal velocity2_n_62 : STD_LOGIC;
  signal velocity2_n_63 : STD_LOGIC;
  signal velocity2_n_64 : STD_LOGIC;
  signal velocity2_n_65 : STD_LOGIC;
  signal velocity2_n_66 : STD_LOGIC;
  signal velocity2_n_67 : STD_LOGIC;
  signal velocity2_n_68 : STD_LOGIC;
  signal velocity2_n_69 : STD_LOGIC;
  signal velocity2_n_7 : STD_LOGIC;
  signal velocity2_n_70 : STD_LOGIC;
  signal velocity2_n_71 : STD_LOGIC;
  signal velocity2_n_72 : STD_LOGIC;
  signal velocity2_n_73 : STD_LOGIC;
  signal velocity2_n_74 : STD_LOGIC;
  signal velocity2_n_75 : STD_LOGIC;
  signal velocity2_n_76 : STD_LOGIC;
  signal velocity2_n_77 : STD_LOGIC;
  signal velocity2_n_78 : STD_LOGIC;
  signal velocity2_n_79 : STD_LOGIC;
  signal velocity2_n_8 : STD_LOGIC;
  signal velocity2_n_80 : STD_LOGIC;
  signal velocity2_n_81 : STD_LOGIC;
  signal velocity2_n_82 : STD_LOGIC;
  signal velocity2_n_83 : STD_LOGIC;
  signal velocity2_n_84 : STD_LOGIC;
  signal velocity2_n_85 : STD_LOGIC;
  signal velocity2_n_86 : STD_LOGIC;
  signal velocity2_n_87 : STD_LOGIC;
  signal velocity2_n_88 : STD_LOGIC;
  signal velocity2_n_89 : STD_LOGIC;
  signal velocity2_n_9 : STD_LOGIC;
  signal velocity2_n_90 : STD_LOGIC;
  signal velocity2_n_91 : STD_LOGIC;
  signal velocity2_n_92 : STD_LOGIC;
  signal velocity2_n_93 : STD_LOGIC;
  signal velocity2_n_94 : STD_LOGIC;
  signal velocity2_n_95 : STD_LOGIC;
  signal velocity2_n_96 : STD_LOGIC;
  signal velocity2_n_97 : STD_LOGIC;
  signal velocity2_n_98 : STD_LOGIC;
  signal velocity2_n_99 : STD_LOGIC;
  signal \NLW_velocity0__0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_velocity0__93_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity0__93_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity0__93_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_velocity0__93_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_velocity1_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity1_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity1_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity1_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity1_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity1_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity1_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_velocity1_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1__0_CARRYCASCOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity1__0_MULTSIGNOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity1__0_OVERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity1__0_PATTERNBDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity1__0_PATTERNDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity1__0_UNDERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity1__0_ACOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal \NLW_velocity1__0_BCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_velocity1__0_CARRYOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity1__0_PCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal NLW_velocity2_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity2_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity2_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity2_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity2_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity2_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_velocity2_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_velocity2_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity2__0_CARRYCASCOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__0_MULTSIGNOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__0_OVERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__0_PATTERNBDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__0_PATTERNDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__0_UNDERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__0_ACOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal \NLW_velocity2__0_BCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_velocity2__0_CARRYOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity2__0_PCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal \NLW_velocity2__1_CARRYCASCOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__1_MULTSIGNOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__1_OVERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__1_PATTERNBDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__1_PATTERNDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__1_UNDERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__1_ACOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal \NLW_velocity2__1_CARRYOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity2__2_CARRYCASCOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__2_MULTSIGNOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__2_OVERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__2_PATTERNBDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__2_PATTERNDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__2_UNDERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_velocity2__2_ACOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal \NLW_velocity2__2_BCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_velocity2__2_CARRYOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_velocity2__2_PCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 47 downto 0 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \velocity0__0_carry\ : label is 35;
  attribute ADDER_THRESHOLD of \velocity0__0_carry__0\ : label is 35;
  attribute HLUTNM : string;
  attribute HLUTNM of \velocity0__0_carry__0_i_1\ : label is "lutpair6";
  attribute HLUTNM of \velocity0__0_carry__0_i_2\ : label is "lutpair5";
  attribute HLUTNM of \velocity0__0_carry__0_i_3\ : label is "lutpair4";
  attribute HLUTNM of \velocity0__0_carry__0_i_4\ : label is "lutpair3";
  attribute HLUTNM of \velocity0__0_carry__0_i_5\ : label is "lutpair7";
  attribute HLUTNM of \velocity0__0_carry__0_i_6\ : label is "lutpair6";
  attribute HLUTNM of \velocity0__0_carry__0_i_7\ : label is "lutpair5";
  attribute HLUTNM of \velocity0__0_carry__0_i_8\ : label is "lutpair4";
  attribute ADDER_THRESHOLD of \velocity0__0_carry__1\ : label is 35;
  attribute HLUTNM of \velocity0__0_carry__1_i_1\ : label is "lutpair10";
  attribute HLUTNM of \velocity0__0_carry__1_i_2\ : label is "lutpair9";
  attribute HLUTNM of \velocity0__0_carry__1_i_3\ : label is "lutpair8";
  attribute HLUTNM of \velocity0__0_carry__1_i_4\ : label is "lutpair7";
  attribute HLUTNM of \velocity0__0_carry__1_i_5\ : label is "lutpair11";
  attribute HLUTNM of \velocity0__0_carry__1_i_6\ : label is "lutpair10";
  attribute HLUTNM of \velocity0__0_carry__1_i_7\ : label is "lutpair9";
  attribute HLUTNM of \velocity0__0_carry__1_i_8\ : label is "lutpair8";
  attribute ADDER_THRESHOLD of \velocity0__0_carry__2\ : label is 35;
  attribute HLUTNM of \velocity0__0_carry__2_i_1\ : label is "lutpair14";
  attribute HLUTNM of \velocity0__0_carry__2_i_2\ : label is "lutpair13";
  attribute HLUTNM of \velocity0__0_carry__2_i_3\ : label is "lutpair12";
  attribute HLUTNM of \velocity0__0_carry__2_i_4\ : label is "lutpair11";
  attribute HLUTNM of \velocity0__0_carry__2_i_5\ : label is "lutpair15";
  attribute HLUTNM of \velocity0__0_carry__2_i_6\ : label is "lutpair14";
  attribute HLUTNM of \velocity0__0_carry__2_i_7\ : label is "lutpair13";
  attribute HLUTNM of \velocity0__0_carry__2_i_8\ : label is "lutpair12";
  attribute ADDER_THRESHOLD of \velocity0__0_carry__3\ : label is 35;
  attribute HLUTNM of \velocity0__0_carry__3_i_1\ : label is "lutpair18";
  attribute HLUTNM of \velocity0__0_carry__3_i_2\ : label is "lutpair17";
  attribute HLUTNM of \velocity0__0_carry__3_i_3\ : label is "lutpair16";
  attribute HLUTNM of \velocity0__0_carry__3_i_4\ : label is "lutpair15";
  attribute HLUTNM of \velocity0__0_carry__3_i_5\ : label is "lutpair19";
  attribute HLUTNM of \velocity0__0_carry__3_i_6\ : label is "lutpair18";
  attribute HLUTNM of \velocity0__0_carry__3_i_7\ : label is "lutpair17";
  attribute HLUTNM of \velocity0__0_carry__3_i_8\ : label is "lutpair16";
  attribute ADDER_THRESHOLD of \velocity0__0_carry__4\ : label is 35;
  attribute HLUTNM of \velocity0__0_carry__4_i_1\ : label is "lutpair22";
  attribute HLUTNM of \velocity0__0_carry__4_i_2\ : label is "lutpair21";
  attribute HLUTNM of \velocity0__0_carry__4_i_3\ : label is "lutpair20";
  attribute HLUTNM of \velocity0__0_carry__4_i_4\ : label is "lutpair19";
  attribute HLUTNM of \velocity0__0_carry__4_i_5\ : label is "lutpair23";
  attribute HLUTNM of \velocity0__0_carry__4_i_6\ : label is "lutpair22";
  attribute HLUTNM of \velocity0__0_carry__4_i_7\ : label is "lutpair21";
  attribute HLUTNM of \velocity0__0_carry__4_i_8\ : label is "lutpair20";
  attribute ADDER_THRESHOLD of \velocity0__0_carry__5\ : label is 35;
  attribute HLUTNM of \velocity0__0_carry__5_i_1\ : label is "lutpair26";
  attribute HLUTNM of \velocity0__0_carry__5_i_2\ : label is "lutpair25";
  attribute HLUTNM of \velocity0__0_carry__5_i_3\ : label is "lutpair24";
  attribute HLUTNM of \velocity0__0_carry__5_i_4\ : label is "lutpair23";
  attribute HLUTNM of \velocity0__0_carry__5_i_5\ : label is "lutpair27";
  attribute HLUTNM of \velocity0__0_carry__5_i_6\ : label is "lutpair26";
  attribute HLUTNM of \velocity0__0_carry__5_i_7\ : label is "lutpair25";
  attribute HLUTNM of \velocity0__0_carry__5_i_8\ : label is "lutpair24";
  attribute ADDER_THRESHOLD of \velocity0__0_carry__6\ : label is 35;
  attribute HLUTNM of \velocity0__0_carry__6_i_1\ : label is "lutpair29";
  attribute HLUTNM of \velocity0__0_carry__6_i_2\ : label is "lutpair28";
  attribute HLUTNM of \velocity0__0_carry__6_i_3\ : label is "lutpair27";
  attribute HLUTNM of \velocity0__0_carry__6_i_6\ : label is "lutpair29";
  attribute HLUTNM of \velocity0__0_carry__6_i_7\ : label is "lutpair28";
  attribute HLUTNM of \velocity0__0_carry_i_1\ : label is "lutpair2";
  attribute HLUTNM of \velocity0__0_carry_i_2\ : label is "lutpair1";
  attribute HLUTNM of \velocity0__0_carry_i_3\ : label is "lutpair0";
  attribute HLUTNM of \velocity0__0_carry_i_4\ : label is "lutpair3";
  attribute HLUTNM of \velocity0__0_carry_i_5\ : label is "lutpair2";
  attribute HLUTNM of \velocity0__0_carry_i_6\ : label is "lutpair1";
  attribute HLUTNM of \velocity0__0_carry_i_7\ : label is "lutpair0";
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of velocity1 : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of \velocity1__0\ : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of velocity2 : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of \velocity2__0\ : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of \velocity2__1\ : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of \velocity2__2\ : label is "{SYNTH-13 {cell *THIS*}}";
begin
  output_velocity(31 downto 0) <= \^output_velocity\(31 downto 0);
\new_velocity_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => '1',
      D => p_0_in,
      Q => new_velocity_available(0),
      R => '0'
    );
\velocity0__0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \velocity0__0_carry_n_0\,
      CO(2) => \velocity0__0_carry_n_1\,
      CO(1) => \velocity0__0_carry_n_2\,
      CO(0) => \velocity0__0_carry_n_3\,
      CYINIT => '0',
      DI(3) => \velocity0__0_carry_i_1_n_0\,
      DI(2) => \velocity0__0_carry_i_2_n_0\,
      DI(1) => \velocity0__0_carry_i_3_n_0\,
      DI(0) => '0',
      O(3 downto 0) => p_1_in(3 downto 0),
      S(3) => \velocity0__0_carry_i_4_n_0\,
      S(2) => \velocity0__0_carry_i_5_n_0\,
      S(1) => \velocity0__0_carry_i_6_n_0\,
      S(0) => \velocity0__0_carry_i_7_n_0\
    );
\velocity0__0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__0_carry_n_0\,
      CO(3) => \velocity0__0_carry__0_n_0\,
      CO(2) => \velocity0__0_carry__0_n_1\,
      CO(1) => \velocity0__0_carry__0_n_2\,
      CO(0) => \velocity0__0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \velocity0__0_carry__0_i_1_n_0\,
      DI(2) => \velocity0__0_carry__0_i_2_n_0\,
      DI(1) => \velocity0__0_carry__0_i_3_n_0\,
      DI(0) => \velocity0__0_carry__0_i_4_n_0\,
      O(3 downto 0) => p_1_in(7 downto 4),
      S(3) => \velocity0__0_carry__0_i_5_n_0\,
      S(2) => \velocity0__0_carry__0_i_6_n_0\,
      S(1) => \velocity0__0_carry__0_i_7_n_0\,
      S(0) => \velocity0__0_carry__0_i_8_n_0\
    );
\velocity0__0_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_99,
      I1 => velocity1_n_99,
      I2 => \velocity2__1_n_99\,
      O => \velocity0__0_carry__0_i_1_n_0\
    );
\velocity0__0_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_100,
      I1 => velocity1_n_100,
      I2 => \velocity2__1_n_100\,
      O => \velocity0__0_carry__0_i_2_n_0\
    );
\velocity0__0_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_101,
      I1 => velocity1_n_101,
      I2 => \velocity2__1_n_101\,
      O => \velocity0__0_carry__0_i_3_n_0\
    );
\velocity0__0_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_102,
      I1 => velocity1_n_102,
      I2 => \velocity2__1_n_102\,
      O => \velocity0__0_carry__0_i_4_n_0\
    );
\velocity0__0_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_98,
      I1 => velocity1_n_98,
      I2 => \velocity2__1_n_98\,
      I3 => \velocity0__0_carry__0_i_1_n_0\,
      O => \velocity0__0_carry__0_i_5_n_0\
    );
\velocity0__0_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_99,
      I1 => velocity1_n_99,
      I2 => \velocity2__1_n_99\,
      I3 => \velocity0__0_carry__0_i_2_n_0\,
      O => \velocity0__0_carry__0_i_6_n_0\
    );
\velocity0__0_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_100,
      I1 => velocity1_n_100,
      I2 => \velocity2__1_n_100\,
      I3 => \velocity0__0_carry__0_i_3_n_0\,
      O => \velocity0__0_carry__0_i_7_n_0\
    );
\velocity0__0_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_101,
      I1 => velocity1_n_101,
      I2 => \velocity2__1_n_101\,
      I3 => \velocity0__0_carry__0_i_4_n_0\,
      O => \velocity0__0_carry__0_i_8_n_0\
    );
\velocity0__0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__0_carry__0_n_0\,
      CO(3) => \velocity0__0_carry__1_n_0\,
      CO(2) => \velocity0__0_carry__1_n_1\,
      CO(1) => \velocity0__0_carry__1_n_2\,
      CO(0) => \velocity0__0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \velocity0__0_carry__1_i_1_n_0\,
      DI(2) => \velocity0__0_carry__1_i_2_n_0\,
      DI(1) => \velocity0__0_carry__1_i_3_n_0\,
      DI(0) => \velocity0__0_carry__1_i_4_n_0\,
      O(3 downto 0) => p_1_in(11 downto 8),
      S(3) => \velocity0__0_carry__1_i_5_n_0\,
      S(2) => \velocity0__0_carry__1_i_6_n_0\,
      S(1) => \velocity0__0_carry__1_i_7_n_0\,
      S(0) => \velocity0__0_carry__1_i_8_n_0\
    );
\velocity0__0_carry__1_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_95,
      I1 => velocity1_n_95,
      I2 => \velocity2__1_n_95\,
      O => \velocity0__0_carry__1_i_1_n_0\
    );
\velocity0__0_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_96,
      I1 => velocity1_n_96,
      I2 => \velocity2__1_n_96\,
      O => \velocity0__0_carry__1_i_2_n_0\
    );
\velocity0__0_carry__1_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_97,
      I1 => velocity1_n_97,
      I2 => \velocity2__1_n_97\,
      O => \velocity0__0_carry__1_i_3_n_0\
    );
\velocity0__0_carry__1_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_98,
      I1 => velocity1_n_98,
      I2 => \velocity2__1_n_98\,
      O => \velocity0__0_carry__1_i_4_n_0\
    );
\velocity0__0_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_94,
      I1 => velocity1_n_94,
      I2 => \velocity2__1_n_94\,
      I3 => \velocity0__0_carry__1_i_1_n_0\,
      O => \velocity0__0_carry__1_i_5_n_0\
    );
\velocity0__0_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_95,
      I1 => velocity1_n_95,
      I2 => \velocity2__1_n_95\,
      I3 => \velocity0__0_carry__1_i_2_n_0\,
      O => \velocity0__0_carry__1_i_6_n_0\
    );
\velocity0__0_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_96,
      I1 => velocity1_n_96,
      I2 => \velocity2__1_n_96\,
      I3 => \velocity0__0_carry__1_i_3_n_0\,
      O => \velocity0__0_carry__1_i_7_n_0\
    );
\velocity0__0_carry__1_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_97,
      I1 => velocity1_n_97,
      I2 => \velocity2__1_n_97\,
      I3 => \velocity0__0_carry__1_i_4_n_0\,
      O => \velocity0__0_carry__1_i_8_n_0\
    );
\velocity0__0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__0_carry__1_n_0\,
      CO(3) => \velocity0__0_carry__2_n_0\,
      CO(2) => \velocity0__0_carry__2_n_1\,
      CO(1) => \velocity0__0_carry__2_n_2\,
      CO(0) => \velocity0__0_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \velocity0__0_carry__2_i_1_n_0\,
      DI(2) => \velocity0__0_carry__2_i_2_n_0\,
      DI(1) => \velocity0__0_carry__2_i_3_n_0\,
      DI(0) => \velocity0__0_carry__2_i_4_n_0\,
      O(3 downto 0) => p_1_in(15 downto 12),
      S(3) => \velocity0__0_carry__2_i_5_n_0\,
      S(2) => \velocity0__0_carry__2_i_6_n_0\,
      S(1) => \velocity0__0_carry__2_i_7_n_0\,
      S(0) => \velocity0__0_carry__2_i_8_n_0\
    );
\velocity0__0_carry__2_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_91,
      I1 => velocity1_n_91,
      I2 => \velocity2__1_n_91\,
      O => \velocity0__0_carry__2_i_1_n_0\
    );
\velocity0__0_carry__2_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_92,
      I1 => velocity1_n_92,
      I2 => \velocity2__1_n_92\,
      O => \velocity0__0_carry__2_i_2_n_0\
    );
\velocity0__0_carry__2_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_93,
      I1 => velocity1_n_93,
      I2 => \velocity2__1_n_93\,
      O => \velocity0__0_carry__2_i_3_n_0\
    );
\velocity0__0_carry__2_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_94,
      I1 => velocity1_n_94,
      I2 => \velocity2__1_n_94\,
      O => \velocity0__0_carry__2_i_4_n_0\
    );
\velocity0__0_carry__2_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_90,
      I1 => velocity1_n_90,
      I2 => \velocity2__1_n_90\,
      I3 => \velocity0__0_carry__2_i_1_n_0\,
      O => \velocity0__0_carry__2_i_5_n_0\
    );
\velocity0__0_carry__2_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_91,
      I1 => velocity1_n_91,
      I2 => \velocity2__1_n_91\,
      I3 => \velocity0__0_carry__2_i_2_n_0\,
      O => \velocity0__0_carry__2_i_6_n_0\
    );
\velocity0__0_carry__2_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_92,
      I1 => velocity1_n_92,
      I2 => \velocity2__1_n_92\,
      I3 => \velocity0__0_carry__2_i_3_n_0\,
      O => \velocity0__0_carry__2_i_7_n_0\
    );
\velocity0__0_carry__2_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_93,
      I1 => velocity1_n_93,
      I2 => \velocity2__1_n_93\,
      I3 => \velocity0__0_carry__2_i_4_n_0\,
      O => \velocity0__0_carry__2_i_8_n_0\
    );
\velocity0__0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__0_carry__2_n_0\,
      CO(3) => \velocity0__0_carry__3_n_0\,
      CO(2) => \velocity0__0_carry__3_n_1\,
      CO(1) => \velocity0__0_carry__3_n_2\,
      CO(0) => \velocity0__0_carry__3_n_3\,
      CYINIT => '0',
      DI(3) => \velocity0__0_carry__3_i_1_n_0\,
      DI(2) => \velocity0__0_carry__3_i_2_n_0\,
      DI(1) => \velocity0__0_carry__3_i_3_n_0\,
      DI(0) => \velocity0__0_carry__3_i_4_n_0\,
      O(3 downto 0) => p_1_in(19 downto 16),
      S(3) => \velocity0__0_carry__3_i_5_n_0\,
      S(2) => \velocity0__0_carry__3_i_6_n_0\,
      S(1) => \velocity0__0_carry__3_i_7_n_0\,
      S(0) => \velocity0__0_carry__3_i_8_n_0\
    );
\velocity0__0_carry__3_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_104\,
      I1 => \velocity1__0_n_104\,
      I2 => \velocity2__2_n_104\,
      O => \velocity0__0_carry__3_i_1_n_0\
    );
\velocity0__0_carry__3_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_105\,
      I1 => \velocity1__0_n_105\,
      I2 => \velocity2__2_n_105\,
      O => \velocity0__0_carry__3_i_2_n_0\
    );
\velocity0__0_carry__3_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_89,
      I1 => velocity1_n_89,
      I2 => \velocity2__1_n_89\,
      O => \velocity0__0_carry__3_i_3_n_0\
    );
\velocity0__0_carry__3_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_90,
      I1 => velocity1_n_90,
      I2 => \velocity2__1_n_90\,
      O => \velocity0__0_carry__3_i_4_n_0\
    );
\velocity0__0_carry__3_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_103\,
      I1 => \velocity1__0_n_103\,
      I2 => \velocity2__2_n_103\,
      I3 => \velocity0__0_carry__3_i_1_n_0\,
      O => \velocity0__0_carry__3_i_5_n_0\
    );
\velocity0__0_carry__3_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_104\,
      I1 => \velocity1__0_n_104\,
      I2 => \velocity2__2_n_104\,
      I3 => \velocity0__0_carry__3_i_2_n_0\,
      O => \velocity0__0_carry__3_i_6_n_0\
    );
\velocity0__0_carry__3_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_105\,
      I1 => \velocity1__0_n_105\,
      I2 => \velocity2__2_n_105\,
      I3 => \velocity0__0_carry__3_i_3_n_0\,
      O => \velocity0__0_carry__3_i_7_n_0\
    );
\velocity0__0_carry__3_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_89,
      I1 => velocity1_n_89,
      I2 => \velocity2__1_n_89\,
      I3 => \velocity0__0_carry__3_i_4_n_0\,
      O => \velocity0__0_carry__3_i_8_n_0\
    );
\velocity0__0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__0_carry__3_n_0\,
      CO(3) => \velocity0__0_carry__4_n_0\,
      CO(2) => \velocity0__0_carry__4_n_1\,
      CO(1) => \velocity0__0_carry__4_n_2\,
      CO(0) => \velocity0__0_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \velocity0__0_carry__4_i_1_n_0\,
      DI(2) => \velocity0__0_carry__4_i_2_n_0\,
      DI(1) => \velocity0__0_carry__4_i_3_n_0\,
      DI(0) => \velocity0__0_carry__4_i_4_n_0\,
      O(3 downto 0) => p_1_in(23 downto 20),
      S(3) => \velocity0__0_carry__4_i_5_n_0\,
      S(2) => \velocity0__0_carry__4_i_6_n_0\,
      S(1) => \velocity0__0_carry__4_i_7_n_0\,
      S(0) => \velocity0__0_carry__4_i_8_n_0\
    );
\velocity0__0_carry__4_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_100\,
      I1 => \velocity1__0_n_100\,
      I2 => \velocity2__2_n_100\,
      O => \velocity0__0_carry__4_i_1_n_0\
    );
\velocity0__0_carry__4_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_101\,
      I1 => \velocity1__0_n_101\,
      I2 => \velocity2__2_n_101\,
      O => \velocity0__0_carry__4_i_2_n_0\
    );
\velocity0__0_carry__4_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_102\,
      I1 => \velocity1__0_n_102\,
      I2 => \velocity2__2_n_102\,
      O => \velocity0__0_carry__4_i_3_n_0\
    );
\velocity0__0_carry__4_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_103\,
      I1 => \velocity1__0_n_103\,
      I2 => \velocity2__2_n_103\,
      O => \velocity0__0_carry__4_i_4_n_0\
    );
\velocity0__0_carry__4_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_99\,
      I1 => \velocity1__0_n_99\,
      I2 => \velocity2__2_n_99\,
      I3 => \velocity0__0_carry__4_i_1_n_0\,
      O => \velocity0__0_carry__4_i_5_n_0\
    );
\velocity0__0_carry__4_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_100\,
      I1 => \velocity1__0_n_100\,
      I2 => \velocity2__2_n_100\,
      I3 => \velocity0__0_carry__4_i_2_n_0\,
      O => \velocity0__0_carry__4_i_6_n_0\
    );
\velocity0__0_carry__4_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_101\,
      I1 => \velocity1__0_n_101\,
      I2 => \velocity2__2_n_101\,
      I3 => \velocity0__0_carry__4_i_3_n_0\,
      O => \velocity0__0_carry__4_i_7_n_0\
    );
\velocity0__0_carry__4_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_102\,
      I1 => \velocity1__0_n_102\,
      I2 => \velocity2__2_n_102\,
      I3 => \velocity0__0_carry__4_i_4_n_0\,
      O => \velocity0__0_carry__4_i_8_n_0\
    );
\velocity0__0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__0_carry__4_n_0\,
      CO(3) => \velocity0__0_carry__5_n_0\,
      CO(2) => \velocity0__0_carry__5_n_1\,
      CO(1) => \velocity0__0_carry__5_n_2\,
      CO(0) => \velocity0__0_carry__5_n_3\,
      CYINIT => '0',
      DI(3) => \velocity0__0_carry__5_i_1_n_0\,
      DI(2) => \velocity0__0_carry__5_i_2_n_0\,
      DI(1) => \velocity0__0_carry__5_i_3_n_0\,
      DI(0) => \velocity0__0_carry__5_i_4_n_0\,
      O(3 downto 0) => p_1_in(27 downto 24),
      S(3) => \velocity0__0_carry__5_i_5_n_0\,
      S(2) => \velocity0__0_carry__5_i_6_n_0\,
      S(1) => \velocity0__0_carry__5_i_7_n_0\,
      S(0) => \velocity0__0_carry__5_i_8_n_0\
    );
\velocity0__0_carry__5_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_96\,
      I1 => \velocity1__0_n_96\,
      I2 => \velocity2__2_n_96\,
      O => \velocity0__0_carry__5_i_1_n_0\
    );
\velocity0__0_carry__5_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_97\,
      I1 => \velocity1__0_n_97\,
      I2 => \velocity2__2_n_97\,
      O => \velocity0__0_carry__5_i_2_n_0\
    );
\velocity0__0_carry__5_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_98\,
      I1 => \velocity1__0_n_98\,
      I2 => \velocity2__2_n_98\,
      O => \velocity0__0_carry__5_i_3_n_0\
    );
\velocity0__0_carry__5_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_99\,
      I1 => \velocity1__0_n_99\,
      I2 => \velocity2__2_n_99\,
      O => \velocity0__0_carry__5_i_4_n_0\
    );
\velocity0__0_carry__5_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_95\,
      I1 => \velocity1__0_n_95\,
      I2 => \velocity2__2_n_95\,
      I3 => \velocity0__0_carry__5_i_1_n_0\,
      O => \velocity0__0_carry__5_i_5_n_0\
    );
\velocity0__0_carry__5_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_96\,
      I1 => \velocity1__0_n_96\,
      I2 => \velocity2__2_n_96\,
      I3 => \velocity0__0_carry__5_i_2_n_0\,
      O => \velocity0__0_carry__5_i_6_n_0\
    );
\velocity0__0_carry__5_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_97\,
      I1 => \velocity1__0_n_97\,
      I2 => \velocity2__2_n_97\,
      I3 => \velocity0__0_carry__5_i_3_n_0\,
      O => \velocity0__0_carry__5_i_7_n_0\
    );
\velocity0__0_carry__5_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_98\,
      I1 => \velocity1__0_n_98\,
      I2 => \velocity2__2_n_98\,
      I3 => \velocity0__0_carry__5_i_4_n_0\,
      O => \velocity0__0_carry__5_i_8_n_0\
    );
\velocity0__0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__0_carry__5_n_0\,
      CO(3) => \NLW_velocity0__0_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \velocity0__0_carry__6_n_1\,
      CO(1) => \velocity0__0_carry__6_n_2\,
      CO(0) => \velocity0__0_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \velocity0__0_carry__6_i_1_n_0\,
      DI(1) => \velocity0__0_carry__6_i_2_n_0\,
      DI(0) => \velocity0__0_carry__6_i_3_n_0\,
      O(3 downto 0) => p_1_in(31 downto 28),
      S(3) => \velocity0__0_carry__6_i_4_n_0\,
      S(2) => \velocity0__0_carry__6_i_5_n_0\,
      S(1) => \velocity0__0_carry__6_i_6_n_0\,
      S(0) => \velocity0__0_carry__6_i_7_n_0\
    );
\velocity0__0_carry__6_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_93\,
      I1 => \velocity1__0_n_93\,
      I2 => \velocity2__2_n_93\,
      O => \velocity0__0_carry__6_i_1_n_0\
    );
\velocity0__0_carry__6_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_94\,
      I1 => \velocity1__0_n_94\,
      I2 => \velocity2__2_n_94\,
      O => \velocity0__0_carry__6_i_2_n_0\
    );
\velocity0__0_carry__6_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => \velocity2__0_n_95\,
      I1 => \velocity1__0_n_95\,
      I2 => \velocity2__2_n_95\,
      O => \velocity0__0_carry__6_i_3_n_0\
    );
\velocity0__0_carry__6_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17E8E817E81717E8"
    )
        port map (
      I0 => \velocity2__2_n_92\,
      I1 => \velocity1__0_n_92\,
      I2 => \velocity2__0_n_92\,
      I3 => \velocity1__0_n_91\,
      I4 => \velocity2__0_n_91\,
      I5 => \velocity2__2_n_91\,
      O => \velocity0__0_carry__6_i_4_n_0\
    );
\velocity0__0_carry__6_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity0__0_carry__6_i_1_n_0\,
      I1 => \velocity1__0_n_92\,
      I2 => \velocity2__0_n_92\,
      I3 => \velocity2__2_n_92\,
      O => \velocity0__0_carry__6_i_5_n_0\
    );
\velocity0__0_carry__6_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_93\,
      I1 => \velocity1__0_n_93\,
      I2 => \velocity2__2_n_93\,
      I3 => \velocity0__0_carry__6_i_2_n_0\,
      O => \velocity0__0_carry__6_i_6_n_0\
    );
\velocity0__0_carry__6_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \velocity2__0_n_94\,
      I1 => \velocity1__0_n_94\,
      I2 => \velocity2__2_n_94\,
      I3 => \velocity0__0_carry__6_i_3_n_0\,
      O => \velocity0__0_carry__6_i_7_n_0\
    );
\velocity0__0_carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_103,
      I1 => velocity1_n_103,
      I2 => \velocity2__1_n_103\,
      O => \velocity0__0_carry_i_1_n_0\
    );
\velocity0__0_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_104,
      I1 => velocity1_n_104,
      I2 => \velocity2__1_n_104\,
      O => \velocity0__0_carry_i_2_n_0\
    );
\velocity0__0_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => velocity2_n_105,
      I1 => velocity1_n_105,
      I2 => \velocity2__1_n_105\,
      O => \velocity0__0_carry_i_3_n_0\
    );
\velocity0__0_carry_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_102,
      I1 => velocity1_n_102,
      I2 => \velocity2__1_n_102\,
      I3 => \velocity0__0_carry_i_1_n_0\,
      O => \velocity0__0_carry_i_4_n_0\
    );
\velocity0__0_carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_103,
      I1 => velocity1_n_103,
      I2 => \velocity2__1_n_103\,
      I3 => \velocity0__0_carry_i_2_n_0\,
      O => \velocity0__0_carry_i_5_n_0\
    );
\velocity0__0_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity2_n_104,
      I1 => velocity1_n_104,
      I2 => \velocity2__1_n_104\,
      I3 => \velocity0__0_carry_i_3_n_0\,
      O => \velocity0__0_carry_i_6_n_0\
    );
\velocity0__0_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => velocity2_n_105,
      I1 => velocity1_n_105,
      I2 => \velocity2__1_n_105\,
      O => \velocity0__0_carry_i_7_n_0\
    );
\velocity0__93_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \velocity0__93_carry_n_0\,
      CO(2) => \velocity0__93_carry_n_1\,
      CO(1) => \velocity0__93_carry_n_2\,
      CO(0) => \velocity0__93_carry_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3 downto 0) => \NLW_velocity0__93_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity0__93_carry_i_1_n_0\,
      S(2) => \velocity0__93_carry_i_2_n_0\,
      S(1) => \velocity0__93_carry_i_3_n_0\,
      S(0) => \velocity0__93_carry_i_4_n_0\
    );
\velocity0__93_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__93_carry_n_0\,
      CO(3) => \velocity0__93_carry__0_n_0\,
      CO(2) => \velocity0__93_carry__0_n_1\,
      CO(1) => \velocity0__93_carry__0_n_2\,
      CO(0) => \velocity0__93_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"1111",
      O(3 downto 0) => \NLW_velocity0__93_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \velocity0__93_carry__0_i_1_n_0\,
      S(2) => \velocity0__93_carry__0_i_2_n_0\,
      S(1) => \velocity0__93_carry__0_i_3_n_0\,
      S(0) => \velocity0__93_carry__0_i_4_n_0\
    );
\velocity0__93_carry__0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(21),
      I1 => p_1_in(21),
      I2 => p_1_in(23),
      I3 => \^output_velocity\(23),
      I4 => p_1_in(22),
      I5 => \^output_velocity\(22),
      O => \velocity0__93_carry__0_i_1_n_0\
    );
\velocity0__93_carry__0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(18),
      I1 => p_1_in(18),
      I2 => p_1_in(20),
      I3 => \^output_velocity\(20),
      I4 => p_1_in(19),
      I5 => \^output_velocity\(19),
      O => \velocity0__93_carry__0_i_2_n_0\
    );
\velocity0__93_carry__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(15),
      I1 => p_1_in(15),
      I2 => p_1_in(17),
      I3 => \^output_velocity\(17),
      I4 => p_1_in(16),
      I5 => \^output_velocity\(16),
      O => \velocity0__93_carry__0_i_3_n_0\
    );
\velocity0__93_carry__0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(12),
      I1 => p_1_in(12),
      I2 => p_1_in(14),
      I3 => \^output_velocity\(14),
      I4 => p_1_in(13),
      I5 => \^output_velocity\(13),
      O => \velocity0__93_carry__0_i_4_n_0\
    );
\velocity0__93_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \velocity0__93_carry__0_n_0\,
      CO(3) => \NLW_velocity0__93_carry__1_CO_UNCONNECTED\(3),
      CO(2) => p_0_in,
      CO(1) => \velocity0__93_carry__1_n_2\,
      CO(0) => \velocity0__93_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0111",
      O(3 downto 0) => \NLW_velocity0__93_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \velocity0__93_carry__1_i_1_n_0\,
      S(1) => \velocity0__93_carry__1_i_2_n_0\,
      S(0) => \velocity0__93_carry__1_i_3_n_0\
    );
\velocity0__93_carry__1_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \^output_velocity\(30),
      I1 => p_1_in(30),
      I2 => \^output_velocity\(31),
      I3 => p_1_in(31),
      O => \velocity0__93_carry__1_i_1_n_0\
    );
\velocity0__93_carry__1_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(27),
      I1 => p_1_in(27),
      I2 => p_1_in(29),
      I3 => \^output_velocity\(29),
      I4 => p_1_in(28),
      I5 => \^output_velocity\(28),
      O => \velocity0__93_carry__1_i_2_n_0\
    );
\velocity0__93_carry__1_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(24),
      I1 => p_1_in(24),
      I2 => p_1_in(26),
      I3 => \^output_velocity\(26),
      I4 => p_1_in(25),
      I5 => \^output_velocity\(25),
      O => \velocity0__93_carry__1_i_3_n_0\
    );
\velocity0__93_carry_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(9),
      I1 => p_1_in(9),
      I2 => p_1_in(11),
      I3 => \^output_velocity\(11),
      I4 => p_1_in(10),
      I5 => \^output_velocity\(10),
      O => \velocity0__93_carry_i_1_n_0\
    );
\velocity0__93_carry_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(6),
      I1 => p_1_in(6),
      I2 => p_1_in(8),
      I3 => \^output_velocity\(8),
      I4 => p_1_in(7),
      I5 => \^output_velocity\(7),
      O => \velocity0__93_carry_i_2_n_0\
    );
\velocity0__93_carry_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(3),
      I1 => p_1_in(3),
      I2 => p_1_in(5),
      I3 => \^output_velocity\(5),
      I4 => p_1_in(4),
      I5 => \^output_velocity\(4),
      O => \velocity0__93_carry_i_3_n_0\
    );
\velocity0__93_carry_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9009000000009009"
    )
        port map (
      I0 => \^output_velocity\(0),
      I1 => p_1_in(0),
      I2 => p_1_in(2),
      I3 => \^output_velocity\(2),
      I4 => p_1_in(1),
      I5 => \^output_velocity\(1),
      O => \velocity0__93_carry_i_4_n_0\
    );
velocity1: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => derivative(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_velocity1_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 12) => B"000000",
      B(11 downto 0) => k_d(11 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17) => velocity1_n_6,
      BCOUT(16) => velocity1_n_7,
      BCOUT(15) => velocity1_n_8,
      BCOUT(14) => velocity1_n_9,
      BCOUT(13) => velocity1_n_10,
      BCOUT(12) => velocity1_n_11,
      BCOUT(11) => velocity1_n_12,
      BCOUT(10) => velocity1_n_13,
      BCOUT(9) => velocity1_n_14,
      BCOUT(8) => velocity1_n_15,
      BCOUT(7) => velocity1_n_16,
      BCOUT(6) => velocity1_n_17,
      BCOUT(5) => velocity1_n_18,
      BCOUT(4) => velocity1_n_19,
      BCOUT(3) => velocity1_n_20,
      BCOUT(2) => velocity1_n_21,
      BCOUT(1) => velocity1_n_22,
      BCOUT(0) => velocity1_n_23,
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_velocity1_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_velocity1_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_velocity1_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_velocity1_OVERFLOW_UNCONNECTED,
      P(47) => velocity1_n_58,
      P(46) => velocity1_n_59,
      P(45) => velocity1_n_60,
      P(44) => velocity1_n_61,
      P(43) => velocity1_n_62,
      P(42) => velocity1_n_63,
      P(41) => velocity1_n_64,
      P(40) => velocity1_n_65,
      P(39) => velocity1_n_66,
      P(38) => velocity1_n_67,
      P(37) => velocity1_n_68,
      P(36) => velocity1_n_69,
      P(35) => velocity1_n_70,
      P(34) => velocity1_n_71,
      P(33) => velocity1_n_72,
      P(32) => velocity1_n_73,
      P(31) => velocity1_n_74,
      P(30) => velocity1_n_75,
      P(29) => velocity1_n_76,
      P(28) => velocity1_n_77,
      P(27) => velocity1_n_78,
      P(26) => velocity1_n_79,
      P(25) => velocity1_n_80,
      P(24) => velocity1_n_81,
      P(23) => velocity1_n_82,
      P(22) => velocity1_n_83,
      P(21) => velocity1_n_84,
      P(20) => velocity1_n_85,
      P(19) => velocity1_n_86,
      P(18) => velocity1_n_87,
      P(17) => velocity1_n_88,
      P(16) => velocity1_n_89,
      P(15) => velocity1_n_90,
      P(14) => velocity1_n_91,
      P(13) => velocity1_n_92,
      P(12) => velocity1_n_93,
      P(11) => velocity1_n_94,
      P(10) => velocity1_n_95,
      P(9) => velocity1_n_96,
      P(8) => velocity1_n_97,
      P(7) => velocity1_n_98,
      P(6) => velocity1_n_99,
      P(5) => velocity1_n_100,
      P(4) => velocity1_n_101,
      P(3) => velocity1_n_102,
      P(2) => velocity1_n_103,
      P(1) => velocity1_n_104,
      P(0) => velocity1_n_105,
      PATTERNBDETECT => NLW_velocity1_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_velocity1_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => velocity1_n_106,
      PCOUT(46) => velocity1_n_107,
      PCOUT(45) => velocity1_n_108,
      PCOUT(44) => velocity1_n_109,
      PCOUT(43) => velocity1_n_110,
      PCOUT(42) => velocity1_n_111,
      PCOUT(41) => velocity1_n_112,
      PCOUT(40) => velocity1_n_113,
      PCOUT(39) => velocity1_n_114,
      PCOUT(38) => velocity1_n_115,
      PCOUT(37) => velocity1_n_116,
      PCOUT(36) => velocity1_n_117,
      PCOUT(35) => velocity1_n_118,
      PCOUT(34) => velocity1_n_119,
      PCOUT(33) => velocity1_n_120,
      PCOUT(32) => velocity1_n_121,
      PCOUT(31) => velocity1_n_122,
      PCOUT(30) => velocity1_n_123,
      PCOUT(29) => velocity1_n_124,
      PCOUT(28) => velocity1_n_125,
      PCOUT(27) => velocity1_n_126,
      PCOUT(26) => velocity1_n_127,
      PCOUT(25) => velocity1_n_128,
      PCOUT(24) => velocity1_n_129,
      PCOUT(23) => velocity1_n_130,
      PCOUT(22) => velocity1_n_131,
      PCOUT(21) => velocity1_n_132,
      PCOUT(20) => velocity1_n_133,
      PCOUT(19) => velocity1_n_134,
      PCOUT(18) => velocity1_n_135,
      PCOUT(17) => velocity1_n_136,
      PCOUT(16) => velocity1_n_137,
      PCOUT(15) => velocity1_n_138,
      PCOUT(14) => velocity1_n_139,
      PCOUT(13) => velocity1_n_140,
      PCOUT(12) => velocity1_n_141,
      PCOUT(11) => velocity1_n_142,
      PCOUT(10) => velocity1_n_143,
      PCOUT(9) => velocity1_n_144,
      PCOUT(8) => velocity1_n_145,
      PCOUT(7) => velocity1_n_146,
      PCOUT(6) => velocity1_n_147,
      PCOUT(5) => velocity1_n_148,
      PCOUT(4) => velocity1_n_149,
      PCOUT(3) => velocity1_n_150,
      PCOUT(2) => velocity1_n_151,
      PCOUT(1) => velocity1_n_152,
      PCOUT(0) => velocity1_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_velocity1_UNDERFLOW_UNCONNECTED
    );
\velocity1__0\: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "CASCADE",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 15) => B"000000000000000",
      A(14 downto 0) => derivative(31 downto 17),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => \NLW_velocity1__0_ACOUT_UNCONNECTED\(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 0) => B"000000000000000000",
      BCIN(17) => velocity1_n_6,
      BCIN(16) => velocity1_n_7,
      BCIN(15) => velocity1_n_8,
      BCIN(14) => velocity1_n_9,
      BCIN(13) => velocity1_n_10,
      BCIN(12) => velocity1_n_11,
      BCIN(11) => velocity1_n_12,
      BCIN(10) => velocity1_n_13,
      BCIN(9) => velocity1_n_14,
      BCIN(8) => velocity1_n_15,
      BCIN(7) => velocity1_n_16,
      BCIN(6) => velocity1_n_17,
      BCIN(5) => velocity1_n_18,
      BCIN(4) => velocity1_n_19,
      BCIN(3) => velocity1_n_20,
      BCIN(2) => velocity1_n_21,
      BCIN(1) => velocity1_n_22,
      BCIN(0) => velocity1_n_23,
      BCOUT(17 downto 0) => \NLW_velocity1__0_BCOUT_UNCONNECTED\(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => \NLW_velocity1__0_CARRYCASCOUT_UNCONNECTED\,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => \NLW_velocity1__0_CARRYOUT_UNCONNECTED\(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => \NLW_velocity1__0_MULTSIGNOUT_UNCONNECTED\,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => \NLW_velocity1__0_OVERFLOW_UNCONNECTED\,
      P(47) => \velocity1__0_n_58\,
      P(46) => \velocity1__0_n_59\,
      P(45) => \velocity1__0_n_60\,
      P(44) => \velocity1__0_n_61\,
      P(43) => \velocity1__0_n_62\,
      P(42) => \velocity1__0_n_63\,
      P(41) => \velocity1__0_n_64\,
      P(40) => \velocity1__0_n_65\,
      P(39) => \velocity1__0_n_66\,
      P(38) => \velocity1__0_n_67\,
      P(37) => \velocity1__0_n_68\,
      P(36) => \velocity1__0_n_69\,
      P(35) => \velocity1__0_n_70\,
      P(34) => \velocity1__0_n_71\,
      P(33) => \velocity1__0_n_72\,
      P(32) => \velocity1__0_n_73\,
      P(31) => \velocity1__0_n_74\,
      P(30) => \velocity1__0_n_75\,
      P(29) => \velocity1__0_n_76\,
      P(28) => \velocity1__0_n_77\,
      P(27) => \velocity1__0_n_78\,
      P(26) => \velocity1__0_n_79\,
      P(25) => \velocity1__0_n_80\,
      P(24) => \velocity1__0_n_81\,
      P(23) => \velocity1__0_n_82\,
      P(22) => \velocity1__0_n_83\,
      P(21) => \velocity1__0_n_84\,
      P(20) => \velocity1__0_n_85\,
      P(19) => \velocity1__0_n_86\,
      P(18) => \velocity1__0_n_87\,
      P(17) => \velocity1__0_n_88\,
      P(16) => \velocity1__0_n_89\,
      P(15) => \velocity1__0_n_90\,
      P(14) => \velocity1__0_n_91\,
      P(13) => \velocity1__0_n_92\,
      P(12) => \velocity1__0_n_93\,
      P(11) => \velocity1__0_n_94\,
      P(10) => \velocity1__0_n_95\,
      P(9) => \velocity1__0_n_96\,
      P(8) => \velocity1__0_n_97\,
      P(7) => \velocity1__0_n_98\,
      P(6) => \velocity1__0_n_99\,
      P(5) => \velocity1__0_n_100\,
      P(4) => \velocity1__0_n_101\,
      P(3) => \velocity1__0_n_102\,
      P(2) => \velocity1__0_n_103\,
      P(1) => \velocity1__0_n_104\,
      P(0) => \velocity1__0_n_105\,
      PATTERNBDETECT => \NLW_velocity1__0_PATTERNBDETECT_UNCONNECTED\,
      PATTERNDETECT => \NLW_velocity1__0_PATTERNDETECT_UNCONNECTED\,
      PCIN(47) => velocity1_n_106,
      PCIN(46) => velocity1_n_107,
      PCIN(45) => velocity1_n_108,
      PCIN(44) => velocity1_n_109,
      PCIN(43) => velocity1_n_110,
      PCIN(42) => velocity1_n_111,
      PCIN(41) => velocity1_n_112,
      PCIN(40) => velocity1_n_113,
      PCIN(39) => velocity1_n_114,
      PCIN(38) => velocity1_n_115,
      PCIN(37) => velocity1_n_116,
      PCIN(36) => velocity1_n_117,
      PCIN(35) => velocity1_n_118,
      PCIN(34) => velocity1_n_119,
      PCIN(33) => velocity1_n_120,
      PCIN(32) => velocity1_n_121,
      PCIN(31) => velocity1_n_122,
      PCIN(30) => velocity1_n_123,
      PCIN(29) => velocity1_n_124,
      PCIN(28) => velocity1_n_125,
      PCIN(27) => velocity1_n_126,
      PCIN(26) => velocity1_n_127,
      PCIN(25) => velocity1_n_128,
      PCIN(24) => velocity1_n_129,
      PCIN(23) => velocity1_n_130,
      PCIN(22) => velocity1_n_131,
      PCIN(21) => velocity1_n_132,
      PCIN(20) => velocity1_n_133,
      PCIN(19) => velocity1_n_134,
      PCIN(18) => velocity1_n_135,
      PCIN(17) => velocity1_n_136,
      PCIN(16) => velocity1_n_137,
      PCIN(15) => velocity1_n_138,
      PCIN(14) => velocity1_n_139,
      PCIN(13) => velocity1_n_140,
      PCIN(12) => velocity1_n_141,
      PCIN(11) => velocity1_n_142,
      PCIN(10) => velocity1_n_143,
      PCIN(9) => velocity1_n_144,
      PCIN(8) => velocity1_n_145,
      PCIN(7) => velocity1_n_146,
      PCIN(6) => velocity1_n_147,
      PCIN(5) => velocity1_n_148,
      PCIN(4) => velocity1_n_149,
      PCIN(3) => velocity1_n_150,
      PCIN(2) => velocity1_n_151,
      PCIN(1) => velocity1_n_152,
      PCIN(0) => velocity1_n_153,
      PCOUT(47 downto 0) => \NLW_velocity1__0_PCOUT_UNCONNECTED\(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => \NLW_velocity1__0_UNDERFLOW_UNCONNECTED\
    );
velocity2: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => integral(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_velocity2_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 12) => B"000000",
      B(11 downto 0) => k_i(11 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17) => velocity2_n_6,
      BCOUT(16) => velocity2_n_7,
      BCOUT(15) => velocity2_n_8,
      BCOUT(14) => velocity2_n_9,
      BCOUT(13) => velocity2_n_10,
      BCOUT(12) => velocity2_n_11,
      BCOUT(11) => velocity2_n_12,
      BCOUT(10) => velocity2_n_13,
      BCOUT(9) => velocity2_n_14,
      BCOUT(8) => velocity2_n_15,
      BCOUT(7) => velocity2_n_16,
      BCOUT(6) => velocity2_n_17,
      BCOUT(5) => velocity2_n_18,
      BCOUT(4) => velocity2_n_19,
      BCOUT(3) => velocity2_n_20,
      BCOUT(2) => velocity2_n_21,
      BCOUT(1) => velocity2_n_22,
      BCOUT(0) => velocity2_n_23,
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_velocity2_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_velocity2_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_velocity2_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_velocity2_OVERFLOW_UNCONNECTED,
      P(47) => velocity2_n_58,
      P(46) => velocity2_n_59,
      P(45) => velocity2_n_60,
      P(44) => velocity2_n_61,
      P(43) => velocity2_n_62,
      P(42) => velocity2_n_63,
      P(41) => velocity2_n_64,
      P(40) => velocity2_n_65,
      P(39) => velocity2_n_66,
      P(38) => velocity2_n_67,
      P(37) => velocity2_n_68,
      P(36) => velocity2_n_69,
      P(35) => velocity2_n_70,
      P(34) => velocity2_n_71,
      P(33) => velocity2_n_72,
      P(32) => velocity2_n_73,
      P(31) => velocity2_n_74,
      P(30) => velocity2_n_75,
      P(29) => velocity2_n_76,
      P(28) => velocity2_n_77,
      P(27) => velocity2_n_78,
      P(26) => velocity2_n_79,
      P(25) => velocity2_n_80,
      P(24) => velocity2_n_81,
      P(23) => velocity2_n_82,
      P(22) => velocity2_n_83,
      P(21) => velocity2_n_84,
      P(20) => velocity2_n_85,
      P(19) => velocity2_n_86,
      P(18) => velocity2_n_87,
      P(17) => velocity2_n_88,
      P(16) => velocity2_n_89,
      P(15) => velocity2_n_90,
      P(14) => velocity2_n_91,
      P(13) => velocity2_n_92,
      P(12) => velocity2_n_93,
      P(11) => velocity2_n_94,
      P(10) => velocity2_n_95,
      P(9) => velocity2_n_96,
      P(8) => velocity2_n_97,
      P(7) => velocity2_n_98,
      P(6) => velocity2_n_99,
      P(5) => velocity2_n_100,
      P(4) => velocity2_n_101,
      P(3) => velocity2_n_102,
      P(2) => velocity2_n_103,
      P(1) => velocity2_n_104,
      P(0) => velocity2_n_105,
      PATTERNBDETECT => NLW_velocity2_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_velocity2_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => velocity2_n_106,
      PCOUT(46) => velocity2_n_107,
      PCOUT(45) => velocity2_n_108,
      PCOUT(44) => velocity2_n_109,
      PCOUT(43) => velocity2_n_110,
      PCOUT(42) => velocity2_n_111,
      PCOUT(41) => velocity2_n_112,
      PCOUT(40) => velocity2_n_113,
      PCOUT(39) => velocity2_n_114,
      PCOUT(38) => velocity2_n_115,
      PCOUT(37) => velocity2_n_116,
      PCOUT(36) => velocity2_n_117,
      PCOUT(35) => velocity2_n_118,
      PCOUT(34) => velocity2_n_119,
      PCOUT(33) => velocity2_n_120,
      PCOUT(32) => velocity2_n_121,
      PCOUT(31) => velocity2_n_122,
      PCOUT(30) => velocity2_n_123,
      PCOUT(29) => velocity2_n_124,
      PCOUT(28) => velocity2_n_125,
      PCOUT(27) => velocity2_n_126,
      PCOUT(26) => velocity2_n_127,
      PCOUT(25) => velocity2_n_128,
      PCOUT(24) => velocity2_n_129,
      PCOUT(23) => velocity2_n_130,
      PCOUT(22) => velocity2_n_131,
      PCOUT(21) => velocity2_n_132,
      PCOUT(20) => velocity2_n_133,
      PCOUT(19) => velocity2_n_134,
      PCOUT(18) => velocity2_n_135,
      PCOUT(17) => velocity2_n_136,
      PCOUT(16) => velocity2_n_137,
      PCOUT(15) => velocity2_n_138,
      PCOUT(14) => velocity2_n_139,
      PCOUT(13) => velocity2_n_140,
      PCOUT(12) => velocity2_n_141,
      PCOUT(11) => velocity2_n_142,
      PCOUT(10) => velocity2_n_143,
      PCOUT(9) => velocity2_n_144,
      PCOUT(8) => velocity2_n_145,
      PCOUT(7) => velocity2_n_146,
      PCOUT(6) => velocity2_n_147,
      PCOUT(5) => velocity2_n_148,
      PCOUT(4) => velocity2_n_149,
      PCOUT(3) => velocity2_n_150,
      PCOUT(2) => velocity2_n_151,
      PCOUT(1) => velocity2_n_152,
      PCOUT(0) => velocity2_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_velocity2_UNDERFLOW_UNCONNECTED
    );
\velocity2__0\: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "CASCADE",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 15) => B"000000000000000",
      A(14 downto 0) => integral(31 downto 17),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => \NLW_velocity2__0_ACOUT_UNCONNECTED\(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 0) => B"000000000000000000",
      BCIN(17) => velocity2_n_6,
      BCIN(16) => velocity2_n_7,
      BCIN(15) => velocity2_n_8,
      BCIN(14) => velocity2_n_9,
      BCIN(13) => velocity2_n_10,
      BCIN(12) => velocity2_n_11,
      BCIN(11) => velocity2_n_12,
      BCIN(10) => velocity2_n_13,
      BCIN(9) => velocity2_n_14,
      BCIN(8) => velocity2_n_15,
      BCIN(7) => velocity2_n_16,
      BCIN(6) => velocity2_n_17,
      BCIN(5) => velocity2_n_18,
      BCIN(4) => velocity2_n_19,
      BCIN(3) => velocity2_n_20,
      BCIN(2) => velocity2_n_21,
      BCIN(1) => velocity2_n_22,
      BCIN(0) => velocity2_n_23,
      BCOUT(17 downto 0) => \NLW_velocity2__0_BCOUT_UNCONNECTED\(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => \NLW_velocity2__0_CARRYCASCOUT_UNCONNECTED\,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => \NLW_velocity2__0_CARRYOUT_UNCONNECTED\(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => \NLW_velocity2__0_MULTSIGNOUT_UNCONNECTED\,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => \NLW_velocity2__0_OVERFLOW_UNCONNECTED\,
      P(47) => \velocity2__0_n_58\,
      P(46) => \velocity2__0_n_59\,
      P(45) => \velocity2__0_n_60\,
      P(44) => \velocity2__0_n_61\,
      P(43) => \velocity2__0_n_62\,
      P(42) => \velocity2__0_n_63\,
      P(41) => \velocity2__0_n_64\,
      P(40) => \velocity2__0_n_65\,
      P(39) => \velocity2__0_n_66\,
      P(38) => \velocity2__0_n_67\,
      P(37) => \velocity2__0_n_68\,
      P(36) => \velocity2__0_n_69\,
      P(35) => \velocity2__0_n_70\,
      P(34) => \velocity2__0_n_71\,
      P(33) => \velocity2__0_n_72\,
      P(32) => \velocity2__0_n_73\,
      P(31) => \velocity2__0_n_74\,
      P(30) => \velocity2__0_n_75\,
      P(29) => \velocity2__0_n_76\,
      P(28) => \velocity2__0_n_77\,
      P(27) => \velocity2__0_n_78\,
      P(26) => \velocity2__0_n_79\,
      P(25) => \velocity2__0_n_80\,
      P(24) => \velocity2__0_n_81\,
      P(23) => \velocity2__0_n_82\,
      P(22) => \velocity2__0_n_83\,
      P(21) => \velocity2__0_n_84\,
      P(20) => \velocity2__0_n_85\,
      P(19) => \velocity2__0_n_86\,
      P(18) => \velocity2__0_n_87\,
      P(17) => \velocity2__0_n_88\,
      P(16) => \velocity2__0_n_89\,
      P(15) => \velocity2__0_n_90\,
      P(14) => \velocity2__0_n_91\,
      P(13) => \velocity2__0_n_92\,
      P(12) => \velocity2__0_n_93\,
      P(11) => \velocity2__0_n_94\,
      P(10) => \velocity2__0_n_95\,
      P(9) => \velocity2__0_n_96\,
      P(8) => \velocity2__0_n_97\,
      P(7) => \velocity2__0_n_98\,
      P(6) => \velocity2__0_n_99\,
      P(5) => \velocity2__0_n_100\,
      P(4) => \velocity2__0_n_101\,
      P(3) => \velocity2__0_n_102\,
      P(2) => \velocity2__0_n_103\,
      P(1) => \velocity2__0_n_104\,
      P(0) => \velocity2__0_n_105\,
      PATTERNBDETECT => \NLW_velocity2__0_PATTERNBDETECT_UNCONNECTED\,
      PATTERNDETECT => \NLW_velocity2__0_PATTERNDETECT_UNCONNECTED\,
      PCIN(47) => velocity2_n_106,
      PCIN(46) => velocity2_n_107,
      PCIN(45) => velocity2_n_108,
      PCIN(44) => velocity2_n_109,
      PCIN(43) => velocity2_n_110,
      PCIN(42) => velocity2_n_111,
      PCIN(41) => velocity2_n_112,
      PCIN(40) => velocity2_n_113,
      PCIN(39) => velocity2_n_114,
      PCIN(38) => velocity2_n_115,
      PCIN(37) => velocity2_n_116,
      PCIN(36) => velocity2_n_117,
      PCIN(35) => velocity2_n_118,
      PCIN(34) => velocity2_n_119,
      PCIN(33) => velocity2_n_120,
      PCIN(32) => velocity2_n_121,
      PCIN(31) => velocity2_n_122,
      PCIN(30) => velocity2_n_123,
      PCIN(29) => velocity2_n_124,
      PCIN(28) => velocity2_n_125,
      PCIN(27) => velocity2_n_126,
      PCIN(26) => velocity2_n_127,
      PCIN(25) => velocity2_n_128,
      PCIN(24) => velocity2_n_129,
      PCIN(23) => velocity2_n_130,
      PCIN(22) => velocity2_n_131,
      PCIN(21) => velocity2_n_132,
      PCIN(20) => velocity2_n_133,
      PCIN(19) => velocity2_n_134,
      PCIN(18) => velocity2_n_135,
      PCIN(17) => velocity2_n_136,
      PCIN(16) => velocity2_n_137,
      PCIN(15) => velocity2_n_138,
      PCIN(14) => velocity2_n_139,
      PCIN(13) => velocity2_n_140,
      PCIN(12) => velocity2_n_141,
      PCIN(11) => velocity2_n_142,
      PCIN(10) => velocity2_n_143,
      PCIN(9) => velocity2_n_144,
      PCIN(8) => velocity2_n_145,
      PCIN(7) => velocity2_n_146,
      PCIN(6) => velocity2_n_147,
      PCIN(5) => velocity2_n_148,
      PCIN(4) => velocity2_n_149,
      PCIN(3) => velocity2_n_150,
      PCIN(2) => velocity2_n_151,
      PCIN(1) => velocity2_n_152,
      PCIN(0) => velocity2_n_153,
      PCOUT(47 downto 0) => \NLW_velocity2__0_PCOUT_UNCONNECTED\(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => \NLW_velocity2__0_UNDERFLOW_UNCONNECTED\
    );
\velocity2__1\: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => error(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => \NLW_velocity2__1_ACOUT_UNCONNECTED\(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 12) => B"000000",
      B(11 downto 0) => k_p(11 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17) => \velocity2__1_n_6\,
      BCOUT(16) => \velocity2__1_n_7\,
      BCOUT(15) => \velocity2__1_n_8\,
      BCOUT(14) => \velocity2__1_n_9\,
      BCOUT(13) => \velocity2__1_n_10\,
      BCOUT(12) => \velocity2__1_n_11\,
      BCOUT(11) => \velocity2__1_n_12\,
      BCOUT(10) => \velocity2__1_n_13\,
      BCOUT(9) => \velocity2__1_n_14\,
      BCOUT(8) => \velocity2__1_n_15\,
      BCOUT(7) => \velocity2__1_n_16\,
      BCOUT(6) => \velocity2__1_n_17\,
      BCOUT(5) => \velocity2__1_n_18\,
      BCOUT(4) => \velocity2__1_n_19\,
      BCOUT(3) => \velocity2__1_n_20\,
      BCOUT(2) => \velocity2__1_n_21\,
      BCOUT(1) => \velocity2__1_n_22\,
      BCOUT(0) => \velocity2__1_n_23\,
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => \NLW_velocity2__1_CARRYCASCOUT_UNCONNECTED\,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => \NLW_velocity2__1_CARRYOUT_UNCONNECTED\(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => \NLW_velocity2__1_MULTSIGNOUT_UNCONNECTED\,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => \NLW_velocity2__1_OVERFLOW_UNCONNECTED\,
      P(47) => \velocity2__1_n_58\,
      P(46) => \velocity2__1_n_59\,
      P(45) => \velocity2__1_n_60\,
      P(44) => \velocity2__1_n_61\,
      P(43) => \velocity2__1_n_62\,
      P(42) => \velocity2__1_n_63\,
      P(41) => \velocity2__1_n_64\,
      P(40) => \velocity2__1_n_65\,
      P(39) => \velocity2__1_n_66\,
      P(38) => \velocity2__1_n_67\,
      P(37) => \velocity2__1_n_68\,
      P(36) => \velocity2__1_n_69\,
      P(35) => \velocity2__1_n_70\,
      P(34) => \velocity2__1_n_71\,
      P(33) => \velocity2__1_n_72\,
      P(32) => \velocity2__1_n_73\,
      P(31) => \velocity2__1_n_74\,
      P(30) => \velocity2__1_n_75\,
      P(29) => \velocity2__1_n_76\,
      P(28) => \velocity2__1_n_77\,
      P(27) => \velocity2__1_n_78\,
      P(26) => \velocity2__1_n_79\,
      P(25) => \velocity2__1_n_80\,
      P(24) => \velocity2__1_n_81\,
      P(23) => \velocity2__1_n_82\,
      P(22) => \velocity2__1_n_83\,
      P(21) => \velocity2__1_n_84\,
      P(20) => \velocity2__1_n_85\,
      P(19) => \velocity2__1_n_86\,
      P(18) => \velocity2__1_n_87\,
      P(17) => \velocity2__1_n_88\,
      P(16) => \velocity2__1_n_89\,
      P(15) => \velocity2__1_n_90\,
      P(14) => \velocity2__1_n_91\,
      P(13) => \velocity2__1_n_92\,
      P(12) => \velocity2__1_n_93\,
      P(11) => \velocity2__1_n_94\,
      P(10) => \velocity2__1_n_95\,
      P(9) => \velocity2__1_n_96\,
      P(8) => \velocity2__1_n_97\,
      P(7) => \velocity2__1_n_98\,
      P(6) => \velocity2__1_n_99\,
      P(5) => \velocity2__1_n_100\,
      P(4) => \velocity2__1_n_101\,
      P(3) => \velocity2__1_n_102\,
      P(2) => \velocity2__1_n_103\,
      P(1) => \velocity2__1_n_104\,
      P(0) => \velocity2__1_n_105\,
      PATTERNBDETECT => \NLW_velocity2__1_PATTERNBDETECT_UNCONNECTED\,
      PATTERNDETECT => \NLW_velocity2__1_PATTERNDETECT_UNCONNECTED\,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => \velocity2__1_n_106\,
      PCOUT(46) => \velocity2__1_n_107\,
      PCOUT(45) => \velocity2__1_n_108\,
      PCOUT(44) => \velocity2__1_n_109\,
      PCOUT(43) => \velocity2__1_n_110\,
      PCOUT(42) => \velocity2__1_n_111\,
      PCOUT(41) => \velocity2__1_n_112\,
      PCOUT(40) => \velocity2__1_n_113\,
      PCOUT(39) => \velocity2__1_n_114\,
      PCOUT(38) => \velocity2__1_n_115\,
      PCOUT(37) => \velocity2__1_n_116\,
      PCOUT(36) => \velocity2__1_n_117\,
      PCOUT(35) => \velocity2__1_n_118\,
      PCOUT(34) => \velocity2__1_n_119\,
      PCOUT(33) => \velocity2__1_n_120\,
      PCOUT(32) => \velocity2__1_n_121\,
      PCOUT(31) => \velocity2__1_n_122\,
      PCOUT(30) => \velocity2__1_n_123\,
      PCOUT(29) => \velocity2__1_n_124\,
      PCOUT(28) => \velocity2__1_n_125\,
      PCOUT(27) => \velocity2__1_n_126\,
      PCOUT(26) => \velocity2__1_n_127\,
      PCOUT(25) => \velocity2__1_n_128\,
      PCOUT(24) => \velocity2__1_n_129\,
      PCOUT(23) => \velocity2__1_n_130\,
      PCOUT(22) => \velocity2__1_n_131\,
      PCOUT(21) => \velocity2__1_n_132\,
      PCOUT(20) => \velocity2__1_n_133\,
      PCOUT(19) => \velocity2__1_n_134\,
      PCOUT(18) => \velocity2__1_n_135\,
      PCOUT(17) => \velocity2__1_n_136\,
      PCOUT(16) => \velocity2__1_n_137\,
      PCOUT(15) => \velocity2__1_n_138\,
      PCOUT(14) => \velocity2__1_n_139\,
      PCOUT(13) => \velocity2__1_n_140\,
      PCOUT(12) => \velocity2__1_n_141\,
      PCOUT(11) => \velocity2__1_n_142\,
      PCOUT(10) => \velocity2__1_n_143\,
      PCOUT(9) => \velocity2__1_n_144\,
      PCOUT(8) => \velocity2__1_n_145\,
      PCOUT(7) => \velocity2__1_n_146\,
      PCOUT(6) => \velocity2__1_n_147\,
      PCOUT(5) => \velocity2__1_n_148\,
      PCOUT(4) => \velocity2__1_n_149\,
      PCOUT(3) => \velocity2__1_n_150\,
      PCOUT(2) => \velocity2__1_n_151\,
      PCOUT(1) => \velocity2__1_n_152\,
      PCOUT(0) => \velocity2__1_n_153\,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => \NLW_velocity2__1_UNDERFLOW_UNCONNECTED\
    );
\velocity2__2\: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "CASCADE",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 15) => B"000000000000000",
      A(14 downto 0) => error(31 downto 17),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => \NLW_velocity2__2_ACOUT_UNCONNECTED\(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 0) => B"000000000000000000",
      BCIN(17) => \velocity2__1_n_6\,
      BCIN(16) => \velocity2__1_n_7\,
      BCIN(15) => \velocity2__1_n_8\,
      BCIN(14) => \velocity2__1_n_9\,
      BCIN(13) => \velocity2__1_n_10\,
      BCIN(12) => \velocity2__1_n_11\,
      BCIN(11) => \velocity2__1_n_12\,
      BCIN(10) => \velocity2__1_n_13\,
      BCIN(9) => \velocity2__1_n_14\,
      BCIN(8) => \velocity2__1_n_15\,
      BCIN(7) => \velocity2__1_n_16\,
      BCIN(6) => \velocity2__1_n_17\,
      BCIN(5) => \velocity2__1_n_18\,
      BCIN(4) => \velocity2__1_n_19\,
      BCIN(3) => \velocity2__1_n_20\,
      BCIN(2) => \velocity2__1_n_21\,
      BCIN(1) => \velocity2__1_n_22\,
      BCIN(0) => \velocity2__1_n_23\,
      BCOUT(17 downto 0) => \NLW_velocity2__2_BCOUT_UNCONNECTED\(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => \NLW_velocity2__2_CARRYCASCOUT_UNCONNECTED\,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => \NLW_velocity2__2_CARRYOUT_UNCONNECTED\(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => \NLW_velocity2__2_MULTSIGNOUT_UNCONNECTED\,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => \NLW_velocity2__2_OVERFLOW_UNCONNECTED\,
      P(47) => \velocity2__2_n_58\,
      P(46) => \velocity2__2_n_59\,
      P(45) => \velocity2__2_n_60\,
      P(44) => \velocity2__2_n_61\,
      P(43) => \velocity2__2_n_62\,
      P(42) => \velocity2__2_n_63\,
      P(41) => \velocity2__2_n_64\,
      P(40) => \velocity2__2_n_65\,
      P(39) => \velocity2__2_n_66\,
      P(38) => \velocity2__2_n_67\,
      P(37) => \velocity2__2_n_68\,
      P(36) => \velocity2__2_n_69\,
      P(35) => \velocity2__2_n_70\,
      P(34) => \velocity2__2_n_71\,
      P(33) => \velocity2__2_n_72\,
      P(32) => \velocity2__2_n_73\,
      P(31) => \velocity2__2_n_74\,
      P(30) => \velocity2__2_n_75\,
      P(29) => \velocity2__2_n_76\,
      P(28) => \velocity2__2_n_77\,
      P(27) => \velocity2__2_n_78\,
      P(26) => \velocity2__2_n_79\,
      P(25) => \velocity2__2_n_80\,
      P(24) => \velocity2__2_n_81\,
      P(23) => \velocity2__2_n_82\,
      P(22) => \velocity2__2_n_83\,
      P(21) => \velocity2__2_n_84\,
      P(20) => \velocity2__2_n_85\,
      P(19) => \velocity2__2_n_86\,
      P(18) => \velocity2__2_n_87\,
      P(17) => \velocity2__2_n_88\,
      P(16) => \velocity2__2_n_89\,
      P(15) => \velocity2__2_n_90\,
      P(14) => \velocity2__2_n_91\,
      P(13) => \velocity2__2_n_92\,
      P(12) => \velocity2__2_n_93\,
      P(11) => \velocity2__2_n_94\,
      P(10) => \velocity2__2_n_95\,
      P(9) => \velocity2__2_n_96\,
      P(8) => \velocity2__2_n_97\,
      P(7) => \velocity2__2_n_98\,
      P(6) => \velocity2__2_n_99\,
      P(5) => \velocity2__2_n_100\,
      P(4) => \velocity2__2_n_101\,
      P(3) => \velocity2__2_n_102\,
      P(2) => \velocity2__2_n_103\,
      P(1) => \velocity2__2_n_104\,
      P(0) => \velocity2__2_n_105\,
      PATTERNBDETECT => \NLW_velocity2__2_PATTERNBDETECT_UNCONNECTED\,
      PATTERNDETECT => \NLW_velocity2__2_PATTERNDETECT_UNCONNECTED\,
      PCIN(47) => \velocity2__1_n_106\,
      PCIN(46) => \velocity2__1_n_107\,
      PCIN(45) => \velocity2__1_n_108\,
      PCIN(44) => \velocity2__1_n_109\,
      PCIN(43) => \velocity2__1_n_110\,
      PCIN(42) => \velocity2__1_n_111\,
      PCIN(41) => \velocity2__1_n_112\,
      PCIN(40) => \velocity2__1_n_113\,
      PCIN(39) => \velocity2__1_n_114\,
      PCIN(38) => \velocity2__1_n_115\,
      PCIN(37) => \velocity2__1_n_116\,
      PCIN(36) => \velocity2__1_n_117\,
      PCIN(35) => \velocity2__1_n_118\,
      PCIN(34) => \velocity2__1_n_119\,
      PCIN(33) => \velocity2__1_n_120\,
      PCIN(32) => \velocity2__1_n_121\,
      PCIN(31) => \velocity2__1_n_122\,
      PCIN(30) => \velocity2__1_n_123\,
      PCIN(29) => \velocity2__1_n_124\,
      PCIN(28) => \velocity2__1_n_125\,
      PCIN(27) => \velocity2__1_n_126\,
      PCIN(26) => \velocity2__1_n_127\,
      PCIN(25) => \velocity2__1_n_128\,
      PCIN(24) => \velocity2__1_n_129\,
      PCIN(23) => \velocity2__1_n_130\,
      PCIN(22) => \velocity2__1_n_131\,
      PCIN(21) => \velocity2__1_n_132\,
      PCIN(20) => \velocity2__1_n_133\,
      PCIN(19) => \velocity2__1_n_134\,
      PCIN(18) => \velocity2__1_n_135\,
      PCIN(17) => \velocity2__1_n_136\,
      PCIN(16) => \velocity2__1_n_137\,
      PCIN(15) => \velocity2__1_n_138\,
      PCIN(14) => \velocity2__1_n_139\,
      PCIN(13) => \velocity2__1_n_140\,
      PCIN(12) => \velocity2__1_n_141\,
      PCIN(11) => \velocity2__1_n_142\,
      PCIN(10) => \velocity2__1_n_143\,
      PCIN(9) => \velocity2__1_n_144\,
      PCIN(8) => \velocity2__1_n_145\,
      PCIN(7) => \velocity2__1_n_146\,
      PCIN(6) => \velocity2__1_n_147\,
      PCIN(5) => \velocity2__1_n_148\,
      PCIN(4) => \velocity2__1_n_149\,
      PCIN(3) => \velocity2__1_n_150\,
      PCIN(2) => \velocity2__1_n_151\,
      PCIN(1) => \velocity2__1_n_152\,
      PCIN(0) => \velocity2__1_n_153\,
      PCOUT(47 downto 0) => \NLW_velocity2__2_PCOUT_UNCONNECTED\(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => \NLW_velocity2__2_UNDERFLOW_UNCONNECTED\
    );
\velocity_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(0),
      Q => \^output_velocity\(0),
      R => '0'
    );
\velocity_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(10),
      Q => \^output_velocity\(10),
      R => '0'
    );
\velocity_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(11),
      Q => \^output_velocity\(11),
      R => '0'
    );
\velocity_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(12),
      Q => \^output_velocity\(12),
      R => '0'
    );
\velocity_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(13),
      Q => \^output_velocity\(13),
      R => '0'
    );
\velocity_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(14),
      Q => \^output_velocity\(14),
      R => '0'
    );
\velocity_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(15),
      Q => \^output_velocity\(15),
      R => '0'
    );
\velocity_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(16),
      Q => \^output_velocity\(16),
      R => '0'
    );
\velocity_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(17),
      Q => \^output_velocity\(17),
      R => '0'
    );
\velocity_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(18),
      Q => \^output_velocity\(18),
      R => '0'
    );
\velocity_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(19),
      Q => \^output_velocity\(19),
      R => '0'
    );
\velocity_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(1),
      Q => \^output_velocity\(1),
      R => '0'
    );
\velocity_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(20),
      Q => \^output_velocity\(20),
      R => '0'
    );
\velocity_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(21),
      Q => \^output_velocity\(21),
      R => '0'
    );
\velocity_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(22),
      Q => \^output_velocity\(22),
      R => '0'
    );
\velocity_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(23),
      Q => \^output_velocity\(23),
      R => '0'
    );
\velocity_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(24),
      Q => \^output_velocity\(24),
      R => '0'
    );
\velocity_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(25),
      Q => \^output_velocity\(25),
      R => '0'
    );
\velocity_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(26),
      Q => \^output_velocity\(26),
      R => '0'
    );
\velocity_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(27),
      Q => \^output_velocity\(27),
      R => '0'
    );
\velocity_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(28),
      Q => \^output_velocity\(28),
      R => '0'
    );
\velocity_reg[29]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(29),
      Q => \^output_velocity\(29),
      R => '0'
    );
\velocity_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(2),
      Q => \^output_velocity\(2),
      R => '0'
    );
\velocity_reg[30]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(30),
      Q => \^output_velocity\(30),
      R => '0'
    );
\velocity_reg[31]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(31),
      Q => \^output_velocity\(31),
      R => '0'
    );
\velocity_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(3),
      Q => \^output_velocity\(3),
      R => '0'
    );
\velocity_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(4),
      Q => \^output_velocity\(4),
      R => '0'
    );
\velocity_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(5),
      Q => \^output_velocity\(5),
      R => '0'
    );
\velocity_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(6),
      Q => \^output_velocity\(6),
      R => '0'
    );
\velocity_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(7),
      Q => \^output_velocity\(7),
      R => '0'
    );
\velocity_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(8),
      Q => \^output_velocity\(8),
      R => '0'
    );
\velocity_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clock(0),
      CE => p_0_in,
      D => p_1_in(9),
      Q => \^output_velocity\(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_term_calculation_0_0 is
  port (
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    error : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral : in STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative : in STD_LOGIC_VECTOR ( 31 downto 0 );
    k_p : in STD_LOGIC_VECTOR ( 11 downto 0 );
    k_i : in STD_LOGIC_VECTOR ( 11 downto 0 );
    k_d : in STD_LOGIC_VECTOR ( 11 downto 0 );
    output_velocity : out STD_LOGIC_VECTOR ( 31 downto 0 );
    new_velocity_available : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_term_calculation_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_term_calculation_0_0 : entity is "design_1_term_calculation_0_0,term_calculation,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_term_calculation_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of design_1_term_calculation_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_1_term_calculation_0_0 : entity is "term_calculation,Vivado 2021.1";
end design_1_term_calculation_0_0;

architecture STRUCTURE of design_1_term_calculation_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
begin
inst: entity work.design_1_term_calculation_0_0_term_calculation
     port map (
      clock(0) => clock(0),
      derivative(31 downto 0) => derivative(31 downto 0),
      error(31 downto 0) => error(31 downto 0),
      integral(31 downto 0) => integral(31 downto 0),
      k_d(11 downto 0) => k_d(11 downto 0),
      k_i(11 downto 0) => k_i(11 downto 0),
      k_p(11 downto 0) => k_p(11 downto 0),
      new_velocity_available(0) => new_velocity_available(0),
      output_velocity(31 downto 0) => output_velocity(31 downto 0)
    );
end STRUCTURE;
