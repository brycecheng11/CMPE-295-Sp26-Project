// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep 21 21:48:48 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top design_1_k_math_0_0 -prefix
//               design_1_k_math_0_0_ design_1_k_math_0_0_stub.v
// Design      : design_1_k_math_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "k_math,Vivado 2021.1" *)
module design_1_k_math_0_0(clock, kp_in, ki_in, kd_in, kp_out, ki_out, kd_out)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],kp_in[11:0],ki_in[11:0],kd_in[11:0],kp_out[8:0],ki_out[8:0],kd_out[8:0]" */;
  input [0:0]clock;
  input [11:0]kp_in;
  input [11:0]ki_in;
  input [11:0]kd_in;
  output [8:0]kp_out;
  output [8:0]ki_out;
  output [8:0]kd_out;
endmodule
