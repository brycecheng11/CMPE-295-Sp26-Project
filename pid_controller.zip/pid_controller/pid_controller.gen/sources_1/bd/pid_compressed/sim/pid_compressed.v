//Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
//Date        : Tue Sep 29 13:41:13 2026
//Host        : Dell-XPS running 64-bit major release  (build 9200)
//Command     : generate_target pid_compressed.bd
//Design      : pid_compressed
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "pid_compressed,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=pid_compressed,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=2,numReposBlks=2,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=2,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "pid_compressed.hwdef" *) 
module pid_compressed
   (angle_0,
    kd_in_0,
    ki_in_0,
    kp_in_0,
    new_target_angle_available_0,
    output_velocity_0,
    sys_clk,
    target_angle_0);
  input [31:0]angle_0;
  input [11:0]kd_in_0;
  input [11:0]ki_in_0;
  input [11:0]kp_in_0;
  input [0:0]new_target_angle_available_0;
  output [31:0]output_velocity_0;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.SYS_CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.SYS_CLK, CLK_DOMAIN pid_compressed_clock_0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input [0:0]sys_clk;
  input [31:0]target_angle_0;

  wire [31:0]angle_0_1;
  wire [0:0]clock_0_1;
  wire [8:0]k_math_0_kd_out;
  wire [8:0]k_math_0_ki_out;
  wire [8:0]k_math_0_kp_out;
  wire [11:0]kd_in_0_1;
  wire [11:0]ki_in_0_1;
  wire [11:0]kp_in_0_1;
  wire [0:0]new_target_angle_available_0_1;
  wire [31:0]pid_calc_0_output_velocity;
  wire [31:0]target_angle_0_1;

  assign angle_0_1 = angle_0[31:0];
  assign clock_0_1 = sys_clk[0];
  assign kd_in_0_1 = kd_in_0[11:0];
  assign ki_in_0_1 = ki_in_0[11:0];
  assign kp_in_0_1 = kp_in_0[11:0];
  assign new_target_angle_available_0_1 = new_target_angle_available_0[0];
  assign output_velocity_0[31:0] = pid_calc_0_output_velocity;
  assign target_angle_0_1 = target_angle_0[31:0];
  pid_compressed_k_math_0_0 k_math_0
       (.clock(clock_0_1),
        .kd_in(kd_in_0_1),
        .kd_out(k_math_0_kd_out),
        .ki_in(ki_in_0_1),
        .ki_out(k_math_0_ki_out),
        .kp_in(kp_in_0_1),
        .kp_out(k_math_0_kp_out));
  pid_compressed_pid_calc_0_0 pid_calc_0
       (.angle(angle_0_1),
        .clock(clock_0_1),
        .kd(k_math_0_kd_out),
        .ki(k_math_0_ki_out),
        .kp(k_math_0_kp_out),
        .new_target_angle_available(new_target_angle_available_0_1),
        .output_velocity(pid_calc_0_output_velocity),
        .target_angle(target_angle_0_1));
endmodule
