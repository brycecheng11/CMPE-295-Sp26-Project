-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Tue Sep 29 13:37:35 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Xilinx/Projects/pid_controller/pid_controller.gen/sources_1/bd/pid_compressed/ip/pid_compressed_k_math_0_0/pid_compressed_k_math_0_0_sim_netlist.vhdl
-- Design      : pid_compressed_k_math_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity pid_compressed_k_math_0_0_k_math is
  port (
    kp_out : out STD_LOGIC_VECTOR ( 7 downto 0 );
    ki_out : out STD_LOGIC_VECTOR ( 7 downto 0 );
    kd_out : out STD_LOGIC_VECTOR ( 7 downto 0 );
    kp_in : in STD_LOGIC_VECTOR ( 7 downto 0 );
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    ki_in : in STD_LOGIC_VECTOR ( 7 downto 0 );
    kd_in : in STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of pid_compressed_k_math_0_0_k_math : entity is "k_math";
end pid_compressed_k_math_0_0_k_math;

architecture STRUCTURE of pid_compressed_k_math_0_0_k_math is
begin
\kd_signed_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(0),
      Q => kd_out(0),
      R => '0'
    );
\kd_signed_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(1),
      Q => kd_out(1),
      R => '0'
    );
\kd_signed_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(2),
      Q => kd_out(2),
      R => '0'
    );
\kd_signed_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(3),
      Q => kd_out(3),
      R => '0'
    );
\kd_signed_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(4),
      Q => kd_out(4),
      R => '0'
    );
\kd_signed_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(5),
      Q => kd_out(5),
      R => '0'
    );
\kd_signed_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(6),
      Q => kd_out(6),
      R => '0'
    );
\kd_signed_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kd_in(7),
      Q => kd_out(7),
      R => '0'
    );
\ki_signed_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(0),
      Q => ki_out(0),
      R => '0'
    );
\ki_signed_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(1),
      Q => ki_out(1),
      R => '0'
    );
\ki_signed_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(2),
      Q => ki_out(2),
      R => '0'
    );
\ki_signed_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(3),
      Q => ki_out(3),
      R => '0'
    );
\ki_signed_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(4),
      Q => ki_out(4),
      R => '0'
    );
\ki_signed_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(5),
      Q => ki_out(5),
      R => '0'
    );
\ki_signed_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(6),
      Q => ki_out(6),
      R => '0'
    );
\ki_signed_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => ki_in(7),
      Q => ki_out(7),
      R => '0'
    );
\kp_signed_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(0),
      Q => kp_out(0),
      R => '0'
    );
\kp_signed_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(1),
      Q => kp_out(1),
      R => '0'
    );
\kp_signed_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(2),
      Q => kp_out(2),
      R => '0'
    );
\kp_signed_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(3),
      Q => kp_out(3),
      R => '0'
    );
\kp_signed_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(4),
      Q => kp_out(4),
      R => '0'
    );
\kp_signed_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(5),
      Q => kp_out(5),
      R => '0'
    );
\kp_signed_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(6),
      Q => kp_out(6),
      R => '0'
    );
\kp_signed_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => kp_in(7),
      Q => kp_out(7),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity pid_compressed_k_math_0_0 is
  port (
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    kp_in : in STD_LOGIC_VECTOR ( 11 downto 0 );
    ki_in : in STD_LOGIC_VECTOR ( 11 downto 0 );
    kd_in : in STD_LOGIC_VECTOR ( 11 downto 0 );
    kp_out : out STD_LOGIC_VECTOR ( 8 downto 0 );
    ki_out : out STD_LOGIC_VECTOR ( 8 downto 0 );
    kd_out : out STD_LOGIC_VECTOR ( 8 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of pid_compressed_k_math_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of pid_compressed_k_math_0_0 : entity is "pid_compressed_k_math_0_0,k_math,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of pid_compressed_k_math_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of pid_compressed_k_math_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of pid_compressed_k_math_0_0 : entity is "k_math,Vivado 2021.1";
end pid_compressed_k_math_0_0;

architecture STRUCTURE of pid_compressed_k_math_0_0 is
  signal \<const0>\ : STD_LOGIC;
  signal \^kd_out\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \^ki_out\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \^kp_out\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_compressed_clock_0, INSERT_VIP 0";
begin
  kd_out(8) <= \<const0>\;
  kd_out(7 downto 0) <= \^kd_out\(7 downto 0);
  ki_out(8) <= \<const0>\;
  ki_out(7 downto 0) <= \^ki_out\(7 downto 0);
  kp_out(8) <= \<const0>\;
  kp_out(7 downto 0) <= \^kp_out\(7 downto 0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.pid_compressed_k_math_0_0_k_math
     port map (
      clock(0) => clock(0),
      kd_in(7 downto 0) => kd_in(11 downto 4),
      kd_out(7 downto 0) => \^kd_out\(7 downto 0),
      ki_in(7 downto 0) => ki_in(11 downto 4),
      ki_out(7 downto 0) => \^ki_out\(7 downto 0),
      kp_in(7 downto 0) => kp_in(11 downto 4),
      kp_out(7 downto 0) => \^kp_out\(7 downto 0)
    );
end STRUCTURE;
