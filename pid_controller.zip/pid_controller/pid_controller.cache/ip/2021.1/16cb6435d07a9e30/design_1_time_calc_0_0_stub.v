// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Wed Sep 16 22:00:40 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_time_calc_0_0_stub.v
// Design      : design_1_time_calc_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "time_calc,Vivado 2021.1" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clock, new_angle_available, time_curr, 
  time_prev, new_angle_pass_on, dt_out, new_time_out)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],new_angle_available[0:0],time_curr[63:0],time_prev[63:0],new_angle_pass_on[0:0],dt_out[63:0],new_time_out[63:0]" */;
  input [0:0]clock;
  input [0:0]new_angle_available;
  input [63:0]time_curr;
  input [63:0]time_prev;
  output [0:0]new_angle_pass_on;
  output [63:0]dt_out;
  output [63:0]new_time_out;
endmodule
