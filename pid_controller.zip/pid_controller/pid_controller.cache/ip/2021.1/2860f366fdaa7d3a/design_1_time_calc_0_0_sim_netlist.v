// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep  7 13:31:30 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_time_calc_0_0_sim_netlist.v
// Design      : design_1_time_calc_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_time_calc_0_0,time_calc,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "time_calc,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clock,
    new_angle_available,
    time_curr,
    time_prev,
    new_angle_pass_on,
    dt_out,
    new_time_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input [0:0]clock;
  input [0:0]new_angle_available;
  input [0:0]time_curr;
  input [63:0]time_prev;
  output [0:0]new_angle_pass_on;
  output [63:0]dt_out;
  output [63:0]new_time_out;

  wire \<const0> ;
  wire [63:0]dt_out;
  wire [0:0]new_angle_available;
  wire [0:0]\^new_time_out ;
  wire [0:0]time_curr;
  wire [63:0]time_prev;

  assign new_angle_pass_on[0] = new_angle_available;
  assign new_time_out[63] = \<const0> ;
  assign new_time_out[62] = \<const0> ;
  assign new_time_out[61] = \<const0> ;
  assign new_time_out[60] = \<const0> ;
  assign new_time_out[59] = \<const0> ;
  assign new_time_out[58] = \<const0> ;
  assign new_time_out[57] = \<const0> ;
  assign new_time_out[56] = \<const0> ;
  assign new_time_out[55] = \<const0> ;
  assign new_time_out[54] = \<const0> ;
  assign new_time_out[53] = \<const0> ;
  assign new_time_out[52] = \<const0> ;
  assign new_time_out[51] = \<const0> ;
  assign new_time_out[50] = \<const0> ;
  assign new_time_out[49] = \<const0> ;
  assign new_time_out[48] = \<const0> ;
  assign new_time_out[47] = \<const0> ;
  assign new_time_out[46] = \<const0> ;
  assign new_time_out[45] = \<const0> ;
  assign new_time_out[44] = \<const0> ;
  assign new_time_out[43] = \<const0> ;
  assign new_time_out[42] = \<const0> ;
  assign new_time_out[41] = \<const0> ;
  assign new_time_out[40] = \<const0> ;
  assign new_time_out[39] = \<const0> ;
  assign new_time_out[38] = \<const0> ;
  assign new_time_out[37] = \<const0> ;
  assign new_time_out[36] = \<const0> ;
  assign new_time_out[35] = \<const0> ;
  assign new_time_out[34] = \<const0> ;
  assign new_time_out[33] = \<const0> ;
  assign new_time_out[32] = \<const0> ;
  assign new_time_out[31] = \<const0> ;
  assign new_time_out[30] = \<const0> ;
  assign new_time_out[29] = \<const0> ;
  assign new_time_out[28] = \<const0> ;
  assign new_time_out[27] = \<const0> ;
  assign new_time_out[26] = \<const0> ;
  assign new_time_out[25] = \<const0> ;
  assign new_time_out[24] = \<const0> ;
  assign new_time_out[23] = \<const0> ;
  assign new_time_out[22] = \<const0> ;
  assign new_time_out[21] = \<const0> ;
  assign new_time_out[20] = \<const0> ;
  assign new_time_out[19] = \<const0> ;
  assign new_time_out[18] = \<const0> ;
  assign new_time_out[17] = \<const0> ;
  assign new_time_out[16] = \<const0> ;
  assign new_time_out[15] = \<const0> ;
  assign new_time_out[14] = \<const0> ;
  assign new_time_out[13] = \<const0> ;
  assign new_time_out[12] = \<const0> ;
  assign new_time_out[11] = \<const0> ;
  assign new_time_out[10] = \<const0> ;
  assign new_time_out[9] = \<const0> ;
  assign new_time_out[8] = \<const0> ;
  assign new_time_out[7] = \<const0> ;
  assign new_time_out[6] = \<const0> ;
  assign new_time_out[5] = \<const0> ;
  assign new_time_out[4] = \<const0> ;
  assign new_time_out[3] = \<const0> ;
  assign new_time_out[2] = \<const0> ;
  assign new_time_out[1] = \<const0> ;
  assign new_time_out[0] = \^new_time_out [0];
  GND GND
       (.G(\<const0> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_time_calc inst
       (.dt_out(dt_out),
        .new_angle_available(new_angle_available),
        .new_time_out(\^new_time_out ),
        .time_curr(time_curr),
        .time_prev(time_prev));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_time_calc
   (dt_out,
    new_time_out,
    time_curr,
    time_prev,
    new_angle_available);
  output [63:0]dt_out;
  output [0:0]new_time_out;
  input [0:0]time_curr;
  input [63:0]time_prev;
  input [0:0]new_angle_available;

  wire [63:0]dt0;
  wire dt0_carry__0_n_0;
  wire dt0_carry__0_n_1;
  wire dt0_carry__0_n_2;
  wire dt0_carry__0_n_3;
  wire dt0_carry__10_n_0;
  wire dt0_carry__10_n_1;
  wire dt0_carry__10_n_2;
  wire dt0_carry__10_n_3;
  wire dt0_carry__11_n_0;
  wire dt0_carry__11_n_1;
  wire dt0_carry__11_n_2;
  wire dt0_carry__11_n_3;
  wire dt0_carry__12_n_0;
  wire dt0_carry__12_n_1;
  wire dt0_carry__12_n_2;
  wire dt0_carry__12_n_3;
  wire dt0_carry__13_n_0;
  wire dt0_carry__13_n_1;
  wire dt0_carry__13_n_2;
  wire dt0_carry__13_n_3;
  wire dt0_carry__14_n_1;
  wire dt0_carry__14_n_2;
  wire dt0_carry__14_n_3;
  wire dt0_carry__1_n_0;
  wire dt0_carry__1_n_1;
  wire dt0_carry__1_n_2;
  wire dt0_carry__1_n_3;
  wire dt0_carry__2_n_0;
  wire dt0_carry__2_n_1;
  wire dt0_carry__2_n_2;
  wire dt0_carry__2_n_3;
  wire dt0_carry__3_n_0;
  wire dt0_carry__3_n_1;
  wire dt0_carry__3_n_2;
  wire dt0_carry__3_n_3;
  wire dt0_carry__4_n_0;
  wire dt0_carry__4_n_1;
  wire dt0_carry__4_n_2;
  wire dt0_carry__4_n_3;
  wire dt0_carry__5_n_0;
  wire dt0_carry__5_n_1;
  wire dt0_carry__5_n_2;
  wire dt0_carry__5_n_3;
  wire dt0_carry__6_n_0;
  wire dt0_carry__6_n_1;
  wire dt0_carry__6_n_2;
  wire dt0_carry__6_n_3;
  wire dt0_carry__7_n_0;
  wire dt0_carry__7_n_1;
  wire dt0_carry__7_n_2;
  wire dt0_carry__7_n_3;
  wire dt0_carry__8_n_0;
  wire dt0_carry__8_n_1;
  wire dt0_carry__8_n_2;
  wire dt0_carry__8_n_3;
  wire dt0_carry__9_n_0;
  wire dt0_carry__9_n_1;
  wire dt0_carry__9_n_2;
  wire dt0_carry__9_n_3;
  wire dt0_carry_i_1_n_0;
  wire dt0_carry_i_4_n_0;
  wire dt0_carry_i_5_n_0;
  wire dt0_carry_n_0;
  wire dt0_carry_n_1;
  wire dt0_carry_n_2;
  wire dt0_carry_n_3;
  wire [63:0]dt_out;
  wire [0:0]new_angle_available;
  wire [0:0]new_time_out;
  wire [63:2]p_0_in;
  wire [0:0]time_curr;
  wire [63:0]time_prev;
  wire [3:3]NLW_dt0_carry__14_CO_UNCONNECTED;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry
       (.CI(1'b0),
        .CO({dt0_carry_n_0,dt0_carry_n_1,dt0_carry_n_2,dt0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,dt0_carry_i_1_n_0,1'b0}),
        .O(dt0[3:0]),
        .S({p_0_in[3:2],dt0_carry_i_4_n_0,dt0_carry_i_5_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__0
       (.CI(dt0_carry_n_0),
        .CO({dt0_carry__0_n_0,dt0_carry__0_n_1,dt0_carry__0_n_2,dt0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[7:4]),
        .S(p_0_in[7:4]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__0_i_1
       (.I0(time_prev[7]),
        .O(p_0_in[7]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__0_i_2
       (.I0(time_prev[6]),
        .O(p_0_in[6]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__0_i_3
       (.I0(time_prev[5]),
        .O(p_0_in[5]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__0_i_4
       (.I0(time_prev[4]),
        .O(p_0_in[4]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__1
       (.CI(dt0_carry__0_n_0),
        .CO({dt0_carry__1_n_0,dt0_carry__1_n_1,dt0_carry__1_n_2,dt0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[11:8]),
        .S(p_0_in[11:8]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__10
       (.CI(dt0_carry__9_n_0),
        .CO({dt0_carry__10_n_0,dt0_carry__10_n_1,dt0_carry__10_n_2,dt0_carry__10_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[47:44]),
        .S(p_0_in[47:44]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__10_i_1
       (.I0(time_prev[47]),
        .O(p_0_in[47]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__10_i_2
       (.I0(time_prev[46]),
        .O(p_0_in[46]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__10_i_3
       (.I0(time_prev[45]),
        .O(p_0_in[45]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__10_i_4
       (.I0(time_prev[44]),
        .O(p_0_in[44]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__11
       (.CI(dt0_carry__10_n_0),
        .CO({dt0_carry__11_n_0,dt0_carry__11_n_1,dt0_carry__11_n_2,dt0_carry__11_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[51:48]),
        .S(p_0_in[51:48]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__11_i_1
       (.I0(time_prev[51]),
        .O(p_0_in[51]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__11_i_2
       (.I0(time_prev[50]),
        .O(p_0_in[50]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__11_i_3
       (.I0(time_prev[49]),
        .O(p_0_in[49]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__11_i_4
       (.I0(time_prev[48]),
        .O(p_0_in[48]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__12
       (.CI(dt0_carry__11_n_0),
        .CO({dt0_carry__12_n_0,dt0_carry__12_n_1,dt0_carry__12_n_2,dt0_carry__12_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[55:52]),
        .S(p_0_in[55:52]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__12_i_1
       (.I0(time_prev[55]),
        .O(p_0_in[55]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__12_i_2
       (.I0(time_prev[54]),
        .O(p_0_in[54]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__12_i_3
       (.I0(time_prev[53]),
        .O(p_0_in[53]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__12_i_4
       (.I0(time_prev[52]),
        .O(p_0_in[52]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__13
       (.CI(dt0_carry__12_n_0),
        .CO({dt0_carry__13_n_0,dt0_carry__13_n_1,dt0_carry__13_n_2,dt0_carry__13_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[59:56]),
        .S(p_0_in[59:56]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__13_i_1
       (.I0(time_prev[59]),
        .O(p_0_in[59]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__13_i_2
       (.I0(time_prev[58]),
        .O(p_0_in[58]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__13_i_3
       (.I0(time_prev[57]),
        .O(p_0_in[57]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__13_i_4
       (.I0(time_prev[56]),
        .O(p_0_in[56]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__14
       (.CI(dt0_carry__13_n_0),
        .CO({NLW_dt0_carry__14_CO_UNCONNECTED[3],dt0_carry__14_n_1,dt0_carry__14_n_2,dt0_carry__14_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[63:60]),
        .S(p_0_in[63:60]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__14_i_1
       (.I0(time_prev[63]),
        .O(p_0_in[63]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__14_i_2
       (.I0(time_prev[62]),
        .O(p_0_in[62]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__14_i_3
       (.I0(time_prev[61]),
        .O(p_0_in[61]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__14_i_4
       (.I0(time_prev[60]),
        .O(p_0_in[60]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__1_i_1
       (.I0(time_prev[11]),
        .O(p_0_in[11]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__1_i_2
       (.I0(time_prev[10]),
        .O(p_0_in[10]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__1_i_3
       (.I0(time_prev[9]),
        .O(p_0_in[9]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__1_i_4
       (.I0(time_prev[8]),
        .O(p_0_in[8]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__2
       (.CI(dt0_carry__1_n_0),
        .CO({dt0_carry__2_n_0,dt0_carry__2_n_1,dt0_carry__2_n_2,dt0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[15:12]),
        .S(p_0_in[15:12]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__2_i_1
       (.I0(time_prev[15]),
        .O(p_0_in[15]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__2_i_2
       (.I0(time_prev[14]),
        .O(p_0_in[14]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__2_i_3
       (.I0(time_prev[13]),
        .O(p_0_in[13]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__2_i_4
       (.I0(time_prev[12]),
        .O(p_0_in[12]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__3
       (.CI(dt0_carry__2_n_0),
        .CO({dt0_carry__3_n_0,dt0_carry__3_n_1,dt0_carry__3_n_2,dt0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[19:16]),
        .S(p_0_in[19:16]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__3_i_1
       (.I0(time_prev[19]),
        .O(p_0_in[19]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__3_i_2
       (.I0(time_prev[18]),
        .O(p_0_in[18]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__3_i_3
       (.I0(time_prev[17]),
        .O(p_0_in[17]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__3_i_4
       (.I0(time_prev[16]),
        .O(p_0_in[16]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__4
       (.CI(dt0_carry__3_n_0),
        .CO({dt0_carry__4_n_0,dt0_carry__4_n_1,dt0_carry__4_n_2,dt0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[23:20]),
        .S(p_0_in[23:20]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__4_i_1
       (.I0(time_prev[23]),
        .O(p_0_in[23]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__4_i_2
       (.I0(time_prev[22]),
        .O(p_0_in[22]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__4_i_3
       (.I0(time_prev[21]),
        .O(p_0_in[21]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__4_i_4
       (.I0(time_prev[20]),
        .O(p_0_in[20]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__5
       (.CI(dt0_carry__4_n_0),
        .CO({dt0_carry__5_n_0,dt0_carry__5_n_1,dt0_carry__5_n_2,dt0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[27:24]),
        .S(p_0_in[27:24]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__5_i_1
       (.I0(time_prev[27]),
        .O(p_0_in[27]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__5_i_2
       (.I0(time_prev[26]),
        .O(p_0_in[26]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__5_i_3
       (.I0(time_prev[25]),
        .O(p_0_in[25]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__5_i_4
       (.I0(time_prev[24]),
        .O(p_0_in[24]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__6
       (.CI(dt0_carry__5_n_0),
        .CO({dt0_carry__6_n_0,dt0_carry__6_n_1,dt0_carry__6_n_2,dt0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[31:28]),
        .S(p_0_in[31:28]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__6_i_1
       (.I0(time_prev[31]),
        .O(p_0_in[31]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__6_i_2
       (.I0(time_prev[30]),
        .O(p_0_in[30]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__6_i_3
       (.I0(time_prev[29]),
        .O(p_0_in[29]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__6_i_4
       (.I0(time_prev[28]),
        .O(p_0_in[28]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__7
       (.CI(dt0_carry__6_n_0),
        .CO({dt0_carry__7_n_0,dt0_carry__7_n_1,dt0_carry__7_n_2,dt0_carry__7_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[35:32]),
        .S(p_0_in[35:32]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__7_i_1
       (.I0(time_prev[35]),
        .O(p_0_in[35]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__7_i_2
       (.I0(time_prev[34]),
        .O(p_0_in[34]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__7_i_3
       (.I0(time_prev[33]),
        .O(p_0_in[33]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__7_i_4
       (.I0(time_prev[32]),
        .O(p_0_in[32]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__8
       (.CI(dt0_carry__7_n_0),
        .CO({dt0_carry__8_n_0,dt0_carry__8_n_1,dt0_carry__8_n_2,dt0_carry__8_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[39:36]),
        .S(p_0_in[39:36]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__8_i_1
       (.I0(time_prev[39]),
        .O(p_0_in[39]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__8_i_2
       (.I0(time_prev[38]),
        .O(p_0_in[38]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__8_i_3
       (.I0(time_prev[37]),
        .O(p_0_in[37]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__8_i_4
       (.I0(time_prev[36]),
        .O(p_0_in[36]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__9
       (.CI(dt0_carry__8_n_0),
        .CO({dt0_carry__9_n_0,dt0_carry__9_n_1,dt0_carry__9_n_2,dt0_carry__9_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0[43:40]),
        .S(p_0_in[43:40]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__9_i_1
       (.I0(time_prev[43]),
        .O(p_0_in[43]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__9_i_2
       (.I0(time_prev[42]),
        .O(p_0_in[42]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__9_i_3
       (.I0(time_prev[41]),
        .O(p_0_in[41]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry__9_i_4
       (.I0(time_prev[40]),
        .O(p_0_in[40]));
  LUT2 #(
    .INIT(4'hB)) 
    dt0_carry_i_1
       (.I0(time_curr),
        .I1(time_prev[0]),
        .O(dt0_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry_i_2
       (.I0(time_prev[3]),
        .O(p_0_in[3]));
  LUT1 #(
    .INIT(2'h1)) 
    dt0_carry_i_3
       (.I0(time_prev[2]),
        .O(p_0_in[2]));
  LUT3 #(
    .INIT(8'hD2)) 
    dt0_carry_i_4
       (.I0(time_prev[0]),
        .I1(time_curr),
        .I2(time_prev[1]),
        .O(dt0_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    dt0_carry_i_5
       (.I0(time_curr),
        .I1(time_prev[0]),
        .O(dt0_carry_i_5_n_0));
  FDRE \dt_reg[0] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[0]),
        .Q(dt_out[0]),
        .R(1'b0));
  FDRE \dt_reg[10] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[10]),
        .Q(dt_out[10]),
        .R(1'b0));
  FDRE \dt_reg[11] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[11]),
        .Q(dt_out[11]),
        .R(1'b0));
  FDRE \dt_reg[12] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[12]),
        .Q(dt_out[12]),
        .R(1'b0));
  FDRE \dt_reg[13] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[13]),
        .Q(dt_out[13]),
        .R(1'b0));
  FDRE \dt_reg[14] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[14]),
        .Q(dt_out[14]),
        .R(1'b0));
  FDRE \dt_reg[15] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[15]),
        .Q(dt_out[15]),
        .R(1'b0));
  FDRE \dt_reg[16] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[16]),
        .Q(dt_out[16]),
        .R(1'b0));
  FDRE \dt_reg[17] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[17]),
        .Q(dt_out[17]),
        .R(1'b0));
  FDRE \dt_reg[18] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[18]),
        .Q(dt_out[18]),
        .R(1'b0));
  FDRE \dt_reg[19] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[19]),
        .Q(dt_out[19]),
        .R(1'b0));
  FDRE \dt_reg[1] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[1]),
        .Q(dt_out[1]),
        .R(1'b0));
  FDRE \dt_reg[20] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[20]),
        .Q(dt_out[20]),
        .R(1'b0));
  FDRE \dt_reg[21] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[21]),
        .Q(dt_out[21]),
        .R(1'b0));
  FDRE \dt_reg[22] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[22]),
        .Q(dt_out[22]),
        .R(1'b0));
  FDRE \dt_reg[23] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[23]),
        .Q(dt_out[23]),
        .R(1'b0));
  FDRE \dt_reg[24] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[24]),
        .Q(dt_out[24]),
        .R(1'b0));
  FDRE \dt_reg[25] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[25]),
        .Q(dt_out[25]),
        .R(1'b0));
  FDRE \dt_reg[26] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[26]),
        .Q(dt_out[26]),
        .R(1'b0));
  FDRE \dt_reg[27] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[27]),
        .Q(dt_out[27]),
        .R(1'b0));
  FDRE \dt_reg[28] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[28]),
        .Q(dt_out[28]),
        .R(1'b0));
  FDRE \dt_reg[29] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[29]),
        .Q(dt_out[29]),
        .R(1'b0));
  FDRE \dt_reg[2] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[2]),
        .Q(dt_out[2]),
        .R(1'b0));
  FDRE \dt_reg[30] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[30]),
        .Q(dt_out[30]),
        .R(1'b0));
  FDRE \dt_reg[31] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[31]),
        .Q(dt_out[31]),
        .R(1'b0));
  FDRE \dt_reg[32] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[32]),
        .Q(dt_out[32]),
        .R(1'b0));
  FDRE \dt_reg[33] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[33]),
        .Q(dt_out[33]),
        .R(1'b0));
  FDRE \dt_reg[34] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[34]),
        .Q(dt_out[34]),
        .R(1'b0));
  FDRE \dt_reg[35] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[35]),
        .Q(dt_out[35]),
        .R(1'b0));
  FDRE \dt_reg[36] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[36]),
        .Q(dt_out[36]),
        .R(1'b0));
  FDRE \dt_reg[37] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[37]),
        .Q(dt_out[37]),
        .R(1'b0));
  FDRE \dt_reg[38] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[38]),
        .Q(dt_out[38]),
        .R(1'b0));
  FDRE \dt_reg[39] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[39]),
        .Q(dt_out[39]),
        .R(1'b0));
  FDRE \dt_reg[3] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[3]),
        .Q(dt_out[3]),
        .R(1'b0));
  FDRE \dt_reg[40] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[40]),
        .Q(dt_out[40]),
        .R(1'b0));
  FDRE \dt_reg[41] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[41]),
        .Q(dt_out[41]),
        .R(1'b0));
  FDRE \dt_reg[42] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[42]),
        .Q(dt_out[42]),
        .R(1'b0));
  FDRE \dt_reg[43] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[43]),
        .Q(dt_out[43]),
        .R(1'b0));
  FDRE \dt_reg[44] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[44]),
        .Q(dt_out[44]),
        .R(1'b0));
  FDRE \dt_reg[45] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[45]),
        .Q(dt_out[45]),
        .R(1'b0));
  FDRE \dt_reg[46] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[46]),
        .Q(dt_out[46]),
        .R(1'b0));
  FDRE \dt_reg[47] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[47]),
        .Q(dt_out[47]),
        .R(1'b0));
  FDRE \dt_reg[48] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[48]),
        .Q(dt_out[48]),
        .R(1'b0));
  FDRE \dt_reg[49] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[49]),
        .Q(dt_out[49]),
        .R(1'b0));
  FDRE \dt_reg[4] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[4]),
        .Q(dt_out[4]),
        .R(1'b0));
  FDRE \dt_reg[50] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[50]),
        .Q(dt_out[50]),
        .R(1'b0));
  FDRE \dt_reg[51] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[51]),
        .Q(dt_out[51]),
        .R(1'b0));
  FDRE \dt_reg[52] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[52]),
        .Q(dt_out[52]),
        .R(1'b0));
  FDRE \dt_reg[53] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[53]),
        .Q(dt_out[53]),
        .R(1'b0));
  FDRE \dt_reg[54] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[54]),
        .Q(dt_out[54]),
        .R(1'b0));
  FDRE \dt_reg[55] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[55]),
        .Q(dt_out[55]),
        .R(1'b0));
  FDRE \dt_reg[56] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[56]),
        .Q(dt_out[56]),
        .R(1'b0));
  FDRE \dt_reg[57] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[57]),
        .Q(dt_out[57]),
        .R(1'b0));
  FDRE \dt_reg[58] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[58]),
        .Q(dt_out[58]),
        .R(1'b0));
  FDRE \dt_reg[59] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[59]),
        .Q(dt_out[59]),
        .R(1'b0));
  FDRE \dt_reg[5] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[5]),
        .Q(dt_out[5]),
        .R(1'b0));
  FDRE \dt_reg[60] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[60]),
        .Q(dt_out[60]),
        .R(1'b0));
  FDRE \dt_reg[61] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[61]),
        .Q(dt_out[61]),
        .R(1'b0));
  FDRE \dt_reg[62] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[62]),
        .Q(dt_out[62]),
        .R(1'b0));
  FDRE \dt_reg[63] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[63]),
        .Q(dt_out[63]),
        .R(1'b0));
  FDRE \dt_reg[6] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[6]),
        .Q(dt_out[6]),
        .R(1'b0));
  FDRE \dt_reg[7] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[7]),
        .Q(dt_out[7]),
        .R(1'b0));
  FDRE \dt_reg[8] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[8]),
        .Q(dt_out[8]),
        .R(1'b0));
  FDRE \dt_reg[9] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(dt0[9]),
        .Q(dt_out[9]),
        .R(1'b0));
  FDRE \new_time_reg[0] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(time_curr),
        .Q(new_time_out),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
