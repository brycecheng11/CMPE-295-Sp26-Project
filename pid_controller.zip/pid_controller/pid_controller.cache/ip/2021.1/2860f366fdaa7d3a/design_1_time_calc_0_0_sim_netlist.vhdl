-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Mon Sep  7 13:31:30 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_time_calc_0_0_sim_netlist.vhdl
-- Design      : design_1_time_calc_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_time_calc is
  port (
    dt_out : out STD_LOGIC_VECTOR ( 63 downto 0 );
    new_time_out : out STD_LOGIC_VECTOR ( 0 to 0 );
    time_curr : in STD_LOGIC_VECTOR ( 0 to 0 );
    time_prev : in STD_LOGIC_VECTOR ( 63 downto 0 );
    new_angle_available : in STD_LOGIC_VECTOR ( 0 to 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_time_calc;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_time_calc is
  signal dt0 : STD_LOGIC_VECTOR ( 63 downto 0 );
  signal \dt0_carry__0_n_0\ : STD_LOGIC;
  signal \dt0_carry__0_n_1\ : STD_LOGIC;
  signal \dt0_carry__0_n_2\ : STD_LOGIC;
  signal \dt0_carry__0_n_3\ : STD_LOGIC;
  signal \dt0_carry__10_n_0\ : STD_LOGIC;
  signal \dt0_carry__10_n_1\ : STD_LOGIC;
  signal \dt0_carry__10_n_2\ : STD_LOGIC;
  signal \dt0_carry__10_n_3\ : STD_LOGIC;
  signal \dt0_carry__11_n_0\ : STD_LOGIC;
  signal \dt0_carry__11_n_1\ : STD_LOGIC;
  signal \dt0_carry__11_n_2\ : STD_LOGIC;
  signal \dt0_carry__11_n_3\ : STD_LOGIC;
  signal \dt0_carry__12_n_0\ : STD_LOGIC;
  signal \dt0_carry__12_n_1\ : STD_LOGIC;
  signal \dt0_carry__12_n_2\ : STD_LOGIC;
  signal \dt0_carry__12_n_3\ : STD_LOGIC;
  signal \dt0_carry__13_n_0\ : STD_LOGIC;
  signal \dt0_carry__13_n_1\ : STD_LOGIC;
  signal \dt0_carry__13_n_2\ : STD_LOGIC;
  signal \dt0_carry__13_n_3\ : STD_LOGIC;
  signal \dt0_carry__14_n_1\ : STD_LOGIC;
  signal \dt0_carry__14_n_2\ : STD_LOGIC;
  signal \dt0_carry__14_n_3\ : STD_LOGIC;
  signal \dt0_carry__1_n_0\ : STD_LOGIC;
  signal \dt0_carry__1_n_1\ : STD_LOGIC;
  signal \dt0_carry__1_n_2\ : STD_LOGIC;
  signal \dt0_carry__1_n_3\ : STD_LOGIC;
  signal \dt0_carry__2_n_0\ : STD_LOGIC;
  signal \dt0_carry__2_n_1\ : STD_LOGIC;
  signal \dt0_carry__2_n_2\ : STD_LOGIC;
  signal \dt0_carry__2_n_3\ : STD_LOGIC;
  signal \dt0_carry__3_n_0\ : STD_LOGIC;
  signal \dt0_carry__3_n_1\ : STD_LOGIC;
  signal \dt0_carry__3_n_2\ : STD_LOGIC;
  signal \dt0_carry__3_n_3\ : STD_LOGIC;
  signal \dt0_carry__4_n_0\ : STD_LOGIC;
  signal \dt0_carry__4_n_1\ : STD_LOGIC;
  signal \dt0_carry__4_n_2\ : STD_LOGIC;
  signal \dt0_carry__4_n_3\ : STD_LOGIC;
  signal \dt0_carry__5_n_0\ : STD_LOGIC;
  signal \dt0_carry__5_n_1\ : STD_LOGIC;
  signal \dt0_carry__5_n_2\ : STD_LOGIC;
  signal \dt0_carry__5_n_3\ : STD_LOGIC;
  signal \dt0_carry__6_n_0\ : STD_LOGIC;
  signal \dt0_carry__6_n_1\ : STD_LOGIC;
  signal \dt0_carry__6_n_2\ : STD_LOGIC;
  signal \dt0_carry__6_n_3\ : STD_LOGIC;
  signal \dt0_carry__7_n_0\ : STD_LOGIC;
  signal \dt0_carry__7_n_1\ : STD_LOGIC;
  signal \dt0_carry__7_n_2\ : STD_LOGIC;
  signal \dt0_carry__7_n_3\ : STD_LOGIC;
  signal \dt0_carry__8_n_0\ : STD_LOGIC;
  signal \dt0_carry__8_n_1\ : STD_LOGIC;
  signal \dt0_carry__8_n_2\ : STD_LOGIC;
  signal \dt0_carry__8_n_3\ : STD_LOGIC;
  signal \dt0_carry__9_n_0\ : STD_LOGIC;
  signal \dt0_carry__9_n_1\ : STD_LOGIC;
  signal \dt0_carry__9_n_2\ : STD_LOGIC;
  signal \dt0_carry__9_n_3\ : STD_LOGIC;
  signal dt0_carry_i_1_n_0 : STD_LOGIC;
  signal dt0_carry_i_4_n_0 : STD_LOGIC;
  signal dt0_carry_i_5_n_0 : STD_LOGIC;
  signal dt0_carry_n_0 : STD_LOGIC;
  signal dt0_carry_n_1 : STD_LOGIC;
  signal dt0_carry_n_2 : STD_LOGIC;
  signal dt0_carry_n_3 : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 63 downto 2 );
  signal \NLW_dt0_carry__14_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of dt0_carry : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__10\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__11\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__12\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__13\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__14\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__6\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__7\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__8\ : label is 35;
  attribute ADDER_THRESHOLD of \dt0_carry__9\ : label is 35;
begin
dt0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => dt0_carry_n_0,
      CO(2) => dt0_carry_n_1,
      CO(1) => dt0_carry_n_2,
      CO(0) => dt0_carry_n_3,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => dt0_carry_i_1_n_0,
      DI(0) => '0',
      O(3 downto 0) => dt0(3 downto 0),
      S(3 downto 2) => p_0_in(3 downto 2),
      S(1) => dt0_carry_i_4_n_0,
      S(0) => dt0_carry_i_5_n_0
    );
\dt0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => dt0_carry_n_0,
      CO(3) => \dt0_carry__0_n_0\,
      CO(2) => \dt0_carry__0_n_1\,
      CO(1) => \dt0_carry__0_n_2\,
      CO(0) => \dt0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(7 downto 4),
      S(3 downto 0) => p_0_in(7 downto 4)
    );
\dt0_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(7),
      O => p_0_in(7)
    );
\dt0_carry__0_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(6),
      O => p_0_in(6)
    );
\dt0_carry__0_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(5),
      O => p_0_in(5)
    );
\dt0_carry__0_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(4),
      O => p_0_in(4)
    );
\dt0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__0_n_0\,
      CO(3) => \dt0_carry__1_n_0\,
      CO(2) => \dt0_carry__1_n_1\,
      CO(1) => \dt0_carry__1_n_2\,
      CO(0) => \dt0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(11 downto 8),
      S(3 downto 0) => p_0_in(11 downto 8)
    );
\dt0_carry__10\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__9_n_0\,
      CO(3) => \dt0_carry__10_n_0\,
      CO(2) => \dt0_carry__10_n_1\,
      CO(1) => \dt0_carry__10_n_2\,
      CO(0) => \dt0_carry__10_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(47 downto 44),
      S(3 downto 0) => p_0_in(47 downto 44)
    );
\dt0_carry__10_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(47),
      O => p_0_in(47)
    );
\dt0_carry__10_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(46),
      O => p_0_in(46)
    );
\dt0_carry__10_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(45),
      O => p_0_in(45)
    );
\dt0_carry__10_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(44),
      O => p_0_in(44)
    );
\dt0_carry__11\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__10_n_0\,
      CO(3) => \dt0_carry__11_n_0\,
      CO(2) => \dt0_carry__11_n_1\,
      CO(1) => \dt0_carry__11_n_2\,
      CO(0) => \dt0_carry__11_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(51 downto 48),
      S(3 downto 0) => p_0_in(51 downto 48)
    );
\dt0_carry__11_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(51),
      O => p_0_in(51)
    );
\dt0_carry__11_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(50),
      O => p_0_in(50)
    );
\dt0_carry__11_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(49),
      O => p_0_in(49)
    );
\dt0_carry__11_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(48),
      O => p_0_in(48)
    );
\dt0_carry__12\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__11_n_0\,
      CO(3) => \dt0_carry__12_n_0\,
      CO(2) => \dt0_carry__12_n_1\,
      CO(1) => \dt0_carry__12_n_2\,
      CO(0) => \dt0_carry__12_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(55 downto 52),
      S(3 downto 0) => p_0_in(55 downto 52)
    );
\dt0_carry__12_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(55),
      O => p_0_in(55)
    );
\dt0_carry__12_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(54),
      O => p_0_in(54)
    );
\dt0_carry__12_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(53),
      O => p_0_in(53)
    );
\dt0_carry__12_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(52),
      O => p_0_in(52)
    );
\dt0_carry__13\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__12_n_0\,
      CO(3) => \dt0_carry__13_n_0\,
      CO(2) => \dt0_carry__13_n_1\,
      CO(1) => \dt0_carry__13_n_2\,
      CO(0) => \dt0_carry__13_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(59 downto 56),
      S(3 downto 0) => p_0_in(59 downto 56)
    );
\dt0_carry__13_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(59),
      O => p_0_in(59)
    );
\dt0_carry__13_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(58),
      O => p_0_in(58)
    );
\dt0_carry__13_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(57),
      O => p_0_in(57)
    );
\dt0_carry__13_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(56),
      O => p_0_in(56)
    );
\dt0_carry__14\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__13_n_0\,
      CO(3) => \NLW_dt0_carry__14_CO_UNCONNECTED\(3),
      CO(2) => \dt0_carry__14_n_1\,
      CO(1) => \dt0_carry__14_n_2\,
      CO(0) => \dt0_carry__14_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(63 downto 60),
      S(3 downto 0) => p_0_in(63 downto 60)
    );
\dt0_carry__14_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(63),
      O => p_0_in(63)
    );
\dt0_carry__14_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(62),
      O => p_0_in(62)
    );
\dt0_carry__14_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(61),
      O => p_0_in(61)
    );
\dt0_carry__14_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(60),
      O => p_0_in(60)
    );
\dt0_carry__1_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(11),
      O => p_0_in(11)
    );
\dt0_carry__1_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(10),
      O => p_0_in(10)
    );
\dt0_carry__1_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(9),
      O => p_0_in(9)
    );
\dt0_carry__1_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(8),
      O => p_0_in(8)
    );
\dt0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__1_n_0\,
      CO(3) => \dt0_carry__2_n_0\,
      CO(2) => \dt0_carry__2_n_1\,
      CO(1) => \dt0_carry__2_n_2\,
      CO(0) => \dt0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(15 downto 12),
      S(3 downto 0) => p_0_in(15 downto 12)
    );
\dt0_carry__2_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(15),
      O => p_0_in(15)
    );
\dt0_carry__2_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(14),
      O => p_0_in(14)
    );
\dt0_carry__2_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(13),
      O => p_0_in(13)
    );
\dt0_carry__2_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(12),
      O => p_0_in(12)
    );
\dt0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__2_n_0\,
      CO(3) => \dt0_carry__3_n_0\,
      CO(2) => \dt0_carry__3_n_1\,
      CO(1) => \dt0_carry__3_n_2\,
      CO(0) => \dt0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(19 downto 16),
      S(3 downto 0) => p_0_in(19 downto 16)
    );
\dt0_carry__3_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(19),
      O => p_0_in(19)
    );
\dt0_carry__3_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(18),
      O => p_0_in(18)
    );
\dt0_carry__3_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(17),
      O => p_0_in(17)
    );
\dt0_carry__3_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(16),
      O => p_0_in(16)
    );
\dt0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__3_n_0\,
      CO(3) => \dt0_carry__4_n_0\,
      CO(2) => \dt0_carry__4_n_1\,
      CO(1) => \dt0_carry__4_n_2\,
      CO(0) => \dt0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(23 downto 20),
      S(3 downto 0) => p_0_in(23 downto 20)
    );
\dt0_carry__4_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(23),
      O => p_0_in(23)
    );
\dt0_carry__4_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(22),
      O => p_0_in(22)
    );
\dt0_carry__4_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(21),
      O => p_0_in(21)
    );
\dt0_carry__4_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(20),
      O => p_0_in(20)
    );
\dt0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__4_n_0\,
      CO(3) => \dt0_carry__5_n_0\,
      CO(2) => \dt0_carry__5_n_1\,
      CO(1) => \dt0_carry__5_n_2\,
      CO(0) => \dt0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(27 downto 24),
      S(3 downto 0) => p_0_in(27 downto 24)
    );
\dt0_carry__5_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(27),
      O => p_0_in(27)
    );
\dt0_carry__5_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(26),
      O => p_0_in(26)
    );
\dt0_carry__5_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(25),
      O => p_0_in(25)
    );
\dt0_carry__5_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(24),
      O => p_0_in(24)
    );
\dt0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__5_n_0\,
      CO(3) => \dt0_carry__6_n_0\,
      CO(2) => \dt0_carry__6_n_1\,
      CO(1) => \dt0_carry__6_n_2\,
      CO(0) => \dt0_carry__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(31 downto 28),
      S(3 downto 0) => p_0_in(31 downto 28)
    );
\dt0_carry__6_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(31),
      O => p_0_in(31)
    );
\dt0_carry__6_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(30),
      O => p_0_in(30)
    );
\dt0_carry__6_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(29),
      O => p_0_in(29)
    );
\dt0_carry__6_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(28),
      O => p_0_in(28)
    );
\dt0_carry__7\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__6_n_0\,
      CO(3) => \dt0_carry__7_n_0\,
      CO(2) => \dt0_carry__7_n_1\,
      CO(1) => \dt0_carry__7_n_2\,
      CO(0) => \dt0_carry__7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(35 downto 32),
      S(3 downto 0) => p_0_in(35 downto 32)
    );
\dt0_carry__7_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(35),
      O => p_0_in(35)
    );
\dt0_carry__7_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(34),
      O => p_0_in(34)
    );
\dt0_carry__7_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(33),
      O => p_0_in(33)
    );
\dt0_carry__7_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(32),
      O => p_0_in(32)
    );
\dt0_carry__8\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__7_n_0\,
      CO(3) => \dt0_carry__8_n_0\,
      CO(2) => \dt0_carry__8_n_1\,
      CO(1) => \dt0_carry__8_n_2\,
      CO(0) => \dt0_carry__8_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(39 downto 36),
      S(3 downto 0) => p_0_in(39 downto 36)
    );
\dt0_carry__8_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(39),
      O => p_0_in(39)
    );
\dt0_carry__8_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(38),
      O => p_0_in(38)
    );
\dt0_carry__8_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(37),
      O => p_0_in(37)
    );
\dt0_carry__8_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(36),
      O => p_0_in(36)
    );
\dt0_carry__9\: unisim.vcomponents.CARRY4
     port map (
      CI => \dt0_carry__8_n_0\,
      CO(3) => \dt0_carry__9_n_0\,
      CO(2) => \dt0_carry__9_n_1\,
      CO(1) => \dt0_carry__9_n_2\,
      CO(0) => \dt0_carry__9_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => dt0(43 downto 40),
      S(3 downto 0) => p_0_in(43 downto 40)
    );
\dt0_carry__9_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(43),
      O => p_0_in(43)
    );
\dt0_carry__9_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(42),
      O => p_0_in(42)
    );
\dt0_carry__9_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(41),
      O => p_0_in(41)
    );
\dt0_carry__9_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(40),
      O => p_0_in(40)
    );
dt0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => time_curr(0),
      I1 => time_prev(0),
      O => dt0_carry_i_1_n_0
    );
dt0_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(3),
      O => p_0_in(3)
    );
dt0_carry_i_3: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => time_prev(2),
      O => p_0_in(2)
    );
dt0_carry_i_4: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => time_prev(0),
      I1 => time_curr(0),
      I2 => time_prev(1),
      O => dt0_carry_i_4_n_0
    );
dt0_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => time_curr(0),
      I1 => time_prev(0),
      O => dt0_carry_i_5_n_0
    );
\dt_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(0),
      Q => dt_out(0),
      R => '0'
    );
\dt_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(10),
      Q => dt_out(10),
      R => '0'
    );
\dt_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(11),
      Q => dt_out(11),
      R => '0'
    );
\dt_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(12),
      Q => dt_out(12),
      R => '0'
    );
\dt_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(13),
      Q => dt_out(13),
      R => '0'
    );
\dt_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(14),
      Q => dt_out(14),
      R => '0'
    );
\dt_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(15),
      Q => dt_out(15),
      R => '0'
    );
\dt_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(16),
      Q => dt_out(16),
      R => '0'
    );
\dt_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(17),
      Q => dt_out(17),
      R => '0'
    );
\dt_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(18),
      Q => dt_out(18),
      R => '0'
    );
\dt_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(19),
      Q => dt_out(19),
      R => '0'
    );
\dt_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(1),
      Q => dt_out(1),
      R => '0'
    );
\dt_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(20),
      Q => dt_out(20),
      R => '0'
    );
\dt_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(21),
      Q => dt_out(21),
      R => '0'
    );
\dt_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(22),
      Q => dt_out(22),
      R => '0'
    );
\dt_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(23),
      Q => dt_out(23),
      R => '0'
    );
\dt_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(24),
      Q => dt_out(24),
      R => '0'
    );
\dt_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(25),
      Q => dt_out(25),
      R => '0'
    );
\dt_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(26),
      Q => dt_out(26),
      R => '0'
    );
\dt_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(27),
      Q => dt_out(27),
      R => '0'
    );
\dt_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(28),
      Q => dt_out(28),
      R => '0'
    );
\dt_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(29),
      Q => dt_out(29),
      R => '0'
    );
\dt_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(2),
      Q => dt_out(2),
      R => '0'
    );
\dt_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(30),
      Q => dt_out(30),
      R => '0'
    );
\dt_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(31),
      Q => dt_out(31),
      R => '0'
    );
\dt_reg[32]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(32),
      Q => dt_out(32),
      R => '0'
    );
\dt_reg[33]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(33),
      Q => dt_out(33),
      R => '0'
    );
\dt_reg[34]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(34),
      Q => dt_out(34),
      R => '0'
    );
\dt_reg[35]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(35),
      Q => dt_out(35),
      R => '0'
    );
\dt_reg[36]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(36),
      Q => dt_out(36),
      R => '0'
    );
\dt_reg[37]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(37),
      Q => dt_out(37),
      R => '0'
    );
\dt_reg[38]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(38),
      Q => dt_out(38),
      R => '0'
    );
\dt_reg[39]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(39),
      Q => dt_out(39),
      R => '0'
    );
\dt_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(3),
      Q => dt_out(3),
      R => '0'
    );
\dt_reg[40]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(40),
      Q => dt_out(40),
      R => '0'
    );
\dt_reg[41]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(41),
      Q => dt_out(41),
      R => '0'
    );
\dt_reg[42]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(42),
      Q => dt_out(42),
      R => '0'
    );
\dt_reg[43]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(43),
      Q => dt_out(43),
      R => '0'
    );
\dt_reg[44]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(44),
      Q => dt_out(44),
      R => '0'
    );
\dt_reg[45]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(45),
      Q => dt_out(45),
      R => '0'
    );
\dt_reg[46]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(46),
      Q => dt_out(46),
      R => '0'
    );
\dt_reg[47]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(47),
      Q => dt_out(47),
      R => '0'
    );
\dt_reg[48]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(48),
      Q => dt_out(48),
      R => '0'
    );
\dt_reg[49]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(49),
      Q => dt_out(49),
      R => '0'
    );
\dt_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(4),
      Q => dt_out(4),
      R => '0'
    );
\dt_reg[50]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(50),
      Q => dt_out(50),
      R => '0'
    );
\dt_reg[51]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(51),
      Q => dt_out(51),
      R => '0'
    );
\dt_reg[52]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(52),
      Q => dt_out(52),
      R => '0'
    );
\dt_reg[53]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(53),
      Q => dt_out(53),
      R => '0'
    );
\dt_reg[54]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(54),
      Q => dt_out(54),
      R => '0'
    );
\dt_reg[55]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(55),
      Q => dt_out(55),
      R => '0'
    );
\dt_reg[56]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(56),
      Q => dt_out(56),
      R => '0'
    );
\dt_reg[57]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(57),
      Q => dt_out(57),
      R => '0'
    );
\dt_reg[58]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(58),
      Q => dt_out(58),
      R => '0'
    );
\dt_reg[59]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(59),
      Q => dt_out(59),
      R => '0'
    );
\dt_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(5),
      Q => dt_out(5),
      R => '0'
    );
\dt_reg[60]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(60),
      Q => dt_out(60),
      R => '0'
    );
\dt_reg[61]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(61),
      Q => dt_out(61),
      R => '0'
    );
\dt_reg[62]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(62),
      Q => dt_out(62),
      R => '0'
    );
\dt_reg[63]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(63),
      Q => dt_out(63),
      R => '0'
    );
\dt_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(6),
      Q => dt_out(6),
      R => '0'
    );
\dt_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(7),
      Q => dt_out(7),
      R => '0'
    );
\dt_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(8),
      Q => dt_out(8),
      R => '0'
    );
\dt_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => dt0(9),
      Q => dt_out(9),
      R => '0'
    );
\new_time_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => time_curr(0),
      Q => new_time_out(0),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    new_angle_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    time_curr : in STD_LOGIC_VECTOR ( 0 to 0 );
    time_prev : in STD_LOGIC_VECTOR ( 63 downto 0 );
    new_angle_pass_on : out STD_LOGIC_VECTOR ( 0 to 0 );
    dt_out : out STD_LOGIC_VECTOR ( 63 downto 0 );
    new_time_out : out STD_LOGIC_VECTOR ( 63 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_time_calc_0_0,time_calc,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "time_calc,Vivado 2021.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  signal \^new_angle_available\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^new_time_out\ : STD_LOGIC_VECTOR ( 0 to 0 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
begin
  \^new_angle_available\(0) <= new_angle_available(0);
  new_angle_pass_on(0) <= \^new_angle_available\(0);
  new_time_out(63) <= \<const0>\;
  new_time_out(62) <= \<const0>\;
  new_time_out(61) <= \<const0>\;
  new_time_out(60) <= \<const0>\;
  new_time_out(59) <= \<const0>\;
  new_time_out(58) <= \<const0>\;
  new_time_out(57) <= \<const0>\;
  new_time_out(56) <= \<const0>\;
  new_time_out(55) <= \<const0>\;
  new_time_out(54) <= \<const0>\;
  new_time_out(53) <= \<const0>\;
  new_time_out(52) <= \<const0>\;
  new_time_out(51) <= \<const0>\;
  new_time_out(50) <= \<const0>\;
  new_time_out(49) <= \<const0>\;
  new_time_out(48) <= \<const0>\;
  new_time_out(47) <= \<const0>\;
  new_time_out(46) <= \<const0>\;
  new_time_out(45) <= \<const0>\;
  new_time_out(44) <= \<const0>\;
  new_time_out(43) <= \<const0>\;
  new_time_out(42) <= \<const0>\;
  new_time_out(41) <= \<const0>\;
  new_time_out(40) <= \<const0>\;
  new_time_out(39) <= \<const0>\;
  new_time_out(38) <= \<const0>\;
  new_time_out(37) <= \<const0>\;
  new_time_out(36) <= \<const0>\;
  new_time_out(35) <= \<const0>\;
  new_time_out(34) <= \<const0>\;
  new_time_out(33) <= \<const0>\;
  new_time_out(32) <= \<const0>\;
  new_time_out(31) <= \<const0>\;
  new_time_out(30) <= \<const0>\;
  new_time_out(29) <= \<const0>\;
  new_time_out(28) <= \<const0>\;
  new_time_out(27) <= \<const0>\;
  new_time_out(26) <= \<const0>\;
  new_time_out(25) <= \<const0>\;
  new_time_out(24) <= \<const0>\;
  new_time_out(23) <= \<const0>\;
  new_time_out(22) <= \<const0>\;
  new_time_out(21) <= \<const0>\;
  new_time_out(20) <= \<const0>\;
  new_time_out(19) <= \<const0>\;
  new_time_out(18) <= \<const0>\;
  new_time_out(17) <= \<const0>\;
  new_time_out(16) <= \<const0>\;
  new_time_out(15) <= \<const0>\;
  new_time_out(14) <= \<const0>\;
  new_time_out(13) <= \<const0>\;
  new_time_out(12) <= \<const0>\;
  new_time_out(11) <= \<const0>\;
  new_time_out(10) <= \<const0>\;
  new_time_out(9) <= \<const0>\;
  new_time_out(8) <= \<const0>\;
  new_time_out(7) <= \<const0>\;
  new_time_out(6) <= \<const0>\;
  new_time_out(5) <= \<const0>\;
  new_time_out(4) <= \<const0>\;
  new_time_out(3) <= \<const0>\;
  new_time_out(2) <= \<const0>\;
  new_time_out(1) <= \<const0>\;
  new_time_out(0) <= \^new_time_out\(0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_time_calc
     port map (
      dt_out(63 downto 0) => dt_out(63 downto 0),
      new_angle_available(0) => \^new_angle_available\(0),
      new_time_out(0) => \^new_time_out\(0),
      time_curr(0) => time_curr(0),
      time_prev(63 downto 0) => time_prev(63 downto 0)
    );
end STRUCTURE;
