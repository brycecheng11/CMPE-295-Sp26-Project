-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Fri Sep  4 02:48:21 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_initial_math_0_0_sim_netlist.vhdl
-- Design      : design_1_initial_math_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math is
  port (
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    dt : in STD_LOGIC_VECTOR ( 31 downto 0 );
    target_velocity : in STD_LOGIC_VECTOR ( 31 downto 0 );
    velocity_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    new_angle_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    new_target_velocity_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math is
  signal derivative11_out : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \derivative1__0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__0_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry__0_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry__0_n_3\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__1_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry__1_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry__1_n_3\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__2_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry__2_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry__2_n_3\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_i_8_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__3_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry__3_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry__3_n_3\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_i_8_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__4_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry__4_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry__4_n_3\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_i_8_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__5_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry__5_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry__5_n_3\ : STD_LOGIC;
  signal \derivative1__0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__6_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__6_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__6_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__6_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__6_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__6_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry__6_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry__6_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry__6_n_3\ : STD_LOGIC;
  signal \derivative1__0_carry_i_1_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_i_2_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_i_3_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_i_4_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_i_5_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_i_6_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_i_7_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_n_0\ : STD_LOGIC;
  signal \derivative1__0_carry_n_1\ : STD_LOGIC;
  signal \derivative1__0_carry_n_2\ : STD_LOGIC;
  signal \derivative1__0_carry_n_3\ : STD_LOGIC;
  signal \derivative[0]_i_10_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_15_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_20_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_25_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_30_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_35_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_5_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[0]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[10]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[11]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[12]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[13]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[14]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[15]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[16]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[17]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[18]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[19]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[1]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[20]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[21]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[22]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[23]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[24]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[25]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[26]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[27]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[28]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[29]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[2]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[30]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_10_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_15_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_20_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_25_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_35_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_43_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_44_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_45_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_46_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_47_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_49_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_50_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_51_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_52_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_53_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_54_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_55_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_56_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_58_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_59_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_5_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_60_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_61_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_62_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_63_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_64_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_65_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_66_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_67_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_68_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_69_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_70_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_71_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_72_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[31]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[3]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[4]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[5]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[6]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[7]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[8]_i_9_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_11_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_12_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_13_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_14_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_16_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_17_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_18_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_19_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_21_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_22_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_23_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_24_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_26_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_27_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_28_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_29_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_31_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_32_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_33_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_34_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_36_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_37_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_38_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_39_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_3_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_40_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_41_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_42_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_4_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_6_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_7_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_8_n_0\ : STD_LOGIC;
  signal \derivative[9]_i_9_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_14_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_14_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_14_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_14_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_19_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_19_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_19_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_19_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_24_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_24_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_24_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_24_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_29_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_29_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_29_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_29_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_34_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_34_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_34_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_34_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_4_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_4_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_4_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_4_n_3\ : STD_LOGIC;
  signal \derivative_reg[0]_i_9_n_0\ : STD_LOGIC;
  signal \derivative_reg[0]_i_9_n_1\ : STD_LOGIC;
  signal \derivative_reg[0]_i_9_n_2\ : STD_LOGIC;
  signal \derivative_reg[0]_i_9_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[10]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[10]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[10]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[11]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[11]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[12]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[12]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[13]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[13]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[14]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[14]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[15]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[15]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[16]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[16]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[17]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[17]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[18]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[18]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[19]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[19]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[1]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[1]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[20]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[20]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[21]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[21]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[22]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[22]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[23]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[23]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[24]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[24]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[25]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[25]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[26]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[26]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[27]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[27]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[28]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[28]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[29]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[29]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[2]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[2]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[30]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[30]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_12_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_21_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_39_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_3_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_48_n_7\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_0\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_1\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_2\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_3\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_4\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_5\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_6\ : STD_LOGIC;
  signal \derivative_reg[31]_i_57_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[3]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[3]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[4]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[4]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[5]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[5]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[6]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[6]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[7]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[7]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[8]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[8]_i_5_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_10_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_15_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_1_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_1_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_1_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_20_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_25_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_2_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_30_n_7\ : STD_LOGIC;
  signal \derivative_reg[9]_i_35_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_35_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_35_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_35_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_35_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_35_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_35_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_0\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_1\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_2\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_3\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_4\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_5\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_6\ : STD_LOGIC;
  signal \derivative_reg[9]_i_5_n_7\ : STD_LOGIC;
  signal error02_out : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \error0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \error0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \error0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \error0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \error0_carry__0_n_0\ : STD_LOGIC;
  signal \error0_carry__0_n_1\ : STD_LOGIC;
  signal \error0_carry__0_n_2\ : STD_LOGIC;
  signal \error0_carry__0_n_3\ : STD_LOGIC;
  signal \error0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \error0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \error0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \error0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \error0_carry__1_n_0\ : STD_LOGIC;
  signal \error0_carry__1_n_1\ : STD_LOGIC;
  signal \error0_carry__1_n_2\ : STD_LOGIC;
  signal \error0_carry__1_n_3\ : STD_LOGIC;
  signal \error0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \error0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \error0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \error0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \error0_carry__2_n_0\ : STD_LOGIC;
  signal \error0_carry__2_n_1\ : STD_LOGIC;
  signal \error0_carry__2_n_2\ : STD_LOGIC;
  signal \error0_carry__2_n_3\ : STD_LOGIC;
  signal \error0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \error0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \error0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \error0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \error0_carry__3_n_0\ : STD_LOGIC;
  signal \error0_carry__3_n_1\ : STD_LOGIC;
  signal \error0_carry__3_n_2\ : STD_LOGIC;
  signal \error0_carry__3_n_3\ : STD_LOGIC;
  signal \error0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \error0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \error0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \error0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \error0_carry__4_n_0\ : STD_LOGIC;
  signal \error0_carry__4_n_1\ : STD_LOGIC;
  signal \error0_carry__4_n_2\ : STD_LOGIC;
  signal \error0_carry__4_n_3\ : STD_LOGIC;
  signal \error0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \error0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \error0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \error0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \error0_carry__5_n_0\ : STD_LOGIC;
  signal \error0_carry__5_n_1\ : STD_LOGIC;
  signal \error0_carry__5_n_2\ : STD_LOGIC;
  signal \error0_carry__5_n_3\ : STD_LOGIC;
  signal \error0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \error0_carry__6_i_2_n_0\ : STD_LOGIC;
  signal \error0_carry__6_i_3_n_0\ : STD_LOGIC;
  signal \error0_carry__6_i_4_n_0\ : STD_LOGIC;
  signal \error0_carry__6_n_1\ : STD_LOGIC;
  signal \error0_carry__6_n_2\ : STD_LOGIC;
  signal \error0_carry__6_n_3\ : STD_LOGIC;
  signal error0_carry_i_1_n_0 : STD_LOGIC;
  signal error0_carry_i_2_n_0 : STD_LOGIC;
  signal error0_carry_i_3_n_0 : STD_LOGIC;
  signal error0_carry_i_4_n_0 : STD_LOGIC;
  signal error0_carry_n_0 : STD_LOGIC;
  signal error0_carry_n_1 : STD_LOGIC;
  signal error0_carry_n_2 : STD_LOGIC;
  signal error0_carry_n_3 : STD_LOGIC;
  signal integral0 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \integral0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_n_0\ : STD_LOGIC;
  signal \integral0_carry__0_n_1\ : STD_LOGIC;
  signal \integral0_carry__0_n_2\ : STD_LOGIC;
  signal \integral0_carry__0_n_3\ : STD_LOGIC;
  signal \integral0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_n_0\ : STD_LOGIC;
  signal \integral0_carry__1_n_1\ : STD_LOGIC;
  signal \integral0_carry__1_n_2\ : STD_LOGIC;
  signal \integral0_carry__1_n_3\ : STD_LOGIC;
  signal \integral0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_n_0\ : STD_LOGIC;
  signal \integral0_carry__2_n_1\ : STD_LOGIC;
  signal \integral0_carry__2_n_2\ : STD_LOGIC;
  signal \integral0_carry__2_n_3\ : STD_LOGIC;
  signal \integral0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_n_0\ : STD_LOGIC;
  signal \integral0_carry__3_n_1\ : STD_LOGIC;
  signal \integral0_carry__3_n_2\ : STD_LOGIC;
  signal \integral0_carry__3_n_3\ : STD_LOGIC;
  signal \integral0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_n_0\ : STD_LOGIC;
  signal \integral0_carry__4_n_1\ : STD_LOGIC;
  signal \integral0_carry__4_n_2\ : STD_LOGIC;
  signal \integral0_carry__4_n_3\ : STD_LOGIC;
  signal \integral0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_n_0\ : STD_LOGIC;
  signal \integral0_carry__5_n_1\ : STD_LOGIC;
  signal \integral0_carry__5_n_2\ : STD_LOGIC;
  signal \integral0_carry__5_n_3\ : STD_LOGIC;
  signal \integral0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_i_2_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_i_3_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_i_4_n_0\ : STD_LOGIC;
  signal \integral0_carry__6_n_1\ : STD_LOGIC;
  signal \integral0_carry__6_n_2\ : STD_LOGIC;
  signal \integral0_carry__6_n_3\ : STD_LOGIC;
  signal integral0_carry_i_1_n_0 : STD_LOGIC;
  signal integral0_carry_i_2_n_0 : STD_LOGIC;
  signal integral0_carry_i_3_n_0 : STD_LOGIC;
  signal integral0_carry_i_4_n_0 : STD_LOGIC;
  signal integral0_carry_n_0 : STD_LOGIC;
  signal integral0_carry_n_1 : STD_LOGIC;
  signal integral0_carry_n_2 : STD_LOGIC;
  signal integral0_carry_n_3 : STD_LOGIC;
  signal \integral1__0_n_100\ : STD_LOGIC;
  signal \integral1__0_n_101\ : STD_LOGIC;
  signal \integral1__0_n_102\ : STD_LOGIC;
  signal \integral1__0_n_103\ : STD_LOGIC;
  signal \integral1__0_n_104\ : STD_LOGIC;
  signal \integral1__0_n_105\ : STD_LOGIC;
  signal \integral1__0_n_106\ : STD_LOGIC;
  signal \integral1__0_n_107\ : STD_LOGIC;
  signal \integral1__0_n_108\ : STD_LOGIC;
  signal \integral1__0_n_109\ : STD_LOGIC;
  signal \integral1__0_n_110\ : STD_LOGIC;
  signal \integral1__0_n_111\ : STD_LOGIC;
  signal \integral1__0_n_112\ : STD_LOGIC;
  signal \integral1__0_n_113\ : STD_LOGIC;
  signal \integral1__0_n_114\ : STD_LOGIC;
  signal \integral1__0_n_115\ : STD_LOGIC;
  signal \integral1__0_n_116\ : STD_LOGIC;
  signal \integral1__0_n_117\ : STD_LOGIC;
  signal \integral1__0_n_118\ : STD_LOGIC;
  signal \integral1__0_n_119\ : STD_LOGIC;
  signal \integral1__0_n_120\ : STD_LOGIC;
  signal \integral1__0_n_121\ : STD_LOGIC;
  signal \integral1__0_n_122\ : STD_LOGIC;
  signal \integral1__0_n_123\ : STD_LOGIC;
  signal \integral1__0_n_124\ : STD_LOGIC;
  signal \integral1__0_n_125\ : STD_LOGIC;
  signal \integral1__0_n_126\ : STD_LOGIC;
  signal \integral1__0_n_127\ : STD_LOGIC;
  signal \integral1__0_n_128\ : STD_LOGIC;
  signal \integral1__0_n_129\ : STD_LOGIC;
  signal \integral1__0_n_130\ : STD_LOGIC;
  signal \integral1__0_n_131\ : STD_LOGIC;
  signal \integral1__0_n_132\ : STD_LOGIC;
  signal \integral1__0_n_133\ : STD_LOGIC;
  signal \integral1__0_n_134\ : STD_LOGIC;
  signal \integral1__0_n_135\ : STD_LOGIC;
  signal \integral1__0_n_136\ : STD_LOGIC;
  signal \integral1__0_n_137\ : STD_LOGIC;
  signal \integral1__0_n_138\ : STD_LOGIC;
  signal \integral1__0_n_139\ : STD_LOGIC;
  signal \integral1__0_n_140\ : STD_LOGIC;
  signal \integral1__0_n_141\ : STD_LOGIC;
  signal \integral1__0_n_142\ : STD_LOGIC;
  signal \integral1__0_n_143\ : STD_LOGIC;
  signal \integral1__0_n_144\ : STD_LOGIC;
  signal \integral1__0_n_145\ : STD_LOGIC;
  signal \integral1__0_n_146\ : STD_LOGIC;
  signal \integral1__0_n_147\ : STD_LOGIC;
  signal \integral1__0_n_148\ : STD_LOGIC;
  signal \integral1__0_n_149\ : STD_LOGIC;
  signal \integral1__0_n_150\ : STD_LOGIC;
  signal \integral1__0_n_151\ : STD_LOGIC;
  signal \integral1__0_n_152\ : STD_LOGIC;
  signal \integral1__0_n_153\ : STD_LOGIC;
  signal \integral1__0_n_58\ : STD_LOGIC;
  signal \integral1__0_n_59\ : STD_LOGIC;
  signal \integral1__0_n_60\ : STD_LOGIC;
  signal \integral1__0_n_61\ : STD_LOGIC;
  signal \integral1__0_n_62\ : STD_LOGIC;
  signal \integral1__0_n_63\ : STD_LOGIC;
  signal \integral1__0_n_64\ : STD_LOGIC;
  signal \integral1__0_n_65\ : STD_LOGIC;
  signal \integral1__0_n_66\ : STD_LOGIC;
  signal \integral1__0_n_67\ : STD_LOGIC;
  signal \integral1__0_n_68\ : STD_LOGIC;
  signal \integral1__0_n_69\ : STD_LOGIC;
  signal \integral1__0_n_70\ : STD_LOGIC;
  signal \integral1__0_n_71\ : STD_LOGIC;
  signal \integral1__0_n_72\ : STD_LOGIC;
  signal \integral1__0_n_73\ : STD_LOGIC;
  signal \integral1__0_n_74\ : STD_LOGIC;
  signal \integral1__0_n_75\ : STD_LOGIC;
  signal \integral1__0_n_76\ : STD_LOGIC;
  signal \integral1__0_n_77\ : STD_LOGIC;
  signal \integral1__0_n_78\ : STD_LOGIC;
  signal \integral1__0_n_79\ : STD_LOGIC;
  signal \integral1__0_n_80\ : STD_LOGIC;
  signal \integral1__0_n_81\ : STD_LOGIC;
  signal \integral1__0_n_82\ : STD_LOGIC;
  signal \integral1__0_n_83\ : STD_LOGIC;
  signal \integral1__0_n_84\ : STD_LOGIC;
  signal \integral1__0_n_85\ : STD_LOGIC;
  signal \integral1__0_n_86\ : STD_LOGIC;
  signal \integral1__0_n_87\ : STD_LOGIC;
  signal \integral1__0_n_88\ : STD_LOGIC;
  signal \integral1__0_n_89\ : STD_LOGIC;
  signal \integral1__0_n_90\ : STD_LOGIC;
  signal \integral1__0_n_91\ : STD_LOGIC;
  signal \integral1__0_n_92\ : STD_LOGIC;
  signal \integral1__0_n_93\ : STD_LOGIC;
  signal \integral1__0_n_94\ : STD_LOGIC;
  signal \integral1__0_n_95\ : STD_LOGIC;
  signal \integral1__0_n_96\ : STD_LOGIC;
  signal \integral1__0_n_97\ : STD_LOGIC;
  signal \integral1__0_n_98\ : STD_LOGIC;
  signal \integral1__0_n_99\ : STD_LOGIC;
  signal \integral1__1_n_100\ : STD_LOGIC;
  signal \integral1__1_n_101\ : STD_LOGIC;
  signal \integral1__1_n_102\ : STD_LOGIC;
  signal \integral1__1_n_103\ : STD_LOGIC;
  signal \integral1__1_n_104\ : STD_LOGIC;
  signal \integral1__1_n_105\ : STD_LOGIC;
  signal \integral1__1_n_58\ : STD_LOGIC;
  signal \integral1__1_n_59\ : STD_LOGIC;
  signal \integral1__1_n_60\ : STD_LOGIC;
  signal \integral1__1_n_61\ : STD_LOGIC;
  signal \integral1__1_n_62\ : STD_LOGIC;
  signal \integral1__1_n_63\ : STD_LOGIC;
  signal \integral1__1_n_64\ : STD_LOGIC;
  signal \integral1__1_n_65\ : STD_LOGIC;
  signal \integral1__1_n_66\ : STD_LOGIC;
  signal \integral1__1_n_67\ : STD_LOGIC;
  signal \integral1__1_n_68\ : STD_LOGIC;
  signal \integral1__1_n_69\ : STD_LOGIC;
  signal \integral1__1_n_70\ : STD_LOGIC;
  signal \integral1__1_n_71\ : STD_LOGIC;
  signal \integral1__1_n_72\ : STD_LOGIC;
  signal \integral1__1_n_73\ : STD_LOGIC;
  signal \integral1__1_n_74\ : STD_LOGIC;
  signal \integral1__1_n_75\ : STD_LOGIC;
  signal \integral1__1_n_76\ : STD_LOGIC;
  signal \integral1__1_n_77\ : STD_LOGIC;
  signal \integral1__1_n_78\ : STD_LOGIC;
  signal \integral1__1_n_79\ : STD_LOGIC;
  signal \integral1__1_n_80\ : STD_LOGIC;
  signal \integral1__1_n_81\ : STD_LOGIC;
  signal \integral1__1_n_82\ : STD_LOGIC;
  signal \integral1__1_n_83\ : STD_LOGIC;
  signal \integral1__1_n_84\ : STD_LOGIC;
  signal \integral1__1_n_85\ : STD_LOGIC;
  signal \integral1__1_n_86\ : STD_LOGIC;
  signal \integral1__1_n_87\ : STD_LOGIC;
  signal \integral1__1_n_88\ : STD_LOGIC;
  signal \integral1__1_n_89\ : STD_LOGIC;
  signal \integral1__1_n_90\ : STD_LOGIC;
  signal \integral1__1_n_91\ : STD_LOGIC;
  signal \integral1__1_n_92\ : STD_LOGIC;
  signal \integral1__1_n_93\ : STD_LOGIC;
  signal \integral1__1_n_94\ : STD_LOGIC;
  signal \integral1__1_n_95\ : STD_LOGIC;
  signal \integral1__1_n_96\ : STD_LOGIC;
  signal \integral1__1_n_97\ : STD_LOGIC;
  signal \integral1__1_n_98\ : STD_LOGIC;
  signal \integral1__1_n_99\ : STD_LOGIC;
  signal \integral1_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \integral1_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \integral1_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \integral1_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \integral1_carry__0_n_0\ : STD_LOGIC;
  signal \integral1_carry__0_n_1\ : STD_LOGIC;
  signal \integral1_carry__0_n_2\ : STD_LOGIC;
  signal \integral1_carry__0_n_3\ : STD_LOGIC;
  signal \integral1_carry__0_n_4\ : STD_LOGIC;
  signal \integral1_carry__0_n_5\ : STD_LOGIC;
  signal \integral1_carry__0_n_6\ : STD_LOGIC;
  signal \integral1_carry__0_n_7\ : STD_LOGIC;
  signal \integral1_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \integral1_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \integral1_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \integral1_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \integral1_carry__1_n_0\ : STD_LOGIC;
  signal \integral1_carry__1_n_1\ : STD_LOGIC;
  signal \integral1_carry__1_n_2\ : STD_LOGIC;
  signal \integral1_carry__1_n_3\ : STD_LOGIC;
  signal \integral1_carry__1_n_4\ : STD_LOGIC;
  signal \integral1_carry__1_n_5\ : STD_LOGIC;
  signal \integral1_carry__1_n_6\ : STD_LOGIC;
  signal \integral1_carry__1_n_7\ : STD_LOGIC;
  signal \integral1_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \integral1_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \integral1_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \integral1_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \integral1_carry__2_n_1\ : STD_LOGIC;
  signal \integral1_carry__2_n_2\ : STD_LOGIC;
  signal \integral1_carry__2_n_3\ : STD_LOGIC;
  signal \integral1_carry__2_n_4\ : STD_LOGIC;
  signal \integral1_carry__2_n_5\ : STD_LOGIC;
  signal \integral1_carry__2_n_6\ : STD_LOGIC;
  signal \integral1_carry__2_n_7\ : STD_LOGIC;
  signal integral1_carry_i_1_n_0 : STD_LOGIC;
  signal integral1_carry_i_2_n_0 : STD_LOGIC;
  signal integral1_carry_i_3_n_0 : STD_LOGIC;
  signal integral1_carry_n_0 : STD_LOGIC;
  signal integral1_carry_n_1 : STD_LOGIC;
  signal integral1_carry_n_2 : STD_LOGIC;
  signal integral1_carry_n_3 : STD_LOGIC;
  signal integral1_carry_n_4 : STD_LOGIC;
  signal integral1_carry_n_5 : STD_LOGIC;
  signal integral1_carry_n_6 : STD_LOGIC;
  signal integral1_carry_n_7 : STD_LOGIC;
  signal integral1_n_100 : STD_LOGIC;
  signal integral1_n_101 : STD_LOGIC;
  signal integral1_n_102 : STD_LOGIC;
  signal integral1_n_103 : STD_LOGIC;
  signal integral1_n_104 : STD_LOGIC;
  signal integral1_n_105 : STD_LOGIC;
  signal integral1_n_106 : STD_LOGIC;
  signal integral1_n_107 : STD_LOGIC;
  signal integral1_n_108 : STD_LOGIC;
  signal integral1_n_109 : STD_LOGIC;
  signal integral1_n_110 : STD_LOGIC;
  signal integral1_n_111 : STD_LOGIC;
  signal integral1_n_112 : STD_LOGIC;
  signal integral1_n_113 : STD_LOGIC;
  signal integral1_n_114 : STD_LOGIC;
  signal integral1_n_115 : STD_LOGIC;
  signal integral1_n_116 : STD_LOGIC;
  signal integral1_n_117 : STD_LOGIC;
  signal integral1_n_118 : STD_LOGIC;
  signal integral1_n_119 : STD_LOGIC;
  signal integral1_n_120 : STD_LOGIC;
  signal integral1_n_121 : STD_LOGIC;
  signal integral1_n_122 : STD_LOGIC;
  signal integral1_n_123 : STD_LOGIC;
  signal integral1_n_124 : STD_LOGIC;
  signal integral1_n_125 : STD_LOGIC;
  signal integral1_n_126 : STD_LOGIC;
  signal integral1_n_127 : STD_LOGIC;
  signal integral1_n_128 : STD_LOGIC;
  signal integral1_n_129 : STD_LOGIC;
  signal integral1_n_130 : STD_LOGIC;
  signal integral1_n_131 : STD_LOGIC;
  signal integral1_n_132 : STD_LOGIC;
  signal integral1_n_133 : STD_LOGIC;
  signal integral1_n_134 : STD_LOGIC;
  signal integral1_n_135 : STD_LOGIC;
  signal integral1_n_136 : STD_LOGIC;
  signal integral1_n_137 : STD_LOGIC;
  signal integral1_n_138 : STD_LOGIC;
  signal integral1_n_139 : STD_LOGIC;
  signal integral1_n_140 : STD_LOGIC;
  signal integral1_n_141 : STD_LOGIC;
  signal integral1_n_142 : STD_LOGIC;
  signal integral1_n_143 : STD_LOGIC;
  signal integral1_n_144 : STD_LOGIC;
  signal integral1_n_145 : STD_LOGIC;
  signal integral1_n_146 : STD_LOGIC;
  signal integral1_n_147 : STD_LOGIC;
  signal integral1_n_148 : STD_LOGIC;
  signal integral1_n_149 : STD_LOGIC;
  signal integral1_n_150 : STD_LOGIC;
  signal integral1_n_151 : STD_LOGIC;
  signal integral1_n_152 : STD_LOGIC;
  signal integral1_n_153 : STD_LOGIC;
  signal integral1_n_58 : STD_LOGIC;
  signal integral1_n_59 : STD_LOGIC;
  signal integral1_n_60 : STD_LOGIC;
  signal integral1_n_61 : STD_LOGIC;
  signal integral1_n_62 : STD_LOGIC;
  signal integral1_n_63 : STD_LOGIC;
  signal integral1_n_64 : STD_LOGIC;
  signal integral1_n_65 : STD_LOGIC;
  signal integral1_n_66 : STD_LOGIC;
  signal integral1_n_67 : STD_LOGIC;
  signal integral1_n_68 : STD_LOGIC;
  signal integral1_n_69 : STD_LOGIC;
  signal integral1_n_70 : STD_LOGIC;
  signal integral1_n_71 : STD_LOGIC;
  signal integral1_n_72 : STD_LOGIC;
  signal integral1_n_73 : STD_LOGIC;
  signal integral1_n_74 : STD_LOGIC;
  signal integral1_n_75 : STD_LOGIC;
  signal integral1_n_76 : STD_LOGIC;
  signal integral1_n_77 : STD_LOGIC;
  signal integral1_n_78 : STD_LOGIC;
  signal integral1_n_79 : STD_LOGIC;
  signal integral1_n_80 : STD_LOGIC;
  signal integral1_n_81 : STD_LOGIC;
  signal integral1_n_82 : STD_LOGIC;
  signal integral1_n_83 : STD_LOGIC;
  signal integral1_n_84 : STD_LOGIC;
  signal integral1_n_85 : STD_LOGIC;
  signal integral1_n_86 : STD_LOGIC;
  signal integral1_n_87 : STD_LOGIC;
  signal integral1_n_88 : STD_LOGIC;
  signal integral1_n_89 : STD_LOGIC;
  signal integral1_n_90 : STD_LOGIC;
  signal integral1_n_91 : STD_LOGIC;
  signal integral1_n_92 : STD_LOGIC;
  signal integral1_n_93 : STD_LOGIC;
  signal integral1_n_94 : STD_LOGIC;
  signal integral1_n_95 : STD_LOGIC;
  signal integral1_n_96 : STD_LOGIC;
  signal integral1_n_97 : STD_LOGIC;
  signal integral1_n_98 : STD_LOGIC;
  signal integral1_n_99 : STD_LOGIC;
  signal \NLW_derivative1__0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_derivative_reg[0]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[0]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_14_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_19_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_24_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_29_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_34_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[0]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[10]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[10]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[10]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[11]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[11]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[11]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[12]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[12]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[12]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[13]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[13]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[13]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[14]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[14]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[14]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[15]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[15]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[15]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[16]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[16]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[16]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[17]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[17]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[17]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[18]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[18]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[18]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[19]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[19]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[19]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[1]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[1]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[1]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[20]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[20]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[20]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[21]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[21]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[21]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[22]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[22]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[22]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[23]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[23]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[23]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[24]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[24]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[24]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[25]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[25]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[25]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[26]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[26]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[26]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[27]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[27]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[27]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[28]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[28]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[28]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[29]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[29]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[29]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[2]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[2]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[2]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[30]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[30]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[30]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[31]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[31]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_derivative_reg[3]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[3]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[3]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[4]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[4]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[4]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[5]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[5]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[5]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[6]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[6]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[6]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[7]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[7]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[7]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[8]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[8]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[8]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_derivative_reg[9]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_derivative_reg[9]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_derivative_reg[9]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_error0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_integral0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_integral1_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_integral1_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_integral1_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_integral1_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_integral1_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_integral1_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_integral1_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_integral1_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_integral1_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral1__0_CARRYCASCOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__0_MULTSIGNOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__0_OVERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__0_PATTERNBDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__0_PATTERNDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__0_UNDERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__0_ACOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal \NLW_integral1__0_BCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_integral1__0_CARRYOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral1__1_CARRYCASCOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__1_MULTSIGNOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__1_OVERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__1_PATTERNBDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__1_PATTERNDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__1_UNDERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_integral1__1_ACOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal \NLW_integral1__1_BCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_integral1__1_CARRYOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_integral1__1_PCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal \NLW_integral1_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \derivative1__0_carry\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative1__0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \derivative1__0_carry__1\ : label is 35;
  attribute HLUTNM : string;
  attribute HLUTNM of \derivative1__0_carry__1_i_1\ : label is "lutpair0";
  attribute HLUTNM of \derivative1__0_carry__1_i_5\ : label is "lutpair1";
  attribute HLUTNM of \derivative1__0_carry__1_i_6\ : label is "lutpair0";
  attribute ADDER_THRESHOLD of \derivative1__0_carry__2\ : label is 35;
  attribute HLUTNM of \derivative1__0_carry__2_i_1\ : label is "lutpair4";
  attribute HLUTNM of \derivative1__0_carry__2_i_2\ : label is "lutpair3";
  attribute HLUTNM of \derivative1__0_carry__2_i_3\ : label is "lutpair2";
  attribute HLUTNM of \derivative1__0_carry__2_i_4\ : label is "lutpair1";
  attribute HLUTNM of \derivative1__0_carry__2_i_5\ : label is "lutpair5";
  attribute HLUTNM of \derivative1__0_carry__2_i_6\ : label is "lutpair4";
  attribute HLUTNM of \derivative1__0_carry__2_i_7\ : label is "lutpair3";
  attribute HLUTNM of \derivative1__0_carry__2_i_8\ : label is "lutpair2";
  attribute ADDER_THRESHOLD of \derivative1__0_carry__3\ : label is 35;
  attribute HLUTNM of \derivative1__0_carry__3_i_1\ : label is "lutpair8";
  attribute HLUTNM of \derivative1__0_carry__3_i_2\ : label is "lutpair7";
  attribute HLUTNM of \derivative1__0_carry__3_i_3\ : label is "lutpair6";
  attribute HLUTNM of \derivative1__0_carry__3_i_4\ : label is "lutpair5";
  attribute HLUTNM of \derivative1__0_carry__3_i_5\ : label is "lutpair9";
  attribute HLUTNM of \derivative1__0_carry__3_i_6\ : label is "lutpair8";
  attribute HLUTNM of \derivative1__0_carry__3_i_7\ : label is "lutpair7";
  attribute HLUTNM of \derivative1__0_carry__3_i_8\ : label is "lutpair6";
  attribute ADDER_THRESHOLD of \derivative1__0_carry__4\ : label is 35;
  attribute HLUTNM of \derivative1__0_carry__4_i_1\ : label is "lutpair12";
  attribute HLUTNM of \derivative1__0_carry__4_i_2\ : label is "lutpair11";
  attribute HLUTNM of \derivative1__0_carry__4_i_3\ : label is "lutpair10";
  attribute HLUTNM of \derivative1__0_carry__4_i_4\ : label is "lutpair9";
  attribute HLUTNM of \derivative1__0_carry__4_i_5\ : label is "lutpair13";
  attribute HLUTNM of \derivative1__0_carry__4_i_6\ : label is "lutpair12";
  attribute HLUTNM of \derivative1__0_carry__4_i_7\ : label is "lutpair11";
  attribute HLUTNM of \derivative1__0_carry__4_i_8\ : label is "lutpair10";
  attribute ADDER_THRESHOLD of \derivative1__0_carry__5\ : label is 35;
  attribute HLUTNM of \derivative1__0_carry__5_i_1\ : label is "lutpair16";
  attribute HLUTNM of \derivative1__0_carry__5_i_2\ : label is "lutpair15";
  attribute HLUTNM of \derivative1__0_carry__5_i_3\ : label is "lutpair14";
  attribute HLUTNM of \derivative1__0_carry__5_i_4\ : label is "lutpair13";
  attribute HLUTNM of \derivative1__0_carry__5_i_5\ : label is "lutpair17";
  attribute HLUTNM of \derivative1__0_carry__5_i_6\ : label is "lutpair16";
  attribute HLUTNM of \derivative1__0_carry__5_i_7\ : label is "lutpair15";
  attribute HLUTNM of \derivative1__0_carry__5_i_8\ : label is "lutpair14";
  attribute ADDER_THRESHOLD of \derivative1__0_carry__6\ : label is 35;
  attribute HLUTNM of \derivative1__0_carry__6_i_1\ : label is "lutpair19";
  attribute HLUTNM of \derivative1__0_carry__6_i_2\ : label is "lutpair18";
  attribute HLUTNM of \derivative1__0_carry__6_i_3\ : label is "lutpair17";
  attribute HLUTNM of \derivative1__0_carry__6_i_6\ : label is "lutpair19";
  attribute HLUTNM of \derivative1__0_carry__6_i_7\ : label is "lutpair18";
  attribute ADDER_THRESHOLD of error0_carry : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \error0_carry__6\ : label is 35;
  attribute ADDER_THRESHOLD of integral0_carry : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \integral0_carry__6\ : label is 35;
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of integral1 : label is "{SYNTH-10 {cell *THIS*} {string 16x18 4}}";
  attribute METHODOLOGY_DRC_VIOS of \integral1__0\ : label is "{SYNTH-10 {cell *THIS*} {string 18x18 4}}";
  attribute METHODOLOGY_DRC_VIOS of \integral1__1\ : label is "{SYNTH-10 {cell *THIS*} {string 18x16 4}}";
  attribute ADDER_THRESHOLD of integral1_carry : label is 35;
  attribute ADDER_THRESHOLD of \integral1_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \integral1_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \integral1_carry__2\ : label is 35;
begin
\derivative1__0_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative1__0_carry_n_0\,
      CO(2) => \derivative1__0_carry_n_1\,
      CO(1) => \derivative1__0_carry_n_2\,
      CO(0) => \derivative1__0_carry_n_3\,
      CYINIT => '1',
      DI(3) => \derivative1__0_carry_i_1_n_0\,
      DI(2) => \derivative1__0_carry_i_2_n_0\,
      DI(1) => \derivative1__0_carry_i_3_n_0\,
      DI(0) => '1',
      O(3 downto 0) => derivative11_out(3 downto 0),
      S(3) => \derivative1__0_carry_i_4_n_0\,
      S(2) => \derivative1__0_carry_i_5_n_0\,
      S(1) => \derivative1__0_carry_i_6_n_0\,
      S(0) => \derivative1__0_carry_i_7_n_0\
    );
\derivative1__0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1__0_carry_n_0\,
      CO(3) => \derivative1__0_carry__0_n_0\,
      CO(2) => \derivative1__0_carry__0_n_1\,
      CO(1) => \derivative1__0_carry__0_n_2\,
      CO(0) => \derivative1__0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \derivative1__0_carry__0_i_1_n_0\,
      DI(2) => \derivative1__0_carry__0_i_2_n_0\,
      DI(1) => \derivative1__0_carry__0_i_3_n_0\,
      DI(0) => \derivative1__0_carry__0_i_4_n_0\,
      O(3 downto 0) => derivative11_out(7 downto 4),
      S(3) => \derivative1__0_carry__0_i_5_n_0\,
      S(2) => \derivative1__0_carry__0_i_6_n_0\,
      S(1) => \derivative1__0_carry__0_i_7_n_0\,
      S(0) => \derivative1__0_carry__0_i_8_n_0\
    );
\derivative1__0_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(6),
      I1 => error_in(6),
      I2 => target_velocity(6),
      O => \derivative1__0_carry__0_i_1_n_0\
    );
\derivative1__0_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(5),
      I1 => error_in(5),
      I2 => target_velocity(5),
      O => \derivative1__0_carry__0_i_2_n_0\
    );
\derivative1__0_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(4),
      I1 => error_in(4),
      I2 => target_velocity(4),
      O => \derivative1__0_carry__0_i_3_n_0\
    );
\derivative1__0_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(3),
      I1 => error_in(3),
      I2 => target_velocity(3),
      O => \derivative1__0_carry__0_i_4_n_0\
    );
\derivative1__0_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(7),
      I1 => error_in(7),
      I2 => target_velocity(7),
      I3 => \derivative1__0_carry__0_i_1_n_0\,
      O => \derivative1__0_carry__0_i_5_n_0\
    );
\derivative1__0_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(6),
      I1 => error_in(6),
      I2 => target_velocity(6),
      I3 => \derivative1__0_carry__0_i_2_n_0\,
      O => \derivative1__0_carry__0_i_6_n_0\
    );
\derivative1__0_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(5),
      I1 => error_in(5),
      I2 => target_velocity(5),
      I3 => \derivative1__0_carry__0_i_3_n_0\,
      O => \derivative1__0_carry__0_i_7_n_0\
    );
\derivative1__0_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(4),
      I1 => error_in(4),
      I2 => target_velocity(4),
      I3 => \derivative1__0_carry__0_i_4_n_0\,
      O => \derivative1__0_carry__0_i_8_n_0\
    );
\derivative1__0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1__0_carry__0_n_0\,
      CO(3) => \derivative1__0_carry__1_n_0\,
      CO(2) => \derivative1__0_carry__1_n_1\,
      CO(1) => \derivative1__0_carry__1_n_2\,
      CO(0) => \derivative1__0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \derivative1__0_carry__1_i_1_n_0\,
      DI(2) => \derivative1__0_carry__1_i_2_n_0\,
      DI(1) => \derivative1__0_carry__1_i_3_n_0\,
      DI(0) => \derivative1__0_carry__1_i_4_n_0\,
      O(3 downto 0) => derivative11_out(11 downto 8),
      S(3) => \derivative1__0_carry__1_i_5_n_0\,
      S(2) => \derivative1__0_carry__1_i_6_n_0\,
      S(1) => \derivative1__0_carry__1_i_7_n_0\,
      S(0) => \derivative1__0_carry__1_i_8_n_0\
    );
\derivative1__0_carry__1_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(10),
      I1 => error_in(10),
      I2 => target_velocity(10),
      O => \derivative1__0_carry__1_i_1_n_0\
    );
\derivative1__0_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(9),
      I1 => error_in(9),
      I2 => target_velocity(9),
      O => \derivative1__0_carry__1_i_2_n_0\
    );
\derivative1__0_carry__1_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(8),
      I1 => error_in(8),
      I2 => target_velocity(8),
      O => \derivative1__0_carry__1_i_3_n_0\
    );
\derivative1__0_carry__1_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(7),
      I1 => error_in(7),
      I2 => target_velocity(7),
      O => \derivative1__0_carry__1_i_4_n_0\
    );
\derivative1__0_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(11),
      I1 => error_in(11),
      I2 => target_velocity(11),
      I3 => \derivative1__0_carry__1_i_1_n_0\,
      O => \derivative1__0_carry__1_i_5_n_0\
    );
\derivative1__0_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(10),
      I1 => error_in(10),
      I2 => target_velocity(10),
      I3 => \derivative1__0_carry__1_i_2_n_0\,
      O => \derivative1__0_carry__1_i_6_n_0\
    );
\derivative1__0_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(9),
      I1 => error_in(9),
      I2 => target_velocity(9),
      I3 => \derivative1__0_carry__1_i_3_n_0\,
      O => \derivative1__0_carry__1_i_7_n_0\
    );
\derivative1__0_carry__1_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(8),
      I1 => error_in(8),
      I2 => target_velocity(8),
      I3 => \derivative1__0_carry__1_i_4_n_0\,
      O => \derivative1__0_carry__1_i_8_n_0\
    );
\derivative1__0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1__0_carry__1_n_0\,
      CO(3) => \derivative1__0_carry__2_n_0\,
      CO(2) => \derivative1__0_carry__2_n_1\,
      CO(1) => \derivative1__0_carry__2_n_2\,
      CO(0) => \derivative1__0_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative1__0_carry__2_i_1_n_0\,
      DI(2) => \derivative1__0_carry__2_i_2_n_0\,
      DI(1) => \derivative1__0_carry__2_i_3_n_0\,
      DI(0) => \derivative1__0_carry__2_i_4_n_0\,
      O(3 downto 0) => derivative11_out(15 downto 12),
      S(3) => \derivative1__0_carry__2_i_5_n_0\,
      S(2) => \derivative1__0_carry__2_i_6_n_0\,
      S(1) => \derivative1__0_carry__2_i_7_n_0\,
      S(0) => \derivative1__0_carry__2_i_8_n_0\
    );
\derivative1__0_carry__2_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(14),
      I1 => error_in(14),
      I2 => target_velocity(14),
      O => \derivative1__0_carry__2_i_1_n_0\
    );
\derivative1__0_carry__2_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(13),
      I1 => error_in(13),
      I2 => target_velocity(13),
      O => \derivative1__0_carry__2_i_2_n_0\
    );
\derivative1__0_carry__2_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(12),
      I1 => error_in(12),
      I2 => target_velocity(12),
      O => \derivative1__0_carry__2_i_3_n_0\
    );
\derivative1__0_carry__2_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(11),
      I1 => error_in(11),
      I2 => target_velocity(11),
      O => \derivative1__0_carry__2_i_4_n_0\
    );
\derivative1__0_carry__2_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(15),
      I1 => error_in(15),
      I2 => target_velocity(15),
      I3 => \derivative1__0_carry__2_i_1_n_0\,
      O => \derivative1__0_carry__2_i_5_n_0\
    );
\derivative1__0_carry__2_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(14),
      I1 => error_in(14),
      I2 => target_velocity(14),
      I3 => \derivative1__0_carry__2_i_2_n_0\,
      O => \derivative1__0_carry__2_i_6_n_0\
    );
\derivative1__0_carry__2_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(13),
      I1 => error_in(13),
      I2 => target_velocity(13),
      I3 => \derivative1__0_carry__2_i_3_n_0\,
      O => \derivative1__0_carry__2_i_7_n_0\
    );
\derivative1__0_carry__2_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(12),
      I1 => error_in(12),
      I2 => target_velocity(12),
      I3 => \derivative1__0_carry__2_i_4_n_0\,
      O => \derivative1__0_carry__2_i_8_n_0\
    );
\derivative1__0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1__0_carry__2_n_0\,
      CO(3) => \derivative1__0_carry__3_n_0\,
      CO(2) => \derivative1__0_carry__3_n_1\,
      CO(1) => \derivative1__0_carry__3_n_2\,
      CO(0) => \derivative1__0_carry__3_n_3\,
      CYINIT => '0',
      DI(3) => \derivative1__0_carry__3_i_1_n_0\,
      DI(2) => \derivative1__0_carry__3_i_2_n_0\,
      DI(1) => \derivative1__0_carry__3_i_3_n_0\,
      DI(0) => \derivative1__0_carry__3_i_4_n_0\,
      O(3 downto 0) => derivative11_out(19 downto 16),
      S(3) => \derivative1__0_carry__3_i_5_n_0\,
      S(2) => \derivative1__0_carry__3_i_6_n_0\,
      S(1) => \derivative1__0_carry__3_i_7_n_0\,
      S(0) => \derivative1__0_carry__3_i_8_n_0\
    );
\derivative1__0_carry__3_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(18),
      I1 => error_in(18),
      I2 => target_velocity(18),
      O => \derivative1__0_carry__3_i_1_n_0\
    );
\derivative1__0_carry__3_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(17),
      I1 => error_in(17),
      I2 => target_velocity(17),
      O => \derivative1__0_carry__3_i_2_n_0\
    );
\derivative1__0_carry__3_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(16),
      I1 => error_in(16),
      I2 => target_velocity(16),
      O => \derivative1__0_carry__3_i_3_n_0\
    );
\derivative1__0_carry__3_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(15),
      I1 => error_in(15),
      I2 => target_velocity(15),
      O => \derivative1__0_carry__3_i_4_n_0\
    );
\derivative1__0_carry__3_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(19),
      I1 => error_in(19),
      I2 => target_velocity(19),
      I3 => \derivative1__0_carry__3_i_1_n_0\,
      O => \derivative1__0_carry__3_i_5_n_0\
    );
\derivative1__0_carry__3_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(18),
      I1 => error_in(18),
      I2 => target_velocity(18),
      I3 => \derivative1__0_carry__3_i_2_n_0\,
      O => \derivative1__0_carry__3_i_6_n_0\
    );
\derivative1__0_carry__3_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(17),
      I1 => error_in(17),
      I2 => target_velocity(17),
      I3 => \derivative1__0_carry__3_i_3_n_0\,
      O => \derivative1__0_carry__3_i_7_n_0\
    );
\derivative1__0_carry__3_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(16),
      I1 => error_in(16),
      I2 => target_velocity(16),
      I3 => \derivative1__0_carry__3_i_4_n_0\,
      O => \derivative1__0_carry__3_i_8_n_0\
    );
\derivative1__0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1__0_carry__3_n_0\,
      CO(3) => \derivative1__0_carry__4_n_0\,
      CO(2) => \derivative1__0_carry__4_n_1\,
      CO(1) => \derivative1__0_carry__4_n_2\,
      CO(0) => \derivative1__0_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \derivative1__0_carry__4_i_1_n_0\,
      DI(2) => \derivative1__0_carry__4_i_2_n_0\,
      DI(1) => \derivative1__0_carry__4_i_3_n_0\,
      DI(0) => \derivative1__0_carry__4_i_4_n_0\,
      O(3 downto 0) => derivative11_out(23 downto 20),
      S(3) => \derivative1__0_carry__4_i_5_n_0\,
      S(2) => \derivative1__0_carry__4_i_6_n_0\,
      S(1) => \derivative1__0_carry__4_i_7_n_0\,
      S(0) => \derivative1__0_carry__4_i_8_n_0\
    );
\derivative1__0_carry__4_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(22),
      I1 => error_in(22),
      I2 => target_velocity(22),
      O => \derivative1__0_carry__4_i_1_n_0\
    );
\derivative1__0_carry__4_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(21),
      I1 => error_in(21),
      I2 => target_velocity(21),
      O => \derivative1__0_carry__4_i_2_n_0\
    );
\derivative1__0_carry__4_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(20),
      I1 => error_in(20),
      I2 => target_velocity(20),
      O => \derivative1__0_carry__4_i_3_n_0\
    );
\derivative1__0_carry__4_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(19),
      I1 => error_in(19),
      I2 => target_velocity(19),
      O => \derivative1__0_carry__4_i_4_n_0\
    );
\derivative1__0_carry__4_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(23),
      I1 => error_in(23),
      I2 => target_velocity(23),
      I3 => \derivative1__0_carry__4_i_1_n_0\,
      O => \derivative1__0_carry__4_i_5_n_0\
    );
\derivative1__0_carry__4_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(22),
      I1 => error_in(22),
      I2 => target_velocity(22),
      I3 => \derivative1__0_carry__4_i_2_n_0\,
      O => \derivative1__0_carry__4_i_6_n_0\
    );
\derivative1__0_carry__4_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(21),
      I1 => error_in(21),
      I2 => target_velocity(21),
      I3 => \derivative1__0_carry__4_i_3_n_0\,
      O => \derivative1__0_carry__4_i_7_n_0\
    );
\derivative1__0_carry__4_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(20),
      I1 => error_in(20),
      I2 => target_velocity(20),
      I3 => \derivative1__0_carry__4_i_4_n_0\,
      O => \derivative1__0_carry__4_i_8_n_0\
    );
\derivative1__0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1__0_carry__4_n_0\,
      CO(3) => \derivative1__0_carry__5_n_0\,
      CO(2) => \derivative1__0_carry__5_n_1\,
      CO(1) => \derivative1__0_carry__5_n_2\,
      CO(0) => \derivative1__0_carry__5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative1__0_carry__5_i_1_n_0\,
      DI(2) => \derivative1__0_carry__5_i_2_n_0\,
      DI(1) => \derivative1__0_carry__5_i_3_n_0\,
      DI(0) => \derivative1__0_carry__5_i_4_n_0\,
      O(3 downto 0) => derivative11_out(27 downto 24),
      S(3) => \derivative1__0_carry__5_i_5_n_0\,
      S(2) => \derivative1__0_carry__5_i_6_n_0\,
      S(1) => \derivative1__0_carry__5_i_7_n_0\,
      S(0) => \derivative1__0_carry__5_i_8_n_0\
    );
\derivative1__0_carry__5_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(26),
      I1 => error_in(26),
      I2 => target_velocity(26),
      O => \derivative1__0_carry__5_i_1_n_0\
    );
\derivative1__0_carry__5_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(25),
      I1 => error_in(25),
      I2 => target_velocity(25),
      O => \derivative1__0_carry__5_i_2_n_0\
    );
\derivative1__0_carry__5_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(24),
      I1 => error_in(24),
      I2 => target_velocity(24),
      O => \derivative1__0_carry__5_i_3_n_0\
    );
\derivative1__0_carry__5_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(23),
      I1 => error_in(23),
      I2 => target_velocity(23),
      O => \derivative1__0_carry__5_i_4_n_0\
    );
\derivative1__0_carry__5_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(27),
      I1 => error_in(27),
      I2 => target_velocity(27),
      I3 => \derivative1__0_carry__5_i_1_n_0\,
      O => \derivative1__0_carry__5_i_5_n_0\
    );
\derivative1__0_carry__5_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(26),
      I1 => error_in(26),
      I2 => target_velocity(26),
      I3 => \derivative1__0_carry__5_i_2_n_0\,
      O => \derivative1__0_carry__5_i_6_n_0\
    );
\derivative1__0_carry__5_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(25),
      I1 => error_in(25),
      I2 => target_velocity(25),
      I3 => \derivative1__0_carry__5_i_3_n_0\,
      O => \derivative1__0_carry__5_i_7_n_0\
    );
\derivative1__0_carry__5_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(24),
      I1 => error_in(24),
      I2 => target_velocity(24),
      I3 => \derivative1__0_carry__5_i_4_n_0\,
      O => \derivative1__0_carry__5_i_8_n_0\
    );
\derivative1__0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative1__0_carry__5_n_0\,
      CO(3) => \NLW_derivative1__0_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \derivative1__0_carry__6_n_1\,
      CO(1) => \derivative1__0_carry__6_n_2\,
      CO(0) => \derivative1__0_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \derivative1__0_carry__6_i_1_n_0\,
      DI(1) => \derivative1__0_carry__6_i_2_n_0\,
      DI(0) => \derivative1__0_carry__6_i_3_n_0\,
      O(3 downto 0) => derivative11_out(31 downto 28),
      S(3) => \derivative1__0_carry__6_i_4_n_0\,
      S(2) => \derivative1__0_carry__6_i_5_n_0\,
      S(1) => \derivative1__0_carry__6_i_6_n_0\,
      S(0) => \derivative1__0_carry__6_i_7_n_0\
    );
\derivative1__0_carry__6_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(29),
      I1 => error_in(29),
      I2 => target_velocity(29),
      O => \derivative1__0_carry__6_i_1_n_0\
    );
\derivative1__0_carry__6_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(28),
      I1 => error_in(28),
      I2 => target_velocity(28),
      O => \derivative1__0_carry__6_i_2_n_0\
    );
\derivative1__0_carry__6_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(27),
      I1 => error_in(27),
      I2 => target_velocity(27),
      O => \derivative1__0_carry__6_i_3_n_0\
    );
\derivative1__0_carry__6_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D42B2BD42BD4D42B"
    )
        port map (
      I0 => target_velocity(30),
      I1 => error_in(30),
      I2 => velocity_in(30),
      I3 => error_in(31),
      I4 => velocity_in(31),
      I5 => target_velocity(31),
      O => \derivative1__0_carry__6_i_4_n_0\
    );
\derivative1__0_carry__6_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \derivative1__0_carry__6_i_1_n_0\,
      I1 => error_in(30),
      I2 => velocity_in(30),
      I3 => target_velocity(30),
      O => \derivative1__0_carry__6_i_5_n_0\
    );
\derivative1__0_carry__6_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(29),
      I1 => error_in(29),
      I2 => target_velocity(29),
      I3 => \derivative1__0_carry__6_i_2_n_0\,
      O => \derivative1__0_carry__6_i_6_n_0\
    );
\derivative1__0_carry__6_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(28),
      I1 => error_in(28),
      I2 => target_velocity(28),
      I3 => \derivative1__0_carry__6_i_3_n_0\,
      O => \derivative1__0_carry__6_i_7_n_0\
    );
\derivative1__0_carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(2),
      I1 => error_in(2),
      I2 => target_velocity(2),
      O => \derivative1__0_carry_i_1_n_0\
    );
\derivative1__0_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(1),
      I1 => error_in(1),
      I2 => target_velocity(1),
      O => \derivative1__0_carry_i_2_n_0\
    );
\derivative1__0_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => velocity_in(0),
      I1 => error_in(0),
      I2 => target_velocity(0),
      O => \derivative1__0_carry_i_3_n_0\
    );
\derivative1__0_carry_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(3),
      I1 => error_in(3),
      I2 => target_velocity(3),
      I3 => \derivative1__0_carry_i_1_n_0\,
      O => \derivative1__0_carry_i_4_n_0\
    );
\derivative1__0_carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(2),
      I1 => error_in(2),
      I2 => target_velocity(2),
      I3 => \derivative1__0_carry_i_2_n_0\,
      O => \derivative1__0_carry_i_5_n_0\
    );
\derivative1__0_carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => velocity_in(1),
      I1 => error_in(1),
      I2 => target_velocity(1),
      I3 => \derivative1__0_carry_i_3_n_0\,
      O => \derivative1__0_carry_i_6_n_0\
    );
\derivative1__0_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => velocity_in(0),
      I1 => error_in(0),
      I2 => target_velocity(0),
      O => \derivative1__0_carry_i_7_n_0\
    );
\derivative[0]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[1]_i_5_n_4\,
      O => \derivative[0]_i_10_n_0\
    );
\derivative[0]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[1]_i_5_n_5\,
      O => \derivative[0]_i_11_n_0\
    );
\derivative[0]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[1]_i_5_n_6\,
      O => \derivative[0]_i_12_n_0\
    );
\derivative[0]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[1]_i_5_n_7\,
      O => \derivative[0]_i_13_n_0\
    );
\derivative[0]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[1]_i_10_n_4\,
      O => \derivative[0]_i_15_n_0\
    );
\derivative[0]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[1]_i_10_n_5\,
      O => \derivative[0]_i_16_n_0\
    );
\derivative[0]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[1]_i_10_n_6\,
      O => \derivative[0]_i_17_n_0\
    );
\derivative[0]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[1]_i_10_n_7\,
      O => \derivative[0]_i_18_n_0\
    );
\derivative[0]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[1]_i_15_n_4\,
      O => \derivative[0]_i_20_n_0\
    );
\derivative[0]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[1]_i_15_n_5\,
      O => \derivative[0]_i_21_n_0\
    );
\derivative[0]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[1]_i_15_n_6\,
      O => \derivative[0]_i_22_n_0\
    );
\derivative[0]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[1]_i_15_n_7\,
      O => \derivative[0]_i_23_n_0\
    );
\derivative[0]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[1]_i_20_n_4\,
      O => \derivative[0]_i_25_n_0\
    );
\derivative[0]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[1]_i_20_n_5\,
      O => \derivative[0]_i_26_n_0\
    );
\derivative[0]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[1]_i_20_n_6\,
      O => \derivative[0]_i_27_n_0\
    );
\derivative[0]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[1]_i_20_n_7\,
      O => \derivative[0]_i_28_n_0\
    );
\derivative[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => \derivative_reg[1]_i_1_n_7\,
      O => \derivative[0]_i_3_n_0\
    );
\derivative[0]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[1]_i_25_n_4\,
      O => \derivative[0]_i_30_n_0\
    );
\derivative[0]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[1]_i_25_n_5\,
      O => \derivative[0]_i_31_n_0\
    );
\derivative[0]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[1]_i_25_n_6\,
      O => \derivative[0]_i_32_n_0\
    );
\derivative[0]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[1]_i_25_n_7\,
      O => \derivative[0]_i_33_n_0\
    );
\derivative[0]_i_35\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[1]_i_30_n_4\,
      O => \derivative[0]_i_35_n_0\
    );
\derivative[0]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[1]_i_30_n_5\,
      O => \derivative[0]_i_36_n_0\
    );
\derivative[0]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[1]_i_30_n_6\,
      O => \derivative[0]_i_37_n_0\
    );
\derivative[0]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[1]_i_30_n_7\,
      O => \derivative[0]_i_38_n_0\
    );
\derivative[0]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[1]_i_35_n_4\,
      O => \derivative[0]_i_39_n_0\
    );
\derivative[0]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[1]_i_35_n_5\,
      O => \derivative[0]_i_40_n_0\
    );
\derivative[0]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[1]_i_35_n_6\,
      O => \derivative[0]_i_41_n_0\
    );
\derivative[0]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(0),
      O => \derivative[0]_i_42_n_0\
    );
\derivative[0]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[1]_i_2_n_4\,
      O => \derivative[0]_i_5_n_0\
    );
\derivative[0]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[1]_i_2_n_5\,
      O => \derivative[0]_i_6_n_0\
    );
\derivative[0]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[1]_i_2_n_6\,
      O => \derivative[0]_i_7_n_0\
    );
\derivative[0]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[1]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[1]_i_2_n_7\,
      O => \derivative[0]_i_8_n_0\
    );
\derivative[10]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[11]_i_5_n_5\,
      O => \derivative[10]_i_11_n_0\
    );
\derivative[10]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[11]_i_5_n_6\,
      O => \derivative[10]_i_12_n_0\
    );
\derivative[10]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[11]_i_5_n_7\,
      O => \derivative[10]_i_13_n_0\
    );
\derivative[10]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[11]_i_10_n_4\,
      O => \derivative[10]_i_14_n_0\
    );
\derivative[10]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[11]_i_10_n_5\,
      O => \derivative[10]_i_16_n_0\
    );
\derivative[10]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[11]_i_10_n_6\,
      O => \derivative[10]_i_17_n_0\
    );
\derivative[10]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[11]_i_10_n_7\,
      O => \derivative[10]_i_18_n_0\
    );
\derivative[10]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[11]_i_15_n_4\,
      O => \derivative[10]_i_19_n_0\
    );
\derivative[10]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[11]_i_15_n_5\,
      O => \derivative[10]_i_21_n_0\
    );
\derivative[10]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[11]_i_15_n_6\,
      O => \derivative[10]_i_22_n_0\
    );
\derivative[10]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[11]_i_15_n_7\,
      O => \derivative[10]_i_23_n_0\
    );
\derivative[10]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[11]_i_20_n_4\,
      O => \derivative[10]_i_24_n_0\
    );
\derivative[10]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[11]_i_20_n_5\,
      O => \derivative[10]_i_26_n_0\
    );
\derivative[10]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[11]_i_20_n_6\,
      O => \derivative[10]_i_27_n_0\
    );
\derivative[10]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[11]_i_20_n_7\,
      O => \derivative[10]_i_28_n_0\
    );
\derivative[10]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[11]_i_25_n_4\,
      O => \derivative[10]_i_29_n_0\
    );
\derivative[10]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => \derivative_reg[11]_i_1_n_7\,
      O => \derivative[10]_i_3_n_0\
    );
\derivative[10]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[11]_i_25_n_5\,
      O => \derivative[10]_i_31_n_0\
    );
\derivative[10]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[11]_i_25_n_6\,
      O => \derivative[10]_i_32_n_0\
    );
\derivative[10]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[11]_i_25_n_7\,
      O => \derivative[10]_i_33_n_0\
    );
\derivative[10]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[11]_i_30_n_4\,
      O => \derivative[10]_i_34_n_0\
    );
\derivative[10]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[11]_i_30_n_5\,
      O => \derivative[10]_i_36_n_0\
    );
\derivative[10]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[11]_i_30_n_6\,
      O => \derivative[10]_i_37_n_0\
    );
\derivative[10]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[11]_i_30_n_7\,
      O => \derivative[10]_i_38_n_0\
    );
\derivative[10]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[11]_i_35_n_4\,
      O => \derivative[10]_i_39_n_0\
    );
\derivative[10]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[11]_i_2_n_4\,
      O => \derivative[10]_i_4_n_0\
    );
\derivative[10]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[11]_i_35_n_5\,
      O => \derivative[10]_i_40_n_0\
    );
\derivative[10]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[11]_i_35_n_6\,
      O => \derivative[10]_i_41_n_0\
    );
\derivative[10]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(10),
      O => \derivative[10]_i_42_n_0\
    );
\derivative[10]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[11]_i_2_n_5\,
      O => \derivative[10]_i_6_n_0\
    );
\derivative[10]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[11]_i_2_n_6\,
      O => \derivative[10]_i_7_n_0\
    );
\derivative[10]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[11]_i_2_n_7\,
      O => \derivative[10]_i_8_n_0\
    );
\derivative[10]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[11]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[11]_i_5_n_4\,
      O => \derivative[10]_i_9_n_0\
    );
\derivative[11]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[12]_i_5_n_5\,
      O => \derivative[11]_i_11_n_0\
    );
\derivative[11]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[12]_i_5_n_6\,
      O => \derivative[11]_i_12_n_0\
    );
\derivative[11]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[12]_i_5_n_7\,
      O => \derivative[11]_i_13_n_0\
    );
\derivative[11]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[12]_i_10_n_4\,
      O => \derivative[11]_i_14_n_0\
    );
\derivative[11]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[12]_i_10_n_5\,
      O => \derivative[11]_i_16_n_0\
    );
\derivative[11]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[12]_i_10_n_6\,
      O => \derivative[11]_i_17_n_0\
    );
\derivative[11]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[12]_i_10_n_7\,
      O => \derivative[11]_i_18_n_0\
    );
\derivative[11]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[12]_i_15_n_4\,
      O => \derivative[11]_i_19_n_0\
    );
\derivative[11]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[12]_i_15_n_5\,
      O => \derivative[11]_i_21_n_0\
    );
\derivative[11]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[12]_i_15_n_6\,
      O => \derivative[11]_i_22_n_0\
    );
\derivative[11]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[12]_i_15_n_7\,
      O => \derivative[11]_i_23_n_0\
    );
\derivative[11]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[12]_i_20_n_4\,
      O => \derivative[11]_i_24_n_0\
    );
\derivative[11]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[12]_i_20_n_5\,
      O => \derivative[11]_i_26_n_0\
    );
\derivative[11]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[12]_i_20_n_6\,
      O => \derivative[11]_i_27_n_0\
    );
\derivative[11]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[12]_i_20_n_7\,
      O => \derivative[11]_i_28_n_0\
    );
\derivative[11]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[12]_i_25_n_4\,
      O => \derivative[11]_i_29_n_0\
    );
\derivative[11]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => \derivative_reg[12]_i_1_n_7\,
      O => \derivative[11]_i_3_n_0\
    );
\derivative[11]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[12]_i_25_n_5\,
      O => \derivative[11]_i_31_n_0\
    );
\derivative[11]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[12]_i_25_n_6\,
      O => \derivative[11]_i_32_n_0\
    );
\derivative[11]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[12]_i_25_n_7\,
      O => \derivative[11]_i_33_n_0\
    );
\derivative[11]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[12]_i_30_n_4\,
      O => \derivative[11]_i_34_n_0\
    );
\derivative[11]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[12]_i_30_n_5\,
      O => \derivative[11]_i_36_n_0\
    );
\derivative[11]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[12]_i_30_n_6\,
      O => \derivative[11]_i_37_n_0\
    );
\derivative[11]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[12]_i_30_n_7\,
      O => \derivative[11]_i_38_n_0\
    );
\derivative[11]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[12]_i_35_n_4\,
      O => \derivative[11]_i_39_n_0\
    );
\derivative[11]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[12]_i_2_n_4\,
      O => \derivative[11]_i_4_n_0\
    );
\derivative[11]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[12]_i_35_n_5\,
      O => \derivative[11]_i_40_n_0\
    );
\derivative[11]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[12]_i_35_n_6\,
      O => \derivative[11]_i_41_n_0\
    );
\derivative[11]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(11),
      O => \derivative[11]_i_42_n_0\
    );
\derivative[11]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[12]_i_2_n_5\,
      O => \derivative[11]_i_6_n_0\
    );
\derivative[11]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[12]_i_2_n_6\,
      O => \derivative[11]_i_7_n_0\
    );
\derivative[11]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[12]_i_2_n_7\,
      O => \derivative[11]_i_8_n_0\
    );
\derivative[11]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[12]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[12]_i_5_n_4\,
      O => \derivative[11]_i_9_n_0\
    );
\derivative[12]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[13]_i_5_n_5\,
      O => \derivative[12]_i_11_n_0\
    );
\derivative[12]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[13]_i_5_n_6\,
      O => \derivative[12]_i_12_n_0\
    );
\derivative[12]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[13]_i_5_n_7\,
      O => \derivative[12]_i_13_n_0\
    );
\derivative[12]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[13]_i_10_n_4\,
      O => \derivative[12]_i_14_n_0\
    );
\derivative[12]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[13]_i_10_n_5\,
      O => \derivative[12]_i_16_n_0\
    );
\derivative[12]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[13]_i_10_n_6\,
      O => \derivative[12]_i_17_n_0\
    );
\derivative[12]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[13]_i_10_n_7\,
      O => \derivative[12]_i_18_n_0\
    );
\derivative[12]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[13]_i_15_n_4\,
      O => \derivative[12]_i_19_n_0\
    );
\derivative[12]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[13]_i_15_n_5\,
      O => \derivative[12]_i_21_n_0\
    );
\derivative[12]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[13]_i_15_n_6\,
      O => \derivative[12]_i_22_n_0\
    );
\derivative[12]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[13]_i_15_n_7\,
      O => \derivative[12]_i_23_n_0\
    );
\derivative[12]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[13]_i_20_n_4\,
      O => \derivative[12]_i_24_n_0\
    );
\derivative[12]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[13]_i_20_n_5\,
      O => \derivative[12]_i_26_n_0\
    );
\derivative[12]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[13]_i_20_n_6\,
      O => \derivative[12]_i_27_n_0\
    );
\derivative[12]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[13]_i_20_n_7\,
      O => \derivative[12]_i_28_n_0\
    );
\derivative[12]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[13]_i_25_n_4\,
      O => \derivative[12]_i_29_n_0\
    );
\derivative[12]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => \derivative_reg[13]_i_1_n_7\,
      O => \derivative[12]_i_3_n_0\
    );
\derivative[12]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[13]_i_25_n_5\,
      O => \derivative[12]_i_31_n_0\
    );
\derivative[12]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[13]_i_25_n_6\,
      O => \derivative[12]_i_32_n_0\
    );
\derivative[12]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[13]_i_25_n_7\,
      O => \derivative[12]_i_33_n_0\
    );
\derivative[12]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[13]_i_30_n_4\,
      O => \derivative[12]_i_34_n_0\
    );
\derivative[12]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[13]_i_30_n_5\,
      O => \derivative[12]_i_36_n_0\
    );
\derivative[12]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[13]_i_30_n_6\,
      O => \derivative[12]_i_37_n_0\
    );
\derivative[12]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[13]_i_30_n_7\,
      O => \derivative[12]_i_38_n_0\
    );
\derivative[12]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[13]_i_35_n_4\,
      O => \derivative[12]_i_39_n_0\
    );
\derivative[12]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[13]_i_2_n_4\,
      O => \derivative[12]_i_4_n_0\
    );
\derivative[12]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[13]_i_35_n_5\,
      O => \derivative[12]_i_40_n_0\
    );
\derivative[12]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[13]_i_35_n_6\,
      O => \derivative[12]_i_41_n_0\
    );
\derivative[12]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(12),
      O => \derivative[12]_i_42_n_0\
    );
\derivative[12]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[13]_i_2_n_5\,
      O => \derivative[12]_i_6_n_0\
    );
\derivative[12]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[13]_i_2_n_6\,
      O => \derivative[12]_i_7_n_0\
    );
\derivative[12]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[13]_i_2_n_7\,
      O => \derivative[12]_i_8_n_0\
    );
\derivative[12]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[13]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[13]_i_5_n_4\,
      O => \derivative[12]_i_9_n_0\
    );
\derivative[13]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[14]_i_5_n_5\,
      O => \derivative[13]_i_11_n_0\
    );
\derivative[13]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[14]_i_5_n_6\,
      O => \derivative[13]_i_12_n_0\
    );
\derivative[13]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[14]_i_5_n_7\,
      O => \derivative[13]_i_13_n_0\
    );
\derivative[13]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[14]_i_10_n_4\,
      O => \derivative[13]_i_14_n_0\
    );
\derivative[13]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[14]_i_10_n_5\,
      O => \derivative[13]_i_16_n_0\
    );
\derivative[13]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[14]_i_10_n_6\,
      O => \derivative[13]_i_17_n_0\
    );
\derivative[13]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[14]_i_10_n_7\,
      O => \derivative[13]_i_18_n_0\
    );
\derivative[13]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[14]_i_15_n_4\,
      O => \derivative[13]_i_19_n_0\
    );
\derivative[13]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[14]_i_15_n_5\,
      O => \derivative[13]_i_21_n_0\
    );
\derivative[13]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[14]_i_15_n_6\,
      O => \derivative[13]_i_22_n_0\
    );
\derivative[13]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[14]_i_15_n_7\,
      O => \derivative[13]_i_23_n_0\
    );
\derivative[13]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[14]_i_20_n_4\,
      O => \derivative[13]_i_24_n_0\
    );
\derivative[13]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[14]_i_20_n_5\,
      O => \derivative[13]_i_26_n_0\
    );
\derivative[13]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[14]_i_20_n_6\,
      O => \derivative[13]_i_27_n_0\
    );
\derivative[13]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[14]_i_20_n_7\,
      O => \derivative[13]_i_28_n_0\
    );
\derivative[13]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[14]_i_25_n_4\,
      O => \derivative[13]_i_29_n_0\
    );
\derivative[13]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => \derivative_reg[14]_i_1_n_7\,
      O => \derivative[13]_i_3_n_0\
    );
\derivative[13]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[14]_i_25_n_5\,
      O => \derivative[13]_i_31_n_0\
    );
\derivative[13]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[14]_i_25_n_6\,
      O => \derivative[13]_i_32_n_0\
    );
\derivative[13]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[14]_i_25_n_7\,
      O => \derivative[13]_i_33_n_0\
    );
\derivative[13]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[14]_i_30_n_4\,
      O => \derivative[13]_i_34_n_0\
    );
\derivative[13]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[14]_i_30_n_5\,
      O => \derivative[13]_i_36_n_0\
    );
\derivative[13]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[14]_i_30_n_6\,
      O => \derivative[13]_i_37_n_0\
    );
\derivative[13]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[14]_i_30_n_7\,
      O => \derivative[13]_i_38_n_0\
    );
\derivative[13]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[14]_i_35_n_4\,
      O => \derivative[13]_i_39_n_0\
    );
\derivative[13]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[14]_i_2_n_4\,
      O => \derivative[13]_i_4_n_0\
    );
\derivative[13]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[14]_i_35_n_5\,
      O => \derivative[13]_i_40_n_0\
    );
\derivative[13]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[14]_i_35_n_6\,
      O => \derivative[13]_i_41_n_0\
    );
\derivative[13]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(13),
      O => \derivative[13]_i_42_n_0\
    );
\derivative[13]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[14]_i_2_n_5\,
      O => \derivative[13]_i_6_n_0\
    );
\derivative[13]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[14]_i_2_n_6\,
      O => \derivative[13]_i_7_n_0\
    );
\derivative[13]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[14]_i_2_n_7\,
      O => \derivative[13]_i_8_n_0\
    );
\derivative[13]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[14]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[14]_i_5_n_4\,
      O => \derivative[13]_i_9_n_0\
    );
\derivative[14]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[15]_i_5_n_5\,
      O => \derivative[14]_i_11_n_0\
    );
\derivative[14]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[15]_i_5_n_6\,
      O => \derivative[14]_i_12_n_0\
    );
\derivative[14]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[15]_i_5_n_7\,
      O => \derivative[14]_i_13_n_0\
    );
\derivative[14]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[15]_i_10_n_4\,
      O => \derivative[14]_i_14_n_0\
    );
\derivative[14]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[15]_i_10_n_5\,
      O => \derivative[14]_i_16_n_0\
    );
\derivative[14]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[15]_i_10_n_6\,
      O => \derivative[14]_i_17_n_0\
    );
\derivative[14]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[15]_i_10_n_7\,
      O => \derivative[14]_i_18_n_0\
    );
\derivative[14]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[15]_i_15_n_4\,
      O => \derivative[14]_i_19_n_0\
    );
\derivative[14]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[15]_i_15_n_5\,
      O => \derivative[14]_i_21_n_0\
    );
\derivative[14]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[15]_i_15_n_6\,
      O => \derivative[14]_i_22_n_0\
    );
\derivative[14]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[15]_i_15_n_7\,
      O => \derivative[14]_i_23_n_0\
    );
\derivative[14]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[15]_i_20_n_4\,
      O => \derivative[14]_i_24_n_0\
    );
\derivative[14]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[15]_i_20_n_5\,
      O => \derivative[14]_i_26_n_0\
    );
\derivative[14]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[15]_i_20_n_6\,
      O => \derivative[14]_i_27_n_0\
    );
\derivative[14]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[15]_i_20_n_7\,
      O => \derivative[14]_i_28_n_0\
    );
\derivative[14]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[15]_i_25_n_4\,
      O => \derivative[14]_i_29_n_0\
    );
\derivative[14]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => \derivative_reg[15]_i_1_n_7\,
      O => \derivative[14]_i_3_n_0\
    );
\derivative[14]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[15]_i_25_n_5\,
      O => \derivative[14]_i_31_n_0\
    );
\derivative[14]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[15]_i_25_n_6\,
      O => \derivative[14]_i_32_n_0\
    );
\derivative[14]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[15]_i_25_n_7\,
      O => \derivative[14]_i_33_n_0\
    );
\derivative[14]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[15]_i_30_n_4\,
      O => \derivative[14]_i_34_n_0\
    );
\derivative[14]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[15]_i_30_n_5\,
      O => \derivative[14]_i_36_n_0\
    );
\derivative[14]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[15]_i_30_n_6\,
      O => \derivative[14]_i_37_n_0\
    );
\derivative[14]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[15]_i_30_n_7\,
      O => \derivative[14]_i_38_n_0\
    );
\derivative[14]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[15]_i_35_n_4\,
      O => \derivative[14]_i_39_n_0\
    );
\derivative[14]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[15]_i_2_n_4\,
      O => \derivative[14]_i_4_n_0\
    );
\derivative[14]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[15]_i_35_n_5\,
      O => \derivative[14]_i_40_n_0\
    );
\derivative[14]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[15]_i_35_n_6\,
      O => \derivative[14]_i_41_n_0\
    );
\derivative[14]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(14),
      O => \derivative[14]_i_42_n_0\
    );
\derivative[14]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[15]_i_2_n_5\,
      O => \derivative[14]_i_6_n_0\
    );
\derivative[14]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[15]_i_2_n_6\,
      O => \derivative[14]_i_7_n_0\
    );
\derivative[14]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[15]_i_2_n_7\,
      O => \derivative[14]_i_8_n_0\
    );
\derivative[14]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[15]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[15]_i_5_n_4\,
      O => \derivative[14]_i_9_n_0\
    );
\derivative[15]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[16]_i_5_n_5\,
      O => \derivative[15]_i_11_n_0\
    );
\derivative[15]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[16]_i_5_n_6\,
      O => \derivative[15]_i_12_n_0\
    );
\derivative[15]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[16]_i_5_n_7\,
      O => \derivative[15]_i_13_n_0\
    );
\derivative[15]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[16]_i_10_n_4\,
      O => \derivative[15]_i_14_n_0\
    );
\derivative[15]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[16]_i_10_n_5\,
      O => \derivative[15]_i_16_n_0\
    );
\derivative[15]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[16]_i_10_n_6\,
      O => \derivative[15]_i_17_n_0\
    );
\derivative[15]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[16]_i_10_n_7\,
      O => \derivative[15]_i_18_n_0\
    );
\derivative[15]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[16]_i_15_n_4\,
      O => \derivative[15]_i_19_n_0\
    );
\derivative[15]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[16]_i_15_n_5\,
      O => \derivative[15]_i_21_n_0\
    );
\derivative[15]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[16]_i_15_n_6\,
      O => \derivative[15]_i_22_n_0\
    );
\derivative[15]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[16]_i_15_n_7\,
      O => \derivative[15]_i_23_n_0\
    );
\derivative[15]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[16]_i_20_n_4\,
      O => \derivative[15]_i_24_n_0\
    );
\derivative[15]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[16]_i_20_n_5\,
      O => \derivative[15]_i_26_n_0\
    );
\derivative[15]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[16]_i_20_n_6\,
      O => \derivative[15]_i_27_n_0\
    );
\derivative[15]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[16]_i_20_n_7\,
      O => \derivative[15]_i_28_n_0\
    );
\derivative[15]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[16]_i_25_n_4\,
      O => \derivative[15]_i_29_n_0\
    );
\derivative[15]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => \derivative_reg[16]_i_1_n_7\,
      O => \derivative[15]_i_3_n_0\
    );
\derivative[15]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[16]_i_25_n_5\,
      O => \derivative[15]_i_31_n_0\
    );
\derivative[15]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[16]_i_25_n_6\,
      O => \derivative[15]_i_32_n_0\
    );
\derivative[15]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[16]_i_25_n_7\,
      O => \derivative[15]_i_33_n_0\
    );
\derivative[15]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[16]_i_30_n_4\,
      O => \derivative[15]_i_34_n_0\
    );
\derivative[15]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[16]_i_30_n_5\,
      O => \derivative[15]_i_36_n_0\
    );
\derivative[15]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[16]_i_30_n_6\,
      O => \derivative[15]_i_37_n_0\
    );
\derivative[15]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[16]_i_30_n_7\,
      O => \derivative[15]_i_38_n_0\
    );
\derivative[15]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[16]_i_35_n_4\,
      O => \derivative[15]_i_39_n_0\
    );
\derivative[15]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[16]_i_2_n_4\,
      O => \derivative[15]_i_4_n_0\
    );
\derivative[15]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[16]_i_35_n_5\,
      O => \derivative[15]_i_40_n_0\
    );
\derivative[15]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[16]_i_35_n_6\,
      O => \derivative[15]_i_41_n_0\
    );
\derivative[15]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(15),
      O => \derivative[15]_i_42_n_0\
    );
\derivative[15]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[16]_i_2_n_5\,
      O => \derivative[15]_i_6_n_0\
    );
\derivative[15]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[16]_i_2_n_6\,
      O => \derivative[15]_i_7_n_0\
    );
\derivative[15]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[16]_i_2_n_7\,
      O => \derivative[15]_i_8_n_0\
    );
\derivative[15]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[16]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[16]_i_5_n_4\,
      O => \derivative[15]_i_9_n_0\
    );
\derivative[16]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[17]_i_5_n_5\,
      O => \derivative[16]_i_11_n_0\
    );
\derivative[16]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[17]_i_5_n_6\,
      O => \derivative[16]_i_12_n_0\
    );
\derivative[16]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[17]_i_5_n_7\,
      O => \derivative[16]_i_13_n_0\
    );
\derivative[16]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[17]_i_10_n_4\,
      O => \derivative[16]_i_14_n_0\
    );
\derivative[16]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[17]_i_10_n_5\,
      O => \derivative[16]_i_16_n_0\
    );
\derivative[16]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[17]_i_10_n_6\,
      O => \derivative[16]_i_17_n_0\
    );
\derivative[16]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[17]_i_10_n_7\,
      O => \derivative[16]_i_18_n_0\
    );
\derivative[16]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[17]_i_15_n_4\,
      O => \derivative[16]_i_19_n_0\
    );
\derivative[16]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[17]_i_15_n_5\,
      O => \derivative[16]_i_21_n_0\
    );
\derivative[16]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[17]_i_15_n_6\,
      O => \derivative[16]_i_22_n_0\
    );
\derivative[16]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[17]_i_15_n_7\,
      O => \derivative[16]_i_23_n_0\
    );
\derivative[16]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[17]_i_20_n_4\,
      O => \derivative[16]_i_24_n_0\
    );
\derivative[16]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[17]_i_20_n_5\,
      O => \derivative[16]_i_26_n_0\
    );
\derivative[16]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[17]_i_20_n_6\,
      O => \derivative[16]_i_27_n_0\
    );
\derivative[16]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[17]_i_20_n_7\,
      O => \derivative[16]_i_28_n_0\
    );
\derivative[16]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[17]_i_25_n_4\,
      O => \derivative[16]_i_29_n_0\
    );
\derivative[16]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => \derivative_reg[17]_i_1_n_7\,
      O => \derivative[16]_i_3_n_0\
    );
\derivative[16]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[17]_i_25_n_5\,
      O => \derivative[16]_i_31_n_0\
    );
\derivative[16]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[17]_i_25_n_6\,
      O => \derivative[16]_i_32_n_0\
    );
\derivative[16]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[17]_i_25_n_7\,
      O => \derivative[16]_i_33_n_0\
    );
\derivative[16]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[17]_i_30_n_4\,
      O => \derivative[16]_i_34_n_0\
    );
\derivative[16]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[17]_i_30_n_5\,
      O => \derivative[16]_i_36_n_0\
    );
\derivative[16]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[17]_i_30_n_6\,
      O => \derivative[16]_i_37_n_0\
    );
\derivative[16]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[17]_i_30_n_7\,
      O => \derivative[16]_i_38_n_0\
    );
\derivative[16]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[17]_i_35_n_4\,
      O => \derivative[16]_i_39_n_0\
    );
\derivative[16]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[17]_i_2_n_4\,
      O => \derivative[16]_i_4_n_0\
    );
\derivative[16]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[17]_i_35_n_5\,
      O => \derivative[16]_i_40_n_0\
    );
\derivative[16]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[17]_i_35_n_6\,
      O => \derivative[16]_i_41_n_0\
    );
\derivative[16]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(16),
      O => \derivative[16]_i_42_n_0\
    );
\derivative[16]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[17]_i_2_n_5\,
      O => \derivative[16]_i_6_n_0\
    );
\derivative[16]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[17]_i_2_n_6\,
      O => \derivative[16]_i_7_n_0\
    );
\derivative[16]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[17]_i_2_n_7\,
      O => \derivative[16]_i_8_n_0\
    );
\derivative[16]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[17]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[17]_i_5_n_4\,
      O => \derivative[16]_i_9_n_0\
    );
\derivative[17]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[18]_i_5_n_5\,
      O => \derivative[17]_i_11_n_0\
    );
\derivative[17]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[18]_i_5_n_6\,
      O => \derivative[17]_i_12_n_0\
    );
\derivative[17]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[18]_i_5_n_7\,
      O => \derivative[17]_i_13_n_0\
    );
\derivative[17]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[18]_i_10_n_4\,
      O => \derivative[17]_i_14_n_0\
    );
\derivative[17]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[18]_i_10_n_5\,
      O => \derivative[17]_i_16_n_0\
    );
\derivative[17]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[18]_i_10_n_6\,
      O => \derivative[17]_i_17_n_0\
    );
\derivative[17]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[18]_i_10_n_7\,
      O => \derivative[17]_i_18_n_0\
    );
\derivative[17]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[18]_i_15_n_4\,
      O => \derivative[17]_i_19_n_0\
    );
\derivative[17]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[18]_i_15_n_5\,
      O => \derivative[17]_i_21_n_0\
    );
\derivative[17]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[18]_i_15_n_6\,
      O => \derivative[17]_i_22_n_0\
    );
\derivative[17]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[18]_i_15_n_7\,
      O => \derivative[17]_i_23_n_0\
    );
\derivative[17]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[18]_i_20_n_4\,
      O => \derivative[17]_i_24_n_0\
    );
\derivative[17]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[18]_i_20_n_5\,
      O => \derivative[17]_i_26_n_0\
    );
\derivative[17]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[18]_i_20_n_6\,
      O => \derivative[17]_i_27_n_0\
    );
\derivative[17]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[18]_i_20_n_7\,
      O => \derivative[17]_i_28_n_0\
    );
\derivative[17]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[18]_i_25_n_4\,
      O => \derivative[17]_i_29_n_0\
    );
\derivative[17]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => \derivative_reg[18]_i_1_n_7\,
      O => \derivative[17]_i_3_n_0\
    );
\derivative[17]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[18]_i_25_n_5\,
      O => \derivative[17]_i_31_n_0\
    );
\derivative[17]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[18]_i_25_n_6\,
      O => \derivative[17]_i_32_n_0\
    );
\derivative[17]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[18]_i_25_n_7\,
      O => \derivative[17]_i_33_n_0\
    );
\derivative[17]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[18]_i_30_n_4\,
      O => \derivative[17]_i_34_n_0\
    );
\derivative[17]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[18]_i_30_n_5\,
      O => \derivative[17]_i_36_n_0\
    );
\derivative[17]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[18]_i_30_n_6\,
      O => \derivative[17]_i_37_n_0\
    );
\derivative[17]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[18]_i_30_n_7\,
      O => \derivative[17]_i_38_n_0\
    );
\derivative[17]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[18]_i_35_n_4\,
      O => \derivative[17]_i_39_n_0\
    );
\derivative[17]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[18]_i_2_n_4\,
      O => \derivative[17]_i_4_n_0\
    );
\derivative[17]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[18]_i_35_n_5\,
      O => \derivative[17]_i_40_n_0\
    );
\derivative[17]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[18]_i_35_n_6\,
      O => \derivative[17]_i_41_n_0\
    );
\derivative[17]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(17),
      O => \derivative[17]_i_42_n_0\
    );
\derivative[17]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[18]_i_2_n_5\,
      O => \derivative[17]_i_6_n_0\
    );
\derivative[17]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[18]_i_2_n_6\,
      O => \derivative[17]_i_7_n_0\
    );
\derivative[17]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[18]_i_2_n_7\,
      O => \derivative[17]_i_8_n_0\
    );
\derivative[17]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[18]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[18]_i_5_n_4\,
      O => \derivative[17]_i_9_n_0\
    );
\derivative[18]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[19]_i_5_n_5\,
      O => \derivative[18]_i_11_n_0\
    );
\derivative[18]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[19]_i_5_n_6\,
      O => \derivative[18]_i_12_n_0\
    );
\derivative[18]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[19]_i_5_n_7\,
      O => \derivative[18]_i_13_n_0\
    );
\derivative[18]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[19]_i_10_n_4\,
      O => \derivative[18]_i_14_n_0\
    );
\derivative[18]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[19]_i_10_n_5\,
      O => \derivative[18]_i_16_n_0\
    );
\derivative[18]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[19]_i_10_n_6\,
      O => \derivative[18]_i_17_n_0\
    );
\derivative[18]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[19]_i_10_n_7\,
      O => \derivative[18]_i_18_n_0\
    );
\derivative[18]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[19]_i_15_n_4\,
      O => \derivative[18]_i_19_n_0\
    );
\derivative[18]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[19]_i_15_n_5\,
      O => \derivative[18]_i_21_n_0\
    );
\derivative[18]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[19]_i_15_n_6\,
      O => \derivative[18]_i_22_n_0\
    );
\derivative[18]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[19]_i_15_n_7\,
      O => \derivative[18]_i_23_n_0\
    );
\derivative[18]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[19]_i_20_n_4\,
      O => \derivative[18]_i_24_n_0\
    );
\derivative[18]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[19]_i_20_n_5\,
      O => \derivative[18]_i_26_n_0\
    );
\derivative[18]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[19]_i_20_n_6\,
      O => \derivative[18]_i_27_n_0\
    );
\derivative[18]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[19]_i_20_n_7\,
      O => \derivative[18]_i_28_n_0\
    );
\derivative[18]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[19]_i_25_n_4\,
      O => \derivative[18]_i_29_n_0\
    );
\derivative[18]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => \derivative_reg[19]_i_1_n_7\,
      O => \derivative[18]_i_3_n_0\
    );
\derivative[18]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[19]_i_25_n_5\,
      O => \derivative[18]_i_31_n_0\
    );
\derivative[18]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[19]_i_25_n_6\,
      O => \derivative[18]_i_32_n_0\
    );
\derivative[18]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[19]_i_25_n_7\,
      O => \derivative[18]_i_33_n_0\
    );
\derivative[18]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[19]_i_30_n_4\,
      O => \derivative[18]_i_34_n_0\
    );
\derivative[18]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[19]_i_30_n_5\,
      O => \derivative[18]_i_36_n_0\
    );
\derivative[18]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[19]_i_30_n_6\,
      O => \derivative[18]_i_37_n_0\
    );
\derivative[18]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[19]_i_30_n_7\,
      O => \derivative[18]_i_38_n_0\
    );
\derivative[18]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[19]_i_35_n_4\,
      O => \derivative[18]_i_39_n_0\
    );
\derivative[18]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[19]_i_2_n_4\,
      O => \derivative[18]_i_4_n_0\
    );
\derivative[18]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[19]_i_35_n_5\,
      O => \derivative[18]_i_40_n_0\
    );
\derivative[18]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[19]_i_35_n_6\,
      O => \derivative[18]_i_41_n_0\
    );
\derivative[18]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(18),
      O => \derivative[18]_i_42_n_0\
    );
\derivative[18]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[19]_i_2_n_5\,
      O => \derivative[18]_i_6_n_0\
    );
\derivative[18]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[19]_i_2_n_6\,
      O => \derivative[18]_i_7_n_0\
    );
\derivative[18]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[19]_i_2_n_7\,
      O => \derivative[18]_i_8_n_0\
    );
\derivative[18]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[19]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[19]_i_5_n_4\,
      O => \derivative[18]_i_9_n_0\
    );
\derivative[19]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[20]_i_5_n_5\,
      O => \derivative[19]_i_11_n_0\
    );
\derivative[19]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[20]_i_5_n_6\,
      O => \derivative[19]_i_12_n_0\
    );
\derivative[19]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[20]_i_5_n_7\,
      O => \derivative[19]_i_13_n_0\
    );
\derivative[19]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[20]_i_10_n_4\,
      O => \derivative[19]_i_14_n_0\
    );
\derivative[19]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[20]_i_10_n_5\,
      O => \derivative[19]_i_16_n_0\
    );
\derivative[19]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[20]_i_10_n_6\,
      O => \derivative[19]_i_17_n_0\
    );
\derivative[19]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[20]_i_10_n_7\,
      O => \derivative[19]_i_18_n_0\
    );
\derivative[19]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[20]_i_15_n_4\,
      O => \derivative[19]_i_19_n_0\
    );
\derivative[19]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[20]_i_15_n_5\,
      O => \derivative[19]_i_21_n_0\
    );
\derivative[19]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[20]_i_15_n_6\,
      O => \derivative[19]_i_22_n_0\
    );
\derivative[19]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[20]_i_15_n_7\,
      O => \derivative[19]_i_23_n_0\
    );
\derivative[19]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[20]_i_20_n_4\,
      O => \derivative[19]_i_24_n_0\
    );
\derivative[19]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[20]_i_20_n_5\,
      O => \derivative[19]_i_26_n_0\
    );
\derivative[19]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[20]_i_20_n_6\,
      O => \derivative[19]_i_27_n_0\
    );
\derivative[19]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[20]_i_20_n_7\,
      O => \derivative[19]_i_28_n_0\
    );
\derivative[19]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[20]_i_25_n_4\,
      O => \derivative[19]_i_29_n_0\
    );
\derivative[19]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => \derivative_reg[20]_i_1_n_7\,
      O => \derivative[19]_i_3_n_0\
    );
\derivative[19]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[20]_i_25_n_5\,
      O => \derivative[19]_i_31_n_0\
    );
\derivative[19]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[20]_i_25_n_6\,
      O => \derivative[19]_i_32_n_0\
    );
\derivative[19]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[20]_i_25_n_7\,
      O => \derivative[19]_i_33_n_0\
    );
\derivative[19]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[20]_i_30_n_4\,
      O => \derivative[19]_i_34_n_0\
    );
\derivative[19]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[20]_i_30_n_5\,
      O => \derivative[19]_i_36_n_0\
    );
\derivative[19]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[20]_i_30_n_6\,
      O => \derivative[19]_i_37_n_0\
    );
\derivative[19]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[20]_i_30_n_7\,
      O => \derivative[19]_i_38_n_0\
    );
\derivative[19]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[20]_i_35_n_4\,
      O => \derivative[19]_i_39_n_0\
    );
\derivative[19]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[20]_i_2_n_4\,
      O => \derivative[19]_i_4_n_0\
    );
\derivative[19]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[20]_i_35_n_5\,
      O => \derivative[19]_i_40_n_0\
    );
\derivative[19]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[20]_i_35_n_6\,
      O => \derivative[19]_i_41_n_0\
    );
\derivative[19]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(19),
      O => \derivative[19]_i_42_n_0\
    );
\derivative[19]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[20]_i_2_n_5\,
      O => \derivative[19]_i_6_n_0\
    );
\derivative[19]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[20]_i_2_n_6\,
      O => \derivative[19]_i_7_n_0\
    );
\derivative[19]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[20]_i_2_n_7\,
      O => \derivative[19]_i_8_n_0\
    );
\derivative[19]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[20]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[20]_i_5_n_4\,
      O => \derivative[19]_i_9_n_0\
    );
\derivative[1]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[2]_i_5_n_5\,
      O => \derivative[1]_i_11_n_0\
    );
\derivative[1]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[2]_i_5_n_6\,
      O => \derivative[1]_i_12_n_0\
    );
\derivative[1]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[2]_i_5_n_7\,
      O => \derivative[1]_i_13_n_0\
    );
\derivative[1]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[2]_i_10_n_4\,
      O => \derivative[1]_i_14_n_0\
    );
\derivative[1]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[2]_i_10_n_5\,
      O => \derivative[1]_i_16_n_0\
    );
\derivative[1]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[2]_i_10_n_6\,
      O => \derivative[1]_i_17_n_0\
    );
\derivative[1]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[2]_i_10_n_7\,
      O => \derivative[1]_i_18_n_0\
    );
\derivative[1]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[2]_i_15_n_4\,
      O => \derivative[1]_i_19_n_0\
    );
\derivative[1]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[2]_i_15_n_5\,
      O => \derivative[1]_i_21_n_0\
    );
\derivative[1]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[2]_i_15_n_6\,
      O => \derivative[1]_i_22_n_0\
    );
\derivative[1]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[2]_i_15_n_7\,
      O => \derivative[1]_i_23_n_0\
    );
\derivative[1]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[2]_i_20_n_4\,
      O => \derivative[1]_i_24_n_0\
    );
\derivative[1]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[2]_i_20_n_5\,
      O => \derivative[1]_i_26_n_0\
    );
\derivative[1]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[2]_i_20_n_6\,
      O => \derivative[1]_i_27_n_0\
    );
\derivative[1]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[2]_i_20_n_7\,
      O => \derivative[1]_i_28_n_0\
    );
\derivative[1]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[2]_i_25_n_4\,
      O => \derivative[1]_i_29_n_0\
    );
\derivative[1]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => \derivative_reg[2]_i_1_n_7\,
      O => \derivative[1]_i_3_n_0\
    );
\derivative[1]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[2]_i_25_n_5\,
      O => \derivative[1]_i_31_n_0\
    );
\derivative[1]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[2]_i_25_n_6\,
      O => \derivative[1]_i_32_n_0\
    );
\derivative[1]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[2]_i_25_n_7\,
      O => \derivative[1]_i_33_n_0\
    );
\derivative[1]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[2]_i_30_n_4\,
      O => \derivative[1]_i_34_n_0\
    );
\derivative[1]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[2]_i_30_n_5\,
      O => \derivative[1]_i_36_n_0\
    );
\derivative[1]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[2]_i_30_n_6\,
      O => \derivative[1]_i_37_n_0\
    );
\derivative[1]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[2]_i_30_n_7\,
      O => \derivative[1]_i_38_n_0\
    );
\derivative[1]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[2]_i_35_n_4\,
      O => \derivative[1]_i_39_n_0\
    );
\derivative[1]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[2]_i_2_n_4\,
      O => \derivative[1]_i_4_n_0\
    );
\derivative[1]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[2]_i_35_n_5\,
      O => \derivative[1]_i_40_n_0\
    );
\derivative[1]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[2]_i_35_n_6\,
      O => \derivative[1]_i_41_n_0\
    );
\derivative[1]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(1),
      O => \derivative[1]_i_42_n_0\
    );
\derivative[1]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[2]_i_2_n_5\,
      O => \derivative[1]_i_6_n_0\
    );
\derivative[1]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[2]_i_2_n_6\,
      O => \derivative[1]_i_7_n_0\
    );
\derivative[1]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[2]_i_2_n_7\,
      O => \derivative[1]_i_8_n_0\
    );
\derivative[1]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[2]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[2]_i_5_n_4\,
      O => \derivative[1]_i_9_n_0\
    );
\derivative[20]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[21]_i_5_n_5\,
      O => \derivative[20]_i_11_n_0\
    );
\derivative[20]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[21]_i_5_n_6\,
      O => \derivative[20]_i_12_n_0\
    );
\derivative[20]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[21]_i_5_n_7\,
      O => \derivative[20]_i_13_n_0\
    );
\derivative[20]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[21]_i_10_n_4\,
      O => \derivative[20]_i_14_n_0\
    );
\derivative[20]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[21]_i_10_n_5\,
      O => \derivative[20]_i_16_n_0\
    );
\derivative[20]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[21]_i_10_n_6\,
      O => \derivative[20]_i_17_n_0\
    );
\derivative[20]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[21]_i_10_n_7\,
      O => \derivative[20]_i_18_n_0\
    );
\derivative[20]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[21]_i_15_n_4\,
      O => \derivative[20]_i_19_n_0\
    );
\derivative[20]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[21]_i_15_n_5\,
      O => \derivative[20]_i_21_n_0\
    );
\derivative[20]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[21]_i_15_n_6\,
      O => \derivative[20]_i_22_n_0\
    );
\derivative[20]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[21]_i_15_n_7\,
      O => \derivative[20]_i_23_n_0\
    );
\derivative[20]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[21]_i_20_n_4\,
      O => \derivative[20]_i_24_n_0\
    );
\derivative[20]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[21]_i_20_n_5\,
      O => \derivative[20]_i_26_n_0\
    );
\derivative[20]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[21]_i_20_n_6\,
      O => \derivative[20]_i_27_n_0\
    );
\derivative[20]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[21]_i_20_n_7\,
      O => \derivative[20]_i_28_n_0\
    );
\derivative[20]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[21]_i_25_n_4\,
      O => \derivative[20]_i_29_n_0\
    );
\derivative[20]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => \derivative_reg[21]_i_1_n_7\,
      O => \derivative[20]_i_3_n_0\
    );
\derivative[20]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[21]_i_25_n_5\,
      O => \derivative[20]_i_31_n_0\
    );
\derivative[20]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[21]_i_25_n_6\,
      O => \derivative[20]_i_32_n_0\
    );
\derivative[20]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[21]_i_25_n_7\,
      O => \derivative[20]_i_33_n_0\
    );
\derivative[20]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[21]_i_30_n_4\,
      O => \derivative[20]_i_34_n_0\
    );
\derivative[20]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[21]_i_30_n_5\,
      O => \derivative[20]_i_36_n_0\
    );
\derivative[20]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[21]_i_30_n_6\,
      O => \derivative[20]_i_37_n_0\
    );
\derivative[20]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[21]_i_30_n_7\,
      O => \derivative[20]_i_38_n_0\
    );
\derivative[20]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[21]_i_35_n_4\,
      O => \derivative[20]_i_39_n_0\
    );
\derivative[20]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[21]_i_2_n_4\,
      O => \derivative[20]_i_4_n_0\
    );
\derivative[20]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[21]_i_35_n_5\,
      O => \derivative[20]_i_40_n_0\
    );
\derivative[20]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[21]_i_35_n_6\,
      O => \derivative[20]_i_41_n_0\
    );
\derivative[20]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(20),
      O => \derivative[20]_i_42_n_0\
    );
\derivative[20]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[21]_i_2_n_5\,
      O => \derivative[20]_i_6_n_0\
    );
\derivative[20]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[21]_i_2_n_6\,
      O => \derivative[20]_i_7_n_0\
    );
\derivative[20]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[21]_i_2_n_7\,
      O => \derivative[20]_i_8_n_0\
    );
\derivative[20]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[21]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[21]_i_5_n_4\,
      O => \derivative[20]_i_9_n_0\
    );
\derivative[21]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[22]_i_5_n_5\,
      O => \derivative[21]_i_11_n_0\
    );
\derivative[21]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[22]_i_5_n_6\,
      O => \derivative[21]_i_12_n_0\
    );
\derivative[21]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[22]_i_5_n_7\,
      O => \derivative[21]_i_13_n_0\
    );
\derivative[21]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[22]_i_10_n_4\,
      O => \derivative[21]_i_14_n_0\
    );
\derivative[21]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[22]_i_10_n_5\,
      O => \derivative[21]_i_16_n_0\
    );
\derivative[21]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[22]_i_10_n_6\,
      O => \derivative[21]_i_17_n_0\
    );
\derivative[21]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[22]_i_10_n_7\,
      O => \derivative[21]_i_18_n_0\
    );
\derivative[21]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[22]_i_15_n_4\,
      O => \derivative[21]_i_19_n_0\
    );
\derivative[21]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[22]_i_15_n_5\,
      O => \derivative[21]_i_21_n_0\
    );
\derivative[21]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[22]_i_15_n_6\,
      O => \derivative[21]_i_22_n_0\
    );
\derivative[21]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[22]_i_15_n_7\,
      O => \derivative[21]_i_23_n_0\
    );
\derivative[21]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[22]_i_20_n_4\,
      O => \derivative[21]_i_24_n_0\
    );
\derivative[21]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[22]_i_20_n_5\,
      O => \derivative[21]_i_26_n_0\
    );
\derivative[21]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[22]_i_20_n_6\,
      O => \derivative[21]_i_27_n_0\
    );
\derivative[21]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[22]_i_20_n_7\,
      O => \derivative[21]_i_28_n_0\
    );
\derivative[21]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[22]_i_25_n_4\,
      O => \derivative[21]_i_29_n_0\
    );
\derivative[21]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => \derivative_reg[22]_i_1_n_7\,
      O => \derivative[21]_i_3_n_0\
    );
\derivative[21]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[22]_i_25_n_5\,
      O => \derivative[21]_i_31_n_0\
    );
\derivative[21]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[22]_i_25_n_6\,
      O => \derivative[21]_i_32_n_0\
    );
\derivative[21]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[22]_i_25_n_7\,
      O => \derivative[21]_i_33_n_0\
    );
\derivative[21]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[22]_i_30_n_4\,
      O => \derivative[21]_i_34_n_0\
    );
\derivative[21]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[22]_i_30_n_5\,
      O => \derivative[21]_i_36_n_0\
    );
\derivative[21]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[22]_i_30_n_6\,
      O => \derivative[21]_i_37_n_0\
    );
\derivative[21]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[22]_i_30_n_7\,
      O => \derivative[21]_i_38_n_0\
    );
\derivative[21]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[22]_i_35_n_4\,
      O => \derivative[21]_i_39_n_0\
    );
\derivative[21]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[22]_i_2_n_4\,
      O => \derivative[21]_i_4_n_0\
    );
\derivative[21]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[22]_i_35_n_5\,
      O => \derivative[21]_i_40_n_0\
    );
\derivative[21]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[22]_i_35_n_6\,
      O => \derivative[21]_i_41_n_0\
    );
\derivative[21]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(21),
      O => \derivative[21]_i_42_n_0\
    );
\derivative[21]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[22]_i_2_n_5\,
      O => \derivative[21]_i_6_n_0\
    );
\derivative[21]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[22]_i_2_n_6\,
      O => \derivative[21]_i_7_n_0\
    );
\derivative[21]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[22]_i_2_n_7\,
      O => \derivative[21]_i_8_n_0\
    );
\derivative[21]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[22]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[22]_i_5_n_4\,
      O => \derivative[21]_i_9_n_0\
    );
\derivative[22]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[23]_i_5_n_5\,
      O => \derivative[22]_i_11_n_0\
    );
\derivative[22]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[23]_i_5_n_6\,
      O => \derivative[22]_i_12_n_0\
    );
\derivative[22]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[23]_i_5_n_7\,
      O => \derivative[22]_i_13_n_0\
    );
\derivative[22]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[23]_i_10_n_4\,
      O => \derivative[22]_i_14_n_0\
    );
\derivative[22]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[23]_i_10_n_5\,
      O => \derivative[22]_i_16_n_0\
    );
\derivative[22]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[23]_i_10_n_6\,
      O => \derivative[22]_i_17_n_0\
    );
\derivative[22]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[23]_i_10_n_7\,
      O => \derivative[22]_i_18_n_0\
    );
\derivative[22]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[23]_i_15_n_4\,
      O => \derivative[22]_i_19_n_0\
    );
\derivative[22]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[23]_i_15_n_5\,
      O => \derivative[22]_i_21_n_0\
    );
\derivative[22]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[23]_i_15_n_6\,
      O => \derivative[22]_i_22_n_0\
    );
\derivative[22]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[23]_i_15_n_7\,
      O => \derivative[22]_i_23_n_0\
    );
\derivative[22]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[23]_i_20_n_4\,
      O => \derivative[22]_i_24_n_0\
    );
\derivative[22]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[23]_i_20_n_5\,
      O => \derivative[22]_i_26_n_0\
    );
\derivative[22]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[23]_i_20_n_6\,
      O => \derivative[22]_i_27_n_0\
    );
\derivative[22]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[23]_i_20_n_7\,
      O => \derivative[22]_i_28_n_0\
    );
\derivative[22]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[23]_i_25_n_4\,
      O => \derivative[22]_i_29_n_0\
    );
\derivative[22]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => \derivative_reg[23]_i_1_n_7\,
      O => \derivative[22]_i_3_n_0\
    );
\derivative[22]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[23]_i_25_n_5\,
      O => \derivative[22]_i_31_n_0\
    );
\derivative[22]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[23]_i_25_n_6\,
      O => \derivative[22]_i_32_n_0\
    );
\derivative[22]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[23]_i_25_n_7\,
      O => \derivative[22]_i_33_n_0\
    );
\derivative[22]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[23]_i_30_n_4\,
      O => \derivative[22]_i_34_n_0\
    );
\derivative[22]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[23]_i_30_n_5\,
      O => \derivative[22]_i_36_n_0\
    );
\derivative[22]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[23]_i_30_n_6\,
      O => \derivative[22]_i_37_n_0\
    );
\derivative[22]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[23]_i_30_n_7\,
      O => \derivative[22]_i_38_n_0\
    );
\derivative[22]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[23]_i_35_n_4\,
      O => \derivative[22]_i_39_n_0\
    );
\derivative[22]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[23]_i_2_n_4\,
      O => \derivative[22]_i_4_n_0\
    );
\derivative[22]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[23]_i_35_n_5\,
      O => \derivative[22]_i_40_n_0\
    );
\derivative[22]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[23]_i_35_n_6\,
      O => \derivative[22]_i_41_n_0\
    );
\derivative[22]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(22),
      O => \derivative[22]_i_42_n_0\
    );
\derivative[22]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[23]_i_2_n_5\,
      O => \derivative[22]_i_6_n_0\
    );
\derivative[22]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[23]_i_2_n_6\,
      O => \derivative[22]_i_7_n_0\
    );
\derivative[22]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[23]_i_2_n_7\,
      O => \derivative[22]_i_8_n_0\
    );
\derivative[22]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[23]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[23]_i_5_n_4\,
      O => \derivative[22]_i_9_n_0\
    );
\derivative[23]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[24]_i_5_n_5\,
      O => \derivative[23]_i_11_n_0\
    );
\derivative[23]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[24]_i_5_n_6\,
      O => \derivative[23]_i_12_n_0\
    );
\derivative[23]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[24]_i_5_n_7\,
      O => \derivative[23]_i_13_n_0\
    );
\derivative[23]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[24]_i_10_n_4\,
      O => \derivative[23]_i_14_n_0\
    );
\derivative[23]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[24]_i_10_n_5\,
      O => \derivative[23]_i_16_n_0\
    );
\derivative[23]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[24]_i_10_n_6\,
      O => \derivative[23]_i_17_n_0\
    );
\derivative[23]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[24]_i_10_n_7\,
      O => \derivative[23]_i_18_n_0\
    );
\derivative[23]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[24]_i_15_n_4\,
      O => \derivative[23]_i_19_n_0\
    );
\derivative[23]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[24]_i_15_n_5\,
      O => \derivative[23]_i_21_n_0\
    );
\derivative[23]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[24]_i_15_n_6\,
      O => \derivative[23]_i_22_n_0\
    );
\derivative[23]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[24]_i_15_n_7\,
      O => \derivative[23]_i_23_n_0\
    );
\derivative[23]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[24]_i_20_n_4\,
      O => \derivative[23]_i_24_n_0\
    );
\derivative[23]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[24]_i_20_n_5\,
      O => \derivative[23]_i_26_n_0\
    );
\derivative[23]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[24]_i_20_n_6\,
      O => \derivative[23]_i_27_n_0\
    );
\derivative[23]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[24]_i_20_n_7\,
      O => \derivative[23]_i_28_n_0\
    );
\derivative[23]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[24]_i_25_n_4\,
      O => \derivative[23]_i_29_n_0\
    );
\derivative[23]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => \derivative_reg[24]_i_1_n_7\,
      O => \derivative[23]_i_3_n_0\
    );
\derivative[23]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[24]_i_25_n_5\,
      O => \derivative[23]_i_31_n_0\
    );
\derivative[23]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[24]_i_25_n_6\,
      O => \derivative[23]_i_32_n_0\
    );
\derivative[23]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[24]_i_25_n_7\,
      O => \derivative[23]_i_33_n_0\
    );
\derivative[23]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[24]_i_30_n_4\,
      O => \derivative[23]_i_34_n_0\
    );
\derivative[23]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[24]_i_30_n_5\,
      O => \derivative[23]_i_36_n_0\
    );
\derivative[23]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[24]_i_30_n_6\,
      O => \derivative[23]_i_37_n_0\
    );
\derivative[23]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[24]_i_30_n_7\,
      O => \derivative[23]_i_38_n_0\
    );
\derivative[23]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[24]_i_35_n_4\,
      O => \derivative[23]_i_39_n_0\
    );
\derivative[23]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[24]_i_2_n_4\,
      O => \derivative[23]_i_4_n_0\
    );
\derivative[23]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[24]_i_35_n_5\,
      O => \derivative[23]_i_40_n_0\
    );
\derivative[23]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[24]_i_35_n_6\,
      O => \derivative[23]_i_41_n_0\
    );
\derivative[23]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(23),
      O => \derivative[23]_i_42_n_0\
    );
\derivative[23]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[24]_i_2_n_5\,
      O => \derivative[23]_i_6_n_0\
    );
\derivative[23]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[24]_i_2_n_6\,
      O => \derivative[23]_i_7_n_0\
    );
\derivative[23]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[24]_i_2_n_7\,
      O => \derivative[23]_i_8_n_0\
    );
\derivative[23]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[24]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[24]_i_5_n_4\,
      O => \derivative[23]_i_9_n_0\
    );
\derivative[24]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[25]_i_5_n_5\,
      O => \derivative[24]_i_11_n_0\
    );
\derivative[24]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[25]_i_5_n_6\,
      O => \derivative[24]_i_12_n_0\
    );
\derivative[24]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[25]_i_5_n_7\,
      O => \derivative[24]_i_13_n_0\
    );
\derivative[24]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[25]_i_10_n_4\,
      O => \derivative[24]_i_14_n_0\
    );
\derivative[24]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[25]_i_10_n_5\,
      O => \derivative[24]_i_16_n_0\
    );
\derivative[24]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[25]_i_10_n_6\,
      O => \derivative[24]_i_17_n_0\
    );
\derivative[24]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[25]_i_10_n_7\,
      O => \derivative[24]_i_18_n_0\
    );
\derivative[24]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[25]_i_15_n_4\,
      O => \derivative[24]_i_19_n_0\
    );
\derivative[24]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[25]_i_15_n_5\,
      O => \derivative[24]_i_21_n_0\
    );
\derivative[24]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[25]_i_15_n_6\,
      O => \derivative[24]_i_22_n_0\
    );
\derivative[24]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[25]_i_15_n_7\,
      O => \derivative[24]_i_23_n_0\
    );
\derivative[24]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[25]_i_20_n_4\,
      O => \derivative[24]_i_24_n_0\
    );
\derivative[24]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[25]_i_20_n_5\,
      O => \derivative[24]_i_26_n_0\
    );
\derivative[24]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[25]_i_20_n_6\,
      O => \derivative[24]_i_27_n_0\
    );
\derivative[24]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[25]_i_20_n_7\,
      O => \derivative[24]_i_28_n_0\
    );
\derivative[24]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[25]_i_25_n_4\,
      O => \derivative[24]_i_29_n_0\
    );
\derivative[24]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => \derivative_reg[25]_i_1_n_7\,
      O => \derivative[24]_i_3_n_0\
    );
\derivative[24]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[25]_i_25_n_5\,
      O => \derivative[24]_i_31_n_0\
    );
\derivative[24]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[25]_i_25_n_6\,
      O => \derivative[24]_i_32_n_0\
    );
\derivative[24]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[25]_i_25_n_7\,
      O => \derivative[24]_i_33_n_0\
    );
\derivative[24]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[25]_i_30_n_4\,
      O => \derivative[24]_i_34_n_0\
    );
\derivative[24]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[25]_i_30_n_5\,
      O => \derivative[24]_i_36_n_0\
    );
\derivative[24]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[25]_i_30_n_6\,
      O => \derivative[24]_i_37_n_0\
    );
\derivative[24]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[25]_i_30_n_7\,
      O => \derivative[24]_i_38_n_0\
    );
\derivative[24]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[25]_i_35_n_4\,
      O => \derivative[24]_i_39_n_0\
    );
\derivative[24]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[25]_i_2_n_4\,
      O => \derivative[24]_i_4_n_0\
    );
\derivative[24]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[25]_i_35_n_5\,
      O => \derivative[24]_i_40_n_0\
    );
\derivative[24]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[25]_i_35_n_6\,
      O => \derivative[24]_i_41_n_0\
    );
\derivative[24]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(24),
      O => \derivative[24]_i_42_n_0\
    );
\derivative[24]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[25]_i_2_n_5\,
      O => \derivative[24]_i_6_n_0\
    );
\derivative[24]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[25]_i_2_n_6\,
      O => \derivative[24]_i_7_n_0\
    );
\derivative[24]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[25]_i_2_n_7\,
      O => \derivative[24]_i_8_n_0\
    );
\derivative[24]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[25]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[25]_i_5_n_4\,
      O => \derivative[24]_i_9_n_0\
    );
\derivative[25]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[26]_i_5_n_5\,
      O => \derivative[25]_i_11_n_0\
    );
\derivative[25]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[26]_i_5_n_6\,
      O => \derivative[25]_i_12_n_0\
    );
\derivative[25]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[26]_i_5_n_7\,
      O => \derivative[25]_i_13_n_0\
    );
\derivative[25]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[26]_i_10_n_4\,
      O => \derivative[25]_i_14_n_0\
    );
\derivative[25]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[26]_i_10_n_5\,
      O => \derivative[25]_i_16_n_0\
    );
\derivative[25]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[26]_i_10_n_6\,
      O => \derivative[25]_i_17_n_0\
    );
\derivative[25]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[26]_i_10_n_7\,
      O => \derivative[25]_i_18_n_0\
    );
\derivative[25]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[26]_i_15_n_4\,
      O => \derivative[25]_i_19_n_0\
    );
\derivative[25]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[26]_i_15_n_5\,
      O => \derivative[25]_i_21_n_0\
    );
\derivative[25]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[26]_i_15_n_6\,
      O => \derivative[25]_i_22_n_0\
    );
\derivative[25]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[26]_i_15_n_7\,
      O => \derivative[25]_i_23_n_0\
    );
\derivative[25]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[26]_i_20_n_4\,
      O => \derivative[25]_i_24_n_0\
    );
\derivative[25]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[26]_i_20_n_5\,
      O => \derivative[25]_i_26_n_0\
    );
\derivative[25]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[26]_i_20_n_6\,
      O => \derivative[25]_i_27_n_0\
    );
\derivative[25]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[26]_i_20_n_7\,
      O => \derivative[25]_i_28_n_0\
    );
\derivative[25]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[26]_i_25_n_4\,
      O => \derivative[25]_i_29_n_0\
    );
\derivative[25]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => \derivative_reg[26]_i_1_n_7\,
      O => \derivative[25]_i_3_n_0\
    );
\derivative[25]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[26]_i_25_n_5\,
      O => \derivative[25]_i_31_n_0\
    );
\derivative[25]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[26]_i_25_n_6\,
      O => \derivative[25]_i_32_n_0\
    );
\derivative[25]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[26]_i_25_n_7\,
      O => \derivative[25]_i_33_n_0\
    );
\derivative[25]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[26]_i_30_n_4\,
      O => \derivative[25]_i_34_n_0\
    );
\derivative[25]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[26]_i_30_n_5\,
      O => \derivative[25]_i_36_n_0\
    );
\derivative[25]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[26]_i_30_n_6\,
      O => \derivative[25]_i_37_n_0\
    );
\derivative[25]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[26]_i_30_n_7\,
      O => \derivative[25]_i_38_n_0\
    );
\derivative[25]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[26]_i_35_n_4\,
      O => \derivative[25]_i_39_n_0\
    );
\derivative[25]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[26]_i_2_n_4\,
      O => \derivative[25]_i_4_n_0\
    );
\derivative[25]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[26]_i_35_n_5\,
      O => \derivative[25]_i_40_n_0\
    );
\derivative[25]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[26]_i_35_n_6\,
      O => \derivative[25]_i_41_n_0\
    );
\derivative[25]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(25),
      O => \derivative[25]_i_42_n_0\
    );
\derivative[25]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[26]_i_2_n_5\,
      O => \derivative[25]_i_6_n_0\
    );
\derivative[25]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[26]_i_2_n_6\,
      O => \derivative[25]_i_7_n_0\
    );
\derivative[25]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[26]_i_2_n_7\,
      O => \derivative[25]_i_8_n_0\
    );
\derivative[25]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[26]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[26]_i_5_n_4\,
      O => \derivative[25]_i_9_n_0\
    );
\derivative[26]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[27]_i_5_n_5\,
      O => \derivative[26]_i_11_n_0\
    );
\derivative[26]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[27]_i_5_n_6\,
      O => \derivative[26]_i_12_n_0\
    );
\derivative[26]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[27]_i_5_n_7\,
      O => \derivative[26]_i_13_n_0\
    );
\derivative[26]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[27]_i_10_n_4\,
      O => \derivative[26]_i_14_n_0\
    );
\derivative[26]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[27]_i_10_n_5\,
      O => \derivative[26]_i_16_n_0\
    );
\derivative[26]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[27]_i_10_n_6\,
      O => \derivative[26]_i_17_n_0\
    );
\derivative[26]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[27]_i_10_n_7\,
      O => \derivative[26]_i_18_n_0\
    );
\derivative[26]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[27]_i_15_n_4\,
      O => \derivative[26]_i_19_n_0\
    );
\derivative[26]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[27]_i_15_n_5\,
      O => \derivative[26]_i_21_n_0\
    );
\derivative[26]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[27]_i_15_n_6\,
      O => \derivative[26]_i_22_n_0\
    );
\derivative[26]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[27]_i_15_n_7\,
      O => \derivative[26]_i_23_n_0\
    );
\derivative[26]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[27]_i_20_n_4\,
      O => \derivative[26]_i_24_n_0\
    );
\derivative[26]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[27]_i_20_n_5\,
      O => \derivative[26]_i_26_n_0\
    );
\derivative[26]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[27]_i_20_n_6\,
      O => \derivative[26]_i_27_n_0\
    );
\derivative[26]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[27]_i_20_n_7\,
      O => \derivative[26]_i_28_n_0\
    );
\derivative[26]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[27]_i_25_n_4\,
      O => \derivative[26]_i_29_n_0\
    );
\derivative[26]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => \derivative_reg[27]_i_1_n_7\,
      O => \derivative[26]_i_3_n_0\
    );
\derivative[26]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[27]_i_25_n_5\,
      O => \derivative[26]_i_31_n_0\
    );
\derivative[26]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[27]_i_25_n_6\,
      O => \derivative[26]_i_32_n_0\
    );
\derivative[26]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[27]_i_25_n_7\,
      O => \derivative[26]_i_33_n_0\
    );
\derivative[26]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[27]_i_30_n_4\,
      O => \derivative[26]_i_34_n_0\
    );
\derivative[26]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[27]_i_30_n_5\,
      O => \derivative[26]_i_36_n_0\
    );
\derivative[26]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[27]_i_30_n_6\,
      O => \derivative[26]_i_37_n_0\
    );
\derivative[26]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[27]_i_30_n_7\,
      O => \derivative[26]_i_38_n_0\
    );
\derivative[26]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[27]_i_35_n_4\,
      O => \derivative[26]_i_39_n_0\
    );
\derivative[26]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[27]_i_2_n_4\,
      O => \derivative[26]_i_4_n_0\
    );
\derivative[26]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[27]_i_35_n_5\,
      O => \derivative[26]_i_40_n_0\
    );
\derivative[26]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[27]_i_35_n_6\,
      O => \derivative[26]_i_41_n_0\
    );
\derivative[26]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(26),
      O => \derivative[26]_i_42_n_0\
    );
\derivative[26]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[27]_i_2_n_5\,
      O => \derivative[26]_i_6_n_0\
    );
\derivative[26]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[27]_i_2_n_6\,
      O => \derivative[26]_i_7_n_0\
    );
\derivative[26]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[27]_i_2_n_7\,
      O => \derivative[26]_i_8_n_0\
    );
\derivative[26]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[27]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[27]_i_5_n_4\,
      O => \derivative[26]_i_9_n_0\
    );
\derivative[27]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[28]_i_5_n_5\,
      O => \derivative[27]_i_11_n_0\
    );
\derivative[27]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[28]_i_5_n_6\,
      O => \derivative[27]_i_12_n_0\
    );
\derivative[27]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[28]_i_5_n_7\,
      O => \derivative[27]_i_13_n_0\
    );
\derivative[27]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[28]_i_10_n_4\,
      O => \derivative[27]_i_14_n_0\
    );
\derivative[27]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[28]_i_10_n_5\,
      O => \derivative[27]_i_16_n_0\
    );
\derivative[27]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[28]_i_10_n_6\,
      O => \derivative[27]_i_17_n_0\
    );
\derivative[27]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[28]_i_10_n_7\,
      O => \derivative[27]_i_18_n_0\
    );
\derivative[27]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[28]_i_15_n_4\,
      O => \derivative[27]_i_19_n_0\
    );
\derivative[27]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[28]_i_15_n_5\,
      O => \derivative[27]_i_21_n_0\
    );
\derivative[27]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[28]_i_15_n_6\,
      O => \derivative[27]_i_22_n_0\
    );
\derivative[27]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[28]_i_15_n_7\,
      O => \derivative[27]_i_23_n_0\
    );
\derivative[27]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[28]_i_20_n_4\,
      O => \derivative[27]_i_24_n_0\
    );
\derivative[27]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[28]_i_20_n_5\,
      O => \derivative[27]_i_26_n_0\
    );
\derivative[27]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[28]_i_20_n_6\,
      O => \derivative[27]_i_27_n_0\
    );
\derivative[27]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[28]_i_20_n_7\,
      O => \derivative[27]_i_28_n_0\
    );
\derivative[27]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[28]_i_25_n_4\,
      O => \derivative[27]_i_29_n_0\
    );
\derivative[27]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => \derivative_reg[28]_i_1_n_7\,
      O => \derivative[27]_i_3_n_0\
    );
\derivative[27]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[28]_i_25_n_5\,
      O => \derivative[27]_i_31_n_0\
    );
\derivative[27]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[28]_i_25_n_6\,
      O => \derivative[27]_i_32_n_0\
    );
\derivative[27]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[28]_i_25_n_7\,
      O => \derivative[27]_i_33_n_0\
    );
\derivative[27]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[28]_i_30_n_4\,
      O => \derivative[27]_i_34_n_0\
    );
\derivative[27]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[28]_i_30_n_5\,
      O => \derivative[27]_i_36_n_0\
    );
\derivative[27]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[28]_i_30_n_6\,
      O => \derivative[27]_i_37_n_0\
    );
\derivative[27]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[28]_i_30_n_7\,
      O => \derivative[27]_i_38_n_0\
    );
\derivative[27]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[28]_i_35_n_4\,
      O => \derivative[27]_i_39_n_0\
    );
\derivative[27]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[28]_i_2_n_4\,
      O => \derivative[27]_i_4_n_0\
    );
\derivative[27]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[28]_i_35_n_5\,
      O => \derivative[27]_i_40_n_0\
    );
\derivative[27]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[28]_i_35_n_6\,
      O => \derivative[27]_i_41_n_0\
    );
\derivative[27]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(27),
      O => \derivative[27]_i_42_n_0\
    );
\derivative[27]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[28]_i_2_n_5\,
      O => \derivative[27]_i_6_n_0\
    );
\derivative[27]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[28]_i_2_n_6\,
      O => \derivative[27]_i_7_n_0\
    );
\derivative[27]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[28]_i_2_n_7\,
      O => \derivative[27]_i_8_n_0\
    );
\derivative[27]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[28]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[28]_i_5_n_4\,
      O => \derivative[27]_i_9_n_0\
    );
\derivative[28]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[29]_i_5_n_5\,
      O => \derivative[28]_i_11_n_0\
    );
\derivative[28]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[29]_i_5_n_6\,
      O => \derivative[28]_i_12_n_0\
    );
\derivative[28]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[29]_i_5_n_7\,
      O => \derivative[28]_i_13_n_0\
    );
\derivative[28]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[29]_i_10_n_4\,
      O => \derivative[28]_i_14_n_0\
    );
\derivative[28]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[29]_i_10_n_5\,
      O => \derivative[28]_i_16_n_0\
    );
\derivative[28]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[29]_i_10_n_6\,
      O => \derivative[28]_i_17_n_0\
    );
\derivative[28]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[29]_i_10_n_7\,
      O => \derivative[28]_i_18_n_0\
    );
\derivative[28]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[29]_i_15_n_4\,
      O => \derivative[28]_i_19_n_0\
    );
\derivative[28]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[29]_i_15_n_5\,
      O => \derivative[28]_i_21_n_0\
    );
\derivative[28]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[29]_i_15_n_6\,
      O => \derivative[28]_i_22_n_0\
    );
\derivative[28]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[29]_i_15_n_7\,
      O => \derivative[28]_i_23_n_0\
    );
\derivative[28]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[29]_i_20_n_4\,
      O => \derivative[28]_i_24_n_0\
    );
\derivative[28]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[29]_i_20_n_5\,
      O => \derivative[28]_i_26_n_0\
    );
\derivative[28]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[29]_i_20_n_6\,
      O => \derivative[28]_i_27_n_0\
    );
\derivative[28]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[29]_i_20_n_7\,
      O => \derivative[28]_i_28_n_0\
    );
\derivative[28]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[29]_i_25_n_4\,
      O => \derivative[28]_i_29_n_0\
    );
\derivative[28]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => \derivative_reg[29]_i_1_n_7\,
      O => \derivative[28]_i_3_n_0\
    );
\derivative[28]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[29]_i_25_n_5\,
      O => \derivative[28]_i_31_n_0\
    );
\derivative[28]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[29]_i_25_n_6\,
      O => \derivative[28]_i_32_n_0\
    );
\derivative[28]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[29]_i_25_n_7\,
      O => \derivative[28]_i_33_n_0\
    );
\derivative[28]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[29]_i_30_n_4\,
      O => \derivative[28]_i_34_n_0\
    );
\derivative[28]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[29]_i_30_n_5\,
      O => \derivative[28]_i_36_n_0\
    );
\derivative[28]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[29]_i_30_n_6\,
      O => \derivative[28]_i_37_n_0\
    );
\derivative[28]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[29]_i_30_n_7\,
      O => \derivative[28]_i_38_n_0\
    );
\derivative[28]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[29]_i_35_n_4\,
      O => \derivative[28]_i_39_n_0\
    );
\derivative[28]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[29]_i_2_n_4\,
      O => \derivative[28]_i_4_n_0\
    );
\derivative[28]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[29]_i_35_n_5\,
      O => \derivative[28]_i_40_n_0\
    );
\derivative[28]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[29]_i_35_n_6\,
      O => \derivative[28]_i_41_n_0\
    );
\derivative[28]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(28),
      O => \derivative[28]_i_42_n_0\
    );
\derivative[28]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[29]_i_2_n_5\,
      O => \derivative[28]_i_6_n_0\
    );
\derivative[28]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[29]_i_2_n_6\,
      O => \derivative[28]_i_7_n_0\
    );
\derivative[28]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[29]_i_2_n_7\,
      O => \derivative[28]_i_8_n_0\
    );
\derivative[28]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[29]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[29]_i_5_n_4\,
      O => \derivative[28]_i_9_n_0\
    );
\derivative[29]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[30]_i_5_n_5\,
      O => \derivative[29]_i_11_n_0\
    );
\derivative[29]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[30]_i_5_n_6\,
      O => \derivative[29]_i_12_n_0\
    );
\derivative[29]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[30]_i_5_n_7\,
      O => \derivative[29]_i_13_n_0\
    );
\derivative[29]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[30]_i_10_n_4\,
      O => \derivative[29]_i_14_n_0\
    );
\derivative[29]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[30]_i_10_n_5\,
      O => \derivative[29]_i_16_n_0\
    );
\derivative[29]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[30]_i_10_n_6\,
      O => \derivative[29]_i_17_n_0\
    );
\derivative[29]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[30]_i_10_n_7\,
      O => \derivative[29]_i_18_n_0\
    );
\derivative[29]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[30]_i_15_n_4\,
      O => \derivative[29]_i_19_n_0\
    );
\derivative[29]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[30]_i_15_n_5\,
      O => \derivative[29]_i_21_n_0\
    );
\derivative[29]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[30]_i_15_n_6\,
      O => \derivative[29]_i_22_n_0\
    );
\derivative[29]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[30]_i_15_n_7\,
      O => \derivative[29]_i_23_n_0\
    );
\derivative[29]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[30]_i_20_n_4\,
      O => \derivative[29]_i_24_n_0\
    );
\derivative[29]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[30]_i_20_n_5\,
      O => \derivative[29]_i_26_n_0\
    );
\derivative[29]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[30]_i_20_n_6\,
      O => \derivative[29]_i_27_n_0\
    );
\derivative[29]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[30]_i_20_n_7\,
      O => \derivative[29]_i_28_n_0\
    );
\derivative[29]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[30]_i_25_n_4\,
      O => \derivative[29]_i_29_n_0\
    );
\derivative[29]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => \derivative_reg[30]_i_1_n_7\,
      O => \derivative[29]_i_3_n_0\
    );
\derivative[29]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[30]_i_25_n_5\,
      O => \derivative[29]_i_31_n_0\
    );
\derivative[29]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[30]_i_25_n_6\,
      O => \derivative[29]_i_32_n_0\
    );
\derivative[29]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[30]_i_25_n_7\,
      O => \derivative[29]_i_33_n_0\
    );
\derivative[29]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[30]_i_30_n_4\,
      O => \derivative[29]_i_34_n_0\
    );
\derivative[29]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[30]_i_30_n_5\,
      O => \derivative[29]_i_36_n_0\
    );
\derivative[29]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[30]_i_30_n_6\,
      O => \derivative[29]_i_37_n_0\
    );
\derivative[29]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[30]_i_30_n_7\,
      O => \derivative[29]_i_38_n_0\
    );
\derivative[29]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[30]_i_35_n_4\,
      O => \derivative[29]_i_39_n_0\
    );
\derivative[29]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[30]_i_2_n_4\,
      O => \derivative[29]_i_4_n_0\
    );
\derivative[29]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[30]_i_35_n_5\,
      O => \derivative[29]_i_40_n_0\
    );
\derivative[29]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[30]_i_35_n_6\,
      O => \derivative[29]_i_41_n_0\
    );
\derivative[29]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(29),
      O => \derivative[29]_i_42_n_0\
    );
\derivative[29]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[30]_i_2_n_5\,
      O => \derivative[29]_i_6_n_0\
    );
\derivative[29]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[30]_i_2_n_6\,
      O => \derivative[29]_i_7_n_0\
    );
\derivative[29]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[30]_i_2_n_7\,
      O => \derivative[29]_i_8_n_0\
    );
\derivative[29]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[30]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[30]_i_5_n_4\,
      O => \derivative[29]_i_9_n_0\
    );
\derivative[2]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[3]_i_5_n_5\,
      O => \derivative[2]_i_11_n_0\
    );
\derivative[2]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[3]_i_5_n_6\,
      O => \derivative[2]_i_12_n_0\
    );
\derivative[2]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[3]_i_5_n_7\,
      O => \derivative[2]_i_13_n_0\
    );
\derivative[2]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[3]_i_10_n_4\,
      O => \derivative[2]_i_14_n_0\
    );
\derivative[2]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[3]_i_10_n_5\,
      O => \derivative[2]_i_16_n_0\
    );
\derivative[2]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[3]_i_10_n_6\,
      O => \derivative[2]_i_17_n_0\
    );
\derivative[2]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[3]_i_10_n_7\,
      O => \derivative[2]_i_18_n_0\
    );
\derivative[2]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[3]_i_15_n_4\,
      O => \derivative[2]_i_19_n_0\
    );
\derivative[2]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[3]_i_15_n_5\,
      O => \derivative[2]_i_21_n_0\
    );
\derivative[2]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[3]_i_15_n_6\,
      O => \derivative[2]_i_22_n_0\
    );
\derivative[2]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[3]_i_15_n_7\,
      O => \derivative[2]_i_23_n_0\
    );
\derivative[2]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[3]_i_20_n_4\,
      O => \derivative[2]_i_24_n_0\
    );
\derivative[2]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[3]_i_20_n_5\,
      O => \derivative[2]_i_26_n_0\
    );
\derivative[2]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[3]_i_20_n_6\,
      O => \derivative[2]_i_27_n_0\
    );
\derivative[2]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[3]_i_20_n_7\,
      O => \derivative[2]_i_28_n_0\
    );
\derivative[2]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[3]_i_25_n_4\,
      O => \derivative[2]_i_29_n_0\
    );
\derivative[2]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => \derivative_reg[3]_i_1_n_7\,
      O => \derivative[2]_i_3_n_0\
    );
\derivative[2]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[3]_i_25_n_5\,
      O => \derivative[2]_i_31_n_0\
    );
\derivative[2]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[3]_i_25_n_6\,
      O => \derivative[2]_i_32_n_0\
    );
\derivative[2]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[3]_i_25_n_7\,
      O => \derivative[2]_i_33_n_0\
    );
\derivative[2]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[3]_i_30_n_4\,
      O => \derivative[2]_i_34_n_0\
    );
\derivative[2]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[3]_i_30_n_5\,
      O => \derivative[2]_i_36_n_0\
    );
\derivative[2]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[3]_i_30_n_6\,
      O => \derivative[2]_i_37_n_0\
    );
\derivative[2]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[3]_i_30_n_7\,
      O => \derivative[2]_i_38_n_0\
    );
\derivative[2]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[3]_i_35_n_4\,
      O => \derivative[2]_i_39_n_0\
    );
\derivative[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[3]_i_2_n_4\,
      O => \derivative[2]_i_4_n_0\
    );
\derivative[2]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[3]_i_35_n_5\,
      O => \derivative[2]_i_40_n_0\
    );
\derivative[2]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[3]_i_35_n_6\,
      O => \derivative[2]_i_41_n_0\
    );
\derivative[2]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(2),
      O => \derivative[2]_i_42_n_0\
    );
\derivative[2]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[3]_i_2_n_5\,
      O => \derivative[2]_i_6_n_0\
    );
\derivative[2]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[3]_i_2_n_6\,
      O => \derivative[2]_i_7_n_0\
    );
\derivative[2]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[3]_i_2_n_7\,
      O => \derivative[2]_i_8_n_0\
    );
\derivative[2]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[3]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[3]_i_5_n_4\,
      O => \derivative[2]_i_9_n_0\
    );
\derivative[30]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(26),
      I2 => \derivative_reg[31]_i_3_n_6\,
      O => \derivative[30]_i_11_n_0\
    );
\derivative[30]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(25),
      I2 => \derivative_reg[31]_i_3_n_7\,
      O => \derivative[30]_i_12_n_0\
    );
\derivative[30]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(24),
      I2 => \derivative_reg[31]_i_12_n_4\,
      O => \derivative[30]_i_13_n_0\
    );
\derivative[30]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(23),
      I2 => \derivative_reg[31]_i_12_n_5\,
      O => \derivative[30]_i_14_n_0\
    );
\derivative[30]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(22),
      I2 => \derivative_reg[31]_i_12_n_6\,
      O => \derivative[30]_i_16_n_0\
    );
\derivative[30]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(21),
      I2 => \derivative_reg[31]_i_12_n_7\,
      O => \derivative[30]_i_17_n_0\
    );
\derivative[30]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(20),
      I2 => \derivative_reg[31]_i_21_n_4\,
      O => \derivative[30]_i_18_n_0\
    );
\derivative[30]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(19),
      I2 => \derivative_reg[31]_i_21_n_5\,
      O => \derivative[30]_i_19_n_0\
    );
\derivative[30]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(18),
      I2 => \derivative_reg[31]_i_21_n_6\,
      O => \derivative[30]_i_21_n_0\
    );
\derivative[30]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(17),
      I2 => \derivative_reg[31]_i_21_n_7\,
      O => \derivative[30]_i_22_n_0\
    );
\derivative[30]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(16),
      I2 => \derivative_reg[31]_i_30_n_4\,
      O => \derivative[30]_i_23_n_0\
    );
\derivative[30]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(15),
      I2 => \derivative_reg[31]_i_30_n_5\,
      O => \derivative[30]_i_24_n_0\
    );
\derivative[30]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(14),
      I2 => \derivative_reg[31]_i_30_n_6\,
      O => \derivative[30]_i_26_n_0\
    );
\derivative[30]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(13),
      I2 => \derivative_reg[31]_i_30_n_7\,
      O => \derivative[30]_i_27_n_0\
    );
\derivative[30]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(12),
      I2 => \derivative_reg[31]_i_39_n_4\,
      O => \derivative[30]_i_28_n_0\
    );
\derivative[30]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(11),
      I2 => \derivative_reg[31]_i_39_n_5\,
      O => \derivative[30]_i_29_n_0\
    );
\derivative[30]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => \derivative_reg[31]_i_2_n_4\,
      O => \derivative[30]_i_3_n_0\
    );
\derivative[30]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(10),
      I2 => \derivative_reg[31]_i_39_n_6\,
      O => \derivative[30]_i_31_n_0\
    );
\derivative[30]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(9),
      I2 => \derivative_reg[31]_i_39_n_7\,
      O => \derivative[30]_i_32_n_0\
    );
\derivative[30]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(8),
      I2 => \derivative_reg[31]_i_48_n_4\,
      O => \derivative[30]_i_33_n_0\
    );
\derivative[30]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(7),
      I2 => \derivative_reg[31]_i_48_n_5\,
      O => \derivative[30]_i_34_n_0\
    );
\derivative[30]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(6),
      I2 => \derivative_reg[31]_i_48_n_6\,
      O => \derivative[30]_i_36_n_0\
    );
\derivative[30]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(5),
      I2 => \derivative_reg[31]_i_48_n_7\,
      O => \derivative[30]_i_37_n_0\
    );
\derivative[30]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(4),
      I2 => \derivative_reg[31]_i_57_n_4\,
      O => \derivative[30]_i_38_n_0\
    );
\derivative[30]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(3),
      I2 => \derivative_reg[31]_i_57_n_5\,
      O => \derivative[30]_i_39_n_0\
    );
\derivative[30]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(31),
      I2 => \derivative_reg[31]_i_2_n_5\,
      O => \derivative[30]_i_4_n_0\
    );
\derivative[30]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(2),
      I2 => \derivative_reg[31]_i_57_n_6\,
      O => \derivative[30]_i_40_n_0\
    );
\derivative[30]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(1),
      I2 => \derivative_reg[31]_i_57_n_7\,
      O => \derivative[30]_i_41_n_0\
    );
\derivative[30]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(0),
      I2 => derivative11_out(30),
      O => \derivative[30]_i_42_n_0\
    );
\derivative[30]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(30),
      I2 => \derivative_reg[31]_i_2_n_6\,
      O => \derivative[30]_i_6_n_0\
    );
\derivative[30]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(29),
      I2 => \derivative_reg[31]_i_2_n_7\,
      O => \derivative[30]_i_7_n_0\
    );
\derivative[30]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(28),
      I2 => \derivative_reg[31]_i_3_n_4\,
      O => \derivative[30]_i_8_n_0\
    );
\derivative[30]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[31]_i_1_n_3\,
      I1 => dt(27),
      I2 => \derivative_reg[31]_i_3_n_5\,
      O => \derivative[30]_i_9_n_0\
    );
\derivative[31]_i_10\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(29),
      O => \derivative[31]_i_10_n_0\
    );
\derivative[31]_i_11\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(28),
      O => \derivative[31]_i_11_n_0\
    );
\derivative[31]_i_13\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(27),
      O => \derivative[31]_i_13_n_0\
    );
\derivative[31]_i_14\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(26),
      O => \derivative[31]_i_14_n_0\
    );
\derivative[31]_i_15\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(25),
      O => \derivative[31]_i_15_n_0\
    );
\derivative[31]_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(24),
      O => \derivative[31]_i_16_n_0\
    );
\derivative[31]_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(27),
      O => \derivative[31]_i_17_n_0\
    );
\derivative[31]_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(26),
      O => \derivative[31]_i_18_n_0\
    );
\derivative[31]_i_19\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(25),
      O => \derivative[31]_i_19_n_0\
    );
\derivative[31]_i_20\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(24),
      O => \derivative[31]_i_20_n_0\
    );
\derivative[31]_i_22\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(23),
      O => \derivative[31]_i_22_n_0\
    );
\derivative[31]_i_23\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(22),
      O => \derivative[31]_i_23_n_0\
    );
\derivative[31]_i_24\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(21),
      O => \derivative[31]_i_24_n_0\
    );
\derivative[31]_i_25\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(20),
      O => \derivative[31]_i_25_n_0\
    );
\derivative[31]_i_26\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(23),
      O => \derivative[31]_i_26_n_0\
    );
\derivative[31]_i_27\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(22),
      O => \derivative[31]_i_27_n_0\
    );
\derivative[31]_i_28\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(21),
      O => \derivative[31]_i_28_n_0\
    );
\derivative[31]_i_29\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(20),
      O => \derivative[31]_i_29_n_0\
    );
\derivative[31]_i_31\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(19),
      O => \derivative[31]_i_31_n_0\
    );
\derivative[31]_i_32\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(18),
      O => \derivative[31]_i_32_n_0\
    );
\derivative[31]_i_33\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(17),
      O => \derivative[31]_i_33_n_0\
    );
\derivative[31]_i_34\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(16),
      O => \derivative[31]_i_34_n_0\
    );
\derivative[31]_i_35\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(19),
      O => \derivative[31]_i_35_n_0\
    );
\derivative[31]_i_36\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(18),
      O => \derivative[31]_i_36_n_0\
    );
\derivative[31]_i_37\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(17),
      O => \derivative[31]_i_37_n_0\
    );
\derivative[31]_i_38\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(16),
      O => \derivative[31]_i_38_n_0\
    );
\derivative[31]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(31),
      O => \derivative[31]_i_4_n_0\
    );
\derivative[31]_i_40\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(15),
      O => \derivative[31]_i_40_n_0\
    );
\derivative[31]_i_41\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(14),
      O => \derivative[31]_i_41_n_0\
    );
\derivative[31]_i_42\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(13),
      O => \derivative[31]_i_42_n_0\
    );
\derivative[31]_i_43\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(12),
      O => \derivative[31]_i_43_n_0\
    );
\derivative[31]_i_44\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(15),
      O => \derivative[31]_i_44_n_0\
    );
\derivative[31]_i_45\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(14),
      O => \derivative[31]_i_45_n_0\
    );
\derivative[31]_i_46\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(13),
      O => \derivative[31]_i_46_n_0\
    );
\derivative[31]_i_47\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(12),
      O => \derivative[31]_i_47_n_0\
    );
\derivative[31]_i_49\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(11),
      O => \derivative[31]_i_49_n_0\
    );
\derivative[31]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(30),
      O => \derivative[31]_i_5_n_0\
    );
\derivative[31]_i_50\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(10),
      O => \derivative[31]_i_50_n_0\
    );
\derivative[31]_i_51\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(9),
      O => \derivative[31]_i_51_n_0\
    );
\derivative[31]_i_52\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(8),
      O => \derivative[31]_i_52_n_0\
    );
\derivative[31]_i_53\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(11),
      O => \derivative[31]_i_53_n_0\
    );
\derivative[31]_i_54\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(10),
      O => \derivative[31]_i_54_n_0\
    );
\derivative[31]_i_55\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(9),
      O => \derivative[31]_i_55_n_0\
    );
\derivative[31]_i_56\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(8),
      O => \derivative[31]_i_56_n_0\
    );
\derivative[31]_i_58\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(7),
      O => \derivative[31]_i_58_n_0\
    );
\derivative[31]_i_59\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(6),
      O => \derivative[31]_i_59_n_0\
    );
\derivative[31]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(29),
      O => \derivative[31]_i_6_n_0\
    );
\derivative[31]_i_60\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(5),
      O => \derivative[31]_i_60_n_0\
    );
\derivative[31]_i_61\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(4),
      O => \derivative[31]_i_61_n_0\
    );
\derivative[31]_i_62\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(7),
      O => \derivative[31]_i_62_n_0\
    );
\derivative[31]_i_63\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(6),
      O => \derivative[31]_i_63_n_0\
    );
\derivative[31]_i_64\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(5),
      O => \derivative[31]_i_64_n_0\
    );
\derivative[31]_i_65\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(4),
      O => \derivative[31]_i_65_n_0\
    );
\derivative[31]_i_66\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(3),
      O => \derivative[31]_i_66_n_0\
    );
\derivative[31]_i_67\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(2),
      O => \derivative[31]_i_67_n_0\
    );
\derivative[31]_i_68\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(1),
      O => \derivative[31]_i_68_n_0\
    );
\derivative[31]_i_69\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(3),
      O => \derivative[31]_i_69_n_0\
    );
\derivative[31]_i_7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(28),
      O => \derivative[31]_i_7_n_0\
    );
\derivative[31]_i_70\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(2),
      O => \derivative[31]_i_70_n_0\
    );
\derivative[31]_i_71\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(1),
      O => \derivative[31]_i_71_n_0\
    );
\derivative[31]_i_72\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => dt(0),
      I1 => derivative11_out(31),
      O => \derivative[31]_i_72_n_0\
    );
\derivative[31]_i_8\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(31),
      O => \derivative[31]_i_8_n_0\
    );
\derivative[31]_i_9\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dt(30),
      O => \derivative[31]_i_9_n_0\
    );
\derivative[3]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[4]_i_5_n_5\,
      O => \derivative[3]_i_11_n_0\
    );
\derivative[3]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[4]_i_5_n_6\,
      O => \derivative[3]_i_12_n_0\
    );
\derivative[3]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[4]_i_5_n_7\,
      O => \derivative[3]_i_13_n_0\
    );
\derivative[3]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[4]_i_10_n_4\,
      O => \derivative[3]_i_14_n_0\
    );
\derivative[3]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[4]_i_10_n_5\,
      O => \derivative[3]_i_16_n_0\
    );
\derivative[3]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[4]_i_10_n_6\,
      O => \derivative[3]_i_17_n_0\
    );
\derivative[3]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[4]_i_10_n_7\,
      O => \derivative[3]_i_18_n_0\
    );
\derivative[3]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[4]_i_15_n_4\,
      O => \derivative[3]_i_19_n_0\
    );
\derivative[3]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[4]_i_15_n_5\,
      O => \derivative[3]_i_21_n_0\
    );
\derivative[3]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[4]_i_15_n_6\,
      O => \derivative[3]_i_22_n_0\
    );
\derivative[3]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[4]_i_15_n_7\,
      O => \derivative[3]_i_23_n_0\
    );
\derivative[3]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[4]_i_20_n_4\,
      O => \derivative[3]_i_24_n_0\
    );
\derivative[3]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[4]_i_20_n_5\,
      O => \derivative[3]_i_26_n_0\
    );
\derivative[3]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[4]_i_20_n_6\,
      O => \derivative[3]_i_27_n_0\
    );
\derivative[3]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[4]_i_20_n_7\,
      O => \derivative[3]_i_28_n_0\
    );
\derivative[3]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[4]_i_25_n_4\,
      O => \derivative[3]_i_29_n_0\
    );
\derivative[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => \derivative_reg[4]_i_1_n_7\,
      O => \derivative[3]_i_3_n_0\
    );
\derivative[3]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[4]_i_25_n_5\,
      O => \derivative[3]_i_31_n_0\
    );
\derivative[3]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[4]_i_25_n_6\,
      O => \derivative[3]_i_32_n_0\
    );
\derivative[3]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[4]_i_25_n_7\,
      O => \derivative[3]_i_33_n_0\
    );
\derivative[3]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[4]_i_30_n_4\,
      O => \derivative[3]_i_34_n_0\
    );
\derivative[3]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[4]_i_30_n_5\,
      O => \derivative[3]_i_36_n_0\
    );
\derivative[3]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[4]_i_30_n_6\,
      O => \derivative[3]_i_37_n_0\
    );
\derivative[3]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[4]_i_30_n_7\,
      O => \derivative[3]_i_38_n_0\
    );
\derivative[3]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[4]_i_35_n_4\,
      O => \derivative[3]_i_39_n_0\
    );
\derivative[3]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[4]_i_2_n_4\,
      O => \derivative[3]_i_4_n_0\
    );
\derivative[3]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[4]_i_35_n_5\,
      O => \derivative[3]_i_40_n_0\
    );
\derivative[3]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[4]_i_35_n_6\,
      O => \derivative[3]_i_41_n_0\
    );
\derivative[3]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(3),
      O => \derivative[3]_i_42_n_0\
    );
\derivative[3]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[4]_i_2_n_5\,
      O => \derivative[3]_i_6_n_0\
    );
\derivative[3]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[4]_i_2_n_6\,
      O => \derivative[3]_i_7_n_0\
    );
\derivative[3]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[4]_i_2_n_7\,
      O => \derivative[3]_i_8_n_0\
    );
\derivative[3]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[4]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[4]_i_5_n_4\,
      O => \derivative[3]_i_9_n_0\
    );
\derivative[4]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[5]_i_5_n_5\,
      O => \derivative[4]_i_11_n_0\
    );
\derivative[4]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[5]_i_5_n_6\,
      O => \derivative[4]_i_12_n_0\
    );
\derivative[4]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[5]_i_5_n_7\,
      O => \derivative[4]_i_13_n_0\
    );
\derivative[4]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[5]_i_10_n_4\,
      O => \derivative[4]_i_14_n_0\
    );
\derivative[4]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[5]_i_10_n_5\,
      O => \derivative[4]_i_16_n_0\
    );
\derivative[4]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[5]_i_10_n_6\,
      O => \derivative[4]_i_17_n_0\
    );
\derivative[4]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[5]_i_10_n_7\,
      O => \derivative[4]_i_18_n_0\
    );
\derivative[4]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[5]_i_15_n_4\,
      O => \derivative[4]_i_19_n_0\
    );
\derivative[4]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[5]_i_15_n_5\,
      O => \derivative[4]_i_21_n_0\
    );
\derivative[4]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[5]_i_15_n_6\,
      O => \derivative[4]_i_22_n_0\
    );
\derivative[4]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[5]_i_15_n_7\,
      O => \derivative[4]_i_23_n_0\
    );
\derivative[4]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[5]_i_20_n_4\,
      O => \derivative[4]_i_24_n_0\
    );
\derivative[4]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[5]_i_20_n_5\,
      O => \derivative[4]_i_26_n_0\
    );
\derivative[4]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[5]_i_20_n_6\,
      O => \derivative[4]_i_27_n_0\
    );
\derivative[4]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[5]_i_20_n_7\,
      O => \derivative[4]_i_28_n_0\
    );
\derivative[4]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[5]_i_25_n_4\,
      O => \derivative[4]_i_29_n_0\
    );
\derivative[4]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => \derivative_reg[5]_i_1_n_7\,
      O => \derivative[4]_i_3_n_0\
    );
\derivative[4]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[5]_i_25_n_5\,
      O => \derivative[4]_i_31_n_0\
    );
\derivative[4]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[5]_i_25_n_6\,
      O => \derivative[4]_i_32_n_0\
    );
\derivative[4]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[5]_i_25_n_7\,
      O => \derivative[4]_i_33_n_0\
    );
\derivative[4]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[5]_i_30_n_4\,
      O => \derivative[4]_i_34_n_0\
    );
\derivative[4]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[5]_i_30_n_5\,
      O => \derivative[4]_i_36_n_0\
    );
\derivative[4]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[5]_i_30_n_6\,
      O => \derivative[4]_i_37_n_0\
    );
\derivative[4]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[5]_i_30_n_7\,
      O => \derivative[4]_i_38_n_0\
    );
\derivative[4]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[5]_i_35_n_4\,
      O => \derivative[4]_i_39_n_0\
    );
\derivative[4]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[5]_i_2_n_4\,
      O => \derivative[4]_i_4_n_0\
    );
\derivative[4]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[5]_i_35_n_5\,
      O => \derivative[4]_i_40_n_0\
    );
\derivative[4]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[5]_i_35_n_6\,
      O => \derivative[4]_i_41_n_0\
    );
\derivative[4]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(4),
      O => \derivative[4]_i_42_n_0\
    );
\derivative[4]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[5]_i_2_n_5\,
      O => \derivative[4]_i_6_n_0\
    );
\derivative[4]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[5]_i_2_n_6\,
      O => \derivative[4]_i_7_n_0\
    );
\derivative[4]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[5]_i_2_n_7\,
      O => \derivative[4]_i_8_n_0\
    );
\derivative[4]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[5]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[5]_i_5_n_4\,
      O => \derivative[4]_i_9_n_0\
    );
\derivative[5]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[6]_i_5_n_5\,
      O => \derivative[5]_i_11_n_0\
    );
\derivative[5]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[6]_i_5_n_6\,
      O => \derivative[5]_i_12_n_0\
    );
\derivative[5]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[6]_i_5_n_7\,
      O => \derivative[5]_i_13_n_0\
    );
\derivative[5]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[6]_i_10_n_4\,
      O => \derivative[5]_i_14_n_0\
    );
\derivative[5]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[6]_i_10_n_5\,
      O => \derivative[5]_i_16_n_0\
    );
\derivative[5]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[6]_i_10_n_6\,
      O => \derivative[5]_i_17_n_0\
    );
\derivative[5]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[6]_i_10_n_7\,
      O => \derivative[5]_i_18_n_0\
    );
\derivative[5]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[6]_i_15_n_4\,
      O => \derivative[5]_i_19_n_0\
    );
\derivative[5]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[6]_i_15_n_5\,
      O => \derivative[5]_i_21_n_0\
    );
\derivative[5]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[6]_i_15_n_6\,
      O => \derivative[5]_i_22_n_0\
    );
\derivative[5]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[6]_i_15_n_7\,
      O => \derivative[5]_i_23_n_0\
    );
\derivative[5]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[6]_i_20_n_4\,
      O => \derivative[5]_i_24_n_0\
    );
\derivative[5]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[6]_i_20_n_5\,
      O => \derivative[5]_i_26_n_0\
    );
\derivative[5]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[6]_i_20_n_6\,
      O => \derivative[5]_i_27_n_0\
    );
\derivative[5]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[6]_i_20_n_7\,
      O => \derivative[5]_i_28_n_0\
    );
\derivative[5]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[6]_i_25_n_4\,
      O => \derivative[5]_i_29_n_0\
    );
\derivative[5]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => \derivative_reg[6]_i_1_n_7\,
      O => \derivative[5]_i_3_n_0\
    );
\derivative[5]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[6]_i_25_n_5\,
      O => \derivative[5]_i_31_n_0\
    );
\derivative[5]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[6]_i_25_n_6\,
      O => \derivative[5]_i_32_n_0\
    );
\derivative[5]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[6]_i_25_n_7\,
      O => \derivative[5]_i_33_n_0\
    );
\derivative[5]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[6]_i_30_n_4\,
      O => \derivative[5]_i_34_n_0\
    );
\derivative[5]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[6]_i_30_n_5\,
      O => \derivative[5]_i_36_n_0\
    );
\derivative[5]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[6]_i_30_n_6\,
      O => \derivative[5]_i_37_n_0\
    );
\derivative[5]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[6]_i_30_n_7\,
      O => \derivative[5]_i_38_n_0\
    );
\derivative[5]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[6]_i_35_n_4\,
      O => \derivative[5]_i_39_n_0\
    );
\derivative[5]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[6]_i_2_n_4\,
      O => \derivative[5]_i_4_n_0\
    );
\derivative[5]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[6]_i_35_n_5\,
      O => \derivative[5]_i_40_n_0\
    );
\derivative[5]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[6]_i_35_n_6\,
      O => \derivative[5]_i_41_n_0\
    );
\derivative[5]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(5),
      O => \derivative[5]_i_42_n_0\
    );
\derivative[5]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[6]_i_2_n_5\,
      O => \derivative[5]_i_6_n_0\
    );
\derivative[5]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[6]_i_2_n_6\,
      O => \derivative[5]_i_7_n_0\
    );
\derivative[5]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[6]_i_2_n_7\,
      O => \derivative[5]_i_8_n_0\
    );
\derivative[5]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[6]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[6]_i_5_n_4\,
      O => \derivative[5]_i_9_n_0\
    );
\derivative[6]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[7]_i_5_n_5\,
      O => \derivative[6]_i_11_n_0\
    );
\derivative[6]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[7]_i_5_n_6\,
      O => \derivative[6]_i_12_n_0\
    );
\derivative[6]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[7]_i_5_n_7\,
      O => \derivative[6]_i_13_n_0\
    );
\derivative[6]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[7]_i_10_n_4\,
      O => \derivative[6]_i_14_n_0\
    );
\derivative[6]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[7]_i_10_n_5\,
      O => \derivative[6]_i_16_n_0\
    );
\derivative[6]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[7]_i_10_n_6\,
      O => \derivative[6]_i_17_n_0\
    );
\derivative[6]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[7]_i_10_n_7\,
      O => \derivative[6]_i_18_n_0\
    );
\derivative[6]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[7]_i_15_n_4\,
      O => \derivative[6]_i_19_n_0\
    );
\derivative[6]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[7]_i_15_n_5\,
      O => \derivative[6]_i_21_n_0\
    );
\derivative[6]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[7]_i_15_n_6\,
      O => \derivative[6]_i_22_n_0\
    );
\derivative[6]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[7]_i_15_n_7\,
      O => \derivative[6]_i_23_n_0\
    );
\derivative[6]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[7]_i_20_n_4\,
      O => \derivative[6]_i_24_n_0\
    );
\derivative[6]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[7]_i_20_n_5\,
      O => \derivative[6]_i_26_n_0\
    );
\derivative[6]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[7]_i_20_n_6\,
      O => \derivative[6]_i_27_n_0\
    );
\derivative[6]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[7]_i_20_n_7\,
      O => \derivative[6]_i_28_n_0\
    );
\derivative[6]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[7]_i_25_n_4\,
      O => \derivative[6]_i_29_n_0\
    );
\derivative[6]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => \derivative_reg[7]_i_1_n_7\,
      O => \derivative[6]_i_3_n_0\
    );
\derivative[6]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[7]_i_25_n_5\,
      O => \derivative[6]_i_31_n_0\
    );
\derivative[6]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[7]_i_25_n_6\,
      O => \derivative[6]_i_32_n_0\
    );
\derivative[6]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[7]_i_25_n_7\,
      O => \derivative[6]_i_33_n_0\
    );
\derivative[6]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[7]_i_30_n_4\,
      O => \derivative[6]_i_34_n_0\
    );
\derivative[6]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[7]_i_30_n_5\,
      O => \derivative[6]_i_36_n_0\
    );
\derivative[6]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[7]_i_30_n_6\,
      O => \derivative[6]_i_37_n_0\
    );
\derivative[6]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[7]_i_30_n_7\,
      O => \derivative[6]_i_38_n_0\
    );
\derivative[6]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[7]_i_35_n_4\,
      O => \derivative[6]_i_39_n_0\
    );
\derivative[6]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[7]_i_2_n_4\,
      O => \derivative[6]_i_4_n_0\
    );
\derivative[6]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[7]_i_35_n_5\,
      O => \derivative[6]_i_40_n_0\
    );
\derivative[6]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[7]_i_35_n_6\,
      O => \derivative[6]_i_41_n_0\
    );
\derivative[6]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(6),
      O => \derivative[6]_i_42_n_0\
    );
\derivative[6]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[7]_i_2_n_5\,
      O => \derivative[6]_i_6_n_0\
    );
\derivative[6]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[7]_i_2_n_6\,
      O => \derivative[6]_i_7_n_0\
    );
\derivative[6]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[7]_i_2_n_7\,
      O => \derivative[6]_i_8_n_0\
    );
\derivative[6]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[7]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[7]_i_5_n_4\,
      O => \derivative[6]_i_9_n_0\
    );
\derivative[7]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[8]_i_5_n_5\,
      O => \derivative[7]_i_11_n_0\
    );
\derivative[7]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[8]_i_5_n_6\,
      O => \derivative[7]_i_12_n_0\
    );
\derivative[7]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[8]_i_5_n_7\,
      O => \derivative[7]_i_13_n_0\
    );
\derivative[7]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[8]_i_10_n_4\,
      O => \derivative[7]_i_14_n_0\
    );
\derivative[7]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[8]_i_10_n_5\,
      O => \derivative[7]_i_16_n_0\
    );
\derivative[7]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[8]_i_10_n_6\,
      O => \derivative[7]_i_17_n_0\
    );
\derivative[7]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[8]_i_10_n_7\,
      O => \derivative[7]_i_18_n_0\
    );
\derivative[7]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[8]_i_15_n_4\,
      O => \derivative[7]_i_19_n_0\
    );
\derivative[7]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[8]_i_15_n_5\,
      O => \derivative[7]_i_21_n_0\
    );
\derivative[7]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[8]_i_15_n_6\,
      O => \derivative[7]_i_22_n_0\
    );
\derivative[7]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[8]_i_15_n_7\,
      O => \derivative[7]_i_23_n_0\
    );
\derivative[7]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[8]_i_20_n_4\,
      O => \derivative[7]_i_24_n_0\
    );
\derivative[7]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[8]_i_20_n_5\,
      O => \derivative[7]_i_26_n_0\
    );
\derivative[7]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[8]_i_20_n_6\,
      O => \derivative[7]_i_27_n_0\
    );
\derivative[7]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[8]_i_20_n_7\,
      O => \derivative[7]_i_28_n_0\
    );
\derivative[7]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[8]_i_25_n_4\,
      O => \derivative[7]_i_29_n_0\
    );
\derivative[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => \derivative_reg[8]_i_1_n_7\,
      O => \derivative[7]_i_3_n_0\
    );
\derivative[7]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[8]_i_25_n_5\,
      O => \derivative[7]_i_31_n_0\
    );
\derivative[7]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[8]_i_25_n_6\,
      O => \derivative[7]_i_32_n_0\
    );
\derivative[7]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[8]_i_25_n_7\,
      O => \derivative[7]_i_33_n_0\
    );
\derivative[7]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[8]_i_30_n_4\,
      O => \derivative[7]_i_34_n_0\
    );
\derivative[7]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[8]_i_30_n_5\,
      O => \derivative[7]_i_36_n_0\
    );
\derivative[7]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[8]_i_30_n_6\,
      O => \derivative[7]_i_37_n_0\
    );
\derivative[7]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[8]_i_30_n_7\,
      O => \derivative[7]_i_38_n_0\
    );
\derivative[7]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[8]_i_35_n_4\,
      O => \derivative[7]_i_39_n_0\
    );
\derivative[7]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[8]_i_2_n_4\,
      O => \derivative[7]_i_4_n_0\
    );
\derivative[7]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[8]_i_35_n_5\,
      O => \derivative[7]_i_40_n_0\
    );
\derivative[7]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[8]_i_35_n_6\,
      O => \derivative[7]_i_41_n_0\
    );
\derivative[7]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(7),
      O => \derivative[7]_i_42_n_0\
    );
\derivative[7]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[8]_i_2_n_5\,
      O => \derivative[7]_i_6_n_0\
    );
\derivative[7]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[8]_i_2_n_6\,
      O => \derivative[7]_i_7_n_0\
    );
\derivative[7]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[8]_i_2_n_7\,
      O => \derivative[7]_i_8_n_0\
    );
\derivative[7]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[8]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[8]_i_5_n_4\,
      O => \derivative[7]_i_9_n_0\
    );
\derivative[8]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[9]_i_5_n_5\,
      O => \derivative[8]_i_11_n_0\
    );
\derivative[8]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[9]_i_5_n_6\,
      O => \derivative[8]_i_12_n_0\
    );
\derivative[8]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[9]_i_5_n_7\,
      O => \derivative[8]_i_13_n_0\
    );
\derivative[8]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[9]_i_10_n_4\,
      O => \derivative[8]_i_14_n_0\
    );
\derivative[8]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[9]_i_10_n_5\,
      O => \derivative[8]_i_16_n_0\
    );
\derivative[8]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[9]_i_10_n_6\,
      O => \derivative[8]_i_17_n_0\
    );
\derivative[8]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[9]_i_10_n_7\,
      O => \derivative[8]_i_18_n_0\
    );
\derivative[8]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[9]_i_15_n_4\,
      O => \derivative[8]_i_19_n_0\
    );
\derivative[8]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[9]_i_15_n_5\,
      O => \derivative[8]_i_21_n_0\
    );
\derivative[8]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[9]_i_15_n_6\,
      O => \derivative[8]_i_22_n_0\
    );
\derivative[8]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[9]_i_15_n_7\,
      O => \derivative[8]_i_23_n_0\
    );
\derivative[8]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[9]_i_20_n_4\,
      O => \derivative[8]_i_24_n_0\
    );
\derivative[8]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[9]_i_20_n_5\,
      O => \derivative[8]_i_26_n_0\
    );
\derivative[8]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[9]_i_20_n_6\,
      O => \derivative[8]_i_27_n_0\
    );
\derivative[8]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[9]_i_20_n_7\,
      O => \derivative[8]_i_28_n_0\
    );
\derivative[8]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[9]_i_25_n_4\,
      O => \derivative[8]_i_29_n_0\
    );
\derivative[8]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => \derivative_reg[9]_i_1_n_7\,
      O => \derivative[8]_i_3_n_0\
    );
\derivative[8]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[9]_i_25_n_5\,
      O => \derivative[8]_i_31_n_0\
    );
\derivative[8]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[9]_i_25_n_6\,
      O => \derivative[8]_i_32_n_0\
    );
\derivative[8]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[9]_i_25_n_7\,
      O => \derivative[8]_i_33_n_0\
    );
\derivative[8]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[9]_i_30_n_4\,
      O => \derivative[8]_i_34_n_0\
    );
\derivative[8]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[9]_i_30_n_5\,
      O => \derivative[8]_i_36_n_0\
    );
\derivative[8]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[9]_i_30_n_6\,
      O => \derivative[8]_i_37_n_0\
    );
\derivative[8]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[9]_i_30_n_7\,
      O => \derivative[8]_i_38_n_0\
    );
\derivative[8]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[9]_i_35_n_4\,
      O => \derivative[8]_i_39_n_0\
    );
\derivative[8]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[9]_i_2_n_4\,
      O => \derivative[8]_i_4_n_0\
    );
\derivative[8]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[9]_i_35_n_5\,
      O => \derivative[8]_i_40_n_0\
    );
\derivative[8]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[9]_i_35_n_6\,
      O => \derivative[8]_i_41_n_0\
    );
\derivative[8]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(8),
      O => \derivative[8]_i_42_n_0\
    );
\derivative[8]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[9]_i_2_n_5\,
      O => \derivative[8]_i_6_n_0\
    );
\derivative[8]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[9]_i_2_n_6\,
      O => \derivative[8]_i_7_n_0\
    );
\derivative[8]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[9]_i_2_n_7\,
      O => \derivative[8]_i_8_n_0\
    );
\derivative[8]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[9]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[9]_i_5_n_4\,
      O => \derivative[8]_i_9_n_0\
    );
\derivative[9]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(26),
      I2 => \derivative_reg[10]_i_5_n_5\,
      O => \derivative[9]_i_11_n_0\
    );
\derivative[9]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(25),
      I2 => \derivative_reg[10]_i_5_n_6\,
      O => \derivative[9]_i_12_n_0\
    );
\derivative[9]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(24),
      I2 => \derivative_reg[10]_i_5_n_7\,
      O => \derivative[9]_i_13_n_0\
    );
\derivative[9]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(23),
      I2 => \derivative_reg[10]_i_10_n_4\,
      O => \derivative[9]_i_14_n_0\
    );
\derivative[9]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(22),
      I2 => \derivative_reg[10]_i_10_n_5\,
      O => \derivative[9]_i_16_n_0\
    );
\derivative[9]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(21),
      I2 => \derivative_reg[10]_i_10_n_6\,
      O => \derivative[9]_i_17_n_0\
    );
\derivative[9]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(20),
      I2 => \derivative_reg[10]_i_10_n_7\,
      O => \derivative[9]_i_18_n_0\
    );
\derivative[9]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(19),
      I2 => \derivative_reg[10]_i_15_n_4\,
      O => \derivative[9]_i_19_n_0\
    );
\derivative[9]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(18),
      I2 => \derivative_reg[10]_i_15_n_5\,
      O => \derivative[9]_i_21_n_0\
    );
\derivative[9]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(17),
      I2 => \derivative_reg[10]_i_15_n_6\,
      O => \derivative[9]_i_22_n_0\
    );
\derivative[9]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(16),
      I2 => \derivative_reg[10]_i_15_n_7\,
      O => \derivative[9]_i_23_n_0\
    );
\derivative[9]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(15),
      I2 => \derivative_reg[10]_i_20_n_4\,
      O => \derivative[9]_i_24_n_0\
    );
\derivative[9]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(14),
      I2 => \derivative_reg[10]_i_20_n_5\,
      O => \derivative[9]_i_26_n_0\
    );
\derivative[9]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(13),
      I2 => \derivative_reg[10]_i_20_n_6\,
      O => \derivative[9]_i_27_n_0\
    );
\derivative[9]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(12),
      I2 => \derivative_reg[10]_i_20_n_7\,
      O => \derivative[9]_i_28_n_0\
    );
\derivative[9]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(11),
      I2 => \derivative_reg[10]_i_25_n_4\,
      O => \derivative[9]_i_29_n_0\
    );
\derivative[9]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => \derivative_reg[10]_i_1_n_7\,
      O => \derivative[9]_i_3_n_0\
    );
\derivative[9]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(10),
      I2 => \derivative_reg[10]_i_25_n_5\,
      O => \derivative[9]_i_31_n_0\
    );
\derivative[9]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(9),
      I2 => \derivative_reg[10]_i_25_n_6\,
      O => \derivative[9]_i_32_n_0\
    );
\derivative[9]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(8),
      I2 => \derivative_reg[10]_i_25_n_7\,
      O => \derivative[9]_i_33_n_0\
    );
\derivative[9]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(7),
      I2 => \derivative_reg[10]_i_30_n_4\,
      O => \derivative[9]_i_34_n_0\
    );
\derivative[9]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(6),
      I2 => \derivative_reg[10]_i_30_n_5\,
      O => \derivative[9]_i_36_n_0\
    );
\derivative[9]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(5),
      I2 => \derivative_reg[10]_i_30_n_6\,
      O => \derivative[9]_i_37_n_0\
    );
\derivative[9]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(4),
      I2 => \derivative_reg[10]_i_30_n_7\,
      O => \derivative[9]_i_38_n_0\
    );
\derivative[9]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(3),
      I2 => \derivative_reg[10]_i_35_n_4\,
      O => \derivative[9]_i_39_n_0\
    );
\derivative[9]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(31),
      I2 => \derivative_reg[10]_i_2_n_4\,
      O => \derivative[9]_i_4_n_0\
    );
\derivative[9]_i_40\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(2),
      I2 => \derivative_reg[10]_i_35_n_5\,
      O => \derivative[9]_i_40_n_0\
    );
\derivative[9]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(1),
      I2 => \derivative_reg[10]_i_35_n_6\,
      O => \derivative[9]_i_41_n_0\
    );
\derivative[9]_i_42\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(0),
      I2 => derivative11_out(9),
      O => \derivative[9]_i_42_n_0\
    );
\derivative[9]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(30),
      I2 => \derivative_reg[10]_i_2_n_5\,
      O => \derivative[9]_i_6_n_0\
    );
\derivative[9]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(29),
      I2 => \derivative_reg[10]_i_2_n_6\,
      O => \derivative[9]_i_7_n_0\
    );
\derivative[9]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(28),
      I2 => \derivative_reg[10]_i_2_n_7\,
      O => \derivative[9]_i_8_n_0\
    );
\derivative[9]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \derivative_reg[10]_i_1_n_2\,
      I1 => dt(27),
      I2 => \derivative_reg[10]_i_5_n_4\,
      O => \derivative[9]_i_9_n_0\
    );
\derivative_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[0]_i_1_n_3\,
      Q => derivative_out(0),
      R => '0'
    );
\derivative_reg[0]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_2_n_0\,
      CO(3 downto 1) => \NLW_derivative_reg[0]_i_1_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \derivative_reg[0]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \derivative_reg[1]_i_1_n_2\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \derivative[0]_i_3_n_0\
    );
\derivative_reg[0]_i_14\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_19_n_0\,
      CO(3) => \derivative_reg[0]_i_14_n_0\,
      CO(2) => \derivative_reg[0]_i_14_n_1\,
      CO(1) => \derivative_reg[0]_i_14_n_2\,
      CO(0) => \derivative_reg[0]_i_14_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[1]_i_15_n_4\,
      DI(2) => \derivative_reg[1]_i_15_n_5\,
      DI(1) => \derivative_reg[1]_i_15_n_6\,
      DI(0) => \derivative_reg[1]_i_15_n_7\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_14_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_20_n_0\,
      S(2) => \derivative[0]_i_21_n_0\,
      S(1) => \derivative[0]_i_22_n_0\,
      S(0) => \derivative[0]_i_23_n_0\
    );
\derivative_reg[0]_i_19\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_24_n_0\,
      CO(3) => \derivative_reg[0]_i_19_n_0\,
      CO(2) => \derivative_reg[0]_i_19_n_1\,
      CO(1) => \derivative_reg[0]_i_19_n_2\,
      CO(0) => \derivative_reg[0]_i_19_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[1]_i_20_n_4\,
      DI(2) => \derivative_reg[1]_i_20_n_5\,
      DI(1) => \derivative_reg[1]_i_20_n_6\,
      DI(0) => \derivative_reg[1]_i_20_n_7\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_19_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_25_n_0\,
      S(2) => \derivative[0]_i_26_n_0\,
      S(1) => \derivative[0]_i_27_n_0\,
      S(0) => \derivative[0]_i_28_n_0\
    );
\derivative_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_4_n_0\,
      CO(3) => \derivative_reg[0]_i_2_n_0\,
      CO(2) => \derivative_reg[0]_i_2_n_1\,
      CO(1) => \derivative_reg[0]_i_2_n_2\,
      CO(0) => \derivative_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[1]_i_2_n_4\,
      DI(2) => \derivative_reg[1]_i_2_n_5\,
      DI(1) => \derivative_reg[1]_i_2_n_6\,
      DI(0) => \derivative_reg[1]_i_2_n_7\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_5_n_0\,
      S(2) => \derivative[0]_i_6_n_0\,
      S(1) => \derivative[0]_i_7_n_0\,
      S(0) => \derivative[0]_i_8_n_0\
    );
\derivative_reg[0]_i_24\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_29_n_0\,
      CO(3) => \derivative_reg[0]_i_24_n_0\,
      CO(2) => \derivative_reg[0]_i_24_n_1\,
      CO(1) => \derivative_reg[0]_i_24_n_2\,
      CO(0) => \derivative_reg[0]_i_24_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[1]_i_25_n_4\,
      DI(2) => \derivative_reg[1]_i_25_n_5\,
      DI(1) => \derivative_reg[1]_i_25_n_6\,
      DI(0) => \derivative_reg[1]_i_25_n_7\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_24_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_30_n_0\,
      S(2) => \derivative[0]_i_31_n_0\,
      S(1) => \derivative[0]_i_32_n_0\,
      S(0) => \derivative[0]_i_33_n_0\
    );
\derivative_reg[0]_i_29\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_34_n_0\,
      CO(3) => \derivative_reg[0]_i_29_n_0\,
      CO(2) => \derivative_reg[0]_i_29_n_1\,
      CO(1) => \derivative_reg[0]_i_29_n_2\,
      CO(0) => \derivative_reg[0]_i_29_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[1]_i_30_n_4\,
      DI(2) => \derivative_reg[1]_i_30_n_5\,
      DI(1) => \derivative_reg[1]_i_30_n_6\,
      DI(0) => \derivative_reg[1]_i_30_n_7\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_29_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_35_n_0\,
      S(2) => \derivative[0]_i_36_n_0\,
      S(1) => \derivative[0]_i_37_n_0\,
      S(0) => \derivative[0]_i_38_n_0\
    );
\derivative_reg[0]_i_34\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[0]_i_34_n_0\,
      CO(2) => \derivative_reg[0]_i_34_n_1\,
      CO(1) => \derivative_reg[0]_i_34_n_2\,
      CO(0) => \derivative_reg[0]_i_34_n_3\,
      CYINIT => \derivative_reg[1]_i_1_n_2\,
      DI(3) => \derivative_reg[1]_i_35_n_4\,
      DI(2) => \derivative_reg[1]_i_35_n_5\,
      DI(1) => \derivative_reg[1]_i_35_n_6\,
      DI(0) => derivative11_out(0),
      O(3 downto 0) => \NLW_derivative_reg[0]_i_34_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_39_n_0\,
      S(2) => \derivative[0]_i_40_n_0\,
      S(1) => \derivative[0]_i_41_n_0\,
      S(0) => \derivative[0]_i_42_n_0\
    );
\derivative_reg[0]_i_4\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_9_n_0\,
      CO(3) => \derivative_reg[0]_i_4_n_0\,
      CO(2) => \derivative_reg[0]_i_4_n_1\,
      CO(1) => \derivative_reg[0]_i_4_n_2\,
      CO(0) => \derivative_reg[0]_i_4_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[1]_i_5_n_4\,
      DI(2) => \derivative_reg[1]_i_5_n_5\,
      DI(1) => \derivative_reg[1]_i_5_n_6\,
      DI(0) => \derivative_reg[1]_i_5_n_7\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_4_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_10_n_0\,
      S(2) => \derivative[0]_i_11_n_0\,
      S(1) => \derivative[0]_i_12_n_0\,
      S(0) => \derivative[0]_i_13_n_0\
    );
\derivative_reg[0]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[0]_i_14_n_0\,
      CO(3) => \derivative_reg[0]_i_9_n_0\,
      CO(2) => \derivative_reg[0]_i_9_n_1\,
      CO(1) => \derivative_reg[0]_i_9_n_2\,
      CO(0) => \derivative_reg[0]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[1]_i_10_n_4\,
      DI(2) => \derivative_reg[1]_i_10_n_5\,
      DI(1) => \derivative_reg[1]_i_10_n_6\,
      DI(0) => \derivative_reg[1]_i_10_n_7\,
      O(3 downto 0) => \NLW_derivative_reg[0]_i_9_O_UNCONNECTED\(3 downto 0),
      S(3) => \derivative[0]_i_15_n_0\,
      S(2) => \derivative[0]_i_16_n_0\,
      S(1) => \derivative[0]_i_17_n_0\,
      S(0) => \derivative[0]_i_18_n_0\
    );
\derivative_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[10]_i_1_n_2\,
      Q => derivative_out(10),
      R => '0'
    );
\derivative_reg[10]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[10]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[10]_i_1_n_2\,
      CO(0) => \derivative_reg[10]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[11]_i_1_n_2\,
      DI(0) => \derivative_reg[11]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[10]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[10]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[10]_i_3_n_0\,
      S(0) => \derivative[10]_i_4_n_0\
    );
\derivative_reg[10]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_15_n_0\,
      CO(3) => \derivative_reg[10]_i_10_n_0\,
      CO(2) => \derivative_reg[10]_i_10_n_1\,
      CO(1) => \derivative_reg[10]_i_10_n_2\,
      CO(0) => \derivative_reg[10]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[11]_i_10_n_5\,
      DI(2) => \derivative_reg[11]_i_10_n_6\,
      DI(1) => \derivative_reg[11]_i_10_n_7\,
      DI(0) => \derivative_reg[11]_i_15_n_4\,
      O(3) => \derivative_reg[10]_i_10_n_4\,
      O(2) => \derivative_reg[10]_i_10_n_5\,
      O(1) => \derivative_reg[10]_i_10_n_6\,
      O(0) => \derivative_reg[10]_i_10_n_7\,
      S(3) => \derivative[10]_i_16_n_0\,
      S(2) => \derivative[10]_i_17_n_0\,
      S(1) => \derivative[10]_i_18_n_0\,
      S(0) => \derivative[10]_i_19_n_0\
    );
\derivative_reg[10]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_20_n_0\,
      CO(3) => \derivative_reg[10]_i_15_n_0\,
      CO(2) => \derivative_reg[10]_i_15_n_1\,
      CO(1) => \derivative_reg[10]_i_15_n_2\,
      CO(0) => \derivative_reg[10]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[11]_i_15_n_5\,
      DI(2) => \derivative_reg[11]_i_15_n_6\,
      DI(1) => \derivative_reg[11]_i_15_n_7\,
      DI(0) => \derivative_reg[11]_i_20_n_4\,
      O(3) => \derivative_reg[10]_i_15_n_4\,
      O(2) => \derivative_reg[10]_i_15_n_5\,
      O(1) => \derivative_reg[10]_i_15_n_6\,
      O(0) => \derivative_reg[10]_i_15_n_7\,
      S(3) => \derivative[10]_i_21_n_0\,
      S(2) => \derivative[10]_i_22_n_0\,
      S(1) => \derivative[10]_i_23_n_0\,
      S(0) => \derivative[10]_i_24_n_0\
    );
\derivative_reg[10]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_5_n_0\,
      CO(3) => \derivative_reg[10]_i_2_n_0\,
      CO(2) => \derivative_reg[10]_i_2_n_1\,
      CO(1) => \derivative_reg[10]_i_2_n_2\,
      CO(0) => \derivative_reg[10]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[11]_i_2_n_5\,
      DI(2) => \derivative_reg[11]_i_2_n_6\,
      DI(1) => \derivative_reg[11]_i_2_n_7\,
      DI(0) => \derivative_reg[11]_i_5_n_4\,
      O(3) => \derivative_reg[10]_i_2_n_4\,
      O(2) => \derivative_reg[10]_i_2_n_5\,
      O(1) => \derivative_reg[10]_i_2_n_6\,
      O(0) => \derivative_reg[10]_i_2_n_7\,
      S(3) => \derivative[10]_i_6_n_0\,
      S(2) => \derivative[10]_i_7_n_0\,
      S(1) => \derivative[10]_i_8_n_0\,
      S(0) => \derivative[10]_i_9_n_0\
    );
\derivative_reg[10]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_25_n_0\,
      CO(3) => \derivative_reg[10]_i_20_n_0\,
      CO(2) => \derivative_reg[10]_i_20_n_1\,
      CO(1) => \derivative_reg[10]_i_20_n_2\,
      CO(0) => \derivative_reg[10]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[11]_i_20_n_5\,
      DI(2) => \derivative_reg[11]_i_20_n_6\,
      DI(1) => \derivative_reg[11]_i_20_n_7\,
      DI(0) => \derivative_reg[11]_i_25_n_4\,
      O(3) => \derivative_reg[10]_i_20_n_4\,
      O(2) => \derivative_reg[10]_i_20_n_5\,
      O(1) => \derivative_reg[10]_i_20_n_6\,
      O(0) => \derivative_reg[10]_i_20_n_7\,
      S(3) => \derivative[10]_i_26_n_0\,
      S(2) => \derivative[10]_i_27_n_0\,
      S(1) => \derivative[10]_i_28_n_0\,
      S(0) => \derivative[10]_i_29_n_0\
    );
\derivative_reg[10]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_30_n_0\,
      CO(3) => \derivative_reg[10]_i_25_n_0\,
      CO(2) => \derivative_reg[10]_i_25_n_1\,
      CO(1) => \derivative_reg[10]_i_25_n_2\,
      CO(0) => \derivative_reg[10]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[11]_i_25_n_5\,
      DI(2) => \derivative_reg[11]_i_25_n_6\,
      DI(1) => \derivative_reg[11]_i_25_n_7\,
      DI(0) => \derivative_reg[11]_i_30_n_4\,
      O(3) => \derivative_reg[10]_i_25_n_4\,
      O(2) => \derivative_reg[10]_i_25_n_5\,
      O(1) => \derivative_reg[10]_i_25_n_6\,
      O(0) => \derivative_reg[10]_i_25_n_7\,
      S(3) => \derivative[10]_i_31_n_0\,
      S(2) => \derivative[10]_i_32_n_0\,
      S(1) => \derivative[10]_i_33_n_0\,
      S(0) => \derivative[10]_i_34_n_0\
    );
\derivative_reg[10]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_35_n_0\,
      CO(3) => \derivative_reg[10]_i_30_n_0\,
      CO(2) => \derivative_reg[10]_i_30_n_1\,
      CO(1) => \derivative_reg[10]_i_30_n_2\,
      CO(0) => \derivative_reg[10]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[11]_i_30_n_5\,
      DI(2) => \derivative_reg[11]_i_30_n_6\,
      DI(1) => \derivative_reg[11]_i_30_n_7\,
      DI(0) => \derivative_reg[11]_i_35_n_4\,
      O(3) => \derivative_reg[10]_i_30_n_4\,
      O(2) => \derivative_reg[10]_i_30_n_5\,
      O(1) => \derivative_reg[10]_i_30_n_6\,
      O(0) => \derivative_reg[10]_i_30_n_7\,
      S(3) => \derivative[10]_i_36_n_0\,
      S(2) => \derivative[10]_i_37_n_0\,
      S(1) => \derivative[10]_i_38_n_0\,
      S(0) => \derivative[10]_i_39_n_0\
    );
\derivative_reg[10]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[10]_i_35_n_0\,
      CO(2) => \derivative_reg[10]_i_35_n_1\,
      CO(1) => \derivative_reg[10]_i_35_n_2\,
      CO(0) => \derivative_reg[10]_i_35_n_3\,
      CYINIT => \derivative_reg[11]_i_1_n_2\,
      DI(3) => \derivative_reg[11]_i_35_n_5\,
      DI(2) => \derivative_reg[11]_i_35_n_6\,
      DI(1) => derivative11_out(10),
      DI(0) => '0',
      O(3) => \derivative_reg[10]_i_35_n_4\,
      O(2) => \derivative_reg[10]_i_35_n_5\,
      O(1) => \derivative_reg[10]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[10]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[10]_i_40_n_0\,
      S(2) => \derivative[10]_i_41_n_0\,
      S(1) => \derivative[10]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[10]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[10]_i_10_n_0\,
      CO(3) => \derivative_reg[10]_i_5_n_0\,
      CO(2) => \derivative_reg[10]_i_5_n_1\,
      CO(1) => \derivative_reg[10]_i_5_n_2\,
      CO(0) => \derivative_reg[10]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[11]_i_5_n_5\,
      DI(2) => \derivative_reg[11]_i_5_n_6\,
      DI(1) => \derivative_reg[11]_i_5_n_7\,
      DI(0) => \derivative_reg[11]_i_10_n_4\,
      O(3) => \derivative_reg[10]_i_5_n_4\,
      O(2) => \derivative_reg[10]_i_5_n_5\,
      O(1) => \derivative_reg[10]_i_5_n_6\,
      O(0) => \derivative_reg[10]_i_5_n_7\,
      S(3) => \derivative[10]_i_11_n_0\,
      S(2) => \derivative[10]_i_12_n_0\,
      S(1) => \derivative[10]_i_13_n_0\,
      S(0) => \derivative[10]_i_14_n_0\
    );
\derivative_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[11]_i_1_n_2\,
      Q => derivative_out(11),
      R => '0'
    );
\derivative_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[11]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[11]_i_1_n_2\,
      CO(0) => \derivative_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[12]_i_1_n_2\,
      DI(0) => \derivative_reg[12]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[11]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[11]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[11]_i_3_n_0\,
      S(0) => \derivative[11]_i_4_n_0\
    );
\derivative_reg[11]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_15_n_0\,
      CO(3) => \derivative_reg[11]_i_10_n_0\,
      CO(2) => \derivative_reg[11]_i_10_n_1\,
      CO(1) => \derivative_reg[11]_i_10_n_2\,
      CO(0) => \derivative_reg[11]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[12]_i_10_n_5\,
      DI(2) => \derivative_reg[12]_i_10_n_6\,
      DI(1) => \derivative_reg[12]_i_10_n_7\,
      DI(0) => \derivative_reg[12]_i_15_n_4\,
      O(3) => \derivative_reg[11]_i_10_n_4\,
      O(2) => \derivative_reg[11]_i_10_n_5\,
      O(1) => \derivative_reg[11]_i_10_n_6\,
      O(0) => \derivative_reg[11]_i_10_n_7\,
      S(3) => \derivative[11]_i_16_n_0\,
      S(2) => \derivative[11]_i_17_n_0\,
      S(1) => \derivative[11]_i_18_n_0\,
      S(0) => \derivative[11]_i_19_n_0\
    );
\derivative_reg[11]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_20_n_0\,
      CO(3) => \derivative_reg[11]_i_15_n_0\,
      CO(2) => \derivative_reg[11]_i_15_n_1\,
      CO(1) => \derivative_reg[11]_i_15_n_2\,
      CO(0) => \derivative_reg[11]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[12]_i_15_n_5\,
      DI(2) => \derivative_reg[12]_i_15_n_6\,
      DI(1) => \derivative_reg[12]_i_15_n_7\,
      DI(0) => \derivative_reg[12]_i_20_n_4\,
      O(3) => \derivative_reg[11]_i_15_n_4\,
      O(2) => \derivative_reg[11]_i_15_n_5\,
      O(1) => \derivative_reg[11]_i_15_n_6\,
      O(0) => \derivative_reg[11]_i_15_n_7\,
      S(3) => \derivative[11]_i_21_n_0\,
      S(2) => \derivative[11]_i_22_n_0\,
      S(1) => \derivative[11]_i_23_n_0\,
      S(0) => \derivative[11]_i_24_n_0\
    );
\derivative_reg[11]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_5_n_0\,
      CO(3) => \derivative_reg[11]_i_2_n_0\,
      CO(2) => \derivative_reg[11]_i_2_n_1\,
      CO(1) => \derivative_reg[11]_i_2_n_2\,
      CO(0) => \derivative_reg[11]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[12]_i_2_n_5\,
      DI(2) => \derivative_reg[12]_i_2_n_6\,
      DI(1) => \derivative_reg[12]_i_2_n_7\,
      DI(0) => \derivative_reg[12]_i_5_n_4\,
      O(3) => \derivative_reg[11]_i_2_n_4\,
      O(2) => \derivative_reg[11]_i_2_n_5\,
      O(1) => \derivative_reg[11]_i_2_n_6\,
      O(0) => \derivative_reg[11]_i_2_n_7\,
      S(3) => \derivative[11]_i_6_n_0\,
      S(2) => \derivative[11]_i_7_n_0\,
      S(1) => \derivative[11]_i_8_n_0\,
      S(0) => \derivative[11]_i_9_n_0\
    );
\derivative_reg[11]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_25_n_0\,
      CO(3) => \derivative_reg[11]_i_20_n_0\,
      CO(2) => \derivative_reg[11]_i_20_n_1\,
      CO(1) => \derivative_reg[11]_i_20_n_2\,
      CO(0) => \derivative_reg[11]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[12]_i_20_n_5\,
      DI(2) => \derivative_reg[12]_i_20_n_6\,
      DI(1) => \derivative_reg[12]_i_20_n_7\,
      DI(0) => \derivative_reg[12]_i_25_n_4\,
      O(3) => \derivative_reg[11]_i_20_n_4\,
      O(2) => \derivative_reg[11]_i_20_n_5\,
      O(1) => \derivative_reg[11]_i_20_n_6\,
      O(0) => \derivative_reg[11]_i_20_n_7\,
      S(3) => \derivative[11]_i_26_n_0\,
      S(2) => \derivative[11]_i_27_n_0\,
      S(1) => \derivative[11]_i_28_n_0\,
      S(0) => \derivative[11]_i_29_n_0\
    );
\derivative_reg[11]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_30_n_0\,
      CO(3) => \derivative_reg[11]_i_25_n_0\,
      CO(2) => \derivative_reg[11]_i_25_n_1\,
      CO(1) => \derivative_reg[11]_i_25_n_2\,
      CO(0) => \derivative_reg[11]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[12]_i_25_n_5\,
      DI(2) => \derivative_reg[12]_i_25_n_6\,
      DI(1) => \derivative_reg[12]_i_25_n_7\,
      DI(0) => \derivative_reg[12]_i_30_n_4\,
      O(3) => \derivative_reg[11]_i_25_n_4\,
      O(2) => \derivative_reg[11]_i_25_n_5\,
      O(1) => \derivative_reg[11]_i_25_n_6\,
      O(0) => \derivative_reg[11]_i_25_n_7\,
      S(3) => \derivative[11]_i_31_n_0\,
      S(2) => \derivative[11]_i_32_n_0\,
      S(1) => \derivative[11]_i_33_n_0\,
      S(0) => \derivative[11]_i_34_n_0\
    );
\derivative_reg[11]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_35_n_0\,
      CO(3) => \derivative_reg[11]_i_30_n_0\,
      CO(2) => \derivative_reg[11]_i_30_n_1\,
      CO(1) => \derivative_reg[11]_i_30_n_2\,
      CO(0) => \derivative_reg[11]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[12]_i_30_n_5\,
      DI(2) => \derivative_reg[12]_i_30_n_6\,
      DI(1) => \derivative_reg[12]_i_30_n_7\,
      DI(0) => \derivative_reg[12]_i_35_n_4\,
      O(3) => \derivative_reg[11]_i_30_n_4\,
      O(2) => \derivative_reg[11]_i_30_n_5\,
      O(1) => \derivative_reg[11]_i_30_n_6\,
      O(0) => \derivative_reg[11]_i_30_n_7\,
      S(3) => \derivative[11]_i_36_n_0\,
      S(2) => \derivative[11]_i_37_n_0\,
      S(1) => \derivative[11]_i_38_n_0\,
      S(0) => \derivative[11]_i_39_n_0\
    );
\derivative_reg[11]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[11]_i_35_n_0\,
      CO(2) => \derivative_reg[11]_i_35_n_1\,
      CO(1) => \derivative_reg[11]_i_35_n_2\,
      CO(0) => \derivative_reg[11]_i_35_n_3\,
      CYINIT => \derivative_reg[12]_i_1_n_2\,
      DI(3) => \derivative_reg[12]_i_35_n_5\,
      DI(2) => \derivative_reg[12]_i_35_n_6\,
      DI(1) => derivative11_out(11),
      DI(0) => '0',
      O(3) => \derivative_reg[11]_i_35_n_4\,
      O(2) => \derivative_reg[11]_i_35_n_5\,
      O(1) => \derivative_reg[11]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[11]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[11]_i_40_n_0\,
      S(2) => \derivative[11]_i_41_n_0\,
      S(1) => \derivative[11]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[11]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[11]_i_10_n_0\,
      CO(3) => \derivative_reg[11]_i_5_n_0\,
      CO(2) => \derivative_reg[11]_i_5_n_1\,
      CO(1) => \derivative_reg[11]_i_5_n_2\,
      CO(0) => \derivative_reg[11]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[12]_i_5_n_5\,
      DI(2) => \derivative_reg[12]_i_5_n_6\,
      DI(1) => \derivative_reg[12]_i_5_n_7\,
      DI(0) => \derivative_reg[12]_i_10_n_4\,
      O(3) => \derivative_reg[11]_i_5_n_4\,
      O(2) => \derivative_reg[11]_i_5_n_5\,
      O(1) => \derivative_reg[11]_i_5_n_6\,
      O(0) => \derivative_reg[11]_i_5_n_7\,
      S(3) => \derivative[11]_i_11_n_0\,
      S(2) => \derivative[11]_i_12_n_0\,
      S(1) => \derivative[11]_i_13_n_0\,
      S(0) => \derivative[11]_i_14_n_0\
    );
\derivative_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[12]_i_1_n_2\,
      Q => derivative_out(12),
      R => '0'
    );
\derivative_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[12]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[12]_i_1_n_2\,
      CO(0) => \derivative_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[13]_i_1_n_2\,
      DI(0) => \derivative_reg[13]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[12]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[12]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[12]_i_3_n_0\,
      S(0) => \derivative[12]_i_4_n_0\
    );
\derivative_reg[12]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_15_n_0\,
      CO(3) => \derivative_reg[12]_i_10_n_0\,
      CO(2) => \derivative_reg[12]_i_10_n_1\,
      CO(1) => \derivative_reg[12]_i_10_n_2\,
      CO(0) => \derivative_reg[12]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[13]_i_10_n_5\,
      DI(2) => \derivative_reg[13]_i_10_n_6\,
      DI(1) => \derivative_reg[13]_i_10_n_7\,
      DI(0) => \derivative_reg[13]_i_15_n_4\,
      O(3) => \derivative_reg[12]_i_10_n_4\,
      O(2) => \derivative_reg[12]_i_10_n_5\,
      O(1) => \derivative_reg[12]_i_10_n_6\,
      O(0) => \derivative_reg[12]_i_10_n_7\,
      S(3) => \derivative[12]_i_16_n_0\,
      S(2) => \derivative[12]_i_17_n_0\,
      S(1) => \derivative[12]_i_18_n_0\,
      S(0) => \derivative[12]_i_19_n_0\
    );
\derivative_reg[12]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_20_n_0\,
      CO(3) => \derivative_reg[12]_i_15_n_0\,
      CO(2) => \derivative_reg[12]_i_15_n_1\,
      CO(1) => \derivative_reg[12]_i_15_n_2\,
      CO(0) => \derivative_reg[12]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[13]_i_15_n_5\,
      DI(2) => \derivative_reg[13]_i_15_n_6\,
      DI(1) => \derivative_reg[13]_i_15_n_7\,
      DI(0) => \derivative_reg[13]_i_20_n_4\,
      O(3) => \derivative_reg[12]_i_15_n_4\,
      O(2) => \derivative_reg[12]_i_15_n_5\,
      O(1) => \derivative_reg[12]_i_15_n_6\,
      O(0) => \derivative_reg[12]_i_15_n_7\,
      S(3) => \derivative[12]_i_21_n_0\,
      S(2) => \derivative[12]_i_22_n_0\,
      S(1) => \derivative[12]_i_23_n_0\,
      S(0) => \derivative[12]_i_24_n_0\
    );
\derivative_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_5_n_0\,
      CO(3) => \derivative_reg[12]_i_2_n_0\,
      CO(2) => \derivative_reg[12]_i_2_n_1\,
      CO(1) => \derivative_reg[12]_i_2_n_2\,
      CO(0) => \derivative_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[13]_i_2_n_5\,
      DI(2) => \derivative_reg[13]_i_2_n_6\,
      DI(1) => \derivative_reg[13]_i_2_n_7\,
      DI(0) => \derivative_reg[13]_i_5_n_4\,
      O(3) => \derivative_reg[12]_i_2_n_4\,
      O(2) => \derivative_reg[12]_i_2_n_5\,
      O(1) => \derivative_reg[12]_i_2_n_6\,
      O(0) => \derivative_reg[12]_i_2_n_7\,
      S(3) => \derivative[12]_i_6_n_0\,
      S(2) => \derivative[12]_i_7_n_0\,
      S(1) => \derivative[12]_i_8_n_0\,
      S(0) => \derivative[12]_i_9_n_0\
    );
\derivative_reg[12]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_25_n_0\,
      CO(3) => \derivative_reg[12]_i_20_n_0\,
      CO(2) => \derivative_reg[12]_i_20_n_1\,
      CO(1) => \derivative_reg[12]_i_20_n_2\,
      CO(0) => \derivative_reg[12]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[13]_i_20_n_5\,
      DI(2) => \derivative_reg[13]_i_20_n_6\,
      DI(1) => \derivative_reg[13]_i_20_n_7\,
      DI(0) => \derivative_reg[13]_i_25_n_4\,
      O(3) => \derivative_reg[12]_i_20_n_4\,
      O(2) => \derivative_reg[12]_i_20_n_5\,
      O(1) => \derivative_reg[12]_i_20_n_6\,
      O(0) => \derivative_reg[12]_i_20_n_7\,
      S(3) => \derivative[12]_i_26_n_0\,
      S(2) => \derivative[12]_i_27_n_0\,
      S(1) => \derivative[12]_i_28_n_0\,
      S(0) => \derivative[12]_i_29_n_0\
    );
\derivative_reg[12]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_30_n_0\,
      CO(3) => \derivative_reg[12]_i_25_n_0\,
      CO(2) => \derivative_reg[12]_i_25_n_1\,
      CO(1) => \derivative_reg[12]_i_25_n_2\,
      CO(0) => \derivative_reg[12]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[13]_i_25_n_5\,
      DI(2) => \derivative_reg[13]_i_25_n_6\,
      DI(1) => \derivative_reg[13]_i_25_n_7\,
      DI(0) => \derivative_reg[13]_i_30_n_4\,
      O(3) => \derivative_reg[12]_i_25_n_4\,
      O(2) => \derivative_reg[12]_i_25_n_5\,
      O(1) => \derivative_reg[12]_i_25_n_6\,
      O(0) => \derivative_reg[12]_i_25_n_7\,
      S(3) => \derivative[12]_i_31_n_0\,
      S(2) => \derivative[12]_i_32_n_0\,
      S(1) => \derivative[12]_i_33_n_0\,
      S(0) => \derivative[12]_i_34_n_0\
    );
\derivative_reg[12]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_35_n_0\,
      CO(3) => \derivative_reg[12]_i_30_n_0\,
      CO(2) => \derivative_reg[12]_i_30_n_1\,
      CO(1) => \derivative_reg[12]_i_30_n_2\,
      CO(0) => \derivative_reg[12]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[13]_i_30_n_5\,
      DI(2) => \derivative_reg[13]_i_30_n_6\,
      DI(1) => \derivative_reg[13]_i_30_n_7\,
      DI(0) => \derivative_reg[13]_i_35_n_4\,
      O(3) => \derivative_reg[12]_i_30_n_4\,
      O(2) => \derivative_reg[12]_i_30_n_5\,
      O(1) => \derivative_reg[12]_i_30_n_6\,
      O(0) => \derivative_reg[12]_i_30_n_7\,
      S(3) => \derivative[12]_i_36_n_0\,
      S(2) => \derivative[12]_i_37_n_0\,
      S(1) => \derivative[12]_i_38_n_0\,
      S(0) => \derivative[12]_i_39_n_0\
    );
\derivative_reg[12]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[12]_i_35_n_0\,
      CO(2) => \derivative_reg[12]_i_35_n_1\,
      CO(1) => \derivative_reg[12]_i_35_n_2\,
      CO(0) => \derivative_reg[12]_i_35_n_3\,
      CYINIT => \derivative_reg[13]_i_1_n_2\,
      DI(3) => \derivative_reg[13]_i_35_n_5\,
      DI(2) => \derivative_reg[13]_i_35_n_6\,
      DI(1) => derivative11_out(12),
      DI(0) => '0',
      O(3) => \derivative_reg[12]_i_35_n_4\,
      O(2) => \derivative_reg[12]_i_35_n_5\,
      O(1) => \derivative_reg[12]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[12]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[12]_i_40_n_0\,
      S(2) => \derivative[12]_i_41_n_0\,
      S(1) => \derivative[12]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[12]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[12]_i_10_n_0\,
      CO(3) => \derivative_reg[12]_i_5_n_0\,
      CO(2) => \derivative_reg[12]_i_5_n_1\,
      CO(1) => \derivative_reg[12]_i_5_n_2\,
      CO(0) => \derivative_reg[12]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[13]_i_5_n_5\,
      DI(2) => \derivative_reg[13]_i_5_n_6\,
      DI(1) => \derivative_reg[13]_i_5_n_7\,
      DI(0) => \derivative_reg[13]_i_10_n_4\,
      O(3) => \derivative_reg[12]_i_5_n_4\,
      O(2) => \derivative_reg[12]_i_5_n_5\,
      O(1) => \derivative_reg[12]_i_5_n_6\,
      O(0) => \derivative_reg[12]_i_5_n_7\,
      S(3) => \derivative[12]_i_11_n_0\,
      S(2) => \derivative[12]_i_12_n_0\,
      S(1) => \derivative[12]_i_13_n_0\,
      S(0) => \derivative[12]_i_14_n_0\
    );
\derivative_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[13]_i_1_n_2\,
      Q => derivative_out(13),
      R => '0'
    );
\derivative_reg[13]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[13]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[13]_i_1_n_2\,
      CO(0) => \derivative_reg[13]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[14]_i_1_n_2\,
      DI(0) => \derivative_reg[14]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[13]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[13]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[13]_i_3_n_0\,
      S(0) => \derivative[13]_i_4_n_0\
    );
\derivative_reg[13]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_15_n_0\,
      CO(3) => \derivative_reg[13]_i_10_n_0\,
      CO(2) => \derivative_reg[13]_i_10_n_1\,
      CO(1) => \derivative_reg[13]_i_10_n_2\,
      CO(0) => \derivative_reg[13]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[14]_i_10_n_5\,
      DI(2) => \derivative_reg[14]_i_10_n_6\,
      DI(1) => \derivative_reg[14]_i_10_n_7\,
      DI(0) => \derivative_reg[14]_i_15_n_4\,
      O(3) => \derivative_reg[13]_i_10_n_4\,
      O(2) => \derivative_reg[13]_i_10_n_5\,
      O(1) => \derivative_reg[13]_i_10_n_6\,
      O(0) => \derivative_reg[13]_i_10_n_7\,
      S(3) => \derivative[13]_i_16_n_0\,
      S(2) => \derivative[13]_i_17_n_0\,
      S(1) => \derivative[13]_i_18_n_0\,
      S(0) => \derivative[13]_i_19_n_0\
    );
\derivative_reg[13]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_20_n_0\,
      CO(3) => \derivative_reg[13]_i_15_n_0\,
      CO(2) => \derivative_reg[13]_i_15_n_1\,
      CO(1) => \derivative_reg[13]_i_15_n_2\,
      CO(0) => \derivative_reg[13]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[14]_i_15_n_5\,
      DI(2) => \derivative_reg[14]_i_15_n_6\,
      DI(1) => \derivative_reg[14]_i_15_n_7\,
      DI(0) => \derivative_reg[14]_i_20_n_4\,
      O(3) => \derivative_reg[13]_i_15_n_4\,
      O(2) => \derivative_reg[13]_i_15_n_5\,
      O(1) => \derivative_reg[13]_i_15_n_6\,
      O(0) => \derivative_reg[13]_i_15_n_7\,
      S(3) => \derivative[13]_i_21_n_0\,
      S(2) => \derivative[13]_i_22_n_0\,
      S(1) => \derivative[13]_i_23_n_0\,
      S(0) => \derivative[13]_i_24_n_0\
    );
\derivative_reg[13]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_5_n_0\,
      CO(3) => \derivative_reg[13]_i_2_n_0\,
      CO(2) => \derivative_reg[13]_i_2_n_1\,
      CO(1) => \derivative_reg[13]_i_2_n_2\,
      CO(0) => \derivative_reg[13]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[14]_i_2_n_5\,
      DI(2) => \derivative_reg[14]_i_2_n_6\,
      DI(1) => \derivative_reg[14]_i_2_n_7\,
      DI(0) => \derivative_reg[14]_i_5_n_4\,
      O(3) => \derivative_reg[13]_i_2_n_4\,
      O(2) => \derivative_reg[13]_i_2_n_5\,
      O(1) => \derivative_reg[13]_i_2_n_6\,
      O(0) => \derivative_reg[13]_i_2_n_7\,
      S(3) => \derivative[13]_i_6_n_0\,
      S(2) => \derivative[13]_i_7_n_0\,
      S(1) => \derivative[13]_i_8_n_0\,
      S(0) => \derivative[13]_i_9_n_0\
    );
\derivative_reg[13]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_25_n_0\,
      CO(3) => \derivative_reg[13]_i_20_n_0\,
      CO(2) => \derivative_reg[13]_i_20_n_1\,
      CO(1) => \derivative_reg[13]_i_20_n_2\,
      CO(0) => \derivative_reg[13]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[14]_i_20_n_5\,
      DI(2) => \derivative_reg[14]_i_20_n_6\,
      DI(1) => \derivative_reg[14]_i_20_n_7\,
      DI(0) => \derivative_reg[14]_i_25_n_4\,
      O(3) => \derivative_reg[13]_i_20_n_4\,
      O(2) => \derivative_reg[13]_i_20_n_5\,
      O(1) => \derivative_reg[13]_i_20_n_6\,
      O(0) => \derivative_reg[13]_i_20_n_7\,
      S(3) => \derivative[13]_i_26_n_0\,
      S(2) => \derivative[13]_i_27_n_0\,
      S(1) => \derivative[13]_i_28_n_0\,
      S(0) => \derivative[13]_i_29_n_0\
    );
\derivative_reg[13]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_30_n_0\,
      CO(3) => \derivative_reg[13]_i_25_n_0\,
      CO(2) => \derivative_reg[13]_i_25_n_1\,
      CO(1) => \derivative_reg[13]_i_25_n_2\,
      CO(0) => \derivative_reg[13]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[14]_i_25_n_5\,
      DI(2) => \derivative_reg[14]_i_25_n_6\,
      DI(1) => \derivative_reg[14]_i_25_n_7\,
      DI(0) => \derivative_reg[14]_i_30_n_4\,
      O(3) => \derivative_reg[13]_i_25_n_4\,
      O(2) => \derivative_reg[13]_i_25_n_5\,
      O(1) => \derivative_reg[13]_i_25_n_6\,
      O(0) => \derivative_reg[13]_i_25_n_7\,
      S(3) => \derivative[13]_i_31_n_0\,
      S(2) => \derivative[13]_i_32_n_0\,
      S(1) => \derivative[13]_i_33_n_0\,
      S(0) => \derivative[13]_i_34_n_0\
    );
\derivative_reg[13]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_35_n_0\,
      CO(3) => \derivative_reg[13]_i_30_n_0\,
      CO(2) => \derivative_reg[13]_i_30_n_1\,
      CO(1) => \derivative_reg[13]_i_30_n_2\,
      CO(0) => \derivative_reg[13]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[14]_i_30_n_5\,
      DI(2) => \derivative_reg[14]_i_30_n_6\,
      DI(1) => \derivative_reg[14]_i_30_n_7\,
      DI(0) => \derivative_reg[14]_i_35_n_4\,
      O(3) => \derivative_reg[13]_i_30_n_4\,
      O(2) => \derivative_reg[13]_i_30_n_5\,
      O(1) => \derivative_reg[13]_i_30_n_6\,
      O(0) => \derivative_reg[13]_i_30_n_7\,
      S(3) => \derivative[13]_i_36_n_0\,
      S(2) => \derivative[13]_i_37_n_0\,
      S(1) => \derivative[13]_i_38_n_0\,
      S(0) => \derivative[13]_i_39_n_0\
    );
\derivative_reg[13]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[13]_i_35_n_0\,
      CO(2) => \derivative_reg[13]_i_35_n_1\,
      CO(1) => \derivative_reg[13]_i_35_n_2\,
      CO(0) => \derivative_reg[13]_i_35_n_3\,
      CYINIT => \derivative_reg[14]_i_1_n_2\,
      DI(3) => \derivative_reg[14]_i_35_n_5\,
      DI(2) => \derivative_reg[14]_i_35_n_6\,
      DI(1) => derivative11_out(13),
      DI(0) => '0',
      O(3) => \derivative_reg[13]_i_35_n_4\,
      O(2) => \derivative_reg[13]_i_35_n_5\,
      O(1) => \derivative_reg[13]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[13]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[13]_i_40_n_0\,
      S(2) => \derivative[13]_i_41_n_0\,
      S(1) => \derivative[13]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[13]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[13]_i_10_n_0\,
      CO(3) => \derivative_reg[13]_i_5_n_0\,
      CO(2) => \derivative_reg[13]_i_5_n_1\,
      CO(1) => \derivative_reg[13]_i_5_n_2\,
      CO(0) => \derivative_reg[13]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[14]_i_5_n_5\,
      DI(2) => \derivative_reg[14]_i_5_n_6\,
      DI(1) => \derivative_reg[14]_i_5_n_7\,
      DI(0) => \derivative_reg[14]_i_10_n_4\,
      O(3) => \derivative_reg[13]_i_5_n_4\,
      O(2) => \derivative_reg[13]_i_5_n_5\,
      O(1) => \derivative_reg[13]_i_5_n_6\,
      O(0) => \derivative_reg[13]_i_5_n_7\,
      S(3) => \derivative[13]_i_11_n_0\,
      S(2) => \derivative[13]_i_12_n_0\,
      S(1) => \derivative[13]_i_13_n_0\,
      S(0) => \derivative[13]_i_14_n_0\
    );
\derivative_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[14]_i_1_n_2\,
      Q => derivative_out(14),
      R => '0'
    );
\derivative_reg[14]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[14]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[14]_i_1_n_2\,
      CO(0) => \derivative_reg[14]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[15]_i_1_n_2\,
      DI(0) => \derivative_reg[15]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[14]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[14]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[14]_i_3_n_0\,
      S(0) => \derivative[14]_i_4_n_0\
    );
\derivative_reg[14]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_15_n_0\,
      CO(3) => \derivative_reg[14]_i_10_n_0\,
      CO(2) => \derivative_reg[14]_i_10_n_1\,
      CO(1) => \derivative_reg[14]_i_10_n_2\,
      CO(0) => \derivative_reg[14]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[15]_i_10_n_5\,
      DI(2) => \derivative_reg[15]_i_10_n_6\,
      DI(1) => \derivative_reg[15]_i_10_n_7\,
      DI(0) => \derivative_reg[15]_i_15_n_4\,
      O(3) => \derivative_reg[14]_i_10_n_4\,
      O(2) => \derivative_reg[14]_i_10_n_5\,
      O(1) => \derivative_reg[14]_i_10_n_6\,
      O(0) => \derivative_reg[14]_i_10_n_7\,
      S(3) => \derivative[14]_i_16_n_0\,
      S(2) => \derivative[14]_i_17_n_0\,
      S(1) => \derivative[14]_i_18_n_0\,
      S(0) => \derivative[14]_i_19_n_0\
    );
\derivative_reg[14]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_20_n_0\,
      CO(3) => \derivative_reg[14]_i_15_n_0\,
      CO(2) => \derivative_reg[14]_i_15_n_1\,
      CO(1) => \derivative_reg[14]_i_15_n_2\,
      CO(0) => \derivative_reg[14]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[15]_i_15_n_5\,
      DI(2) => \derivative_reg[15]_i_15_n_6\,
      DI(1) => \derivative_reg[15]_i_15_n_7\,
      DI(0) => \derivative_reg[15]_i_20_n_4\,
      O(3) => \derivative_reg[14]_i_15_n_4\,
      O(2) => \derivative_reg[14]_i_15_n_5\,
      O(1) => \derivative_reg[14]_i_15_n_6\,
      O(0) => \derivative_reg[14]_i_15_n_7\,
      S(3) => \derivative[14]_i_21_n_0\,
      S(2) => \derivative[14]_i_22_n_0\,
      S(1) => \derivative[14]_i_23_n_0\,
      S(0) => \derivative[14]_i_24_n_0\
    );
\derivative_reg[14]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_5_n_0\,
      CO(3) => \derivative_reg[14]_i_2_n_0\,
      CO(2) => \derivative_reg[14]_i_2_n_1\,
      CO(1) => \derivative_reg[14]_i_2_n_2\,
      CO(0) => \derivative_reg[14]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[15]_i_2_n_5\,
      DI(2) => \derivative_reg[15]_i_2_n_6\,
      DI(1) => \derivative_reg[15]_i_2_n_7\,
      DI(0) => \derivative_reg[15]_i_5_n_4\,
      O(3) => \derivative_reg[14]_i_2_n_4\,
      O(2) => \derivative_reg[14]_i_2_n_5\,
      O(1) => \derivative_reg[14]_i_2_n_6\,
      O(0) => \derivative_reg[14]_i_2_n_7\,
      S(3) => \derivative[14]_i_6_n_0\,
      S(2) => \derivative[14]_i_7_n_0\,
      S(1) => \derivative[14]_i_8_n_0\,
      S(0) => \derivative[14]_i_9_n_0\
    );
\derivative_reg[14]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_25_n_0\,
      CO(3) => \derivative_reg[14]_i_20_n_0\,
      CO(2) => \derivative_reg[14]_i_20_n_1\,
      CO(1) => \derivative_reg[14]_i_20_n_2\,
      CO(0) => \derivative_reg[14]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[15]_i_20_n_5\,
      DI(2) => \derivative_reg[15]_i_20_n_6\,
      DI(1) => \derivative_reg[15]_i_20_n_7\,
      DI(0) => \derivative_reg[15]_i_25_n_4\,
      O(3) => \derivative_reg[14]_i_20_n_4\,
      O(2) => \derivative_reg[14]_i_20_n_5\,
      O(1) => \derivative_reg[14]_i_20_n_6\,
      O(0) => \derivative_reg[14]_i_20_n_7\,
      S(3) => \derivative[14]_i_26_n_0\,
      S(2) => \derivative[14]_i_27_n_0\,
      S(1) => \derivative[14]_i_28_n_0\,
      S(0) => \derivative[14]_i_29_n_0\
    );
\derivative_reg[14]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_30_n_0\,
      CO(3) => \derivative_reg[14]_i_25_n_0\,
      CO(2) => \derivative_reg[14]_i_25_n_1\,
      CO(1) => \derivative_reg[14]_i_25_n_2\,
      CO(0) => \derivative_reg[14]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[15]_i_25_n_5\,
      DI(2) => \derivative_reg[15]_i_25_n_6\,
      DI(1) => \derivative_reg[15]_i_25_n_7\,
      DI(0) => \derivative_reg[15]_i_30_n_4\,
      O(3) => \derivative_reg[14]_i_25_n_4\,
      O(2) => \derivative_reg[14]_i_25_n_5\,
      O(1) => \derivative_reg[14]_i_25_n_6\,
      O(0) => \derivative_reg[14]_i_25_n_7\,
      S(3) => \derivative[14]_i_31_n_0\,
      S(2) => \derivative[14]_i_32_n_0\,
      S(1) => \derivative[14]_i_33_n_0\,
      S(0) => \derivative[14]_i_34_n_0\
    );
\derivative_reg[14]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_35_n_0\,
      CO(3) => \derivative_reg[14]_i_30_n_0\,
      CO(2) => \derivative_reg[14]_i_30_n_1\,
      CO(1) => \derivative_reg[14]_i_30_n_2\,
      CO(0) => \derivative_reg[14]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[15]_i_30_n_5\,
      DI(2) => \derivative_reg[15]_i_30_n_6\,
      DI(1) => \derivative_reg[15]_i_30_n_7\,
      DI(0) => \derivative_reg[15]_i_35_n_4\,
      O(3) => \derivative_reg[14]_i_30_n_4\,
      O(2) => \derivative_reg[14]_i_30_n_5\,
      O(1) => \derivative_reg[14]_i_30_n_6\,
      O(0) => \derivative_reg[14]_i_30_n_7\,
      S(3) => \derivative[14]_i_36_n_0\,
      S(2) => \derivative[14]_i_37_n_0\,
      S(1) => \derivative[14]_i_38_n_0\,
      S(0) => \derivative[14]_i_39_n_0\
    );
\derivative_reg[14]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[14]_i_35_n_0\,
      CO(2) => \derivative_reg[14]_i_35_n_1\,
      CO(1) => \derivative_reg[14]_i_35_n_2\,
      CO(0) => \derivative_reg[14]_i_35_n_3\,
      CYINIT => \derivative_reg[15]_i_1_n_2\,
      DI(3) => \derivative_reg[15]_i_35_n_5\,
      DI(2) => \derivative_reg[15]_i_35_n_6\,
      DI(1) => derivative11_out(14),
      DI(0) => '0',
      O(3) => \derivative_reg[14]_i_35_n_4\,
      O(2) => \derivative_reg[14]_i_35_n_5\,
      O(1) => \derivative_reg[14]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[14]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[14]_i_40_n_0\,
      S(2) => \derivative[14]_i_41_n_0\,
      S(1) => \derivative[14]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[14]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[14]_i_10_n_0\,
      CO(3) => \derivative_reg[14]_i_5_n_0\,
      CO(2) => \derivative_reg[14]_i_5_n_1\,
      CO(1) => \derivative_reg[14]_i_5_n_2\,
      CO(0) => \derivative_reg[14]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[15]_i_5_n_5\,
      DI(2) => \derivative_reg[15]_i_5_n_6\,
      DI(1) => \derivative_reg[15]_i_5_n_7\,
      DI(0) => \derivative_reg[15]_i_10_n_4\,
      O(3) => \derivative_reg[14]_i_5_n_4\,
      O(2) => \derivative_reg[14]_i_5_n_5\,
      O(1) => \derivative_reg[14]_i_5_n_6\,
      O(0) => \derivative_reg[14]_i_5_n_7\,
      S(3) => \derivative[14]_i_11_n_0\,
      S(2) => \derivative[14]_i_12_n_0\,
      S(1) => \derivative[14]_i_13_n_0\,
      S(0) => \derivative[14]_i_14_n_0\
    );
\derivative_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[15]_i_1_n_2\,
      Q => derivative_out(15),
      R => '0'
    );
\derivative_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[15]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[15]_i_1_n_2\,
      CO(0) => \derivative_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[16]_i_1_n_2\,
      DI(0) => \derivative_reg[16]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[15]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[15]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[15]_i_3_n_0\,
      S(0) => \derivative[15]_i_4_n_0\
    );
\derivative_reg[15]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_15_n_0\,
      CO(3) => \derivative_reg[15]_i_10_n_0\,
      CO(2) => \derivative_reg[15]_i_10_n_1\,
      CO(1) => \derivative_reg[15]_i_10_n_2\,
      CO(0) => \derivative_reg[15]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[16]_i_10_n_5\,
      DI(2) => \derivative_reg[16]_i_10_n_6\,
      DI(1) => \derivative_reg[16]_i_10_n_7\,
      DI(0) => \derivative_reg[16]_i_15_n_4\,
      O(3) => \derivative_reg[15]_i_10_n_4\,
      O(2) => \derivative_reg[15]_i_10_n_5\,
      O(1) => \derivative_reg[15]_i_10_n_6\,
      O(0) => \derivative_reg[15]_i_10_n_7\,
      S(3) => \derivative[15]_i_16_n_0\,
      S(2) => \derivative[15]_i_17_n_0\,
      S(1) => \derivative[15]_i_18_n_0\,
      S(0) => \derivative[15]_i_19_n_0\
    );
\derivative_reg[15]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_20_n_0\,
      CO(3) => \derivative_reg[15]_i_15_n_0\,
      CO(2) => \derivative_reg[15]_i_15_n_1\,
      CO(1) => \derivative_reg[15]_i_15_n_2\,
      CO(0) => \derivative_reg[15]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[16]_i_15_n_5\,
      DI(2) => \derivative_reg[16]_i_15_n_6\,
      DI(1) => \derivative_reg[16]_i_15_n_7\,
      DI(0) => \derivative_reg[16]_i_20_n_4\,
      O(3) => \derivative_reg[15]_i_15_n_4\,
      O(2) => \derivative_reg[15]_i_15_n_5\,
      O(1) => \derivative_reg[15]_i_15_n_6\,
      O(0) => \derivative_reg[15]_i_15_n_7\,
      S(3) => \derivative[15]_i_21_n_0\,
      S(2) => \derivative[15]_i_22_n_0\,
      S(1) => \derivative[15]_i_23_n_0\,
      S(0) => \derivative[15]_i_24_n_0\
    );
\derivative_reg[15]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_5_n_0\,
      CO(3) => \derivative_reg[15]_i_2_n_0\,
      CO(2) => \derivative_reg[15]_i_2_n_1\,
      CO(1) => \derivative_reg[15]_i_2_n_2\,
      CO(0) => \derivative_reg[15]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[16]_i_2_n_5\,
      DI(2) => \derivative_reg[16]_i_2_n_6\,
      DI(1) => \derivative_reg[16]_i_2_n_7\,
      DI(0) => \derivative_reg[16]_i_5_n_4\,
      O(3) => \derivative_reg[15]_i_2_n_4\,
      O(2) => \derivative_reg[15]_i_2_n_5\,
      O(1) => \derivative_reg[15]_i_2_n_6\,
      O(0) => \derivative_reg[15]_i_2_n_7\,
      S(3) => \derivative[15]_i_6_n_0\,
      S(2) => \derivative[15]_i_7_n_0\,
      S(1) => \derivative[15]_i_8_n_0\,
      S(0) => \derivative[15]_i_9_n_0\
    );
\derivative_reg[15]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_25_n_0\,
      CO(3) => \derivative_reg[15]_i_20_n_0\,
      CO(2) => \derivative_reg[15]_i_20_n_1\,
      CO(1) => \derivative_reg[15]_i_20_n_2\,
      CO(0) => \derivative_reg[15]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[16]_i_20_n_5\,
      DI(2) => \derivative_reg[16]_i_20_n_6\,
      DI(1) => \derivative_reg[16]_i_20_n_7\,
      DI(0) => \derivative_reg[16]_i_25_n_4\,
      O(3) => \derivative_reg[15]_i_20_n_4\,
      O(2) => \derivative_reg[15]_i_20_n_5\,
      O(1) => \derivative_reg[15]_i_20_n_6\,
      O(0) => \derivative_reg[15]_i_20_n_7\,
      S(3) => \derivative[15]_i_26_n_0\,
      S(2) => \derivative[15]_i_27_n_0\,
      S(1) => \derivative[15]_i_28_n_0\,
      S(0) => \derivative[15]_i_29_n_0\
    );
\derivative_reg[15]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_30_n_0\,
      CO(3) => \derivative_reg[15]_i_25_n_0\,
      CO(2) => \derivative_reg[15]_i_25_n_1\,
      CO(1) => \derivative_reg[15]_i_25_n_2\,
      CO(0) => \derivative_reg[15]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[16]_i_25_n_5\,
      DI(2) => \derivative_reg[16]_i_25_n_6\,
      DI(1) => \derivative_reg[16]_i_25_n_7\,
      DI(0) => \derivative_reg[16]_i_30_n_4\,
      O(3) => \derivative_reg[15]_i_25_n_4\,
      O(2) => \derivative_reg[15]_i_25_n_5\,
      O(1) => \derivative_reg[15]_i_25_n_6\,
      O(0) => \derivative_reg[15]_i_25_n_7\,
      S(3) => \derivative[15]_i_31_n_0\,
      S(2) => \derivative[15]_i_32_n_0\,
      S(1) => \derivative[15]_i_33_n_0\,
      S(0) => \derivative[15]_i_34_n_0\
    );
\derivative_reg[15]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_35_n_0\,
      CO(3) => \derivative_reg[15]_i_30_n_0\,
      CO(2) => \derivative_reg[15]_i_30_n_1\,
      CO(1) => \derivative_reg[15]_i_30_n_2\,
      CO(0) => \derivative_reg[15]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[16]_i_30_n_5\,
      DI(2) => \derivative_reg[16]_i_30_n_6\,
      DI(1) => \derivative_reg[16]_i_30_n_7\,
      DI(0) => \derivative_reg[16]_i_35_n_4\,
      O(3) => \derivative_reg[15]_i_30_n_4\,
      O(2) => \derivative_reg[15]_i_30_n_5\,
      O(1) => \derivative_reg[15]_i_30_n_6\,
      O(0) => \derivative_reg[15]_i_30_n_7\,
      S(3) => \derivative[15]_i_36_n_0\,
      S(2) => \derivative[15]_i_37_n_0\,
      S(1) => \derivative[15]_i_38_n_0\,
      S(0) => \derivative[15]_i_39_n_0\
    );
\derivative_reg[15]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[15]_i_35_n_0\,
      CO(2) => \derivative_reg[15]_i_35_n_1\,
      CO(1) => \derivative_reg[15]_i_35_n_2\,
      CO(0) => \derivative_reg[15]_i_35_n_3\,
      CYINIT => \derivative_reg[16]_i_1_n_2\,
      DI(3) => \derivative_reg[16]_i_35_n_5\,
      DI(2) => \derivative_reg[16]_i_35_n_6\,
      DI(1) => derivative11_out(15),
      DI(0) => '0',
      O(3) => \derivative_reg[15]_i_35_n_4\,
      O(2) => \derivative_reg[15]_i_35_n_5\,
      O(1) => \derivative_reg[15]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[15]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[15]_i_40_n_0\,
      S(2) => \derivative[15]_i_41_n_0\,
      S(1) => \derivative[15]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[15]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[15]_i_10_n_0\,
      CO(3) => \derivative_reg[15]_i_5_n_0\,
      CO(2) => \derivative_reg[15]_i_5_n_1\,
      CO(1) => \derivative_reg[15]_i_5_n_2\,
      CO(0) => \derivative_reg[15]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[16]_i_5_n_5\,
      DI(2) => \derivative_reg[16]_i_5_n_6\,
      DI(1) => \derivative_reg[16]_i_5_n_7\,
      DI(0) => \derivative_reg[16]_i_10_n_4\,
      O(3) => \derivative_reg[15]_i_5_n_4\,
      O(2) => \derivative_reg[15]_i_5_n_5\,
      O(1) => \derivative_reg[15]_i_5_n_6\,
      O(0) => \derivative_reg[15]_i_5_n_7\,
      S(3) => \derivative[15]_i_11_n_0\,
      S(2) => \derivative[15]_i_12_n_0\,
      S(1) => \derivative[15]_i_13_n_0\,
      S(0) => \derivative[15]_i_14_n_0\
    );
\derivative_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[16]_i_1_n_2\,
      Q => derivative_out(16),
      R => '0'
    );
\derivative_reg[16]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[16]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[16]_i_1_n_2\,
      CO(0) => \derivative_reg[16]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[17]_i_1_n_2\,
      DI(0) => \derivative_reg[17]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[16]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[16]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[16]_i_3_n_0\,
      S(0) => \derivative[16]_i_4_n_0\
    );
\derivative_reg[16]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_15_n_0\,
      CO(3) => \derivative_reg[16]_i_10_n_0\,
      CO(2) => \derivative_reg[16]_i_10_n_1\,
      CO(1) => \derivative_reg[16]_i_10_n_2\,
      CO(0) => \derivative_reg[16]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[17]_i_10_n_5\,
      DI(2) => \derivative_reg[17]_i_10_n_6\,
      DI(1) => \derivative_reg[17]_i_10_n_7\,
      DI(0) => \derivative_reg[17]_i_15_n_4\,
      O(3) => \derivative_reg[16]_i_10_n_4\,
      O(2) => \derivative_reg[16]_i_10_n_5\,
      O(1) => \derivative_reg[16]_i_10_n_6\,
      O(0) => \derivative_reg[16]_i_10_n_7\,
      S(3) => \derivative[16]_i_16_n_0\,
      S(2) => \derivative[16]_i_17_n_0\,
      S(1) => \derivative[16]_i_18_n_0\,
      S(0) => \derivative[16]_i_19_n_0\
    );
\derivative_reg[16]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_20_n_0\,
      CO(3) => \derivative_reg[16]_i_15_n_0\,
      CO(2) => \derivative_reg[16]_i_15_n_1\,
      CO(1) => \derivative_reg[16]_i_15_n_2\,
      CO(0) => \derivative_reg[16]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[17]_i_15_n_5\,
      DI(2) => \derivative_reg[17]_i_15_n_6\,
      DI(1) => \derivative_reg[17]_i_15_n_7\,
      DI(0) => \derivative_reg[17]_i_20_n_4\,
      O(3) => \derivative_reg[16]_i_15_n_4\,
      O(2) => \derivative_reg[16]_i_15_n_5\,
      O(1) => \derivative_reg[16]_i_15_n_6\,
      O(0) => \derivative_reg[16]_i_15_n_7\,
      S(3) => \derivative[16]_i_21_n_0\,
      S(2) => \derivative[16]_i_22_n_0\,
      S(1) => \derivative[16]_i_23_n_0\,
      S(0) => \derivative[16]_i_24_n_0\
    );
\derivative_reg[16]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_5_n_0\,
      CO(3) => \derivative_reg[16]_i_2_n_0\,
      CO(2) => \derivative_reg[16]_i_2_n_1\,
      CO(1) => \derivative_reg[16]_i_2_n_2\,
      CO(0) => \derivative_reg[16]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[17]_i_2_n_5\,
      DI(2) => \derivative_reg[17]_i_2_n_6\,
      DI(1) => \derivative_reg[17]_i_2_n_7\,
      DI(0) => \derivative_reg[17]_i_5_n_4\,
      O(3) => \derivative_reg[16]_i_2_n_4\,
      O(2) => \derivative_reg[16]_i_2_n_5\,
      O(1) => \derivative_reg[16]_i_2_n_6\,
      O(0) => \derivative_reg[16]_i_2_n_7\,
      S(3) => \derivative[16]_i_6_n_0\,
      S(2) => \derivative[16]_i_7_n_0\,
      S(1) => \derivative[16]_i_8_n_0\,
      S(0) => \derivative[16]_i_9_n_0\
    );
\derivative_reg[16]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_25_n_0\,
      CO(3) => \derivative_reg[16]_i_20_n_0\,
      CO(2) => \derivative_reg[16]_i_20_n_1\,
      CO(1) => \derivative_reg[16]_i_20_n_2\,
      CO(0) => \derivative_reg[16]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[17]_i_20_n_5\,
      DI(2) => \derivative_reg[17]_i_20_n_6\,
      DI(1) => \derivative_reg[17]_i_20_n_7\,
      DI(0) => \derivative_reg[17]_i_25_n_4\,
      O(3) => \derivative_reg[16]_i_20_n_4\,
      O(2) => \derivative_reg[16]_i_20_n_5\,
      O(1) => \derivative_reg[16]_i_20_n_6\,
      O(0) => \derivative_reg[16]_i_20_n_7\,
      S(3) => \derivative[16]_i_26_n_0\,
      S(2) => \derivative[16]_i_27_n_0\,
      S(1) => \derivative[16]_i_28_n_0\,
      S(0) => \derivative[16]_i_29_n_0\
    );
\derivative_reg[16]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_30_n_0\,
      CO(3) => \derivative_reg[16]_i_25_n_0\,
      CO(2) => \derivative_reg[16]_i_25_n_1\,
      CO(1) => \derivative_reg[16]_i_25_n_2\,
      CO(0) => \derivative_reg[16]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[17]_i_25_n_5\,
      DI(2) => \derivative_reg[17]_i_25_n_6\,
      DI(1) => \derivative_reg[17]_i_25_n_7\,
      DI(0) => \derivative_reg[17]_i_30_n_4\,
      O(3) => \derivative_reg[16]_i_25_n_4\,
      O(2) => \derivative_reg[16]_i_25_n_5\,
      O(1) => \derivative_reg[16]_i_25_n_6\,
      O(0) => \derivative_reg[16]_i_25_n_7\,
      S(3) => \derivative[16]_i_31_n_0\,
      S(2) => \derivative[16]_i_32_n_0\,
      S(1) => \derivative[16]_i_33_n_0\,
      S(0) => \derivative[16]_i_34_n_0\
    );
\derivative_reg[16]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_35_n_0\,
      CO(3) => \derivative_reg[16]_i_30_n_0\,
      CO(2) => \derivative_reg[16]_i_30_n_1\,
      CO(1) => \derivative_reg[16]_i_30_n_2\,
      CO(0) => \derivative_reg[16]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[17]_i_30_n_5\,
      DI(2) => \derivative_reg[17]_i_30_n_6\,
      DI(1) => \derivative_reg[17]_i_30_n_7\,
      DI(0) => \derivative_reg[17]_i_35_n_4\,
      O(3) => \derivative_reg[16]_i_30_n_4\,
      O(2) => \derivative_reg[16]_i_30_n_5\,
      O(1) => \derivative_reg[16]_i_30_n_6\,
      O(0) => \derivative_reg[16]_i_30_n_7\,
      S(3) => \derivative[16]_i_36_n_0\,
      S(2) => \derivative[16]_i_37_n_0\,
      S(1) => \derivative[16]_i_38_n_0\,
      S(0) => \derivative[16]_i_39_n_0\
    );
\derivative_reg[16]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[16]_i_35_n_0\,
      CO(2) => \derivative_reg[16]_i_35_n_1\,
      CO(1) => \derivative_reg[16]_i_35_n_2\,
      CO(0) => \derivative_reg[16]_i_35_n_3\,
      CYINIT => \derivative_reg[17]_i_1_n_2\,
      DI(3) => \derivative_reg[17]_i_35_n_5\,
      DI(2) => \derivative_reg[17]_i_35_n_6\,
      DI(1) => derivative11_out(16),
      DI(0) => '0',
      O(3) => \derivative_reg[16]_i_35_n_4\,
      O(2) => \derivative_reg[16]_i_35_n_5\,
      O(1) => \derivative_reg[16]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[16]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[16]_i_40_n_0\,
      S(2) => \derivative[16]_i_41_n_0\,
      S(1) => \derivative[16]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[16]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[16]_i_10_n_0\,
      CO(3) => \derivative_reg[16]_i_5_n_0\,
      CO(2) => \derivative_reg[16]_i_5_n_1\,
      CO(1) => \derivative_reg[16]_i_5_n_2\,
      CO(0) => \derivative_reg[16]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[17]_i_5_n_5\,
      DI(2) => \derivative_reg[17]_i_5_n_6\,
      DI(1) => \derivative_reg[17]_i_5_n_7\,
      DI(0) => \derivative_reg[17]_i_10_n_4\,
      O(3) => \derivative_reg[16]_i_5_n_4\,
      O(2) => \derivative_reg[16]_i_5_n_5\,
      O(1) => \derivative_reg[16]_i_5_n_6\,
      O(0) => \derivative_reg[16]_i_5_n_7\,
      S(3) => \derivative[16]_i_11_n_0\,
      S(2) => \derivative[16]_i_12_n_0\,
      S(1) => \derivative[16]_i_13_n_0\,
      S(0) => \derivative[16]_i_14_n_0\
    );
\derivative_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[17]_i_1_n_2\,
      Q => derivative_out(17),
      R => '0'
    );
\derivative_reg[17]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[17]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[17]_i_1_n_2\,
      CO(0) => \derivative_reg[17]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[18]_i_1_n_2\,
      DI(0) => \derivative_reg[18]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[17]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[17]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[17]_i_3_n_0\,
      S(0) => \derivative[17]_i_4_n_0\
    );
\derivative_reg[17]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_15_n_0\,
      CO(3) => \derivative_reg[17]_i_10_n_0\,
      CO(2) => \derivative_reg[17]_i_10_n_1\,
      CO(1) => \derivative_reg[17]_i_10_n_2\,
      CO(0) => \derivative_reg[17]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[18]_i_10_n_5\,
      DI(2) => \derivative_reg[18]_i_10_n_6\,
      DI(1) => \derivative_reg[18]_i_10_n_7\,
      DI(0) => \derivative_reg[18]_i_15_n_4\,
      O(3) => \derivative_reg[17]_i_10_n_4\,
      O(2) => \derivative_reg[17]_i_10_n_5\,
      O(1) => \derivative_reg[17]_i_10_n_6\,
      O(0) => \derivative_reg[17]_i_10_n_7\,
      S(3) => \derivative[17]_i_16_n_0\,
      S(2) => \derivative[17]_i_17_n_0\,
      S(1) => \derivative[17]_i_18_n_0\,
      S(0) => \derivative[17]_i_19_n_0\
    );
\derivative_reg[17]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_20_n_0\,
      CO(3) => \derivative_reg[17]_i_15_n_0\,
      CO(2) => \derivative_reg[17]_i_15_n_1\,
      CO(1) => \derivative_reg[17]_i_15_n_2\,
      CO(0) => \derivative_reg[17]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[18]_i_15_n_5\,
      DI(2) => \derivative_reg[18]_i_15_n_6\,
      DI(1) => \derivative_reg[18]_i_15_n_7\,
      DI(0) => \derivative_reg[18]_i_20_n_4\,
      O(3) => \derivative_reg[17]_i_15_n_4\,
      O(2) => \derivative_reg[17]_i_15_n_5\,
      O(1) => \derivative_reg[17]_i_15_n_6\,
      O(0) => \derivative_reg[17]_i_15_n_7\,
      S(3) => \derivative[17]_i_21_n_0\,
      S(2) => \derivative[17]_i_22_n_0\,
      S(1) => \derivative[17]_i_23_n_0\,
      S(0) => \derivative[17]_i_24_n_0\
    );
\derivative_reg[17]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_5_n_0\,
      CO(3) => \derivative_reg[17]_i_2_n_0\,
      CO(2) => \derivative_reg[17]_i_2_n_1\,
      CO(1) => \derivative_reg[17]_i_2_n_2\,
      CO(0) => \derivative_reg[17]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[18]_i_2_n_5\,
      DI(2) => \derivative_reg[18]_i_2_n_6\,
      DI(1) => \derivative_reg[18]_i_2_n_7\,
      DI(0) => \derivative_reg[18]_i_5_n_4\,
      O(3) => \derivative_reg[17]_i_2_n_4\,
      O(2) => \derivative_reg[17]_i_2_n_5\,
      O(1) => \derivative_reg[17]_i_2_n_6\,
      O(0) => \derivative_reg[17]_i_2_n_7\,
      S(3) => \derivative[17]_i_6_n_0\,
      S(2) => \derivative[17]_i_7_n_0\,
      S(1) => \derivative[17]_i_8_n_0\,
      S(0) => \derivative[17]_i_9_n_0\
    );
\derivative_reg[17]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_25_n_0\,
      CO(3) => \derivative_reg[17]_i_20_n_0\,
      CO(2) => \derivative_reg[17]_i_20_n_1\,
      CO(1) => \derivative_reg[17]_i_20_n_2\,
      CO(0) => \derivative_reg[17]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[18]_i_20_n_5\,
      DI(2) => \derivative_reg[18]_i_20_n_6\,
      DI(1) => \derivative_reg[18]_i_20_n_7\,
      DI(0) => \derivative_reg[18]_i_25_n_4\,
      O(3) => \derivative_reg[17]_i_20_n_4\,
      O(2) => \derivative_reg[17]_i_20_n_5\,
      O(1) => \derivative_reg[17]_i_20_n_6\,
      O(0) => \derivative_reg[17]_i_20_n_7\,
      S(3) => \derivative[17]_i_26_n_0\,
      S(2) => \derivative[17]_i_27_n_0\,
      S(1) => \derivative[17]_i_28_n_0\,
      S(0) => \derivative[17]_i_29_n_0\
    );
\derivative_reg[17]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_30_n_0\,
      CO(3) => \derivative_reg[17]_i_25_n_0\,
      CO(2) => \derivative_reg[17]_i_25_n_1\,
      CO(1) => \derivative_reg[17]_i_25_n_2\,
      CO(0) => \derivative_reg[17]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[18]_i_25_n_5\,
      DI(2) => \derivative_reg[18]_i_25_n_6\,
      DI(1) => \derivative_reg[18]_i_25_n_7\,
      DI(0) => \derivative_reg[18]_i_30_n_4\,
      O(3) => \derivative_reg[17]_i_25_n_4\,
      O(2) => \derivative_reg[17]_i_25_n_5\,
      O(1) => \derivative_reg[17]_i_25_n_6\,
      O(0) => \derivative_reg[17]_i_25_n_7\,
      S(3) => \derivative[17]_i_31_n_0\,
      S(2) => \derivative[17]_i_32_n_0\,
      S(1) => \derivative[17]_i_33_n_0\,
      S(0) => \derivative[17]_i_34_n_0\
    );
\derivative_reg[17]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_35_n_0\,
      CO(3) => \derivative_reg[17]_i_30_n_0\,
      CO(2) => \derivative_reg[17]_i_30_n_1\,
      CO(1) => \derivative_reg[17]_i_30_n_2\,
      CO(0) => \derivative_reg[17]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[18]_i_30_n_5\,
      DI(2) => \derivative_reg[18]_i_30_n_6\,
      DI(1) => \derivative_reg[18]_i_30_n_7\,
      DI(0) => \derivative_reg[18]_i_35_n_4\,
      O(3) => \derivative_reg[17]_i_30_n_4\,
      O(2) => \derivative_reg[17]_i_30_n_5\,
      O(1) => \derivative_reg[17]_i_30_n_6\,
      O(0) => \derivative_reg[17]_i_30_n_7\,
      S(3) => \derivative[17]_i_36_n_0\,
      S(2) => \derivative[17]_i_37_n_0\,
      S(1) => \derivative[17]_i_38_n_0\,
      S(0) => \derivative[17]_i_39_n_0\
    );
\derivative_reg[17]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[17]_i_35_n_0\,
      CO(2) => \derivative_reg[17]_i_35_n_1\,
      CO(1) => \derivative_reg[17]_i_35_n_2\,
      CO(0) => \derivative_reg[17]_i_35_n_3\,
      CYINIT => \derivative_reg[18]_i_1_n_2\,
      DI(3) => \derivative_reg[18]_i_35_n_5\,
      DI(2) => \derivative_reg[18]_i_35_n_6\,
      DI(1) => derivative11_out(17),
      DI(0) => '0',
      O(3) => \derivative_reg[17]_i_35_n_4\,
      O(2) => \derivative_reg[17]_i_35_n_5\,
      O(1) => \derivative_reg[17]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[17]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[17]_i_40_n_0\,
      S(2) => \derivative[17]_i_41_n_0\,
      S(1) => \derivative[17]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[17]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[17]_i_10_n_0\,
      CO(3) => \derivative_reg[17]_i_5_n_0\,
      CO(2) => \derivative_reg[17]_i_5_n_1\,
      CO(1) => \derivative_reg[17]_i_5_n_2\,
      CO(0) => \derivative_reg[17]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[18]_i_5_n_5\,
      DI(2) => \derivative_reg[18]_i_5_n_6\,
      DI(1) => \derivative_reg[18]_i_5_n_7\,
      DI(0) => \derivative_reg[18]_i_10_n_4\,
      O(3) => \derivative_reg[17]_i_5_n_4\,
      O(2) => \derivative_reg[17]_i_5_n_5\,
      O(1) => \derivative_reg[17]_i_5_n_6\,
      O(0) => \derivative_reg[17]_i_5_n_7\,
      S(3) => \derivative[17]_i_11_n_0\,
      S(2) => \derivative[17]_i_12_n_0\,
      S(1) => \derivative[17]_i_13_n_0\,
      S(0) => \derivative[17]_i_14_n_0\
    );
\derivative_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[18]_i_1_n_2\,
      Q => derivative_out(18),
      R => '0'
    );
\derivative_reg[18]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[18]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[18]_i_1_n_2\,
      CO(0) => \derivative_reg[18]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[19]_i_1_n_2\,
      DI(0) => \derivative_reg[19]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[18]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[18]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[18]_i_3_n_0\,
      S(0) => \derivative[18]_i_4_n_0\
    );
\derivative_reg[18]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_15_n_0\,
      CO(3) => \derivative_reg[18]_i_10_n_0\,
      CO(2) => \derivative_reg[18]_i_10_n_1\,
      CO(1) => \derivative_reg[18]_i_10_n_2\,
      CO(0) => \derivative_reg[18]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[19]_i_10_n_5\,
      DI(2) => \derivative_reg[19]_i_10_n_6\,
      DI(1) => \derivative_reg[19]_i_10_n_7\,
      DI(0) => \derivative_reg[19]_i_15_n_4\,
      O(3) => \derivative_reg[18]_i_10_n_4\,
      O(2) => \derivative_reg[18]_i_10_n_5\,
      O(1) => \derivative_reg[18]_i_10_n_6\,
      O(0) => \derivative_reg[18]_i_10_n_7\,
      S(3) => \derivative[18]_i_16_n_0\,
      S(2) => \derivative[18]_i_17_n_0\,
      S(1) => \derivative[18]_i_18_n_0\,
      S(0) => \derivative[18]_i_19_n_0\
    );
\derivative_reg[18]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_20_n_0\,
      CO(3) => \derivative_reg[18]_i_15_n_0\,
      CO(2) => \derivative_reg[18]_i_15_n_1\,
      CO(1) => \derivative_reg[18]_i_15_n_2\,
      CO(0) => \derivative_reg[18]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[19]_i_15_n_5\,
      DI(2) => \derivative_reg[19]_i_15_n_6\,
      DI(1) => \derivative_reg[19]_i_15_n_7\,
      DI(0) => \derivative_reg[19]_i_20_n_4\,
      O(3) => \derivative_reg[18]_i_15_n_4\,
      O(2) => \derivative_reg[18]_i_15_n_5\,
      O(1) => \derivative_reg[18]_i_15_n_6\,
      O(0) => \derivative_reg[18]_i_15_n_7\,
      S(3) => \derivative[18]_i_21_n_0\,
      S(2) => \derivative[18]_i_22_n_0\,
      S(1) => \derivative[18]_i_23_n_0\,
      S(0) => \derivative[18]_i_24_n_0\
    );
\derivative_reg[18]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_5_n_0\,
      CO(3) => \derivative_reg[18]_i_2_n_0\,
      CO(2) => \derivative_reg[18]_i_2_n_1\,
      CO(1) => \derivative_reg[18]_i_2_n_2\,
      CO(0) => \derivative_reg[18]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[19]_i_2_n_5\,
      DI(2) => \derivative_reg[19]_i_2_n_6\,
      DI(1) => \derivative_reg[19]_i_2_n_7\,
      DI(0) => \derivative_reg[19]_i_5_n_4\,
      O(3) => \derivative_reg[18]_i_2_n_4\,
      O(2) => \derivative_reg[18]_i_2_n_5\,
      O(1) => \derivative_reg[18]_i_2_n_6\,
      O(0) => \derivative_reg[18]_i_2_n_7\,
      S(3) => \derivative[18]_i_6_n_0\,
      S(2) => \derivative[18]_i_7_n_0\,
      S(1) => \derivative[18]_i_8_n_0\,
      S(0) => \derivative[18]_i_9_n_0\
    );
\derivative_reg[18]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_25_n_0\,
      CO(3) => \derivative_reg[18]_i_20_n_0\,
      CO(2) => \derivative_reg[18]_i_20_n_1\,
      CO(1) => \derivative_reg[18]_i_20_n_2\,
      CO(0) => \derivative_reg[18]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[19]_i_20_n_5\,
      DI(2) => \derivative_reg[19]_i_20_n_6\,
      DI(1) => \derivative_reg[19]_i_20_n_7\,
      DI(0) => \derivative_reg[19]_i_25_n_4\,
      O(3) => \derivative_reg[18]_i_20_n_4\,
      O(2) => \derivative_reg[18]_i_20_n_5\,
      O(1) => \derivative_reg[18]_i_20_n_6\,
      O(0) => \derivative_reg[18]_i_20_n_7\,
      S(3) => \derivative[18]_i_26_n_0\,
      S(2) => \derivative[18]_i_27_n_0\,
      S(1) => \derivative[18]_i_28_n_0\,
      S(0) => \derivative[18]_i_29_n_0\
    );
\derivative_reg[18]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_30_n_0\,
      CO(3) => \derivative_reg[18]_i_25_n_0\,
      CO(2) => \derivative_reg[18]_i_25_n_1\,
      CO(1) => \derivative_reg[18]_i_25_n_2\,
      CO(0) => \derivative_reg[18]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[19]_i_25_n_5\,
      DI(2) => \derivative_reg[19]_i_25_n_6\,
      DI(1) => \derivative_reg[19]_i_25_n_7\,
      DI(0) => \derivative_reg[19]_i_30_n_4\,
      O(3) => \derivative_reg[18]_i_25_n_4\,
      O(2) => \derivative_reg[18]_i_25_n_5\,
      O(1) => \derivative_reg[18]_i_25_n_6\,
      O(0) => \derivative_reg[18]_i_25_n_7\,
      S(3) => \derivative[18]_i_31_n_0\,
      S(2) => \derivative[18]_i_32_n_0\,
      S(1) => \derivative[18]_i_33_n_0\,
      S(0) => \derivative[18]_i_34_n_0\
    );
\derivative_reg[18]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_35_n_0\,
      CO(3) => \derivative_reg[18]_i_30_n_0\,
      CO(2) => \derivative_reg[18]_i_30_n_1\,
      CO(1) => \derivative_reg[18]_i_30_n_2\,
      CO(0) => \derivative_reg[18]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[19]_i_30_n_5\,
      DI(2) => \derivative_reg[19]_i_30_n_6\,
      DI(1) => \derivative_reg[19]_i_30_n_7\,
      DI(0) => \derivative_reg[19]_i_35_n_4\,
      O(3) => \derivative_reg[18]_i_30_n_4\,
      O(2) => \derivative_reg[18]_i_30_n_5\,
      O(1) => \derivative_reg[18]_i_30_n_6\,
      O(0) => \derivative_reg[18]_i_30_n_7\,
      S(3) => \derivative[18]_i_36_n_0\,
      S(2) => \derivative[18]_i_37_n_0\,
      S(1) => \derivative[18]_i_38_n_0\,
      S(0) => \derivative[18]_i_39_n_0\
    );
\derivative_reg[18]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[18]_i_35_n_0\,
      CO(2) => \derivative_reg[18]_i_35_n_1\,
      CO(1) => \derivative_reg[18]_i_35_n_2\,
      CO(0) => \derivative_reg[18]_i_35_n_3\,
      CYINIT => \derivative_reg[19]_i_1_n_2\,
      DI(3) => \derivative_reg[19]_i_35_n_5\,
      DI(2) => \derivative_reg[19]_i_35_n_6\,
      DI(1) => derivative11_out(18),
      DI(0) => '0',
      O(3) => \derivative_reg[18]_i_35_n_4\,
      O(2) => \derivative_reg[18]_i_35_n_5\,
      O(1) => \derivative_reg[18]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[18]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[18]_i_40_n_0\,
      S(2) => \derivative[18]_i_41_n_0\,
      S(1) => \derivative[18]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[18]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[18]_i_10_n_0\,
      CO(3) => \derivative_reg[18]_i_5_n_0\,
      CO(2) => \derivative_reg[18]_i_5_n_1\,
      CO(1) => \derivative_reg[18]_i_5_n_2\,
      CO(0) => \derivative_reg[18]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[19]_i_5_n_5\,
      DI(2) => \derivative_reg[19]_i_5_n_6\,
      DI(1) => \derivative_reg[19]_i_5_n_7\,
      DI(0) => \derivative_reg[19]_i_10_n_4\,
      O(3) => \derivative_reg[18]_i_5_n_4\,
      O(2) => \derivative_reg[18]_i_5_n_5\,
      O(1) => \derivative_reg[18]_i_5_n_6\,
      O(0) => \derivative_reg[18]_i_5_n_7\,
      S(3) => \derivative[18]_i_11_n_0\,
      S(2) => \derivative[18]_i_12_n_0\,
      S(1) => \derivative[18]_i_13_n_0\,
      S(0) => \derivative[18]_i_14_n_0\
    );
\derivative_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[19]_i_1_n_2\,
      Q => derivative_out(19),
      R => '0'
    );
\derivative_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[19]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[19]_i_1_n_2\,
      CO(0) => \derivative_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[20]_i_1_n_2\,
      DI(0) => \derivative_reg[20]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[19]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[19]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[19]_i_3_n_0\,
      S(0) => \derivative[19]_i_4_n_0\
    );
\derivative_reg[19]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_15_n_0\,
      CO(3) => \derivative_reg[19]_i_10_n_0\,
      CO(2) => \derivative_reg[19]_i_10_n_1\,
      CO(1) => \derivative_reg[19]_i_10_n_2\,
      CO(0) => \derivative_reg[19]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[20]_i_10_n_5\,
      DI(2) => \derivative_reg[20]_i_10_n_6\,
      DI(1) => \derivative_reg[20]_i_10_n_7\,
      DI(0) => \derivative_reg[20]_i_15_n_4\,
      O(3) => \derivative_reg[19]_i_10_n_4\,
      O(2) => \derivative_reg[19]_i_10_n_5\,
      O(1) => \derivative_reg[19]_i_10_n_6\,
      O(0) => \derivative_reg[19]_i_10_n_7\,
      S(3) => \derivative[19]_i_16_n_0\,
      S(2) => \derivative[19]_i_17_n_0\,
      S(1) => \derivative[19]_i_18_n_0\,
      S(0) => \derivative[19]_i_19_n_0\
    );
\derivative_reg[19]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_20_n_0\,
      CO(3) => \derivative_reg[19]_i_15_n_0\,
      CO(2) => \derivative_reg[19]_i_15_n_1\,
      CO(1) => \derivative_reg[19]_i_15_n_2\,
      CO(0) => \derivative_reg[19]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[20]_i_15_n_5\,
      DI(2) => \derivative_reg[20]_i_15_n_6\,
      DI(1) => \derivative_reg[20]_i_15_n_7\,
      DI(0) => \derivative_reg[20]_i_20_n_4\,
      O(3) => \derivative_reg[19]_i_15_n_4\,
      O(2) => \derivative_reg[19]_i_15_n_5\,
      O(1) => \derivative_reg[19]_i_15_n_6\,
      O(0) => \derivative_reg[19]_i_15_n_7\,
      S(3) => \derivative[19]_i_21_n_0\,
      S(2) => \derivative[19]_i_22_n_0\,
      S(1) => \derivative[19]_i_23_n_0\,
      S(0) => \derivative[19]_i_24_n_0\
    );
\derivative_reg[19]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_5_n_0\,
      CO(3) => \derivative_reg[19]_i_2_n_0\,
      CO(2) => \derivative_reg[19]_i_2_n_1\,
      CO(1) => \derivative_reg[19]_i_2_n_2\,
      CO(0) => \derivative_reg[19]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[20]_i_2_n_5\,
      DI(2) => \derivative_reg[20]_i_2_n_6\,
      DI(1) => \derivative_reg[20]_i_2_n_7\,
      DI(0) => \derivative_reg[20]_i_5_n_4\,
      O(3) => \derivative_reg[19]_i_2_n_4\,
      O(2) => \derivative_reg[19]_i_2_n_5\,
      O(1) => \derivative_reg[19]_i_2_n_6\,
      O(0) => \derivative_reg[19]_i_2_n_7\,
      S(3) => \derivative[19]_i_6_n_0\,
      S(2) => \derivative[19]_i_7_n_0\,
      S(1) => \derivative[19]_i_8_n_0\,
      S(0) => \derivative[19]_i_9_n_0\
    );
\derivative_reg[19]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_25_n_0\,
      CO(3) => \derivative_reg[19]_i_20_n_0\,
      CO(2) => \derivative_reg[19]_i_20_n_1\,
      CO(1) => \derivative_reg[19]_i_20_n_2\,
      CO(0) => \derivative_reg[19]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[20]_i_20_n_5\,
      DI(2) => \derivative_reg[20]_i_20_n_6\,
      DI(1) => \derivative_reg[20]_i_20_n_7\,
      DI(0) => \derivative_reg[20]_i_25_n_4\,
      O(3) => \derivative_reg[19]_i_20_n_4\,
      O(2) => \derivative_reg[19]_i_20_n_5\,
      O(1) => \derivative_reg[19]_i_20_n_6\,
      O(0) => \derivative_reg[19]_i_20_n_7\,
      S(3) => \derivative[19]_i_26_n_0\,
      S(2) => \derivative[19]_i_27_n_0\,
      S(1) => \derivative[19]_i_28_n_0\,
      S(0) => \derivative[19]_i_29_n_0\
    );
\derivative_reg[19]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_30_n_0\,
      CO(3) => \derivative_reg[19]_i_25_n_0\,
      CO(2) => \derivative_reg[19]_i_25_n_1\,
      CO(1) => \derivative_reg[19]_i_25_n_2\,
      CO(0) => \derivative_reg[19]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[20]_i_25_n_5\,
      DI(2) => \derivative_reg[20]_i_25_n_6\,
      DI(1) => \derivative_reg[20]_i_25_n_7\,
      DI(0) => \derivative_reg[20]_i_30_n_4\,
      O(3) => \derivative_reg[19]_i_25_n_4\,
      O(2) => \derivative_reg[19]_i_25_n_5\,
      O(1) => \derivative_reg[19]_i_25_n_6\,
      O(0) => \derivative_reg[19]_i_25_n_7\,
      S(3) => \derivative[19]_i_31_n_0\,
      S(2) => \derivative[19]_i_32_n_0\,
      S(1) => \derivative[19]_i_33_n_0\,
      S(0) => \derivative[19]_i_34_n_0\
    );
\derivative_reg[19]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_35_n_0\,
      CO(3) => \derivative_reg[19]_i_30_n_0\,
      CO(2) => \derivative_reg[19]_i_30_n_1\,
      CO(1) => \derivative_reg[19]_i_30_n_2\,
      CO(0) => \derivative_reg[19]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[20]_i_30_n_5\,
      DI(2) => \derivative_reg[20]_i_30_n_6\,
      DI(1) => \derivative_reg[20]_i_30_n_7\,
      DI(0) => \derivative_reg[20]_i_35_n_4\,
      O(3) => \derivative_reg[19]_i_30_n_4\,
      O(2) => \derivative_reg[19]_i_30_n_5\,
      O(1) => \derivative_reg[19]_i_30_n_6\,
      O(0) => \derivative_reg[19]_i_30_n_7\,
      S(3) => \derivative[19]_i_36_n_0\,
      S(2) => \derivative[19]_i_37_n_0\,
      S(1) => \derivative[19]_i_38_n_0\,
      S(0) => \derivative[19]_i_39_n_0\
    );
\derivative_reg[19]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[19]_i_35_n_0\,
      CO(2) => \derivative_reg[19]_i_35_n_1\,
      CO(1) => \derivative_reg[19]_i_35_n_2\,
      CO(0) => \derivative_reg[19]_i_35_n_3\,
      CYINIT => \derivative_reg[20]_i_1_n_2\,
      DI(3) => \derivative_reg[20]_i_35_n_5\,
      DI(2) => \derivative_reg[20]_i_35_n_6\,
      DI(1) => derivative11_out(19),
      DI(0) => '0',
      O(3) => \derivative_reg[19]_i_35_n_4\,
      O(2) => \derivative_reg[19]_i_35_n_5\,
      O(1) => \derivative_reg[19]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[19]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[19]_i_40_n_0\,
      S(2) => \derivative[19]_i_41_n_0\,
      S(1) => \derivative[19]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[19]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[19]_i_10_n_0\,
      CO(3) => \derivative_reg[19]_i_5_n_0\,
      CO(2) => \derivative_reg[19]_i_5_n_1\,
      CO(1) => \derivative_reg[19]_i_5_n_2\,
      CO(0) => \derivative_reg[19]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[20]_i_5_n_5\,
      DI(2) => \derivative_reg[20]_i_5_n_6\,
      DI(1) => \derivative_reg[20]_i_5_n_7\,
      DI(0) => \derivative_reg[20]_i_10_n_4\,
      O(3) => \derivative_reg[19]_i_5_n_4\,
      O(2) => \derivative_reg[19]_i_5_n_5\,
      O(1) => \derivative_reg[19]_i_5_n_6\,
      O(0) => \derivative_reg[19]_i_5_n_7\,
      S(3) => \derivative[19]_i_11_n_0\,
      S(2) => \derivative[19]_i_12_n_0\,
      S(1) => \derivative[19]_i_13_n_0\,
      S(0) => \derivative[19]_i_14_n_0\
    );
\derivative_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[1]_i_1_n_2\,
      Q => derivative_out(1),
      R => '0'
    );
\derivative_reg[1]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[1]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[1]_i_1_n_2\,
      CO(0) => \derivative_reg[1]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[2]_i_1_n_2\,
      DI(0) => \derivative_reg[2]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[1]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[1]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[1]_i_3_n_0\,
      S(0) => \derivative[1]_i_4_n_0\
    );
\derivative_reg[1]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_15_n_0\,
      CO(3) => \derivative_reg[1]_i_10_n_0\,
      CO(2) => \derivative_reg[1]_i_10_n_1\,
      CO(1) => \derivative_reg[1]_i_10_n_2\,
      CO(0) => \derivative_reg[1]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[2]_i_10_n_5\,
      DI(2) => \derivative_reg[2]_i_10_n_6\,
      DI(1) => \derivative_reg[2]_i_10_n_7\,
      DI(0) => \derivative_reg[2]_i_15_n_4\,
      O(3) => \derivative_reg[1]_i_10_n_4\,
      O(2) => \derivative_reg[1]_i_10_n_5\,
      O(1) => \derivative_reg[1]_i_10_n_6\,
      O(0) => \derivative_reg[1]_i_10_n_7\,
      S(3) => \derivative[1]_i_16_n_0\,
      S(2) => \derivative[1]_i_17_n_0\,
      S(1) => \derivative[1]_i_18_n_0\,
      S(0) => \derivative[1]_i_19_n_0\
    );
\derivative_reg[1]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_20_n_0\,
      CO(3) => \derivative_reg[1]_i_15_n_0\,
      CO(2) => \derivative_reg[1]_i_15_n_1\,
      CO(1) => \derivative_reg[1]_i_15_n_2\,
      CO(0) => \derivative_reg[1]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[2]_i_15_n_5\,
      DI(2) => \derivative_reg[2]_i_15_n_6\,
      DI(1) => \derivative_reg[2]_i_15_n_7\,
      DI(0) => \derivative_reg[2]_i_20_n_4\,
      O(3) => \derivative_reg[1]_i_15_n_4\,
      O(2) => \derivative_reg[1]_i_15_n_5\,
      O(1) => \derivative_reg[1]_i_15_n_6\,
      O(0) => \derivative_reg[1]_i_15_n_7\,
      S(3) => \derivative[1]_i_21_n_0\,
      S(2) => \derivative[1]_i_22_n_0\,
      S(1) => \derivative[1]_i_23_n_0\,
      S(0) => \derivative[1]_i_24_n_0\
    );
\derivative_reg[1]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_5_n_0\,
      CO(3) => \derivative_reg[1]_i_2_n_0\,
      CO(2) => \derivative_reg[1]_i_2_n_1\,
      CO(1) => \derivative_reg[1]_i_2_n_2\,
      CO(0) => \derivative_reg[1]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[2]_i_2_n_5\,
      DI(2) => \derivative_reg[2]_i_2_n_6\,
      DI(1) => \derivative_reg[2]_i_2_n_7\,
      DI(0) => \derivative_reg[2]_i_5_n_4\,
      O(3) => \derivative_reg[1]_i_2_n_4\,
      O(2) => \derivative_reg[1]_i_2_n_5\,
      O(1) => \derivative_reg[1]_i_2_n_6\,
      O(0) => \derivative_reg[1]_i_2_n_7\,
      S(3) => \derivative[1]_i_6_n_0\,
      S(2) => \derivative[1]_i_7_n_0\,
      S(1) => \derivative[1]_i_8_n_0\,
      S(0) => \derivative[1]_i_9_n_0\
    );
\derivative_reg[1]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_25_n_0\,
      CO(3) => \derivative_reg[1]_i_20_n_0\,
      CO(2) => \derivative_reg[1]_i_20_n_1\,
      CO(1) => \derivative_reg[1]_i_20_n_2\,
      CO(0) => \derivative_reg[1]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[2]_i_20_n_5\,
      DI(2) => \derivative_reg[2]_i_20_n_6\,
      DI(1) => \derivative_reg[2]_i_20_n_7\,
      DI(0) => \derivative_reg[2]_i_25_n_4\,
      O(3) => \derivative_reg[1]_i_20_n_4\,
      O(2) => \derivative_reg[1]_i_20_n_5\,
      O(1) => \derivative_reg[1]_i_20_n_6\,
      O(0) => \derivative_reg[1]_i_20_n_7\,
      S(3) => \derivative[1]_i_26_n_0\,
      S(2) => \derivative[1]_i_27_n_0\,
      S(1) => \derivative[1]_i_28_n_0\,
      S(0) => \derivative[1]_i_29_n_0\
    );
\derivative_reg[1]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_30_n_0\,
      CO(3) => \derivative_reg[1]_i_25_n_0\,
      CO(2) => \derivative_reg[1]_i_25_n_1\,
      CO(1) => \derivative_reg[1]_i_25_n_2\,
      CO(0) => \derivative_reg[1]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[2]_i_25_n_5\,
      DI(2) => \derivative_reg[2]_i_25_n_6\,
      DI(1) => \derivative_reg[2]_i_25_n_7\,
      DI(0) => \derivative_reg[2]_i_30_n_4\,
      O(3) => \derivative_reg[1]_i_25_n_4\,
      O(2) => \derivative_reg[1]_i_25_n_5\,
      O(1) => \derivative_reg[1]_i_25_n_6\,
      O(0) => \derivative_reg[1]_i_25_n_7\,
      S(3) => \derivative[1]_i_31_n_0\,
      S(2) => \derivative[1]_i_32_n_0\,
      S(1) => \derivative[1]_i_33_n_0\,
      S(0) => \derivative[1]_i_34_n_0\
    );
\derivative_reg[1]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_35_n_0\,
      CO(3) => \derivative_reg[1]_i_30_n_0\,
      CO(2) => \derivative_reg[1]_i_30_n_1\,
      CO(1) => \derivative_reg[1]_i_30_n_2\,
      CO(0) => \derivative_reg[1]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[2]_i_30_n_5\,
      DI(2) => \derivative_reg[2]_i_30_n_6\,
      DI(1) => \derivative_reg[2]_i_30_n_7\,
      DI(0) => \derivative_reg[2]_i_35_n_4\,
      O(3) => \derivative_reg[1]_i_30_n_4\,
      O(2) => \derivative_reg[1]_i_30_n_5\,
      O(1) => \derivative_reg[1]_i_30_n_6\,
      O(0) => \derivative_reg[1]_i_30_n_7\,
      S(3) => \derivative[1]_i_36_n_0\,
      S(2) => \derivative[1]_i_37_n_0\,
      S(1) => \derivative[1]_i_38_n_0\,
      S(0) => \derivative[1]_i_39_n_0\
    );
\derivative_reg[1]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[1]_i_35_n_0\,
      CO(2) => \derivative_reg[1]_i_35_n_1\,
      CO(1) => \derivative_reg[1]_i_35_n_2\,
      CO(0) => \derivative_reg[1]_i_35_n_3\,
      CYINIT => \derivative_reg[2]_i_1_n_2\,
      DI(3) => \derivative_reg[2]_i_35_n_5\,
      DI(2) => \derivative_reg[2]_i_35_n_6\,
      DI(1) => derivative11_out(1),
      DI(0) => '0',
      O(3) => \derivative_reg[1]_i_35_n_4\,
      O(2) => \derivative_reg[1]_i_35_n_5\,
      O(1) => \derivative_reg[1]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[1]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[1]_i_40_n_0\,
      S(2) => \derivative[1]_i_41_n_0\,
      S(1) => \derivative[1]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[1]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[1]_i_10_n_0\,
      CO(3) => \derivative_reg[1]_i_5_n_0\,
      CO(2) => \derivative_reg[1]_i_5_n_1\,
      CO(1) => \derivative_reg[1]_i_5_n_2\,
      CO(0) => \derivative_reg[1]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[2]_i_5_n_5\,
      DI(2) => \derivative_reg[2]_i_5_n_6\,
      DI(1) => \derivative_reg[2]_i_5_n_7\,
      DI(0) => \derivative_reg[2]_i_10_n_4\,
      O(3) => \derivative_reg[1]_i_5_n_4\,
      O(2) => \derivative_reg[1]_i_5_n_5\,
      O(1) => \derivative_reg[1]_i_5_n_6\,
      O(0) => \derivative_reg[1]_i_5_n_7\,
      S(3) => \derivative[1]_i_11_n_0\,
      S(2) => \derivative[1]_i_12_n_0\,
      S(1) => \derivative[1]_i_13_n_0\,
      S(0) => \derivative[1]_i_14_n_0\
    );
\derivative_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[20]_i_1_n_2\,
      Q => derivative_out(20),
      R => '0'
    );
\derivative_reg[20]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[20]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[20]_i_1_n_2\,
      CO(0) => \derivative_reg[20]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[21]_i_1_n_2\,
      DI(0) => \derivative_reg[21]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[20]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[20]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[20]_i_3_n_0\,
      S(0) => \derivative[20]_i_4_n_0\
    );
\derivative_reg[20]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_15_n_0\,
      CO(3) => \derivative_reg[20]_i_10_n_0\,
      CO(2) => \derivative_reg[20]_i_10_n_1\,
      CO(1) => \derivative_reg[20]_i_10_n_2\,
      CO(0) => \derivative_reg[20]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[21]_i_10_n_5\,
      DI(2) => \derivative_reg[21]_i_10_n_6\,
      DI(1) => \derivative_reg[21]_i_10_n_7\,
      DI(0) => \derivative_reg[21]_i_15_n_4\,
      O(3) => \derivative_reg[20]_i_10_n_4\,
      O(2) => \derivative_reg[20]_i_10_n_5\,
      O(1) => \derivative_reg[20]_i_10_n_6\,
      O(0) => \derivative_reg[20]_i_10_n_7\,
      S(3) => \derivative[20]_i_16_n_0\,
      S(2) => \derivative[20]_i_17_n_0\,
      S(1) => \derivative[20]_i_18_n_0\,
      S(0) => \derivative[20]_i_19_n_0\
    );
\derivative_reg[20]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_20_n_0\,
      CO(3) => \derivative_reg[20]_i_15_n_0\,
      CO(2) => \derivative_reg[20]_i_15_n_1\,
      CO(1) => \derivative_reg[20]_i_15_n_2\,
      CO(0) => \derivative_reg[20]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[21]_i_15_n_5\,
      DI(2) => \derivative_reg[21]_i_15_n_6\,
      DI(1) => \derivative_reg[21]_i_15_n_7\,
      DI(0) => \derivative_reg[21]_i_20_n_4\,
      O(3) => \derivative_reg[20]_i_15_n_4\,
      O(2) => \derivative_reg[20]_i_15_n_5\,
      O(1) => \derivative_reg[20]_i_15_n_6\,
      O(0) => \derivative_reg[20]_i_15_n_7\,
      S(3) => \derivative[20]_i_21_n_0\,
      S(2) => \derivative[20]_i_22_n_0\,
      S(1) => \derivative[20]_i_23_n_0\,
      S(0) => \derivative[20]_i_24_n_0\
    );
\derivative_reg[20]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_5_n_0\,
      CO(3) => \derivative_reg[20]_i_2_n_0\,
      CO(2) => \derivative_reg[20]_i_2_n_1\,
      CO(1) => \derivative_reg[20]_i_2_n_2\,
      CO(0) => \derivative_reg[20]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[21]_i_2_n_5\,
      DI(2) => \derivative_reg[21]_i_2_n_6\,
      DI(1) => \derivative_reg[21]_i_2_n_7\,
      DI(0) => \derivative_reg[21]_i_5_n_4\,
      O(3) => \derivative_reg[20]_i_2_n_4\,
      O(2) => \derivative_reg[20]_i_2_n_5\,
      O(1) => \derivative_reg[20]_i_2_n_6\,
      O(0) => \derivative_reg[20]_i_2_n_7\,
      S(3) => \derivative[20]_i_6_n_0\,
      S(2) => \derivative[20]_i_7_n_0\,
      S(1) => \derivative[20]_i_8_n_0\,
      S(0) => \derivative[20]_i_9_n_0\
    );
\derivative_reg[20]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_25_n_0\,
      CO(3) => \derivative_reg[20]_i_20_n_0\,
      CO(2) => \derivative_reg[20]_i_20_n_1\,
      CO(1) => \derivative_reg[20]_i_20_n_2\,
      CO(0) => \derivative_reg[20]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[21]_i_20_n_5\,
      DI(2) => \derivative_reg[21]_i_20_n_6\,
      DI(1) => \derivative_reg[21]_i_20_n_7\,
      DI(0) => \derivative_reg[21]_i_25_n_4\,
      O(3) => \derivative_reg[20]_i_20_n_4\,
      O(2) => \derivative_reg[20]_i_20_n_5\,
      O(1) => \derivative_reg[20]_i_20_n_6\,
      O(0) => \derivative_reg[20]_i_20_n_7\,
      S(3) => \derivative[20]_i_26_n_0\,
      S(2) => \derivative[20]_i_27_n_0\,
      S(1) => \derivative[20]_i_28_n_0\,
      S(0) => \derivative[20]_i_29_n_0\
    );
\derivative_reg[20]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_30_n_0\,
      CO(3) => \derivative_reg[20]_i_25_n_0\,
      CO(2) => \derivative_reg[20]_i_25_n_1\,
      CO(1) => \derivative_reg[20]_i_25_n_2\,
      CO(0) => \derivative_reg[20]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[21]_i_25_n_5\,
      DI(2) => \derivative_reg[21]_i_25_n_6\,
      DI(1) => \derivative_reg[21]_i_25_n_7\,
      DI(0) => \derivative_reg[21]_i_30_n_4\,
      O(3) => \derivative_reg[20]_i_25_n_4\,
      O(2) => \derivative_reg[20]_i_25_n_5\,
      O(1) => \derivative_reg[20]_i_25_n_6\,
      O(0) => \derivative_reg[20]_i_25_n_7\,
      S(3) => \derivative[20]_i_31_n_0\,
      S(2) => \derivative[20]_i_32_n_0\,
      S(1) => \derivative[20]_i_33_n_0\,
      S(0) => \derivative[20]_i_34_n_0\
    );
\derivative_reg[20]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_35_n_0\,
      CO(3) => \derivative_reg[20]_i_30_n_0\,
      CO(2) => \derivative_reg[20]_i_30_n_1\,
      CO(1) => \derivative_reg[20]_i_30_n_2\,
      CO(0) => \derivative_reg[20]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[21]_i_30_n_5\,
      DI(2) => \derivative_reg[21]_i_30_n_6\,
      DI(1) => \derivative_reg[21]_i_30_n_7\,
      DI(0) => \derivative_reg[21]_i_35_n_4\,
      O(3) => \derivative_reg[20]_i_30_n_4\,
      O(2) => \derivative_reg[20]_i_30_n_5\,
      O(1) => \derivative_reg[20]_i_30_n_6\,
      O(0) => \derivative_reg[20]_i_30_n_7\,
      S(3) => \derivative[20]_i_36_n_0\,
      S(2) => \derivative[20]_i_37_n_0\,
      S(1) => \derivative[20]_i_38_n_0\,
      S(0) => \derivative[20]_i_39_n_0\
    );
\derivative_reg[20]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[20]_i_35_n_0\,
      CO(2) => \derivative_reg[20]_i_35_n_1\,
      CO(1) => \derivative_reg[20]_i_35_n_2\,
      CO(0) => \derivative_reg[20]_i_35_n_3\,
      CYINIT => \derivative_reg[21]_i_1_n_2\,
      DI(3) => \derivative_reg[21]_i_35_n_5\,
      DI(2) => \derivative_reg[21]_i_35_n_6\,
      DI(1) => derivative11_out(20),
      DI(0) => '0',
      O(3) => \derivative_reg[20]_i_35_n_4\,
      O(2) => \derivative_reg[20]_i_35_n_5\,
      O(1) => \derivative_reg[20]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[20]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[20]_i_40_n_0\,
      S(2) => \derivative[20]_i_41_n_0\,
      S(1) => \derivative[20]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[20]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[20]_i_10_n_0\,
      CO(3) => \derivative_reg[20]_i_5_n_0\,
      CO(2) => \derivative_reg[20]_i_5_n_1\,
      CO(1) => \derivative_reg[20]_i_5_n_2\,
      CO(0) => \derivative_reg[20]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[21]_i_5_n_5\,
      DI(2) => \derivative_reg[21]_i_5_n_6\,
      DI(1) => \derivative_reg[21]_i_5_n_7\,
      DI(0) => \derivative_reg[21]_i_10_n_4\,
      O(3) => \derivative_reg[20]_i_5_n_4\,
      O(2) => \derivative_reg[20]_i_5_n_5\,
      O(1) => \derivative_reg[20]_i_5_n_6\,
      O(0) => \derivative_reg[20]_i_5_n_7\,
      S(3) => \derivative[20]_i_11_n_0\,
      S(2) => \derivative[20]_i_12_n_0\,
      S(1) => \derivative[20]_i_13_n_0\,
      S(0) => \derivative[20]_i_14_n_0\
    );
\derivative_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[21]_i_1_n_2\,
      Q => derivative_out(21),
      R => '0'
    );
\derivative_reg[21]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[21]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[21]_i_1_n_2\,
      CO(0) => \derivative_reg[21]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[22]_i_1_n_2\,
      DI(0) => \derivative_reg[22]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[21]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[21]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[21]_i_3_n_0\,
      S(0) => \derivative[21]_i_4_n_0\
    );
\derivative_reg[21]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_15_n_0\,
      CO(3) => \derivative_reg[21]_i_10_n_0\,
      CO(2) => \derivative_reg[21]_i_10_n_1\,
      CO(1) => \derivative_reg[21]_i_10_n_2\,
      CO(0) => \derivative_reg[21]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[22]_i_10_n_5\,
      DI(2) => \derivative_reg[22]_i_10_n_6\,
      DI(1) => \derivative_reg[22]_i_10_n_7\,
      DI(0) => \derivative_reg[22]_i_15_n_4\,
      O(3) => \derivative_reg[21]_i_10_n_4\,
      O(2) => \derivative_reg[21]_i_10_n_5\,
      O(1) => \derivative_reg[21]_i_10_n_6\,
      O(0) => \derivative_reg[21]_i_10_n_7\,
      S(3) => \derivative[21]_i_16_n_0\,
      S(2) => \derivative[21]_i_17_n_0\,
      S(1) => \derivative[21]_i_18_n_0\,
      S(0) => \derivative[21]_i_19_n_0\
    );
\derivative_reg[21]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_20_n_0\,
      CO(3) => \derivative_reg[21]_i_15_n_0\,
      CO(2) => \derivative_reg[21]_i_15_n_1\,
      CO(1) => \derivative_reg[21]_i_15_n_2\,
      CO(0) => \derivative_reg[21]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[22]_i_15_n_5\,
      DI(2) => \derivative_reg[22]_i_15_n_6\,
      DI(1) => \derivative_reg[22]_i_15_n_7\,
      DI(0) => \derivative_reg[22]_i_20_n_4\,
      O(3) => \derivative_reg[21]_i_15_n_4\,
      O(2) => \derivative_reg[21]_i_15_n_5\,
      O(1) => \derivative_reg[21]_i_15_n_6\,
      O(0) => \derivative_reg[21]_i_15_n_7\,
      S(3) => \derivative[21]_i_21_n_0\,
      S(2) => \derivative[21]_i_22_n_0\,
      S(1) => \derivative[21]_i_23_n_0\,
      S(0) => \derivative[21]_i_24_n_0\
    );
\derivative_reg[21]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_5_n_0\,
      CO(3) => \derivative_reg[21]_i_2_n_0\,
      CO(2) => \derivative_reg[21]_i_2_n_1\,
      CO(1) => \derivative_reg[21]_i_2_n_2\,
      CO(0) => \derivative_reg[21]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[22]_i_2_n_5\,
      DI(2) => \derivative_reg[22]_i_2_n_6\,
      DI(1) => \derivative_reg[22]_i_2_n_7\,
      DI(0) => \derivative_reg[22]_i_5_n_4\,
      O(3) => \derivative_reg[21]_i_2_n_4\,
      O(2) => \derivative_reg[21]_i_2_n_5\,
      O(1) => \derivative_reg[21]_i_2_n_6\,
      O(0) => \derivative_reg[21]_i_2_n_7\,
      S(3) => \derivative[21]_i_6_n_0\,
      S(2) => \derivative[21]_i_7_n_0\,
      S(1) => \derivative[21]_i_8_n_0\,
      S(0) => \derivative[21]_i_9_n_0\
    );
\derivative_reg[21]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_25_n_0\,
      CO(3) => \derivative_reg[21]_i_20_n_0\,
      CO(2) => \derivative_reg[21]_i_20_n_1\,
      CO(1) => \derivative_reg[21]_i_20_n_2\,
      CO(0) => \derivative_reg[21]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[22]_i_20_n_5\,
      DI(2) => \derivative_reg[22]_i_20_n_6\,
      DI(1) => \derivative_reg[22]_i_20_n_7\,
      DI(0) => \derivative_reg[22]_i_25_n_4\,
      O(3) => \derivative_reg[21]_i_20_n_4\,
      O(2) => \derivative_reg[21]_i_20_n_5\,
      O(1) => \derivative_reg[21]_i_20_n_6\,
      O(0) => \derivative_reg[21]_i_20_n_7\,
      S(3) => \derivative[21]_i_26_n_0\,
      S(2) => \derivative[21]_i_27_n_0\,
      S(1) => \derivative[21]_i_28_n_0\,
      S(0) => \derivative[21]_i_29_n_0\
    );
\derivative_reg[21]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_30_n_0\,
      CO(3) => \derivative_reg[21]_i_25_n_0\,
      CO(2) => \derivative_reg[21]_i_25_n_1\,
      CO(1) => \derivative_reg[21]_i_25_n_2\,
      CO(0) => \derivative_reg[21]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[22]_i_25_n_5\,
      DI(2) => \derivative_reg[22]_i_25_n_6\,
      DI(1) => \derivative_reg[22]_i_25_n_7\,
      DI(0) => \derivative_reg[22]_i_30_n_4\,
      O(3) => \derivative_reg[21]_i_25_n_4\,
      O(2) => \derivative_reg[21]_i_25_n_5\,
      O(1) => \derivative_reg[21]_i_25_n_6\,
      O(0) => \derivative_reg[21]_i_25_n_7\,
      S(3) => \derivative[21]_i_31_n_0\,
      S(2) => \derivative[21]_i_32_n_0\,
      S(1) => \derivative[21]_i_33_n_0\,
      S(0) => \derivative[21]_i_34_n_0\
    );
\derivative_reg[21]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_35_n_0\,
      CO(3) => \derivative_reg[21]_i_30_n_0\,
      CO(2) => \derivative_reg[21]_i_30_n_1\,
      CO(1) => \derivative_reg[21]_i_30_n_2\,
      CO(0) => \derivative_reg[21]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[22]_i_30_n_5\,
      DI(2) => \derivative_reg[22]_i_30_n_6\,
      DI(1) => \derivative_reg[22]_i_30_n_7\,
      DI(0) => \derivative_reg[22]_i_35_n_4\,
      O(3) => \derivative_reg[21]_i_30_n_4\,
      O(2) => \derivative_reg[21]_i_30_n_5\,
      O(1) => \derivative_reg[21]_i_30_n_6\,
      O(0) => \derivative_reg[21]_i_30_n_7\,
      S(3) => \derivative[21]_i_36_n_0\,
      S(2) => \derivative[21]_i_37_n_0\,
      S(1) => \derivative[21]_i_38_n_0\,
      S(0) => \derivative[21]_i_39_n_0\
    );
\derivative_reg[21]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[21]_i_35_n_0\,
      CO(2) => \derivative_reg[21]_i_35_n_1\,
      CO(1) => \derivative_reg[21]_i_35_n_2\,
      CO(0) => \derivative_reg[21]_i_35_n_3\,
      CYINIT => \derivative_reg[22]_i_1_n_2\,
      DI(3) => \derivative_reg[22]_i_35_n_5\,
      DI(2) => \derivative_reg[22]_i_35_n_6\,
      DI(1) => derivative11_out(21),
      DI(0) => '0',
      O(3) => \derivative_reg[21]_i_35_n_4\,
      O(2) => \derivative_reg[21]_i_35_n_5\,
      O(1) => \derivative_reg[21]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[21]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[21]_i_40_n_0\,
      S(2) => \derivative[21]_i_41_n_0\,
      S(1) => \derivative[21]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[21]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[21]_i_10_n_0\,
      CO(3) => \derivative_reg[21]_i_5_n_0\,
      CO(2) => \derivative_reg[21]_i_5_n_1\,
      CO(1) => \derivative_reg[21]_i_5_n_2\,
      CO(0) => \derivative_reg[21]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[22]_i_5_n_5\,
      DI(2) => \derivative_reg[22]_i_5_n_6\,
      DI(1) => \derivative_reg[22]_i_5_n_7\,
      DI(0) => \derivative_reg[22]_i_10_n_4\,
      O(3) => \derivative_reg[21]_i_5_n_4\,
      O(2) => \derivative_reg[21]_i_5_n_5\,
      O(1) => \derivative_reg[21]_i_5_n_6\,
      O(0) => \derivative_reg[21]_i_5_n_7\,
      S(3) => \derivative[21]_i_11_n_0\,
      S(2) => \derivative[21]_i_12_n_0\,
      S(1) => \derivative[21]_i_13_n_0\,
      S(0) => \derivative[21]_i_14_n_0\
    );
\derivative_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[22]_i_1_n_2\,
      Q => derivative_out(22),
      R => '0'
    );
\derivative_reg[22]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[22]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[22]_i_1_n_2\,
      CO(0) => \derivative_reg[22]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[23]_i_1_n_2\,
      DI(0) => \derivative_reg[23]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[22]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[22]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[22]_i_3_n_0\,
      S(0) => \derivative[22]_i_4_n_0\
    );
\derivative_reg[22]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_15_n_0\,
      CO(3) => \derivative_reg[22]_i_10_n_0\,
      CO(2) => \derivative_reg[22]_i_10_n_1\,
      CO(1) => \derivative_reg[22]_i_10_n_2\,
      CO(0) => \derivative_reg[22]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[23]_i_10_n_5\,
      DI(2) => \derivative_reg[23]_i_10_n_6\,
      DI(1) => \derivative_reg[23]_i_10_n_7\,
      DI(0) => \derivative_reg[23]_i_15_n_4\,
      O(3) => \derivative_reg[22]_i_10_n_4\,
      O(2) => \derivative_reg[22]_i_10_n_5\,
      O(1) => \derivative_reg[22]_i_10_n_6\,
      O(0) => \derivative_reg[22]_i_10_n_7\,
      S(3) => \derivative[22]_i_16_n_0\,
      S(2) => \derivative[22]_i_17_n_0\,
      S(1) => \derivative[22]_i_18_n_0\,
      S(0) => \derivative[22]_i_19_n_0\
    );
\derivative_reg[22]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_20_n_0\,
      CO(3) => \derivative_reg[22]_i_15_n_0\,
      CO(2) => \derivative_reg[22]_i_15_n_1\,
      CO(1) => \derivative_reg[22]_i_15_n_2\,
      CO(0) => \derivative_reg[22]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[23]_i_15_n_5\,
      DI(2) => \derivative_reg[23]_i_15_n_6\,
      DI(1) => \derivative_reg[23]_i_15_n_7\,
      DI(0) => \derivative_reg[23]_i_20_n_4\,
      O(3) => \derivative_reg[22]_i_15_n_4\,
      O(2) => \derivative_reg[22]_i_15_n_5\,
      O(1) => \derivative_reg[22]_i_15_n_6\,
      O(0) => \derivative_reg[22]_i_15_n_7\,
      S(3) => \derivative[22]_i_21_n_0\,
      S(2) => \derivative[22]_i_22_n_0\,
      S(1) => \derivative[22]_i_23_n_0\,
      S(0) => \derivative[22]_i_24_n_0\
    );
\derivative_reg[22]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_5_n_0\,
      CO(3) => \derivative_reg[22]_i_2_n_0\,
      CO(2) => \derivative_reg[22]_i_2_n_1\,
      CO(1) => \derivative_reg[22]_i_2_n_2\,
      CO(0) => \derivative_reg[22]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[23]_i_2_n_5\,
      DI(2) => \derivative_reg[23]_i_2_n_6\,
      DI(1) => \derivative_reg[23]_i_2_n_7\,
      DI(0) => \derivative_reg[23]_i_5_n_4\,
      O(3) => \derivative_reg[22]_i_2_n_4\,
      O(2) => \derivative_reg[22]_i_2_n_5\,
      O(1) => \derivative_reg[22]_i_2_n_6\,
      O(0) => \derivative_reg[22]_i_2_n_7\,
      S(3) => \derivative[22]_i_6_n_0\,
      S(2) => \derivative[22]_i_7_n_0\,
      S(1) => \derivative[22]_i_8_n_0\,
      S(0) => \derivative[22]_i_9_n_0\
    );
\derivative_reg[22]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_25_n_0\,
      CO(3) => \derivative_reg[22]_i_20_n_0\,
      CO(2) => \derivative_reg[22]_i_20_n_1\,
      CO(1) => \derivative_reg[22]_i_20_n_2\,
      CO(0) => \derivative_reg[22]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[23]_i_20_n_5\,
      DI(2) => \derivative_reg[23]_i_20_n_6\,
      DI(1) => \derivative_reg[23]_i_20_n_7\,
      DI(0) => \derivative_reg[23]_i_25_n_4\,
      O(3) => \derivative_reg[22]_i_20_n_4\,
      O(2) => \derivative_reg[22]_i_20_n_5\,
      O(1) => \derivative_reg[22]_i_20_n_6\,
      O(0) => \derivative_reg[22]_i_20_n_7\,
      S(3) => \derivative[22]_i_26_n_0\,
      S(2) => \derivative[22]_i_27_n_0\,
      S(1) => \derivative[22]_i_28_n_0\,
      S(0) => \derivative[22]_i_29_n_0\
    );
\derivative_reg[22]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_30_n_0\,
      CO(3) => \derivative_reg[22]_i_25_n_0\,
      CO(2) => \derivative_reg[22]_i_25_n_1\,
      CO(1) => \derivative_reg[22]_i_25_n_2\,
      CO(0) => \derivative_reg[22]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[23]_i_25_n_5\,
      DI(2) => \derivative_reg[23]_i_25_n_6\,
      DI(1) => \derivative_reg[23]_i_25_n_7\,
      DI(0) => \derivative_reg[23]_i_30_n_4\,
      O(3) => \derivative_reg[22]_i_25_n_4\,
      O(2) => \derivative_reg[22]_i_25_n_5\,
      O(1) => \derivative_reg[22]_i_25_n_6\,
      O(0) => \derivative_reg[22]_i_25_n_7\,
      S(3) => \derivative[22]_i_31_n_0\,
      S(2) => \derivative[22]_i_32_n_0\,
      S(1) => \derivative[22]_i_33_n_0\,
      S(0) => \derivative[22]_i_34_n_0\
    );
\derivative_reg[22]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_35_n_0\,
      CO(3) => \derivative_reg[22]_i_30_n_0\,
      CO(2) => \derivative_reg[22]_i_30_n_1\,
      CO(1) => \derivative_reg[22]_i_30_n_2\,
      CO(0) => \derivative_reg[22]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[23]_i_30_n_5\,
      DI(2) => \derivative_reg[23]_i_30_n_6\,
      DI(1) => \derivative_reg[23]_i_30_n_7\,
      DI(0) => \derivative_reg[23]_i_35_n_4\,
      O(3) => \derivative_reg[22]_i_30_n_4\,
      O(2) => \derivative_reg[22]_i_30_n_5\,
      O(1) => \derivative_reg[22]_i_30_n_6\,
      O(0) => \derivative_reg[22]_i_30_n_7\,
      S(3) => \derivative[22]_i_36_n_0\,
      S(2) => \derivative[22]_i_37_n_0\,
      S(1) => \derivative[22]_i_38_n_0\,
      S(0) => \derivative[22]_i_39_n_0\
    );
\derivative_reg[22]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[22]_i_35_n_0\,
      CO(2) => \derivative_reg[22]_i_35_n_1\,
      CO(1) => \derivative_reg[22]_i_35_n_2\,
      CO(0) => \derivative_reg[22]_i_35_n_3\,
      CYINIT => \derivative_reg[23]_i_1_n_2\,
      DI(3) => \derivative_reg[23]_i_35_n_5\,
      DI(2) => \derivative_reg[23]_i_35_n_6\,
      DI(1) => derivative11_out(22),
      DI(0) => '0',
      O(3) => \derivative_reg[22]_i_35_n_4\,
      O(2) => \derivative_reg[22]_i_35_n_5\,
      O(1) => \derivative_reg[22]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[22]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[22]_i_40_n_0\,
      S(2) => \derivative[22]_i_41_n_0\,
      S(1) => \derivative[22]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[22]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[22]_i_10_n_0\,
      CO(3) => \derivative_reg[22]_i_5_n_0\,
      CO(2) => \derivative_reg[22]_i_5_n_1\,
      CO(1) => \derivative_reg[22]_i_5_n_2\,
      CO(0) => \derivative_reg[22]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[23]_i_5_n_5\,
      DI(2) => \derivative_reg[23]_i_5_n_6\,
      DI(1) => \derivative_reg[23]_i_5_n_7\,
      DI(0) => \derivative_reg[23]_i_10_n_4\,
      O(3) => \derivative_reg[22]_i_5_n_4\,
      O(2) => \derivative_reg[22]_i_5_n_5\,
      O(1) => \derivative_reg[22]_i_5_n_6\,
      O(0) => \derivative_reg[22]_i_5_n_7\,
      S(3) => \derivative[22]_i_11_n_0\,
      S(2) => \derivative[22]_i_12_n_0\,
      S(1) => \derivative[22]_i_13_n_0\,
      S(0) => \derivative[22]_i_14_n_0\
    );
\derivative_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[23]_i_1_n_2\,
      Q => derivative_out(23),
      R => '0'
    );
\derivative_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[23]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[23]_i_1_n_2\,
      CO(0) => \derivative_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[24]_i_1_n_2\,
      DI(0) => \derivative_reg[24]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[23]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[23]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[23]_i_3_n_0\,
      S(0) => \derivative[23]_i_4_n_0\
    );
\derivative_reg[23]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_15_n_0\,
      CO(3) => \derivative_reg[23]_i_10_n_0\,
      CO(2) => \derivative_reg[23]_i_10_n_1\,
      CO(1) => \derivative_reg[23]_i_10_n_2\,
      CO(0) => \derivative_reg[23]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[24]_i_10_n_5\,
      DI(2) => \derivative_reg[24]_i_10_n_6\,
      DI(1) => \derivative_reg[24]_i_10_n_7\,
      DI(0) => \derivative_reg[24]_i_15_n_4\,
      O(3) => \derivative_reg[23]_i_10_n_4\,
      O(2) => \derivative_reg[23]_i_10_n_5\,
      O(1) => \derivative_reg[23]_i_10_n_6\,
      O(0) => \derivative_reg[23]_i_10_n_7\,
      S(3) => \derivative[23]_i_16_n_0\,
      S(2) => \derivative[23]_i_17_n_0\,
      S(1) => \derivative[23]_i_18_n_0\,
      S(0) => \derivative[23]_i_19_n_0\
    );
\derivative_reg[23]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_20_n_0\,
      CO(3) => \derivative_reg[23]_i_15_n_0\,
      CO(2) => \derivative_reg[23]_i_15_n_1\,
      CO(1) => \derivative_reg[23]_i_15_n_2\,
      CO(0) => \derivative_reg[23]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[24]_i_15_n_5\,
      DI(2) => \derivative_reg[24]_i_15_n_6\,
      DI(1) => \derivative_reg[24]_i_15_n_7\,
      DI(0) => \derivative_reg[24]_i_20_n_4\,
      O(3) => \derivative_reg[23]_i_15_n_4\,
      O(2) => \derivative_reg[23]_i_15_n_5\,
      O(1) => \derivative_reg[23]_i_15_n_6\,
      O(0) => \derivative_reg[23]_i_15_n_7\,
      S(3) => \derivative[23]_i_21_n_0\,
      S(2) => \derivative[23]_i_22_n_0\,
      S(1) => \derivative[23]_i_23_n_0\,
      S(0) => \derivative[23]_i_24_n_0\
    );
\derivative_reg[23]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_5_n_0\,
      CO(3) => \derivative_reg[23]_i_2_n_0\,
      CO(2) => \derivative_reg[23]_i_2_n_1\,
      CO(1) => \derivative_reg[23]_i_2_n_2\,
      CO(0) => \derivative_reg[23]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[24]_i_2_n_5\,
      DI(2) => \derivative_reg[24]_i_2_n_6\,
      DI(1) => \derivative_reg[24]_i_2_n_7\,
      DI(0) => \derivative_reg[24]_i_5_n_4\,
      O(3) => \derivative_reg[23]_i_2_n_4\,
      O(2) => \derivative_reg[23]_i_2_n_5\,
      O(1) => \derivative_reg[23]_i_2_n_6\,
      O(0) => \derivative_reg[23]_i_2_n_7\,
      S(3) => \derivative[23]_i_6_n_0\,
      S(2) => \derivative[23]_i_7_n_0\,
      S(1) => \derivative[23]_i_8_n_0\,
      S(0) => \derivative[23]_i_9_n_0\
    );
\derivative_reg[23]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_25_n_0\,
      CO(3) => \derivative_reg[23]_i_20_n_0\,
      CO(2) => \derivative_reg[23]_i_20_n_1\,
      CO(1) => \derivative_reg[23]_i_20_n_2\,
      CO(0) => \derivative_reg[23]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[24]_i_20_n_5\,
      DI(2) => \derivative_reg[24]_i_20_n_6\,
      DI(1) => \derivative_reg[24]_i_20_n_7\,
      DI(0) => \derivative_reg[24]_i_25_n_4\,
      O(3) => \derivative_reg[23]_i_20_n_4\,
      O(2) => \derivative_reg[23]_i_20_n_5\,
      O(1) => \derivative_reg[23]_i_20_n_6\,
      O(0) => \derivative_reg[23]_i_20_n_7\,
      S(3) => \derivative[23]_i_26_n_0\,
      S(2) => \derivative[23]_i_27_n_0\,
      S(1) => \derivative[23]_i_28_n_0\,
      S(0) => \derivative[23]_i_29_n_0\
    );
\derivative_reg[23]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_30_n_0\,
      CO(3) => \derivative_reg[23]_i_25_n_0\,
      CO(2) => \derivative_reg[23]_i_25_n_1\,
      CO(1) => \derivative_reg[23]_i_25_n_2\,
      CO(0) => \derivative_reg[23]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[24]_i_25_n_5\,
      DI(2) => \derivative_reg[24]_i_25_n_6\,
      DI(1) => \derivative_reg[24]_i_25_n_7\,
      DI(0) => \derivative_reg[24]_i_30_n_4\,
      O(3) => \derivative_reg[23]_i_25_n_4\,
      O(2) => \derivative_reg[23]_i_25_n_5\,
      O(1) => \derivative_reg[23]_i_25_n_6\,
      O(0) => \derivative_reg[23]_i_25_n_7\,
      S(3) => \derivative[23]_i_31_n_0\,
      S(2) => \derivative[23]_i_32_n_0\,
      S(1) => \derivative[23]_i_33_n_0\,
      S(0) => \derivative[23]_i_34_n_0\
    );
\derivative_reg[23]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_35_n_0\,
      CO(3) => \derivative_reg[23]_i_30_n_0\,
      CO(2) => \derivative_reg[23]_i_30_n_1\,
      CO(1) => \derivative_reg[23]_i_30_n_2\,
      CO(0) => \derivative_reg[23]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[24]_i_30_n_5\,
      DI(2) => \derivative_reg[24]_i_30_n_6\,
      DI(1) => \derivative_reg[24]_i_30_n_7\,
      DI(0) => \derivative_reg[24]_i_35_n_4\,
      O(3) => \derivative_reg[23]_i_30_n_4\,
      O(2) => \derivative_reg[23]_i_30_n_5\,
      O(1) => \derivative_reg[23]_i_30_n_6\,
      O(0) => \derivative_reg[23]_i_30_n_7\,
      S(3) => \derivative[23]_i_36_n_0\,
      S(2) => \derivative[23]_i_37_n_0\,
      S(1) => \derivative[23]_i_38_n_0\,
      S(0) => \derivative[23]_i_39_n_0\
    );
\derivative_reg[23]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[23]_i_35_n_0\,
      CO(2) => \derivative_reg[23]_i_35_n_1\,
      CO(1) => \derivative_reg[23]_i_35_n_2\,
      CO(0) => \derivative_reg[23]_i_35_n_3\,
      CYINIT => \derivative_reg[24]_i_1_n_2\,
      DI(3) => \derivative_reg[24]_i_35_n_5\,
      DI(2) => \derivative_reg[24]_i_35_n_6\,
      DI(1) => derivative11_out(23),
      DI(0) => '0',
      O(3) => \derivative_reg[23]_i_35_n_4\,
      O(2) => \derivative_reg[23]_i_35_n_5\,
      O(1) => \derivative_reg[23]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[23]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[23]_i_40_n_0\,
      S(2) => \derivative[23]_i_41_n_0\,
      S(1) => \derivative[23]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[23]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[23]_i_10_n_0\,
      CO(3) => \derivative_reg[23]_i_5_n_0\,
      CO(2) => \derivative_reg[23]_i_5_n_1\,
      CO(1) => \derivative_reg[23]_i_5_n_2\,
      CO(0) => \derivative_reg[23]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[24]_i_5_n_5\,
      DI(2) => \derivative_reg[24]_i_5_n_6\,
      DI(1) => \derivative_reg[24]_i_5_n_7\,
      DI(0) => \derivative_reg[24]_i_10_n_4\,
      O(3) => \derivative_reg[23]_i_5_n_4\,
      O(2) => \derivative_reg[23]_i_5_n_5\,
      O(1) => \derivative_reg[23]_i_5_n_6\,
      O(0) => \derivative_reg[23]_i_5_n_7\,
      S(3) => \derivative[23]_i_11_n_0\,
      S(2) => \derivative[23]_i_12_n_0\,
      S(1) => \derivative[23]_i_13_n_0\,
      S(0) => \derivative[23]_i_14_n_0\
    );
\derivative_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[24]_i_1_n_2\,
      Q => derivative_out(24),
      R => '0'
    );
\derivative_reg[24]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[24]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[24]_i_1_n_2\,
      CO(0) => \derivative_reg[24]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[25]_i_1_n_2\,
      DI(0) => \derivative_reg[25]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[24]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[24]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[24]_i_3_n_0\,
      S(0) => \derivative[24]_i_4_n_0\
    );
\derivative_reg[24]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_15_n_0\,
      CO(3) => \derivative_reg[24]_i_10_n_0\,
      CO(2) => \derivative_reg[24]_i_10_n_1\,
      CO(1) => \derivative_reg[24]_i_10_n_2\,
      CO(0) => \derivative_reg[24]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[25]_i_10_n_5\,
      DI(2) => \derivative_reg[25]_i_10_n_6\,
      DI(1) => \derivative_reg[25]_i_10_n_7\,
      DI(0) => \derivative_reg[25]_i_15_n_4\,
      O(3) => \derivative_reg[24]_i_10_n_4\,
      O(2) => \derivative_reg[24]_i_10_n_5\,
      O(1) => \derivative_reg[24]_i_10_n_6\,
      O(0) => \derivative_reg[24]_i_10_n_7\,
      S(3) => \derivative[24]_i_16_n_0\,
      S(2) => \derivative[24]_i_17_n_0\,
      S(1) => \derivative[24]_i_18_n_0\,
      S(0) => \derivative[24]_i_19_n_0\
    );
\derivative_reg[24]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_20_n_0\,
      CO(3) => \derivative_reg[24]_i_15_n_0\,
      CO(2) => \derivative_reg[24]_i_15_n_1\,
      CO(1) => \derivative_reg[24]_i_15_n_2\,
      CO(0) => \derivative_reg[24]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[25]_i_15_n_5\,
      DI(2) => \derivative_reg[25]_i_15_n_6\,
      DI(1) => \derivative_reg[25]_i_15_n_7\,
      DI(0) => \derivative_reg[25]_i_20_n_4\,
      O(3) => \derivative_reg[24]_i_15_n_4\,
      O(2) => \derivative_reg[24]_i_15_n_5\,
      O(1) => \derivative_reg[24]_i_15_n_6\,
      O(0) => \derivative_reg[24]_i_15_n_7\,
      S(3) => \derivative[24]_i_21_n_0\,
      S(2) => \derivative[24]_i_22_n_0\,
      S(1) => \derivative[24]_i_23_n_0\,
      S(0) => \derivative[24]_i_24_n_0\
    );
\derivative_reg[24]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_5_n_0\,
      CO(3) => \derivative_reg[24]_i_2_n_0\,
      CO(2) => \derivative_reg[24]_i_2_n_1\,
      CO(1) => \derivative_reg[24]_i_2_n_2\,
      CO(0) => \derivative_reg[24]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[25]_i_2_n_5\,
      DI(2) => \derivative_reg[25]_i_2_n_6\,
      DI(1) => \derivative_reg[25]_i_2_n_7\,
      DI(0) => \derivative_reg[25]_i_5_n_4\,
      O(3) => \derivative_reg[24]_i_2_n_4\,
      O(2) => \derivative_reg[24]_i_2_n_5\,
      O(1) => \derivative_reg[24]_i_2_n_6\,
      O(0) => \derivative_reg[24]_i_2_n_7\,
      S(3) => \derivative[24]_i_6_n_0\,
      S(2) => \derivative[24]_i_7_n_0\,
      S(1) => \derivative[24]_i_8_n_0\,
      S(0) => \derivative[24]_i_9_n_0\
    );
\derivative_reg[24]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_25_n_0\,
      CO(3) => \derivative_reg[24]_i_20_n_0\,
      CO(2) => \derivative_reg[24]_i_20_n_1\,
      CO(1) => \derivative_reg[24]_i_20_n_2\,
      CO(0) => \derivative_reg[24]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[25]_i_20_n_5\,
      DI(2) => \derivative_reg[25]_i_20_n_6\,
      DI(1) => \derivative_reg[25]_i_20_n_7\,
      DI(0) => \derivative_reg[25]_i_25_n_4\,
      O(3) => \derivative_reg[24]_i_20_n_4\,
      O(2) => \derivative_reg[24]_i_20_n_5\,
      O(1) => \derivative_reg[24]_i_20_n_6\,
      O(0) => \derivative_reg[24]_i_20_n_7\,
      S(3) => \derivative[24]_i_26_n_0\,
      S(2) => \derivative[24]_i_27_n_0\,
      S(1) => \derivative[24]_i_28_n_0\,
      S(0) => \derivative[24]_i_29_n_0\
    );
\derivative_reg[24]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_30_n_0\,
      CO(3) => \derivative_reg[24]_i_25_n_0\,
      CO(2) => \derivative_reg[24]_i_25_n_1\,
      CO(1) => \derivative_reg[24]_i_25_n_2\,
      CO(0) => \derivative_reg[24]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[25]_i_25_n_5\,
      DI(2) => \derivative_reg[25]_i_25_n_6\,
      DI(1) => \derivative_reg[25]_i_25_n_7\,
      DI(0) => \derivative_reg[25]_i_30_n_4\,
      O(3) => \derivative_reg[24]_i_25_n_4\,
      O(2) => \derivative_reg[24]_i_25_n_5\,
      O(1) => \derivative_reg[24]_i_25_n_6\,
      O(0) => \derivative_reg[24]_i_25_n_7\,
      S(3) => \derivative[24]_i_31_n_0\,
      S(2) => \derivative[24]_i_32_n_0\,
      S(1) => \derivative[24]_i_33_n_0\,
      S(0) => \derivative[24]_i_34_n_0\
    );
\derivative_reg[24]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_35_n_0\,
      CO(3) => \derivative_reg[24]_i_30_n_0\,
      CO(2) => \derivative_reg[24]_i_30_n_1\,
      CO(1) => \derivative_reg[24]_i_30_n_2\,
      CO(0) => \derivative_reg[24]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[25]_i_30_n_5\,
      DI(2) => \derivative_reg[25]_i_30_n_6\,
      DI(1) => \derivative_reg[25]_i_30_n_7\,
      DI(0) => \derivative_reg[25]_i_35_n_4\,
      O(3) => \derivative_reg[24]_i_30_n_4\,
      O(2) => \derivative_reg[24]_i_30_n_5\,
      O(1) => \derivative_reg[24]_i_30_n_6\,
      O(0) => \derivative_reg[24]_i_30_n_7\,
      S(3) => \derivative[24]_i_36_n_0\,
      S(2) => \derivative[24]_i_37_n_0\,
      S(1) => \derivative[24]_i_38_n_0\,
      S(0) => \derivative[24]_i_39_n_0\
    );
\derivative_reg[24]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[24]_i_35_n_0\,
      CO(2) => \derivative_reg[24]_i_35_n_1\,
      CO(1) => \derivative_reg[24]_i_35_n_2\,
      CO(0) => \derivative_reg[24]_i_35_n_3\,
      CYINIT => \derivative_reg[25]_i_1_n_2\,
      DI(3) => \derivative_reg[25]_i_35_n_5\,
      DI(2) => \derivative_reg[25]_i_35_n_6\,
      DI(1) => derivative11_out(24),
      DI(0) => '0',
      O(3) => \derivative_reg[24]_i_35_n_4\,
      O(2) => \derivative_reg[24]_i_35_n_5\,
      O(1) => \derivative_reg[24]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[24]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[24]_i_40_n_0\,
      S(2) => \derivative[24]_i_41_n_0\,
      S(1) => \derivative[24]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[24]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[24]_i_10_n_0\,
      CO(3) => \derivative_reg[24]_i_5_n_0\,
      CO(2) => \derivative_reg[24]_i_5_n_1\,
      CO(1) => \derivative_reg[24]_i_5_n_2\,
      CO(0) => \derivative_reg[24]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[25]_i_5_n_5\,
      DI(2) => \derivative_reg[25]_i_5_n_6\,
      DI(1) => \derivative_reg[25]_i_5_n_7\,
      DI(0) => \derivative_reg[25]_i_10_n_4\,
      O(3) => \derivative_reg[24]_i_5_n_4\,
      O(2) => \derivative_reg[24]_i_5_n_5\,
      O(1) => \derivative_reg[24]_i_5_n_6\,
      O(0) => \derivative_reg[24]_i_5_n_7\,
      S(3) => \derivative[24]_i_11_n_0\,
      S(2) => \derivative[24]_i_12_n_0\,
      S(1) => \derivative[24]_i_13_n_0\,
      S(0) => \derivative[24]_i_14_n_0\
    );
\derivative_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[25]_i_1_n_2\,
      Q => derivative_out(25),
      R => '0'
    );
\derivative_reg[25]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[25]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[25]_i_1_n_2\,
      CO(0) => \derivative_reg[25]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[26]_i_1_n_2\,
      DI(0) => \derivative_reg[26]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[25]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[25]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[25]_i_3_n_0\,
      S(0) => \derivative[25]_i_4_n_0\
    );
\derivative_reg[25]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_15_n_0\,
      CO(3) => \derivative_reg[25]_i_10_n_0\,
      CO(2) => \derivative_reg[25]_i_10_n_1\,
      CO(1) => \derivative_reg[25]_i_10_n_2\,
      CO(0) => \derivative_reg[25]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[26]_i_10_n_5\,
      DI(2) => \derivative_reg[26]_i_10_n_6\,
      DI(1) => \derivative_reg[26]_i_10_n_7\,
      DI(0) => \derivative_reg[26]_i_15_n_4\,
      O(3) => \derivative_reg[25]_i_10_n_4\,
      O(2) => \derivative_reg[25]_i_10_n_5\,
      O(1) => \derivative_reg[25]_i_10_n_6\,
      O(0) => \derivative_reg[25]_i_10_n_7\,
      S(3) => \derivative[25]_i_16_n_0\,
      S(2) => \derivative[25]_i_17_n_0\,
      S(1) => \derivative[25]_i_18_n_0\,
      S(0) => \derivative[25]_i_19_n_0\
    );
\derivative_reg[25]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_20_n_0\,
      CO(3) => \derivative_reg[25]_i_15_n_0\,
      CO(2) => \derivative_reg[25]_i_15_n_1\,
      CO(1) => \derivative_reg[25]_i_15_n_2\,
      CO(0) => \derivative_reg[25]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[26]_i_15_n_5\,
      DI(2) => \derivative_reg[26]_i_15_n_6\,
      DI(1) => \derivative_reg[26]_i_15_n_7\,
      DI(0) => \derivative_reg[26]_i_20_n_4\,
      O(3) => \derivative_reg[25]_i_15_n_4\,
      O(2) => \derivative_reg[25]_i_15_n_5\,
      O(1) => \derivative_reg[25]_i_15_n_6\,
      O(0) => \derivative_reg[25]_i_15_n_7\,
      S(3) => \derivative[25]_i_21_n_0\,
      S(2) => \derivative[25]_i_22_n_0\,
      S(1) => \derivative[25]_i_23_n_0\,
      S(0) => \derivative[25]_i_24_n_0\
    );
\derivative_reg[25]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_5_n_0\,
      CO(3) => \derivative_reg[25]_i_2_n_0\,
      CO(2) => \derivative_reg[25]_i_2_n_1\,
      CO(1) => \derivative_reg[25]_i_2_n_2\,
      CO(0) => \derivative_reg[25]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[26]_i_2_n_5\,
      DI(2) => \derivative_reg[26]_i_2_n_6\,
      DI(1) => \derivative_reg[26]_i_2_n_7\,
      DI(0) => \derivative_reg[26]_i_5_n_4\,
      O(3) => \derivative_reg[25]_i_2_n_4\,
      O(2) => \derivative_reg[25]_i_2_n_5\,
      O(1) => \derivative_reg[25]_i_2_n_6\,
      O(0) => \derivative_reg[25]_i_2_n_7\,
      S(3) => \derivative[25]_i_6_n_0\,
      S(2) => \derivative[25]_i_7_n_0\,
      S(1) => \derivative[25]_i_8_n_0\,
      S(0) => \derivative[25]_i_9_n_0\
    );
\derivative_reg[25]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_25_n_0\,
      CO(3) => \derivative_reg[25]_i_20_n_0\,
      CO(2) => \derivative_reg[25]_i_20_n_1\,
      CO(1) => \derivative_reg[25]_i_20_n_2\,
      CO(0) => \derivative_reg[25]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[26]_i_20_n_5\,
      DI(2) => \derivative_reg[26]_i_20_n_6\,
      DI(1) => \derivative_reg[26]_i_20_n_7\,
      DI(0) => \derivative_reg[26]_i_25_n_4\,
      O(3) => \derivative_reg[25]_i_20_n_4\,
      O(2) => \derivative_reg[25]_i_20_n_5\,
      O(1) => \derivative_reg[25]_i_20_n_6\,
      O(0) => \derivative_reg[25]_i_20_n_7\,
      S(3) => \derivative[25]_i_26_n_0\,
      S(2) => \derivative[25]_i_27_n_0\,
      S(1) => \derivative[25]_i_28_n_0\,
      S(0) => \derivative[25]_i_29_n_0\
    );
\derivative_reg[25]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_30_n_0\,
      CO(3) => \derivative_reg[25]_i_25_n_0\,
      CO(2) => \derivative_reg[25]_i_25_n_1\,
      CO(1) => \derivative_reg[25]_i_25_n_2\,
      CO(0) => \derivative_reg[25]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[26]_i_25_n_5\,
      DI(2) => \derivative_reg[26]_i_25_n_6\,
      DI(1) => \derivative_reg[26]_i_25_n_7\,
      DI(0) => \derivative_reg[26]_i_30_n_4\,
      O(3) => \derivative_reg[25]_i_25_n_4\,
      O(2) => \derivative_reg[25]_i_25_n_5\,
      O(1) => \derivative_reg[25]_i_25_n_6\,
      O(0) => \derivative_reg[25]_i_25_n_7\,
      S(3) => \derivative[25]_i_31_n_0\,
      S(2) => \derivative[25]_i_32_n_0\,
      S(1) => \derivative[25]_i_33_n_0\,
      S(0) => \derivative[25]_i_34_n_0\
    );
\derivative_reg[25]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_35_n_0\,
      CO(3) => \derivative_reg[25]_i_30_n_0\,
      CO(2) => \derivative_reg[25]_i_30_n_1\,
      CO(1) => \derivative_reg[25]_i_30_n_2\,
      CO(0) => \derivative_reg[25]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[26]_i_30_n_5\,
      DI(2) => \derivative_reg[26]_i_30_n_6\,
      DI(1) => \derivative_reg[26]_i_30_n_7\,
      DI(0) => \derivative_reg[26]_i_35_n_4\,
      O(3) => \derivative_reg[25]_i_30_n_4\,
      O(2) => \derivative_reg[25]_i_30_n_5\,
      O(1) => \derivative_reg[25]_i_30_n_6\,
      O(0) => \derivative_reg[25]_i_30_n_7\,
      S(3) => \derivative[25]_i_36_n_0\,
      S(2) => \derivative[25]_i_37_n_0\,
      S(1) => \derivative[25]_i_38_n_0\,
      S(0) => \derivative[25]_i_39_n_0\
    );
\derivative_reg[25]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[25]_i_35_n_0\,
      CO(2) => \derivative_reg[25]_i_35_n_1\,
      CO(1) => \derivative_reg[25]_i_35_n_2\,
      CO(0) => \derivative_reg[25]_i_35_n_3\,
      CYINIT => \derivative_reg[26]_i_1_n_2\,
      DI(3) => \derivative_reg[26]_i_35_n_5\,
      DI(2) => \derivative_reg[26]_i_35_n_6\,
      DI(1) => derivative11_out(25),
      DI(0) => '0',
      O(3) => \derivative_reg[25]_i_35_n_4\,
      O(2) => \derivative_reg[25]_i_35_n_5\,
      O(1) => \derivative_reg[25]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[25]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[25]_i_40_n_0\,
      S(2) => \derivative[25]_i_41_n_0\,
      S(1) => \derivative[25]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[25]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[25]_i_10_n_0\,
      CO(3) => \derivative_reg[25]_i_5_n_0\,
      CO(2) => \derivative_reg[25]_i_5_n_1\,
      CO(1) => \derivative_reg[25]_i_5_n_2\,
      CO(0) => \derivative_reg[25]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[26]_i_5_n_5\,
      DI(2) => \derivative_reg[26]_i_5_n_6\,
      DI(1) => \derivative_reg[26]_i_5_n_7\,
      DI(0) => \derivative_reg[26]_i_10_n_4\,
      O(3) => \derivative_reg[25]_i_5_n_4\,
      O(2) => \derivative_reg[25]_i_5_n_5\,
      O(1) => \derivative_reg[25]_i_5_n_6\,
      O(0) => \derivative_reg[25]_i_5_n_7\,
      S(3) => \derivative[25]_i_11_n_0\,
      S(2) => \derivative[25]_i_12_n_0\,
      S(1) => \derivative[25]_i_13_n_0\,
      S(0) => \derivative[25]_i_14_n_0\
    );
\derivative_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[26]_i_1_n_2\,
      Q => derivative_out(26),
      R => '0'
    );
\derivative_reg[26]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[26]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[26]_i_1_n_2\,
      CO(0) => \derivative_reg[26]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[27]_i_1_n_2\,
      DI(0) => \derivative_reg[27]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[26]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[26]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[26]_i_3_n_0\,
      S(0) => \derivative[26]_i_4_n_0\
    );
\derivative_reg[26]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_15_n_0\,
      CO(3) => \derivative_reg[26]_i_10_n_0\,
      CO(2) => \derivative_reg[26]_i_10_n_1\,
      CO(1) => \derivative_reg[26]_i_10_n_2\,
      CO(0) => \derivative_reg[26]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[27]_i_10_n_5\,
      DI(2) => \derivative_reg[27]_i_10_n_6\,
      DI(1) => \derivative_reg[27]_i_10_n_7\,
      DI(0) => \derivative_reg[27]_i_15_n_4\,
      O(3) => \derivative_reg[26]_i_10_n_4\,
      O(2) => \derivative_reg[26]_i_10_n_5\,
      O(1) => \derivative_reg[26]_i_10_n_6\,
      O(0) => \derivative_reg[26]_i_10_n_7\,
      S(3) => \derivative[26]_i_16_n_0\,
      S(2) => \derivative[26]_i_17_n_0\,
      S(1) => \derivative[26]_i_18_n_0\,
      S(0) => \derivative[26]_i_19_n_0\
    );
\derivative_reg[26]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_20_n_0\,
      CO(3) => \derivative_reg[26]_i_15_n_0\,
      CO(2) => \derivative_reg[26]_i_15_n_1\,
      CO(1) => \derivative_reg[26]_i_15_n_2\,
      CO(0) => \derivative_reg[26]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[27]_i_15_n_5\,
      DI(2) => \derivative_reg[27]_i_15_n_6\,
      DI(1) => \derivative_reg[27]_i_15_n_7\,
      DI(0) => \derivative_reg[27]_i_20_n_4\,
      O(3) => \derivative_reg[26]_i_15_n_4\,
      O(2) => \derivative_reg[26]_i_15_n_5\,
      O(1) => \derivative_reg[26]_i_15_n_6\,
      O(0) => \derivative_reg[26]_i_15_n_7\,
      S(3) => \derivative[26]_i_21_n_0\,
      S(2) => \derivative[26]_i_22_n_0\,
      S(1) => \derivative[26]_i_23_n_0\,
      S(0) => \derivative[26]_i_24_n_0\
    );
\derivative_reg[26]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_5_n_0\,
      CO(3) => \derivative_reg[26]_i_2_n_0\,
      CO(2) => \derivative_reg[26]_i_2_n_1\,
      CO(1) => \derivative_reg[26]_i_2_n_2\,
      CO(0) => \derivative_reg[26]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[27]_i_2_n_5\,
      DI(2) => \derivative_reg[27]_i_2_n_6\,
      DI(1) => \derivative_reg[27]_i_2_n_7\,
      DI(0) => \derivative_reg[27]_i_5_n_4\,
      O(3) => \derivative_reg[26]_i_2_n_4\,
      O(2) => \derivative_reg[26]_i_2_n_5\,
      O(1) => \derivative_reg[26]_i_2_n_6\,
      O(0) => \derivative_reg[26]_i_2_n_7\,
      S(3) => \derivative[26]_i_6_n_0\,
      S(2) => \derivative[26]_i_7_n_0\,
      S(1) => \derivative[26]_i_8_n_0\,
      S(0) => \derivative[26]_i_9_n_0\
    );
\derivative_reg[26]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_25_n_0\,
      CO(3) => \derivative_reg[26]_i_20_n_0\,
      CO(2) => \derivative_reg[26]_i_20_n_1\,
      CO(1) => \derivative_reg[26]_i_20_n_2\,
      CO(0) => \derivative_reg[26]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[27]_i_20_n_5\,
      DI(2) => \derivative_reg[27]_i_20_n_6\,
      DI(1) => \derivative_reg[27]_i_20_n_7\,
      DI(0) => \derivative_reg[27]_i_25_n_4\,
      O(3) => \derivative_reg[26]_i_20_n_4\,
      O(2) => \derivative_reg[26]_i_20_n_5\,
      O(1) => \derivative_reg[26]_i_20_n_6\,
      O(0) => \derivative_reg[26]_i_20_n_7\,
      S(3) => \derivative[26]_i_26_n_0\,
      S(2) => \derivative[26]_i_27_n_0\,
      S(1) => \derivative[26]_i_28_n_0\,
      S(0) => \derivative[26]_i_29_n_0\
    );
\derivative_reg[26]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_30_n_0\,
      CO(3) => \derivative_reg[26]_i_25_n_0\,
      CO(2) => \derivative_reg[26]_i_25_n_1\,
      CO(1) => \derivative_reg[26]_i_25_n_2\,
      CO(0) => \derivative_reg[26]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[27]_i_25_n_5\,
      DI(2) => \derivative_reg[27]_i_25_n_6\,
      DI(1) => \derivative_reg[27]_i_25_n_7\,
      DI(0) => \derivative_reg[27]_i_30_n_4\,
      O(3) => \derivative_reg[26]_i_25_n_4\,
      O(2) => \derivative_reg[26]_i_25_n_5\,
      O(1) => \derivative_reg[26]_i_25_n_6\,
      O(0) => \derivative_reg[26]_i_25_n_7\,
      S(3) => \derivative[26]_i_31_n_0\,
      S(2) => \derivative[26]_i_32_n_0\,
      S(1) => \derivative[26]_i_33_n_0\,
      S(0) => \derivative[26]_i_34_n_0\
    );
\derivative_reg[26]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_35_n_0\,
      CO(3) => \derivative_reg[26]_i_30_n_0\,
      CO(2) => \derivative_reg[26]_i_30_n_1\,
      CO(1) => \derivative_reg[26]_i_30_n_2\,
      CO(0) => \derivative_reg[26]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[27]_i_30_n_5\,
      DI(2) => \derivative_reg[27]_i_30_n_6\,
      DI(1) => \derivative_reg[27]_i_30_n_7\,
      DI(0) => \derivative_reg[27]_i_35_n_4\,
      O(3) => \derivative_reg[26]_i_30_n_4\,
      O(2) => \derivative_reg[26]_i_30_n_5\,
      O(1) => \derivative_reg[26]_i_30_n_6\,
      O(0) => \derivative_reg[26]_i_30_n_7\,
      S(3) => \derivative[26]_i_36_n_0\,
      S(2) => \derivative[26]_i_37_n_0\,
      S(1) => \derivative[26]_i_38_n_0\,
      S(0) => \derivative[26]_i_39_n_0\
    );
\derivative_reg[26]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[26]_i_35_n_0\,
      CO(2) => \derivative_reg[26]_i_35_n_1\,
      CO(1) => \derivative_reg[26]_i_35_n_2\,
      CO(0) => \derivative_reg[26]_i_35_n_3\,
      CYINIT => \derivative_reg[27]_i_1_n_2\,
      DI(3) => \derivative_reg[27]_i_35_n_5\,
      DI(2) => \derivative_reg[27]_i_35_n_6\,
      DI(1) => derivative11_out(26),
      DI(0) => '0',
      O(3) => \derivative_reg[26]_i_35_n_4\,
      O(2) => \derivative_reg[26]_i_35_n_5\,
      O(1) => \derivative_reg[26]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[26]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[26]_i_40_n_0\,
      S(2) => \derivative[26]_i_41_n_0\,
      S(1) => \derivative[26]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[26]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[26]_i_10_n_0\,
      CO(3) => \derivative_reg[26]_i_5_n_0\,
      CO(2) => \derivative_reg[26]_i_5_n_1\,
      CO(1) => \derivative_reg[26]_i_5_n_2\,
      CO(0) => \derivative_reg[26]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[27]_i_5_n_5\,
      DI(2) => \derivative_reg[27]_i_5_n_6\,
      DI(1) => \derivative_reg[27]_i_5_n_7\,
      DI(0) => \derivative_reg[27]_i_10_n_4\,
      O(3) => \derivative_reg[26]_i_5_n_4\,
      O(2) => \derivative_reg[26]_i_5_n_5\,
      O(1) => \derivative_reg[26]_i_5_n_6\,
      O(0) => \derivative_reg[26]_i_5_n_7\,
      S(3) => \derivative[26]_i_11_n_0\,
      S(2) => \derivative[26]_i_12_n_0\,
      S(1) => \derivative[26]_i_13_n_0\,
      S(0) => \derivative[26]_i_14_n_0\
    );
\derivative_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[27]_i_1_n_2\,
      Q => derivative_out(27),
      R => '0'
    );
\derivative_reg[27]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[27]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[27]_i_1_n_2\,
      CO(0) => \derivative_reg[27]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[28]_i_1_n_2\,
      DI(0) => \derivative_reg[28]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[27]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[27]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[27]_i_3_n_0\,
      S(0) => \derivative[27]_i_4_n_0\
    );
\derivative_reg[27]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_15_n_0\,
      CO(3) => \derivative_reg[27]_i_10_n_0\,
      CO(2) => \derivative_reg[27]_i_10_n_1\,
      CO(1) => \derivative_reg[27]_i_10_n_2\,
      CO(0) => \derivative_reg[27]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[28]_i_10_n_5\,
      DI(2) => \derivative_reg[28]_i_10_n_6\,
      DI(1) => \derivative_reg[28]_i_10_n_7\,
      DI(0) => \derivative_reg[28]_i_15_n_4\,
      O(3) => \derivative_reg[27]_i_10_n_4\,
      O(2) => \derivative_reg[27]_i_10_n_5\,
      O(1) => \derivative_reg[27]_i_10_n_6\,
      O(0) => \derivative_reg[27]_i_10_n_7\,
      S(3) => \derivative[27]_i_16_n_0\,
      S(2) => \derivative[27]_i_17_n_0\,
      S(1) => \derivative[27]_i_18_n_0\,
      S(0) => \derivative[27]_i_19_n_0\
    );
\derivative_reg[27]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_20_n_0\,
      CO(3) => \derivative_reg[27]_i_15_n_0\,
      CO(2) => \derivative_reg[27]_i_15_n_1\,
      CO(1) => \derivative_reg[27]_i_15_n_2\,
      CO(0) => \derivative_reg[27]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[28]_i_15_n_5\,
      DI(2) => \derivative_reg[28]_i_15_n_6\,
      DI(1) => \derivative_reg[28]_i_15_n_7\,
      DI(0) => \derivative_reg[28]_i_20_n_4\,
      O(3) => \derivative_reg[27]_i_15_n_4\,
      O(2) => \derivative_reg[27]_i_15_n_5\,
      O(1) => \derivative_reg[27]_i_15_n_6\,
      O(0) => \derivative_reg[27]_i_15_n_7\,
      S(3) => \derivative[27]_i_21_n_0\,
      S(2) => \derivative[27]_i_22_n_0\,
      S(1) => \derivative[27]_i_23_n_0\,
      S(0) => \derivative[27]_i_24_n_0\
    );
\derivative_reg[27]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_5_n_0\,
      CO(3) => \derivative_reg[27]_i_2_n_0\,
      CO(2) => \derivative_reg[27]_i_2_n_1\,
      CO(1) => \derivative_reg[27]_i_2_n_2\,
      CO(0) => \derivative_reg[27]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[28]_i_2_n_5\,
      DI(2) => \derivative_reg[28]_i_2_n_6\,
      DI(1) => \derivative_reg[28]_i_2_n_7\,
      DI(0) => \derivative_reg[28]_i_5_n_4\,
      O(3) => \derivative_reg[27]_i_2_n_4\,
      O(2) => \derivative_reg[27]_i_2_n_5\,
      O(1) => \derivative_reg[27]_i_2_n_6\,
      O(0) => \derivative_reg[27]_i_2_n_7\,
      S(3) => \derivative[27]_i_6_n_0\,
      S(2) => \derivative[27]_i_7_n_0\,
      S(1) => \derivative[27]_i_8_n_0\,
      S(0) => \derivative[27]_i_9_n_0\
    );
\derivative_reg[27]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_25_n_0\,
      CO(3) => \derivative_reg[27]_i_20_n_0\,
      CO(2) => \derivative_reg[27]_i_20_n_1\,
      CO(1) => \derivative_reg[27]_i_20_n_2\,
      CO(0) => \derivative_reg[27]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[28]_i_20_n_5\,
      DI(2) => \derivative_reg[28]_i_20_n_6\,
      DI(1) => \derivative_reg[28]_i_20_n_7\,
      DI(0) => \derivative_reg[28]_i_25_n_4\,
      O(3) => \derivative_reg[27]_i_20_n_4\,
      O(2) => \derivative_reg[27]_i_20_n_5\,
      O(1) => \derivative_reg[27]_i_20_n_6\,
      O(0) => \derivative_reg[27]_i_20_n_7\,
      S(3) => \derivative[27]_i_26_n_0\,
      S(2) => \derivative[27]_i_27_n_0\,
      S(1) => \derivative[27]_i_28_n_0\,
      S(0) => \derivative[27]_i_29_n_0\
    );
\derivative_reg[27]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_30_n_0\,
      CO(3) => \derivative_reg[27]_i_25_n_0\,
      CO(2) => \derivative_reg[27]_i_25_n_1\,
      CO(1) => \derivative_reg[27]_i_25_n_2\,
      CO(0) => \derivative_reg[27]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[28]_i_25_n_5\,
      DI(2) => \derivative_reg[28]_i_25_n_6\,
      DI(1) => \derivative_reg[28]_i_25_n_7\,
      DI(0) => \derivative_reg[28]_i_30_n_4\,
      O(3) => \derivative_reg[27]_i_25_n_4\,
      O(2) => \derivative_reg[27]_i_25_n_5\,
      O(1) => \derivative_reg[27]_i_25_n_6\,
      O(0) => \derivative_reg[27]_i_25_n_7\,
      S(3) => \derivative[27]_i_31_n_0\,
      S(2) => \derivative[27]_i_32_n_0\,
      S(1) => \derivative[27]_i_33_n_0\,
      S(0) => \derivative[27]_i_34_n_0\
    );
\derivative_reg[27]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_35_n_0\,
      CO(3) => \derivative_reg[27]_i_30_n_0\,
      CO(2) => \derivative_reg[27]_i_30_n_1\,
      CO(1) => \derivative_reg[27]_i_30_n_2\,
      CO(0) => \derivative_reg[27]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[28]_i_30_n_5\,
      DI(2) => \derivative_reg[28]_i_30_n_6\,
      DI(1) => \derivative_reg[28]_i_30_n_7\,
      DI(0) => \derivative_reg[28]_i_35_n_4\,
      O(3) => \derivative_reg[27]_i_30_n_4\,
      O(2) => \derivative_reg[27]_i_30_n_5\,
      O(1) => \derivative_reg[27]_i_30_n_6\,
      O(0) => \derivative_reg[27]_i_30_n_7\,
      S(3) => \derivative[27]_i_36_n_0\,
      S(2) => \derivative[27]_i_37_n_0\,
      S(1) => \derivative[27]_i_38_n_0\,
      S(0) => \derivative[27]_i_39_n_0\
    );
\derivative_reg[27]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[27]_i_35_n_0\,
      CO(2) => \derivative_reg[27]_i_35_n_1\,
      CO(1) => \derivative_reg[27]_i_35_n_2\,
      CO(0) => \derivative_reg[27]_i_35_n_3\,
      CYINIT => \derivative_reg[28]_i_1_n_2\,
      DI(3) => \derivative_reg[28]_i_35_n_5\,
      DI(2) => \derivative_reg[28]_i_35_n_6\,
      DI(1) => derivative11_out(27),
      DI(0) => '0',
      O(3) => \derivative_reg[27]_i_35_n_4\,
      O(2) => \derivative_reg[27]_i_35_n_5\,
      O(1) => \derivative_reg[27]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[27]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[27]_i_40_n_0\,
      S(2) => \derivative[27]_i_41_n_0\,
      S(1) => \derivative[27]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[27]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[27]_i_10_n_0\,
      CO(3) => \derivative_reg[27]_i_5_n_0\,
      CO(2) => \derivative_reg[27]_i_5_n_1\,
      CO(1) => \derivative_reg[27]_i_5_n_2\,
      CO(0) => \derivative_reg[27]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[28]_i_5_n_5\,
      DI(2) => \derivative_reg[28]_i_5_n_6\,
      DI(1) => \derivative_reg[28]_i_5_n_7\,
      DI(0) => \derivative_reg[28]_i_10_n_4\,
      O(3) => \derivative_reg[27]_i_5_n_4\,
      O(2) => \derivative_reg[27]_i_5_n_5\,
      O(1) => \derivative_reg[27]_i_5_n_6\,
      O(0) => \derivative_reg[27]_i_5_n_7\,
      S(3) => \derivative[27]_i_11_n_0\,
      S(2) => \derivative[27]_i_12_n_0\,
      S(1) => \derivative[27]_i_13_n_0\,
      S(0) => \derivative[27]_i_14_n_0\
    );
\derivative_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[28]_i_1_n_2\,
      Q => derivative_out(28),
      R => '0'
    );
\derivative_reg[28]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[28]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[28]_i_1_n_2\,
      CO(0) => \derivative_reg[28]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[29]_i_1_n_2\,
      DI(0) => \derivative_reg[29]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[28]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[28]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[28]_i_3_n_0\,
      S(0) => \derivative[28]_i_4_n_0\
    );
\derivative_reg[28]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_15_n_0\,
      CO(3) => \derivative_reg[28]_i_10_n_0\,
      CO(2) => \derivative_reg[28]_i_10_n_1\,
      CO(1) => \derivative_reg[28]_i_10_n_2\,
      CO(0) => \derivative_reg[28]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[29]_i_10_n_5\,
      DI(2) => \derivative_reg[29]_i_10_n_6\,
      DI(1) => \derivative_reg[29]_i_10_n_7\,
      DI(0) => \derivative_reg[29]_i_15_n_4\,
      O(3) => \derivative_reg[28]_i_10_n_4\,
      O(2) => \derivative_reg[28]_i_10_n_5\,
      O(1) => \derivative_reg[28]_i_10_n_6\,
      O(0) => \derivative_reg[28]_i_10_n_7\,
      S(3) => \derivative[28]_i_16_n_0\,
      S(2) => \derivative[28]_i_17_n_0\,
      S(1) => \derivative[28]_i_18_n_0\,
      S(0) => \derivative[28]_i_19_n_0\
    );
\derivative_reg[28]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_20_n_0\,
      CO(3) => \derivative_reg[28]_i_15_n_0\,
      CO(2) => \derivative_reg[28]_i_15_n_1\,
      CO(1) => \derivative_reg[28]_i_15_n_2\,
      CO(0) => \derivative_reg[28]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[29]_i_15_n_5\,
      DI(2) => \derivative_reg[29]_i_15_n_6\,
      DI(1) => \derivative_reg[29]_i_15_n_7\,
      DI(0) => \derivative_reg[29]_i_20_n_4\,
      O(3) => \derivative_reg[28]_i_15_n_4\,
      O(2) => \derivative_reg[28]_i_15_n_5\,
      O(1) => \derivative_reg[28]_i_15_n_6\,
      O(0) => \derivative_reg[28]_i_15_n_7\,
      S(3) => \derivative[28]_i_21_n_0\,
      S(2) => \derivative[28]_i_22_n_0\,
      S(1) => \derivative[28]_i_23_n_0\,
      S(0) => \derivative[28]_i_24_n_0\
    );
\derivative_reg[28]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_5_n_0\,
      CO(3) => \derivative_reg[28]_i_2_n_0\,
      CO(2) => \derivative_reg[28]_i_2_n_1\,
      CO(1) => \derivative_reg[28]_i_2_n_2\,
      CO(0) => \derivative_reg[28]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[29]_i_2_n_5\,
      DI(2) => \derivative_reg[29]_i_2_n_6\,
      DI(1) => \derivative_reg[29]_i_2_n_7\,
      DI(0) => \derivative_reg[29]_i_5_n_4\,
      O(3) => \derivative_reg[28]_i_2_n_4\,
      O(2) => \derivative_reg[28]_i_2_n_5\,
      O(1) => \derivative_reg[28]_i_2_n_6\,
      O(0) => \derivative_reg[28]_i_2_n_7\,
      S(3) => \derivative[28]_i_6_n_0\,
      S(2) => \derivative[28]_i_7_n_0\,
      S(1) => \derivative[28]_i_8_n_0\,
      S(0) => \derivative[28]_i_9_n_0\
    );
\derivative_reg[28]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_25_n_0\,
      CO(3) => \derivative_reg[28]_i_20_n_0\,
      CO(2) => \derivative_reg[28]_i_20_n_1\,
      CO(1) => \derivative_reg[28]_i_20_n_2\,
      CO(0) => \derivative_reg[28]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[29]_i_20_n_5\,
      DI(2) => \derivative_reg[29]_i_20_n_6\,
      DI(1) => \derivative_reg[29]_i_20_n_7\,
      DI(0) => \derivative_reg[29]_i_25_n_4\,
      O(3) => \derivative_reg[28]_i_20_n_4\,
      O(2) => \derivative_reg[28]_i_20_n_5\,
      O(1) => \derivative_reg[28]_i_20_n_6\,
      O(0) => \derivative_reg[28]_i_20_n_7\,
      S(3) => \derivative[28]_i_26_n_0\,
      S(2) => \derivative[28]_i_27_n_0\,
      S(1) => \derivative[28]_i_28_n_0\,
      S(0) => \derivative[28]_i_29_n_0\
    );
\derivative_reg[28]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_30_n_0\,
      CO(3) => \derivative_reg[28]_i_25_n_0\,
      CO(2) => \derivative_reg[28]_i_25_n_1\,
      CO(1) => \derivative_reg[28]_i_25_n_2\,
      CO(0) => \derivative_reg[28]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[29]_i_25_n_5\,
      DI(2) => \derivative_reg[29]_i_25_n_6\,
      DI(1) => \derivative_reg[29]_i_25_n_7\,
      DI(0) => \derivative_reg[29]_i_30_n_4\,
      O(3) => \derivative_reg[28]_i_25_n_4\,
      O(2) => \derivative_reg[28]_i_25_n_5\,
      O(1) => \derivative_reg[28]_i_25_n_6\,
      O(0) => \derivative_reg[28]_i_25_n_7\,
      S(3) => \derivative[28]_i_31_n_0\,
      S(2) => \derivative[28]_i_32_n_0\,
      S(1) => \derivative[28]_i_33_n_0\,
      S(0) => \derivative[28]_i_34_n_0\
    );
\derivative_reg[28]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_35_n_0\,
      CO(3) => \derivative_reg[28]_i_30_n_0\,
      CO(2) => \derivative_reg[28]_i_30_n_1\,
      CO(1) => \derivative_reg[28]_i_30_n_2\,
      CO(0) => \derivative_reg[28]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[29]_i_30_n_5\,
      DI(2) => \derivative_reg[29]_i_30_n_6\,
      DI(1) => \derivative_reg[29]_i_30_n_7\,
      DI(0) => \derivative_reg[29]_i_35_n_4\,
      O(3) => \derivative_reg[28]_i_30_n_4\,
      O(2) => \derivative_reg[28]_i_30_n_5\,
      O(1) => \derivative_reg[28]_i_30_n_6\,
      O(0) => \derivative_reg[28]_i_30_n_7\,
      S(3) => \derivative[28]_i_36_n_0\,
      S(2) => \derivative[28]_i_37_n_0\,
      S(1) => \derivative[28]_i_38_n_0\,
      S(0) => \derivative[28]_i_39_n_0\
    );
\derivative_reg[28]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[28]_i_35_n_0\,
      CO(2) => \derivative_reg[28]_i_35_n_1\,
      CO(1) => \derivative_reg[28]_i_35_n_2\,
      CO(0) => \derivative_reg[28]_i_35_n_3\,
      CYINIT => \derivative_reg[29]_i_1_n_2\,
      DI(3) => \derivative_reg[29]_i_35_n_5\,
      DI(2) => \derivative_reg[29]_i_35_n_6\,
      DI(1) => derivative11_out(28),
      DI(0) => '0',
      O(3) => \derivative_reg[28]_i_35_n_4\,
      O(2) => \derivative_reg[28]_i_35_n_5\,
      O(1) => \derivative_reg[28]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[28]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[28]_i_40_n_0\,
      S(2) => \derivative[28]_i_41_n_0\,
      S(1) => \derivative[28]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[28]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[28]_i_10_n_0\,
      CO(3) => \derivative_reg[28]_i_5_n_0\,
      CO(2) => \derivative_reg[28]_i_5_n_1\,
      CO(1) => \derivative_reg[28]_i_5_n_2\,
      CO(0) => \derivative_reg[28]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[29]_i_5_n_5\,
      DI(2) => \derivative_reg[29]_i_5_n_6\,
      DI(1) => \derivative_reg[29]_i_5_n_7\,
      DI(0) => \derivative_reg[29]_i_10_n_4\,
      O(3) => \derivative_reg[28]_i_5_n_4\,
      O(2) => \derivative_reg[28]_i_5_n_5\,
      O(1) => \derivative_reg[28]_i_5_n_6\,
      O(0) => \derivative_reg[28]_i_5_n_7\,
      S(3) => \derivative[28]_i_11_n_0\,
      S(2) => \derivative[28]_i_12_n_0\,
      S(1) => \derivative[28]_i_13_n_0\,
      S(0) => \derivative[28]_i_14_n_0\
    );
\derivative_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[29]_i_1_n_2\,
      Q => derivative_out(29),
      R => '0'
    );
\derivative_reg[29]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[29]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[29]_i_1_n_2\,
      CO(0) => \derivative_reg[29]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[30]_i_1_n_2\,
      DI(0) => \derivative_reg[30]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[29]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[29]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[29]_i_3_n_0\,
      S(0) => \derivative[29]_i_4_n_0\
    );
\derivative_reg[29]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_15_n_0\,
      CO(3) => \derivative_reg[29]_i_10_n_0\,
      CO(2) => \derivative_reg[29]_i_10_n_1\,
      CO(1) => \derivative_reg[29]_i_10_n_2\,
      CO(0) => \derivative_reg[29]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[30]_i_10_n_5\,
      DI(2) => \derivative_reg[30]_i_10_n_6\,
      DI(1) => \derivative_reg[30]_i_10_n_7\,
      DI(0) => \derivative_reg[30]_i_15_n_4\,
      O(3) => \derivative_reg[29]_i_10_n_4\,
      O(2) => \derivative_reg[29]_i_10_n_5\,
      O(1) => \derivative_reg[29]_i_10_n_6\,
      O(0) => \derivative_reg[29]_i_10_n_7\,
      S(3) => \derivative[29]_i_16_n_0\,
      S(2) => \derivative[29]_i_17_n_0\,
      S(1) => \derivative[29]_i_18_n_0\,
      S(0) => \derivative[29]_i_19_n_0\
    );
\derivative_reg[29]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_20_n_0\,
      CO(3) => \derivative_reg[29]_i_15_n_0\,
      CO(2) => \derivative_reg[29]_i_15_n_1\,
      CO(1) => \derivative_reg[29]_i_15_n_2\,
      CO(0) => \derivative_reg[29]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[30]_i_15_n_5\,
      DI(2) => \derivative_reg[30]_i_15_n_6\,
      DI(1) => \derivative_reg[30]_i_15_n_7\,
      DI(0) => \derivative_reg[30]_i_20_n_4\,
      O(3) => \derivative_reg[29]_i_15_n_4\,
      O(2) => \derivative_reg[29]_i_15_n_5\,
      O(1) => \derivative_reg[29]_i_15_n_6\,
      O(0) => \derivative_reg[29]_i_15_n_7\,
      S(3) => \derivative[29]_i_21_n_0\,
      S(2) => \derivative[29]_i_22_n_0\,
      S(1) => \derivative[29]_i_23_n_0\,
      S(0) => \derivative[29]_i_24_n_0\
    );
\derivative_reg[29]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_5_n_0\,
      CO(3) => \derivative_reg[29]_i_2_n_0\,
      CO(2) => \derivative_reg[29]_i_2_n_1\,
      CO(1) => \derivative_reg[29]_i_2_n_2\,
      CO(0) => \derivative_reg[29]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[30]_i_2_n_5\,
      DI(2) => \derivative_reg[30]_i_2_n_6\,
      DI(1) => \derivative_reg[30]_i_2_n_7\,
      DI(0) => \derivative_reg[30]_i_5_n_4\,
      O(3) => \derivative_reg[29]_i_2_n_4\,
      O(2) => \derivative_reg[29]_i_2_n_5\,
      O(1) => \derivative_reg[29]_i_2_n_6\,
      O(0) => \derivative_reg[29]_i_2_n_7\,
      S(3) => \derivative[29]_i_6_n_0\,
      S(2) => \derivative[29]_i_7_n_0\,
      S(1) => \derivative[29]_i_8_n_0\,
      S(0) => \derivative[29]_i_9_n_0\
    );
\derivative_reg[29]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_25_n_0\,
      CO(3) => \derivative_reg[29]_i_20_n_0\,
      CO(2) => \derivative_reg[29]_i_20_n_1\,
      CO(1) => \derivative_reg[29]_i_20_n_2\,
      CO(0) => \derivative_reg[29]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[30]_i_20_n_5\,
      DI(2) => \derivative_reg[30]_i_20_n_6\,
      DI(1) => \derivative_reg[30]_i_20_n_7\,
      DI(0) => \derivative_reg[30]_i_25_n_4\,
      O(3) => \derivative_reg[29]_i_20_n_4\,
      O(2) => \derivative_reg[29]_i_20_n_5\,
      O(1) => \derivative_reg[29]_i_20_n_6\,
      O(0) => \derivative_reg[29]_i_20_n_7\,
      S(3) => \derivative[29]_i_26_n_0\,
      S(2) => \derivative[29]_i_27_n_0\,
      S(1) => \derivative[29]_i_28_n_0\,
      S(0) => \derivative[29]_i_29_n_0\
    );
\derivative_reg[29]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_30_n_0\,
      CO(3) => \derivative_reg[29]_i_25_n_0\,
      CO(2) => \derivative_reg[29]_i_25_n_1\,
      CO(1) => \derivative_reg[29]_i_25_n_2\,
      CO(0) => \derivative_reg[29]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[30]_i_25_n_5\,
      DI(2) => \derivative_reg[30]_i_25_n_6\,
      DI(1) => \derivative_reg[30]_i_25_n_7\,
      DI(0) => \derivative_reg[30]_i_30_n_4\,
      O(3) => \derivative_reg[29]_i_25_n_4\,
      O(2) => \derivative_reg[29]_i_25_n_5\,
      O(1) => \derivative_reg[29]_i_25_n_6\,
      O(0) => \derivative_reg[29]_i_25_n_7\,
      S(3) => \derivative[29]_i_31_n_0\,
      S(2) => \derivative[29]_i_32_n_0\,
      S(1) => \derivative[29]_i_33_n_0\,
      S(0) => \derivative[29]_i_34_n_0\
    );
\derivative_reg[29]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_35_n_0\,
      CO(3) => \derivative_reg[29]_i_30_n_0\,
      CO(2) => \derivative_reg[29]_i_30_n_1\,
      CO(1) => \derivative_reg[29]_i_30_n_2\,
      CO(0) => \derivative_reg[29]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[30]_i_30_n_5\,
      DI(2) => \derivative_reg[30]_i_30_n_6\,
      DI(1) => \derivative_reg[30]_i_30_n_7\,
      DI(0) => \derivative_reg[30]_i_35_n_4\,
      O(3) => \derivative_reg[29]_i_30_n_4\,
      O(2) => \derivative_reg[29]_i_30_n_5\,
      O(1) => \derivative_reg[29]_i_30_n_6\,
      O(0) => \derivative_reg[29]_i_30_n_7\,
      S(3) => \derivative[29]_i_36_n_0\,
      S(2) => \derivative[29]_i_37_n_0\,
      S(1) => \derivative[29]_i_38_n_0\,
      S(0) => \derivative[29]_i_39_n_0\
    );
\derivative_reg[29]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[29]_i_35_n_0\,
      CO(2) => \derivative_reg[29]_i_35_n_1\,
      CO(1) => \derivative_reg[29]_i_35_n_2\,
      CO(0) => \derivative_reg[29]_i_35_n_3\,
      CYINIT => \derivative_reg[30]_i_1_n_2\,
      DI(3) => \derivative_reg[30]_i_35_n_5\,
      DI(2) => \derivative_reg[30]_i_35_n_6\,
      DI(1) => derivative11_out(29),
      DI(0) => '0',
      O(3) => \derivative_reg[29]_i_35_n_4\,
      O(2) => \derivative_reg[29]_i_35_n_5\,
      O(1) => \derivative_reg[29]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[29]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[29]_i_40_n_0\,
      S(2) => \derivative[29]_i_41_n_0\,
      S(1) => \derivative[29]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[29]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[29]_i_10_n_0\,
      CO(3) => \derivative_reg[29]_i_5_n_0\,
      CO(2) => \derivative_reg[29]_i_5_n_1\,
      CO(1) => \derivative_reg[29]_i_5_n_2\,
      CO(0) => \derivative_reg[29]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[30]_i_5_n_5\,
      DI(2) => \derivative_reg[30]_i_5_n_6\,
      DI(1) => \derivative_reg[30]_i_5_n_7\,
      DI(0) => \derivative_reg[30]_i_10_n_4\,
      O(3) => \derivative_reg[29]_i_5_n_4\,
      O(2) => \derivative_reg[29]_i_5_n_5\,
      O(1) => \derivative_reg[29]_i_5_n_6\,
      O(0) => \derivative_reg[29]_i_5_n_7\,
      S(3) => \derivative[29]_i_11_n_0\,
      S(2) => \derivative[29]_i_12_n_0\,
      S(1) => \derivative[29]_i_13_n_0\,
      S(0) => \derivative[29]_i_14_n_0\
    );
\derivative_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[2]_i_1_n_2\,
      Q => derivative_out(2),
      R => '0'
    );
\derivative_reg[2]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[2]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[2]_i_1_n_2\,
      CO(0) => \derivative_reg[2]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[3]_i_1_n_2\,
      DI(0) => \derivative_reg[3]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[2]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[2]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[2]_i_3_n_0\,
      S(0) => \derivative[2]_i_4_n_0\
    );
\derivative_reg[2]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_15_n_0\,
      CO(3) => \derivative_reg[2]_i_10_n_0\,
      CO(2) => \derivative_reg[2]_i_10_n_1\,
      CO(1) => \derivative_reg[2]_i_10_n_2\,
      CO(0) => \derivative_reg[2]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[3]_i_10_n_5\,
      DI(2) => \derivative_reg[3]_i_10_n_6\,
      DI(1) => \derivative_reg[3]_i_10_n_7\,
      DI(0) => \derivative_reg[3]_i_15_n_4\,
      O(3) => \derivative_reg[2]_i_10_n_4\,
      O(2) => \derivative_reg[2]_i_10_n_5\,
      O(1) => \derivative_reg[2]_i_10_n_6\,
      O(0) => \derivative_reg[2]_i_10_n_7\,
      S(3) => \derivative[2]_i_16_n_0\,
      S(2) => \derivative[2]_i_17_n_0\,
      S(1) => \derivative[2]_i_18_n_0\,
      S(0) => \derivative[2]_i_19_n_0\
    );
\derivative_reg[2]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_20_n_0\,
      CO(3) => \derivative_reg[2]_i_15_n_0\,
      CO(2) => \derivative_reg[2]_i_15_n_1\,
      CO(1) => \derivative_reg[2]_i_15_n_2\,
      CO(0) => \derivative_reg[2]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[3]_i_15_n_5\,
      DI(2) => \derivative_reg[3]_i_15_n_6\,
      DI(1) => \derivative_reg[3]_i_15_n_7\,
      DI(0) => \derivative_reg[3]_i_20_n_4\,
      O(3) => \derivative_reg[2]_i_15_n_4\,
      O(2) => \derivative_reg[2]_i_15_n_5\,
      O(1) => \derivative_reg[2]_i_15_n_6\,
      O(0) => \derivative_reg[2]_i_15_n_7\,
      S(3) => \derivative[2]_i_21_n_0\,
      S(2) => \derivative[2]_i_22_n_0\,
      S(1) => \derivative[2]_i_23_n_0\,
      S(0) => \derivative[2]_i_24_n_0\
    );
\derivative_reg[2]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_5_n_0\,
      CO(3) => \derivative_reg[2]_i_2_n_0\,
      CO(2) => \derivative_reg[2]_i_2_n_1\,
      CO(1) => \derivative_reg[2]_i_2_n_2\,
      CO(0) => \derivative_reg[2]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[3]_i_2_n_5\,
      DI(2) => \derivative_reg[3]_i_2_n_6\,
      DI(1) => \derivative_reg[3]_i_2_n_7\,
      DI(0) => \derivative_reg[3]_i_5_n_4\,
      O(3) => \derivative_reg[2]_i_2_n_4\,
      O(2) => \derivative_reg[2]_i_2_n_5\,
      O(1) => \derivative_reg[2]_i_2_n_6\,
      O(0) => \derivative_reg[2]_i_2_n_7\,
      S(3) => \derivative[2]_i_6_n_0\,
      S(2) => \derivative[2]_i_7_n_0\,
      S(1) => \derivative[2]_i_8_n_0\,
      S(0) => \derivative[2]_i_9_n_0\
    );
\derivative_reg[2]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_25_n_0\,
      CO(3) => \derivative_reg[2]_i_20_n_0\,
      CO(2) => \derivative_reg[2]_i_20_n_1\,
      CO(1) => \derivative_reg[2]_i_20_n_2\,
      CO(0) => \derivative_reg[2]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[3]_i_20_n_5\,
      DI(2) => \derivative_reg[3]_i_20_n_6\,
      DI(1) => \derivative_reg[3]_i_20_n_7\,
      DI(0) => \derivative_reg[3]_i_25_n_4\,
      O(3) => \derivative_reg[2]_i_20_n_4\,
      O(2) => \derivative_reg[2]_i_20_n_5\,
      O(1) => \derivative_reg[2]_i_20_n_6\,
      O(0) => \derivative_reg[2]_i_20_n_7\,
      S(3) => \derivative[2]_i_26_n_0\,
      S(2) => \derivative[2]_i_27_n_0\,
      S(1) => \derivative[2]_i_28_n_0\,
      S(0) => \derivative[2]_i_29_n_0\
    );
\derivative_reg[2]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_30_n_0\,
      CO(3) => \derivative_reg[2]_i_25_n_0\,
      CO(2) => \derivative_reg[2]_i_25_n_1\,
      CO(1) => \derivative_reg[2]_i_25_n_2\,
      CO(0) => \derivative_reg[2]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[3]_i_25_n_5\,
      DI(2) => \derivative_reg[3]_i_25_n_6\,
      DI(1) => \derivative_reg[3]_i_25_n_7\,
      DI(0) => \derivative_reg[3]_i_30_n_4\,
      O(3) => \derivative_reg[2]_i_25_n_4\,
      O(2) => \derivative_reg[2]_i_25_n_5\,
      O(1) => \derivative_reg[2]_i_25_n_6\,
      O(0) => \derivative_reg[2]_i_25_n_7\,
      S(3) => \derivative[2]_i_31_n_0\,
      S(2) => \derivative[2]_i_32_n_0\,
      S(1) => \derivative[2]_i_33_n_0\,
      S(0) => \derivative[2]_i_34_n_0\
    );
\derivative_reg[2]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_35_n_0\,
      CO(3) => \derivative_reg[2]_i_30_n_0\,
      CO(2) => \derivative_reg[2]_i_30_n_1\,
      CO(1) => \derivative_reg[2]_i_30_n_2\,
      CO(0) => \derivative_reg[2]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[3]_i_30_n_5\,
      DI(2) => \derivative_reg[3]_i_30_n_6\,
      DI(1) => \derivative_reg[3]_i_30_n_7\,
      DI(0) => \derivative_reg[3]_i_35_n_4\,
      O(3) => \derivative_reg[2]_i_30_n_4\,
      O(2) => \derivative_reg[2]_i_30_n_5\,
      O(1) => \derivative_reg[2]_i_30_n_6\,
      O(0) => \derivative_reg[2]_i_30_n_7\,
      S(3) => \derivative[2]_i_36_n_0\,
      S(2) => \derivative[2]_i_37_n_0\,
      S(1) => \derivative[2]_i_38_n_0\,
      S(0) => \derivative[2]_i_39_n_0\
    );
\derivative_reg[2]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[2]_i_35_n_0\,
      CO(2) => \derivative_reg[2]_i_35_n_1\,
      CO(1) => \derivative_reg[2]_i_35_n_2\,
      CO(0) => \derivative_reg[2]_i_35_n_3\,
      CYINIT => \derivative_reg[3]_i_1_n_2\,
      DI(3) => \derivative_reg[3]_i_35_n_5\,
      DI(2) => \derivative_reg[3]_i_35_n_6\,
      DI(1) => derivative11_out(2),
      DI(0) => '0',
      O(3) => \derivative_reg[2]_i_35_n_4\,
      O(2) => \derivative_reg[2]_i_35_n_5\,
      O(1) => \derivative_reg[2]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[2]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[2]_i_40_n_0\,
      S(2) => \derivative[2]_i_41_n_0\,
      S(1) => \derivative[2]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[2]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[2]_i_10_n_0\,
      CO(3) => \derivative_reg[2]_i_5_n_0\,
      CO(2) => \derivative_reg[2]_i_5_n_1\,
      CO(1) => \derivative_reg[2]_i_5_n_2\,
      CO(0) => \derivative_reg[2]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[3]_i_5_n_5\,
      DI(2) => \derivative_reg[3]_i_5_n_6\,
      DI(1) => \derivative_reg[3]_i_5_n_7\,
      DI(0) => \derivative_reg[3]_i_10_n_4\,
      O(3) => \derivative_reg[2]_i_5_n_4\,
      O(2) => \derivative_reg[2]_i_5_n_5\,
      O(1) => \derivative_reg[2]_i_5_n_6\,
      O(0) => \derivative_reg[2]_i_5_n_7\,
      S(3) => \derivative[2]_i_11_n_0\,
      S(2) => \derivative[2]_i_12_n_0\,
      S(1) => \derivative[2]_i_13_n_0\,
      S(0) => \derivative[2]_i_14_n_0\
    );
\derivative_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[30]_i_1_n_2\,
      Q => derivative_out(30),
      R => '0'
    );
\derivative_reg[30]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[30]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[30]_i_1_n_2\,
      CO(0) => \derivative_reg[30]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[31]_i_1_n_3\,
      DI(0) => \derivative_reg[31]_i_2_n_5\,
      O(3 downto 1) => \NLW_derivative_reg[30]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[30]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[30]_i_3_n_0\,
      S(0) => \derivative[30]_i_4_n_0\
    );
\derivative_reg[30]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_15_n_0\,
      CO(3) => \derivative_reg[30]_i_10_n_0\,
      CO(2) => \derivative_reg[30]_i_10_n_1\,
      CO(1) => \derivative_reg[30]_i_10_n_2\,
      CO(0) => \derivative_reg[30]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[31]_i_12_n_6\,
      DI(2) => \derivative_reg[31]_i_12_n_7\,
      DI(1) => \derivative_reg[31]_i_21_n_4\,
      DI(0) => \derivative_reg[31]_i_21_n_5\,
      O(3) => \derivative_reg[30]_i_10_n_4\,
      O(2) => \derivative_reg[30]_i_10_n_5\,
      O(1) => \derivative_reg[30]_i_10_n_6\,
      O(0) => \derivative_reg[30]_i_10_n_7\,
      S(3) => \derivative[30]_i_16_n_0\,
      S(2) => \derivative[30]_i_17_n_0\,
      S(1) => \derivative[30]_i_18_n_0\,
      S(0) => \derivative[30]_i_19_n_0\
    );
\derivative_reg[30]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_20_n_0\,
      CO(3) => \derivative_reg[30]_i_15_n_0\,
      CO(2) => \derivative_reg[30]_i_15_n_1\,
      CO(1) => \derivative_reg[30]_i_15_n_2\,
      CO(0) => \derivative_reg[30]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[31]_i_21_n_6\,
      DI(2) => \derivative_reg[31]_i_21_n_7\,
      DI(1) => \derivative_reg[31]_i_30_n_4\,
      DI(0) => \derivative_reg[31]_i_30_n_5\,
      O(3) => \derivative_reg[30]_i_15_n_4\,
      O(2) => \derivative_reg[30]_i_15_n_5\,
      O(1) => \derivative_reg[30]_i_15_n_6\,
      O(0) => \derivative_reg[30]_i_15_n_7\,
      S(3) => \derivative[30]_i_21_n_0\,
      S(2) => \derivative[30]_i_22_n_0\,
      S(1) => \derivative[30]_i_23_n_0\,
      S(0) => \derivative[30]_i_24_n_0\
    );
\derivative_reg[30]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_5_n_0\,
      CO(3) => \derivative_reg[30]_i_2_n_0\,
      CO(2) => \derivative_reg[30]_i_2_n_1\,
      CO(1) => \derivative_reg[30]_i_2_n_2\,
      CO(0) => \derivative_reg[30]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[31]_i_2_n_6\,
      DI(2) => \derivative_reg[31]_i_2_n_7\,
      DI(1) => \derivative_reg[31]_i_3_n_4\,
      DI(0) => \derivative_reg[31]_i_3_n_5\,
      O(3) => \derivative_reg[30]_i_2_n_4\,
      O(2) => \derivative_reg[30]_i_2_n_5\,
      O(1) => \derivative_reg[30]_i_2_n_6\,
      O(0) => \derivative_reg[30]_i_2_n_7\,
      S(3) => \derivative[30]_i_6_n_0\,
      S(2) => \derivative[30]_i_7_n_0\,
      S(1) => \derivative[30]_i_8_n_0\,
      S(0) => \derivative[30]_i_9_n_0\
    );
\derivative_reg[30]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_25_n_0\,
      CO(3) => \derivative_reg[30]_i_20_n_0\,
      CO(2) => \derivative_reg[30]_i_20_n_1\,
      CO(1) => \derivative_reg[30]_i_20_n_2\,
      CO(0) => \derivative_reg[30]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[31]_i_30_n_6\,
      DI(2) => \derivative_reg[31]_i_30_n_7\,
      DI(1) => \derivative_reg[31]_i_39_n_4\,
      DI(0) => \derivative_reg[31]_i_39_n_5\,
      O(3) => \derivative_reg[30]_i_20_n_4\,
      O(2) => \derivative_reg[30]_i_20_n_5\,
      O(1) => \derivative_reg[30]_i_20_n_6\,
      O(0) => \derivative_reg[30]_i_20_n_7\,
      S(3) => \derivative[30]_i_26_n_0\,
      S(2) => \derivative[30]_i_27_n_0\,
      S(1) => \derivative[30]_i_28_n_0\,
      S(0) => \derivative[30]_i_29_n_0\
    );
\derivative_reg[30]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_30_n_0\,
      CO(3) => \derivative_reg[30]_i_25_n_0\,
      CO(2) => \derivative_reg[30]_i_25_n_1\,
      CO(1) => \derivative_reg[30]_i_25_n_2\,
      CO(0) => \derivative_reg[30]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[31]_i_39_n_6\,
      DI(2) => \derivative_reg[31]_i_39_n_7\,
      DI(1) => \derivative_reg[31]_i_48_n_4\,
      DI(0) => \derivative_reg[31]_i_48_n_5\,
      O(3) => \derivative_reg[30]_i_25_n_4\,
      O(2) => \derivative_reg[30]_i_25_n_5\,
      O(1) => \derivative_reg[30]_i_25_n_6\,
      O(0) => \derivative_reg[30]_i_25_n_7\,
      S(3) => \derivative[30]_i_31_n_0\,
      S(2) => \derivative[30]_i_32_n_0\,
      S(1) => \derivative[30]_i_33_n_0\,
      S(0) => \derivative[30]_i_34_n_0\
    );
\derivative_reg[30]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_35_n_0\,
      CO(3) => \derivative_reg[30]_i_30_n_0\,
      CO(2) => \derivative_reg[30]_i_30_n_1\,
      CO(1) => \derivative_reg[30]_i_30_n_2\,
      CO(0) => \derivative_reg[30]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[31]_i_48_n_6\,
      DI(2) => \derivative_reg[31]_i_48_n_7\,
      DI(1) => \derivative_reg[31]_i_57_n_4\,
      DI(0) => \derivative_reg[31]_i_57_n_5\,
      O(3) => \derivative_reg[30]_i_30_n_4\,
      O(2) => \derivative_reg[30]_i_30_n_5\,
      O(1) => \derivative_reg[30]_i_30_n_6\,
      O(0) => \derivative_reg[30]_i_30_n_7\,
      S(3) => \derivative[30]_i_36_n_0\,
      S(2) => \derivative[30]_i_37_n_0\,
      S(1) => \derivative[30]_i_38_n_0\,
      S(0) => \derivative[30]_i_39_n_0\
    );
\derivative_reg[30]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[30]_i_35_n_0\,
      CO(2) => \derivative_reg[30]_i_35_n_1\,
      CO(1) => \derivative_reg[30]_i_35_n_2\,
      CO(0) => \derivative_reg[30]_i_35_n_3\,
      CYINIT => \derivative_reg[31]_i_1_n_3\,
      DI(3) => \derivative_reg[31]_i_57_n_6\,
      DI(2) => \derivative_reg[31]_i_57_n_7\,
      DI(1) => derivative11_out(30),
      DI(0) => '0',
      O(3) => \derivative_reg[30]_i_35_n_4\,
      O(2) => \derivative_reg[30]_i_35_n_5\,
      O(1) => \derivative_reg[30]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[30]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[30]_i_40_n_0\,
      S(2) => \derivative[30]_i_41_n_0\,
      S(1) => \derivative[30]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[30]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[30]_i_10_n_0\,
      CO(3) => \derivative_reg[30]_i_5_n_0\,
      CO(2) => \derivative_reg[30]_i_5_n_1\,
      CO(1) => \derivative_reg[30]_i_5_n_2\,
      CO(0) => \derivative_reg[30]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[31]_i_3_n_6\,
      DI(2) => \derivative_reg[31]_i_3_n_7\,
      DI(1) => \derivative_reg[31]_i_12_n_4\,
      DI(0) => \derivative_reg[31]_i_12_n_5\,
      O(3) => \derivative_reg[30]_i_5_n_4\,
      O(2) => \derivative_reg[30]_i_5_n_5\,
      O(1) => \derivative_reg[30]_i_5_n_6\,
      O(0) => \derivative_reg[30]_i_5_n_7\,
      S(3) => \derivative[30]_i_11_n_0\,
      S(2) => \derivative[30]_i_12_n_0\,
      S(1) => \derivative[30]_i_13_n_0\,
      S(0) => \derivative[30]_i_14_n_0\
    );
\derivative_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[31]_i_1_n_3\,
      Q => derivative_out(31),
      R => '0'
    );
\derivative_reg[31]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_2_n_0\,
      CO(3 downto 1) => \NLW_derivative_reg[31]_i_1_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \derivative_reg[31]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_derivative_reg[31]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\derivative_reg[31]_i_12\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_21_n_0\,
      CO(3) => \derivative_reg[31]_i_12_n_0\,
      CO(2) => \derivative_reg[31]_i_12_n_1\,
      CO(1) => \derivative_reg[31]_i_12_n_2\,
      CO(0) => \derivative_reg[31]_i_12_n_3\,
      CYINIT => '0',
      DI(3) => \derivative[31]_i_22_n_0\,
      DI(2) => \derivative[31]_i_23_n_0\,
      DI(1) => \derivative[31]_i_24_n_0\,
      DI(0) => \derivative[31]_i_25_n_0\,
      O(3) => \derivative_reg[31]_i_12_n_4\,
      O(2) => \derivative_reg[31]_i_12_n_5\,
      O(1) => \derivative_reg[31]_i_12_n_6\,
      O(0) => \derivative_reg[31]_i_12_n_7\,
      S(3) => \derivative[31]_i_26_n_0\,
      S(2) => \derivative[31]_i_27_n_0\,
      S(1) => \derivative[31]_i_28_n_0\,
      S(0) => \derivative[31]_i_29_n_0\
    );
\derivative_reg[31]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_3_n_0\,
      CO(3) => \derivative_reg[31]_i_2_n_0\,
      CO(2) => \derivative_reg[31]_i_2_n_1\,
      CO(1) => \derivative_reg[31]_i_2_n_2\,
      CO(0) => \derivative_reg[31]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative[31]_i_4_n_0\,
      DI(2) => \derivative[31]_i_5_n_0\,
      DI(1) => \derivative[31]_i_6_n_0\,
      DI(0) => \derivative[31]_i_7_n_0\,
      O(3) => \derivative_reg[31]_i_2_n_4\,
      O(2) => \derivative_reg[31]_i_2_n_5\,
      O(1) => \derivative_reg[31]_i_2_n_6\,
      O(0) => \derivative_reg[31]_i_2_n_7\,
      S(3) => \derivative[31]_i_8_n_0\,
      S(2) => \derivative[31]_i_9_n_0\,
      S(1) => \derivative[31]_i_10_n_0\,
      S(0) => \derivative[31]_i_11_n_0\
    );
\derivative_reg[31]_i_21\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_30_n_0\,
      CO(3) => \derivative_reg[31]_i_21_n_0\,
      CO(2) => \derivative_reg[31]_i_21_n_1\,
      CO(1) => \derivative_reg[31]_i_21_n_2\,
      CO(0) => \derivative_reg[31]_i_21_n_3\,
      CYINIT => '0',
      DI(3) => \derivative[31]_i_31_n_0\,
      DI(2) => \derivative[31]_i_32_n_0\,
      DI(1) => \derivative[31]_i_33_n_0\,
      DI(0) => \derivative[31]_i_34_n_0\,
      O(3) => \derivative_reg[31]_i_21_n_4\,
      O(2) => \derivative_reg[31]_i_21_n_5\,
      O(1) => \derivative_reg[31]_i_21_n_6\,
      O(0) => \derivative_reg[31]_i_21_n_7\,
      S(3) => \derivative[31]_i_35_n_0\,
      S(2) => \derivative[31]_i_36_n_0\,
      S(1) => \derivative[31]_i_37_n_0\,
      S(0) => \derivative[31]_i_38_n_0\
    );
\derivative_reg[31]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_12_n_0\,
      CO(3) => \derivative_reg[31]_i_3_n_0\,
      CO(2) => \derivative_reg[31]_i_3_n_1\,
      CO(1) => \derivative_reg[31]_i_3_n_2\,
      CO(0) => \derivative_reg[31]_i_3_n_3\,
      CYINIT => '0',
      DI(3) => \derivative[31]_i_13_n_0\,
      DI(2) => \derivative[31]_i_14_n_0\,
      DI(1) => \derivative[31]_i_15_n_0\,
      DI(0) => \derivative[31]_i_16_n_0\,
      O(3) => \derivative_reg[31]_i_3_n_4\,
      O(2) => \derivative_reg[31]_i_3_n_5\,
      O(1) => \derivative_reg[31]_i_3_n_6\,
      O(0) => \derivative_reg[31]_i_3_n_7\,
      S(3) => \derivative[31]_i_17_n_0\,
      S(2) => \derivative[31]_i_18_n_0\,
      S(1) => \derivative[31]_i_19_n_0\,
      S(0) => \derivative[31]_i_20_n_0\
    );
\derivative_reg[31]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_39_n_0\,
      CO(3) => \derivative_reg[31]_i_30_n_0\,
      CO(2) => \derivative_reg[31]_i_30_n_1\,
      CO(1) => \derivative_reg[31]_i_30_n_2\,
      CO(0) => \derivative_reg[31]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative[31]_i_40_n_0\,
      DI(2) => \derivative[31]_i_41_n_0\,
      DI(1) => \derivative[31]_i_42_n_0\,
      DI(0) => \derivative[31]_i_43_n_0\,
      O(3) => \derivative_reg[31]_i_30_n_4\,
      O(2) => \derivative_reg[31]_i_30_n_5\,
      O(1) => \derivative_reg[31]_i_30_n_6\,
      O(0) => \derivative_reg[31]_i_30_n_7\,
      S(3) => \derivative[31]_i_44_n_0\,
      S(2) => \derivative[31]_i_45_n_0\,
      S(1) => \derivative[31]_i_46_n_0\,
      S(0) => \derivative[31]_i_47_n_0\
    );
\derivative_reg[31]_i_39\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_48_n_0\,
      CO(3) => \derivative_reg[31]_i_39_n_0\,
      CO(2) => \derivative_reg[31]_i_39_n_1\,
      CO(1) => \derivative_reg[31]_i_39_n_2\,
      CO(0) => \derivative_reg[31]_i_39_n_3\,
      CYINIT => '0',
      DI(3) => \derivative[31]_i_49_n_0\,
      DI(2) => \derivative[31]_i_50_n_0\,
      DI(1) => \derivative[31]_i_51_n_0\,
      DI(0) => \derivative[31]_i_52_n_0\,
      O(3) => \derivative_reg[31]_i_39_n_4\,
      O(2) => \derivative_reg[31]_i_39_n_5\,
      O(1) => \derivative_reg[31]_i_39_n_6\,
      O(0) => \derivative_reg[31]_i_39_n_7\,
      S(3) => \derivative[31]_i_53_n_0\,
      S(2) => \derivative[31]_i_54_n_0\,
      S(1) => \derivative[31]_i_55_n_0\,
      S(0) => \derivative[31]_i_56_n_0\
    );
\derivative_reg[31]_i_48\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[31]_i_57_n_0\,
      CO(3) => \derivative_reg[31]_i_48_n_0\,
      CO(2) => \derivative_reg[31]_i_48_n_1\,
      CO(1) => \derivative_reg[31]_i_48_n_2\,
      CO(0) => \derivative_reg[31]_i_48_n_3\,
      CYINIT => '0',
      DI(3) => \derivative[31]_i_58_n_0\,
      DI(2) => \derivative[31]_i_59_n_0\,
      DI(1) => \derivative[31]_i_60_n_0\,
      DI(0) => \derivative[31]_i_61_n_0\,
      O(3) => \derivative_reg[31]_i_48_n_4\,
      O(2) => \derivative_reg[31]_i_48_n_5\,
      O(1) => \derivative_reg[31]_i_48_n_6\,
      O(0) => \derivative_reg[31]_i_48_n_7\,
      S(3) => \derivative[31]_i_62_n_0\,
      S(2) => \derivative[31]_i_63_n_0\,
      S(1) => \derivative[31]_i_64_n_0\,
      S(0) => \derivative[31]_i_65_n_0\
    );
\derivative_reg[31]_i_57\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[31]_i_57_n_0\,
      CO(2) => \derivative_reg[31]_i_57_n_1\,
      CO(1) => \derivative_reg[31]_i_57_n_2\,
      CO(0) => \derivative_reg[31]_i_57_n_3\,
      CYINIT => '1',
      DI(3) => \derivative[31]_i_66_n_0\,
      DI(2) => \derivative[31]_i_67_n_0\,
      DI(1) => \derivative[31]_i_68_n_0\,
      DI(0) => derivative11_out(31),
      O(3) => \derivative_reg[31]_i_57_n_4\,
      O(2) => \derivative_reg[31]_i_57_n_5\,
      O(1) => \derivative_reg[31]_i_57_n_6\,
      O(0) => \derivative_reg[31]_i_57_n_7\,
      S(3) => \derivative[31]_i_69_n_0\,
      S(2) => \derivative[31]_i_70_n_0\,
      S(1) => \derivative[31]_i_71_n_0\,
      S(0) => \derivative[31]_i_72_n_0\
    );
\derivative_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[3]_i_1_n_2\,
      Q => derivative_out(3),
      R => '0'
    );
\derivative_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[3]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[3]_i_1_n_2\,
      CO(0) => \derivative_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[4]_i_1_n_2\,
      DI(0) => \derivative_reg[4]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[3]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[3]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[3]_i_3_n_0\,
      S(0) => \derivative[3]_i_4_n_0\
    );
\derivative_reg[3]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_15_n_0\,
      CO(3) => \derivative_reg[3]_i_10_n_0\,
      CO(2) => \derivative_reg[3]_i_10_n_1\,
      CO(1) => \derivative_reg[3]_i_10_n_2\,
      CO(0) => \derivative_reg[3]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[4]_i_10_n_5\,
      DI(2) => \derivative_reg[4]_i_10_n_6\,
      DI(1) => \derivative_reg[4]_i_10_n_7\,
      DI(0) => \derivative_reg[4]_i_15_n_4\,
      O(3) => \derivative_reg[3]_i_10_n_4\,
      O(2) => \derivative_reg[3]_i_10_n_5\,
      O(1) => \derivative_reg[3]_i_10_n_6\,
      O(0) => \derivative_reg[3]_i_10_n_7\,
      S(3) => \derivative[3]_i_16_n_0\,
      S(2) => \derivative[3]_i_17_n_0\,
      S(1) => \derivative[3]_i_18_n_0\,
      S(0) => \derivative[3]_i_19_n_0\
    );
\derivative_reg[3]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_20_n_0\,
      CO(3) => \derivative_reg[3]_i_15_n_0\,
      CO(2) => \derivative_reg[3]_i_15_n_1\,
      CO(1) => \derivative_reg[3]_i_15_n_2\,
      CO(0) => \derivative_reg[3]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[4]_i_15_n_5\,
      DI(2) => \derivative_reg[4]_i_15_n_6\,
      DI(1) => \derivative_reg[4]_i_15_n_7\,
      DI(0) => \derivative_reg[4]_i_20_n_4\,
      O(3) => \derivative_reg[3]_i_15_n_4\,
      O(2) => \derivative_reg[3]_i_15_n_5\,
      O(1) => \derivative_reg[3]_i_15_n_6\,
      O(0) => \derivative_reg[3]_i_15_n_7\,
      S(3) => \derivative[3]_i_21_n_0\,
      S(2) => \derivative[3]_i_22_n_0\,
      S(1) => \derivative[3]_i_23_n_0\,
      S(0) => \derivative[3]_i_24_n_0\
    );
\derivative_reg[3]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_5_n_0\,
      CO(3) => \derivative_reg[3]_i_2_n_0\,
      CO(2) => \derivative_reg[3]_i_2_n_1\,
      CO(1) => \derivative_reg[3]_i_2_n_2\,
      CO(0) => \derivative_reg[3]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[4]_i_2_n_5\,
      DI(2) => \derivative_reg[4]_i_2_n_6\,
      DI(1) => \derivative_reg[4]_i_2_n_7\,
      DI(0) => \derivative_reg[4]_i_5_n_4\,
      O(3) => \derivative_reg[3]_i_2_n_4\,
      O(2) => \derivative_reg[3]_i_2_n_5\,
      O(1) => \derivative_reg[3]_i_2_n_6\,
      O(0) => \derivative_reg[3]_i_2_n_7\,
      S(3) => \derivative[3]_i_6_n_0\,
      S(2) => \derivative[3]_i_7_n_0\,
      S(1) => \derivative[3]_i_8_n_0\,
      S(0) => \derivative[3]_i_9_n_0\
    );
\derivative_reg[3]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_25_n_0\,
      CO(3) => \derivative_reg[3]_i_20_n_0\,
      CO(2) => \derivative_reg[3]_i_20_n_1\,
      CO(1) => \derivative_reg[3]_i_20_n_2\,
      CO(0) => \derivative_reg[3]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[4]_i_20_n_5\,
      DI(2) => \derivative_reg[4]_i_20_n_6\,
      DI(1) => \derivative_reg[4]_i_20_n_7\,
      DI(0) => \derivative_reg[4]_i_25_n_4\,
      O(3) => \derivative_reg[3]_i_20_n_4\,
      O(2) => \derivative_reg[3]_i_20_n_5\,
      O(1) => \derivative_reg[3]_i_20_n_6\,
      O(0) => \derivative_reg[3]_i_20_n_7\,
      S(3) => \derivative[3]_i_26_n_0\,
      S(2) => \derivative[3]_i_27_n_0\,
      S(1) => \derivative[3]_i_28_n_0\,
      S(0) => \derivative[3]_i_29_n_0\
    );
\derivative_reg[3]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_30_n_0\,
      CO(3) => \derivative_reg[3]_i_25_n_0\,
      CO(2) => \derivative_reg[3]_i_25_n_1\,
      CO(1) => \derivative_reg[3]_i_25_n_2\,
      CO(0) => \derivative_reg[3]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[4]_i_25_n_5\,
      DI(2) => \derivative_reg[4]_i_25_n_6\,
      DI(1) => \derivative_reg[4]_i_25_n_7\,
      DI(0) => \derivative_reg[4]_i_30_n_4\,
      O(3) => \derivative_reg[3]_i_25_n_4\,
      O(2) => \derivative_reg[3]_i_25_n_5\,
      O(1) => \derivative_reg[3]_i_25_n_6\,
      O(0) => \derivative_reg[3]_i_25_n_7\,
      S(3) => \derivative[3]_i_31_n_0\,
      S(2) => \derivative[3]_i_32_n_0\,
      S(1) => \derivative[3]_i_33_n_0\,
      S(0) => \derivative[3]_i_34_n_0\
    );
\derivative_reg[3]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_35_n_0\,
      CO(3) => \derivative_reg[3]_i_30_n_0\,
      CO(2) => \derivative_reg[3]_i_30_n_1\,
      CO(1) => \derivative_reg[3]_i_30_n_2\,
      CO(0) => \derivative_reg[3]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[4]_i_30_n_5\,
      DI(2) => \derivative_reg[4]_i_30_n_6\,
      DI(1) => \derivative_reg[4]_i_30_n_7\,
      DI(0) => \derivative_reg[4]_i_35_n_4\,
      O(3) => \derivative_reg[3]_i_30_n_4\,
      O(2) => \derivative_reg[3]_i_30_n_5\,
      O(1) => \derivative_reg[3]_i_30_n_6\,
      O(0) => \derivative_reg[3]_i_30_n_7\,
      S(3) => \derivative[3]_i_36_n_0\,
      S(2) => \derivative[3]_i_37_n_0\,
      S(1) => \derivative[3]_i_38_n_0\,
      S(0) => \derivative[3]_i_39_n_0\
    );
\derivative_reg[3]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[3]_i_35_n_0\,
      CO(2) => \derivative_reg[3]_i_35_n_1\,
      CO(1) => \derivative_reg[3]_i_35_n_2\,
      CO(0) => \derivative_reg[3]_i_35_n_3\,
      CYINIT => \derivative_reg[4]_i_1_n_2\,
      DI(3) => \derivative_reg[4]_i_35_n_5\,
      DI(2) => \derivative_reg[4]_i_35_n_6\,
      DI(1) => derivative11_out(3),
      DI(0) => '0',
      O(3) => \derivative_reg[3]_i_35_n_4\,
      O(2) => \derivative_reg[3]_i_35_n_5\,
      O(1) => \derivative_reg[3]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[3]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[3]_i_40_n_0\,
      S(2) => \derivative[3]_i_41_n_0\,
      S(1) => \derivative[3]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[3]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[3]_i_10_n_0\,
      CO(3) => \derivative_reg[3]_i_5_n_0\,
      CO(2) => \derivative_reg[3]_i_5_n_1\,
      CO(1) => \derivative_reg[3]_i_5_n_2\,
      CO(0) => \derivative_reg[3]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[4]_i_5_n_5\,
      DI(2) => \derivative_reg[4]_i_5_n_6\,
      DI(1) => \derivative_reg[4]_i_5_n_7\,
      DI(0) => \derivative_reg[4]_i_10_n_4\,
      O(3) => \derivative_reg[3]_i_5_n_4\,
      O(2) => \derivative_reg[3]_i_5_n_5\,
      O(1) => \derivative_reg[3]_i_5_n_6\,
      O(0) => \derivative_reg[3]_i_5_n_7\,
      S(3) => \derivative[3]_i_11_n_0\,
      S(2) => \derivative[3]_i_12_n_0\,
      S(1) => \derivative[3]_i_13_n_0\,
      S(0) => \derivative[3]_i_14_n_0\
    );
\derivative_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[4]_i_1_n_2\,
      Q => derivative_out(4),
      R => '0'
    );
\derivative_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[4]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[4]_i_1_n_2\,
      CO(0) => \derivative_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[5]_i_1_n_2\,
      DI(0) => \derivative_reg[5]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[4]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[4]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[4]_i_3_n_0\,
      S(0) => \derivative[4]_i_4_n_0\
    );
\derivative_reg[4]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_15_n_0\,
      CO(3) => \derivative_reg[4]_i_10_n_0\,
      CO(2) => \derivative_reg[4]_i_10_n_1\,
      CO(1) => \derivative_reg[4]_i_10_n_2\,
      CO(0) => \derivative_reg[4]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[5]_i_10_n_5\,
      DI(2) => \derivative_reg[5]_i_10_n_6\,
      DI(1) => \derivative_reg[5]_i_10_n_7\,
      DI(0) => \derivative_reg[5]_i_15_n_4\,
      O(3) => \derivative_reg[4]_i_10_n_4\,
      O(2) => \derivative_reg[4]_i_10_n_5\,
      O(1) => \derivative_reg[4]_i_10_n_6\,
      O(0) => \derivative_reg[4]_i_10_n_7\,
      S(3) => \derivative[4]_i_16_n_0\,
      S(2) => \derivative[4]_i_17_n_0\,
      S(1) => \derivative[4]_i_18_n_0\,
      S(0) => \derivative[4]_i_19_n_0\
    );
\derivative_reg[4]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_20_n_0\,
      CO(3) => \derivative_reg[4]_i_15_n_0\,
      CO(2) => \derivative_reg[4]_i_15_n_1\,
      CO(1) => \derivative_reg[4]_i_15_n_2\,
      CO(0) => \derivative_reg[4]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[5]_i_15_n_5\,
      DI(2) => \derivative_reg[5]_i_15_n_6\,
      DI(1) => \derivative_reg[5]_i_15_n_7\,
      DI(0) => \derivative_reg[5]_i_20_n_4\,
      O(3) => \derivative_reg[4]_i_15_n_4\,
      O(2) => \derivative_reg[4]_i_15_n_5\,
      O(1) => \derivative_reg[4]_i_15_n_6\,
      O(0) => \derivative_reg[4]_i_15_n_7\,
      S(3) => \derivative[4]_i_21_n_0\,
      S(2) => \derivative[4]_i_22_n_0\,
      S(1) => \derivative[4]_i_23_n_0\,
      S(0) => \derivative[4]_i_24_n_0\
    );
\derivative_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_5_n_0\,
      CO(3) => \derivative_reg[4]_i_2_n_0\,
      CO(2) => \derivative_reg[4]_i_2_n_1\,
      CO(1) => \derivative_reg[4]_i_2_n_2\,
      CO(0) => \derivative_reg[4]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[5]_i_2_n_5\,
      DI(2) => \derivative_reg[5]_i_2_n_6\,
      DI(1) => \derivative_reg[5]_i_2_n_7\,
      DI(0) => \derivative_reg[5]_i_5_n_4\,
      O(3) => \derivative_reg[4]_i_2_n_4\,
      O(2) => \derivative_reg[4]_i_2_n_5\,
      O(1) => \derivative_reg[4]_i_2_n_6\,
      O(0) => \derivative_reg[4]_i_2_n_7\,
      S(3) => \derivative[4]_i_6_n_0\,
      S(2) => \derivative[4]_i_7_n_0\,
      S(1) => \derivative[4]_i_8_n_0\,
      S(0) => \derivative[4]_i_9_n_0\
    );
\derivative_reg[4]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_25_n_0\,
      CO(3) => \derivative_reg[4]_i_20_n_0\,
      CO(2) => \derivative_reg[4]_i_20_n_1\,
      CO(1) => \derivative_reg[4]_i_20_n_2\,
      CO(0) => \derivative_reg[4]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[5]_i_20_n_5\,
      DI(2) => \derivative_reg[5]_i_20_n_6\,
      DI(1) => \derivative_reg[5]_i_20_n_7\,
      DI(0) => \derivative_reg[5]_i_25_n_4\,
      O(3) => \derivative_reg[4]_i_20_n_4\,
      O(2) => \derivative_reg[4]_i_20_n_5\,
      O(1) => \derivative_reg[4]_i_20_n_6\,
      O(0) => \derivative_reg[4]_i_20_n_7\,
      S(3) => \derivative[4]_i_26_n_0\,
      S(2) => \derivative[4]_i_27_n_0\,
      S(1) => \derivative[4]_i_28_n_0\,
      S(0) => \derivative[4]_i_29_n_0\
    );
\derivative_reg[4]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_30_n_0\,
      CO(3) => \derivative_reg[4]_i_25_n_0\,
      CO(2) => \derivative_reg[4]_i_25_n_1\,
      CO(1) => \derivative_reg[4]_i_25_n_2\,
      CO(0) => \derivative_reg[4]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[5]_i_25_n_5\,
      DI(2) => \derivative_reg[5]_i_25_n_6\,
      DI(1) => \derivative_reg[5]_i_25_n_7\,
      DI(0) => \derivative_reg[5]_i_30_n_4\,
      O(3) => \derivative_reg[4]_i_25_n_4\,
      O(2) => \derivative_reg[4]_i_25_n_5\,
      O(1) => \derivative_reg[4]_i_25_n_6\,
      O(0) => \derivative_reg[4]_i_25_n_7\,
      S(3) => \derivative[4]_i_31_n_0\,
      S(2) => \derivative[4]_i_32_n_0\,
      S(1) => \derivative[4]_i_33_n_0\,
      S(0) => \derivative[4]_i_34_n_0\
    );
\derivative_reg[4]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_35_n_0\,
      CO(3) => \derivative_reg[4]_i_30_n_0\,
      CO(2) => \derivative_reg[4]_i_30_n_1\,
      CO(1) => \derivative_reg[4]_i_30_n_2\,
      CO(0) => \derivative_reg[4]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[5]_i_30_n_5\,
      DI(2) => \derivative_reg[5]_i_30_n_6\,
      DI(1) => \derivative_reg[5]_i_30_n_7\,
      DI(0) => \derivative_reg[5]_i_35_n_4\,
      O(3) => \derivative_reg[4]_i_30_n_4\,
      O(2) => \derivative_reg[4]_i_30_n_5\,
      O(1) => \derivative_reg[4]_i_30_n_6\,
      O(0) => \derivative_reg[4]_i_30_n_7\,
      S(3) => \derivative[4]_i_36_n_0\,
      S(2) => \derivative[4]_i_37_n_0\,
      S(1) => \derivative[4]_i_38_n_0\,
      S(0) => \derivative[4]_i_39_n_0\
    );
\derivative_reg[4]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[4]_i_35_n_0\,
      CO(2) => \derivative_reg[4]_i_35_n_1\,
      CO(1) => \derivative_reg[4]_i_35_n_2\,
      CO(0) => \derivative_reg[4]_i_35_n_3\,
      CYINIT => \derivative_reg[5]_i_1_n_2\,
      DI(3) => \derivative_reg[5]_i_35_n_5\,
      DI(2) => \derivative_reg[5]_i_35_n_6\,
      DI(1) => derivative11_out(4),
      DI(0) => '0',
      O(3) => \derivative_reg[4]_i_35_n_4\,
      O(2) => \derivative_reg[4]_i_35_n_5\,
      O(1) => \derivative_reg[4]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[4]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[4]_i_40_n_0\,
      S(2) => \derivative[4]_i_41_n_0\,
      S(1) => \derivative[4]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[4]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[4]_i_10_n_0\,
      CO(3) => \derivative_reg[4]_i_5_n_0\,
      CO(2) => \derivative_reg[4]_i_5_n_1\,
      CO(1) => \derivative_reg[4]_i_5_n_2\,
      CO(0) => \derivative_reg[4]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[5]_i_5_n_5\,
      DI(2) => \derivative_reg[5]_i_5_n_6\,
      DI(1) => \derivative_reg[5]_i_5_n_7\,
      DI(0) => \derivative_reg[5]_i_10_n_4\,
      O(3) => \derivative_reg[4]_i_5_n_4\,
      O(2) => \derivative_reg[4]_i_5_n_5\,
      O(1) => \derivative_reg[4]_i_5_n_6\,
      O(0) => \derivative_reg[4]_i_5_n_7\,
      S(3) => \derivative[4]_i_11_n_0\,
      S(2) => \derivative[4]_i_12_n_0\,
      S(1) => \derivative[4]_i_13_n_0\,
      S(0) => \derivative[4]_i_14_n_0\
    );
\derivative_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[5]_i_1_n_2\,
      Q => derivative_out(5),
      R => '0'
    );
\derivative_reg[5]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[5]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[5]_i_1_n_2\,
      CO(0) => \derivative_reg[5]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[6]_i_1_n_2\,
      DI(0) => \derivative_reg[6]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[5]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[5]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[5]_i_3_n_0\,
      S(0) => \derivative[5]_i_4_n_0\
    );
\derivative_reg[5]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_15_n_0\,
      CO(3) => \derivative_reg[5]_i_10_n_0\,
      CO(2) => \derivative_reg[5]_i_10_n_1\,
      CO(1) => \derivative_reg[5]_i_10_n_2\,
      CO(0) => \derivative_reg[5]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[6]_i_10_n_5\,
      DI(2) => \derivative_reg[6]_i_10_n_6\,
      DI(1) => \derivative_reg[6]_i_10_n_7\,
      DI(0) => \derivative_reg[6]_i_15_n_4\,
      O(3) => \derivative_reg[5]_i_10_n_4\,
      O(2) => \derivative_reg[5]_i_10_n_5\,
      O(1) => \derivative_reg[5]_i_10_n_6\,
      O(0) => \derivative_reg[5]_i_10_n_7\,
      S(3) => \derivative[5]_i_16_n_0\,
      S(2) => \derivative[5]_i_17_n_0\,
      S(1) => \derivative[5]_i_18_n_0\,
      S(0) => \derivative[5]_i_19_n_0\
    );
\derivative_reg[5]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_20_n_0\,
      CO(3) => \derivative_reg[5]_i_15_n_0\,
      CO(2) => \derivative_reg[5]_i_15_n_1\,
      CO(1) => \derivative_reg[5]_i_15_n_2\,
      CO(0) => \derivative_reg[5]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[6]_i_15_n_5\,
      DI(2) => \derivative_reg[6]_i_15_n_6\,
      DI(1) => \derivative_reg[6]_i_15_n_7\,
      DI(0) => \derivative_reg[6]_i_20_n_4\,
      O(3) => \derivative_reg[5]_i_15_n_4\,
      O(2) => \derivative_reg[5]_i_15_n_5\,
      O(1) => \derivative_reg[5]_i_15_n_6\,
      O(0) => \derivative_reg[5]_i_15_n_7\,
      S(3) => \derivative[5]_i_21_n_0\,
      S(2) => \derivative[5]_i_22_n_0\,
      S(1) => \derivative[5]_i_23_n_0\,
      S(0) => \derivative[5]_i_24_n_0\
    );
\derivative_reg[5]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_5_n_0\,
      CO(3) => \derivative_reg[5]_i_2_n_0\,
      CO(2) => \derivative_reg[5]_i_2_n_1\,
      CO(1) => \derivative_reg[5]_i_2_n_2\,
      CO(0) => \derivative_reg[5]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[6]_i_2_n_5\,
      DI(2) => \derivative_reg[6]_i_2_n_6\,
      DI(1) => \derivative_reg[6]_i_2_n_7\,
      DI(0) => \derivative_reg[6]_i_5_n_4\,
      O(3) => \derivative_reg[5]_i_2_n_4\,
      O(2) => \derivative_reg[5]_i_2_n_5\,
      O(1) => \derivative_reg[5]_i_2_n_6\,
      O(0) => \derivative_reg[5]_i_2_n_7\,
      S(3) => \derivative[5]_i_6_n_0\,
      S(2) => \derivative[5]_i_7_n_0\,
      S(1) => \derivative[5]_i_8_n_0\,
      S(0) => \derivative[5]_i_9_n_0\
    );
\derivative_reg[5]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_25_n_0\,
      CO(3) => \derivative_reg[5]_i_20_n_0\,
      CO(2) => \derivative_reg[5]_i_20_n_1\,
      CO(1) => \derivative_reg[5]_i_20_n_2\,
      CO(0) => \derivative_reg[5]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[6]_i_20_n_5\,
      DI(2) => \derivative_reg[6]_i_20_n_6\,
      DI(1) => \derivative_reg[6]_i_20_n_7\,
      DI(0) => \derivative_reg[6]_i_25_n_4\,
      O(3) => \derivative_reg[5]_i_20_n_4\,
      O(2) => \derivative_reg[5]_i_20_n_5\,
      O(1) => \derivative_reg[5]_i_20_n_6\,
      O(0) => \derivative_reg[5]_i_20_n_7\,
      S(3) => \derivative[5]_i_26_n_0\,
      S(2) => \derivative[5]_i_27_n_0\,
      S(1) => \derivative[5]_i_28_n_0\,
      S(0) => \derivative[5]_i_29_n_0\
    );
\derivative_reg[5]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_30_n_0\,
      CO(3) => \derivative_reg[5]_i_25_n_0\,
      CO(2) => \derivative_reg[5]_i_25_n_1\,
      CO(1) => \derivative_reg[5]_i_25_n_2\,
      CO(0) => \derivative_reg[5]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[6]_i_25_n_5\,
      DI(2) => \derivative_reg[6]_i_25_n_6\,
      DI(1) => \derivative_reg[6]_i_25_n_7\,
      DI(0) => \derivative_reg[6]_i_30_n_4\,
      O(3) => \derivative_reg[5]_i_25_n_4\,
      O(2) => \derivative_reg[5]_i_25_n_5\,
      O(1) => \derivative_reg[5]_i_25_n_6\,
      O(0) => \derivative_reg[5]_i_25_n_7\,
      S(3) => \derivative[5]_i_31_n_0\,
      S(2) => \derivative[5]_i_32_n_0\,
      S(1) => \derivative[5]_i_33_n_0\,
      S(0) => \derivative[5]_i_34_n_0\
    );
\derivative_reg[5]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_35_n_0\,
      CO(3) => \derivative_reg[5]_i_30_n_0\,
      CO(2) => \derivative_reg[5]_i_30_n_1\,
      CO(1) => \derivative_reg[5]_i_30_n_2\,
      CO(0) => \derivative_reg[5]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[6]_i_30_n_5\,
      DI(2) => \derivative_reg[6]_i_30_n_6\,
      DI(1) => \derivative_reg[6]_i_30_n_7\,
      DI(0) => \derivative_reg[6]_i_35_n_4\,
      O(3) => \derivative_reg[5]_i_30_n_4\,
      O(2) => \derivative_reg[5]_i_30_n_5\,
      O(1) => \derivative_reg[5]_i_30_n_6\,
      O(0) => \derivative_reg[5]_i_30_n_7\,
      S(3) => \derivative[5]_i_36_n_0\,
      S(2) => \derivative[5]_i_37_n_0\,
      S(1) => \derivative[5]_i_38_n_0\,
      S(0) => \derivative[5]_i_39_n_0\
    );
\derivative_reg[5]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[5]_i_35_n_0\,
      CO(2) => \derivative_reg[5]_i_35_n_1\,
      CO(1) => \derivative_reg[5]_i_35_n_2\,
      CO(0) => \derivative_reg[5]_i_35_n_3\,
      CYINIT => \derivative_reg[6]_i_1_n_2\,
      DI(3) => \derivative_reg[6]_i_35_n_5\,
      DI(2) => \derivative_reg[6]_i_35_n_6\,
      DI(1) => derivative11_out(5),
      DI(0) => '0',
      O(3) => \derivative_reg[5]_i_35_n_4\,
      O(2) => \derivative_reg[5]_i_35_n_5\,
      O(1) => \derivative_reg[5]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[5]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[5]_i_40_n_0\,
      S(2) => \derivative[5]_i_41_n_0\,
      S(1) => \derivative[5]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[5]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[5]_i_10_n_0\,
      CO(3) => \derivative_reg[5]_i_5_n_0\,
      CO(2) => \derivative_reg[5]_i_5_n_1\,
      CO(1) => \derivative_reg[5]_i_5_n_2\,
      CO(0) => \derivative_reg[5]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[6]_i_5_n_5\,
      DI(2) => \derivative_reg[6]_i_5_n_6\,
      DI(1) => \derivative_reg[6]_i_5_n_7\,
      DI(0) => \derivative_reg[6]_i_10_n_4\,
      O(3) => \derivative_reg[5]_i_5_n_4\,
      O(2) => \derivative_reg[5]_i_5_n_5\,
      O(1) => \derivative_reg[5]_i_5_n_6\,
      O(0) => \derivative_reg[5]_i_5_n_7\,
      S(3) => \derivative[5]_i_11_n_0\,
      S(2) => \derivative[5]_i_12_n_0\,
      S(1) => \derivative[5]_i_13_n_0\,
      S(0) => \derivative[5]_i_14_n_0\
    );
\derivative_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[6]_i_1_n_2\,
      Q => derivative_out(6),
      R => '0'
    );
\derivative_reg[6]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[6]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[6]_i_1_n_2\,
      CO(0) => \derivative_reg[6]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[7]_i_1_n_2\,
      DI(0) => \derivative_reg[7]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[6]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[6]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[6]_i_3_n_0\,
      S(0) => \derivative[6]_i_4_n_0\
    );
\derivative_reg[6]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_15_n_0\,
      CO(3) => \derivative_reg[6]_i_10_n_0\,
      CO(2) => \derivative_reg[6]_i_10_n_1\,
      CO(1) => \derivative_reg[6]_i_10_n_2\,
      CO(0) => \derivative_reg[6]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[7]_i_10_n_5\,
      DI(2) => \derivative_reg[7]_i_10_n_6\,
      DI(1) => \derivative_reg[7]_i_10_n_7\,
      DI(0) => \derivative_reg[7]_i_15_n_4\,
      O(3) => \derivative_reg[6]_i_10_n_4\,
      O(2) => \derivative_reg[6]_i_10_n_5\,
      O(1) => \derivative_reg[6]_i_10_n_6\,
      O(0) => \derivative_reg[6]_i_10_n_7\,
      S(3) => \derivative[6]_i_16_n_0\,
      S(2) => \derivative[6]_i_17_n_0\,
      S(1) => \derivative[6]_i_18_n_0\,
      S(0) => \derivative[6]_i_19_n_0\
    );
\derivative_reg[6]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_20_n_0\,
      CO(3) => \derivative_reg[6]_i_15_n_0\,
      CO(2) => \derivative_reg[6]_i_15_n_1\,
      CO(1) => \derivative_reg[6]_i_15_n_2\,
      CO(0) => \derivative_reg[6]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[7]_i_15_n_5\,
      DI(2) => \derivative_reg[7]_i_15_n_6\,
      DI(1) => \derivative_reg[7]_i_15_n_7\,
      DI(0) => \derivative_reg[7]_i_20_n_4\,
      O(3) => \derivative_reg[6]_i_15_n_4\,
      O(2) => \derivative_reg[6]_i_15_n_5\,
      O(1) => \derivative_reg[6]_i_15_n_6\,
      O(0) => \derivative_reg[6]_i_15_n_7\,
      S(3) => \derivative[6]_i_21_n_0\,
      S(2) => \derivative[6]_i_22_n_0\,
      S(1) => \derivative[6]_i_23_n_0\,
      S(0) => \derivative[6]_i_24_n_0\
    );
\derivative_reg[6]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_5_n_0\,
      CO(3) => \derivative_reg[6]_i_2_n_0\,
      CO(2) => \derivative_reg[6]_i_2_n_1\,
      CO(1) => \derivative_reg[6]_i_2_n_2\,
      CO(0) => \derivative_reg[6]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[7]_i_2_n_5\,
      DI(2) => \derivative_reg[7]_i_2_n_6\,
      DI(1) => \derivative_reg[7]_i_2_n_7\,
      DI(0) => \derivative_reg[7]_i_5_n_4\,
      O(3) => \derivative_reg[6]_i_2_n_4\,
      O(2) => \derivative_reg[6]_i_2_n_5\,
      O(1) => \derivative_reg[6]_i_2_n_6\,
      O(0) => \derivative_reg[6]_i_2_n_7\,
      S(3) => \derivative[6]_i_6_n_0\,
      S(2) => \derivative[6]_i_7_n_0\,
      S(1) => \derivative[6]_i_8_n_0\,
      S(0) => \derivative[6]_i_9_n_0\
    );
\derivative_reg[6]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_25_n_0\,
      CO(3) => \derivative_reg[6]_i_20_n_0\,
      CO(2) => \derivative_reg[6]_i_20_n_1\,
      CO(1) => \derivative_reg[6]_i_20_n_2\,
      CO(0) => \derivative_reg[6]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[7]_i_20_n_5\,
      DI(2) => \derivative_reg[7]_i_20_n_6\,
      DI(1) => \derivative_reg[7]_i_20_n_7\,
      DI(0) => \derivative_reg[7]_i_25_n_4\,
      O(3) => \derivative_reg[6]_i_20_n_4\,
      O(2) => \derivative_reg[6]_i_20_n_5\,
      O(1) => \derivative_reg[6]_i_20_n_6\,
      O(0) => \derivative_reg[6]_i_20_n_7\,
      S(3) => \derivative[6]_i_26_n_0\,
      S(2) => \derivative[6]_i_27_n_0\,
      S(1) => \derivative[6]_i_28_n_0\,
      S(0) => \derivative[6]_i_29_n_0\
    );
\derivative_reg[6]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_30_n_0\,
      CO(3) => \derivative_reg[6]_i_25_n_0\,
      CO(2) => \derivative_reg[6]_i_25_n_1\,
      CO(1) => \derivative_reg[6]_i_25_n_2\,
      CO(0) => \derivative_reg[6]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[7]_i_25_n_5\,
      DI(2) => \derivative_reg[7]_i_25_n_6\,
      DI(1) => \derivative_reg[7]_i_25_n_7\,
      DI(0) => \derivative_reg[7]_i_30_n_4\,
      O(3) => \derivative_reg[6]_i_25_n_4\,
      O(2) => \derivative_reg[6]_i_25_n_5\,
      O(1) => \derivative_reg[6]_i_25_n_6\,
      O(0) => \derivative_reg[6]_i_25_n_7\,
      S(3) => \derivative[6]_i_31_n_0\,
      S(2) => \derivative[6]_i_32_n_0\,
      S(1) => \derivative[6]_i_33_n_0\,
      S(0) => \derivative[6]_i_34_n_0\
    );
\derivative_reg[6]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_35_n_0\,
      CO(3) => \derivative_reg[6]_i_30_n_0\,
      CO(2) => \derivative_reg[6]_i_30_n_1\,
      CO(1) => \derivative_reg[6]_i_30_n_2\,
      CO(0) => \derivative_reg[6]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[7]_i_30_n_5\,
      DI(2) => \derivative_reg[7]_i_30_n_6\,
      DI(1) => \derivative_reg[7]_i_30_n_7\,
      DI(0) => \derivative_reg[7]_i_35_n_4\,
      O(3) => \derivative_reg[6]_i_30_n_4\,
      O(2) => \derivative_reg[6]_i_30_n_5\,
      O(1) => \derivative_reg[6]_i_30_n_6\,
      O(0) => \derivative_reg[6]_i_30_n_7\,
      S(3) => \derivative[6]_i_36_n_0\,
      S(2) => \derivative[6]_i_37_n_0\,
      S(1) => \derivative[6]_i_38_n_0\,
      S(0) => \derivative[6]_i_39_n_0\
    );
\derivative_reg[6]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[6]_i_35_n_0\,
      CO(2) => \derivative_reg[6]_i_35_n_1\,
      CO(1) => \derivative_reg[6]_i_35_n_2\,
      CO(0) => \derivative_reg[6]_i_35_n_3\,
      CYINIT => \derivative_reg[7]_i_1_n_2\,
      DI(3) => \derivative_reg[7]_i_35_n_5\,
      DI(2) => \derivative_reg[7]_i_35_n_6\,
      DI(1) => derivative11_out(6),
      DI(0) => '0',
      O(3) => \derivative_reg[6]_i_35_n_4\,
      O(2) => \derivative_reg[6]_i_35_n_5\,
      O(1) => \derivative_reg[6]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[6]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[6]_i_40_n_0\,
      S(2) => \derivative[6]_i_41_n_0\,
      S(1) => \derivative[6]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[6]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[6]_i_10_n_0\,
      CO(3) => \derivative_reg[6]_i_5_n_0\,
      CO(2) => \derivative_reg[6]_i_5_n_1\,
      CO(1) => \derivative_reg[6]_i_5_n_2\,
      CO(0) => \derivative_reg[6]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[7]_i_5_n_5\,
      DI(2) => \derivative_reg[7]_i_5_n_6\,
      DI(1) => \derivative_reg[7]_i_5_n_7\,
      DI(0) => \derivative_reg[7]_i_10_n_4\,
      O(3) => \derivative_reg[6]_i_5_n_4\,
      O(2) => \derivative_reg[6]_i_5_n_5\,
      O(1) => \derivative_reg[6]_i_5_n_6\,
      O(0) => \derivative_reg[6]_i_5_n_7\,
      S(3) => \derivative[6]_i_11_n_0\,
      S(2) => \derivative[6]_i_12_n_0\,
      S(1) => \derivative[6]_i_13_n_0\,
      S(0) => \derivative[6]_i_14_n_0\
    );
\derivative_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[7]_i_1_n_2\,
      Q => derivative_out(7),
      R => '0'
    );
\derivative_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[7]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[7]_i_1_n_2\,
      CO(0) => \derivative_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[8]_i_1_n_2\,
      DI(0) => \derivative_reg[8]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[7]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[7]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[7]_i_3_n_0\,
      S(0) => \derivative[7]_i_4_n_0\
    );
\derivative_reg[7]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_15_n_0\,
      CO(3) => \derivative_reg[7]_i_10_n_0\,
      CO(2) => \derivative_reg[7]_i_10_n_1\,
      CO(1) => \derivative_reg[7]_i_10_n_2\,
      CO(0) => \derivative_reg[7]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[8]_i_10_n_5\,
      DI(2) => \derivative_reg[8]_i_10_n_6\,
      DI(1) => \derivative_reg[8]_i_10_n_7\,
      DI(0) => \derivative_reg[8]_i_15_n_4\,
      O(3) => \derivative_reg[7]_i_10_n_4\,
      O(2) => \derivative_reg[7]_i_10_n_5\,
      O(1) => \derivative_reg[7]_i_10_n_6\,
      O(0) => \derivative_reg[7]_i_10_n_7\,
      S(3) => \derivative[7]_i_16_n_0\,
      S(2) => \derivative[7]_i_17_n_0\,
      S(1) => \derivative[7]_i_18_n_0\,
      S(0) => \derivative[7]_i_19_n_0\
    );
\derivative_reg[7]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_20_n_0\,
      CO(3) => \derivative_reg[7]_i_15_n_0\,
      CO(2) => \derivative_reg[7]_i_15_n_1\,
      CO(1) => \derivative_reg[7]_i_15_n_2\,
      CO(0) => \derivative_reg[7]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[8]_i_15_n_5\,
      DI(2) => \derivative_reg[8]_i_15_n_6\,
      DI(1) => \derivative_reg[8]_i_15_n_7\,
      DI(0) => \derivative_reg[8]_i_20_n_4\,
      O(3) => \derivative_reg[7]_i_15_n_4\,
      O(2) => \derivative_reg[7]_i_15_n_5\,
      O(1) => \derivative_reg[7]_i_15_n_6\,
      O(0) => \derivative_reg[7]_i_15_n_7\,
      S(3) => \derivative[7]_i_21_n_0\,
      S(2) => \derivative[7]_i_22_n_0\,
      S(1) => \derivative[7]_i_23_n_0\,
      S(0) => \derivative[7]_i_24_n_0\
    );
\derivative_reg[7]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_5_n_0\,
      CO(3) => \derivative_reg[7]_i_2_n_0\,
      CO(2) => \derivative_reg[7]_i_2_n_1\,
      CO(1) => \derivative_reg[7]_i_2_n_2\,
      CO(0) => \derivative_reg[7]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[8]_i_2_n_5\,
      DI(2) => \derivative_reg[8]_i_2_n_6\,
      DI(1) => \derivative_reg[8]_i_2_n_7\,
      DI(0) => \derivative_reg[8]_i_5_n_4\,
      O(3) => \derivative_reg[7]_i_2_n_4\,
      O(2) => \derivative_reg[7]_i_2_n_5\,
      O(1) => \derivative_reg[7]_i_2_n_6\,
      O(0) => \derivative_reg[7]_i_2_n_7\,
      S(3) => \derivative[7]_i_6_n_0\,
      S(2) => \derivative[7]_i_7_n_0\,
      S(1) => \derivative[7]_i_8_n_0\,
      S(0) => \derivative[7]_i_9_n_0\
    );
\derivative_reg[7]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_25_n_0\,
      CO(3) => \derivative_reg[7]_i_20_n_0\,
      CO(2) => \derivative_reg[7]_i_20_n_1\,
      CO(1) => \derivative_reg[7]_i_20_n_2\,
      CO(0) => \derivative_reg[7]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[8]_i_20_n_5\,
      DI(2) => \derivative_reg[8]_i_20_n_6\,
      DI(1) => \derivative_reg[8]_i_20_n_7\,
      DI(0) => \derivative_reg[8]_i_25_n_4\,
      O(3) => \derivative_reg[7]_i_20_n_4\,
      O(2) => \derivative_reg[7]_i_20_n_5\,
      O(1) => \derivative_reg[7]_i_20_n_6\,
      O(0) => \derivative_reg[7]_i_20_n_7\,
      S(3) => \derivative[7]_i_26_n_0\,
      S(2) => \derivative[7]_i_27_n_0\,
      S(1) => \derivative[7]_i_28_n_0\,
      S(0) => \derivative[7]_i_29_n_0\
    );
\derivative_reg[7]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_30_n_0\,
      CO(3) => \derivative_reg[7]_i_25_n_0\,
      CO(2) => \derivative_reg[7]_i_25_n_1\,
      CO(1) => \derivative_reg[7]_i_25_n_2\,
      CO(0) => \derivative_reg[7]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[8]_i_25_n_5\,
      DI(2) => \derivative_reg[8]_i_25_n_6\,
      DI(1) => \derivative_reg[8]_i_25_n_7\,
      DI(0) => \derivative_reg[8]_i_30_n_4\,
      O(3) => \derivative_reg[7]_i_25_n_4\,
      O(2) => \derivative_reg[7]_i_25_n_5\,
      O(1) => \derivative_reg[7]_i_25_n_6\,
      O(0) => \derivative_reg[7]_i_25_n_7\,
      S(3) => \derivative[7]_i_31_n_0\,
      S(2) => \derivative[7]_i_32_n_0\,
      S(1) => \derivative[7]_i_33_n_0\,
      S(0) => \derivative[7]_i_34_n_0\
    );
\derivative_reg[7]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_35_n_0\,
      CO(3) => \derivative_reg[7]_i_30_n_0\,
      CO(2) => \derivative_reg[7]_i_30_n_1\,
      CO(1) => \derivative_reg[7]_i_30_n_2\,
      CO(0) => \derivative_reg[7]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[8]_i_30_n_5\,
      DI(2) => \derivative_reg[8]_i_30_n_6\,
      DI(1) => \derivative_reg[8]_i_30_n_7\,
      DI(0) => \derivative_reg[8]_i_35_n_4\,
      O(3) => \derivative_reg[7]_i_30_n_4\,
      O(2) => \derivative_reg[7]_i_30_n_5\,
      O(1) => \derivative_reg[7]_i_30_n_6\,
      O(0) => \derivative_reg[7]_i_30_n_7\,
      S(3) => \derivative[7]_i_36_n_0\,
      S(2) => \derivative[7]_i_37_n_0\,
      S(1) => \derivative[7]_i_38_n_0\,
      S(0) => \derivative[7]_i_39_n_0\
    );
\derivative_reg[7]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[7]_i_35_n_0\,
      CO(2) => \derivative_reg[7]_i_35_n_1\,
      CO(1) => \derivative_reg[7]_i_35_n_2\,
      CO(0) => \derivative_reg[7]_i_35_n_3\,
      CYINIT => \derivative_reg[8]_i_1_n_2\,
      DI(3) => \derivative_reg[8]_i_35_n_5\,
      DI(2) => \derivative_reg[8]_i_35_n_6\,
      DI(1) => derivative11_out(7),
      DI(0) => '0',
      O(3) => \derivative_reg[7]_i_35_n_4\,
      O(2) => \derivative_reg[7]_i_35_n_5\,
      O(1) => \derivative_reg[7]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[7]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[7]_i_40_n_0\,
      S(2) => \derivative[7]_i_41_n_0\,
      S(1) => \derivative[7]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[7]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[7]_i_10_n_0\,
      CO(3) => \derivative_reg[7]_i_5_n_0\,
      CO(2) => \derivative_reg[7]_i_5_n_1\,
      CO(1) => \derivative_reg[7]_i_5_n_2\,
      CO(0) => \derivative_reg[7]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[8]_i_5_n_5\,
      DI(2) => \derivative_reg[8]_i_5_n_6\,
      DI(1) => \derivative_reg[8]_i_5_n_7\,
      DI(0) => \derivative_reg[8]_i_10_n_4\,
      O(3) => \derivative_reg[7]_i_5_n_4\,
      O(2) => \derivative_reg[7]_i_5_n_5\,
      O(1) => \derivative_reg[7]_i_5_n_6\,
      O(0) => \derivative_reg[7]_i_5_n_7\,
      S(3) => \derivative[7]_i_11_n_0\,
      S(2) => \derivative[7]_i_12_n_0\,
      S(1) => \derivative[7]_i_13_n_0\,
      S(0) => \derivative[7]_i_14_n_0\
    );
\derivative_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[8]_i_1_n_2\,
      Q => derivative_out(8),
      R => '0'
    );
\derivative_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[8]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[8]_i_1_n_2\,
      CO(0) => \derivative_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[9]_i_1_n_2\,
      DI(0) => \derivative_reg[9]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[8]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[8]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[8]_i_3_n_0\,
      S(0) => \derivative[8]_i_4_n_0\
    );
\derivative_reg[8]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_15_n_0\,
      CO(3) => \derivative_reg[8]_i_10_n_0\,
      CO(2) => \derivative_reg[8]_i_10_n_1\,
      CO(1) => \derivative_reg[8]_i_10_n_2\,
      CO(0) => \derivative_reg[8]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[9]_i_10_n_5\,
      DI(2) => \derivative_reg[9]_i_10_n_6\,
      DI(1) => \derivative_reg[9]_i_10_n_7\,
      DI(0) => \derivative_reg[9]_i_15_n_4\,
      O(3) => \derivative_reg[8]_i_10_n_4\,
      O(2) => \derivative_reg[8]_i_10_n_5\,
      O(1) => \derivative_reg[8]_i_10_n_6\,
      O(0) => \derivative_reg[8]_i_10_n_7\,
      S(3) => \derivative[8]_i_16_n_0\,
      S(2) => \derivative[8]_i_17_n_0\,
      S(1) => \derivative[8]_i_18_n_0\,
      S(0) => \derivative[8]_i_19_n_0\
    );
\derivative_reg[8]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_20_n_0\,
      CO(3) => \derivative_reg[8]_i_15_n_0\,
      CO(2) => \derivative_reg[8]_i_15_n_1\,
      CO(1) => \derivative_reg[8]_i_15_n_2\,
      CO(0) => \derivative_reg[8]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[9]_i_15_n_5\,
      DI(2) => \derivative_reg[9]_i_15_n_6\,
      DI(1) => \derivative_reg[9]_i_15_n_7\,
      DI(0) => \derivative_reg[9]_i_20_n_4\,
      O(3) => \derivative_reg[8]_i_15_n_4\,
      O(2) => \derivative_reg[8]_i_15_n_5\,
      O(1) => \derivative_reg[8]_i_15_n_6\,
      O(0) => \derivative_reg[8]_i_15_n_7\,
      S(3) => \derivative[8]_i_21_n_0\,
      S(2) => \derivative[8]_i_22_n_0\,
      S(1) => \derivative[8]_i_23_n_0\,
      S(0) => \derivative[8]_i_24_n_0\
    );
\derivative_reg[8]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_5_n_0\,
      CO(3) => \derivative_reg[8]_i_2_n_0\,
      CO(2) => \derivative_reg[8]_i_2_n_1\,
      CO(1) => \derivative_reg[8]_i_2_n_2\,
      CO(0) => \derivative_reg[8]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[9]_i_2_n_5\,
      DI(2) => \derivative_reg[9]_i_2_n_6\,
      DI(1) => \derivative_reg[9]_i_2_n_7\,
      DI(0) => \derivative_reg[9]_i_5_n_4\,
      O(3) => \derivative_reg[8]_i_2_n_4\,
      O(2) => \derivative_reg[8]_i_2_n_5\,
      O(1) => \derivative_reg[8]_i_2_n_6\,
      O(0) => \derivative_reg[8]_i_2_n_7\,
      S(3) => \derivative[8]_i_6_n_0\,
      S(2) => \derivative[8]_i_7_n_0\,
      S(1) => \derivative[8]_i_8_n_0\,
      S(0) => \derivative[8]_i_9_n_0\
    );
\derivative_reg[8]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_25_n_0\,
      CO(3) => \derivative_reg[8]_i_20_n_0\,
      CO(2) => \derivative_reg[8]_i_20_n_1\,
      CO(1) => \derivative_reg[8]_i_20_n_2\,
      CO(0) => \derivative_reg[8]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[9]_i_20_n_5\,
      DI(2) => \derivative_reg[9]_i_20_n_6\,
      DI(1) => \derivative_reg[9]_i_20_n_7\,
      DI(0) => \derivative_reg[9]_i_25_n_4\,
      O(3) => \derivative_reg[8]_i_20_n_4\,
      O(2) => \derivative_reg[8]_i_20_n_5\,
      O(1) => \derivative_reg[8]_i_20_n_6\,
      O(0) => \derivative_reg[8]_i_20_n_7\,
      S(3) => \derivative[8]_i_26_n_0\,
      S(2) => \derivative[8]_i_27_n_0\,
      S(1) => \derivative[8]_i_28_n_0\,
      S(0) => \derivative[8]_i_29_n_0\
    );
\derivative_reg[8]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_30_n_0\,
      CO(3) => \derivative_reg[8]_i_25_n_0\,
      CO(2) => \derivative_reg[8]_i_25_n_1\,
      CO(1) => \derivative_reg[8]_i_25_n_2\,
      CO(0) => \derivative_reg[8]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[9]_i_25_n_5\,
      DI(2) => \derivative_reg[9]_i_25_n_6\,
      DI(1) => \derivative_reg[9]_i_25_n_7\,
      DI(0) => \derivative_reg[9]_i_30_n_4\,
      O(3) => \derivative_reg[8]_i_25_n_4\,
      O(2) => \derivative_reg[8]_i_25_n_5\,
      O(1) => \derivative_reg[8]_i_25_n_6\,
      O(0) => \derivative_reg[8]_i_25_n_7\,
      S(3) => \derivative[8]_i_31_n_0\,
      S(2) => \derivative[8]_i_32_n_0\,
      S(1) => \derivative[8]_i_33_n_0\,
      S(0) => \derivative[8]_i_34_n_0\
    );
\derivative_reg[8]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_35_n_0\,
      CO(3) => \derivative_reg[8]_i_30_n_0\,
      CO(2) => \derivative_reg[8]_i_30_n_1\,
      CO(1) => \derivative_reg[8]_i_30_n_2\,
      CO(0) => \derivative_reg[8]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[9]_i_30_n_5\,
      DI(2) => \derivative_reg[9]_i_30_n_6\,
      DI(1) => \derivative_reg[9]_i_30_n_7\,
      DI(0) => \derivative_reg[9]_i_35_n_4\,
      O(3) => \derivative_reg[8]_i_30_n_4\,
      O(2) => \derivative_reg[8]_i_30_n_5\,
      O(1) => \derivative_reg[8]_i_30_n_6\,
      O(0) => \derivative_reg[8]_i_30_n_7\,
      S(3) => \derivative[8]_i_36_n_0\,
      S(2) => \derivative[8]_i_37_n_0\,
      S(1) => \derivative[8]_i_38_n_0\,
      S(0) => \derivative[8]_i_39_n_0\
    );
\derivative_reg[8]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[8]_i_35_n_0\,
      CO(2) => \derivative_reg[8]_i_35_n_1\,
      CO(1) => \derivative_reg[8]_i_35_n_2\,
      CO(0) => \derivative_reg[8]_i_35_n_3\,
      CYINIT => \derivative_reg[9]_i_1_n_2\,
      DI(3) => \derivative_reg[9]_i_35_n_5\,
      DI(2) => \derivative_reg[9]_i_35_n_6\,
      DI(1) => derivative11_out(8),
      DI(0) => '0',
      O(3) => \derivative_reg[8]_i_35_n_4\,
      O(2) => \derivative_reg[8]_i_35_n_5\,
      O(1) => \derivative_reg[8]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[8]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[8]_i_40_n_0\,
      S(2) => \derivative[8]_i_41_n_0\,
      S(1) => \derivative[8]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[8]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[8]_i_10_n_0\,
      CO(3) => \derivative_reg[8]_i_5_n_0\,
      CO(2) => \derivative_reg[8]_i_5_n_1\,
      CO(1) => \derivative_reg[8]_i_5_n_2\,
      CO(0) => \derivative_reg[8]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[9]_i_5_n_5\,
      DI(2) => \derivative_reg[9]_i_5_n_6\,
      DI(1) => \derivative_reg[9]_i_5_n_7\,
      DI(0) => \derivative_reg[9]_i_10_n_4\,
      O(3) => \derivative_reg[8]_i_5_n_4\,
      O(2) => \derivative_reg[8]_i_5_n_5\,
      O(1) => \derivative_reg[8]_i_5_n_6\,
      O(0) => \derivative_reg[8]_i_5_n_7\,
      S(3) => \derivative[8]_i_11_n_0\,
      S(2) => \derivative[8]_i_12_n_0\,
      S(1) => \derivative[8]_i_13_n_0\,
      S(0) => \derivative[8]_i_14_n_0\
    );
\derivative_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => \derivative_reg[9]_i_1_n_2\,
      Q => derivative_out(9),
      R => '0'
    );
\derivative_reg[9]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_2_n_0\,
      CO(3 downto 2) => \NLW_derivative_reg[9]_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \derivative_reg[9]_i_1_n_2\,
      CO(0) => \derivative_reg[9]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \derivative_reg[10]_i_1_n_2\,
      DI(0) => \derivative_reg[10]_i_2_n_4\,
      O(3 downto 1) => \NLW_derivative_reg[9]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => \derivative_reg[9]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \derivative[9]_i_3_n_0\,
      S(0) => \derivative[9]_i_4_n_0\
    );
\derivative_reg[9]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_15_n_0\,
      CO(3) => \derivative_reg[9]_i_10_n_0\,
      CO(2) => \derivative_reg[9]_i_10_n_1\,
      CO(1) => \derivative_reg[9]_i_10_n_2\,
      CO(0) => \derivative_reg[9]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[10]_i_10_n_5\,
      DI(2) => \derivative_reg[10]_i_10_n_6\,
      DI(1) => \derivative_reg[10]_i_10_n_7\,
      DI(0) => \derivative_reg[10]_i_15_n_4\,
      O(3) => \derivative_reg[9]_i_10_n_4\,
      O(2) => \derivative_reg[9]_i_10_n_5\,
      O(1) => \derivative_reg[9]_i_10_n_6\,
      O(0) => \derivative_reg[9]_i_10_n_7\,
      S(3) => \derivative[9]_i_16_n_0\,
      S(2) => \derivative[9]_i_17_n_0\,
      S(1) => \derivative[9]_i_18_n_0\,
      S(0) => \derivative[9]_i_19_n_0\
    );
\derivative_reg[9]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_20_n_0\,
      CO(3) => \derivative_reg[9]_i_15_n_0\,
      CO(2) => \derivative_reg[9]_i_15_n_1\,
      CO(1) => \derivative_reg[9]_i_15_n_2\,
      CO(0) => \derivative_reg[9]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[10]_i_15_n_5\,
      DI(2) => \derivative_reg[10]_i_15_n_6\,
      DI(1) => \derivative_reg[10]_i_15_n_7\,
      DI(0) => \derivative_reg[10]_i_20_n_4\,
      O(3) => \derivative_reg[9]_i_15_n_4\,
      O(2) => \derivative_reg[9]_i_15_n_5\,
      O(1) => \derivative_reg[9]_i_15_n_6\,
      O(0) => \derivative_reg[9]_i_15_n_7\,
      S(3) => \derivative[9]_i_21_n_0\,
      S(2) => \derivative[9]_i_22_n_0\,
      S(1) => \derivative[9]_i_23_n_0\,
      S(0) => \derivative[9]_i_24_n_0\
    );
\derivative_reg[9]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_5_n_0\,
      CO(3) => \derivative_reg[9]_i_2_n_0\,
      CO(2) => \derivative_reg[9]_i_2_n_1\,
      CO(1) => \derivative_reg[9]_i_2_n_2\,
      CO(0) => \derivative_reg[9]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[10]_i_2_n_5\,
      DI(2) => \derivative_reg[10]_i_2_n_6\,
      DI(1) => \derivative_reg[10]_i_2_n_7\,
      DI(0) => \derivative_reg[10]_i_5_n_4\,
      O(3) => \derivative_reg[9]_i_2_n_4\,
      O(2) => \derivative_reg[9]_i_2_n_5\,
      O(1) => \derivative_reg[9]_i_2_n_6\,
      O(0) => \derivative_reg[9]_i_2_n_7\,
      S(3) => \derivative[9]_i_6_n_0\,
      S(2) => \derivative[9]_i_7_n_0\,
      S(1) => \derivative[9]_i_8_n_0\,
      S(0) => \derivative[9]_i_9_n_0\
    );
\derivative_reg[9]_i_20\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_25_n_0\,
      CO(3) => \derivative_reg[9]_i_20_n_0\,
      CO(2) => \derivative_reg[9]_i_20_n_1\,
      CO(1) => \derivative_reg[9]_i_20_n_2\,
      CO(0) => \derivative_reg[9]_i_20_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[10]_i_20_n_5\,
      DI(2) => \derivative_reg[10]_i_20_n_6\,
      DI(1) => \derivative_reg[10]_i_20_n_7\,
      DI(0) => \derivative_reg[10]_i_25_n_4\,
      O(3) => \derivative_reg[9]_i_20_n_4\,
      O(2) => \derivative_reg[9]_i_20_n_5\,
      O(1) => \derivative_reg[9]_i_20_n_6\,
      O(0) => \derivative_reg[9]_i_20_n_7\,
      S(3) => \derivative[9]_i_26_n_0\,
      S(2) => \derivative[9]_i_27_n_0\,
      S(1) => \derivative[9]_i_28_n_0\,
      S(0) => \derivative[9]_i_29_n_0\
    );
\derivative_reg[9]_i_25\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_30_n_0\,
      CO(3) => \derivative_reg[9]_i_25_n_0\,
      CO(2) => \derivative_reg[9]_i_25_n_1\,
      CO(1) => \derivative_reg[9]_i_25_n_2\,
      CO(0) => \derivative_reg[9]_i_25_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[10]_i_25_n_5\,
      DI(2) => \derivative_reg[10]_i_25_n_6\,
      DI(1) => \derivative_reg[10]_i_25_n_7\,
      DI(0) => \derivative_reg[10]_i_30_n_4\,
      O(3) => \derivative_reg[9]_i_25_n_4\,
      O(2) => \derivative_reg[9]_i_25_n_5\,
      O(1) => \derivative_reg[9]_i_25_n_6\,
      O(0) => \derivative_reg[9]_i_25_n_7\,
      S(3) => \derivative[9]_i_31_n_0\,
      S(2) => \derivative[9]_i_32_n_0\,
      S(1) => \derivative[9]_i_33_n_0\,
      S(0) => \derivative[9]_i_34_n_0\
    );
\derivative_reg[9]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_35_n_0\,
      CO(3) => \derivative_reg[9]_i_30_n_0\,
      CO(2) => \derivative_reg[9]_i_30_n_1\,
      CO(1) => \derivative_reg[9]_i_30_n_2\,
      CO(0) => \derivative_reg[9]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[10]_i_30_n_5\,
      DI(2) => \derivative_reg[10]_i_30_n_6\,
      DI(1) => \derivative_reg[10]_i_30_n_7\,
      DI(0) => \derivative_reg[10]_i_35_n_4\,
      O(3) => \derivative_reg[9]_i_30_n_4\,
      O(2) => \derivative_reg[9]_i_30_n_5\,
      O(1) => \derivative_reg[9]_i_30_n_6\,
      O(0) => \derivative_reg[9]_i_30_n_7\,
      S(3) => \derivative[9]_i_36_n_0\,
      S(2) => \derivative[9]_i_37_n_0\,
      S(1) => \derivative[9]_i_38_n_0\,
      S(0) => \derivative[9]_i_39_n_0\
    );
\derivative_reg[9]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \derivative_reg[9]_i_35_n_0\,
      CO(2) => \derivative_reg[9]_i_35_n_1\,
      CO(1) => \derivative_reg[9]_i_35_n_2\,
      CO(0) => \derivative_reg[9]_i_35_n_3\,
      CYINIT => \derivative_reg[10]_i_1_n_2\,
      DI(3) => \derivative_reg[10]_i_35_n_5\,
      DI(2) => \derivative_reg[10]_i_35_n_6\,
      DI(1) => derivative11_out(9),
      DI(0) => '0',
      O(3) => \derivative_reg[9]_i_35_n_4\,
      O(2) => \derivative_reg[9]_i_35_n_5\,
      O(1) => \derivative_reg[9]_i_35_n_6\,
      O(0) => \NLW_derivative_reg[9]_i_35_O_UNCONNECTED\(0),
      S(3) => \derivative[9]_i_40_n_0\,
      S(2) => \derivative[9]_i_41_n_0\,
      S(1) => \derivative[9]_i_42_n_0\,
      S(0) => '1'
    );
\derivative_reg[9]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \derivative_reg[9]_i_10_n_0\,
      CO(3) => \derivative_reg[9]_i_5_n_0\,
      CO(2) => \derivative_reg[9]_i_5_n_1\,
      CO(1) => \derivative_reg[9]_i_5_n_2\,
      CO(0) => \derivative_reg[9]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => \derivative_reg[10]_i_5_n_5\,
      DI(2) => \derivative_reg[10]_i_5_n_6\,
      DI(1) => \derivative_reg[10]_i_5_n_7\,
      DI(0) => \derivative_reg[10]_i_10_n_4\,
      O(3) => \derivative_reg[9]_i_5_n_4\,
      O(2) => \derivative_reg[9]_i_5_n_5\,
      O(1) => \derivative_reg[9]_i_5_n_6\,
      O(0) => \derivative_reg[9]_i_5_n_7\,
      S(3) => \derivative[9]_i_11_n_0\,
      S(2) => \derivative[9]_i_12_n_0\,
      S(1) => \derivative[9]_i_13_n_0\,
      S(0) => \derivative[9]_i_14_n_0\
    );
error0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => error0_carry_n_0,
      CO(2) => error0_carry_n_1,
      CO(1) => error0_carry_n_2,
      CO(0) => error0_carry_n_3,
      CYINIT => '1',
      DI(3 downto 0) => target_velocity(3 downto 0),
      O(3 downto 0) => error02_out(3 downto 0),
      S(3) => error0_carry_i_1_n_0,
      S(2) => error0_carry_i_2_n_0,
      S(1) => error0_carry_i_3_n_0,
      S(0) => error0_carry_i_4_n_0
    );
\error0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => error0_carry_n_0,
      CO(3) => \error0_carry__0_n_0\,
      CO(2) => \error0_carry__0_n_1\,
      CO(1) => \error0_carry__0_n_2\,
      CO(0) => \error0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => target_velocity(7 downto 4),
      O(3 downto 0) => error02_out(7 downto 4),
      S(3) => \error0_carry__0_i_1_n_0\,
      S(2) => \error0_carry__0_i_2_n_0\,
      S(1) => \error0_carry__0_i_3_n_0\,
      S(0) => \error0_carry__0_i_4_n_0\
    );
\error0_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(7),
      I1 => velocity_in(7),
      O => \error0_carry__0_i_1_n_0\
    );
\error0_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(6),
      I1 => velocity_in(6),
      O => \error0_carry__0_i_2_n_0\
    );
\error0_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(5),
      I1 => velocity_in(5),
      O => \error0_carry__0_i_3_n_0\
    );
\error0_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(4),
      I1 => velocity_in(4),
      O => \error0_carry__0_i_4_n_0\
    );
\error0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__0_n_0\,
      CO(3) => \error0_carry__1_n_0\,
      CO(2) => \error0_carry__1_n_1\,
      CO(1) => \error0_carry__1_n_2\,
      CO(0) => \error0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => target_velocity(11 downto 8),
      O(3 downto 0) => error02_out(11 downto 8),
      S(3) => \error0_carry__1_i_1_n_0\,
      S(2) => \error0_carry__1_i_2_n_0\,
      S(1) => \error0_carry__1_i_3_n_0\,
      S(0) => \error0_carry__1_i_4_n_0\
    );
\error0_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(11),
      I1 => velocity_in(11),
      O => \error0_carry__1_i_1_n_0\
    );
\error0_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(10),
      I1 => velocity_in(10),
      O => \error0_carry__1_i_2_n_0\
    );
\error0_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(9),
      I1 => velocity_in(9),
      O => \error0_carry__1_i_3_n_0\
    );
\error0_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(8),
      I1 => velocity_in(8),
      O => \error0_carry__1_i_4_n_0\
    );
\error0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__1_n_0\,
      CO(3) => \error0_carry__2_n_0\,
      CO(2) => \error0_carry__2_n_1\,
      CO(1) => \error0_carry__2_n_2\,
      CO(0) => \error0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => target_velocity(15 downto 12),
      O(3 downto 0) => error02_out(15 downto 12),
      S(3) => \error0_carry__2_i_1_n_0\,
      S(2) => \error0_carry__2_i_2_n_0\,
      S(1) => \error0_carry__2_i_3_n_0\,
      S(0) => \error0_carry__2_i_4_n_0\
    );
\error0_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(15),
      I1 => velocity_in(15),
      O => \error0_carry__2_i_1_n_0\
    );
\error0_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(14),
      I1 => velocity_in(14),
      O => \error0_carry__2_i_2_n_0\
    );
\error0_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(13),
      I1 => velocity_in(13),
      O => \error0_carry__2_i_3_n_0\
    );
\error0_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(12),
      I1 => velocity_in(12),
      O => \error0_carry__2_i_4_n_0\
    );
\error0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__2_n_0\,
      CO(3) => \error0_carry__3_n_0\,
      CO(2) => \error0_carry__3_n_1\,
      CO(1) => \error0_carry__3_n_2\,
      CO(0) => \error0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => target_velocity(19 downto 16),
      O(3 downto 0) => error02_out(19 downto 16),
      S(3) => \error0_carry__3_i_1_n_0\,
      S(2) => \error0_carry__3_i_2_n_0\,
      S(1) => \error0_carry__3_i_3_n_0\,
      S(0) => \error0_carry__3_i_4_n_0\
    );
\error0_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(19),
      I1 => velocity_in(19),
      O => \error0_carry__3_i_1_n_0\
    );
\error0_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(18),
      I1 => velocity_in(18),
      O => \error0_carry__3_i_2_n_0\
    );
\error0_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(17),
      I1 => velocity_in(17),
      O => \error0_carry__3_i_3_n_0\
    );
\error0_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(16),
      I1 => velocity_in(16),
      O => \error0_carry__3_i_4_n_0\
    );
\error0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__3_n_0\,
      CO(3) => \error0_carry__4_n_0\,
      CO(2) => \error0_carry__4_n_1\,
      CO(1) => \error0_carry__4_n_2\,
      CO(0) => \error0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => target_velocity(23 downto 20),
      O(3 downto 0) => error02_out(23 downto 20),
      S(3) => \error0_carry__4_i_1_n_0\,
      S(2) => \error0_carry__4_i_2_n_0\,
      S(1) => \error0_carry__4_i_3_n_0\,
      S(0) => \error0_carry__4_i_4_n_0\
    );
\error0_carry__4_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(23),
      I1 => velocity_in(23),
      O => \error0_carry__4_i_1_n_0\
    );
\error0_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(22),
      I1 => velocity_in(22),
      O => \error0_carry__4_i_2_n_0\
    );
\error0_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(21),
      I1 => velocity_in(21),
      O => \error0_carry__4_i_3_n_0\
    );
\error0_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(20),
      I1 => velocity_in(20),
      O => \error0_carry__4_i_4_n_0\
    );
\error0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__4_n_0\,
      CO(3) => \error0_carry__5_n_0\,
      CO(2) => \error0_carry__5_n_1\,
      CO(1) => \error0_carry__5_n_2\,
      CO(0) => \error0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => target_velocity(27 downto 24),
      O(3 downto 0) => error02_out(27 downto 24),
      S(3) => \error0_carry__5_i_1_n_0\,
      S(2) => \error0_carry__5_i_2_n_0\,
      S(1) => \error0_carry__5_i_3_n_0\,
      S(0) => \error0_carry__5_i_4_n_0\
    );
\error0_carry__5_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(27),
      I1 => velocity_in(27),
      O => \error0_carry__5_i_1_n_0\
    );
\error0_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(26),
      I1 => velocity_in(26),
      O => \error0_carry__5_i_2_n_0\
    );
\error0_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(25),
      I1 => velocity_in(25),
      O => \error0_carry__5_i_3_n_0\
    );
\error0_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(24),
      I1 => velocity_in(24),
      O => \error0_carry__5_i_4_n_0\
    );
\error0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \error0_carry__5_n_0\,
      CO(3) => \NLW_error0_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \error0_carry__6_n_1\,
      CO(1) => \error0_carry__6_n_2\,
      CO(0) => \error0_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => target_velocity(30 downto 28),
      O(3 downto 0) => error02_out(31 downto 28),
      S(3) => \error0_carry__6_i_1_n_0\,
      S(2) => \error0_carry__6_i_2_n_0\,
      S(1) => \error0_carry__6_i_3_n_0\,
      S(0) => \error0_carry__6_i_4_n_0\
    );
\error0_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(31),
      I1 => velocity_in(31),
      O => \error0_carry__6_i_1_n_0\
    );
\error0_carry__6_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(30),
      I1 => velocity_in(30),
      O => \error0_carry__6_i_2_n_0\
    );
\error0_carry__6_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(29),
      I1 => velocity_in(29),
      O => \error0_carry__6_i_3_n_0\
    );
\error0_carry__6_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(28),
      I1 => velocity_in(28),
      O => \error0_carry__6_i_4_n_0\
    );
error0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(3),
      I1 => velocity_in(3),
      O => error0_carry_i_1_n_0
    );
error0_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(2),
      I1 => velocity_in(2),
      O => error0_carry_i_2_n_0
    );
error0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(1),
      I1 => velocity_in(1),
      O => error0_carry_i_3_n_0
    );
error0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => target_velocity(0),
      I1 => velocity_in(0),
      O => error0_carry_i_4_n_0
    );
\error_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(0),
      Q => error_out(0),
      R => '0'
    );
\error_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(10),
      Q => error_out(10),
      R => '0'
    );
\error_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(11),
      Q => error_out(11),
      R => '0'
    );
\error_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(12),
      Q => error_out(12),
      R => '0'
    );
\error_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(13),
      Q => error_out(13),
      R => '0'
    );
\error_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(14),
      Q => error_out(14),
      R => '0'
    );
\error_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(15),
      Q => error_out(15),
      R => '0'
    );
\error_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(16),
      Q => error_out(16),
      R => '0'
    );
\error_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(17),
      Q => error_out(17),
      R => '0'
    );
\error_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(18),
      Q => error_out(18),
      R => '0'
    );
\error_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(19),
      Q => error_out(19),
      R => '0'
    );
\error_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(1),
      Q => error_out(1),
      R => '0'
    );
\error_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(20),
      Q => error_out(20),
      R => '0'
    );
\error_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(21),
      Q => error_out(21),
      R => '0'
    );
\error_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(22),
      Q => error_out(22),
      R => '0'
    );
\error_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(23),
      Q => error_out(23),
      R => '0'
    );
\error_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(24),
      Q => error_out(24),
      R => '0'
    );
\error_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(25),
      Q => error_out(25),
      R => '0'
    );
\error_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(26),
      Q => error_out(26),
      R => '0'
    );
\error_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(27),
      Q => error_out(27),
      R => '0'
    );
\error_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(28),
      Q => error_out(28),
      R => '0'
    );
\error_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(29),
      Q => error_out(29),
      R => '0'
    );
\error_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(2),
      Q => error_out(2),
      R => '0'
    );
\error_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(30),
      Q => error_out(30),
      R => '0'
    );
\error_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(31),
      Q => error_out(31),
      R => '0'
    );
\error_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(3),
      Q => error_out(3),
      R => '0'
    );
\error_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(4),
      Q => error_out(4),
      R => '0'
    );
\error_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(5),
      Q => error_out(5),
      R => '0'
    );
\error_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(6),
      Q => error_out(6),
      R => '0'
    );
\error_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(7),
      Q => error_out(7),
      R => '0'
    );
\error_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(8),
      Q => error_out(8),
      R => '0'
    );
\error_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => error02_out(9),
      Q => error_out(9),
      R => '0'
    );
integral0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => integral0_carry_n_0,
      CO(2) => integral0_carry_n_1,
      CO(1) => integral0_carry_n_2,
      CO(0) => integral0_carry_n_3,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(3 downto 0),
      O(3 downto 0) => integral0(3 downto 0),
      S(3) => integral0_carry_i_1_n_0,
      S(2) => integral0_carry_i_2_n_0,
      S(1) => integral0_carry_i_3_n_0,
      S(0) => integral0_carry_i_4_n_0
    );
\integral0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => integral0_carry_n_0,
      CO(3) => \integral0_carry__0_n_0\,
      CO(2) => \integral0_carry__0_n_1\,
      CO(1) => \integral0_carry__0_n_2\,
      CO(0) => \integral0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(7 downto 4),
      O(3 downto 0) => integral0(7 downto 4),
      S(3) => \integral0_carry__0_i_1_n_0\,
      S(2) => \integral0_carry__0_i_2_n_0\,
      S(1) => \integral0_carry__0_i_3_n_0\,
      S(0) => \integral0_carry__0_i_4_n_0\
    );
\integral0_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(7),
      I1 => \integral1__0_n_98\,
      O => \integral0_carry__0_i_1_n_0\
    );
\integral0_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(6),
      I1 => \integral1__0_n_99\,
      O => \integral0_carry__0_i_2_n_0\
    );
\integral0_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(5),
      I1 => \integral1__0_n_100\,
      O => \integral0_carry__0_i_3_n_0\
    );
\integral0_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(4),
      I1 => \integral1__0_n_101\,
      O => \integral0_carry__0_i_4_n_0\
    );
\integral0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__0_n_0\,
      CO(3) => \integral0_carry__1_n_0\,
      CO(2) => \integral0_carry__1_n_1\,
      CO(1) => \integral0_carry__1_n_2\,
      CO(0) => \integral0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(11 downto 8),
      O(3 downto 0) => integral0(11 downto 8),
      S(3) => \integral0_carry__1_i_1_n_0\,
      S(2) => \integral0_carry__1_i_2_n_0\,
      S(1) => \integral0_carry__1_i_3_n_0\,
      S(0) => \integral0_carry__1_i_4_n_0\
    );
\integral0_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(11),
      I1 => \integral1__0_n_94\,
      O => \integral0_carry__1_i_1_n_0\
    );
\integral0_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(10),
      I1 => \integral1__0_n_95\,
      O => \integral0_carry__1_i_2_n_0\
    );
\integral0_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(9),
      I1 => \integral1__0_n_96\,
      O => \integral0_carry__1_i_3_n_0\
    );
\integral0_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(8),
      I1 => \integral1__0_n_97\,
      O => \integral0_carry__1_i_4_n_0\
    );
\integral0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__1_n_0\,
      CO(3) => \integral0_carry__2_n_0\,
      CO(2) => \integral0_carry__2_n_1\,
      CO(1) => \integral0_carry__2_n_2\,
      CO(0) => \integral0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(15 downto 12),
      O(3 downto 0) => integral0(15 downto 12),
      S(3) => \integral0_carry__2_i_1_n_0\,
      S(2) => \integral0_carry__2_i_2_n_0\,
      S(1) => \integral0_carry__2_i_3_n_0\,
      S(0) => \integral0_carry__2_i_4_n_0\
    );
\integral0_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(15),
      I1 => \integral1__0_n_90\,
      O => \integral0_carry__2_i_1_n_0\
    );
\integral0_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(14),
      I1 => \integral1__0_n_91\,
      O => \integral0_carry__2_i_2_n_0\
    );
\integral0_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(13),
      I1 => \integral1__0_n_92\,
      O => \integral0_carry__2_i_3_n_0\
    );
\integral0_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(12),
      I1 => \integral1__0_n_93\,
      O => \integral0_carry__2_i_4_n_0\
    );
\integral0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__2_n_0\,
      CO(3) => \integral0_carry__3_n_0\,
      CO(2) => \integral0_carry__3_n_1\,
      CO(1) => \integral0_carry__3_n_2\,
      CO(0) => \integral0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(19 downto 16),
      O(3 downto 0) => integral0(19 downto 16),
      S(3) => \integral0_carry__3_i_1_n_0\,
      S(2) => \integral0_carry__3_i_2_n_0\,
      S(1) => \integral0_carry__3_i_3_n_0\,
      S(0) => \integral0_carry__3_i_4_n_0\
    );
\integral0_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(19),
      I1 => integral1_carry_n_4,
      O => \integral0_carry__3_i_1_n_0\
    );
\integral0_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(18),
      I1 => integral1_carry_n_5,
      O => \integral0_carry__3_i_2_n_0\
    );
\integral0_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(17),
      I1 => integral1_carry_n_6,
      O => \integral0_carry__3_i_3_n_0\
    );
\integral0_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(16),
      I1 => integral1_carry_n_7,
      O => \integral0_carry__3_i_4_n_0\
    );
\integral0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__3_n_0\,
      CO(3) => \integral0_carry__4_n_0\,
      CO(2) => \integral0_carry__4_n_1\,
      CO(1) => \integral0_carry__4_n_2\,
      CO(0) => \integral0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(23 downto 20),
      O(3 downto 0) => integral0(23 downto 20),
      S(3) => \integral0_carry__4_i_1_n_0\,
      S(2) => \integral0_carry__4_i_2_n_0\,
      S(1) => \integral0_carry__4_i_3_n_0\,
      S(0) => \integral0_carry__4_i_4_n_0\
    );
\integral0_carry__4_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(23),
      I1 => \integral1_carry__0_n_4\,
      O => \integral0_carry__4_i_1_n_0\
    );
\integral0_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(22),
      I1 => \integral1_carry__0_n_5\,
      O => \integral0_carry__4_i_2_n_0\
    );
\integral0_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(21),
      I1 => \integral1_carry__0_n_6\,
      O => \integral0_carry__4_i_3_n_0\
    );
\integral0_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(20),
      I1 => \integral1_carry__0_n_7\,
      O => \integral0_carry__4_i_4_n_0\
    );
\integral0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__4_n_0\,
      CO(3) => \integral0_carry__5_n_0\,
      CO(2) => \integral0_carry__5_n_1\,
      CO(1) => \integral0_carry__5_n_2\,
      CO(0) => \integral0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => integral_in(27 downto 24),
      O(3 downto 0) => integral0(27 downto 24),
      S(3) => \integral0_carry__5_i_1_n_0\,
      S(2) => \integral0_carry__5_i_2_n_0\,
      S(1) => \integral0_carry__5_i_3_n_0\,
      S(0) => \integral0_carry__5_i_4_n_0\
    );
\integral0_carry__5_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(27),
      I1 => \integral1_carry__1_n_4\,
      O => \integral0_carry__5_i_1_n_0\
    );
\integral0_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(26),
      I1 => \integral1_carry__1_n_5\,
      O => \integral0_carry__5_i_2_n_0\
    );
\integral0_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(25),
      I1 => \integral1_carry__1_n_6\,
      O => \integral0_carry__5_i_3_n_0\
    );
\integral0_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(24),
      I1 => \integral1_carry__1_n_7\,
      O => \integral0_carry__5_i_4_n_0\
    );
\integral0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral0_carry__5_n_0\,
      CO(3) => \NLW_integral0_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \integral0_carry__6_n_1\,
      CO(1) => \integral0_carry__6_n_2\,
      CO(0) => \integral0_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => integral_in(30 downto 28),
      O(3 downto 0) => integral0(31 downto 28),
      S(3) => \integral0_carry__6_i_1_n_0\,
      S(2) => \integral0_carry__6_i_2_n_0\,
      S(1) => \integral0_carry__6_i_3_n_0\,
      S(0) => \integral0_carry__6_i_4_n_0\
    );
\integral0_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(31),
      I1 => \integral1_carry__2_n_4\,
      O => \integral0_carry__6_i_1_n_0\
    );
\integral0_carry__6_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(30),
      I1 => \integral1_carry__2_n_5\,
      O => \integral0_carry__6_i_2_n_0\
    );
\integral0_carry__6_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(29),
      I1 => \integral1_carry__2_n_6\,
      O => \integral0_carry__6_i_3_n_0\
    );
\integral0_carry__6_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(28),
      I1 => \integral1_carry__2_n_7\,
      O => \integral0_carry__6_i_4_n_0\
    );
integral0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(3),
      I1 => \integral1__0_n_102\,
      O => integral0_carry_i_1_n_0
    );
integral0_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(2),
      I1 => \integral1__0_n_103\,
      O => integral0_carry_i_2_n_0
    );
integral0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(1),
      I1 => \integral1__0_n_104\,
      O => integral0_carry_i_3_n_0
    );
integral0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => integral_in(0),
      I1 => \integral1__0_n_105\,
      O => integral0_carry_i_4_n_0
    );
integral1: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => dt(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_integral1_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 15) => B"000",
      B(14 downto 0) => error02_out(31 downto 17),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_integral1_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_integral1_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_integral1_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_integral1_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_integral1_OVERFLOW_UNCONNECTED,
      P(47) => integral1_n_58,
      P(46) => integral1_n_59,
      P(45) => integral1_n_60,
      P(44) => integral1_n_61,
      P(43) => integral1_n_62,
      P(42) => integral1_n_63,
      P(41) => integral1_n_64,
      P(40) => integral1_n_65,
      P(39) => integral1_n_66,
      P(38) => integral1_n_67,
      P(37) => integral1_n_68,
      P(36) => integral1_n_69,
      P(35) => integral1_n_70,
      P(34) => integral1_n_71,
      P(33) => integral1_n_72,
      P(32) => integral1_n_73,
      P(31) => integral1_n_74,
      P(30) => integral1_n_75,
      P(29) => integral1_n_76,
      P(28) => integral1_n_77,
      P(27) => integral1_n_78,
      P(26) => integral1_n_79,
      P(25) => integral1_n_80,
      P(24) => integral1_n_81,
      P(23) => integral1_n_82,
      P(22) => integral1_n_83,
      P(21) => integral1_n_84,
      P(20) => integral1_n_85,
      P(19) => integral1_n_86,
      P(18) => integral1_n_87,
      P(17) => integral1_n_88,
      P(16) => integral1_n_89,
      P(15) => integral1_n_90,
      P(14) => integral1_n_91,
      P(13) => integral1_n_92,
      P(12) => integral1_n_93,
      P(11) => integral1_n_94,
      P(10) => integral1_n_95,
      P(9) => integral1_n_96,
      P(8) => integral1_n_97,
      P(7) => integral1_n_98,
      P(6) => integral1_n_99,
      P(5) => integral1_n_100,
      P(4) => integral1_n_101,
      P(3) => integral1_n_102,
      P(2) => integral1_n_103,
      P(1) => integral1_n_104,
      P(0) => integral1_n_105,
      PATTERNBDETECT => NLW_integral1_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_integral1_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => integral1_n_106,
      PCOUT(46) => integral1_n_107,
      PCOUT(45) => integral1_n_108,
      PCOUT(44) => integral1_n_109,
      PCOUT(43) => integral1_n_110,
      PCOUT(42) => integral1_n_111,
      PCOUT(41) => integral1_n_112,
      PCOUT(40) => integral1_n_113,
      PCOUT(39) => integral1_n_114,
      PCOUT(38) => integral1_n_115,
      PCOUT(37) => integral1_n_116,
      PCOUT(36) => integral1_n_117,
      PCOUT(35) => integral1_n_118,
      PCOUT(34) => integral1_n_119,
      PCOUT(33) => integral1_n_120,
      PCOUT(32) => integral1_n_121,
      PCOUT(31) => integral1_n_122,
      PCOUT(30) => integral1_n_123,
      PCOUT(29) => integral1_n_124,
      PCOUT(28) => integral1_n_125,
      PCOUT(27) => integral1_n_126,
      PCOUT(26) => integral1_n_127,
      PCOUT(25) => integral1_n_128,
      PCOUT(24) => integral1_n_129,
      PCOUT(23) => integral1_n_130,
      PCOUT(22) => integral1_n_131,
      PCOUT(21) => integral1_n_132,
      PCOUT(20) => integral1_n_133,
      PCOUT(19) => integral1_n_134,
      PCOUT(18) => integral1_n_135,
      PCOUT(17) => integral1_n_136,
      PCOUT(16) => integral1_n_137,
      PCOUT(15) => integral1_n_138,
      PCOUT(14) => integral1_n_139,
      PCOUT(13) => integral1_n_140,
      PCOUT(12) => integral1_n_141,
      PCOUT(11) => integral1_n_142,
      PCOUT(10) => integral1_n_143,
      PCOUT(9) => integral1_n_144,
      PCOUT(8) => integral1_n_145,
      PCOUT(7) => integral1_n_146,
      PCOUT(6) => integral1_n_147,
      PCOUT(5) => integral1_n_148,
      PCOUT(4) => integral1_n_149,
      PCOUT(3) => integral1_n_150,
      PCOUT(2) => integral1_n_151,
      PCOUT(1) => integral1_n_152,
      PCOUT(0) => integral1_n_153,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_integral1_UNDERFLOW_UNCONNECTED
    );
\integral1__0\: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => error02_out(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => \NLW_integral1__0_ACOUT_UNCONNECTED\(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17) => '0',
      B(16 downto 0) => dt(16 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => \NLW_integral1__0_BCOUT_UNCONNECTED\(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => \NLW_integral1__0_CARRYCASCOUT_UNCONNECTED\,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => \NLW_integral1__0_CARRYOUT_UNCONNECTED\(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => \NLW_integral1__0_MULTSIGNOUT_UNCONNECTED\,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => \NLW_integral1__0_OVERFLOW_UNCONNECTED\,
      P(47) => \integral1__0_n_58\,
      P(46) => \integral1__0_n_59\,
      P(45) => \integral1__0_n_60\,
      P(44) => \integral1__0_n_61\,
      P(43) => \integral1__0_n_62\,
      P(42) => \integral1__0_n_63\,
      P(41) => \integral1__0_n_64\,
      P(40) => \integral1__0_n_65\,
      P(39) => \integral1__0_n_66\,
      P(38) => \integral1__0_n_67\,
      P(37) => \integral1__0_n_68\,
      P(36) => \integral1__0_n_69\,
      P(35) => \integral1__0_n_70\,
      P(34) => \integral1__0_n_71\,
      P(33) => \integral1__0_n_72\,
      P(32) => \integral1__0_n_73\,
      P(31) => \integral1__0_n_74\,
      P(30) => \integral1__0_n_75\,
      P(29) => \integral1__0_n_76\,
      P(28) => \integral1__0_n_77\,
      P(27) => \integral1__0_n_78\,
      P(26) => \integral1__0_n_79\,
      P(25) => \integral1__0_n_80\,
      P(24) => \integral1__0_n_81\,
      P(23) => \integral1__0_n_82\,
      P(22) => \integral1__0_n_83\,
      P(21) => \integral1__0_n_84\,
      P(20) => \integral1__0_n_85\,
      P(19) => \integral1__0_n_86\,
      P(18) => \integral1__0_n_87\,
      P(17) => \integral1__0_n_88\,
      P(16) => \integral1__0_n_89\,
      P(15) => \integral1__0_n_90\,
      P(14) => \integral1__0_n_91\,
      P(13) => \integral1__0_n_92\,
      P(12) => \integral1__0_n_93\,
      P(11) => \integral1__0_n_94\,
      P(10) => \integral1__0_n_95\,
      P(9) => \integral1__0_n_96\,
      P(8) => \integral1__0_n_97\,
      P(7) => \integral1__0_n_98\,
      P(6) => \integral1__0_n_99\,
      P(5) => \integral1__0_n_100\,
      P(4) => \integral1__0_n_101\,
      P(3) => \integral1__0_n_102\,
      P(2) => \integral1__0_n_103\,
      P(1) => \integral1__0_n_104\,
      P(0) => \integral1__0_n_105\,
      PATTERNBDETECT => \NLW_integral1__0_PATTERNBDETECT_UNCONNECTED\,
      PATTERNDETECT => \NLW_integral1__0_PATTERNDETECT_UNCONNECTED\,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47) => \integral1__0_n_106\,
      PCOUT(46) => \integral1__0_n_107\,
      PCOUT(45) => \integral1__0_n_108\,
      PCOUT(44) => \integral1__0_n_109\,
      PCOUT(43) => \integral1__0_n_110\,
      PCOUT(42) => \integral1__0_n_111\,
      PCOUT(41) => \integral1__0_n_112\,
      PCOUT(40) => \integral1__0_n_113\,
      PCOUT(39) => \integral1__0_n_114\,
      PCOUT(38) => \integral1__0_n_115\,
      PCOUT(37) => \integral1__0_n_116\,
      PCOUT(36) => \integral1__0_n_117\,
      PCOUT(35) => \integral1__0_n_118\,
      PCOUT(34) => \integral1__0_n_119\,
      PCOUT(33) => \integral1__0_n_120\,
      PCOUT(32) => \integral1__0_n_121\,
      PCOUT(31) => \integral1__0_n_122\,
      PCOUT(30) => \integral1__0_n_123\,
      PCOUT(29) => \integral1__0_n_124\,
      PCOUT(28) => \integral1__0_n_125\,
      PCOUT(27) => \integral1__0_n_126\,
      PCOUT(26) => \integral1__0_n_127\,
      PCOUT(25) => \integral1__0_n_128\,
      PCOUT(24) => \integral1__0_n_129\,
      PCOUT(23) => \integral1__0_n_130\,
      PCOUT(22) => \integral1__0_n_131\,
      PCOUT(21) => \integral1__0_n_132\,
      PCOUT(20) => \integral1__0_n_133\,
      PCOUT(19) => \integral1__0_n_134\,
      PCOUT(18) => \integral1__0_n_135\,
      PCOUT(17) => \integral1__0_n_136\,
      PCOUT(16) => \integral1__0_n_137\,
      PCOUT(15) => \integral1__0_n_138\,
      PCOUT(14) => \integral1__0_n_139\,
      PCOUT(13) => \integral1__0_n_140\,
      PCOUT(12) => \integral1__0_n_141\,
      PCOUT(11) => \integral1__0_n_142\,
      PCOUT(10) => \integral1__0_n_143\,
      PCOUT(9) => \integral1__0_n_144\,
      PCOUT(8) => \integral1__0_n_145\,
      PCOUT(7) => \integral1__0_n_146\,
      PCOUT(6) => \integral1__0_n_147\,
      PCOUT(5) => \integral1__0_n_148\,
      PCOUT(4) => \integral1__0_n_149\,
      PCOUT(3) => \integral1__0_n_150\,
      PCOUT(2) => \integral1__0_n_151\,
      PCOUT(1) => \integral1__0_n_152\,
      PCOUT(0) => \integral1__0_n_153\,
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => \NLW_integral1__0_UNDERFLOW_UNCONNECTED\
    );
\integral1__1\: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 17) => B"0000000000000",
      A(16 downto 0) => error02_out(16 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => \NLW_integral1__1_ACOUT_UNCONNECTED\(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 15) => B"000",
      B(14 downto 0) => dt(31 downto 17),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => \NLW_integral1__1_BCOUT_UNCONNECTED\(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => \NLW_integral1__1_CARRYCASCOUT_UNCONNECTED\,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => \NLW_integral1__1_CARRYOUT_UNCONNECTED\(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => \NLW_integral1__1_MULTSIGNOUT_UNCONNECTED\,
      OPMODE(6 downto 0) => B"1010101",
      OVERFLOW => \NLW_integral1__1_OVERFLOW_UNCONNECTED\,
      P(47) => \integral1__1_n_58\,
      P(46) => \integral1__1_n_59\,
      P(45) => \integral1__1_n_60\,
      P(44) => \integral1__1_n_61\,
      P(43) => \integral1__1_n_62\,
      P(42) => \integral1__1_n_63\,
      P(41) => \integral1__1_n_64\,
      P(40) => \integral1__1_n_65\,
      P(39) => \integral1__1_n_66\,
      P(38) => \integral1__1_n_67\,
      P(37) => \integral1__1_n_68\,
      P(36) => \integral1__1_n_69\,
      P(35) => \integral1__1_n_70\,
      P(34) => \integral1__1_n_71\,
      P(33) => \integral1__1_n_72\,
      P(32) => \integral1__1_n_73\,
      P(31) => \integral1__1_n_74\,
      P(30) => \integral1__1_n_75\,
      P(29) => \integral1__1_n_76\,
      P(28) => \integral1__1_n_77\,
      P(27) => \integral1__1_n_78\,
      P(26) => \integral1__1_n_79\,
      P(25) => \integral1__1_n_80\,
      P(24) => \integral1__1_n_81\,
      P(23) => \integral1__1_n_82\,
      P(22) => \integral1__1_n_83\,
      P(21) => \integral1__1_n_84\,
      P(20) => \integral1__1_n_85\,
      P(19) => \integral1__1_n_86\,
      P(18) => \integral1__1_n_87\,
      P(17) => \integral1__1_n_88\,
      P(16) => \integral1__1_n_89\,
      P(15) => \integral1__1_n_90\,
      P(14) => \integral1__1_n_91\,
      P(13) => \integral1__1_n_92\,
      P(12) => \integral1__1_n_93\,
      P(11) => \integral1__1_n_94\,
      P(10) => \integral1__1_n_95\,
      P(9) => \integral1__1_n_96\,
      P(8) => \integral1__1_n_97\,
      P(7) => \integral1__1_n_98\,
      P(6) => \integral1__1_n_99\,
      P(5) => \integral1__1_n_100\,
      P(4) => \integral1__1_n_101\,
      P(3) => \integral1__1_n_102\,
      P(2) => \integral1__1_n_103\,
      P(1) => \integral1__1_n_104\,
      P(0) => \integral1__1_n_105\,
      PATTERNBDETECT => \NLW_integral1__1_PATTERNBDETECT_UNCONNECTED\,
      PATTERNDETECT => \NLW_integral1__1_PATTERNDETECT_UNCONNECTED\,
      PCIN(47) => \integral1__0_n_106\,
      PCIN(46) => \integral1__0_n_107\,
      PCIN(45) => \integral1__0_n_108\,
      PCIN(44) => \integral1__0_n_109\,
      PCIN(43) => \integral1__0_n_110\,
      PCIN(42) => \integral1__0_n_111\,
      PCIN(41) => \integral1__0_n_112\,
      PCIN(40) => \integral1__0_n_113\,
      PCIN(39) => \integral1__0_n_114\,
      PCIN(38) => \integral1__0_n_115\,
      PCIN(37) => \integral1__0_n_116\,
      PCIN(36) => \integral1__0_n_117\,
      PCIN(35) => \integral1__0_n_118\,
      PCIN(34) => \integral1__0_n_119\,
      PCIN(33) => \integral1__0_n_120\,
      PCIN(32) => \integral1__0_n_121\,
      PCIN(31) => \integral1__0_n_122\,
      PCIN(30) => \integral1__0_n_123\,
      PCIN(29) => \integral1__0_n_124\,
      PCIN(28) => \integral1__0_n_125\,
      PCIN(27) => \integral1__0_n_126\,
      PCIN(26) => \integral1__0_n_127\,
      PCIN(25) => \integral1__0_n_128\,
      PCIN(24) => \integral1__0_n_129\,
      PCIN(23) => \integral1__0_n_130\,
      PCIN(22) => \integral1__0_n_131\,
      PCIN(21) => \integral1__0_n_132\,
      PCIN(20) => \integral1__0_n_133\,
      PCIN(19) => \integral1__0_n_134\,
      PCIN(18) => \integral1__0_n_135\,
      PCIN(17) => \integral1__0_n_136\,
      PCIN(16) => \integral1__0_n_137\,
      PCIN(15) => \integral1__0_n_138\,
      PCIN(14) => \integral1__0_n_139\,
      PCIN(13) => \integral1__0_n_140\,
      PCIN(12) => \integral1__0_n_141\,
      PCIN(11) => \integral1__0_n_142\,
      PCIN(10) => \integral1__0_n_143\,
      PCIN(9) => \integral1__0_n_144\,
      PCIN(8) => \integral1__0_n_145\,
      PCIN(7) => \integral1__0_n_146\,
      PCIN(6) => \integral1__0_n_147\,
      PCIN(5) => \integral1__0_n_148\,
      PCIN(4) => \integral1__0_n_149\,
      PCIN(3) => \integral1__0_n_150\,
      PCIN(2) => \integral1__0_n_151\,
      PCIN(1) => \integral1__0_n_152\,
      PCIN(0) => \integral1__0_n_153\,
      PCOUT(47 downto 0) => \NLW_integral1__1_PCOUT_UNCONNECTED\(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => \NLW_integral1__1_UNDERFLOW_UNCONNECTED\
    );
integral1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => integral1_carry_n_0,
      CO(2) => integral1_carry_n_1,
      CO(1) => integral1_carry_n_2,
      CO(0) => integral1_carry_n_3,
      CYINIT => '0',
      DI(3) => \integral1__1_n_103\,
      DI(2) => \integral1__1_n_104\,
      DI(1) => \integral1__1_n_105\,
      DI(0) => '0',
      O(3) => integral1_carry_n_4,
      O(2) => integral1_carry_n_5,
      O(1) => integral1_carry_n_6,
      O(0) => integral1_carry_n_7,
      S(3) => integral1_carry_i_1_n_0,
      S(2) => integral1_carry_i_2_n_0,
      S(1) => integral1_carry_i_3_n_0,
      S(0) => \integral1__0_n_89\
    );
\integral1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => integral1_carry_n_0,
      CO(3) => \integral1_carry__0_n_0\,
      CO(2) => \integral1_carry__0_n_1\,
      CO(1) => \integral1_carry__0_n_2\,
      CO(0) => \integral1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \integral1__1_n_99\,
      DI(2) => \integral1__1_n_100\,
      DI(1) => \integral1__1_n_101\,
      DI(0) => \integral1__1_n_102\,
      O(3) => \integral1_carry__0_n_4\,
      O(2) => \integral1_carry__0_n_5\,
      O(1) => \integral1_carry__0_n_6\,
      O(0) => \integral1_carry__0_n_7\,
      S(3) => \integral1_carry__0_i_1_n_0\,
      S(2) => \integral1_carry__0_i_2_n_0\,
      S(1) => \integral1_carry__0_i_3_n_0\,
      S(0) => \integral1_carry__0_i_4_n_0\
    );
\integral1_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_99\,
      I1 => integral1_n_99,
      O => \integral1_carry__0_i_1_n_0\
    );
\integral1_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_100\,
      I1 => integral1_n_100,
      O => \integral1_carry__0_i_2_n_0\
    );
\integral1_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_101\,
      I1 => integral1_n_101,
      O => \integral1_carry__0_i_3_n_0\
    );
\integral1_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_102\,
      I1 => integral1_n_102,
      O => \integral1_carry__0_i_4_n_0\
    );
\integral1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral1_carry__0_n_0\,
      CO(3) => \integral1_carry__1_n_0\,
      CO(2) => \integral1_carry__1_n_1\,
      CO(1) => \integral1_carry__1_n_2\,
      CO(0) => \integral1_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \integral1__1_n_95\,
      DI(2) => \integral1__1_n_96\,
      DI(1) => \integral1__1_n_97\,
      DI(0) => \integral1__1_n_98\,
      O(3) => \integral1_carry__1_n_4\,
      O(2) => \integral1_carry__1_n_5\,
      O(1) => \integral1_carry__1_n_6\,
      O(0) => \integral1_carry__1_n_7\,
      S(3) => \integral1_carry__1_i_1_n_0\,
      S(2) => \integral1_carry__1_i_2_n_0\,
      S(1) => \integral1_carry__1_i_3_n_0\,
      S(0) => \integral1_carry__1_i_4_n_0\
    );
\integral1_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_95\,
      I1 => integral1_n_95,
      O => \integral1_carry__1_i_1_n_0\
    );
\integral1_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_96\,
      I1 => integral1_n_96,
      O => \integral1_carry__1_i_2_n_0\
    );
\integral1_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_97\,
      I1 => integral1_n_97,
      O => \integral1_carry__1_i_3_n_0\
    );
\integral1_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_98\,
      I1 => integral1_n_98,
      O => \integral1_carry__1_i_4_n_0\
    );
\integral1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \integral1_carry__1_n_0\,
      CO(3) => \NLW_integral1_carry__2_CO_UNCONNECTED\(3),
      CO(2) => \integral1_carry__2_n_1\,
      CO(1) => \integral1_carry__2_n_2\,
      CO(0) => \integral1_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \integral1__1_n_92\,
      DI(1) => \integral1__1_n_93\,
      DI(0) => \integral1__1_n_94\,
      O(3) => \integral1_carry__2_n_4\,
      O(2) => \integral1_carry__2_n_5\,
      O(1) => \integral1_carry__2_n_6\,
      O(0) => \integral1_carry__2_n_7\,
      S(3) => \integral1_carry__2_i_1_n_0\,
      S(2) => \integral1_carry__2_i_2_n_0\,
      S(1) => \integral1_carry__2_i_3_n_0\,
      S(0) => \integral1_carry__2_i_4_n_0\
    );
\integral1_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_91\,
      I1 => integral1_n_91,
      O => \integral1_carry__2_i_1_n_0\
    );
\integral1_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_92\,
      I1 => integral1_n_92,
      O => \integral1_carry__2_i_2_n_0\
    );
\integral1_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_93\,
      I1 => integral1_n_93,
      O => \integral1_carry__2_i_3_n_0\
    );
\integral1_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_94\,
      I1 => integral1_n_94,
      O => \integral1_carry__2_i_4_n_0\
    );
integral1_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_103\,
      I1 => integral1_n_103,
      O => integral1_carry_i_1_n_0
    );
integral1_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_104\,
      I1 => integral1_n_104,
      O => integral1_carry_i_2_n_0
    );
integral1_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \integral1__1_n_105\,
      I1 => integral1_n_105,
      O => integral1_carry_i_3_n_0
    );
\integral_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(0),
      Q => integral_out(0),
      R => new_target_velocity_available(0)
    );
\integral_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(10),
      Q => integral_out(10),
      R => new_target_velocity_available(0)
    );
\integral_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(11),
      Q => integral_out(11),
      R => new_target_velocity_available(0)
    );
\integral_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(12),
      Q => integral_out(12),
      R => new_target_velocity_available(0)
    );
\integral_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(13),
      Q => integral_out(13),
      R => new_target_velocity_available(0)
    );
\integral_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(14),
      Q => integral_out(14),
      R => new_target_velocity_available(0)
    );
\integral_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(15),
      Q => integral_out(15),
      R => new_target_velocity_available(0)
    );
\integral_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(16),
      Q => integral_out(16),
      R => new_target_velocity_available(0)
    );
\integral_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(17),
      Q => integral_out(17),
      R => new_target_velocity_available(0)
    );
\integral_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(18),
      Q => integral_out(18),
      R => new_target_velocity_available(0)
    );
\integral_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(19),
      Q => integral_out(19),
      R => new_target_velocity_available(0)
    );
\integral_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(1),
      Q => integral_out(1),
      R => new_target_velocity_available(0)
    );
\integral_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(20),
      Q => integral_out(20),
      R => new_target_velocity_available(0)
    );
\integral_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(21),
      Q => integral_out(21),
      R => new_target_velocity_available(0)
    );
\integral_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(22),
      Q => integral_out(22),
      R => new_target_velocity_available(0)
    );
\integral_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(23),
      Q => integral_out(23),
      R => new_target_velocity_available(0)
    );
\integral_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(24),
      Q => integral_out(24),
      R => new_target_velocity_available(0)
    );
\integral_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(25),
      Q => integral_out(25),
      R => new_target_velocity_available(0)
    );
\integral_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(26),
      Q => integral_out(26),
      R => new_target_velocity_available(0)
    );
\integral_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(27),
      Q => integral_out(27),
      R => new_target_velocity_available(0)
    );
\integral_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(28),
      Q => integral_out(28),
      R => new_target_velocity_available(0)
    );
\integral_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(29),
      Q => integral_out(29),
      R => new_target_velocity_available(0)
    );
\integral_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(2),
      Q => integral_out(2),
      R => new_target_velocity_available(0)
    );
\integral_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(30),
      Q => integral_out(30),
      R => new_target_velocity_available(0)
    );
\integral_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(31),
      Q => integral_out(31),
      R => new_target_velocity_available(0)
    );
\integral_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(3),
      Q => integral_out(3),
      R => new_target_velocity_available(0)
    );
\integral_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(4),
      Q => integral_out(4),
      R => new_target_velocity_available(0)
    );
\integral_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(5),
      Q => integral_out(5),
      R => new_target_velocity_available(0)
    );
\integral_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(6),
      Q => integral_out(6),
      R => new_target_velocity_available(0)
    );
\integral_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(7),
      Q => integral_out(7),
      R => new_target_velocity_available(0)
    );
\integral_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(8),
      Q => integral_out(8),
      R => new_target_velocity_available(0)
    );
\integral_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => new_angle_available(0),
      CE => '1',
      D => integral0(9),
      Q => integral_out(9),
      R => new_target_velocity_available(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    new_angle_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    new_target_velocity_available : in STD_LOGIC_VECTOR ( 0 to 0 );
    target_velocity : in STD_LOGIC_VECTOR ( 31 downto 0 );
    velocity_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    dt : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative_out : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_initial_math_0_0,initial_math,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "initial_math,Vivado 2021.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math
     port map (
      derivative_out(31 downto 0) => derivative_out(31 downto 0),
      dt(31 downto 0) => dt(31 downto 0),
      error_in(31 downto 0) => error_in(31 downto 0),
      error_out(31 downto 0) => error_out(31 downto 0),
      integral_in(31 downto 0) => integral_in(31 downto 0),
      integral_out(31 downto 0) => integral_out(31 downto 0),
      new_angle_available(0) => new_angle_available(0),
      new_target_velocity_available(0) => new_target_velocity_available(0),
      target_velocity(31 downto 0) => target_velocity(31 downto 0),
      velocity_in(31 downto 0) => velocity_in(31 downto 0)
    );
end STRUCTURE;
