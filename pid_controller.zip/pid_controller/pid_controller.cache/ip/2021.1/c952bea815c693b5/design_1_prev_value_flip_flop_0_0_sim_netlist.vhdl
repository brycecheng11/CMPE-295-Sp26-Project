-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Fri Sep  4 02:48:14 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_prev_value_flip_flop_0_0_sim_netlist.vhdl
-- Design      : design_1_prev_value_flip_flop_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop is
  port (
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    time_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    time_in : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop is
begin
\error_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(0),
      Q => error_out(0),
      R => '0'
    );
\error_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(10),
      Q => error_out(10),
      R => '0'
    );
\error_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(11),
      Q => error_out(11),
      R => '0'
    );
\error_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(12),
      Q => error_out(12),
      R => '0'
    );
\error_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(13),
      Q => error_out(13),
      R => '0'
    );
\error_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(14),
      Q => error_out(14),
      R => '0'
    );
\error_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(15),
      Q => error_out(15),
      R => '0'
    );
\error_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(16),
      Q => error_out(16),
      R => '0'
    );
\error_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(17),
      Q => error_out(17),
      R => '0'
    );
\error_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(18),
      Q => error_out(18),
      R => '0'
    );
\error_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(19),
      Q => error_out(19),
      R => '0'
    );
\error_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(1),
      Q => error_out(1),
      R => '0'
    );
\error_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(20),
      Q => error_out(20),
      R => '0'
    );
\error_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(21),
      Q => error_out(21),
      R => '0'
    );
\error_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(22),
      Q => error_out(22),
      R => '0'
    );
\error_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(23),
      Q => error_out(23),
      R => '0'
    );
\error_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(24),
      Q => error_out(24),
      R => '0'
    );
\error_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(25),
      Q => error_out(25),
      R => '0'
    );
\error_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(26),
      Q => error_out(26),
      R => '0'
    );
\error_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(27),
      Q => error_out(27),
      R => '0'
    );
\error_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(28),
      Q => error_out(28),
      R => '0'
    );
\error_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(29),
      Q => error_out(29),
      R => '0'
    );
\error_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(2),
      Q => error_out(2),
      R => '0'
    );
\error_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(30),
      Q => error_out(30),
      R => '0'
    );
\error_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(31),
      Q => error_out(31),
      R => '0'
    );
\error_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(3),
      Q => error_out(3),
      R => '0'
    );
\error_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(4),
      Q => error_out(4),
      R => '0'
    );
\error_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(5),
      Q => error_out(5),
      R => '0'
    );
\error_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(6),
      Q => error_out(6),
      R => '0'
    );
\error_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(7),
      Q => error_out(7),
      R => '0'
    );
\error_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(8),
      Q => error_out(8),
      R => '0'
    );
\error_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => error_in(9),
      Q => error_out(9),
      R => '0'
    );
\integral_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(0),
      Q => integral_out(0),
      R => '0'
    );
\integral_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(10),
      Q => integral_out(10),
      R => '0'
    );
\integral_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(11),
      Q => integral_out(11),
      R => '0'
    );
\integral_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(12),
      Q => integral_out(12),
      R => '0'
    );
\integral_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(13),
      Q => integral_out(13),
      R => '0'
    );
\integral_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(14),
      Q => integral_out(14),
      R => '0'
    );
\integral_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(15),
      Q => integral_out(15),
      R => '0'
    );
\integral_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(16),
      Q => integral_out(16),
      R => '0'
    );
\integral_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(17),
      Q => integral_out(17),
      R => '0'
    );
\integral_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(18),
      Q => integral_out(18),
      R => '0'
    );
\integral_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(19),
      Q => integral_out(19),
      R => '0'
    );
\integral_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(1),
      Q => integral_out(1),
      R => '0'
    );
\integral_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(20),
      Q => integral_out(20),
      R => '0'
    );
\integral_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(21),
      Q => integral_out(21),
      R => '0'
    );
\integral_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(22),
      Q => integral_out(22),
      R => '0'
    );
\integral_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(23),
      Q => integral_out(23),
      R => '0'
    );
\integral_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(24),
      Q => integral_out(24),
      R => '0'
    );
\integral_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(25),
      Q => integral_out(25),
      R => '0'
    );
\integral_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(26),
      Q => integral_out(26),
      R => '0'
    );
\integral_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(27),
      Q => integral_out(27),
      R => '0'
    );
\integral_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(28),
      Q => integral_out(28),
      R => '0'
    );
\integral_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(29),
      Q => integral_out(29),
      R => '0'
    );
\integral_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(2),
      Q => integral_out(2),
      R => '0'
    );
\integral_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(30),
      Q => integral_out(30),
      R => '0'
    );
\integral_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(31),
      Q => integral_out(31),
      R => '0'
    );
\integral_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(3),
      Q => integral_out(3),
      R => '0'
    );
\integral_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(4),
      Q => integral_out(4),
      R => '0'
    );
\integral_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(5),
      Q => integral_out(5),
      R => '0'
    );
\integral_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(6),
      Q => integral_out(6),
      R => '0'
    );
\integral_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(7),
      Q => integral_out(7),
      R => '0'
    );
\integral_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(8),
      Q => integral_out(8),
      R => '0'
    );
\integral_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => integral_in(9),
      Q => integral_out(9),
      R => '0'
    );
\time_interim_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(0),
      Q => time_out(0),
      R => '0'
    );
\time_interim_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(10),
      Q => time_out(10),
      R => '0'
    );
\time_interim_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(11),
      Q => time_out(11),
      R => '0'
    );
\time_interim_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(12),
      Q => time_out(12),
      R => '0'
    );
\time_interim_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(13),
      Q => time_out(13),
      R => '0'
    );
\time_interim_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(14),
      Q => time_out(14),
      R => '0'
    );
\time_interim_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(15),
      Q => time_out(15),
      R => '0'
    );
\time_interim_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(16),
      Q => time_out(16),
      R => '0'
    );
\time_interim_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(17),
      Q => time_out(17),
      R => '0'
    );
\time_interim_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(18),
      Q => time_out(18),
      R => '0'
    );
\time_interim_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(19),
      Q => time_out(19),
      R => '0'
    );
\time_interim_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(1),
      Q => time_out(1),
      R => '0'
    );
\time_interim_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(20),
      Q => time_out(20),
      R => '0'
    );
\time_interim_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(21),
      Q => time_out(21),
      R => '0'
    );
\time_interim_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(22),
      Q => time_out(22),
      R => '0'
    );
\time_interim_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(23),
      Q => time_out(23),
      R => '0'
    );
\time_interim_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(24),
      Q => time_out(24),
      R => '0'
    );
\time_interim_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(25),
      Q => time_out(25),
      R => '0'
    );
\time_interim_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(26),
      Q => time_out(26),
      R => '0'
    );
\time_interim_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(27),
      Q => time_out(27),
      R => '0'
    );
\time_interim_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(28),
      Q => time_out(28),
      R => '0'
    );
\time_interim_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(29),
      Q => time_out(29),
      R => '0'
    );
\time_interim_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(2),
      Q => time_out(2),
      R => '0'
    );
\time_interim_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(30),
      Q => time_out(30),
      R => '0'
    );
\time_interim_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(31),
      Q => time_out(31),
      R => '0'
    );
\time_interim_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(3),
      Q => time_out(3),
      R => '0'
    );
\time_interim_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(4),
      Q => time_out(4),
      R => '0'
    );
\time_interim_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(5),
      Q => time_out(5),
      R => '0'
    );
\time_interim_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(6),
      Q => time_out(6),
      R => '0'
    );
\time_interim_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(7),
      Q => time_out(7),
      R => '0'
    );
\time_interim_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(8),
      Q => time_out(8),
      R => '0'
    );
\time_interim_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clock(0),
      CE => '1',
      D => time_in(9),
      Q => time_out(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    time_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    time_out : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_prev_value_flip_flop_0_0,prev_value_flip_flop,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "prev_value_flip_flop,Vivado 2021.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clock : signal is "xilinx.com:signal:clock:1.0 clock CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clock : signal is "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop
     port map (
      clock(0) => clock(0),
      error_in(31 downto 0) => error_in(31 downto 0),
      error_out(31 downto 0) => error_out(31 downto 0),
      integral_in(31 downto 0) => integral_in(31 downto 0),
      integral_out(31 downto 0) => integral_out(31 downto 0),
      time_in(31 downto 0) => time_in(31 downto 0),
      time_out(31 downto 0) => time_out(31 downto 0)
    );
end STRUCTURE;
