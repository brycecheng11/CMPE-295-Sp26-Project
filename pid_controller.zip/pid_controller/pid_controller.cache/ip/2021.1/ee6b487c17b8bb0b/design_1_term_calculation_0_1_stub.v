// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep 21 22:23:07 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_term_calculation_0_1_stub.v
// Design      : design_1_term_calculation_0_1
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "term_calculation,Vivado 2021.1" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clock, error, integral, derivative, kp, ki, kd, p_term, 
  i_term, d_term)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],error[31:0],integral[31:0],derivative[31:0],kp[8:0],ki[8:0],kd[8:0],p_term[31:0],i_term[31:0],d_term[31:0]" */;
  input [0:0]clock;
  input [31:0]error;
  input [31:0]integral;
  input [31:0]derivative;
  input [8:0]kp;
  input [8:0]ki;
  input [8:0]kd;
  output [31:0]p_term;
  output [31:0]i_term;
  output [31:0]d_term;
endmodule
