// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Wed Sep 16 20:56:18 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_prev_value_flip_flop_0_0_stub.v
// Design      : design_1_prev_value_flip_flop_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "prev_value_flip_flop,Vivado 2021.1" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clock, error_in, integral_in, time_in, error_out, 
  integral_out, time_out)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],error_in[31:0],integral_in[31:0],time_in[63:0],error_out[31:0],integral_out[31:0],time_out[63:0]" */;
  input [0:0]clock;
  input [31:0]error_in;
  input [31:0]integral_in;
  input [63:0]time_in;
  output [31:0]error_out;
  output [31:0]integral_out;
  output [63:0]time_out;
endmodule
