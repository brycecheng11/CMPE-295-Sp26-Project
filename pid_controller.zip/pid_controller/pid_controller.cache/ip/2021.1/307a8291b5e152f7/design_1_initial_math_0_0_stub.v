// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Wed Sep 16 22:17:58 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_initial_math_0_0_stub.v
// Design      : design_1_initial_math_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "initial_math,Vivado 2021.1" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clock, angle, target_angle, 
  new_target_angle_available, dt, error_in, integral_in, error_out, integral_out, 
  derivative_out)
/* synthesis syn_black_box black_box_pad_pin="clock[0:0],angle[31:0],target_angle[31:0],new_target_angle_available[0:0],dt[63:0],error_in[31:0],integral_in[31:0],error_out[31:0],integral_out[31:0],derivative_out[31:0]" */;
  input [0:0]clock;
  input [31:0]angle;
  input [31:0]target_angle;
  input [0:0]new_target_angle_available;
  input [63:0]dt;
  input [31:0]error_in;
  input [31:0]integral_in;
  output [31:0]error_out;
  output [31:0]integral_out;
  output [31:0]derivative_out;
endmodule
