// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Fri Sep  4 03:05:04 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_prev_value_flip_flop_0_0_sim_netlist.v
// Design      : design_1_prev_value_flip_flop_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_prev_value_flip_flop_0_0,prev_value_flip_flop,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "prev_value_flip_flop,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clock,
    error_in,
    integral_in,
    time_in,
    error_out,
    integral_out,
    time_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input [0:0]clock;
  input [31:0]error_in;
  input [31:0]integral_in;
  input [63:0]time_in;
  output [31:0]error_out;
  output [31:0]integral_out;
  output [63:0]time_out;

  wire [0:0]clock;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [63:0]time_in;
  wire [63:0]time_out;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop inst
       (.clock(clock),
        .error_in(error_in),
        .error_out(error_out),
        .integral_in(integral_in),
        .integral_out(integral_out),
        .time_in(time_in),
        .time_out(time_out));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_prev_value_flip_flop
   (error_out,
    integral_out,
    time_out,
    error_in,
    clock,
    integral_in,
    time_in);
  output [31:0]error_out;
  output [31:0]integral_out;
  output [63:0]time_out;
  input [31:0]error_in;
  input [0:0]clock;
  input [31:0]integral_in;
  input [63:0]time_in;

  wire [0:0]clock;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [63:0]time_in;
  wire [63:0]time_out;

  FDRE \error_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[0]),
        .Q(error_out[0]),
        .R(1'b0));
  FDRE \error_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[10]),
        .Q(error_out[10]),
        .R(1'b0));
  FDRE \error_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[11]),
        .Q(error_out[11]),
        .R(1'b0));
  FDRE \error_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[12]),
        .Q(error_out[12]),
        .R(1'b0));
  FDRE \error_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[13]),
        .Q(error_out[13]),
        .R(1'b0));
  FDRE \error_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[14]),
        .Q(error_out[14]),
        .R(1'b0));
  FDRE \error_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[15]),
        .Q(error_out[15]),
        .R(1'b0));
  FDRE \error_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[16]),
        .Q(error_out[16]),
        .R(1'b0));
  FDRE \error_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[17]),
        .Q(error_out[17]),
        .R(1'b0));
  FDRE \error_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[18]),
        .Q(error_out[18]),
        .R(1'b0));
  FDRE \error_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[19]),
        .Q(error_out[19]),
        .R(1'b0));
  FDRE \error_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[1]),
        .Q(error_out[1]),
        .R(1'b0));
  FDRE \error_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[20]),
        .Q(error_out[20]),
        .R(1'b0));
  FDRE \error_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[21]),
        .Q(error_out[21]),
        .R(1'b0));
  FDRE \error_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[22]),
        .Q(error_out[22]),
        .R(1'b0));
  FDRE \error_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[23]),
        .Q(error_out[23]),
        .R(1'b0));
  FDRE \error_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[24]),
        .Q(error_out[24]),
        .R(1'b0));
  FDRE \error_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[25]),
        .Q(error_out[25]),
        .R(1'b0));
  FDRE \error_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[26]),
        .Q(error_out[26]),
        .R(1'b0));
  FDRE \error_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[27]),
        .Q(error_out[27]),
        .R(1'b0));
  FDRE \error_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[28]),
        .Q(error_out[28]),
        .R(1'b0));
  FDRE \error_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[29]),
        .Q(error_out[29]),
        .R(1'b0));
  FDRE \error_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[2]),
        .Q(error_out[2]),
        .R(1'b0));
  FDRE \error_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[30]),
        .Q(error_out[30]),
        .R(1'b0));
  FDRE \error_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[31]),
        .Q(error_out[31]),
        .R(1'b0));
  FDRE \error_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[3]),
        .Q(error_out[3]),
        .R(1'b0));
  FDRE \error_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[4]),
        .Q(error_out[4]),
        .R(1'b0));
  FDRE \error_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[5]),
        .Q(error_out[5]),
        .R(1'b0));
  FDRE \error_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[6]),
        .Q(error_out[6]),
        .R(1'b0));
  FDRE \error_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[7]),
        .Q(error_out[7]),
        .R(1'b0));
  FDRE \error_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[8]),
        .Q(error_out[8]),
        .R(1'b0));
  FDRE \error_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(error_in[9]),
        .Q(error_out[9]),
        .R(1'b0));
  FDRE \integral_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[0]),
        .Q(integral_out[0]),
        .R(1'b0));
  FDRE \integral_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[10]),
        .Q(integral_out[10]),
        .R(1'b0));
  FDRE \integral_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[11]),
        .Q(integral_out[11]),
        .R(1'b0));
  FDRE \integral_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[12]),
        .Q(integral_out[12]),
        .R(1'b0));
  FDRE \integral_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[13]),
        .Q(integral_out[13]),
        .R(1'b0));
  FDRE \integral_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[14]),
        .Q(integral_out[14]),
        .R(1'b0));
  FDRE \integral_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[15]),
        .Q(integral_out[15]),
        .R(1'b0));
  FDRE \integral_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[16]),
        .Q(integral_out[16]),
        .R(1'b0));
  FDRE \integral_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[17]),
        .Q(integral_out[17]),
        .R(1'b0));
  FDRE \integral_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[18]),
        .Q(integral_out[18]),
        .R(1'b0));
  FDRE \integral_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[19]),
        .Q(integral_out[19]),
        .R(1'b0));
  FDRE \integral_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[1]),
        .Q(integral_out[1]),
        .R(1'b0));
  FDRE \integral_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[20]),
        .Q(integral_out[20]),
        .R(1'b0));
  FDRE \integral_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[21]),
        .Q(integral_out[21]),
        .R(1'b0));
  FDRE \integral_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[22]),
        .Q(integral_out[22]),
        .R(1'b0));
  FDRE \integral_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[23]),
        .Q(integral_out[23]),
        .R(1'b0));
  FDRE \integral_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[24]),
        .Q(integral_out[24]),
        .R(1'b0));
  FDRE \integral_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[25]),
        .Q(integral_out[25]),
        .R(1'b0));
  FDRE \integral_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[26]),
        .Q(integral_out[26]),
        .R(1'b0));
  FDRE \integral_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[27]),
        .Q(integral_out[27]),
        .R(1'b0));
  FDRE \integral_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[28]),
        .Q(integral_out[28]),
        .R(1'b0));
  FDRE \integral_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[29]),
        .Q(integral_out[29]),
        .R(1'b0));
  FDRE \integral_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[2]),
        .Q(integral_out[2]),
        .R(1'b0));
  FDRE \integral_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[30]),
        .Q(integral_out[30]),
        .R(1'b0));
  FDRE \integral_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[31]),
        .Q(integral_out[31]),
        .R(1'b0));
  FDRE \integral_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[3]),
        .Q(integral_out[3]),
        .R(1'b0));
  FDRE \integral_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[4]),
        .Q(integral_out[4]),
        .R(1'b0));
  FDRE \integral_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[5]),
        .Q(integral_out[5]),
        .R(1'b0));
  FDRE \integral_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[6]),
        .Q(integral_out[6]),
        .R(1'b0));
  FDRE \integral_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[7]),
        .Q(integral_out[7]),
        .R(1'b0));
  FDRE \integral_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[8]),
        .Q(integral_out[8]),
        .R(1'b0));
  FDRE \integral_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(integral_in[9]),
        .Q(integral_out[9]),
        .R(1'b0));
  FDRE \time_interim_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[0]),
        .Q(time_out[0]),
        .R(1'b0));
  FDRE \time_interim_reg[10] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[10]),
        .Q(time_out[10]),
        .R(1'b0));
  FDRE \time_interim_reg[11] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[11]),
        .Q(time_out[11]),
        .R(1'b0));
  FDRE \time_interim_reg[12] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[12]),
        .Q(time_out[12]),
        .R(1'b0));
  FDRE \time_interim_reg[13] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[13]),
        .Q(time_out[13]),
        .R(1'b0));
  FDRE \time_interim_reg[14] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[14]),
        .Q(time_out[14]),
        .R(1'b0));
  FDRE \time_interim_reg[15] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[15]),
        .Q(time_out[15]),
        .R(1'b0));
  FDRE \time_interim_reg[16] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[16]),
        .Q(time_out[16]),
        .R(1'b0));
  FDRE \time_interim_reg[17] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[17]),
        .Q(time_out[17]),
        .R(1'b0));
  FDRE \time_interim_reg[18] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[18]),
        .Q(time_out[18]),
        .R(1'b0));
  FDRE \time_interim_reg[19] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[19]),
        .Q(time_out[19]),
        .R(1'b0));
  FDRE \time_interim_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[1]),
        .Q(time_out[1]),
        .R(1'b0));
  FDRE \time_interim_reg[20] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[20]),
        .Q(time_out[20]),
        .R(1'b0));
  FDRE \time_interim_reg[21] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[21]),
        .Q(time_out[21]),
        .R(1'b0));
  FDRE \time_interim_reg[22] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[22]),
        .Q(time_out[22]),
        .R(1'b0));
  FDRE \time_interim_reg[23] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[23]),
        .Q(time_out[23]),
        .R(1'b0));
  FDRE \time_interim_reg[24] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[24]),
        .Q(time_out[24]),
        .R(1'b0));
  FDRE \time_interim_reg[25] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[25]),
        .Q(time_out[25]),
        .R(1'b0));
  FDRE \time_interim_reg[26] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[26]),
        .Q(time_out[26]),
        .R(1'b0));
  FDRE \time_interim_reg[27] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[27]),
        .Q(time_out[27]),
        .R(1'b0));
  FDRE \time_interim_reg[28] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[28]),
        .Q(time_out[28]),
        .R(1'b0));
  FDRE \time_interim_reg[29] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[29]),
        .Q(time_out[29]),
        .R(1'b0));
  FDRE \time_interim_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[2]),
        .Q(time_out[2]),
        .R(1'b0));
  FDRE \time_interim_reg[30] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[30]),
        .Q(time_out[30]),
        .R(1'b0));
  FDRE \time_interim_reg[31] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[31]),
        .Q(time_out[31]),
        .R(1'b0));
  FDRE \time_interim_reg[32] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[32]),
        .Q(time_out[32]),
        .R(1'b0));
  FDRE \time_interim_reg[33] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[33]),
        .Q(time_out[33]),
        .R(1'b0));
  FDRE \time_interim_reg[34] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[34]),
        .Q(time_out[34]),
        .R(1'b0));
  FDRE \time_interim_reg[35] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[35]),
        .Q(time_out[35]),
        .R(1'b0));
  FDRE \time_interim_reg[36] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[36]),
        .Q(time_out[36]),
        .R(1'b0));
  FDRE \time_interim_reg[37] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[37]),
        .Q(time_out[37]),
        .R(1'b0));
  FDRE \time_interim_reg[38] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[38]),
        .Q(time_out[38]),
        .R(1'b0));
  FDRE \time_interim_reg[39] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[39]),
        .Q(time_out[39]),
        .R(1'b0));
  FDRE \time_interim_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[3]),
        .Q(time_out[3]),
        .R(1'b0));
  FDRE \time_interim_reg[40] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[40]),
        .Q(time_out[40]),
        .R(1'b0));
  FDRE \time_interim_reg[41] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[41]),
        .Q(time_out[41]),
        .R(1'b0));
  FDRE \time_interim_reg[42] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[42]),
        .Q(time_out[42]),
        .R(1'b0));
  FDRE \time_interim_reg[43] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[43]),
        .Q(time_out[43]),
        .R(1'b0));
  FDRE \time_interim_reg[44] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[44]),
        .Q(time_out[44]),
        .R(1'b0));
  FDRE \time_interim_reg[45] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[45]),
        .Q(time_out[45]),
        .R(1'b0));
  FDRE \time_interim_reg[46] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[46]),
        .Q(time_out[46]),
        .R(1'b0));
  FDRE \time_interim_reg[47] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[47]),
        .Q(time_out[47]),
        .R(1'b0));
  FDRE \time_interim_reg[48] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[48]),
        .Q(time_out[48]),
        .R(1'b0));
  FDRE \time_interim_reg[49] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[49]),
        .Q(time_out[49]),
        .R(1'b0));
  FDRE \time_interim_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[4]),
        .Q(time_out[4]),
        .R(1'b0));
  FDRE \time_interim_reg[50] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[50]),
        .Q(time_out[50]),
        .R(1'b0));
  FDRE \time_interim_reg[51] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[51]),
        .Q(time_out[51]),
        .R(1'b0));
  FDRE \time_interim_reg[52] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[52]),
        .Q(time_out[52]),
        .R(1'b0));
  FDRE \time_interim_reg[53] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[53]),
        .Q(time_out[53]),
        .R(1'b0));
  FDRE \time_interim_reg[54] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[54]),
        .Q(time_out[54]),
        .R(1'b0));
  FDRE \time_interim_reg[55] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[55]),
        .Q(time_out[55]),
        .R(1'b0));
  FDRE \time_interim_reg[56] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[56]),
        .Q(time_out[56]),
        .R(1'b0));
  FDRE \time_interim_reg[57] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[57]),
        .Q(time_out[57]),
        .R(1'b0));
  FDRE \time_interim_reg[58] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[58]),
        .Q(time_out[58]),
        .R(1'b0));
  FDRE \time_interim_reg[59] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[59]),
        .Q(time_out[59]),
        .R(1'b0));
  FDRE \time_interim_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[5]),
        .Q(time_out[5]),
        .R(1'b0));
  FDRE \time_interim_reg[60] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[60]),
        .Q(time_out[60]),
        .R(1'b0));
  FDRE \time_interim_reg[61] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[61]),
        .Q(time_out[61]),
        .R(1'b0));
  FDRE \time_interim_reg[62] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[62]),
        .Q(time_out[62]),
        .R(1'b0));
  FDRE \time_interim_reg[63] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[63]),
        .Q(time_out[63]),
        .R(1'b0));
  FDRE \time_interim_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[6]),
        .Q(time_out[6]),
        .R(1'b0));
  FDRE \time_interim_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[7]),
        .Q(time_out[7]),
        .R(1'b0));
  FDRE \time_interim_reg[8] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[8]),
        .Q(time_out[8]),
        .R(1'b0));
  FDRE \time_interim_reg[9] 
       (.C(clock),
        .CE(1'b1),
        .D(time_in[9]),
        .Q(time_out[9]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
