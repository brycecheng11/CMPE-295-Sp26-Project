-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Fri Sep  4 03:05:04 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_prev_value_flip_flop_0_0_stub.vhdl
-- Design      : design_1_prev_value_flip_flop_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clock : in STD_LOGIC_VECTOR ( 0 to 0 );
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    time_in : in STD_LOGIC_VECTOR ( 63 downto 0 );
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    time_out : out STD_LOGIC_VECTOR ( 63 downto 0 )
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock[0:0],error_in[31:0],integral_in[31:0],time_in[63:0],error_out[31:0],integral_out[31:0],time_out[63:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "prev_value_flip_flop,Vivado 2021.1";
begin
end;
