// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Fri Sep  4 02:57:51 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_initial_math_0_0_sim_netlist.v
// Design      : design_1_initial_math_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_initial_math_0_0,initial_math,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "initial_math,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (angle,
    new_angle_available,
    target_angle,
    new_target_angle_available,
    dt,
    error_in,
    integral_in,
    error_out,
    integral_out,
    derivative_out);
  input [31:0]angle;
  input [0:0]new_angle_available;
  input [31:0]target_angle;
  input [0:0]new_target_angle_available;
  input [31:0]dt;
  input [31:0]error_in;
  input [31:0]integral_in;
  output [31:0]error_out;
  output [31:0]integral_out;
  output [31:0]derivative_out;

  wire [31:0]angle;
  wire [31:0]derivative_out;
  wire [31:0]dt;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [0:0]new_angle_available;
  wire [0:0]new_target_angle_available;
  wire [31:0]target_angle;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math inst
       (.angle(angle),
        .derivative_out(derivative_out),
        .dt(dt),
        .error_in(error_in),
        .error_out(error_out),
        .integral_in(integral_in),
        .integral_out(integral_out),
        .new_angle_available(new_angle_available),
        .new_target_angle_available(new_target_angle_available),
        .target_angle(target_angle));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_initial_math
   (error_out,
    integral_out,
    derivative_out,
    dt,
    target_angle,
    angle,
    error_in,
    new_angle_available,
    new_target_angle_available,
    integral_in);
  output [31:0]error_out;
  output [31:0]integral_out;
  output [31:0]derivative_out;
  input [31:0]dt;
  input [31:0]target_angle;
  input [31:0]angle;
  input [31:0]error_in;
  input [0:0]new_angle_available;
  input [0:0]new_target_angle_available;
  input [31:0]integral_in;

  wire [31:0]angle;
  wire [31:0]derivative11_out;
  wire derivative1__0_carry__0_i_1_n_0;
  wire derivative1__0_carry__0_i_2_n_0;
  wire derivative1__0_carry__0_i_3_n_0;
  wire derivative1__0_carry__0_i_4_n_0;
  wire derivative1__0_carry__0_i_5_n_0;
  wire derivative1__0_carry__0_i_6_n_0;
  wire derivative1__0_carry__0_i_7_n_0;
  wire derivative1__0_carry__0_i_8_n_0;
  wire derivative1__0_carry__0_n_0;
  wire derivative1__0_carry__0_n_1;
  wire derivative1__0_carry__0_n_2;
  wire derivative1__0_carry__0_n_3;
  wire derivative1__0_carry__1_i_1_n_0;
  wire derivative1__0_carry__1_i_2_n_0;
  wire derivative1__0_carry__1_i_3_n_0;
  wire derivative1__0_carry__1_i_4_n_0;
  wire derivative1__0_carry__1_i_5_n_0;
  wire derivative1__0_carry__1_i_6_n_0;
  wire derivative1__0_carry__1_i_7_n_0;
  wire derivative1__0_carry__1_i_8_n_0;
  wire derivative1__0_carry__1_n_0;
  wire derivative1__0_carry__1_n_1;
  wire derivative1__0_carry__1_n_2;
  wire derivative1__0_carry__1_n_3;
  wire derivative1__0_carry__2_i_1_n_0;
  wire derivative1__0_carry__2_i_2_n_0;
  wire derivative1__0_carry__2_i_3_n_0;
  wire derivative1__0_carry__2_i_4_n_0;
  wire derivative1__0_carry__2_i_5_n_0;
  wire derivative1__0_carry__2_i_6_n_0;
  wire derivative1__0_carry__2_i_7_n_0;
  wire derivative1__0_carry__2_i_8_n_0;
  wire derivative1__0_carry__2_n_0;
  wire derivative1__0_carry__2_n_1;
  wire derivative1__0_carry__2_n_2;
  wire derivative1__0_carry__2_n_3;
  wire derivative1__0_carry__3_i_1_n_0;
  wire derivative1__0_carry__3_i_2_n_0;
  wire derivative1__0_carry__3_i_3_n_0;
  wire derivative1__0_carry__3_i_4_n_0;
  wire derivative1__0_carry__3_i_5_n_0;
  wire derivative1__0_carry__3_i_6_n_0;
  wire derivative1__0_carry__3_i_7_n_0;
  wire derivative1__0_carry__3_i_8_n_0;
  wire derivative1__0_carry__3_n_0;
  wire derivative1__0_carry__3_n_1;
  wire derivative1__0_carry__3_n_2;
  wire derivative1__0_carry__3_n_3;
  wire derivative1__0_carry__4_i_1_n_0;
  wire derivative1__0_carry__4_i_2_n_0;
  wire derivative1__0_carry__4_i_3_n_0;
  wire derivative1__0_carry__4_i_4_n_0;
  wire derivative1__0_carry__4_i_5_n_0;
  wire derivative1__0_carry__4_i_6_n_0;
  wire derivative1__0_carry__4_i_7_n_0;
  wire derivative1__0_carry__4_i_8_n_0;
  wire derivative1__0_carry__4_n_0;
  wire derivative1__0_carry__4_n_1;
  wire derivative1__0_carry__4_n_2;
  wire derivative1__0_carry__4_n_3;
  wire derivative1__0_carry__5_i_1_n_0;
  wire derivative1__0_carry__5_i_2_n_0;
  wire derivative1__0_carry__5_i_3_n_0;
  wire derivative1__0_carry__5_i_4_n_0;
  wire derivative1__0_carry__5_i_5_n_0;
  wire derivative1__0_carry__5_i_6_n_0;
  wire derivative1__0_carry__5_i_7_n_0;
  wire derivative1__0_carry__5_i_8_n_0;
  wire derivative1__0_carry__5_n_0;
  wire derivative1__0_carry__5_n_1;
  wire derivative1__0_carry__5_n_2;
  wire derivative1__0_carry__5_n_3;
  wire derivative1__0_carry__6_i_1_n_0;
  wire derivative1__0_carry__6_i_2_n_0;
  wire derivative1__0_carry__6_i_3_n_0;
  wire derivative1__0_carry__6_i_4_n_0;
  wire derivative1__0_carry__6_i_5_n_0;
  wire derivative1__0_carry__6_i_6_n_0;
  wire derivative1__0_carry__6_i_7_n_0;
  wire derivative1__0_carry__6_n_1;
  wire derivative1__0_carry__6_n_2;
  wire derivative1__0_carry__6_n_3;
  wire derivative1__0_carry_i_1_n_0;
  wire derivative1__0_carry_i_2_n_0;
  wire derivative1__0_carry_i_3_n_0;
  wire derivative1__0_carry_i_4_n_0;
  wire derivative1__0_carry_i_5_n_0;
  wire derivative1__0_carry_i_6_n_0;
  wire derivative1__0_carry_i_7_n_0;
  wire derivative1__0_carry_n_0;
  wire derivative1__0_carry_n_1;
  wire derivative1__0_carry_n_2;
  wire derivative1__0_carry_n_3;
  wire \derivative[0]_i_10_n_0 ;
  wire \derivative[0]_i_11_n_0 ;
  wire \derivative[0]_i_12_n_0 ;
  wire \derivative[0]_i_13_n_0 ;
  wire \derivative[0]_i_15_n_0 ;
  wire \derivative[0]_i_16_n_0 ;
  wire \derivative[0]_i_17_n_0 ;
  wire \derivative[0]_i_18_n_0 ;
  wire \derivative[0]_i_20_n_0 ;
  wire \derivative[0]_i_21_n_0 ;
  wire \derivative[0]_i_22_n_0 ;
  wire \derivative[0]_i_23_n_0 ;
  wire \derivative[0]_i_25_n_0 ;
  wire \derivative[0]_i_26_n_0 ;
  wire \derivative[0]_i_27_n_0 ;
  wire \derivative[0]_i_28_n_0 ;
  wire \derivative[0]_i_30_n_0 ;
  wire \derivative[0]_i_31_n_0 ;
  wire \derivative[0]_i_32_n_0 ;
  wire \derivative[0]_i_33_n_0 ;
  wire \derivative[0]_i_35_n_0 ;
  wire \derivative[0]_i_36_n_0 ;
  wire \derivative[0]_i_37_n_0 ;
  wire \derivative[0]_i_38_n_0 ;
  wire \derivative[0]_i_39_n_0 ;
  wire \derivative[0]_i_3_n_0 ;
  wire \derivative[0]_i_40_n_0 ;
  wire \derivative[0]_i_41_n_0 ;
  wire \derivative[0]_i_42_n_0 ;
  wire \derivative[0]_i_5_n_0 ;
  wire \derivative[0]_i_6_n_0 ;
  wire \derivative[0]_i_7_n_0 ;
  wire \derivative[0]_i_8_n_0 ;
  wire \derivative[10]_i_11_n_0 ;
  wire \derivative[10]_i_12_n_0 ;
  wire \derivative[10]_i_13_n_0 ;
  wire \derivative[10]_i_14_n_0 ;
  wire \derivative[10]_i_16_n_0 ;
  wire \derivative[10]_i_17_n_0 ;
  wire \derivative[10]_i_18_n_0 ;
  wire \derivative[10]_i_19_n_0 ;
  wire \derivative[10]_i_21_n_0 ;
  wire \derivative[10]_i_22_n_0 ;
  wire \derivative[10]_i_23_n_0 ;
  wire \derivative[10]_i_24_n_0 ;
  wire \derivative[10]_i_26_n_0 ;
  wire \derivative[10]_i_27_n_0 ;
  wire \derivative[10]_i_28_n_0 ;
  wire \derivative[10]_i_29_n_0 ;
  wire \derivative[10]_i_31_n_0 ;
  wire \derivative[10]_i_32_n_0 ;
  wire \derivative[10]_i_33_n_0 ;
  wire \derivative[10]_i_34_n_0 ;
  wire \derivative[10]_i_36_n_0 ;
  wire \derivative[10]_i_37_n_0 ;
  wire \derivative[10]_i_38_n_0 ;
  wire \derivative[10]_i_39_n_0 ;
  wire \derivative[10]_i_3_n_0 ;
  wire \derivative[10]_i_40_n_0 ;
  wire \derivative[10]_i_41_n_0 ;
  wire \derivative[10]_i_42_n_0 ;
  wire \derivative[10]_i_4_n_0 ;
  wire \derivative[10]_i_6_n_0 ;
  wire \derivative[10]_i_7_n_0 ;
  wire \derivative[10]_i_8_n_0 ;
  wire \derivative[10]_i_9_n_0 ;
  wire \derivative[11]_i_11_n_0 ;
  wire \derivative[11]_i_12_n_0 ;
  wire \derivative[11]_i_13_n_0 ;
  wire \derivative[11]_i_14_n_0 ;
  wire \derivative[11]_i_16_n_0 ;
  wire \derivative[11]_i_17_n_0 ;
  wire \derivative[11]_i_18_n_0 ;
  wire \derivative[11]_i_19_n_0 ;
  wire \derivative[11]_i_21_n_0 ;
  wire \derivative[11]_i_22_n_0 ;
  wire \derivative[11]_i_23_n_0 ;
  wire \derivative[11]_i_24_n_0 ;
  wire \derivative[11]_i_26_n_0 ;
  wire \derivative[11]_i_27_n_0 ;
  wire \derivative[11]_i_28_n_0 ;
  wire \derivative[11]_i_29_n_0 ;
  wire \derivative[11]_i_31_n_0 ;
  wire \derivative[11]_i_32_n_0 ;
  wire \derivative[11]_i_33_n_0 ;
  wire \derivative[11]_i_34_n_0 ;
  wire \derivative[11]_i_36_n_0 ;
  wire \derivative[11]_i_37_n_0 ;
  wire \derivative[11]_i_38_n_0 ;
  wire \derivative[11]_i_39_n_0 ;
  wire \derivative[11]_i_3_n_0 ;
  wire \derivative[11]_i_40_n_0 ;
  wire \derivative[11]_i_41_n_0 ;
  wire \derivative[11]_i_42_n_0 ;
  wire \derivative[11]_i_4_n_0 ;
  wire \derivative[11]_i_6_n_0 ;
  wire \derivative[11]_i_7_n_0 ;
  wire \derivative[11]_i_8_n_0 ;
  wire \derivative[11]_i_9_n_0 ;
  wire \derivative[12]_i_11_n_0 ;
  wire \derivative[12]_i_12_n_0 ;
  wire \derivative[12]_i_13_n_0 ;
  wire \derivative[12]_i_14_n_0 ;
  wire \derivative[12]_i_16_n_0 ;
  wire \derivative[12]_i_17_n_0 ;
  wire \derivative[12]_i_18_n_0 ;
  wire \derivative[12]_i_19_n_0 ;
  wire \derivative[12]_i_21_n_0 ;
  wire \derivative[12]_i_22_n_0 ;
  wire \derivative[12]_i_23_n_0 ;
  wire \derivative[12]_i_24_n_0 ;
  wire \derivative[12]_i_26_n_0 ;
  wire \derivative[12]_i_27_n_0 ;
  wire \derivative[12]_i_28_n_0 ;
  wire \derivative[12]_i_29_n_0 ;
  wire \derivative[12]_i_31_n_0 ;
  wire \derivative[12]_i_32_n_0 ;
  wire \derivative[12]_i_33_n_0 ;
  wire \derivative[12]_i_34_n_0 ;
  wire \derivative[12]_i_36_n_0 ;
  wire \derivative[12]_i_37_n_0 ;
  wire \derivative[12]_i_38_n_0 ;
  wire \derivative[12]_i_39_n_0 ;
  wire \derivative[12]_i_3_n_0 ;
  wire \derivative[12]_i_40_n_0 ;
  wire \derivative[12]_i_41_n_0 ;
  wire \derivative[12]_i_42_n_0 ;
  wire \derivative[12]_i_4_n_0 ;
  wire \derivative[12]_i_6_n_0 ;
  wire \derivative[12]_i_7_n_0 ;
  wire \derivative[12]_i_8_n_0 ;
  wire \derivative[12]_i_9_n_0 ;
  wire \derivative[13]_i_11_n_0 ;
  wire \derivative[13]_i_12_n_0 ;
  wire \derivative[13]_i_13_n_0 ;
  wire \derivative[13]_i_14_n_0 ;
  wire \derivative[13]_i_16_n_0 ;
  wire \derivative[13]_i_17_n_0 ;
  wire \derivative[13]_i_18_n_0 ;
  wire \derivative[13]_i_19_n_0 ;
  wire \derivative[13]_i_21_n_0 ;
  wire \derivative[13]_i_22_n_0 ;
  wire \derivative[13]_i_23_n_0 ;
  wire \derivative[13]_i_24_n_0 ;
  wire \derivative[13]_i_26_n_0 ;
  wire \derivative[13]_i_27_n_0 ;
  wire \derivative[13]_i_28_n_0 ;
  wire \derivative[13]_i_29_n_0 ;
  wire \derivative[13]_i_31_n_0 ;
  wire \derivative[13]_i_32_n_0 ;
  wire \derivative[13]_i_33_n_0 ;
  wire \derivative[13]_i_34_n_0 ;
  wire \derivative[13]_i_36_n_0 ;
  wire \derivative[13]_i_37_n_0 ;
  wire \derivative[13]_i_38_n_0 ;
  wire \derivative[13]_i_39_n_0 ;
  wire \derivative[13]_i_3_n_0 ;
  wire \derivative[13]_i_40_n_0 ;
  wire \derivative[13]_i_41_n_0 ;
  wire \derivative[13]_i_42_n_0 ;
  wire \derivative[13]_i_4_n_0 ;
  wire \derivative[13]_i_6_n_0 ;
  wire \derivative[13]_i_7_n_0 ;
  wire \derivative[13]_i_8_n_0 ;
  wire \derivative[13]_i_9_n_0 ;
  wire \derivative[14]_i_11_n_0 ;
  wire \derivative[14]_i_12_n_0 ;
  wire \derivative[14]_i_13_n_0 ;
  wire \derivative[14]_i_14_n_0 ;
  wire \derivative[14]_i_16_n_0 ;
  wire \derivative[14]_i_17_n_0 ;
  wire \derivative[14]_i_18_n_0 ;
  wire \derivative[14]_i_19_n_0 ;
  wire \derivative[14]_i_21_n_0 ;
  wire \derivative[14]_i_22_n_0 ;
  wire \derivative[14]_i_23_n_0 ;
  wire \derivative[14]_i_24_n_0 ;
  wire \derivative[14]_i_26_n_0 ;
  wire \derivative[14]_i_27_n_0 ;
  wire \derivative[14]_i_28_n_0 ;
  wire \derivative[14]_i_29_n_0 ;
  wire \derivative[14]_i_31_n_0 ;
  wire \derivative[14]_i_32_n_0 ;
  wire \derivative[14]_i_33_n_0 ;
  wire \derivative[14]_i_34_n_0 ;
  wire \derivative[14]_i_36_n_0 ;
  wire \derivative[14]_i_37_n_0 ;
  wire \derivative[14]_i_38_n_0 ;
  wire \derivative[14]_i_39_n_0 ;
  wire \derivative[14]_i_3_n_0 ;
  wire \derivative[14]_i_40_n_0 ;
  wire \derivative[14]_i_41_n_0 ;
  wire \derivative[14]_i_42_n_0 ;
  wire \derivative[14]_i_4_n_0 ;
  wire \derivative[14]_i_6_n_0 ;
  wire \derivative[14]_i_7_n_0 ;
  wire \derivative[14]_i_8_n_0 ;
  wire \derivative[14]_i_9_n_0 ;
  wire \derivative[15]_i_11_n_0 ;
  wire \derivative[15]_i_12_n_0 ;
  wire \derivative[15]_i_13_n_0 ;
  wire \derivative[15]_i_14_n_0 ;
  wire \derivative[15]_i_16_n_0 ;
  wire \derivative[15]_i_17_n_0 ;
  wire \derivative[15]_i_18_n_0 ;
  wire \derivative[15]_i_19_n_0 ;
  wire \derivative[15]_i_21_n_0 ;
  wire \derivative[15]_i_22_n_0 ;
  wire \derivative[15]_i_23_n_0 ;
  wire \derivative[15]_i_24_n_0 ;
  wire \derivative[15]_i_26_n_0 ;
  wire \derivative[15]_i_27_n_0 ;
  wire \derivative[15]_i_28_n_0 ;
  wire \derivative[15]_i_29_n_0 ;
  wire \derivative[15]_i_31_n_0 ;
  wire \derivative[15]_i_32_n_0 ;
  wire \derivative[15]_i_33_n_0 ;
  wire \derivative[15]_i_34_n_0 ;
  wire \derivative[15]_i_36_n_0 ;
  wire \derivative[15]_i_37_n_0 ;
  wire \derivative[15]_i_38_n_0 ;
  wire \derivative[15]_i_39_n_0 ;
  wire \derivative[15]_i_3_n_0 ;
  wire \derivative[15]_i_40_n_0 ;
  wire \derivative[15]_i_41_n_0 ;
  wire \derivative[15]_i_42_n_0 ;
  wire \derivative[15]_i_4_n_0 ;
  wire \derivative[15]_i_6_n_0 ;
  wire \derivative[15]_i_7_n_0 ;
  wire \derivative[15]_i_8_n_0 ;
  wire \derivative[15]_i_9_n_0 ;
  wire \derivative[16]_i_11_n_0 ;
  wire \derivative[16]_i_12_n_0 ;
  wire \derivative[16]_i_13_n_0 ;
  wire \derivative[16]_i_14_n_0 ;
  wire \derivative[16]_i_16_n_0 ;
  wire \derivative[16]_i_17_n_0 ;
  wire \derivative[16]_i_18_n_0 ;
  wire \derivative[16]_i_19_n_0 ;
  wire \derivative[16]_i_21_n_0 ;
  wire \derivative[16]_i_22_n_0 ;
  wire \derivative[16]_i_23_n_0 ;
  wire \derivative[16]_i_24_n_0 ;
  wire \derivative[16]_i_26_n_0 ;
  wire \derivative[16]_i_27_n_0 ;
  wire \derivative[16]_i_28_n_0 ;
  wire \derivative[16]_i_29_n_0 ;
  wire \derivative[16]_i_31_n_0 ;
  wire \derivative[16]_i_32_n_0 ;
  wire \derivative[16]_i_33_n_0 ;
  wire \derivative[16]_i_34_n_0 ;
  wire \derivative[16]_i_36_n_0 ;
  wire \derivative[16]_i_37_n_0 ;
  wire \derivative[16]_i_38_n_0 ;
  wire \derivative[16]_i_39_n_0 ;
  wire \derivative[16]_i_3_n_0 ;
  wire \derivative[16]_i_40_n_0 ;
  wire \derivative[16]_i_41_n_0 ;
  wire \derivative[16]_i_42_n_0 ;
  wire \derivative[16]_i_4_n_0 ;
  wire \derivative[16]_i_6_n_0 ;
  wire \derivative[16]_i_7_n_0 ;
  wire \derivative[16]_i_8_n_0 ;
  wire \derivative[16]_i_9_n_0 ;
  wire \derivative[17]_i_11_n_0 ;
  wire \derivative[17]_i_12_n_0 ;
  wire \derivative[17]_i_13_n_0 ;
  wire \derivative[17]_i_14_n_0 ;
  wire \derivative[17]_i_16_n_0 ;
  wire \derivative[17]_i_17_n_0 ;
  wire \derivative[17]_i_18_n_0 ;
  wire \derivative[17]_i_19_n_0 ;
  wire \derivative[17]_i_21_n_0 ;
  wire \derivative[17]_i_22_n_0 ;
  wire \derivative[17]_i_23_n_0 ;
  wire \derivative[17]_i_24_n_0 ;
  wire \derivative[17]_i_26_n_0 ;
  wire \derivative[17]_i_27_n_0 ;
  wire \derivative[17]_i_28_n_0 ;
  wire \derivative[17]_i_29_n_0 ;
  wire \derivative[17]_i_31_n_0 ;
  wire \derivative[17]_i_32_n_0 ;
  wire \derivative[17]_i_33_n_0 ;
  wire \derivative[17]_i_34_n_0 ;
  wire \derivative[17]_i_36_n_0 ;
  wire \derivative[17]_i_37_n_0 ;
  wire \derivative[17]_i_38_n_0 ;
  wire \derivative[17]_i_39_n_0 ;
  wire \derivative[17]_i_3_n_0 ;
  wire \derivative[17]_i_40_n_0 ;
  wire \derivative[17]_i_41_n_0 ;
  wire \derivative[17]_i_42_n_0 ;
  wire \derivative[17]_i_4_n_0 ;
  wire \derivative[17]_i_6_n_0 ;
  wire \derivative[17]_i_7_n_0 ;
  wire \derivative[17]_i_8_n_0 ;
  wire \derivative[17]_i_9_n_0 ;
  wire \derivative[18]_i_11_n_0 ;
  wire \derivative[18]_i_12_n_0 ;
  wire \derivative[18]_i_13_n_0 ;
  wire \derivative[18]_i_14_n_0 ;
  wire \derivative[18]_i_16_n_0 ;
  wire \derivative[18]_i_17_n_0 ;
  wire \derivative[18]_i_18_n_0 ;
  wire \derivative[18]_i_19_n_0 ;
  wire \derivative[18]_i_21_n_0 ;
  wire \derivative[18]_i_22_n_0 ;
  wire \derivative[18]_i_23_n_0 ;
  wire \derivative[18]_i_24_n_0 ;
  wire \derivative[18]_i_26_n_0 ;
  wire \derivative[18]_i_27_n_0 ;
  wire \derivative[18]_i_28_n_0 ;
  wire \derivative[18]_i_29_n_0 ;
  wire \derivative[18]_i_31_n_0 ;
  wire \derivative[18]_i_32_n_0 ;
  wire \derivative[18]_i_33_n_0 ;
  wire \derivative[18]_i_34_n_0 ;
  wire \derivative[18]_i_36_n_0 ;
  wire \derivative[18]_i_37_n_0 ;
  wire \derivative[18]_i_38_n_0 ;
  wire \derivative[18]_i_39_n_0 ;
  wire \derivative[18]_i_3_n_0 ;
  wire \derivative[18]_i_40_n_0 ;
  wire \derivative[18]_i_41_n_0 ;
  wire \derivative[18]_i_42_n_0 ;
  wire \derivative[18]_i_4_n_0 ;
  wire \derivative[18]_i_6_n_0 ;
  wire \derivative[18]_i_7_n_0 ;
  wire \derivative[18]_i_8_n_0 ;
  wire \derivative[18]_i_9_n_0 ;
  wire \derivative[19]_i_11_n_0 ;
  wire \derivative[19]_i_12_n_0 ;
  wire \derivative[19]_i_13_n_0 ;
  wire \derivative[19]_i_14_n_0 ;
  wire \derivative[19]_i_16_n_0 ;
  wire \derivative[19]_i_17_n_0 ;
  wire \derivative[19]_i_18_n_0 ;
  wire \derivative[19]_i_19_n_0 ;
  wire \derivative[19]_i_21_n_0 ;
  wire \derivative[19]_i_22_n_0 ;
  wire \derivative[19]_i_23_n_0 ;
  wire \derivative[19]_i_24_n_0 ;
  wire \derivative[19]_i_26_n_0 ;
  wire \derivative[19]_i_27_n_0 ;
  wire \derivative[19]_i_28_n_0 ;
  wire \derivative[19]_i_29_n_0 ;
  wire \derivative[19]_i_31_n_0 ;
  wire \derivative[19]_i_32_n_0 ;
  wire \derivative[19]_i_33_n_0 ;
  wire \derivative[19]_i_34_n_0 ;
  wire \derivative[19]_i_36_n_0 ;
  wire \derivative[19]_i_37_n_0 ;
  wire \derivative[19]_i_38_n_0 ;
  wire \derivative[19]_i_39_n_0 ;
  wire \derivative[19]_i_3_n_0 ;
  wire \derivative[19]_i_40_n_0 ;
  wire \derivative[19]_i_41_n_0 ;
  wire \derivative[19]_i_42_n_0 ;
  wire \derivative[19]_i_4_n_0 ;
  wire \derivative[19]_i_6_n_0 ;
  wire \derivative[19]_i_7_n_0 ;
  wire \derivative[19]_i_8_n_0 ;
  wire \derivative[19]_i_9_n_0 ;
  wire \derivative[1]_i_11_n_0 ;
  wire \derivative[1]_i_12_n_0 ;
  wire \derivative[1]_i_13_n_0 ;
  wire \derivative[1]_i_14_n_0 ;
  wire \derivative[1]_i_16_n_0 ;
  wire \derivative[1]_i_17_n_0 ;
  wire \derivative[1]_i_18_n_0 ;
  wire \derivative[1]_i_19_n_0 ;
  wire \derivative[1]_i_21_n_0 ;
  wire \derivative[1]_i_22_n_0 ;
  wire \derivative[1]_i_23_n_0 ;
  wire \derivative[1]_i_24_n_0 ;
  wire \derivative[1]_i_26_n_0 ;
  wire \derivative[1]_i_27_n_0 ;
  wire \derivative[1]_i_28_n_0 ;
  wire \derivative[1]_i_29_n_0 ;
  wire \derivative[1]_i_31_n_0 ;
  wire \derivative[1]_i_32_n_0 ;
  wire \derivative[1]_i_33_n_0 ;
  wire \derivative[1]_i_34_n_0 ;
  wire \derivative[1]_i_36_n_0 ;
  wire \derivative[1]_i_37_n_0 ;
  wire \derivative[1]_i_38_n_0 ;
  wire \derivative[1]_i_39_n_0 ;
  wire \derivative[1]_i_3_n_0 ;
  wire \derivative[1]_i_40_n_0 ;
  wire \derivative[1]_i_41_n_0 ;
  wire \derivative[1]_i_42_n_0 ;
  wire \derivative[1]_i_4_n_0 ;
  wire \derivative[1]_i_6_n_0 ;
  wire \derivative[1]_i_7_n_0 ;
  wire \derivative[1]_i_8_n_0 ;
  wire \derivative[1]_i_9_n_0 ;
  wire \derivative[20]_i_11_n_0 ;
  wire \derivative[20]_i_12_n_0 ;
  wire \derivative[20]_i_13_n_0 ;
  wire \derivative[20]_i_14_n_0 ;
  wire \derivative[20]_i_16_n_0 ;
  wire \derivative[20]_i_17_n_0 ;
  wire \derivative[20]_i_18_n_0 ;
  wire \derivative[20]_i_19_n_0 ;
  wire \derivative[20]_i_21_n_0 ;
  wire \derivative[20]_i_22_n_0 ;
  wire \derivative[20]_i_23_n_0 ;
  wire \derivative[20]_i_24_n_0 ;
  wire \derivative[20]_i_26_n_0 ;
  wire \derivative[20]_i_27_n_0 ;
  wire \derivative[20]_i_28_n_0 ;
  wire \derivative[20]_i_29_n_0 ;
  wire \derivative[20]_i_31_n_0 ;
  wire \derivative[20]_i_32_n_0 ;
  wire \derivative[20]_i_33_n_0 ;
  wire \derivative[20]_i_34_n_0 ;
  wire \derivative[20]_i_36_n_0 ;
  wire \derivative[20]_i_37_n_0 ;
  wire \derivative[20]_i_38_n_0 ;
  wire \derivative[20]_i_39_n_0 ;
  wire \derivative[20]_i_3_n_0 ;
  wire \derivative[20]_i_40_n_0 ;
  wire \derivative[20]_i_41_n_0 ;
  wire \derivative[20]_i_42_n_0 ;
  wire \derivative[20]_i_4_n_0 ;
  wire \derivative[20]_i_6_n_0 ;
  wire \derivative[20]_i_7_n_0 ;
  wire \derivative[20]_i_8_n_0 ;
  wire \derivative[20]_i_9_n_0 ;
  wire \derivative[21]_i_11_n_0 ;
  wire \derivative[21]_i_12_n_0 ;
  wire \derivative[21]_i_13_n_0 ;
  wire \derivative[21]_i_14_n_0 ;
  wire \derivative[21]_i_16_n_0 ;
  wire \derivative[21]_i_17_n_0 ;
  wire \derivative[21]_i_18_n_0 ;
  wire \derivative[21]_i_19_n_0 ;
  wire \derivative[21]_i_21_n_0 ;
  wire \derivative[21]_i_22_n_0 ;
  wire \derivative[21]_i_23_n_0 ;
  wire \derivative[21]_i_24_n_0 ;
  wire \derivative[21]_i_26_n_0 ;
  wire \derivative[21]_i_27_n_0 ;
  wire \derivative[21]_i_28_n_0 ;
  wire \derivative[21]_i_29_n_0 ;
  wire \derivative[21]_i_31_n_0 ;
  wire \derivative[21]_i_32_n_0 ;
  wire \derivative[21]_i_33_n_0 ;
  wire \derivative[21]_i_34_n_0 ;
  wire \derivative[21]_i_36_n_0 ;
  wire \derivative[21]_i_37_n_0 ;
  wire \derivative[21]_i_38_n_0 ;
  wire \derivative[21]_i_39_n_0 ;
  wire \derivative[21]_i_3_n_0 ;
  wire \derivative[21]_i_40_n_0 ;
  wire \derivative[21]_i_41_n_0 ;
  wire \derivative[21]_i_42_n_0 ;
  wire \derivative[21]_i_4_n_0 ;
  wire \derivative[21]_i_6_n_0 ;
  wire \derivative[21]_i_7_n_0 ;
  wire \derivative[21]_i_8_n_0 ;
  wire \derivative[21]_i_9_n_0 ;
  wire \derivative[22]_i_11_n_0 ;
  wire \derivative[22]_i_12_n_0 ;
  wire \derivative[22]_i_13_n_0 ;
  wire \derivative[22]_i_14_n_0 ;
  wire \derivative[22]_i_16_n_0 ;
  wire \derivative[22]_i_17_n_0 ;
  wire \derivative[22]_i_18_n_0 ;
  wire \derivative[22]_i_19_n_0 ;
  wire \derivative[22]_i_21_n_0 ;
  wire \derivative[22]_i_22_n_0 ;
  wire \derivative[22]_i_23_n_0 ;
  wire \derivative[22]_i_24_n_0 ;
  wire \derivative[22]_i_26_n_0 ;
  wire \derivative[22]_i_27_n_0 ;
  wire \derivative[22]_i_28_n_0 ;
  wire \derivative[22]_i_29_n_0 ;
  wire \derivative[22]_i_31_n_0 ;
  wire \derivative[22]_i_32_n_0 ;
  wire \derivative[22]_i_33_n_0 ;
  wire \derivative[22]_i_34_n_0 ;
  wire \derivative[22]_i_36_n_0 ;
  wire \derivative[22]_i_37_n_0 ;
  wire \derivative[22]_i_38_n_0 ;
  wire \derivative[22]_i_39_n_0 ;
  wire \derivative[22]_i_3_n_0 ;
  wire \derivative[22]_i_40_n_0 ;
  wire \derivative[22]_i_41_n_0 ;
  wire \derivative[22]_i_42_n_0 ;
  wire \derivative[22]_i_4_n_0 ;
  wire \derivative[22]_i_6_n_0 ;
  wire \derivative[22]_i_7_n_0 ;
  wire \derivative[22]_i_8_n_0 ;
  wire \derivative[22]_i_9_n_0 ;
  wire \derivative[23]_i_11_n_0 ;
  wire \derivative[23]_i_12_n_0 ;
  wire \derivative[23]_i_13_n_0 ;
  wire \derivative[23]_i_14_n_0 ;
  wire \derivative[23]_i_16_n_0 ;
  wire \derivative[23]_i_17_n_0 ;
  wire \derivative[23]_i_18_n_0 ;
  wire \derivative[23]_i_19_n_0 ;
  wire \derivative[23]_i_21_n_0 ;
  wire \derivative[23]_i_22_n_0 ;
  wire \derivative[23]_i_23_n_0 ;
  wire \derivative[23]_i_24_n_0 ;
  wire \derivative[23]_i_26_n_0 ;
  wire \derivative[23]_i_27_n_0 ;
  wire \derivative[23]_i_28_n_0 ;
  wire \derivative[23]_i_29_n_0 ;
  wire \derivative[23]_i_31_n_0 ;
  wire \derivative[23]_i_32_n_0 ;
  wire \derivative[23]_i_33_n_0 ;
  wire \derivative[23]_i_34_n_0 ;
  wire \derivative[23]_i_36_n_0 ;
  wire \derivative[23]_i_37_n_0 ;
  wire \derivative[23]_i_38_n_0 ;
  wire \derivative[23]_i_39_n_0 ;
  wire \derivative[23]_i_3_n_0 ;
  wire \derivative[23]_i_40_n_0 ;
  wire \derivative[23]_i_41_n_0 ;
  wire \derivative[23]_i_42_n_0 ;
  wire \derivative[23]_i_4_n_0 ;
  wire \derivative[23]_i_6_n_0 ;
  wire \derivative[23]_i_7_n_0 ;
  wire \derivative[23]_i_8_n_0 ;
  wire \derivative[23]_i_9_n_0 ;
  wire \derivative[24]_i_11_n_0 ;
  wire \derivative[24]_i_12_n_0 ;
  wire \derivative[24]_i_13_n_0 ;
  wire \derivative[24]_i_14_n_0 ;
  wire \derivative[24]_i_16_n_0 ;
  wire \derivative[24]_i_17_n_0 ;
  wire \derivative[24]_i_18_n_0 ;
  wire \derivative[24]_i_19_n_0 ;
  wire \derivative[24]_i_21_n_0 ;
  wire \derivative[24]_i_22_n_0 ;
  wire \derivative[24]_i_23_n_0 ;
  wire \derivative[24]_i_24_n_0 ;
  wire \derivative[24]_i_26_n_0 ;
  wire \derivative[24]_i_27_n_0 ;
  wire \derivative[24]_i_28_n_0 ;
  wire \derivative[24]_i_29_n_0 ;
  wire \derivative[24]_i_31_n_0 ;
  wire \derivative[24]_i_32_n_0 ;
  wire \derivative[24]_i_33_n_0 ;
  wire \derivative[24]_i_34_n_0 ;
  wire \derivative[24]_i_36_n_0 ;
  wire \derivative[24]_i_37_n_0 ;
  wire \derivative[24]_i_38_n_0 ;
  wire \derivative[24]_i_39_n_0 ;
  wire \derivative[24]_i_3_n_0 ;
  wire \derivative[24]_i_40_n_0 ;
  wire \derivative[24]_i_41_n_0 ;
  wire \derivative[24]_i_42_n_0 ;
  wire \derivative[24]_i_4_n_0 ;
  wire \derivative[24]_i_6_n_0 ;
  wire \derivative[24]_i_7_n_0 ;
  wire \derivative[24]_i_8_n_0 ;
  wire \derivative[24]_i_9_n_0 ;
  wire \derivative[25]_i_11_n_0 ;
  wire \derivative[25]_i_12_n_0 ;
  wire \derivative[25]_i_13_n_0 ;
  wire \derivative[25]_i_14_n_0 ;
  wire \derivative[25]_i_16_n_0 ;
  wire \derivative[25]_i_17_n_0 ;
  wire \derivative[25]_i_18_n_0 ;
  wire \derivative[25]_i_19_n_0 ;
  wire \derivative[25]_i_21_n_0 ;
  wire \derivative[25]_i_22_n_0 ;
  wire \derivative[25]_i_23_n_0 ;
  wire \derivative[25]_i_24_n_0 ;
  wire \derivative[25]_i_26_n_0 ;
  wire \derivative[25]_i_27_n_0 ;
  wire \derivative[25]_i_28_n_0 ;
  wire \derivative[25]_i_29_n_0 ;
  wire \derivative[25]_i_31_n_0 ;
  wire \derivative[25]_i_32_n_0 ;
  wire \derivative[25]_i_33_n_0 ;
  wire \derivative[25]_i_34_n_0 ;
  wire \derivative[25]_i_36_n_0 ;
  wire \derivative[25]_i_37_n_0 ;
  wire \derivative[25]_i_38_n_0 ;
  wire \derivative[25]_i_39_n_0 ;
  wire \derivative[25]_i_3_n_0 ;
  wire \derivative[25]_i_40_n_0 ;
  wire \derivative[25]_i_41_n_0 ;
  wire \derivative[25]_i_42_n_0 ;
  wire \derivative[25]_i_4_n_0 ;
  wire \derivative[25]_i_6_n_0 ;
  wire \derivative[25]_i_7_n_0 ;
  wire \derivative[25]_i_8_n_0 ;
  wire \derivative[25]_i_9_n_0 ;
  wire \derivative[26]_i_11_n_0 ;
  wire \derivative[26]_i_12_n_0 ;
  wire \derivative[26]_i_13_n_0 ;
  wire \derivative[26]_i_14_n_0 ;
  wire \derivative[26]_i_16_n_0 ;
  wire \derivative[26]_i_17_n_0 ;
  wire \derivative[26]_i_18_n_0 ;
  wire \derivative[26]_i_19_n_0 ;
  wire \derivative[26]_i_21_n_0 ;
  wire \derivative[26]_i_22_n_0 ;
  wire \derivative[26]_i_23_n_0 ;
  wire \derivative[26]_i_24_n_0 ;
  wire \derivative[26]_i_26_n_0 ;
  wire \derivative[26]_i_27_n_0 ;
  wire \derivative[26]_i_28_n_0 ;
  wire \derivative[26]_i_29_n_0 ;
  wire \derivative[26]_i_31_n_0 ;
  wire \derivative[26]_i_32_n_0 ;
  wire \derivative[26]_i_33_n_0 ;
  wire \derivative[26]_i_34_n_0 ;
  wire \derivative[26]_i_36_n_0 ;
  wire \derivative[26]_i_37_n_0 ;
  wire \derivative[26]_i_38_n_0 ;
  wire \derivative[26]_i_39_n_0 ;
  wire \derivative[26]_i_3_n_0 ;
  wire \derivative[26]_i_40_n_0 ;
  wire \derivative[26]_i_41_n_0 ;
  wire \derivative[26]_i_42_n_0 ;
  wire \derivative[26]_i_4_n_0 ;
  wire \derivative[26]_i_6_n_0 ;
  wire \derivative[26]_i_7_n_0 ;
  wire \derivative[26]_i_8_n_0 ;
  wire \derivative[26]_i_9_n_0 ;
  wire \derivative[27]_i_11_n_0 ;
  wire \derivative[27]_i_12_n_0 ;
  wire \derivative[27]_i_13_n_0 ;
  wire \derivative[27]_i_14_n_0 ;
  wire \derivative[27]_i_16_n_0 ;
  wire \derivative[27]_i_17_n_0 ;
  wire \derivative[27]_i_18_n_0 ;
  wire \derivative[27]_i_19_n_0 ;
  wire \derivative[27]_i_21_n_0 ;
  wire \derivative[27]_i_22_n_0 ;
  wire \derivative[27]_i_23_n_0 ;
  wire \derivative[27]_i_24_n_0 ;
  wire \derivative[27]_i_26_n_0 ;
  wire \derivative[27]_i_27_n_0 ;
  wire \derivative[27]_i_28_n_0 ;
  wire \derivative[27]_i_29_n_0 ;
  wire \derivative[27]_i_31_n_0 ;
  wire \derivative[27]_i_32_n_0 ;
  wire \derivative[27]_i_33_n_0 ;
  wire \derivative[27]_i_34_n_0 ;
  wire \derivative[27]_i_36_n_0 ;
  wire \derivative[27]_i_37_n_0 ;
  wire \derivative[27]_i_38_n_0 ;
  wire \derivative[27]_i_39_n_0 ;
  wire \derivative[27]_i_3_n_0 ;
  wire \derivative[27]_i_40_n_0 ;
  wire \derivative[27]_i_41_n_0 ;
  wire \derivative[27]_i_42_n_0 ;
  wire \derivative[27]_i_4_n_0 ;
  wire \derivative[27]_i_6_n_0 ;
  wire \derivative[27]_i_7_n_0 ;
  wire \derivative[27]_i_8_n_0 ;
  wire \derivative[27]_i_9_n_0 ;
  wire \derivative[28]_i_11_n_0 ;
  wire \derivative[28]_i_12_n_0 ;
  wire \derivative[28]_i_13_n_0 ;
  wire \derivative[28]_i_14_n_0 ;
  wire \derivative[28]_i_16_n_0 ;
  wire \derivative[28]_i_17_n_0 ;
  wire \derivative[28]_i_18_n_0 ;
  wire \derivative[28]_i_19_n_0 ;
  wire \derivative[28]_i_21_n_0 ;
  wire \derivative[28]_i_22_n_0 ;
  wire \derivative[28]_i_23_n_0 ;
  wire \derivative[28]_i_24_n_0 ;
  wire \derivative[28]_i_26_n_0 ;
  wire \derivative[28]_i_27_n_0 ;
  wire \derivative[28]_i_28_n_0 ;
  wire \derivative[28]_i_29_n_0 ;
  wire \derivative[28]_i_31_n_0 ;
  wire \derivative[28]_i_32_n_0 ;
  wire \derivative[28]_i_33_n_0 ;
  wire \derivative[28]_i_34_n_0 ;
  wire \derivative[28]_i_36_n_0 ;
  wire \derivative[28]_i_37_n_0 ;
  wire \derivative[28]_i_38_n_0 ;
  wire \derivative[28]_i_39_n_0 ;
  wire \derivative[28]_i_3_n_0 ;
  wire \derivative[28]_i_40_n_0 ;
  wire \derivative[28]_i_41_n_0 ;
  wire \derivative[28]_i_42_n_0 ;
  wire \derivative[28]_i_4_n_0 ;
  wire \derivative[28]_i_6_n_0 ;
  wire \derivative[28]_i_7_n_0 ;
  wire \derivative[28]_i_8_n_0 ;
  wire \derivative[28]_i_9_n_0 ;
  wire \derivative[29]_i_11_n_0 ;
  wire \derivative[29]_i_12_n_0 ;
  wire \derivative[29]_i_13_n_0 ;
  wire \derivative[29]_i_14_n_0 ;
  wire \derivative[29]_i_16_n_0 ;
  wire \derivative[29]_i_17_n_0 ;
  wire \derivative[29]_i_18_n_0 ;
  wire \derivative[29]_i_19_n_0 ;
  wire \derivative[29]_i_21_n_0 ;
  wire \derivative[29]_i_22_n_0 ;
  wire \derivative[29]_i_23_n_0 ;
  wire \derivative[29]_i_24_n_0 ;
  wire \derivative[29]_i_26_n_0 ;
  wire \derivative[29]_i_27_n_0 ;
  wire \derivative[29]_i_28_n_0 ;
  wire \derivative[29]_i_29_n_0 ;
  wire \derivative[29]_i_31_n_0 ;
  wire \derivative[29]_i_32_n_0 ;
  wire \derivative[29]_i_33_n_0 ;
  wire \derivative[29]_i_34_n_0 ;
  wire \derivative[29]_i_36_n_0 ;
  wire \derivative[29]_i_37_n_0 ;
  wire \derivative[29]_i_38_n_0 ;
  wire \derivative[29]_i_39_n_0 ;
  wire \derivative[29]_i_3_n_0 ;
  wire \derivative[29]_i_40_n_0 ;
  wire \derivative[29]_i_41_n_0 ;
  wire \derivative[29]_i_42_n_0 ;
  wire \derivative[29]_i_4_n_0 ;
  wire \derivative[29]_i_6_n_0 ;
  wire \derivative[29]_i_7_n_0 ;
  wire \derivative[29]_i_8_n_0 ;
  wire \derivative[29]_i_9_n_0 ;
  wire \derivative[2]_i_11_n_0 ;
  wire \derivative[2]_i_12_n_0 ;
  wire \derivative[2]_i_13_n_0 ;
  wire \derivative[2]_i_14_n_0 ;
  wire \derivative[2]_i_16_n_0 ;
  wire \derivative[2]_i_17_n_0 ;
  wire \derivative[2]_i_18_n_0 ;
  wire \derivative[2]_i_19_n_0 ;
  wire \derivative[2]_i_21_n_0 ;
  wire \derivative[2]_i_22_n_0 ;
  wire \derivative[2]_i_23_n_0 ;
  wire \derivative[2]_i_24_n_0 ;
  wire \derivative[2]_i_26_n_0 ;
  wire \derivative[2]_i_27_n_0 ;
  wire \derivative[2]_i_28_n_0 ;
  wire \derivative[2]_i_29_n_0 ;
  wire \derivative[2]_i_31_n_0 ;
  wire \derivative[2]_i_32_n_0 ;
  wire \derivative[2]_i_33_n_0 ;
  wire \derivative[2]_i_34_n_0 ;
  wire \derivative[2]_i_36_n_0 ;
  wire \derivative[2]_i_37_n_0 ;
  wire \derivative[2]_i_38_n_0 ;
  wire \derivative[2]_i_39_n_0 ;
  wire \derivative[2]_i_3_n_0 ;
  wire \derivative[2]_i_40_n_0 ;
  wire \derivative[2]_i_41_n_0 ;
  wire \derivative[2]_i_42_n_0 ;
  wire \derivative[2]_i_4_n_0 ;
  wire \derivative[2]_i_6_n_0 ;
  wire \derivative[2]_i_7_n_0 ;
  wire \derivative[2]_i_8_n_0 ;
  wire \derivative[2]_i_9_n_0 ;
  wire \derivative[30]_i_11_n_0 ;
  wire \derivative[30]_i_12_n_0 ;
  wire \derivative[30]_i_13_n_0 ;
  wire \derivative[30]_i_14_n_0 ;
  wire \derivative[30]_i_16_n_0 ;
  wire \derivative[30]_i_17_n_0 ;
  wire \derivative[30]_i_18_n_0 ;
  wire \derivative[30]_i_19_n_0 ;
  wire \derivative[30]_i_21_n_0 ;
  wire \derivative[30]_i_22_n_0 ;
  wire \derivative[30]_i_23_n_0 ;
  wire \derivative[30]_i_24_n_0 ;
  wire \derivative[30]_i_26_n_0 ;
  wire \derivative[30]_i_27_n_0 ;
  wire \derivative[30]_i_28_n_0 ;
  wire \derivative[30]_i_29_n_0 ;
  wire \derivative[30]_i_31_n_0 ;
  wire \derivative[30]_i_32_n_0 ;
  wire \derivative[30]_i_33_n_0 ;
  wire \derivative[30]_i_34_n_0 ;
  wire \derivative[30]_i_36_n_0 ;
  wire \derivative[30]_i_37_n_0 ;
  wire \derivative[30]_i_38_n_0 ;
  wire \derivative[30]_i_39_n_0 ;
  wire \derivative[30]_i_3_n_0 ;
  wire \derivative[30]_i_40_n_0 ;
  wire \derivative[30]_i_41_n_0 ;
  wire \derivative[30]_i_42_n_0 ;
  wire \derivative[30]_i_4_n_0 ;
  wire \derivative[30]_i_6_n_0 ;
  wire \derivative[30]_i_7_n_0 ;
  wire \derivative[30]_i_8_n_0 ;
  wire \derivative[30]_i_9_n_0 ;
  wire \derivative[31]_i_10_n_0 ;
  wire \derivative[31]_i_11_n_0 ;
  wire \derivative[31]_i_13_n_0 ;
  wire \derivative[31]_i_14_n_0 ;
  wire \derivative[31]_i_15_n_0 ;
  wire \derivative[31]_i_16_n_0 ;
  wire \derivative[31]_i_17_n_0 ;
  wire \derivative[31]_i_18_n_0 ;
  wire \derivative[31]_i_19_n_0 ;
  wire \derivative[31]_i_20_n_0 ;
  wire \derivative[31]_i_22_n_0 ;
  wire \derivative[31]_i_23_n_0 ;
  wire \derivative[31]_i_24_n_0 ;
  wire \derivative[31]_i_25_n_0 ;
  wire \derivative[31]_i_26_n_0 ;
  wire \derivative[31]_i_27_n_0 ;
  wire \derivative[31]_i_28_n_0 ;
  wire \derivative[31]_i_29_n_0 ;
  wire \derivative[31]_i_31_n_0 ;
  wire \derivative[31]_i_32_n_0 ;
  wire \derivative[31]_i_33_n_0 ;
  wire \derivative[31]_i_34_n_0 ;
  wire \derivative[31]_i_35_n_0 ;
  wire \derivative[31]_i_36_n_0 ;
  wire \derivative[31]_i_37_n_0 ;
  wire \derivative[31]_i_38_n_0 ;
  wire \derivative[31]_i_40_n_0 ;
  wire \derivative[31]_i_41_n_0 ;
  wire \derivative[31]_i_42_n_0 ;
  wire \derivative[31]_i_43_n_0 ;
  wire \derivative[31]_i_44_n_0 ;
  wire \derivative[31]_i_45_n_0 ;
  wire \derivative[31]_i_46_n_0 ;
  wire \derivative[31]_i_47_n_0 ;
  wire \derivative[31]_i_49_n_0 ;
  wire \derivative[31]_i_4_n_0 ;
  wire \derivative[31]_i_50_n_0 ;
  wire \derivative[31]_i_51_n_0 ;
  wire \derivative[31]_i_52_n_0 ;
  wire \derivative[31]_i_53_n_0 ;
  wire \derivative[31]_i_54_n_0 ;
  wire \derivative[31]_i_55_n_0 ;
  wire \derivative[31]_i_56_n_0 ;
  wire \derivative[31]_i_58_n_0 ;
  wire \derivative[31]_i_59_n_0 ;
  wire \derivative[31]_i_5_n_0 ;
  wire \derivative[31]_i_60_n_0 ;
  wire \derivative[31]_i_61_n_0 ;
  wire \derivative[31]_i_62_n_0 ;
  wire \derivative[31]_i_63_n_0 ;
  wire \derivative[31]_i_64_n_0 ;
  wire \derivative[31]_i_65_n_0 ;
  wire \derivative[31]_i_66_n_0 ;
  wire \derivative[31]_i_67_n_0 ;
  wire \derivative[31]_i_68_n_0 ;
  wire \derivative[31]_i_69_n_0 ;
  wire \derivative[31]_i_6_n_0 ;
  wire \derivative[31]_i_70_n_0 ;
  wire \derivative[31]_i_71_n_0 ;
  wire \derivative[31]_i_72_n_0 ;
  wire \derivative[31]_i_7_n_0 ;
  wire \derivative[31]_i_8_n_0 ;
  wire \derivative[31]_i_9_n_0 ;
  wire \derivative[3]_i_11_n_0 ;
  wire \derivative[3]_i_12_n_0 ;
  wire \derivative[3]_i_13_n_0 ;
  wire \derivative[3]_i_14_n_0 ;
  wire \derivative[3]_i_16_n_0 ;
  wire \derivative[3]_i_17_n_0 ;
  wire \derivative[3]_i_18_n_0 ;
  wire \derivative[3]_i_19_n_0 ;
  wire \derivative[3]_i_21_n_0 ;
  wire \derivative[3]_i_22_n_0 ;
  wire \derivative[3]_i_23_n_0 ;
  wire \derivative[3]_i_24_n_0 ;
  wire \derivative[3]_i_26_n_0 ;
  wire \derivative[3]_i_27_n_0 ;
  wire \derivative[3]_i_28_n_0 ;
  wire \derivative[3]_i_29_n_0 ;
  wire \derivative[3]_i_31_n_0 ;
  wire \derivative[3]_i_32_n_0 ;
  wire \derivative[3]_i_33_n_0 ;
  wire \derivative[3]_i_34_n_0 ;
  wire \derivative[3]_i_36_n_0 ;
  wire \derivative[3]_i_37_n_0 ;
  wire \derivative[3]_i_38_n_0 ;
  wire \derivative[3]_i_39_n_0 ;
  wire \derivative[3]_i_3_n_0 ;
  wire \derivative[3]_i_40_n_0 ;
  wire \derivative[3]_i_41_n_0 ;
  wire \derivative[3]_i_42_n_0 ;
  wire \derivative[3]_i_4_n_0 ;
  wire \derivative[3]_i_6_n_0 ;
  wire \derivative[3]_i_7_n_0 ;
  wire \derivative[3]_i_8_n_0 ;
  wire \derivative[3]_i_9_n_0 ;
  wire \derivative[4]_i_11_n_0 ;
  wire \derivative[4]_i_12_n_0 ;
  wire \derivative[4]_i_13_n_0 ;
  wire \derivative[4]_i_14_n_0 ;
  wire \derivative[4]_i_16_n_0 ;
  wire \derivative[4]_i_17_n_0 ;
  wire \derivative[4]_i_18_n_0 ;
  wire \derivative[4]_i_19_n_0 ;
  wire \derivative[4]_i_21_n_0 ;
  wire \derivative[4]_i_22_n_0 ;
  wire \derivative[4]_i_23_n_0 ;
  wire \derivative[4]_i_24_n_0 ;
  wire \derivative[4]_i_26_n_0 ;
  wire \derivative[4]_i_27_n_0 ;
  wire \derivative[4]_i_28_n_0 ;
  wire \derivative[4]_i_29_n_0 ;
  wire \derivative[4]_i_31_n_0 ;
  wire \derivative[4]_i_32_n_0 ;
  wire \derivative[4]_i_33_n_0 ;
  wire \derivative[4]_i_34_n_0 ;
  wire \derivative[4]_i_36_n_0 ;
  wire \derivative[4]_i_37_n_0 ;
  wire \derivative[4]_i_38_n_0 ;
  wire \derivative[4]_i_39_n_0 ;
  wire \derivative[4]_i_3_n_0 ;
  wire \derivative[4]_i_40_n_0 ;
  wire \derivative[4]_i_41_n_0 ;
  wire \derivative[4]_i_42_n_0 ;
  wire \derivative[4]_i_4_n_0 ;
  wire \derivative[4]_i_6_n_0 ;
  wire \derivative[4]_i_7_n_0 ;
  wire \derivative[4]_i_8_n_0 ;
  wire \derivative[4]_i_9_n_0 ;
  wire \derivative[5]_i_11_n_0 ;
  wire \derivative[5]_i_12_n_0 ;
  wire \derivative[5]_i_13_n_0 ;
  wire \derivative[5]_i_14_n_0 ;
  wire \derivative[5]_i_16_n_0 ;
  wire \derivative[5]_i_17_n_0 ;
  wire \derivative[5]_i_18_n_0 ;
  wire \derivative[5]_i_19_n_0 ;
  wire \derivative[5]_i_21_n_0 ;
  wire \derivative[5]_i_22_n_0 ;
  wire \derivative[5]_i_23_n_0 ;
  wire \derivative[5]_i_24_n_0 ;
  wire \derivative[5]_i_26_n_0 ;
  wire \derivative[5]_i_27_n_0 ;
  wire \derivative[5]_i_28_n_0 ;
  wire \derivative[5]_i_29_n_0 ;
  wire \derivative[5]_i_31_n_0 ;
  wire \derivative[5]_i_32_n_0 ;
  wire \derivative[5]_i_33_n_0 ;
  wire \derivative[5]_i_34_n_0 ;
  wire \derivative[5]_i_36_n_0 ;
  wire \derivative[5]_i_37_n_0 ;
  wire \derivative[5]_i_38_n_0 ;
  wire \derivative[5]_i_39_n_0 ;
  wire \derivative[5]_i_3_n_0 ;
  wire \derivative[5]_i_40_n_0 ;
  wire \derivative[5]_i_41_n_0 ;
  wire \derivative[5]_i_42_n_0 ;
  wire \derivative[5]_i_4_n_0 ;
  wire \derivative[5]_i_6_n_0 ;
  wire \derivative[5]_i_7_n_0 ;
  wire \derivative[5]_i_8_n_0 ;
  wire \derivative[5]_i_9_n_0 ;
  wire \derivative[6]_i_11_n_0 ;
  wire \derivative[6]_i_12_n_0 ;
  wire \derivative[6]_i_13_n_0 ;
  wire \derivative[6]_i_14_n_0 ;
  wire \derivative[6]_i_16_n_0 ;
  wire \derivative[6]_i_17_n_0 ;
  wire \derivative[6]_i_18_n_0 ;
  wire \derivative[6]_i_19_n_0 ;
  wire \derivative[6]_i_21_n_0 ;
  wire \derivative[6]_i_22_n_0 ;
  wire \derivative[6]_i_23_n_0 ;
  wire \derivative[6]_i_24_n_0 ;
  wire \derivative[6]_i_26_n_0 ;
  wire \derivative[6]_i_27_n_0 ;
  wire \derivative[6]_i_28_n_0 ;
  wire \derivative[6]_i_29_n_0 ;
  wire \derivative[6]_i_31_n_0 ;
  wire \derivative[6]_i_32_n_0 ;
  wire \derivative[6]_i_33_n_0 ;
  wire \derivative[6]_i_34_n_0 ;
  wire \derivative[6]_i_36_n_0 ;
  wire \derivative[6]_i_37_n_0 ;
  wire \derivative[6]_i_38_n_0 ;
  wire \derivative[6]_i_39_n_0 ;
  wire \derivative[6]_i_3_n_0 ;
  wire \derivative[6]_i_40_n_0 ;
  wire \derivative[6]_i_41_n_0 ;
  wire \derivative[6]_i_42_n_0 ;
  wire \derivative[6]_i_4_n_0 ;
  wire \derivative[6]_i_6_n_0 ;
  wire \derivative[6]_i_7_n_0 ;
  wire \derivative[6]_i_8_n_0 ;
  wire \derivative[6]_i_9_n_0 ;
  wire \derivative[7]_i_11_n_0 ;
  wire \derivative[7]_i_12_n_0 ;
  wire \derivative[7]_i_13_n_0 ;
  wire \derivative[7]_i_14_n_0 ;
  wire \derivative[7]_i_16_n_0 ;
  wire \derivative[7]_i_17_n_0 ;
  wire \derivative[7]_i_18_n_0 ;
  wire \derivative[7]_i_19_n_0 ;
  wire \derivative[7]_i_21_n_0 ;
  wire \derivative[7]_i_22_n_0 ;
  wire \derivative[7]_i_23_n_0 ;
  wire \derivative[7]_i_24_n_0 ;
  wire \derivative[7]_i_26_n_0 ;
  wire \derivative[7]_i_27_n_0 ;
  wire \derivative[7]_i_28_n_0 ;
  wire \derivative[7]_i_29_n_0 ;
  wire \derivative[7]_i_31_n_0 ;
  wire \derivative[7]_i_32_n_0 ;
  wire \derivative[7]_i_33_n_0 ;
  wire \derivative[7]_i_34_n_0 ;
  wire \derivative[7]_i_36_n_0 ;
  wire \derivative[7]_i_37_n_0 ;
  wire \derivative[7]_i_38_n_0 ;
  wire \derivative[7]_i_39_n_0 ;
  wire \derivative[7]_i_3_n_0 ;
  wire \derivative[7]_i_40_n_0 ;
  wire \derivative[7]_i_41_n_0 ;
  wire \derivative[7]_i_42_n_0 ;
  wire \derivative[7]_i_4_n_0 ;
  wire \derivative[7]_i_6_n_0 ;
  wire \derivative[7]_i_7_n_0 ;
  wire \derivative[7]_i_8_n_0 ;
  wire \derivative[7]_i_9_n_0 ;
  wire \derivative[8]_i_11_n_0 ;
  wire \derivative[8]_i_12_n_0 ;
  wire \derivative[8]_i_13_n_0 ;
  wire \derivative[8]_i_14_n_0 ;
  wire \derivative[8]_i_16_n_0 ;
  wire \derivative[8]_i_17_n_0 ;
  wire \derivative[8]_i_18_n_0 ;
  wire \derivative[8]_i_19_n_0 ;
  wire \derivative[8]_i_21_n_0 ;
  wire \derivative[8]_i_22_n_0 ;
  wire \derivative[8]_i_23_n_0 ;
  wire \derivative[8]_i_24_n_0 ;
  wire \derivative[8]_i_26_n_0 ;
  wire \derivative[8]_i_27_n_0 ;
  wire \derivative[8]_i_28_n_0 ;
  wire \derivative[8]_i_29_n_0 ;
  wire \derivative[8]_i_31_n_0 ;
  wire \derivative[8]_i_32_n_0 ;
  wire \derivative[8]_i_33_n_0 ;
  wire \derivative[8]_i_34_n_0 ;
  wire \derivative[8]_i_36_n_0 ;
  wire \derivative[8]_i_37_n_0 ;
  wire \derivative[8]_i_38_n_0 ;
  wire \derivative[8]_i_39_n_0 ;
  wire \derivative[8]_i_3_n_0 ;
  wire \derivative[8]_i_40_n_0 ;
  wire \derivative[8]_i_41_n_0 ;
  wire \derivative[8]_i_42_n_0 ;
  wire \derivative[8]_i_4_n_0 ;
  wire \derivative[8]_i_6_n_0 ;
  wire \derivative[8]_i_7_n_0 ;
  wire \derivative[8]_i_8_n_0 ;
  wire \derivative[8]_i_9_n_0 ;
  wire \derivative[9]_i_11_n_0 ;
  wire \derivative[9]_i_12_n_0 ;
  wire \derivative[9]_i_13_n_0 ;
  wire \derivative[9]_i_14_n_0 ;
  wire \derivative[9]_i_16_n_0 ;
  wire \derivative[9]_i_17_n_0 ;
  wire \derivative[9]_i_18_n_0 ;
  wire \derivative[9]_i_19_n_0 ;
  wire \derivative[9]_i_21_n_0 ;
  wire \derivative[9]_i_22_n_0 ;
  wire \derivative[9]_i_23_n_0 ;
  wire \derivative[9]_i_24_n_0 ;
  wire \derivative[9]_i_26_n_0 ;
  wire \derivative[9]_i_27_n_0 ;
  wire \derivative[9]_i_28_n_0 ;
  wire \derivative[9]_i_29_n_0 ;
  wire \derivative[9]_i_31_n_0 ;
  wire \derivative[9]_i_32_n_0 ;
  wire \derivative[9]_i_33_n_0 ;
  wire \derivative[9]_i_34_n_0 ;
  wire \derivative[9]_i_36_n_0 ;
  wire \derivative[9]_i_37_n_0 ;
  wire \derivative[9]_i_38_n_0 ;
  wire \derivative[9]_i_39_n_0 ;
  wire \derivative[9]_i_3_n_0 ;
  wire \derivative[9]_i_40_n_0 ;
  wire \derivative[9]_i_41_n_0 ;
  wire \derivative[9]_i_42_n_0 ;
  wire \derivative[9]_i_4_n_0 ;
  wire \derivative[9]_i_6_n_0 ;
  wire \derivative[9]_i_7_n_0 ;
  wire \derivative[9]_i_8_n_0 ;
  wire \derivative[9]_i_9_n_0 ;
  wire [31:0]derivative_out;
  wire \derivative_reg[0]_i_14_n_0 ;
  wire \derivative_reg[0]_i_14_n_1 ;
  wire \derivative_reg[0]_i_14_n_2 ;
  wire \derivative_reg[0]_i_14_n_3 ;
  wire \derivative_reg[0]_i_19_n_0 ;
  wire \derivative_reg[0]_i_19_n_1 ;
  wire \derivative_reg[0]_i_19_n_2 ;
  wire \derivative_reg[0]_i_19_n_3 ;
  wire \derivative_reg[0]_i_1_n_3 ;
  wire \derivative_reg[0]_i_24_n_0 ;
  wire \derivative_reg[0]_i_24_n_1 ;
  wire \derivative_reg[0]_i_24_n_2 ;
  wire \derivative_reg[0]_i_24_n_3 ;
  wire \derivative_reg[0]_i_29_n_0 ;
  wire \derivative_reg[0]_i_29_n_1 ;
  wire \derivative_reg[0]_i_29_n_2 ;
  wire \derivative_reg[0]_i_29_n_3 ;
  wire \derivative_reg[0]_i_2_n_0 ;
  wire \derivative_reg[0]_i_2_n_1 ;
  wire \derivative_reg[0]_i_2_n_2 ;
  wire \derivative_reg[0]_i_2_n_3 ;
  wire \derivative_reg[0]_i_34_n_0 ;
  wire \derivative_reg[0]_i_34_n_1 ;
  wire \derivative_reg[0]_i_34_n_2 ;
  wire \derivative_reg[0]_i_34_n_3 ;
  wire \derivative_reg[0]_i_4_n_0 ;
  wire \derivative_reg[0]_i_4_n_1 ;
  wire \derivative_reg[0]_i_4_n_2 ;
  wire \derivative_reg[0]_i_4_n_3 ;
  wire \derivative_reg[0]_i_9_n_0 ;
  wire \derivative_reg[0]_i_9_n_1 ;
  wire \derivative_reg[0]_i_9_n_2 ;
  wire \derivative_reg[0]_i_9_n_3 ;
  wire \derivative_reg[10]_i_10_n_0 ;
  wire \derivative_reg[10]_i_10_n_1 ;
  wire \derivative_reg[10]_i_10_n_2 ;
  wire \derivative_reg[10]_i_10_n_3 ;
  wire \derivative_reg[10]_i_10_n_4 ;
  wire \derivative_reg[10]_i_10_n_5 ;
  wire \derivative_reg[10]_i_10_n_6 ;
  wire \derivative_reg[10]_i_10_n_7 ;
  wire \derivative_reg[10]_i_15_n_0 ;
  wire \derivative_reg[10]_i_15_n_1 ;
  wire \derivative_reg[10]_i_15_n_2 ;
  wire \derivative_reg[10]_i_15_n_3 ;
  wire \derivative_reg[10]_i_15_n_4 ;
  wire \derivative_reg[10]_i_15_n_5 ;
  wire \derivative_reg[10]_i_15_n_6 ;
  wire \derivative_reg[10]_i_15_n_7 ;
  wire \derivative_reg[10]_i_1_n_2 ;
  wire \derivative_reg[10]_i_1_n_3 ;
  wire \derivative_reg[10]_i_1_n_7 ;
  wire \derivative_reg[10]_i_20_n_0 ;
  wire \derivative_reg[10]_i_20_n_1 ;
  wire \derivative_reg[10]_i_20_n_2 ;
  wire \derivative_reg[10]_i_20_n_3 ;
  wire \derivative_reg[10]_i_20_n_4 ;
  wire \derivative_reg[10]_i_20_n_5 ;
  wire \derivative_reg[10]_i_20_n_6 ;
  wire \derivative_reg[10]_i_20_n_7 ;
  wire \derivative_reg[10]_i_25_n_0 ;
  wire \derivative_reg[10]_i_25_n_1 ;
  wire \derivative_reg[10]_i_25_n_2 ;
  wire \derivative_reg[10]_i_25_n_3 ;
  wire \derivative_reg[10]_i_25_n_4 ;
  wire \derivative_reg[10]_i_25_n_5 ;
  wire \derivative_reg[10]_i_25_n_6 ;
  wire \derivative_reg[10]_i_25_n_7 ;
  wire \derivative_reg[10]_i_2_n_0 ;
  wire \derivative_reg[10]_i_2_n_1 ;
  wire \derivative_reg[10]_i_2_n_2 ;
  wire \derivative_reg[10]_i_2_n_3 ;
  wire \derivative_reg[10]_i_2_n_4 ;
  wire \derivative_reg[10]_i_2_n_5 ;
  wire \derivative_reg[10]_i_2_n_6 ;
  wire \derivative_reg[10]_i_2_n_7 ;
  wire \derivative_reg[10]_i_30_n_0 ;
  wire \derivative_reg[10]_i_30_n_1 ;
  wire \derivative_reg[10]_i_30_n_2 ;
  wire \derivative_reg[10]_i_30_n_3 ;
  wire \derivative_reg[10]_i_30_n_4 ;
  wire \derivative_reg[10]_i_30_n_5 ;
  wire \derivative_reg[10]_i_30_n_6 ;
  wire \derivative_reg[10]_i_30_n_7 ;
  wire \derivative_reg[10]_i_35_n_0 ;
  wire \derivative_reg[10]_i_35_n_1 ;
  wire \derivative_reg[10]_i_35_n_2 ;
  wire \derivative_reg[10]_i_35_n_3 ;
  wire \derivative_reg[10]_i_35_n_4 ;
  wire \derivative_reg[10]_i_35_n_5 ;
  wire \derivative_reg[10]_i_35_n_6 ;
  wire \derivative_reg[10]_i_5_n_0 ;
  wire \derivative_reg[10]_i_5_n_1 ;
  wire \derivative_reg[10]_i_5_n_2 ;
  wire \derivative_reg[10]_i_5_n_3 ;
  wire \derivative_reg[10]_i_5_n_4 ;
  wire \derivative_reg[10]_i_5_n_5 ;
  wire \derivative_reg[10]_i_5_n_6 ;
  wire \derivative_reg[10]_i_5_n_7 ;
  wire \derivative_reg[11]_i_10_n_0 ;
  wire \derivative_reg[11]_i_10_n_1 ;
  wire \derivative_reg[11]_i_10_n_2 ;
  wire \derivative_reg[11]_i_10_n_3 ;
  wire \derivative_reg[11]_i_10_n_4 ;
  wire \derivative_reg[11]_i_10_n_5 ;
  wire \derivative_reg[11]_i_10_n_6 ;
  wire \derivative_reg[11]_i_10_n_7 ;
  wire \derivative_reg[11]_i_15_n_0 ;
  wire \derivative_reg[11]_i_15_n_1 ;
  wire \derivative_reg[11]_i_15_n_2 ;
  wire \derivative_reg[11]_i_15_n_3 ;
  wire \derivative_reg[11]_i_15_n_4 ;
  wire \derivative_reg[11]_i_15_n_5 ;
  wire \derivative_reg[11]_i_15_n_6 ;
  wire \derivative_reg[11]_i_15_n_7 ;
  wire \derivative_reg[11]_i_1_n_2 ;
  wire \derivative_reg[11]_i_1_n_3 ;
  wire \derivative_reg[11]_i_1_n_7 ;
  wire \derivative_reg[11]_i_20_n_0 ;
  wire \derivative_reg[11]_i_20_n_1 ;
  wire \derivative_reg[11]_i_20_n_2 ;
  wire \derivative_reg[11]_i_20_n_3 ;
  wire \derivative_reg[11]_i_20_n_4 ;
  wire \derivative_reg[11]_i_20_n_5 ;
  wire \derivative_reg[11]_i_20_n_6 ;
  wire \derivative_reg[11]_i_20_n_7 ;
  wire \derivative_reg[11]_i_25_n_0 ;
  wire \derivative_reg[11]_i_25_n_1 ;
  wire \derivative_reg[11]_i_25_n_2 ;
  wire \derivative_reg[11]_i_25_n_3 ;
  wire \derivative_reg[11]_i_25_n_4 ;
  wire \derivative_reg[11]_i_25_n_5 ;
  wire \derivative_reg[11]_i_25_n_6 ;
  wire \derivative_reg[11]_i_25_n_7 ;
  wire \derivative_reg[11]_i_2_n_0 ;
  wire \derivative_reg[11]_i_2_n_1 ;
  wire \derivative_reg[11]_i_2_n_2 ;
  wire \derivative_reg[11]_i_2_n_3 ;
  wire \derivative_reg[11]_i_2_n_4 ;
  wire \derivative_reg[11]_i_2_n_5 ;
  wire \derivative_reg[11]_i_2_n_6 ;
  wire \derivative_reg[11]_i_2_n_7 ;
  wire \derivative_reg[11]_i_30_n_0 ;
  wire \derivative_reg[11]_i_30_n_1 ;
  wire \derivative_reg[11]_i_30_n_2 ;
  wire \derivative_reg[11]_i_30_n_3 ;
  wire \derivative_reg[11]_i_30_n_4 ;
  wire \derivative_reg[11]_i_30_n_5 ;
  wire \derivative_reg[11]_i_30_n_6 ;
  wire \derivative_reg[11]_i_30_n_7 ;
  wire \derivative_reg[11]_i_35_n_0 ;
  wire \derivative_reg[11]_i_35_n_1 ;
  wire \derivative_reg[11]_i_35_n_2 ;
  wire \derivative_reg[11]_i_35_n_3 ;
  wire \derivative_reg[11]_i_35_n_4 ;
  wire \derivative_reg[11]_i_35_n_5 ;
  wire \derivative_reg[11]_i_35_n_6 ;
  wire \derivative_reg[11]_i_5_n_0 ;
  wire \derivative_reg[11]_i_5_n_1 ;
  wire \derivative_reg[11]_i_5_n_2 ;
  wire \derivative_reg[11]_i_5_n_3 ;
  wire \derivative_reg[11]_i_5_n_4 ;
  wire \derivative_reg[11]_i_5_n_5 ;
  wire \derivative_reg[11]_i_5_n_6 ;
  wire \derivative_reg[11]_i_5_n_7 ;
  wire \derivative_reg[12]_i_10_n_0 ;
  wire \derivative_reg[12]_i_10_n_1 ;
  wire \derivative_reg[12]_i_10_n_2 ;
  wire \derivative_reg[12]_i_10_n_3 ;
  wire \derivative_reg[12]_i_10_n_4 ;
  wire \derivative_reg[12]_i_10_n_5 ;
  wire \derivative_reg[12]_i_10_n_6 ;
  wire \derivative_reg[12]_i_10_n_7 ;
  wire \derivative_reg[12]_i_15_n_0 ;
  wire \derivative_reg[12]_i_15_n_1 ;
  wire \derivative_reg[12]_i_15_n_2 ;
  wire \derivative_reg[12]_i_15_n_3 ;
  wire \derivative_reg[12]_i_15_n_4 ;
  wire \derivative_reg[12]_i_15_n_5 ;
  wire \derivative_reg[12]_i_15_n_6 ;
  wire \derivative_reg[12]_i_15_n_7 ;
  wire \derivative_reg[12]_i_1_n_2 ;
  wire \derivative_reg[12]_i_1_n_3 ;
  wire \derivative_reg[12]_i_1_n_7 ;
  wire \derivative_reg[12]_i_20_n_0 ;
  wire \derivative_reg[12]_i_20_n_1 ;
  wire \derivative_reg[12]_i_20_n_2 ;
  wire \derivative_reg[12]_i_20_n_3 ;
  wire \derivative_reg[12]_i_20_n_4 ;
  wire \derivative_reg[12]_i_20_n_5 ;
  wire \derivative_reg[12]_i_20_n_6 ;
  wire \derivative_reg[12]_i_20_n_7 ;
  wire \derivative_reg[12]_i_25_n_0 ;
  wire \derivative_reg[12]_i_25_n_1 ;
  wire \derivative_reg[12]_i_25_n_2 ;
  wire \derivative_reg[12]_i_25_n_3 ;
  wire \derivative_reg[12]_i_25_n_4 ;
  wire \derivative_reg[12]_i_25_n_5 ;
  wire \derivative_reg[12]_i_25_n_6 ;
  wire \derivative_reg[12]_i_25_n_7 ;
  wire \derivative_reg[12]_i_2_n_0 ;
  wire \derivative_reg[12]_i_2_n_1 ;
  wire \derivative_reg[12]_i_2_n_2 ;
  wire \derivative_reg[12]_i_2_n_3 ;
  wire \derivative_reg[12]_i_2_n_4 ;
  wire \derivative_reg[12]_i_2_n_5 ;
  wire \derivative_reg[12]_i_2_n_6 ;
  wire \derivative_reg[12]_i_2_n_7 ;
  wire \derivative_reg[12]_i_30_n_0 ;
  wire \derivative_reg[12]_i_30_n_1 ;
  wire \derivative_reg[12]_i_30_n_2 ;
  wire \derivative_reg[12]_i_30_n_3 ;
  wire \derivative_reg[12]_i_30_n_4 ;
  wire \derivative_reg[12]_i_30_n_5 ;
  wire \derivative_reg[12]_i_30_n_6 ;
  wire \derivative_reg[12]_i_30_n_7 ;
  wire \derivative_reg[12]_i_35_n_0 ;
  wire \derivative_reg[12]_i_35_n_1 ;
  wire \derivative_reg[12]_i_35_n_2 ;
  wire \derivative_reg[12]_i_35_n_3 ;
  wire \derivative_reg[12]_i_35_n_4 ;
  wire \derivative_reg[12]_i_35_n_5 ;
  wire \derivative_reg[12]_i_35_n_6 ;
  wire \derivative_reg[12]_i_5_n_0 ;
  wire \derivative_reg[12]_i_5_n_1 ;
  wire \derivative_reg[12]_i_5_n_2 ;
  wire \derivative_reg[12]_i_5_n_3 ;
  wire \derivative_reg[12]_i_5_n_4 ;
  wire \derivative_reg[12]_i_5_n_5 ;
  wire \derivative_reg[12]_i_5_n_6 ;
  wire \derivative_reg[12]_i_5_n_7 ;
  wire \derivative_reg[13]_i_10_n_0 ;
  wire \derivative_reg[13]_i_10_n_1 ;
  wire \derivative_reg[13]_i_10_n_2 ;
  wire \derivative_reg[13]_i_10_n_3 ;
  wire \derivative_reg[13]_i_10_n_4 ;
  wire \derivative_reg[13]_i_10_n_5 ;
  wire \derivative_reg[13]_i_10_n_6 ;
  wire \derivative_reg[13]_i_10_n_7 ;
  wire \derivative_reg[13]_i_15_n_0 ;
  wire \derivative_reg[13]_i_15_n_1 ;
  wire \derivative_reg[13]_i_15_n_2 ;
  wire \derivative_reg[13]_i_15_n_3 ;
  wire \derivative_reg[13]_i_15_n_4 ;
  wire \derivative_reg[13]_i_15_n_5 ;
  wire \derivative_reg[13]_i_15_n_6 ;
  wire \derivative_reg[13]_i_15_n_7 ;
  wire \derivative_reg[13]_i_1_n_2 ;
  wire \derivative_reg[13]_i_1_n_3 ;
  wire \derivative_reg[13]_i_1_n_7 ;
  wire \derivative_reg[13]_i_20_n_0 ;
  wire \derivative_reg[13]_i_20_n_1 ;
  wire \derivative_reg[13]_i_20_n_2 ;
  wire \derivative_reg[13]_i_20_n_3 ;
  wire \derivative_reg[13]_i_20_n_4 ;
  wire \derivative_reg[13]_i_20_n_5 ;
  wire \derivative_reg[13]_i_20_n_6 ;
  wire \derivative_reg[13]_i_20_n_7 ;
  wire \derivative_reg[13]_i_25_n_0 ;
  wire \derivative_reg[13]_i_25_n_1 ;
  wire \derivative_reg[13]_i_25_n_2 ;
  wire \derivative_reg[13]_i_25_n_3 ;
  wire \derivative_reg[13]_i_25_n_4 ;
  wire \derivative_reg[13]_i_25_n_5 ;
  wire \derivative_reg[13]_i_25_n_6 ;
  wire \derivative_reg[13]_i_25_n_7 ;
  wire \derivative_reg[13]_i_2_n_0 ;
  wire \derivative_reg[13]_i_2_n_1 ;
  wire \derivative_reg[13]_i_2_n_2 ;
  wire \derivative_reg[13]_i_2_n_3 ;
  wire \derivative_reg[13]_i_2_n_4 ;
  wire \derivative_reg[13]_i_2_n_5 ;
  wire \derivative_reg[13]_i_2_n_6 ;
  wire \derivative_reg[13]_i_2_n_7 ;
  wire \derivative_reg[13]_i_30_n_0 ;
  wire \derivative_reg[13]_i_30_n_1 ;
  wire \derivative_reg[13]_i_30_n_2 ;
  wire \derivative_reg[13]_i_30_n_3 ;
  wire \derivative_reg[13]_i_30_n_4 ;
  wire \derivative_reg[13]_i_30_n_5 ;
  wire \derivative_reg[13]_i_30_n_6 ;
  wire \derivative_reg[13]_i_30_n_7 ;
  wire \derivative_reg[13]_i_35_n_0 ;
  wire \derivative_reg[13]_i_35_n_1 ;
  wire \derivative_reg[13]_i_35_n_2 ;
  wire \derivative_reg[13]_i_35_n_3 ;
  wire \derivative_reg[13]_i_35_n_4 ;
  wire \derivative_reg[13]_i_35_n_5 ;
  wire \derivative_reg[13]_i_35_n_6 ;
  wire \derivative_reg[13]_i_5_n_0 ;
  wire \derivative_reg[13]_i_5_n_1 ;
  wire \derivative_reg[13]_i_5_n_2 ;
  wire \derivative_reg[13]_i_5_n_3 ;
  wire \derivative_reg[13]_i_5_n_4 ;
  wire \derivative_reg[13]_i_5_n_5 ;
  wire \derivative_reg[13]_i_5_n_6 ;
  wire \derivative_reg[13]_i_5_n_7 ;
  wire \derivative_reg[14]_i_10_n_0 ;
  wire \derivative_reg[14]_i_10_n_1 ;
  wire \derivative_reg[14]_i_10_n_2 ;
  wire \derivative_reg[14]_i_10_n_3 ;
  wire \derivative_reg[14]_i_10_n_4 ;
  wire \derivative_reg[14]_i_10_n_5 ;
  wire \derivative_reg[14]_i_10_n_6 ;
  wire \derivative_reg[14]_i_10_n_7 ;
  wire \derivative_reg[14]_i_15_n_0 ;
  wire \derivative_reg[14]_i_15_n_1 ;
  wire \derivative_reg[14]_i_15_n_2 ;
  wire \derivative_reg[14]_i_15_n_3 ;
  wire \derivative_reg[14]_i_15_n_4 ;
  wire \derivative_reg[14]_i_15_n_5 ;
  wire \derivative_reg[14]_i_15_n_6 ;
  wire \derivative_reg[14]_i_15_n_7 ;
  wire \derivative_reg[14]_i_1_n_2 ;
  wire \derivative_reg[14]_i_1_n_3 ;
  wire \derivative_reg[14]_i_1_n_7 ;
  wire \derivative_reg[14]_i_20_n_0 ;
  wire \derivative_reg[14]_i_20_n_1 ;
  wire \derivative_reg[14]_i_20_n_2 ;
  wire \derivative_reg[14]_i_20_n_3 ;
  wire \derivative_reg[14]_i_20_n_4 ;
  wire \derivative_reg[14]_i_20_n_5 ;
  wire \derivative_reg[14]_i_20_n_6 ;
  wire \derivative_reg[14]_i_20_n_7 ;
  wire \derivative_reg[14]_i_25_n_0 ;
  wire \derivative_reg[14]_i_25_n_1 ;
  wire \derivative_reg[14]_i_25_n_2 ;
  wire \derivative_reg[14]_i_25_n_3 ;
  wire \derivative_reg[14]_i_25_n_4 ;
  wire \derivative_reg[14]_i_25_n_5 ;
  wire \derivative_reg[14]_i_25_n_6 ;
  wire \derivative_reg[14]_i_25_n_7 ;
  wire \derivative_reg[14]_i_2_n_0 ;
  wire \derivative_reg[14]_i_2_n_1 ;
  wire \derivative_reg[14]_i_2_n_2 ;
  wire \derivative_reg[14]_i_2_n_3 ;
  wire \derivative_reg[14]_i_2_n_4 ;
  wire \derivative_reg[14]_i_2_n_5 ;
  wire \derivative_reg[14]_i_2_n_6 ;
  wire \derivative_reg[14]_i_2_n_7 ;
  wire \derivative_reg[14]_i_30_n_0 ;
  wire \derivative_reg[14]_i_30_n_1 ;
  wire \derivative_reg[14]_i_30_n_2 ;
  wire \derivative_reg[14]_i_30_n_3 ;
  wire \derivative_reg[14]_i_30_n_4 ;
  wire \derivative_reg[14]_i_30_n_5 ;
  wire \derivative_reg[14]_i_30_n_6 ;
  wire \derivative_reg[14]_i_30_n_7 ;
  wire \derivative_reg[14]_i_35_n_0 ;
  wire \derivative_reg[14]_i_35_n_1 ;
  wire \derivative_reg[14]_i_35_n_2 ;
  wire \derivative_reg[14]_i_35_n_3 ;
  wire \derivative_reg[14]_i_35_n_4 ;
  wire \derivative_reg[14]_i_35_n_5 ;
  wire \derivative_reg[14]_i_35_n_6 ;
  wire \derivative_reg[14]_i_5_n_0 ;
  wire \derivative_reg[14]_i_5_n_1 ;
  wire \derivative_reg[14]_i_5_n_2 ;
  wire \derivative_reg[14]_i_5_n_3 ;
  wire \derivative_reg[14]_i_5_n_4 ;
  wire \derivative_reg[14]_i_5_n_5 ;
  wire \derivative_reg[14]_i_5_n_6 ;
  wire \derivative_reg[14]_i_5_n_7 ;
  wire \derivative_reg[15]_i_10_n_0 ;
  wire \derivative_reg[15]_i_10_n_1 ;
  wire \derivative_reg[15]_i_10_n_2 ;
  wire \derivative_reg[15]_i_10_n_3 ;
  wire \derivative_reg[15]_i_10_n_4 ;
  wire \derivative_reg[15]_i_10_n_5 ;
  wire \derivative_reg[15]_i_10_n_6 ;
  wire \derivative_reg[15]_i_10_n_7 ;
  wire \derivative_reg[15]_i_15_n_0 ;
  wire \derivative_reg[15]_i_15_n_1 ;
  wire \derivative_reg[15]_i_15_n_2 ;
  wire \derivative_reg[15]_i_15_n_3 ;
  wire \derivative_reg[15]_i_15_n_4 ;
  wire \derivative_reg[15]_i_15_n_5 ;
  wire \derivative_reg[15]_i_15_n_6 ;
  wire \derivative_reg[15]_i_15_n_7 ;
  wire \derivative_reg[15]_i_1_n_2 ;
  wire \derivative_reg[15]_i_1_n_3 ;
  wire \derivative_reg[15]_i_1_n_7 ;
  wire \derivative_reg[15]_i_20_n_0 ;
  wire \derivative_reg[15]_i_20_n_1 ;
  wire \derivative_reg[15]_i_20_n_2 ;
  wire \derivative_reg[15]_i_20_n_3 ;
  wire \derivative_reg[15]_i_20_n_4 ;
  wire \derivative_reg[15]_i_20_n_5 ;
  wire \derivative_reg[15]_i_20_n_6 ;
  wire \derivative_reg[15]_i_20_n_7 ;
  wire \derivative_reg[15]_i_25_n_0 ;
  wire \derivative_reg[15]_i_25_n_1 ;
  wire \derivative_reg[15]_i_25_n_2 ;
  wire \derivative_reg[15]_i_25_n_3 ;
  wire \derivative_reg[15]_i_25_n_4 ;
  wire \derivative_reg[15]_i_25_n_5 ;
  wire \derivative_reg[15]_i_25_n_6 ;
  wire \derivative_reg[15]_i_25_n_7 ;
  wire \derivative_reg[15]_i_2_n_0 ;
  wire \derivative_reg[15]_i_2_n_1 ;
  wire \derivative_reg[15]_i_2_n_2 ;
  wire \derivative_reg[15]_i_2_n_3 ;
  wire \derivative_reg[15]_i_2_n_4 ;
  wire \derivative_reg[15]_i_2_n_5 ;
  wire \derivative_reg[15]_i_2_n_6 ;
  wire \derivative_reg[15]_i_2_n_7 ;
  wire \derivative_reg[15]_i_30_n_0 ;
  wire \derivative_reg[15]_i_30_n_1 ;
  wire \derivative_reg[15]_i_30_n_2 ;
  wire \derivative_reg[15]_i_30_n_3 ;
  wire \derivative_reg[15]_i_30_n_4 ;
  wire \derivative_reg[15]_i_30_n_5 ;
  wire \derivative_reg[15]_i_30_n_6 ;
  wire \derivative_reg[15]_i_30_n_7 ;
  wire \derivative_reg[15]_i_35_n_0 ;
  wire \derivative_reg[15]_i_35_n_1 ;
  wire \derivative_reg[15]_i_35_n_2 ;
  wire \derivative_reg[15]_i_35_n_3 ;
  wire \derivative_reg[15]_i_35_n_4 ;
  wire \derivative_reg[15]_i_35_n_5 ;
  wire \derivative_reg[15]_i_35_n_6 ;
  wire \derivative_reg[15]_i_5_n_0 ;
  wire \derivative_reg[15]_i_5_n_1 ;
  wire \derivative_reg[15]_i_5_n_2 ;
  wire \derivative_reg[15]_i_5_n_3 ;
  wire \derivative_reg[15]_i_5_n_4 ;
  wire \derivative_reg[15]_i_5_n_5 ;
  wire \derivative_reg[15]_i_5_n_6 ;
  wire \derivative_reg[15]_i_5_n_7 ;
  wire \derivative_reg[16]_i_10_n_0 ;
  wire \derivative_reg[16]_i_10_n_1 ;
  wire \derivative_reg[16]_i_10_n_2 ;
  wire \derivative_reg[16]_i_10_n_3 ;
  wire \derivative_reg[16]_i_10_n_4 ;
  wire \derivative_reg[16]_i_10_n_5 ;
  wire \derivative_reg[16]_i_10_n_6 ;
  wire \derivative_reg[16]_i_10_n_7 ;
  wire \derivative_reg[16]_i_15_n_0 ;
  wire \derivative_reg[16]_i_15_n_1 ;
  wire \derivative_reg[16]_i_15_n_2 ;
  wire \derivative_reg[16]_i_15_n_3 ;
  wire \derivative_reg[16]_i_15_n_4 ;
  wire \derivative_reg[16]_i_15_n_5 ;
  wire \derivative_reg[16]_i_15_n_6 ;
  wire \derivative_reg[16]_i_15_n_7 ;
  wire \derivative_reg[16]_i_1_n_2 ;
  wire \derivative_reg[16]_i_1_n_3 ;
  wire \derivative_reg[16]_i_1_n_7 ;
  wire \derivative_reg[16]_i_20_n_0 ;
  wire \derivative_reg[16]_i_20_n_1 ;
  wire \derivative_reg[16]_i_20_n_2 ;
  wire \derivative_reg[16]_i_20_n_3 ;
  wire \derivative_reg[16]_i_20_n_4 ;
  wire \derivative_reg[16]_i_20_n_5 ;
  wire \derivative_reg[16]_i_20_n_6 ;
  wire \derivative_reg[16]_i_20_n_7 ;
  wire \derivative_reg[16]_i_25_n_0 ;
  wire \derivative_reg[16]_i_25_n_1 ;
  wire \derivative_reg[16]_i_25_n_2 ;
  wire \derivative_reg[16]_i_25_n_3 ;
  wire \derivative_reg[16]_i_25_n_4 ;
  wire \derivative_reg[16]_i_25_n_5 ;
  wire \derivative_reg[16]_i_25_n_6 ;
  wire \derivative_reg[16]_i_25_n_7 ;
  wire \derivative_reg[16]_i_2_n_0 ;
  wire \derivative_reg[16]_i_2_n_1 ;
  wire \derivative_reg[16]_i_2_n_2 ;
  wire \derivative_reg[16]_i_2_n_3 ;
  wire \derivative_reg[16]_i_2_n_4 ;
  wire \derivative_reg[16]_i_2_n_5 ;
  wire \derivative_reg[16]_i_2_n_6 ;
  wire \derivative_reg[16]_i_2_n_7 ;
  wire \derivative_reg[16]_i_30_n_0 ;
  wire \derivative_reg[16]_i_30_n_1 ;
  wire \derivative_reg[16]_i_30_n_2 ;
  wire \derivative_reg[16]_i_30_n_3 ;
  wire \derivative_reg[16]_i_30_n_4 ;
  wire \derivative_reg[16]_i_30_n_5 ;
  wire \derivative_reg[16]_i_30_n_6 ;
  wire \derivative_reg[16]_i_30_n_7 ;
  wire \derivative_reg[16]_i_35_n_0 ;
  wire \derivative_reg[16]_i_35_n_1 ;
  wire \derivative_reg[16]_i_35_n_2 ;
  wire \derivative_reg[16]_i_35_n_3 ;
  wire \derivative_reg[16]_i_35_n_4 ;
  wire \derivative_reg[16]_i_35_n_5 ;
  wire \derivative_reg[16]_i_35_n_6 ;
  wire \derivative_reg[16]_i_5_n_0 ;
  wire \derivative_reg[16]_i_5_n_1 ;
  wire \derivative_reg[16]_i_5_n_2 ;
  wire \derivative_reg[16]_i_5_n_3 ;
  wire \derivative_reg[16]_i_5_n_4 ;
  wire \derivative_reg[16]_i_5_n_5 ;
  wire \derivative_reg[16]_i_5_n_6 ;
  wire \derivative_reg[16]_i_5_n_7 ;
  wire \derivative_reg[17]_i_10_n_0 ;
  wire \derivative_reg[17]_i_10_n_1 ;
  wire \derivative_reg[17]_i_10_n_2 ;
  wire \derivative_reg[17]_i_10_n_3 ;
  wire \derivative_reg[17]_i_10_n_4 ;
  wire \derivative_reg[17]_i_10_n_5 ;
  wire \derivative_reg[17]_i_10_n_6 ;
  wire \derivative_reg[17]_i_10_n_7 ;
  wire \derivative_reg[17]_i_15_n_0 ;
  wire \derivative_reg[17]_i_15_n_1 ;
  wire \derivative_reg[17]_i_15_n_2 ;
  wire \derivative_reg[17]_i_15_n_3 ;
  wire \derivative_reg[17]_i_15_n_4 ;
  wire \derivative_reg[17]_i_15_n_5 ;
  wire \derivative_reg[17]_i_15_n_6 ;
  wire \derivative_reg[17]_i_15_n_7 ;
  wire \derivative_reg[17]_i_1_n_2 ;
  wire \derivative_reg[17]_i_1_n_3 ;
  wire \derivative_reg[17]_i_1_n_7 ;
  wire \derivative_reg[17]_i_20_n_0 ;
  wire \derivative_reg[17]_i_20_n_1 ;
  wire \derivative_reg[17]_i_20_n_2 ;
  wire \derivative_reg[17]_i_20_n_3 ;
  wire \derivative_reg[17]_i_20_n_4 ;
  wire \derivative_reg[17]_i_20_n_5 ;
  wire \derivative_reg[17]_i_20_n_6 ;
  wire \derivative_reg[17]_i_20_n_7 ;
  wire \derivative_reg[17]_i_25_n_0 ;
  wire \derivative_reg[17]_i_25_n_1 ;
  wire \derivative_reg[17]_i_25_n_2 ;
  wire \derivative_reg[17]_i_25_n_3 ;
  wire \derivative_reg[17]_i_25_n_4 ;
  wire \derivative_reg[17]_i_25_n_5 ;
  wire \derivative_reg[17]_i_25_n_6 ;
  wire \derivative_reg[17]_i_25_n_7 ;
  wire \derivative_reg[17]_i_2_n_0 ;
  wire \derivative_reg[17]_i_2_n_1 ;
  wire \derivative_reg[17]_i_2_n_2 ;
  wire \derivative_reg[17]_i_2_n_3 ;
  wire \derivative_reg[17]_i_2_n_4 ;
  wire \derivative_reg[17]_i_2_n_5 ;
  wire \derivative_reg[17]_i_2_n_6 ;
  wire \derivative_reg[17]_i_2_n_7 ;
  wire \derivative_reg[17]_i_30_n_0 ;
  wire \derivative_reg[17]_i_30_n_1 ;
  wire \derivative_reg[17]_i_30_n_2 ;
  wire \derivative_reg[17]_i_30_n_3 ;
  wire \derivative_reg[17]_i_30_n_4 ;
  wire \derivative_reg[17]_i_30_n_5 ;
  wire \derivative_reg[17]_i_30_n_6 ;
  wire \derivative_reg[17]_i_30_n_7 ;
  wire \derivative_reg[17]_i_35_n_0 ;
  wire \derivative_reg[17]_i_35_n_1 ;
  wire \derivative_reg[17]_i_35_n_2 ;
  wire \derivative_reg[17]_i_35_n_3 ;
  wire \derivative_reg[17]_i_35_n_4 ;
  wire \derivative_reg[17]_i_35_n_5 ;
  wire \derivative_reg[17]_i_35_n_6 ;
  wire \derivative_reg[17]_i_5_n_0 ;
  wire \derivative_reg[17]_i_5_n_1 ;
  wire \derivative_reg[17]_i_5_n_2 ;
  wire \derivative_reg[17]_i_5_n_3 ;
  wire \derivative_reg[17]_i_5_n_4 ;
  wire \derivative_reg[17]_i_5_n_5 ;
  wire \derivative_reg[17]_i_5_n_6 ;
  wire \derivative_reg[17]_i_5_n_7 ;
  wire \derivative_reg[18]_i_10_n_0 ;
  wire \derivative_reg[18]_i_10_n_1 ;
  wire \derivative_reg[18]_i_10_n_2 ;
  wire \derivative_reg[18]_i_10_n_3 ;
  wire \derivative_reg[18]_i_10_n_4 ;
  wire \derivative_reg[18]_i_10_n_5 ;
  wire \derivative_reg[18]_i_10_n_6 ;
  wire \derivative_reg[18]_i_10_n_7 ;
  wire \derivative_reg[18]_i_15_n_0 ;
  wire \derivative_reg[18]_i_15_n_1 ;
  wire \derivative_reg[18]_i_15_n_2 ;
  wire \derivative_reg[18]_i_15_n_3 ;
  wire \derivative_reg[18]_i_15_n_4 ;
  wire \derivative_reg[18]_i_15_n_5 ;
  wire \derivative_reg[18]_i_15_n_6 ;
  wire \derivative_reg[18]_i_15_n_7 ;
  wire \derivative_reg[18]_i_1_n_2 ;
  wire \derivative_reg[18]_i_1_n_3 ;
  wire \derivative_reg[18]_i_1_n_7 ;
  wire \derivative_reg[18]_i_20_n_0 ;
  wire \derivative_reg[18]_i_20_n_1 ;
  wire \derivative_reg[18]_i_20_n_2 ;
  wire \derivative_reg[18]_i_20_n_3 ;
  wire \derivative_reg[18]_i_20_n_4 ;
  wire \derivative_reg[18]_i_20_n_5 ;
  wire \derivative_reg[18]_i_20_n_6 ;
  wire \derivative_reg[18]_i_20_n_7 ;
  wire \derivative_reg[18]_i_25_n_0 ;
  wire \derivative_reg[18]_i_25_n_1 ;
  wire \derivative_reg[18]_i_25_n_2 ;
  wire \derivative_reg[18]_i_25_n_3 ;
  wire \derivative_reg[18]_i_25_n_4 ;
  wire \derivative_reg[18]_i_25_n_5 ;
  wire \derivative_reg[18]_i_25_n_6 ;
  wire \derivative_reg[18]_i_25_n_7 ;
  wire \derivative_reg[18]_i_2_n_0 ;
  wire \derivative_reg[18]_i_2_n_1 ;
  wire \derivative_reg[18]_i_2_n_2 ;
  wire \derivative_reg[18]_i_2_n_3 ;
  wire \derivative_reg[18]_i_2_n_4 ;
  wire \derivative_reg[18]_i_2_n_5 ;
  wire \derivative_reg[18]_i_2_n_6 ;
  wire \derivative_reg[18]_i_2_n_7 ;
  wire \derivative_reg[18]_i_30_n_0 ;
  wire \derivative_reg[18]_i_30_n_1 ;
  wire \derivative_reg[18]_i_30_n_2 ;
  wire \derivative_reg[18]_i_30_n_3 ;
  wire \derivative_reg[18]_i_30_n_4 ;
  wire \derivative_reg[18]_i_30_n_5 ;
  wire \derivative_reg[18]_i_30_n_6 ;
  wire \derivative_reg[18]_i_30_n_7 ;
  wire \derivative_reg[18]_i_35_n_0 ;
  wire \derivative_reg[18]_i_35_n_1 ;
  wire \derivative_reg[18]_i_35_n_2 ;
  wire \derivative_reg[18]_i_35_n_3 ;
  wire \derivative_reg[18]_i_35_n_4 ;
  wire \derivative_reg[18]_i_35_n_5 ;
  wire \derivative_reg[18]_i_35_n_6 ;
  wire \derivative_reg[18]_i_5_n_0 ;
  wire \derivative_reg[18]_i_5_n_1 ;
  wire \derivative_reg[18]_i_5_n_2 ;
  wire \derivative_reg[18]_i_5_n_3 ;
  wire \derivative_reg[18]_i_5_n_4 ;
  wire \derivative_reg[18]_i_5_n_5 ;
  wire \derivative_reg[18]_i_5_n_6 ;
  wire \derivative_reg[18]_i_5_n_7 ;
  wire \derivative_reg[19]_i_10_n_0 ;
  wire \derivative_reg[19]_i_10_n_1 ;
  wire \derivative_reg[19]_i_10_n_2 ;
  wire \derivative_reg[19]_i_10_n_3 ;
  wire \derivative_reg[19]_i_10_n_4 ;
  wire \derivative_reg[19]_i_10_n_5 ;
  wire \derivative_reg[19]_i_10_n_6 ;
  wire \derivative_reg[19]_i_10_n_7 ;
  wire \derivative_reg[19]_i_15_n_0 ;
  wire \derivative_reg[19]_i_15_n_1 ;
  wire \derivative_reg[19]_i_15_n_2 ;
  wire \derivative_reg[19]_i_15_n_3 ;
  wire \derivative_reg[19]_i_15_n_4 ;
  wire \derivative_reg[19]_i_15_n_5 ;
  wire \derivative_reg[19]_i_15_n_6 ;
  wire \derivative_reg[19]_i_15_n_7 ;
  wire \derivative_reg[19]_i_1_n_2 ;
  wire \derivative_reg[19]_i_1_n_3 ;
  wire \derivative_reg[19]_i_1_n_7 ;
  wire \derivative_reg[19]_i_20_n_0 ;
  wire \derivative_reg[19]_i_20_n_1 ;
  wire \derivative_reg[19]_i_20_n_2 ;
  wire \derivative_reg[19]_i_20_n_3 ;
  wire \derivative_reg[19]_i_20_n_4 ;
  wire \derivative_reg[19]_i_20_n_5 ;
  wire \derivative_reg[19]_i_20_n_6 ;
  wire \derivative_reg[19]_i_20_n_7 ;
  wire \derivative_reg[19]_i_25_n_0 ;
  wire \derivative_reg[19]_i_25_n_1 ;
  wire \derivative_reg[19]_i_25_n_2 ;
  wire \derivative_reg[19]_i_25_n_3 ;
  wire \derivative_reg[19]_i_25_n_4 ;
  wire \derivative_reg[19]_i_25_n_5 ;
  wire \derivative_reg[19]_i_25_n_6 ;
  wire \derivative_reg[19]_i_25_n_7 ;
  wire \derivative_reg[19]_i_2_n_0 ;
  wire \derivative_reg[19]_i_2_n_1 ;
  wire \derivative_reg[19]_i_2_n_2 ;
  wire \derivative_reg[19]_i_2_n_3 ;
  wire \derivative_reg[19]_i_2_n_4 ;
  wire \derivative_reg[19]_i_2_n_5 ;
  wire \derivative_reg[19]_i_2_n_6 ;
  wire \derivative_reg[19]_i_2_n_7 ;
  wire \derivative_reg[19]_i_30_n_0 ;
  wire \derivative_reg[19]_i_30_n_1 ;
  wire \derivative_reg[19]_i_30_n_2 ;
  wire \derivative_reg[19]_i_30_n_3 ;
  wire \derivative_reg[19]_i_30_n_4 ;
  wire \derivative_reg[19]_i_30_n_5 ;
  wire \derivative_reg[19]_i_30_n_6 ;
  wire \derivative_reg[19]_i_30_n_7 ;
  wire \derivative_reg[19]_i_35_n_0 ;
  wire \derivative_reg[19]_i_35_n_1 ;
  wire \derivative_reg[19]_i_35_n_2 ;
  wire \derivative_reg[19]_i_35_n_3 ;
  wire \derivative_reg[19]_i_35_n_4 ;
  wire \derivative_reg[19]_i_35_n_5 ;
  wire \derivative_reg[19]_i_35_n_6 ;
  wire \derivative_reg[19]_i_5_n_0 ;
  wire \derivative_reg[19]_i_5_n_1 ;
  wire \derivative_reg[19]_i_5_n_2 ;
  wire \derivative_reg[19]_i_5_n_3 ;
  wire \derivative_reg[19]_i_5_n_4 ;
  wire \derivative_reg[19]_i_5_n_5 ;
  wire \derivative_reg[19]_i_5_n_6 ;
  wire \derivative_reg[19]_i_5_n_7 ;
  wire \derivative_reg[1]_i_10_n_0 ;
  wire \derivative_reg[1]_i_10_n_1 ;
  wire \derivative_reg[1]_i_10_n_2 ;
  wire \derivative_reg[1]_i_10_n_3 ;
  wire \derivative_reg[1]_i_10_n_4 ;
  wire \derivative_reg[1]_i_10_n_5 ;
  wire \derivative_reg[1]_i_10_n_6 ;
  wire \derivative_reg[1]_i_10_n_7 ;
  wire \derivative_reg[1]_i_15_n_0 ;
  wire \derivative_reg[1]_i_15_n_1 ;
  wire \derivative_reg[1]_i_15_n_2 ;
  wire \derivative_reg[1]_i_15_n_3 ;
  wire \derivative_reg[1]_i_15_n_4 ;
  wire \derivative_reg[1]_i_15_n_5 ;
  wire \derivative_reg[1]_i_15_n_6 ;
  wire \derivative_reg[1]_i_15_n_7 ;
  wire \derivative_reg[1]_i_1_n_2 ;
  wire \derivative_reg[1]_i_1_n_3 ;
  wire \derivative_reg[1]_i_1_n_7 ;
  wire \derivative_reg[1]_i_20_n_0 ;
  wire \derivative_reg[1]_i_20_n_1 ;
  wire \derivative_reg[1]_i_20_n_2 ;
  wire \derivative_reg[1]_i_20_n_3 ;
  wire \derivative_reg[1]_i_20_n_4 ;
  wire \derivative_reg[1]_i_20_n_5 ;
  wire \derivative_reg[1]_i_20_n_6 ;
  wire \derivative_reg[1]_i_20_n_7 ;
  wire \derivative_reg[1]_i_25_n_0 ;
  wire \derivative_reg[1]_i_25_n_1 ;
  wire \derivative_reg[1]_i_25_n_2 ;
  wire \derivative_reg[1]_i_25_n_3 ;
  wire \derivative_reg[1]_i_25_n_4 ;
  wire \derivative_reg[1]_i_25_n_5 ;
  wire \derivative_reg[1]_i_25_n_6 ;
  wire \derivative_reg[1]_i_25_n_7 ;
  wire \derivative_reg[1]_i_2_n_0 ;
  wire \derivative_reg[1]_i_2_n_1 ;
  wire \derivative_reg[1]_i_2_n_2 ;
  wire \derivative_reg[1]_i_2_n_3 ;
  wire \derivative_reg[1]_i_2_n_4 ;
  wire \derivative_reg[1]_i_2_n_5 ;
  wire \derivative_reg[1]_i_2_n_6 ;
  wire \derivative_reg[1]_i_2_n_7 ;
  wire \derivative_reg[1]_i_30_n_0 ;
  wire \derivative_reg[1]_i_30_n_1 ;
  wire \derivative_reg[1]_i_30_n_2 ;
  wire \derivative_reg[1]_i_30_n_3 ;
  wire \derivative_reg[1]_i_30_n_4 ;
  wire \derivative_reg[1]_i_30_n_5 ;
  wire \derivative_reg[1]_i_30_n_6 ;
  wire \derivative_reg[1]_i_30_n_7 ;
  wire \derivative_reg[1]_i_35_n_0 ;
  wire \derivative_reg[1]_i_35_n_1 ;
  wire \derivative_reg[1]_i_35_n_2 ;
  wire \derivative_reg[1]_i_35_n_3 ;
  wire \derivative_reg[1]_i_35_n_4 ;
  wire \derivative_reg[1]_i_35_n_5 ;
  wire \derivative_reg[1]_i_35_n_6 ;
  wire \derivative_reg[1]_i_5_n_0 ;
  wire \derivative_reg[1]_i_5_n_1 ;
  wire \derivative_reg[1]_i_5_n_2 ;
  wire \derivative_reg[1]_i_5_n_3 ;
  wire \derivative_reg[1]_i_5_n_4 ;
  wire \derivative_reg[1]_i_5_n_5 ;
  wire \derivative_reg[1]_i_5_n_6 ;
  wire \derivative_reg[1]_i_5_n_7 ;
  wire \derivative_reg[20]_i_10_n_0 ;
  wire \derivative_reg[20]_i_10_n_1 ;
  wire \derivative_reg[20]_i_10_n_2 ;
  wire \derivative_reg[20]_i_10_n_3 ;
  wire \derivative_reg[20]_i_10_n_4 ;
  wire \derivative_reg[20]_i_10_n_5 ;
  wire \derivative_reg[20]_i_10_n_6 ;
  wire \derivative_reg[20]_i_10_n_7 ;
  wire \derivative_reg[20]_i_15_n_0 ;
  wire \derivative_reg[20]_i_15_n_1 ;
  wire \derivative_reg[20]_i_15_n_2 ;
  wire \derivative_reg[20]_i_15_n_3 ;
  wire \derivative_reg[20]_i_15_n_4 ;
  wire \derivative_reg[20]_i_15_n_5 ;
  wire \derivative_reg[20]_i_15_n_6 ;
  wire \derivative_reg[20]_i_15_n_7 ;
  wire \derivative_reg[20]_i_1_n_2 ;
  wire \derivative_reg[20]_i_1_n_3 ;
  wire \derivative_reg[20]_i_1_n_7 ;
  wire \derivative_reg[20]_i_20_n_0 ;
  wire \derivative_reg[20]_i_20_n_1 ;
  wire \derivative_reg[20]_i_20_n_2 ;
  wire \derivative_reg[20]_i_20_n_3 ;
  wire \derivative_reg[20]_i_20_n_4 ;
  wire \derivative_reg[20]_i_20_n_5 ;
  wire \derivative_reg[20]_i_20_n_6 ;
  wire \derivative_reg[20]_i_20_n_7 ;
  wire \derivative_reg[20]_i_25_n_0 ;
  wire \derivative_reg[20]_i_25_n_1 ;
  wire \derivative_reg[20]_i_25_n_2 ;
  wire \derivative_reg[20]_i_25_n_3 ;
  wire \derivative_reg[20]_i_25_n_4 ;
  wire \derivative_reg[20]_i_25_n_5 ;
  wire \derivative_reg[20]_i_25_n_6 ;
  wire \derivative_reg[20]_i_25_n_7 ;
  wire \derivative_reg[20]_i_2_n_0 ;
  wire \derivative_reg[20]_i_2_n_1 ;
  wire \derivative_reg[20]_i_2_n_2 ;
  wire \derivative_reg[20]_i_2_n_3 ;
  wire \derivative_reg[20]_i_2_n_4 ;
  wire \derivative_reg[20]_i_2_n_5 ;
  wire \derivative_reg[20]_i_2_n_6 ;
  wire \derivative_reg[20]_i_2_n_7 ;
  wire \derivative_reg[20]_i_30_n_0 ;
  wire \derivative_reg[20]_i_30_n_1 ;
  wire \derivative_reg[20]_i_30_n_2 ;
  wire \derivative_reg[20]_i_30_n_3 ;
  wire \derivative_reg[20]_i_30_n_4 ;
  wire \derivative_reg[20]_i_30_n_5 ;
  wire \derivative_reg[20]_i_30_n_6 ;
  wire \derivative_reg[20]_i_30_n_7 ;
  wire \derivative_reg[20]_i_35_n_0 ;
  wire \derivative_reg[20]_i_35_n_1 ;
  wire \derivative_reg[20]_i_35_n_2 ;
  wire \derivative_reg[20]_i_35_n_3 ;
  wire \derivative_reg[20]_i_35_n_4 ;
  wire \derivative_reg[20]_i_35_n_5 ;
  wire \derivative_reg[20]_i_35_n_6 ;
  wire \derivative_reg[20]_i_5_n_0 ;
  wire \derivative_reg[20]_i_5_n_1 ;
  wire \derivative_reg[20]_i_5_n_2 ;
  wire \derivative_reg[20]_i_5_n_3 ;
  wire \derivative_reg[20]_i_5_n_4 ;
  wire \derivative_reg[20]_i_5_n_5 ;
  wire \derivative_reg[20]_i_5_n_6 ;
  wire \derivative_reg[20]_i_5_n_7 ;
  wire \derivative_reg[21]_i_10_n_0 ;
  wire \derivative_reg[21]_i_10_n_1 ;
  wire \derivative_reg[21]_i_10_n_2 ;
  wire \derivative_reg[21]_i_10_n_3 ;
  wire \derivative_reg[21]_i_10_n_4 ;
  wire \derivative_reg[21]_i_10_n_5 ;
  wire \derivative_reg[21]_i_10_n_6 ;
  wire \derivative_reg[21]_i_10_n_7 ;
  wire \derivative_reg[21]_i_15_n_0 ;
  wire \derivative_reg[21]_i_15_n_1 ;
  wire \derivative_reg[21]_i_15_n_2 ;
  wire \derivative_reg[21]_i_15_n_3 ;
  wire \derivative_reg[21]_i_15_n_4 ;
  wire \derivative_reg[21]_i_15_n_5 ;
  wire \derivative_reg[21]_i_15_n_6 ;
  wire \derivative_reg[21]_i_15_n_7 ;
  wire \derivative_reg[21]_i_1_n_2 ;
  wire \derivative_reg[21]_i_1_n_3 ;
  wire \derivative_reg[21]_i_1_n_7 ;
  wire \derivative_reg[21]_i_20_n_0 ;
  wire \derivative_reg[21]_i_20_n_1 ;
  wire \derivative_reg[21]_i_20_n_2 ;
  wire \derivative_reg[21]_i_20_n_3 ;
  wire \derivative_reg[21]_i_20_n_4 ;
  wire \derivative_reg[21]_i_20_n_5 ;
  wire \derivative_reg[21]_i_20_n_6 ;
  wire \derivative_reg[21]_i_20_n_7 ;
  wire \derivative_reg[21]_i_25_n_0 ;
  wire \derivative_reg[21]_i_25_n_1 ;
  wire \derivative_reg[21]_i_25_n_2 ;
  wire \derivative_reg[21]_i_25_n_3 ;
  wire \derivative_reg[21]_i_25_n_4 ;
  wire \derivative_reg[21]_i_25_n_5 ;
  wire \derivative_reg[21]_i_25_n_6 ;
  wire \derivative_reg[21]_i_25_n_7 ;
  wire \derivative_reg[21]_i_2_n_0 ;
  wire \derivative_reg[21]_i_2_n_1 ;
  wire \derivative_reg[21]_i_2_n_2 ;
  wire \derivative_reg[21]_i_2_n_3 ;
  wire \derivative_reg[21]_i_2_n_4 ;
  wire \derivative_reg[21]_i_2_n_5 ;
  wire \derivative_reg[21]_i_2_n_6 ;
  wire \derivative_reg[21]_i_2_n_7 ;
  wire \derivative_reg[21]_i_30_n_0 ;
  wire \derivative_reg[21]_i_30_n_1 ;
  wire \derivative_reg[21]_i_30_n_2 ;
  wire \derivative_reg[21]_i_30_n_3 ;
  wire \derivative_reg[21]_i_30_n_4 ;
  wire \derivative_reg[21]_i_30_n_5 ;
  wire \derivative_reg[21]_i_30_n_6 ;
  wire \derivative_reg[21]_i_30_n_7 ;
  wire \derivative_reg[21]_i_35_n_0 ;
  wire \derivative_reg[21]_i_35_n_1 ;
  wire \derivative_reg[21]_i_35_n_2 ;
  wire \derivative_reg[21]_i_35_n_3 ;
  wire \derivative_reg[21]_i_35_n_4 ;
  wire \derivative_reg[21]_i_35_n_5 ;
  wire \derivative_reg[21]_i_35_n_6 ;
  wire \derivative_reg[21]_i_5_n_0 ;
  wire \derivative_reg[21]_i_5_n_1 ;
  wire \derivative_reg[21]_i_5_n_2 ;
  wire \derivative_reg[21]_i_5_n_3 ;
  wire \derivative_reg[21]_i_5_n_4 ;
  wire \derivative_reg[21]_i_5_n_5 ;
  wire \derivative_reg[21]_i_5_n_6 ;
  wire \derivative_reg[21]_i_5_n_7 ;
  wire \derivative_reg[22]_i_10_n_0 ;
  wire \derivative_reg[22]_i_10_n_1 ;
  wire \derivative_reg[22]_i_10_n_2 ;
  wire \derivative_reg[22]_i_10_n_3 ;
  wire \derivative_reg[22]_i_10_n_4 ;
  wire \derivative_reg[22]_i_10_n_5 ;
  wire \derivative_reg[22]_i_10_n_6 ;
  wire \derivative_reg[22]_i_10_n_7 ;
  wire \derivative_reg[22]_i_15_n_0 ;
  wire \derivative_reg[22]_i_15_n_1 ;
  wire \derivative_reg[22]_i_15_n_2 ;
  wire \derivative_reg[22]_i_15_n_3 ;
  wire \derivative_reg[22]_i_15_n_4 ;
  wire \derivative_reg[22]_i_15_n_5 ;
  wire \derivative_reg[22]_i_15_n_6 ;
  wire \derivative_reg[22]_i_15_n_7 ;
  wire \derivative_reg[22]_i_1_n_2 ;
  wire \derivative_reg[22]_i_1_n_3 ;
  wire \derivative_reg[22]_i_1_n_7 ;
  wire \derivative_reg[22]_i_20_n_0 ;
  wire \derivative_reg[22]_i_20_n_1 ;
  wire \derivative_reg[22]_i_20_n_2 ;
  wire \derivative_reg[22]_i_20_n_3 ;
  wire \derivative_reg[22]_i_20_n_4 ;
  wire \derivative_reg[22]_i_20_n_5 ;
  wire \derivative_reg[22]_i_20_n_6 ;
  wire \derivative_reg[22]_i_20_n_7 ;
  wire \derivative_reg[22]_i_25_n_0 ;
  wire \derivative_reg[22]_i_25_n_1 ;
  wire \derivative_reg[22]_i_25_n_2 ;
  wire \derivative_reg[22]_i_25_n_3 ;
  wire \derivative_reg[22]_i_25_n_4 ;
  wire \derivative_reg[22]_i_25_n_5 ;
  wire \derivative_reg[22]_i_25_n_6 ;
  wire \derivative_reg[22]_i_25_n_7 ;
  wire \derivative_reg[22]_i_2_n_0 ;
  wire \derivative_reg[22]_i_2_n_1 ;
  wire \derivative_reg[22]_i_2_n_2 ;
  wire \derivative_reg[22]_i_2_n_3 ;
  wire \derivative_reg[22]_i_2_n_4 ;
  wire \derivative_reg[22]_i_2_n_5 ;
  wire \derivative_reg[22]_i_2_n_6 ;
  wire \derivative_reg[22]_i_2_n_7 ;
  wire \derivative_reg[22]_i_30_n_0 ;
  wire \derivative_reg[22]_i_30_n_1 ;
  wire \derivative_reg[22]_i_30_n_2 ;
  wire \derivative_reg[22]_i_30_n_3 ;
  wire \derivative_reg[22]_i_30_n_4 ;
  wire \derivative_reg[22]_i_30_n_5 ;
  wire \derivative_reg[22]_i_30_n_6 ;
  wire \derivative_reg[22]_i_30_n_7 ;
  wire \derivative_reg[22]_i_35_n_0 ;
  wire \derivative_reg[22]_i_35_n_1 ;
  wire \derivative_reg[22]_i_35_n_2 ;
  wire \derivative_reg[22]_i_35_n_3 ;
  wire \derivative_reg[22]_i_35_n_4 ;
  wire \derivative_reg[22]_i_35_n_5 ;
  wire \derivative_reg[22]_i_35_n_6 ;
  wire \derivative_reg[22]_i_5_n_0 ;
  wire \derivative_reg[22]_i_5_n_1 ;
  wire \derivative_reg[22]_i_5_n_2 ;
  wire \derivative_reg[22]_i_5_n_3 ;
  wire \derivative_reg[22]_i_5_n_4 ;
  wire \derivative_reg[22]_i_5_n_5 ;
  wire \derivative_reg[22]_i_5_n_6 ;
  wire \derivative_reg[22]_i_5_n_7 ;
  wire \derivative_reg[23]_i_10_n_0 ;
  wire \derivative_reg[23]_i_10_n_1 ;
  wire \derivative_reg[23]_i_10_n_2 ;
  wire \derivative_reg[23]_i_10_n_3 ;
  wire \derivative_reg[23]_i_10_n_4 ;
  wire \derivative_reg[23]_i_10_n_5 ;
  wire \derivative_reg[23]_i_10_n_6 ;
  wire \derivative_reg[23]_i_10_n_7 ;
  wire \derivative_reg[23]_i_15_n_0 ;
  wire \derivative_reg[23]_i_15_n_1 ;
  wire \derivative_reg[23]_i_15_n_2 ;
  wire \derivative_reg[23]_i_15_n_3 ;
  wire \derivative_reg[23]_i_15_n_4 ;
  wire \derivative_reg[23]_i_15_n_5 ;
  wire \derivative_reg[23]_i_15_n_6 ;
  wire \derivative_reg[23]_i_15_n_7 ;
  wire \derivative_reg[23]_i_1_n_2 ;
  wire \derivative_reg[23]_i_1_n_3 ;
  wire \derivative_reg[23]_i_1_n_7 ;
  wire \derivative_reg[23]_i_20_n_0 ;
  wire \derivative_reg[23]_i_20_n_1 ;
  wire \derivative_reg[23]_i_20_n_2 ;
  wire \derivative_reg[23]_i_20_n_3 ;
  wire \derivative_reg[23]_i_20_n_4 ;
  wire \derivative_reg[23]_i_20_n_5 ;
  wire \derivative_reg[23]_i_20_n_6 ;
  wire \derivative_reg[23]_i_20_n_7 ;
  wire \derivative_reg[23]_i_25_n_0 ;
  wire \derivative_reg[23]_i_25_n_1 ;
  wire \derivative_reg[23]_i_25_n_2 ;
  wire \derivative_reg[23]_i_25_n_3 ;
  wire \derivative_reg[23]_i_25_n_4 ;
  wire \derivative_reg[23]_i_25_n_5 ;
  wire \derivative_reg[23]_i_25_n_6 ;
  wire \derivative_reg[23]_i_25_n_7 ;
  wire \derivative_reg[23]_i_2_n_0 ;
  wire \derivative_reg[23]_i_2_n_1 ;
  wire \derivative_reg[23]_i_2_n_2 ;
  wire \derivative_reg[23]_i_2_n_3 ;
  wire \derivative_reg[23]_i_2_n_4 ;
  wire \derivative_reg[23]_i_2_n_5 ;
  wire \derivative_reg[23]_i_2_n_6 ;
  wire \derivative_reg[23]_i_2_n_7 ;
  wire \derivative_reg[23]_i_30_n_0 ;
  wire \derivative_reg[23]_i_30_n_1 ;
  wire \derivative_reg[23]_i_30_n_2 ;
  wire \derivative_reg[23]_i_30_n_3 ;
  wire \derivative_reg[23]_i_30_n_4 ;
  wire \derivative_reg[23]_i_30_n_5 ;
  wire \derivative_reg[23]_i_30_n_6 ;
  wire \derivative_reg[23]_i_30_n_7 ;
  wire \derivative_reg[23]_i_35_n_0 ;
  wire \derivative_reg[23]_i_35_n_1 ;
  wire \derivative_reg[23]_i_35_n_2 ;
  wire \derivative_reg[23]_i_35_n_3 ;
  wire \derivative_reg[23]_i_35_n_4 ;
  wire \derivative_reg[23]_i_35_n_5 ;
  wire \derivative_reg[23]_i_35_n_6 ;
  wire \derivative_reg[23]_i_5_n_0 ;
  wire \derivative_reg[23]_i_5_n_1 ;
  wire \derivative_reg[23]_i_5_n_2 ;
  wire \derivative_reg[23]_i_5_n_3 ;
  wire \derivative_reg[23]_i_5_n_4 ;
  wire \derivative_reg[23]_i_5_n_5 ;
  wire \derivative_reg[23]_i_5_n_6 ;
  wire \derivative_reg[23]_i_5_n_7 ;
  wire \derivative_reg[24]_i_10_n_0 ;
  wire \derivative_reg[24]_i_10_n_1 ;
  wire \derivative_reg[24]_i_10_n_2 ;
  wire \derivative_reg[24]_i_10_n_3 ;
  wire \derivative_reg[24]_i_10_n_4 ;
  wire \derivative_reg[24]_i_10_n_5 ;
  wire \derivative_reg[24]_i_10_n_6 ;
  wire \derivative_reg[24]_i_10_n_7 ;
  wire \derivative_reg[24]_i_15_n_0 ;
  wire \derivative_reg[24]_i_15_n_1 ;
  wire \derivative_reg[24]_i_15_n_2 ;
  wire \derivative_reg[24]_i_15_n_3 ;
  wire \derivative_reg[24]_i_15_n_4 ;
  wire \derivative_reg[24]_i_15_n_5 ;
  wire \derivative_reg[24]_i_15_n_6 ;
  wire \derivative_reg[24]_i_15_n_7 ;
  wire \derivative_reg[24]_i_1_n_2 ;
  wire \derivative_reg[24]_i_1_n_3 ;
  wire \derivative_reg[24]_i_1_n_7 ;
  wire \derivative_reg[24]_i_20_n_0 ;
  wire \derivative_reg[24]_i_20_n_1 ;
  wire \derivative_reg[24]_i_20_n_2 ;
  wire \derivative_reg[24]_i_20_n_3 ;
  wire \derivative_reg[24]_i_20_n_4 ;
  wire \derivative_reg[24]_i_20_n_5 ;
  wire \derivative_reg[24]_i_20_n_6 ;
  wire \derivative_reg[24]_i_20_n_7 ;
  wire \derivative_reg[24]_i_25_n_0 ;
  wire \derivative_reg[24]_i_25_n_1 ;
  wire \derivative_reg[24]_i_25_n_2 ;
  wire \derivative_reg[24]_i_25_n_3 ;
  wire \derivative_reg[24]_i_25_n_4 ;
  wire \derivative_reg[24]_i_25_n_5 ;
  wire \derivative_reg[24]_i_25_n_6 ;
  wire \derivative_reg[24]_i_25_n_7 ;
  wire \derivative_reg[24]_i_2_n_0 ;
  wire \derivative_reg[24]_i_2_n_1 ;
  wire \derivative_reg[24]_i_2_n_2 ;
  wire \derivative_reg[24]_i_2_n_3 ;
  wire \derivative_reg[24]_i_2_n_4 ;
  wire \derivative_reg[24]_i_2_n_5 ;
  wire \derivative_reg[24]_i_2_n_6 ;
  wire \derivative_reg[24]_i_2_n_7 ;
  wire \derivative_reg[24]_i_30_n_0 ;
  wire \derivative_reg[24]_i_30_n_1 ;
  wire \derivative_reg[24]_i_30_n_2 ;
  wire \derivative_reg[24]_i_30_n_3 ;
  wire \derivative_reg[24]_i_30_n_4 ;
  wire \derivative_reg[24]_i_30_n_5 ;
  wire \derivative_reg[24]_i_30_n_6 ;
  wire \derivative_reg[24]_i_30_n_7 ;
  wire \derivative_reg[24]_i_35_n_0 ;
  wire \derivative_reg[24]_i_35_n_1 ;
  wire \derivative_reg[24]_i_35_n_2 ;
  wire \derivative_reg[24]_i_35_n_3 ;
  wire \derivative_reg[24]_i_35_n_4 ;
  wire \derivative_reg[24]_i_35_n_5 ;
  wire \derivative_reg[24]_i_35_n_6 ;
  wire \derivative_reg[24]_i_5_n_0 ;
  wire \derivative_reg[24]_i_5_n_1 ;
  wire \derivative_reg[24]_i_5_n_2 ;
  wire \derivative_reg[24]_i_5_n_3 ;
  wire \derivative_reg[24]_i_5_n_4 ;
  wire \derivative_reg[24]_i_5_n_5 ;
  wire \derivative_reg[24]_i_5_n_6 ;
  wire \derivative_reg[24]_i_5_n_7 ;
  wire \derivative_reg[25]_i_10_n_0 ;
  wire \derivative_reg[25]_i_10_n_1 ;
  wire \derivative_reg[25]_i_10_n_2 ;
  wire \derivative_reg[25]_i_10_n_3 ;
  wire \derivative_reg[25]_i_10_n_4 ;
  wire \derivative_reg[25]_i_10_n_5 ;
  wire \derivative_reg[25]_i_10_n_6 ;
  wire \derivative_reg[25]_i_10_n_7 ;
  wire \derivative_reg[25]_i_15_n_0 ;
  wire \derivative_reg[25]_i_15_n_1 ;
  wire \derivative_reg[25]_i_15_n_2 ;
  wire \derivative_reg[25]_i_15_n_3 ;
  wire \derivative_reg[25]_i_15_n_4 ;
  wire \derivative_reg[25]_i_15_n_5 ;
  wire \derivative_reg[25]_i_15_n_6 ;
  wire \derivative_reg[25]_i_15_n_7 ;
  wire \derivative_reg[25]_i_1_n_2 ;
  wire \derivative_reg[25]_i_1_n_3 ;
  wire \derivative_reg[25]_i_1_n_7 ;
  wire \derivative_reg[25]_i_20_n_0 ;
  wire \derivative_reg[25]_i_20_n_1 ;
  wire \derivative_reg[25]_i_20_n_2 ;
  wire \derivative_reg[25]_i_20_n_3 ;
  wire \derivative_reg[25]_i_20_n_4 ;
  wire \derivative_reg[25]_i_20_n_5 ;
  wire \derivative_reg[25]_i_20_n_6 ;
  wire \derivative_reg[25]_i_20_n_7 ;
  wire \derivative_reg[25]_i_25_n_0 ;
  wire \derivative_reg[25]_i_25_n_1 ;
  wire \derivative_reg[25]_i_25_n_2 ;
  wire \derivative_reg[25]_i_25_n_3 ;
  wire \derivative_reg[25]_i_25_n_4 ;
  wire \derivative_reg[25]_i_25_n_5 ;
  wire \derivative_reg[25]_i_25_n_6 ;
  wire \derivative_reg[25]_i_25_n_7 ;
  wire \derivative_reg[25]_i_2_n_0 ;
  wire \derivative_reg[25]_i_2_n_1 ;
  wire \derivative_reg[25]_i_2_n_2 ;
  wire \derivative_reg[25]_i_2_n_3 ;
  wire \derivative_reg[25]_i_2_n_4 ;
  wire \derivative_reg[25]_i_2_n_5 ;
  wire \derivative_reg[25]_i_2_n_6 ;
  wire \derivative_reg[25]_i_2_n_7 ;
  wire \derivative_reg[25]_i_30_n_0 ;
  wire \derivative_reg[25]_i_30_n_1 ;
  wire \derivative_reg[25]_i_30_n_2 ;
  wire \derivative_reg[25]_i_30_n_3 ;
  wire \derivative_reg[25]_i_30_n_4 ;
  wire \derivative_reg[25]_i_30_n_5 ;
  wire \derivative_reg[25]_i_30_n_6 ;
  wire \derivative_reg[25]_i_30_n_7 ;
  wire \derivative_reg[25]_i_35_n_0 ;
  wire \derivative_reg[25]_i_35_n_1 ;
  wire \derivative_reg[25]_i_35_n_2 ;
  wire \derivative_reg[25]_i_35_n_3 ;
  wire \derivative_reg[25]_i_35_n_4 ;
  wire \derivative_reg[25]_i_35_n_5 ;
  wire \derivative_reg[25]_i_35_n_6 ;
  wire \derivative_reg[25]_i_5_n_0 ;
  wire \derivative_reg[25]_i_5_n_1 ;
  wire \derivative_reg[25]_i_5_n_2 ;
  wire \derivative_reg[25]_i_5_n_3 ;
  wire \derivative_reg[25]_i_5_n_4 ;
  wire \derivative_reg[25]_i_5_n_5 ;
  wire \derivative_reg[25]_i_5_n_6 ;
  wire \derivative_reg[25]_i_5_n_7 ;
  wire \derivative_reg[26]_i_10_n_0 ;
  wire \derivative_reg[26]_i_10_n_1 ;
  wire \derivative_reg[26]_i_10_n_2 ;
  wire \derivative_reg[26]_i_10_n_3 ;
  wire \derivative_reg[26]_i_10_n_4 ;
  wire \derivative_reg[26]_i_10_n_5 ;
  wire \derivative_reg[26]_i_10_n_6 ;
  wire \derivative_reg[26]_i_10_n_7 ;
  wire \derivative_reg[26]_i_15_n_0 ;
  wire \derivative_reg[26]_i_15_n_1 ;
  wire \derivative_reg[26]_i_15_n_2 ;
  wire \derivative_reg[26]_i_15_n_3 ;
  wire \derivative_reg[26]_i_15_n_4 ;
  wire \derivative_reg[26]_i_15_n_5 ;
  wire \derivative_reg[26]_i_15_n_6 ;
  wire \derivative_reg[26]_i_15_n_7 ;
  wire \derivative_reg[26]_i_1_n_2 ;
  wire \derivative_reg[26]_i_1_n_3 ;
  wire \derivative_reg[26]_i_1_n_7 ;
  wire \derivative_reg[26]_i_20_n_0 ;
  wire \derivative_reg[26]_i_20_n_1 ;
  wire \derivative_reg[26]_i_20_n_2 ;
  wire \derivative_reg[26]_i_20_n_3 ;
  wire \derivative_reg[26]_i_20_n_4 ;
  wire \derivative_reg[26]_i_20_n_5 ;
  wire \derivative_reg[26]_i_20_n_6 ;
  wire \derivative_reg[26]_i_20_n_7 ;
  wire \derivative_reg[26]_i_25_n_0 ;
  wire \derivative_reg[26]_i_25_n_1 ;
  wire \derivative_reg[26]_i_25_n_2 ;
  wire \derivative_reg[26]_i_25_n_3 ;
  wire \derivative_reg[26]_i_25_n_4 ;
  wire \derivative_reg[26]_i_25_n_5 ;
  wire \derivative_reg[26]_i_25_n_6 ;
  wire \derivative_reg[26]_i_25_n_7 ;
  wire \derivative_reg[26]_i_2_n_0 ;
  wire \derivative_reg[26]_i_2_n_1 ;
  wire \derivative_reg[26]_i_2_n_2 ;
  wire \derivative_reg[26]_i_2_n_3 ;
  wire \derivative_reg[26]_i_2_n_4 ;
  wire \derivative_reg[26]_i_2_n_5 ;
  wire \derivative_reg[26]_i_2_n_6 ;
  wire \derivative_reg[26]_i_2_n_7 ;
  wire \derivative_reg[26]_i_30_n_0 ;
  wire \derivative_reg[26]_i_30_n_1 ;
  wire \derivative_reg[26]_i_30_n_2 ;
  wire \derivative_reg[26]_i_30_n_3 ;
  wire \derivative_reg[26]_i_30_n_4 ;
  wire \derivative_reg[26]_i_30_n_5 ;
  wire \derivative_reg[26]_i_30_n_6 ;
  wire \derivative_reg[26]_i_30_n_7 ;
  wire \derivative_reg[26]_i_35_n_0 ;
  wire \derivative_reg[26]_i_35_n_1 ;
  wire \derivative_reg[26]_i_35_n_2 ;
  wire \derivative_reg[26]_i_35_n_3 ;
  wire \derivative_reg[26]_i_35_n_4 ;
  wire \derivative_reg[26]_i_35_n_5 ;
  wire \derivative_reg[26]_i_35_n_6 ;
  wire \derivative_reg[26]_i_5_n_0 ;
  wire \derivative_reg[26]_i_5_n_1 ;
  wire \derivative_reg[26]_i_5_n_2 ;
  wire \derivative_reg[26]_i_5_n_3 ;
  wire \derivative_reg[26]_i_5_n_4 ;
  wire \derivative_reg[26]_i_5_n_5 ;
  wire \derivative_reg[26]_i_5_n_6 ;
  wire \derivative_reg[26]_i_5_n_7 ;
  wire \derivative_reg[27]_i_10_n_0 ;
  wire \derivative_reg[27]_i_10_n_1 ;
  wire \derivative_reg[27]_i_10_n_2 ;
  wire \derivative_reg[27]_i_10_n_3 ;
  wire \derivative_reg[27]_i_10_n_4 ;
  wire \derivative_reg[27]_i_10_n_5 ;
  wire \derivative_reg[27]_i_10_n_6 ;
  wire \derivative_reg[27]_i_10_n_7 ;
  wire \derivative_reg[27]_i_15_n_0 ;
  wire \derivative_reg[27]_i_15_n_1 ;
  wire \derivative_reg[27]_i_15_n_2 ;
  wire \derivative_reg[27]_i_15_n_3 ;
  wire \derivative_reg[27]_i_15_n_4 ;
  wire \derivative_reg[27]_i_15_n_5 ;
  wire \derivative_reg[27]_i_15_n_6 ;
  wire \derivative_reg[27]_i_15_n_7 ;
  wire \derivative_reg[27]_i_1_n_2 ;
  wire \derivative_reg[27]_i_1_n_3 ;
  wire \derivative_reg[27]_i_1_n_7 ;
  wire \derivative_reg[27]_i_20_n_0 ;
  wire \derivative_reg[27]_i_20_n_1 ;
  wire \derivative_reg[27]_i_20_n_2 ;
  wire \derivative_reg[27]_i_20_n_3 ;
  wire \derivative_reg[27]_i_20_n_4 ;
  wire \derivative_reg[27]_i_20_n_5 ;
  wire \derivative_reg[27]_i_20_n_6 ;
  wire \derivative_reg[27]_i_20_n_7 ;
  wire \derivative_reg[27]_i_25_n_0 ;
  wire \derivative_reg[27]_i_25_n_1 ;
  wire \derivative_reg[27]_i_25_n_2 ;
  wire \derivative_reg[27]_i_25_n_3 ;
  wire \derivative_reg[27]_i_25_n_4 ;
  wire \derivative_reg[27]_i_25_n_5 ;
  wire \derivative_reg[27]_i_25_n_6 ;
  wire \derivative_reg[27]_i_25_n_7 ;
  wire \derivative_reg[27]_i_2_n_0 ;
  wire \derivative_reg[27]_i_2_n_1 ;
  wire \derivative_reg[27]_i_2_n_2 ;
  wire \derivative_reg[27]_i_2_n_3 ;
  wire \derivative_reg[27]_i_2_n_4 ;
  wire \derivative_reg[27]_i_2_n_5 ;
  wire \derivative_reg[27]_i_2_n_6 ;
  wire \derivative_reg[27]_i_2_n_7 ;
  wire \derivative_reg[27]_i_30_n_0 ;
  wire \derivative_reg[27]_i_30_n_1 ;
  wire \derivative_reg[27]_i_30_n_2 ;
  wire \derivative_reg[27]_i_30_n_3 ;
  wire \derivative_reg[27]_i_30_n_4 ;
  wire \derivative_reg[27]_i_30_n_5 ;
  wire \derivative_reg[27]_i_30_n_6 ;
  wire \derivative_reg[27]_i_30_n_7 ;
  wire \derivative_reg[27]_i_35_n_0 ;
  wire \derivative_reg[27]_i_35_n_1 ;
  wire \derivative_reg[27]_i_35_n_2 ;
  wire \derivative_reg[27]_i_35_n_3 ;
  wire \derivative_reg[27]_i_35_n_4 ;
  wire \derivative_reg[27]_i_35_n_5 ;
  wire \derivative_reg[27]_i_35_n_6 ;
  wire \derivative_reg[27]_i_5_n_0 ;
  wire \derivative_reg[27]_i_5_n_1 ;
  wire \derivative_reg[27]_i_5_n_2 ;
  wire \derivative_reg[27]_i_5_n_3 ;
  wire \derivative_reg[27]_i_5_n_4 ;
  wire \derivative_reg[27]_i_5_n_5 ;
  wire \derivative_reg[27]_i_5_n_6 ;
  wire \derivative_reg[27]_i_5_n_7 ;
  wire \derivative_reg[28]_i_10_n_0 ;
  wire \derivative_reg[28]_i_10_n_1 ;
  wire \derivative_reg[28]_i_10_n_2 ;
  wire \derivative_reg[28]_i_10_n_3 ;
  wire \derivative_reg[28]_i_10_n_4 ;
  wire \derivative_reg[28]_i_10_n_5 ;
  wire \derivative_reg[28]_i_10_n_6 ;
  wire \derivative_reg[28]_i_10_n_7 ;
  wire \derivative_reg[28]_i_15_n_0 ;
  wire \derivative_reg[28]_i_15_n_1 ;
  wire \derivative_reg[28]_i_15_n_2 ;
  wire \derivative_reg[28]_i_15_n_3 ;
  wire \derivative_reg[28]_i_15_n_4 ;
  wire \derivative_reg[28]_i_15_n_5 ;
  wire \derivative_reg[28]_i_15_n_6 ;
  wire \derivative_reg[28]_i_15_n_7 ;
  wire \derivative_reg[28]_i_1_n_2 ;
  wire \derivative_reg[28]_i_1_n_3 ;
  wire \derivative_reg[28]_i_1_n_7 ;
  wire \derivative_reg[28]_i_20_n_0 ;
  wire \derivative_reg[28]_i_20_n_1 ;
  wire \derivative_reg[28]_i_20_n_2 ;
  wire \derivative_reg[28]_i_20_n_3 ;
  wire \derivative_reg[28]_i_20_n_4 ;
  wire \derivative_reg[28]_i_20_n_5 ;
  wire \derivative_reg[28]_i_20_n_6 ;
  wire \derivative_reg[28]_i_20_n_7 ;
  wire \derivative_reg[28]_i_25_n_0 ;
  wire \derivative_reg[28]_i_25_n_1 ;
  wire \derivative_reg[28]_i_25_n_2 ;
  wire \derivative_reg[28]_i_25_n_3 ;
  wire \derivative_reg[28]_i_25_n_4 ;
  wire \derivative_reg[28]_i_25_n_5 ;
  wire \derivative_reg[28]_i_25_n_6 ;
  wire \derivative_reg[28]_i_25_n_7 ;
  wire \derivative_reg[28]_i_2_n_0 ;
  wire \derivative_reg[28]_i_2_n_1 ;
  wire \derivative_reg[28]_i_2_n_2 ;
  wire \derivative_reg[28]_i_2_n_3 ;
  wire \derivative_reg[28]_i_2_n_4 ;
  wire \derivative_reg[28]_i_2_n_5 ;
  wire \derivative_reg[28]_i_2_n_6 ;
  wire \derivative_reg[28]_i_2_n_7 ;
  wire \derivative_reg[28]_i_30_n_0 ;
  wire \derivative_reg[28]_i_30_n_1 ;
  wire \derivative_reg[28]_i_30_n_2 ;
  wire \derivative_reg[28]_i_30_n_3 ;
  wire \derivative_reg[28]_i_30_n_4 ;
  wire \derivative_reg[28]_i_30_n_5 ;
  wire \derivative_reg[28]_i_30_n_6 ;
  wire \derivative_reg[28]_i_30_n_7 ;
  wire \derivative_reg[28]_i_35_n_0 ;
  wire \derivative_reg[28]_i_35_n_1 ;
  wire \derivative_reg[28]_i_35_n_2 ;
  wire \derivative_reg[28]_i_35_n_3 ;
  wire \derivative_reg[28]_i_35_n_4 ;
  wire \derivative_reg[28]_i_35_n_5 ;
  wire \derivative_reg[28]_i_35_n_6 ;
  wire \derivative_reg[28]_i_5_n_0 ;
  wire \derivative_reg[28]_i_5_n_1 ;
  wire \derivative_reg[28]_i_5_n_2 ;
  wire \derivative_reg[28]_i_5_n_3 ;
  wire \derivative_reg[28]_i_5_n_4 ;
  wire \derivative_reg[28]_i_5_n_5 ;
  wire \derivative_reg[28]_i_5_n_6 ;
  wire \derivative_reg[28]_i_5_n_7 ;
  wire \derivative_reg[29]_i_10_n_0 ;
  wire \derivative_reg[29]_i_10_n_1 ;
  wire \derivative_reg[29]_i_10_n_2 ;
  wire \derivative_reg[29]_i_10_n_3 ;
  wire \derivative_reg[29]_i_10_n_4 ;
  wire \derivative_reg[29]_i_10_n_5 ;
  wire \derivative_reg[29]_i_10_n_6 ;
  wire \derivative_reg[29]_i_10_n_7 ;
  wire \derivative_reg[29]_i_15_n_0 ;
  wire \derivative_reg[29]_i_15_n_1 ;
  wire \derivative_reg[29]_i_15_n_2 ;
  wire \derivative_reg[29]_i_15_n_3 ;
  wire \derivative_reg[29]_i_15_n_4 ;
  wire \derivative_reg[29]_i_15_n_5 ;
  wire \derivative_reg[29]_i_15_n_6 ;
  wire \derivative_reg[29]_i_15_n_7 ;
  wire \derivative_reg[29]_i_1_n_2 ;
  wire \derivative_reg[29]_i_1_n_3 ;
  wire \derivative_reg[29]_i_1_n_7 ;
  wire \derivative_reg[29]_i_20_n_0 ;
  wire \derivative_reg[29]_i_20_n_1 ;
  wire \derivative_reg[29]_i_20_n_2 ;
  wire \derivative_reg[29]_i_20_n_3 ;
  wire \derivative_reg[29]_i_20_n_4 ;
  wire \derivative_reg[29]_i_20_n_5 ;
  wire \derivative_reg[29]_i_20_n_6 ;
  wire \derivative_reg[29]_i_20_n_7 ;
  wire \derivative_reg[29]_i_25_n_0 ;
  wire \derivative_reg[29]_i_25_n_1 ;
  wire \derivative_reg[29]_i_25_n_2 ;
  wire \derivative_reg[29]_i_25_n_3 ;
  wire \derivative_reg[29]_i_25_n_4 ;
  wire \derivative_reg[29]_i_25_n_5 ;
  wire \derivative_reg[29]_i_25_n_6 ;
  wire \derivative_reg[29]_i_25_n_7 ;
  wire \derivative_reg[29]_i_2_n_0 ;
  wire \derivative_reg[29]_i_2_n_1 ;
  wire \derivative_reg[29]_i_2_n_2 ;
  wire \derivative_reg[29]_i_2_n_3 ;
  wire \derivative_reg[29]_i_2_n_4 ;
  wire \derivative_reg[29]_i_2_n_5 ;
  wire \derivative_reg[29]_i_2_n_6 ;
  wire \derivative_reg[29]_i_2_n_7 ;
  wire \derivative_reg[29]_i_30_n_0 ;
  wire \derivative_reg[29]_i_30_n_1 ;
  wire \derivative_reg[29]_i_30_n_2 ;
  wire \derivative_reg[29]_i_30_n_3 ;
  wire \derivative_reg[29]_i_30_n_4 ;
  wire \derivative_reg[29]_i_30_n_5 ;
  wire \derivative_reg[29]_i_30_n_6 ;
  wire \derivative_reg[29]_i_30_n_7 ;
  wire \derivative_reg[29]_i_35_n_0 ;
  wire \derivative_reg[29]_i_35_n_1 ;
  wire \derivative_reg[29]_i_35_n_2 ;
  wire \derivative_reg[29]_i_35_n_3 ;
  wire \derivative_reg[29]_i_35_n_4 ;
  wire \derivative_reg[29]_i_35_n_5 ;
  wire \derivative_reg[29]_i_35_n_6 ;
  wire \derivative_reg[29]_i_5_n_0 ;
  wire \derivative_reg[29]_i_5_n_1 ;
  wire \derivative_reg[29]_i_5_n_2 ;
  wire \derivative_reg[29]_i_5_n_3 ;
  wire \derivative_reg[29]_i_5_n_4 ;
  wire \derivative_reg[29]_i_5_n_5 ;
  wire \derivative_reg[29]_i_5_n_6 ;
  wire \derivative_reg[29]_i_5_n_7 ;
  wire \derivative_reg[2]_i_10_n_0 ;
  wire \derivative_reg[2]_i_10_n_1 ;
  wire \derivative_reg[2]_i_10_n_2 ;
  wire \derivative_reg[2]_i_10_n_3 ;
  wire \derivative_reg[2]_i_10_n_4 ;
  wire \derivative_reg[2]_i_10_n_5 ;
  wire \derivative_reg[2]_i_10_n_6 ;
  wire \derivative_reg[2]_i_10_n_7 ;
  wire \derivative_reg[2]_i_15_n_0 ;
  wire \derivative_reg[2]_i_15_n_1 ;
  wire \derivative_reg[2]_i_15_n_2 ;
  wire \derivative_reg[2]_i_15_n_3 ;
  wire \derivative_reg[2]_i_15_n_4 ;
  wire \derivative_reg[2]_i_15_n_5 ;
  wire \derivative_reg[2]_i_15_n_6 ;
  wire \derivative_reg[2]_i_15_n_7 ;
  wire \derivative_reg[2]_i_1_n_2 ;
  wire \derivative_reg[2]_i_1_n_3 ;
  wire \derivative_reg[2]_i_1_n_7 ;
  wire \derivative_reg[2]_i_20_n_0 ;
  wire \derivative_reg[2]_i_20_n_1 ;
  wire \derivative_reg[2]_i_20_n_2 ;
  wire \derivative_reg[2]_i_20_n_3 ;
  wire \derivative_reg[2]_i_20_n_4 ;
  wire \derivative_reg[2]_i_20_n_5 ;
  wire \derivative_reg[2]_i_20_n_6 ;
  wire \derivative_reg[2]_i_20_n_7 ;
  wire \derivative_reg[2]_i_25_n_0 ;
  wire \derivative_reg[2]_i_25_n_1 ;
  wire \derivative_reg[2]_i_25_n_2 ;
  wire \derivative_reg[2]_i_25_n_3 ;
  wire \derivative_reg[2]_i_25_n_4 ;
  wire \derivative_reg[2]_i_25_n_5 ;
  wire \derivative_reg[2]_i_25_n_6 ;
  wire \derivative_reg[2]_i_25_n_7 ;
  wire \derivative_reg[2]_i_2_n_0 ;
  wire \derivative_reg[2]_i_2_n_1 ;
  wire \derivative_reg[2]_i_2_n_2 ;
  wire \derivative_reg[2]_i_2_n_3 ;
  wire \derivative_reg[2]_i_2_n_4 ;
  wire \derivative_reg[2]_i_2_n_5 ;
  wire \derivative_reg[2]_i_2_n_6 ;
  wire \derivative_reg[2]_i_2_n_7 ;
  wire \derivative_reg[2]_i_30_n_0 ;
  wire \derivative_reg[2]_i_30_n_1 ;
  wire \derivative_reg[2]_i_30_n_2 ;
  wire \derivative_reg[2]_i_30_n_3 ;
  wire \derivative_reg[2]_i_30_n_4 ;
  wire \derivative_reg[2]_i_30_n_5 ;
  wire \derivative_reg[2]_i_30_n_6 ;
  wire \derivative_reg[2]_i_30_n_7 ;
  wire \derivative_reg[2]_i_35_n_0 ;
  wire \derivative_reg[2]_i_35_n_1 ;
  wire \derivative_reg[2]_i_35_n_2 ;
  wire \derivative_reg[2]_i_35_n_3 ;
  wire \derivative_reg[2]_i_35_n_4 ;
  wire \derivative_reg[2]_i_35_n_5 ;
  wire \derivative_reg[2]_i_35_n_6 ;
  wire \derivative_reg[2]_i_5_n_0 ;
  wire \derivative_reg[2]_i_5_n_1 ;
  wire \derivative_reg[2]_i_5_n_2 ;
  wire \derivative_reg[2]_i_5_n_3 ;
  wire \derivative_reg[2]_i_5_n_4 ;
  wire \derivative_reg[2]_i_5_n_5 ;
  wire \derivative_reg[2]_i_5_n_6 ;
  wire \derivative_reg[2]_i_5_n_7 ;
  wire \derivative_reg[30]_i_10_n_0 ;
  wire \derivative_reg[30]_i_10_n_1 ;
  wire \derivative_reg[30]_i_10_n_2 ;
  wire \derivative_reg[30]_i_10_n_3 ;
  wire \derivative_reg[30]_i_10_n_4 ;
  wire \derivative_reg[30]_i_10_n_5 ;
  wire \derivative_reg[30]_i_10_n_6 ;
  wire \derivative_reg[30]_i_10_n_7 ;
  wire \derivative_reg[30]_i_15_n_0 ;
  wire \derivative_reg[30]_i_15_n_1 ;
  wire \derivative_reg[30]_i_15_n_2 ;
  wire \derivative_reg[30]_i_15_n_3 ;
  wire \derivative_reg[30]_i_15_n_4 ;
  wire \derivative_reg[30]_i_15_n_5 ;
  wire \derivative_reg[30]_i_15_n_6 ;
  wire \derivative_reg[30]_i_15_n_7 ;
  wire \derivative_reg[30]_i_1_n_2 ;
  wire \derivative_reg[30]_i_1_n_3 ;
  wire \derivative_reg[30]_i_1_n_7 ;
  wire \derivative_reg[30]_i_20_n_0 ;
  wire \derivative_reg[30]_i_20_n_1 ;
  wire \derivative_reg[30]_i_20_n_2 ;
  wire \derivative_reg[30]_i_20_n_3 ;
  wire \derivative_reg[30]_i_20_n_4 ;
  wire \derivative_reg[30]_i_20_n_5 ;
  wire \derivative_reg[30]_i_20_n_6 ;
  wire \derivative_reg[30]_i_20_n_7 ;
  wire \derivative_reg[30]_i_25_n_0 ;
  wire \derivative_reg[30]_i_25_n_1 ;
  wire \derivative_reg[30]_i_25_n_2 ;
  wire \derivative_reg[30]_i_25_n_3 ;
  wire \derivative_reg[30]_i_25_n_4 ;
  wire \derivative_reg[30]_i_25_n_5 ;
  wire \derivative_reg[30]_i_25_n_6 ;
  wire \derivative_reg[30]_i_25_n_7 ;
  wire \derivative_reg[30]_i_2_n_0 ;
  wire \derivative_reg[30]_i_2_n_1 ;
  wire \derivative_reg[30]_i_2_n_2 ;
  wire \derivative_reg[30]_i_2_n_3 ;
  wire \derivative_reg[30]_i_2_n_4 ;
  wire \derivative_reg[30]_i_2_n_5 ;
  wire \derivative_reg[30]_i_2_n_6 ;
  wire \derivative_reg[30]_i_2_n_7 ;
  wire \derivative_reg[30]_i_30_n_0 ;
  wire \derivative_reg[30]_i_30_n_1 ;
  wire \derivative_reg[30]_i_30_n_2 ;
  wire \derivative_reg[30]_i_30_n_3 ;
  wire \derivative_reg[30]_i_30_n_4 ;
  wire \derivative_reg[30]_i_30_n_5 ;
  wire \derivative_reg[30]_i_30_n_6 ;
  wire \derivative_reg[30]_i_30_n_7 ;
  wire \derivative_reg[30]_i_35_n_0 ;
  wire \derivative_reg[30]_i_35_n_1 ;
  wire \derivative_reg[30]_i_35_n_2 ;
  wire \derivative_reg[30]_i_35_n_3 ;
  wire \derivative_reg[30]_i_35_n_4 ;
  wire \derivative_reg[30]_i_35_n_5 ;
  wire \derivative_reg[30]_i_35_n_6 ;
  wire \derivative_reg[30]_i_5_n_0 ;
  wire \derivative_reg[30]_i_5_n_1 ;
  wire \derivative_reg[30]_i_5_n_2 ;
  wire \derivative_reg[30]_i_5_n_3 ;
  wire \derivative_reg[30]_i_5_n_4 ;
  wire \derivative_reg[30]_i_5_n_5 ;
  wire \derivative_reg[30]_i_5_n_6 ;
  wire \derivative_reg[30]_i_5_n_7 ;
  wire \derivative_reg[31]_i_12_n_0 ;
  wire \derivative_reg[31]_i_12_n_1 ;
  wire \derivative_reg[31]_i_12_n_2 ;
  wire \derivative_reg[31]_i_12_n_3 ;
  wire \derivative_reg[31]_i_12_n_4 ;
  wire \derivative_reg[31]_i_12_n_5 ;
  wire \derivative_reg[31]_i_12_n_6 ;
  wire \derivative_reg[31]_i_12_n_7 ;
  wire \derivative_reg[31]_i_1_n_3 ;
  wire \derivative_reg[31]_i_21_n_0 ;
  wire \derivative_reg[31]_i_21_n_1 ;
  wire \derivative_reg[31]_i_21_n_2 ;
  wire \derivative_reg[31]_i_21_n_3 ;
  wire \derivative_reg[31]_i_21_n_4 ;
  wire \derivative_reg[31]_i_21_n_5 ;
  wire \derivative_reg[31]_i_21_n_6 ;
  wire \derivative_reg[31]_i_21_n_7 ;
  wire \derivative_reg[31]_i_2_n_0 ;
  wire \derivative_reg[31]_i_2_n_1 ;
  wire \derivative_reg[31]_i_2_n_2 ;
  wire \derivative_reg[31]_i_2_n_3 ;
  wire \derivative_reg[31]_i_2_n_4 ;
  wire \derivative_reg[31]_i_2_n_5 ;
  wire \derivative_reg[31]_i_2_n_6 ;
  wire \derivative_reg[31]_i_2_n_7 ;
  wire \derivative_reg[31]_i_30_n_0 ;
  wire \derivative_reg[31]_i_30_n_1 ;
  wire \derivative_reg[31]_i_30_n_2 ;
  wire \derivative_reg[31]_i_30_n_3 ;
  wire \derivative_reg[31]_i_30_n_4 ;
  wire \derivative_reg[31]_i_30_n_5 ;
  wire \derivative_reg[31]_i_30_n_6 ;
  wire \derivative_reg[31]_i_30_n_7 ;
  wire \derivative_reg[31]_i_39_n_0 ;
  wire \derivative_reg[31]_i_39_n_1 ;
  wire \derivative_reg[31]_i_39_n_2 ;
  wire \derivative_reg[31]_i_39_n_3 ;
  wire \derivative_reg[31]_i_39_n_4 ;
  wire \derivative_reg[31]_i_39_n_5 ;
  wire \derivative_reg[31]_i_39_n_6 ;
  wire \derivative_reg[31]_i_39_n_7 ;
  wire \derivative_reg[31]_i_3_n_0 ;
  wire \derivative_reg[31]_i_3_n_1 ;
  wire \derivative_reg[31]_i_3_n_2 ;
  wire \derivative_reg[31]_i_3_n_3 ;
  wire \derivative_reg[31]_i_3_n_4 ;
  wire \derivative_reg[31]_i_3_n_5 ;
  wire \derivative_reg[31]_i_3_n_6 ;
  wire \derivative_reg[31]_i_3_n_7 ;
  wire \derivative_reg[31]_i_48_n_0 ;
  wire \derivative_reg[31]_i_48_n_1 ;
  wire \derivative_reg[31]_i_48_n_2 ;
  wire \derivative_reg[31]_i_48_n_3 ;
  wire \derivative_reg[31]_i_48_n_4 ;
  wire \derivative_reg[31]_i_48_n_5 ;
  wire \derivative_reg[31]_i_48_n_6 ;
  wire \derivative_reg[31]_i_48_n_7 ;
  wire \derivative_reg[31]_i_57_n_0 ;
  wire \derivative_reg[31]_i_57_n_1 ;
  wire \derivative_reg[31]_i_57_n_2 ;
  wire \derivative_reg[31]_i_57_n_3 ;
  wire \derivative_reg[31]_i_57_n_4 ;
  wire \derivative_reg[31]_i_57_n_5 ;
  wire \derivative_reg[31]_i_57_n_6 ;
  wire \derivative_reg[31]_i_57_n_7 ;
  wire \derivative_reg[3]_i_10_n_0 ;
  wire \derivative_reg[3]_i_10_n_1 ;
  wire \derivative_reg[3]_i_10_n_2 ;
  wire \derivative_reg[3]_i_10_n_3 ;
  wire \derivative_reg[3]_i_10_n_4 ;
  wire \derivative_reg[3]_i_10_n_5 ;
  wire \derivative_reg[3]_i_10_n_6 ;
  wire \derivative_reg[3]_i_10_n_7 ;
  wire \derivative_reg[3]_i_15_n_0 ;
  wire \derivative_reg[3]_i_15_n_1 ;
  wire \derivative_reg[3]_i_15_n_2 ;
  wire \derivative_reg[3]_i_15_n_3 ;
  wire \derivative_reg[3]_i_15_n_4 ;
  wire \derivative_reg[3]_i_15_n_5 ;
  wire \derivative_reg[3]_i_15_n_6 ;
  wire \derivative_reg[3]_i_15_n_7 ;
  wire \derivative_reg[3]_i_1_n_2 ;
  wire \derivative_reg[3]_i_1_n_3 ;
  wire \derivative_reg[3]_i_1_n_7 ;
  wire \derivative_reg[3]_i_20_n_0 ;
  wire \derivative_reg[3]_i_20_n_1 ;
  wire \derivative_reg[3]_i_20_n_2 ;
  wire \derivative_reg[3]_i_20_n_3 ;
  wire \derivative_reg[3]_i_20_n_4 ;
  wire \derivative_reg[3]_i_20_n_5 ;
  wire \derivative_reg[3]_i_20_n_6 ;
  wire \derivative_reg[3]_i_20_n_7 ;
  wire \derivative_reg[3]_i_25_n_0 ;
  wire \derivative_reg[3]_i_25_n_1 ;
  wire \derivative_reg[3]_i_25_n_2 ;
  wire \derivative_reg[3]_i_25_n_3 ;
  wire \derivative_reg[3]_i_25_n_4 ;
  wire \derivative_reg[3]_i_25_n_5 ;
  wire \derivative_reg[3]_i_25_n_6 ;
  wire \derivative_reg[3]_i_25_n_7 ;
  wire \derivative_reg[3]_i_2_n_0 ;
  wire \derivative_reg[3]_i_2_n_1 ;
  wire \derivative_reg[3]_i_2_n_2 ;
  wire \derivative_reg[3]_i_2_n_3 ;
  wire \derivative_reg[3]_i_2_n_4 ;
  wire \derivative_reg[3]_i_2_n_5 ;
  wire \derivative_reg[3]_i_2_n_6 ;
  wire \derivative_reg[3]_i_2_n_7 ;
  wire \derivative_reg[3]_i_30_n_0 ;
  wire \derivative_reg[3]_i_30_n_1 ;
  wire \derivative_reg[3]_i_30_n_2 ;
  wire \derivative_reg[3]_i_30_n_3 ;
  wire \derivative_reg[3]_i_30_n_4 ;
  wire \derivative_reg[3]_i_30_n_5 ;
  wire \derivative_reg[3]_i_30_n_6 ;
  wire \derivative_reg[3]_i_30_n_7 ;
  wire \derivative_reg[3]_i_35_n_0 ;
  wire \derivative_reg[3]_i_35_n_1 ;
  wire \derivative_reg[3]_i_35_n_2 ;
  wire \derivative_reg[3]_i_35_n_3 ;
  wire \derivative_reg[3]_i_35_n_4 ;
  wire \derivative_reg[3]_i_35_n_5 ;
  wire \derivative_reg[3]_i_35_n_6 ;
  wire \derivative_reg[3]_i_5_n_0 ;
  wire \derivative_reg[3]_i_5_n_1 ;
  wire \derivative_reg[3]_i_5_n_2 ;
  wire \derivative_reg[3]_i_5_n_3 ;
  wire \derivative_reg[3]_i_5_n_4 ;
  wire \derivative_reg[3]_i_5_n_5 ;
  wire \derivative_reg[3]_i_5_n_6 ;
  wire \derivative_reg[3]_i_5_n_7 ;
  wire \derivative_reg[4]_i_10_n_0 ;
  wire \derivative_reg[4]_i_10_n_1 ;
  wire \derivative_reg[4]_i_10_n_2 ;
  wire \derivative_reg[4]_i_10_n_3 ;
  wire \derivative_reg[4]_i_10_n_4 ;
  wire \derivative_reg[4]_i_10_n_5 ;
  wire \derivative_reg[4]_i_10_n_6 ;
  wire \derivative_reg[4]_i_10_n_7 ;
  wire \derivative_reg[4]_i_15_n_0 ;
  wire \derivative_reg[4]_i_15_n_1 ;
  wire \derivative_reg[4]_i_15_n_2 ;
  wire \derivative_reg[4]_i_15_n_3 ;
  wire \derivative_reg[4]_i_15_n_4 ;
  wire \derivative_reg[4]_i_15_n_5 ;
  wire \derivative_reg[4]_i_15_n_6 ;
  wire \derivative_reg[4]_i_15_n_7 ;
  wire \derivative_reg[4]_i_1_n_2 ;
  wire \derivative_reg[4]_i_1_n_3 ;
  wire \derivative_reg[4]_i_1_n_7 ;
  wire \derivative_reg[4]_i_20_n_0 ;
  wire \derivative_reg[4]_i_20_n_1 ;
  wire \derivative_reg[4]_i_20_n_2 ;
  wire \derivative_reg[4]_i_20_n_3 ;
  wire \derivative_reg[4]_i_20_n_4 ;
  wire \derivative_reg[4]_i_20_n_5 ;
  wire \derivative_reg[4]_i_20_n_6 ;
  wire \derivative_reg[4]_i_20_n_7 ;
  wire \derivative_reg[4]_i_25_n_0 ;
  wire \derivative_reg[4]_i_25_n_1 ;
  wire \derivative_reg[4]_i_25_n_2 ;
  wire \derivative_reg[4]_i_25_n_3 ;
  wire \derivative_reg[4]_i_25_n_4 ;
  wire \derivative_reg[4]_i_25_n_5 ;
  wire \derivative_reg[4]_i_25_n_6 ;
  wire \derivative_reg[4]_i_25_n_7 ;
  wire \derivative_reg[4]_i_2_n_0 ;
  wire \derivative_reg[4]_i_2_n_1 ;
  wire \derivative_reg[4]_i_2_n_2 ;
  wire \derivative_reg[4]_i_2_n_3 ;
  wire \derivative_reg[4]_i_2_n_4 ;
  wire \derivative_reg[4]_i_2_n_5 ;
  wire \derivative_reg[4]_i_2_n_6 ;
  wire \derivative_reg[4]_i_2_n_7 ;
  wire \derivative_reg[4]_i_30_n_0 ;
  wire \derivative_reg[4]_i_30_n_1 ;
  wire \derivative_reg[4]_i_30_n_2 ;
  wire \derivative_reg[4]_i_30_n_3 ;
  wire \derivative_reg[4]_i_30_n_4 ;
  wire \derivative_reg[4]_i_30_n_5 ;
  wire \derivative_reg[4]_i_30_n_6 ;
  wire \derivative_reg[4]_i_30_n_7 ;
  wire \derivative_reg[4]_i_35_n_0 ;
  wire \derivative_reg[4]_i_35_n_1 ;
  wire \derivative_reg[4]_i_35_n_2 ;
  wire \derivative_reg[4]_i_35_n_3 ;
  wire \derivative_reg[4]_i_35_n_4 ;
  wire \derivative_reg[4]_i_35_n_5 ;
  wire \derivative_reg[4]_i_35_n_6 ;
  wire \derivative_reg[4]_i_5_n_0 ;
  wire \derivative_reg[4]_i_5_n_1 ;
  wire \derivative_reg[4]_i_5_n_2 ;
  wire \derivative_reg[4]_i_5_n_3 ;
  wire \derivative_reg[4]_i_5_n_4 ;
  wire \derivative_reg[4]_i_5_n_5 ;
  wire \derivative_reg[4]_i_5_n_6 ;
  wire \derivative_reg[4]_i_5_n_7 ;
  wire \derivative_reg[5]_i_10_n_0 ;
  wire \derivative_reg[5]_i_10_n_1 ;
  wire \derivative_reg[5]_i_10_n_2 ;
  wire \derivative_reg[5]_i_10_n_3 ;
  wire \derivative_reg[5]_i_10_n_4 ;
  wire \derivative_reg[5]_i_10_n_5 ;
  wire \derivative_reg[5]_i_10_n_6 ;
  wire \derivative_reg[5]_i_10_n_7 ;
  wire \derivative_reg[5]_i_15_n_0 ;
  wire \derivative_reg[5]_i_15_n_1 ;
  wire \derivative_reg[5]_i_15_n_2 ;
  wire \derivative_reg[5]_i_15_n_3 ;
  wire \derivative_reg[5]_i_15_n_4 ;
  wire \derivative_reg[5]_i_15_n_5 ;
  wire \derivative_reg[5]_i_15_n_6 ;
  wire \derivative_reg[5]_i_15_n_7 ;
  wire \derivative_reg[5]_i_1_n_2 ;
  wire \derivative_reg[5]_i_1_n_3 ;
  wire \derivative_reg[5]_i_1_n_7 ;
  wire \derivative_reg[5]_i_20_n_0 ;
  wire \derivative_reg[5]_i_20_n_1 ;
  wire \derivative_reg[5]_i_20_n_2 ;
  wire \derivative_reg[5]_i_20_n_3 ;
  wire \derivative_reg[5]_i_20_n_4 ;
  wire \derivative_reg[5]_i_20_n_5 ;
  wire \derivative_reg[5]_i_20_n_6 ;
  wire \derivative_reg[5]_i_20_n_7 ;
  wire \derivative_reg[5]_i_25_n_0 ;
  wire \derivative_reg[5]_i_25_n_1 ;
  wire \derivative_reg[5]_i_25_n_2 ;
  wire \derivative_reg[5]_i_25_n_3 ;
  wire \derivative_reg[5]_i_25_n_4 ;
  wire \derivative_reg[5]_i_25_n_5 ;
  wire \derivative_reg[5]_i_25_n_6 ;
  wire \derivative_reg[5]_i_25_n_7 ;
  wire \derivative_reg[5]_i_2_n_0 ;
  wire \derivative_reg[5]_i_2_n_1 ;
  wire \derivative_reg[5]_i_2_n_2 ;
  wire \derivative_reg[5]_i_2_n_3 ;
  wire \derivative_reg[5]_i_2_n_4 ;
  wire \derivative_reg[5]_i_2_n_5 ;
  wire \derivative_reg[5]_i_2_n_6 ;
  wire \derivative_reg[5]_i_2_n_7 ;
  wire \derivative_reg[5]_i_30_n_0 ;
  wire \derivative_reg[5]_i_30_n_1 ;
  wire \derivative_reg[5]_i_30_n_2 ;
  wire \derivative_reg[5]_i_30_n_3 ;
  wire \derivative_reg[5]_i_30_n_4 ;
  wire \derivative_reg[5]_i_30_n_5 ;
  wire \derivative_reg[5]_i_30_n_6 ;
  wire \derivative_reg[5]_i_30_n_7 ;
  wire \derivative_reg[5]_i_35_n_0 ;
  wire \derivative_reg[5]_i_35_n_1 ;
  wire \derivative_reg[5]_i_35_n_2 ;
  wire \derivative_reg[5]_i_35_n_3 ;
  wire \derivative_reg[5]_i_35_n_4 ;
  wire \derivative_reg[5]_i_35_n_5 ;
  wire \derivative_reg[5]_i_35_n_6 ;
  wire \derivative_reg[5]_i_5_n_0 ;
  wire \derivative_reg[5]_i_5_n_1 ;
  wire \derivative_reg[5]_i_5_n_2 ;
  wire \derivative_reg[5]_i_5_n_3 ;
  wire \derivative_reg[5]_i_5_n_4 ;
  wire \derivative_reg[5]_i_5_n_5 ;
  wire \derivative_reg[5]_i_5_n_6 ;
  wire \derivative_reg[5]_i_5_n_7 ;
  wire \derivative_reg[6]_i_10_n_0 ;
  wire \derivative_reg[6]_i_10_n_1 ;
  wire \derivative_reg[6]_i_10_n_2 ;
  wire \derivative_reg[6]_i_10_n_3 ;
  wire \derivative_reg[6]_i_10_n_4 ;
  wire \derivative_reg[6]_i_10_n_5 ;
  wire \derivative_reg[6]_i_10_n_6 ;
  wire \derivative_reg[6]_i_10_n_7 ;
  wire \derivative_reg[6]_i_15_n_0 ;
  wire \derivative_reg[6]_i_15_n_1 ;
  wire \derivative_reg[6]_i_15_n_2 ;
  wire \derivative_reg[6]_i_15_n_3 ;
  wire \derivative_reg[6]_i_15_n_4 ;
  wire \derivative_reg[6]_i_15_n_5 ;
  wire \derivative_reg[6]_i_15_n_6 ;
  wire \derivative_reg[6]_i_15_n_7 ;
  wire \derivative_reg[6]_i_1_n_2 ;
  wire \derivative_reg[6]_i_1_n_3 ;
  wire \derivative_reg[6]_i_1_n_7 ;
  wire \derivative_reg[6]_i_20_n_0 ;
  wire \derivative_reg[6]_i_20_n_1 ;
  wire \derivative_reg[6]_i_20_n_2 ;
  wire \derivative_reg[6]_i_20_n_3 ;
  wire \derivative_reg[6]_i_20_n_4 ;
  wire \derivative_reg[6]_i_20_n_5 ;
  wire \derivative_reg[6]_i_20_n_6 ;
  wire \derivative_reg[6]_i_20_n_7 ;
  wire \derivative_reg[6]_i_25_n_0 ;
  wire \derivative_reg[6]_i_25_n_1 ;
  wire \derivative_reg[6]_i_25_n_2 ;
  wire \derivative_reg[6]_i_25_n_3 ;
  wire \derivative_reg[6]_i_25_n_4 ;
  wire \derivative_reg[6]_i_25_n_5 ;
  wire \derivative_reg[6]_i_25_n_6 ;
  wire \derivative_reg[6]_i_25_n_7 ;
  wire \derivative_reg[6]_i_2_n_0 ;
  wire \derivative_reg[6]_i_2_n_1 ;
  wire \derivative_reg[6]_i_2_n_2 ;
  wire \derivative_reg[6]_i_2_n_3 ;
  wire \derivative_reg[6]_i_2_n_4 ;
  wire \derivative_reg[6]_i_2_n_5 ;
  wire \derivative_reg[6]_i_2_n_6 ;
  wire \derivative_reg[6]_i_2_n_7 ;
  wire \derivative_reg[6]_i_30_n_0 ;
  wire \derivative_reg[6]_i_30_n_1 ;
  wire \derivative_reg[6]_i_30_n_2 ;
  wire \derivative_reg[6]_i_30_n_3 ;
  wire \derivative_reg[6]_i_30_n_4 ;
  wire \derivative_reg[6]_i_30_n_5 ;
  wire \derivative_reg[6]_i_30_n_6 ;
  wire \derivative_reg[6]_i_30_n_7 ;
  wire \derivative_reg[6]_i_35_n_0 ;
  wire \derivative_reg[6]_i_35_n_1 ;
  wire \derivative_reg[6]_i_35_n_2 ;
  wire \derivative_reg[6]_i_35_n_3 ;
  wire \derivative_reg[6]_i_35_n_4 ;
  wire \derivative_reg[6]_i_35_n_5 ;
  wire \derivative_reg[6]_i_35_n_6 ;
  wire \derivative_reg[6]_i_5_n_0 ;
  wire \derivative_reg[6]_i_5_n_1 ;
  wire \derivative_reg[6]_i_5_n_2 ;
  wire \derivative_reg[6]_i_5_n_3 ;
  wire \derivative_reg[6]_i_5_n_4 ;
  wire \derivative_reg[6]_i_5_n_5 ;
  wire \derivative_reg[6]_i_5_n_6 ;
  wire \derivative_reg[6]_i_5_n_7 ;
  wire \derivative_reg[7]_i_10_n_0 ;
  wire \derivative_reg[7]_i_10_n_1 ;
  wire \derivative_reg[7]_i_10_n_2 ;
  wire \derivative_reg[7]_i_10_n_3 ;
  wire \derivative_reg[7]_i_10_n_4 ;
  wire \derivative_reg[7]_i_10_n_5 ;
  wire \derivative_reg[7]_i_10_n_6 ;
  wire \derivative_reg[7]_i_10_n_7 ;
  wire \derivative_reg[7]_i_15_n_0 ;
  wire \derivative_reg[7]_i_15_n_1 ;
  wire \derivative_reg[7]_i_15_n_2 ;
  wire \derivative_reg[7]_i_15_n_3 ;
  wire \derivative_reg[7]_i_15_n_4 ;
  wire \derivative_reg[7]_i_15_n_5 ;
  wire \derivative_reg[7]_i_15_n_6 ;
  wire \derivative_reg[7]_i_15_n_7 ;
  wire \derivative_reg[7]_i_1_n_2 ;
  wire \derivative_reg[7]_i_1_n_3 ;
  wire \derivative_reg[7]_i_1_n_7 ;
  wire \derivative_reg[7]_i_20_n_0 ;
  wire \derivative_reg[7]_i_20_n_1 ;
  wire \derivative_reg[7]_i_20_n_2 ;
  wire \derivative_reg[7]_i_20_n_3 ;
  wire \derivative_reg[7]_i_20_n_4 ;
  wire \derivative_reg[7]_i_20_n_5 ;
  wire \derivative_reg[7]_i_20_n_6 ;
  wire \derivative_reg[7]_i_20_n_7 ;
  wire \derivative_reg[7]_i_25_n_0 ;
  wire \derivative_reg[7]_i_25_n_1 ;
  wire \derivative_reg[7]_i_25_n_2 ;
  wire \derivative_reg[7]_i_25_n_3 ;
  wire \derivative_reg[7]_i_25_n_4 ;
  wire \derivative_reg[7]_i_25_n_5 ;
  wire \derivative_reg[7]_i_25_n_6 ;
  wire \derivative_reg[7]_i_25_n_7 ;
  wire \derivative_reg[7]_i_2_n_0 ;
  wire \derivative_reg[7]_i_2_n_1 ;
  wire \derivative_reg[7]_i_2_n_2 ;
  wire \derivative_reg[7]_i_2_n_3 ;
  wire \derivative_reg[7]_i_2_n_4 ;
  wire \derivative_reg[7]_i_2_n_5 ;
  wire \derivative_reg[7]_i_2_n_6 ;
  wire \derivative_reg[7]_i_2_n_7 ;
  wire \derivative_reg[7]_i_30_n_0 ;
  wire \derivative_reg[7]_i_30_n_1 ;
  wire \derivative_reg[7]_i_30_n_2 ;
  wire \derivative_reg[7]_i_30_n_3 ;
  wire \derivative_reg[7]_i_30_n_4 ;
  wire \derivative_reg[7]_i_30_n_5 ;
  wire \derivative_reg[7]_i_30_n_6 ;
  wire \derivative_reg[7]_i_30_n_7 ;
  wire \derivative_reg[7]_i_35_n_0 ;
  wire \derivative_reg[7]_i_35_n_1 ;
  wire \derivative_reg[7]_i_35_n_2 ;
  wire \derivative_reg[7]_i_35_n_3 ;
  wire \derivative_reg[7]_i_35_n_4 ;
  wire \derivative_reg[7]_i_35_n_5 ;
  wire \derivative_reg[7]_i_35_n_6 ;
  wire \derivative_reg[7]_i_5_n_0 ;
  wire \derivative_reg[7]_i_5_n_1 ;
  wire \derivative_reg[7]_i_5_n_2 ;
  wire \derivative_reg[7]_i_5_n_3 ;
  wire \derivative_reg[7]_i_5_n_4 ;
  wire \derivative_reg[7]_i_5_n_5 ;
  wire \derivative_reg[7]_i_5_n_6 ;
  wire \derivative_reg[7]_i_5_n_7 ;
  wire \derivative_reg[8]_i_10_n_0 ;
  wire \derivative_reg[8]_i_10_n_1 ;
  wire \derivative_reg[8]_i_10_n_2 ;
  wire \derivative_reg[8]_i_10_n_3 ;
  wire \derivative_reg[8]_i_10_n_4 ;
  wire \derivative_reg[8]_i_10_n_5 ;
  wire \derivative_reg[8]_i_10_n_6 ;
  wire \derivative_reg[8]_i_10_n_7 ;
  wire \derivative_reg[8]_i_15_n_0 ;
  wire \derivative_reg[8]_i_15_n_1 ;
  wire \derivative_reg[8]_i_15_n_2 ;
  wire \derivative_reg[8]_i_15_n_3 ;
  wire \derivative_reg[8]_i_15_n_4 ;
  wire \derivative_reg[8]_i_15_n_5 ;
  wire \derivative_reg[8]_i_15_n_6 ;
  wire \derivative_reg[8]_i_15_n_7 ;
  wire \derivative_reg[8]_i_1_n_2 ;
  wire \derivative_reg[8]_i_1_n_3 ;
  wire \derivative_reg[8]_i_1_n_7 ;
  wire \derivative_reg[8]_i_20_n_0 ;
  wire \derivative_reg[8]_i_20_n_1 ;
  wire \derivative_reg[8]_i_20_n_2 ;
  wire \derivative_reg[8]_i_20_n_3 ;
  wire \derivative_reg[8]_i_20_n_4 ;
  wire \derivative_reg[8]_i_20_n_5 ;
  wire \derivative_reg[8]_i_20_n_6 ;
  wire \derivative_reg[8]_i_20_n_7 ;
  wire \derivative_reg[8]_i_25_n_0 ;
  wire \derivative_reg[8]_i_25_n_1 ;
  wire \derivative_reg[8]_i_25_n_2 ;
  wire \derivative_reg[8]_i_25_n_3 ;
  wire \derivative_reg[8]_i_25_n_4 ;
  wire \derivative_reg[8]_i_25_n_5 ;
  wire \derivative_reg[8]_i_25_n_6 ;
  wire \derivative_reg[8]_i_25_n_7 ;
  wire \derivative_reg[8]_i_2_n_0 ;
  wire \derivative_reg[8]_i_2_n_1 ;
  wire \derivative_reg[8]_i_2_n_2 ;
  wire \derivative_reg[8]_i_2_n_3 ;
  wire \derivative_reg[8]_i_2_n_4 ;
  wire \derivative_reg[8]_i_2_n_5 ;
  wire \derivative_reg[8]_i_2_n_6 ;
  wire \derivative_reg[8]_i_2_n_7 ;
  wire \derivative_reg[8]_i_30_n_0 ;
  wire \derivative_reg[8]_i_30_n_1 ;
  wire \derivative_reg[8]_i_30_n_2 ;
  wire \derivative_reg[8]_i_30_n_3 ;
  wire \derivative_reg[8]_i_30_n_4 ;
  wire \derivative_reg[8]_i_30_n_5 ;
  wire \derivative_reg[8]_i_30_n_6 ;
  wire \derivative_reg[8]_i_30_n_7 ;
  wire \derivative_reg[8]_i_35_n_0 ;
  wire \derivative_reg[8]_i_35_n_1 ;
  wire \derivative_reg[8]_i_35_n_2 ;
  wire \derivative_reg[8]_i_35_n_3 ;
  wire \derivative_reg[8]_i_35_n_4 ;
  wire \derivative_reg[8]_i_35_n_5 ;
  wire \derivative_reg[8]_i_35_n_6 ;
  wire \derivative_reg[8]_i_5_n_0 ;
  wire \derivative_reg[8]_i_5_n_1 ;
  wire \derivative_reg[8]_i_5_n_2 ;
  wire \derivative_reg[8]_i_5_n_3 ;
  wire \derivative_reg[8]_i_5_n_4 ;
  wire \derivative_reg[8]_i_5_n_5 ;
  wire \derivative_reg[8]_i_5_n_6 ;
  wire \derivative_reg[8]_i_5_n_7 ;
  wire \derivative_reg[9]_i_10_n_0 ;
  wire \derivative_reg[9]_i_10_n_1 ;
  wire \derivative_reg[9]_i_10_n_2 ;
  wire \derivative_reg[9]_i_10_n_3 ;
  wire \derivative_reg[9]_i_10_n_4 ;
  wire \derivative_reg[9]_i_10_n_5 ;
  wire \derivative_reg[9]_i_10_n_6 ;
  wire \derivative_reg[9]_i_10_n_7 ;
  wire \derivative_reg[9]_i_15_n_0 ;
  wire \derivative_reg[9]_i_15_n_1 ;
  wire \derivative_reg[9]_i_15_n_2 ;
  wire \derivative_reg[9]_i_15_n_3 ;
  wire \derivative_reg[9]_i_15_n_4 ;
  wire \derivative_reg[9]_i_15_n_5 ;
  wire \derivative_reg[9]_i_15_n_6 ;
  wire \derivative_reg[9]_i_15_n_7 ;
  wire \derivative_reg[9]_i_1_n_2 ;
  wire \derivative_reg[9]_i_1_n_3 ;
  wire \derivative_reg[9]_i_1_n_7 ;
  wire \derivative_reg[9]_i_20_n_0 ;
  wire \derivative_reg[9]_i_20_n_1 ;
  wire \derivative_reg[9]_i_20_n_2 ;
  wire \derivative_reg[9]_i_20_n_3 ;
  wire \derivative_reg[9]_i_20_n_4 ;
  wire \derivative_reg[9]_i_20_n_5 ;
  wire \derivative_reg[9]_i_20_n_6 ;
  wire \derivative_reg[9]_i_20_n_7 ;
  wire \derivative_reg[9]_i_25_n_0 ;
  wire \derivative_reg[9]_i_25_n_1 ;
  wire \derivative_reg[9]_i_25_n_2 ;
  wire \derivative_reg[9]_i_25_n_3 ;
  wire \derivative_reg[9]_i_25_n_4 ;
  wire \derivative_reg[9]_i_25_n_5 ;
  wire \derivative_reg[9]_i_25_n_6 ;
  wire \derivative_reg[9]_i_25_n_7 ;
  wire \derivative_reg[9]_i_2_n_0 ;
  wire \derivative_reg[9]_i_2_n_1 ;
  wire \derivative_reg[9]_i_2_n_2 ;
  wire \derivative_reg[9]_i_2_n_3 ;
  wire \derivative_reg[9]_i_2_n_4 ;
  wire \derivative_reg[9]_i_2_n_5 ;
  wire \derivative_reg[9]_i_2_n_6 ;
  wire \derivative_reg[9]_i_2_n_7 ;
  wire \derivative_reg[9]_i_30_n_0 ;
  wire \derivative_reg[9]_i_30_n_1 ;
  wire \derivative_reg[9]_i_30_n_2 ;
  wire \derivative_reg[9]_i_30_n_3 ;
  wire \derivative_reg[9]_i_30_n_4 ;
  wire \derivative_reg[9]_i_30_n_5 ;
  wire \derivative_reg[9]_i_30_n_6 ;
  wire \derivative_reg[9]_i_30_n_7 ;
  wire \derivative_reg[9]_i_35_n_0 ;
  wire \derivative_reg[9]_i_35_n_1 ;
  wire \derivative_reg[9]_i_35_n_2 ;
  wire \derivative_reg[9]_i_35_n_3 ;
  wire \derivative_reg[9]_i_35_n_4 ;
  wire \derivative_reg[9]_i_35_n_5 ;
  wire \derivative_reg[9]_i_35_n_6 ;
  wire \derivative_reg[9]_i_5_n_0 ;
  wire \derivative_reg[9]_i_5_n_1 ;
  wire \derivative_reg[9]_i_5_n_2 ;
  wire \derivative_reg[9]_i_5_n_3 ;
  wire \derivative_reg[9]_i_5_n_4 ;
  wire \derivative_reg[9]_i_5_n_5 ;
  wire \derivative_reg[9]_i_5_n_6 ;
  wire \derivative_reg[9]_i_5_n_7 ;
  wire [31:0]dt;
  wire [31:0]error02_out;
  wire error0_carry__0_i_1_n_0;
  wire error0_carry__0_i_2_n_0;
  wire error0_carry__0_i_3_n_0;
  wire error0_carry__0_i_4_n_0;
  wire error0_carry__0_n_0;
  wire error0_carry__0_n_1;
  wire error0_carry__0_n_2;
  wire error0_carry__0_n_3;
  wire error0_carry__1_i_1_n_0;
  wire error0_carry__1_i_2_n_0;
  wire error0_carry__1_i_3_n_0;
  wire error0_carry__1_i_4_n_0;
  wire error0_carry__1_n_0;
  wire error0_carry__1_n_1;
  wire error0_carry__1_n_2;
  wire error0_carry__1_n_3;
  wire error0_carry__2_i_1_n_0;
  wire error0_carry__2_i_2_n_0;
  wire error0_carry__2_i_3_n_0;
  wire error0_carry__2_i_4_n_0;
  wire error0_carry__2_n_0;
  wire error0_carry__2_n_1;
  wire error0_carry__2_n_2;
  wire error0_carry__2_n_3;
  wire error0_carry__3_i_1_n_0;
  wire error0_carry__3_i_2_n_0;
  wire error0_carry__3_i_3_n_0;
  wire error0_carry__3_i_4_n_0;
  wire error0_carry__3_n_0;
  wire error0_carry__3_n_1;
  wire error0_carry__3_n_2;
  wire error0_carry__3_n_3;
  wire error0_carry__4_i_1_n_0;
  wire error0_carry__4_i_2_n_0;
  wire error0_carry__4_i_3_n_0;
  wire error0_carry__4_i_4_n_0;
  wire error0_carry__4_n_0;
  wire error0_carry__4_n_1;
  wire error0_carry__4_n_2;
  wire error0_carry__4_n_3;
  wire error0_carry__5_i_1_n_0;
  wire error0_carry__5_i_2_n_0;
  wire error0_carry__5_i_3_n_0;
  wire error0_carry__5_i_4_n_0;
  wire error0_carry__5_n_0;
  wire error0_carry__5_n_1;
  wire error0_carry__5_n_2;
  wire error0_carry__5_n_3;
  wire error0_carry__6_i_1_n_0;
  wire error0_carry__6_i_2_n_0;
  wire error0_carry__6_i_3_n_0;
  wire error0_carry__6_i_4_n_0;
  wire error0_carry__6_n_1;
  wire error0_carry__6_n_2;
  wire error0_carry__6_n_3;
  wire error0_carry_i_1_n_0;
  wire error0_carry_i_2_n_0;
  wire error0_carry_i_3_n_0;
  wire error0_carry_i_4_n_0;
  wire error0_carry_n_0;
  wire error0_carry_n_1;
  wire error0_carry_n_2;
  wire error0_carry_n_3;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral0;
  wire integral0_carry__0_i_1_n_0;
  wire integral0_carry__0_i_2_n_0;
  wire integral0_carry__0_i_3_n_0;
  wire integral0_carry__0_i_4_n_0;
  wire integral0_carry__0_n_0;
  wire integral0_carry__0_n_1;
  wire integral0_carry__0_n_2;
  wire integral0_carry__0_n_3;
  wire integral0_carry__1_i_1_n_0;
  wire integral0_carry__1_i_2_n_0;
  wire integral0_carry__1_i_3_n_0;
  wire integral0_carry__1_i_4_n_0;
  wire integral0_carry__1_n_0;
  wire integral0_carry__1_n_1;
  wire integral0_carry__1_n_2;
  wire integral0_carry__1_n_3;
  wire integral0_carry__2_i_1_n_0;
  wire integral0_carry__2_i_2_n_0;
  wire integral0_carry__2_i_3_n_0;
  wire integral0_carry__2_i_4_n_0;
  wire integral0_carry__2_n_0;
  wire integral0_carry__2_n_1;
  wire integral0_carry__2_n_2;
  wire integral0_carry__2_n_3;
  wire integral0_carry__3_i_1_n_0;
  wire integral0_carry__3_i_2_n_0;
  wire integral0_carry__3_i_3_n_0;
  wire integral0_carry__3_i_4_n_0;
  wire integral0_carry__3_n_0;
  wire integral0_carry__3_n_1;
  wire integral0_carry__3_n_2;
  wire integral0_carry__3_n_3;
  wire integral0_carry__4_i_1_n_0;
  wire integral0_carry__4_i_2_n_0;
  wire integral0_carry__4_i_3_n_0;
  wire integral0_carry__4_i_4_n_0;
  wire integral0_carry__4_n_0;
  wire integral0_carry__4_n_1;
  wire integral0_carry__4_n_2;
  wire integral0_carry__4_n_3;
  wire integral0_carry__5_i_1_n_0;
  wire integral0_carry__5_i_2_n_0;
  wire integral0_carry__5_i_3_n_0;
  wire integral0_carry__5_i_4_n_0;
  wire integral0_carry__5_n_0;
  wire integral0_carry__5_n_1;
  wire integral0_carry__5_n_2;
  wire integral0_carry__5_n_3;
  wire integral0_carry__6_i_1_n_0;
  wire integral0_carry__6_i_2_n_0;
  wire integral0_carry__6_i_3_n_0;
  wire integral0_carry__6_i_4_n_0;
  wire integral0_carry__6_n_1;
  wire integral0_carry__6_n_2;
  wire integral0_carry__6_n_3;
  wire integral0_carry_i_1_n_0;
  wire integral0_carry_i_2_n_0;
  wire integral0_carry_i_3_n_0;
  wire integral0_carry_i_4_n_0;
  wire integral0_carry_n_0;
  wire integral0_carry_n_1;
  wire integral0_carry_n_2;
  wire integral0_carry_n_3;
  wire integral1__0_n_100;
  wire integral1__0_n_101;
  wire integral1__0_n_102;
  wire integral1__0_n_103;
  wire integral1__0_n_104;
  wire integral1__0_n_105;
  wire integral1__0_n_106;
  wire integral1__0_n_107;
  wire integral1__0_n_108;
  wire integral1__0_n_109;
  wire integral1__0_n_110;
  wire integral1__0_n_111;
  wire integral1__0_n_112;
  wire integral1__0_n_113;
  wire integral1__0_n_114;
  wire integral1__0_n_115;
  wire integral1__0_n_116;
  wire integral1__0_n_117;
  wire integral1__0_n_118;
  wire integral1__0_n_119;
  wire integral1__0_n_120;
  wire integral1__0_n_121;
  wire integral1__0_n_122;
  wire integral1__0_n_123;
  wire integral1__0_n_124;
  wire integral1__0_n_125;
  wire integral1__0_n_126;
  wire integral1__0_n_127;
  wire integral1__0_n_128;
  wire integral1__0_n_129;
  wire integral1__0_n_130;
  wire integral1__0_n_131;
  wire integral1__0_n_132;
  wire integral1__0_n_133;
  wire integral1__0_n_134;
  wire integral1__0_n_135;
  wire integral1__0_n_136;
  wire integral1__0_n_137;
  wire integral1__0_n_138;
  wire integral1__0_n_139;
  wire integral1__0_n_140;
  wire integral1__0_n_141;
  wire integral1__0_n_142;
  wire integral1__0_n_143;
  wire integral1__0_n_144;
  wire integral1__0_n_145;
  wire integral1__0_n_146;
  wire integral1__0_n_147;
  wire integral1__0_n_148;
  wire integral1__0_n_149;
  wire integral1__0_n_150;
  wire integral1__0_n_151;
  wire integral1__0_n_152;
  wire integral1__0_n_153;
  wire integral1__0_n_58;
  wire integral1__0_n_59;
  wire integral1__0_n_60;
  wire integral1__0_n_61;
  wire integral1__0_n_62;
  wire integral1__0_n_63;
  wire integral1__0_n_64;
  wire integral1__0_n_65;
  wire integral1__0_n_66;
  wire integral1__0_n_67;
  wire integral1__0_n_68;
  wire integral1__0_n_69;
  wire integral1__0_n_70;
  wire integral1__0_n_71;
  wire integral1__0_n_72;
  wire integral1__0_n_73;
  wire integral1__0_n_74;
  wire integral1__0_n_75;
  wire integral1__0_n_76;
  wire integral1__0_n_77;
  wire integral1__0_n_78;
  wire integral1__0_n_79;
  wire integral1__0_n_80;
  wire integral1__0_n_81;
  wire integral1__0_n_82;
  wire integral1__0_n_83;
  wire integral1__0_n_84;
  wire integral1__0_n_85;
  wire integral1__0_n_86;
  wire integral1__0_n_87;
  wire integral1__0_n_88;
  wire integral1__0_n_89;
  wire integral1__0_n_90;
  wire integral1__0_n_91;
  wire integral1__0_n_92;
  wire integral1__0_n_93;
  wire integral1__0_n_94;
  wire integral1__0_n_95;
  wire integral1__0_n_96;
  wire integral1__0_n_97;
  wire integral1__0_n_98;
  wire integral1__0_n_99;
  wire integral1__1_n_100;
  wire integral1__1_n_101;
  wire integral1__1_n_102;
  wire integral1__1_n_103;
  wire integral1__1_n_104;
  wire integral1__1_n_105;
  wire integral1__1_n_58;
  wire integral1__1_n_59;
  wire integral1__1_n_60;
  wire integral1__1_n_61;
  wire integral1__1_n_62;
  wire integral1__1_n_63;
  wire integral1__1_n_64;
  wire integral1__1_n_65;
  wire integral1__1_n_66;
  wire integral1__1_n_67;
  wire integral1__1_n_68;
  wire integral1__1_n_69;
  wire integral1__1_n_70;
  wire integral1__1_n_71;
  wire integral1__1_n_72;
  wire integral1__1_n_73;
  wire integral1__1_n_74;
  wire integral1__1_n_75;
  wire integral1__1_n_76;
  wire integral1__1_n_77;
  wire integral1__1_n_78;
  wire integral1__1_n_79;
  wire integral1__1_n_80;
  wire integral1__1_n_81;
  wire integral1__1_n_82;
  wire integral1__1_n_83;
  wire integral1__1_n_84;
  wire integral1__1_n_85;
  wire integral1__1_n_86;
  wire integral1__1_n_87;
  wire integral1__1_n_88;
  wire integral1__1_n_89;
  wire integral1__1_n_90;
  wire integral1__1_n_91;
  wire integral1__1_n_92;
  wire integral1__1_n_93;
  wire integral1__1_n_94;
  wire integral1__1_n_95;
  wire integral1__1_n_96;
  wire integral1__1_n_97;
  wire integral1__1_n_98;
  wire integral1__1_n_99;
  wire integral1_carry__0_i_1_n_0;
  wire integral1_carry__0_i_2_n_0;
  wire integral1_carry__0_i_3_n_0;
  wire integral1_carry__0_i_4_n_0;
  wire integral1_carry__0_n_0;
  wire integral1_carry__0_n_1;
  wire integral1_carry__0_n_2;
  wire integral1_carry__0_n_3;
  wire integral1_carry__0_n_4;
  wire integral1_carry__0_n_5;
  wire integral1_carry__0_n_6;
  wire integral1_carry__0_n_7;
  wire integral1_carry__1_i_1_n_0;
  wire integral1_carry__1_i_2_n_0;
  wire integral1_carry__1_i_3_n_0;
  wire integral1_carry__1_i_4_n_0;
  wire integral1_carry__1_n_0;
  wire integral1_carry__1_n_1;
  wire integral1_carry__1_n_2;
  wire integral1_carry__1_n_3;
  wire integral1_carry__1_n_4;
  wire integral1_carry__1_n_5;
  wire integral1_carry__1_n_6;
  wire integral1_carry__1_n_7;
  wire integral1_carry__2_i_1_n_0;
  wire integral1_carry__2_i_2_n_0;
  wire integral1_carry__2_i_3_n_0;
  wire integral1_carry__2_i_4_n_0;
  wire integral1_carry__2_n_1;
  wire integral1_carry__2_n_2;
  wire integral1_carry__2_n_3;
  wire integral1_carry__2_n_4;
  wire integral1_carry__2_n_5;
  wire integral1_carry__2_n_6;
  wire integral1_carry__2_n_7;
  wire integral1_carry_i_1_n_0;
  wire integral1_carry_i_2_n_0;
  wire integral1_carry_i_3_n_0;
  wire integral1_carry_n_0;
  wire integral1_carry_n_1;
  wire integral1_carry_n_2;
  wire integral1_carry_n_3;
  wire integral1_carry_n_4;
  wire integral1_carry_n_5;
  wire integral1_carry_n_6;
  wire integral1_carry_n_7;
  wire integral1_n_100;
  wire integral1_n_101;
  wire integral1_n_102;
  wire integral1_n_103;
  wire integral1_n_104;
  wire integral1_n_105;
  wire integral1_n_106;
  wire integral1_n_107;
  wire integral1_n_108;
  wire integral1_n_109;
  wire integral1_n_110;
  wire integral1_n_111;
  wire integral1_n_112;
  wire integral1_n_113;
  wire integral1_n_114;
  wire integral1_n_115;
  wire integral1_n_116;
  wire integral1_n_117;
  wire integral1_n_118;
  wire integral1_n_119;
  wire integral1_n_120;
  wire integral1_n_121;
  wire integral1_n_122;
  wire integral1_n_123;
  wire integral1_n_124;
  wire integral1_n_125;
  wire integral1_n_126;
  wire integral1_n_127;
  wire integral1_n_128;
  wire integral1_n_129;
  wire integral1_n_130;
  wire integral1_n_131;
  wire integral1_n_132;
  wire integral1_n_133;
  wire integral1_n_134;
  wire integral1_n_135;
  wire integral1_n_136;
  wire integral1_n_137;
  wire integral1_n_138;
  wire integral1_n_139;
  wire integral1_n_140;
  wire integral1_n_141;
  wire integral1_n_142;
  wire integral1_n_143;
  wire integral1_n_144;
  wire integral1_n_145;
  wire integral1_n_146;
  wire integral1_n_147;
  wire integral1_n_148;
  wire integral1_n_149;
  wire integral1_n_150;
  wire integral1_n_151;
  wire integral1_n_152;
  wire integral1_n_153;
  wire integral1_n_58;
  wire integral1_n_59;
  wire integral1_n_60;
  wire integral1_n_61;
  wire integral1_n_62;
  wire integral1_n_63;
  wire integral1_n_64;
  wire integral1_n_65;
  wire integral1_n_66;
  wire integral1_n_67;
  wire integral1_n_68;
  wire integral1_n_69;
  wire integral1_n_70;
  wire integral1_n_71;
  wire integral1_n_72;
  wire integral1_n_73;
  wire integral1_n_74;
  wire integral1_n_75;
  wire integral1_n_76;
  wire integral1_n_77;
  wire integral1_n_78;
  wire integral1_n_79;
  wire integral1_n_80;
  wire integral1_n_81;
  wire integral1_n_82;
  wire integral1_n_83;
  wire integral1_n_84;
  wire integral1_n_85;
  wire integral1_n_86;
  wire integral1_n_87;
  wire integral1_n_88;
  wire integral1_n_89;
  wire integral1_n_90;
  wire integral1_n_91;
  wire integral1_n_92;
  wire integral1_n_93;
  wire integral1_n_94;
  wire integral1_n_95;
  wire integral1_n_96;
  wire integral1_n_97;
  wire integral1_n_98;
  wire integral1_n_99;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire [0:0]new_angle_available;
  wire [0:0]new_target_angle_available;
  wire [31:0]target_angle;
  wire [3:3]NLW_derivative1__0_carry__6_CO_UNCONNECTED;
  wire [3:1]\NLW_derivative_reg[0]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_14_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_19_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_24_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_29_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_34_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_4_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[0]_i_9_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[10]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[10]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[10]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[11]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[11]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[11]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[12]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[12]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[12]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[13]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[13]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[13]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[14]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[14]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[14]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[15]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[15]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[15]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[16]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[16]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[16]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[17]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[17]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[17]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[18]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[18]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[18]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[19]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[19]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[19]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[1]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[1]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[1]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[20]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[20]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[20]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[21]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[21]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[21]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[22]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[22]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[22]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[23]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[23]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[23]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[24]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[24]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[24]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[25]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[25]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[25]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[26]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[26]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[26]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[27]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[27]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[27]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[28]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[28]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[28]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[29]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[29]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[29]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[2]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[2]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[2]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[30]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[30]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[30]_i_35_O_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[31]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[31]_i_1_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[3]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[3]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[3]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[4]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[4]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[4]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[5]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[5]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[5]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[6]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[6]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[6]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[7]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[7]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[7]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[8]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[8]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[8]_i_35_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[9]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[9]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[9]_i_35_O_UNCONNECTED ;
  wire [3:3]NLW_error0_carry__6_CO_UNCONNECTED;
  wire [3:3]NLW_integral0_carry__6_CO_UNCONNECTED;
  wire NLW_integral1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_integral1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_integral1_OVERFLOW_UNCONNECTED;
  wire NLW_integral1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_integral1_PATTERNDETECT_UNCONNECTED;
  wire NLW_integral1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_integral1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_integral1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_integral1_CARRYOUT_UNCONNECTED;
  wire NLW_integral1__0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_integral1__0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_integral1__0_OVERFLOW_UNCONNECTED;
  wire NLW_integral1__0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_integral1__0_PATTERNDETECT_UNCONNECTED;
  wire NLW_integral1__0_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_integral1__0_ACOUT_UNCONNECTED;
  wire [17:0]NLW_integral1__0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_integral1__0_CARRYOUT_UNCONNECTED;
  wire NLW_integral1__1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_integral1__1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_integral1__1_OVERFLOW_UNCONNECTED;
  wire NLW_integral1__1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_integral1__1_PATTERNDETECT_UNCONNECTED;
  wire NLW_integral1__1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_integral1__1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_integral1__1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_integral1__1_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_integral1__1_PCOUT_UNCONNECTED;
  wire [3:3]NLW_integral1_carry__2_CO_UNCONNECTED;

  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry
       (.CI(1'b0),
        .CO({derivative1__0_carry_n_0,derivative1__0_carry_n_1,derivative1__0_carry_n_2,derivative1__0_carry_n_3}),
        .CYINIT(1'b1),
        .DI({derivative1__0_carry_i_1_n_0,derivative1__0_carry_i_2_n_0,derivative1__0_carry_i_3_n_0,1'b1}),
        .O(derivative11_out[3:0]),
        .S({derivative1__0_carry_i_4_n_0,derivative1__0_carry_i_5_n_0,derivative1__0_carry_i_6_n_0,derivative1__0_carry_i_7_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry__0
       (.CI(derivative1__0_carry_n_0),
        .CO({derivative1__0_carry__0_n_0,derivative1__0_carry__0_n_1,derivative1__0_carry__0_n_2,derivative1__0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({derivative1__0_carry__0_i_1_n_0,derivative1__0_carry__0_i_2_n_0,derivative1__0_carry__0_i_3_n_0,derivative1__0_carry__0_i_4_n_0}),
        .O(derivative11_out[7:4]),
        .S({derivative1__0_carry__0_i_5_n_0,derivative1__0_carry__0_i_6_n_0,derivative1__0_carry__0_i_7_n_0,derivative1__0_carry__0_i_8_n_0}));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__0_i_1
       (.I0(angle[6]),
        .I1(error_in[6]),
        .I2(target_angle[6]),
        .O(derivative1__0_carry__0_i_1_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__0_i_2
       (.I0(angle[5]),
        .I1(error_in[5]),
        .I2(target_angle[5]),
        .O(derivative1__0_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__0_i_3
       (.I0(angle[4]),
        .I1(error_in[4]),
        .I2(target_angle[4]),
        .O(derivative1__0_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__0_i_4
       (.I0(angle[3]),
        .I1(error_in[3]),
        .I2(target_angle[3]),
        .O(derivative1__0_carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__0_i_5
       (.I0(angle[7]),
        .I1(error_in[7]),
        .I2(target_angle[7]),
        .I3(derivative1__0_carry__0_i_1_n_0),
        .O(derivative1__0_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__0_i_6
       (.I0(angle[6]),
        .I1(error_in[6]),
        .I2(target_angle[6]),
        .I3(derivative1__0_carry__0_i_2_n_0),
        .O(derivative1__0_carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__0_i_7
       (.I0(angle[5]),
        .I1(error_in[5]),
        .I2(target_angle[5]),
        .I3(derivative1__0_carry__0_i_3_n_0),
        .O(derivative1__0_carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__0_i_8
       (.I0(angle[4]),
        .I1(error_in[4]),
        .I2(target_angle[4]),
        .I3(derivative1__0_carry__0_i_4_n_0),
        .O(derivative1__0_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry__1
       (.CI(derivative1__0_carry__0_n_0),
        .CO({derivative1__0_carry__1_n_0,derivative1__0_carry__1_n_1,derivative1__0_carry__1_n_2,derivative1__0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({derivative1__0_carry__1_i_1_n_0,derivative1__0_carry__1_i_2_n_0,derivative1__0_carry__1_i_3_n_0,derivative1__0_carry__1_i_4_n_0}),
        .O(derivative11_out[11:8]),
        .S({derivative1__0_carry__1_i_5_n_0,derivative1__0_carry__1_i_6_n_0,derivative1__0_carry__1_i_7_n_0,derivative1__0_carry__1_i_8_n_0}));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__1_i_1
       (.I0(angle[10]),
        .I1(error_in[10]),
        .I2(target_angle[10]),
        .O(derivative1__0_carry__1_i_1_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__1_i_2
       (.I0(angle[9]),
        .I1(error_in[9]),
        .I2(target_angle[9]),
        .O(derivative1__0_carry__1_i_2_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__1_i_3
       (.I0(angle[8]),
        .I1(error_in[8]),
        .I2(target_angle[8]),
        .O(derivative1__0_carry__1_i_3_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__1_i_4
       (.I0(angle[7]),
        .I1(error_in[7]),
        .I2(target_angle[7]),
        .O(derivative1__0_carry__1_i_4_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__1_i_5
       (.I0(angle[11]),
        .I1(error_in[11]),
        .I2(target_angle[11]),
        .I3(derivative1__0_carry__1_i_1_n_0),
        .O(derivative1__0_carry__1_i_5_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__1_i_6
       (.I0(angle[10]),
        .I1(error_in[10]),
        .I2(target_angle[10]),
        .I3(derivative1__0_carry__1_i_2_n_0),
        .O(derivative1__0_carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__1_i_7
       (.I0(angle[9]),
        .I1(error_in[9]),
        .I2(target_angle[9]),
        .I3(derivative1__0_carry__1_i_3_n_0),
        .O(derivative1__0_carry__1_i_7_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__1_i_8
       (.I0(angle[8]),
        .I1(error_in[8]),
        .I2(target_angle[8]),
        .I3(derivative1__0_carry__1_i_4_n_0),
        .O(derivative1__0_carry__1_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry__2
       (.CI(derivative1__0_carry__1_n_0),
        .CO({derivative1__0_carry__2_n_0,derivative1__0_carry__2_n_1,derivative1__0_carry__2_n_2,derivative1__0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({derivative1__0_carry__2_i_1_n_0,derivative1__0_carry__2_i_2_n_0,derivative1__0_carry__2_i_3_n_0,derivative1__0_carry__2_i_4_n_0}),
        .O(derivative11_out[15:12]),
        .S({derivative1__0_carry__2_i_5_n_0,derivative1__0_carry__2_i_6_n_0,derivative1__0_carry__2_i_7_n_0,derivative1__0_carry__2_i_8_n_0}));
  (* HLUTNM = "lutpair4" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__2_i_1
       (.I0(angle[14]),
        .I1(error_in[14]),
        .I2(target_angle[14]),
        .O(derivative1__0_carry__2_i_1_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__2_i_2
       (.I0(angle[13]),
        .I1(error_in[13]),
        .I2(target_angle[13]),
        .O(derivative1__0_carry__2_i_2_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__2_i_3
       (.I0(angle[12]),
        .I1(error_in[12]),
        .I2(target_angle[12]),
        .O(derivative1__0_carry__2_i_3_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__2_i_4
       (.I0(angle[11]),
        .I1(error_in[11]),
        .I2(target_angle[11]),
        .O(derivative1__0_carry__2_i_4_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__2_i_5
       (.I0(angle[15]),
        .I1(error_in[15]),
        .I2(target_angle[15]),
        .I3(derivative1__0_carry__2_i_1_n_0),
        .O(derivative1__0_carry__2_i_5_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__2_i_6
       (.I0(angle[14]),
        .I1(error_in[14]),
        .I2(target_angle[14]),
        .I3(derivative1__0_carry__2_i_2_n_0),
        .O(derivative1__0_carry__2_i_6_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__2_i_7
       (.I0(angle[13]),
        .I1(error_in[13]),
        .I2(target_angle[13]),
        .I3(derivative1__0_carry__2_i_3_n_0),
        .O(derivative1__0_carry__2_i_7_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__2_i_8
       (.I0(angle[12]),
        .I1(error_in[12]),
        .I2(target_angle[12]),
        .I3(derivative1__0_carry__2_i_4_n_0),
        .O(derivative1__0_carry__2_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry__3
       (.CI(derivative1__0_carry__2_n_0),
        .CO({derivative1__0_carry__3_n_0,derivative1__0_carry__3_n_1,derivative1__0_carry__3_n_2,derivative1__0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({derivative1__0_carry__3_i_1_n_0,derivative1__0_carry__3_i_2_n_0,derivative1__0_carry__3_i_3_n_0,derivative1__0_carry__3_i_4_n_0}),
        .O(derivative11_out[19:16]),
        .S({derivative1__0_carry__3_i_5_n_0,derivative1__0_carry__3_i_6_n_0,derivative1__0_carry__3_i_7_n_0,derivative1__0_carry__3_i_8_n_0}));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__3_i_1
       (.I0(angle[18]),
        .I1(error_in[18]),
        .I2(target_angle[18]),
        .O(derivative1__0_carry__3_i_1_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__3_i_2
       (.I0(angle[17]),
        .I1(error_in[17]),
        .I2(target_angle[17]),
        .O(derivative1__0_carry__3_i_2_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__3_i_3
       (.I0(angle[16]),
        .I1(error_in[16]),
        .I2(target_angle[16]),
        .O(derivative1__0_carry__3_i_3_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__3_i_4
       (.I0(angle[15]),
        .I1(error_in[15]),
        .I2(target_angle[15]),
        .O(derivative1__0_carry__3_i_4_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__3_i_5
       (.I0(angle[19]),
        .I1(error_in[19]),
        .I2(target_angle[19]),
        .I3(derivative1__0_carry__3_i_1_n_0),
        .O(derivative1__0_carry__3_i_5_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__3_i_6
       (.I0(angle[18]),
        .I1(error_in[18]),
        .I2(target_angle[18]),
        .I3(derivative1__0_carry__3_i_2_n_0),
        .O(derivative1__0_carry__3_i_6_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__3_i_7
       (.I0(angle[17]),
        .I1(error_in[17]),
        .I2(target_angle[17]),
        .I3(derivative1__0_carry__3_i_3_n_0),
        .O(derivative1__0_carry__3_i_7_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__3_i_8
       (.I0(angle[16]),
        .I1(error_in[16]),
        .I2(target_angle[16]),
        .I3(derivative1__0_carry__3_i_4_n_0),
        .O(derivative1__0_carry__3_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry__4
       (.CI(derivative1__0_carry__3_n_0),
        .CO({derivative1__0_carry__4_n_0,derivative1__0_carry__4_n_1,derivative1__0_carry__4_n_2,derivative1__0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({derivative1__0_carry__4_i_1_n_0,derivative1__0_carry__4_i_2_n_0,derivative1__0_carry__4_i_3_n_0,derivative1__0_carry__4_i_4_n_0}),
        .O(derivative11_out[23:20]),
        .S({derivative1__0_carry__4_i_5_n_0,derivative1__0_carry__4_i_6_n_0,derivative1__0_carry__4_i_7_n_0,derivative1__0_carry__4_i_8_n_0}));
  (* HLUTNM = "lutpair12" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__4_i_1
       (.I0(angle[22]),
        .I1(error_in[22]),
        .I2(target_angle[22]),
        .O(derivative1__0_carry__4_i_1_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__4_i_2
       (.I0(angle[21]),
        .I1(error_in[21]),
        .I2(target_angle[21]),
        .O(derivative1__0_carry__4_i_2_n_0));
  (* HLUTNM = "lutpair10" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__4_i_3
       (.I0(angle[20]),
        .I1(error_in[20]),
        .I2(target_angle[20]),
        .O(derivative1__0_carry__4_i_3_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__4_i_4
       (.I0(angle[19]),
        .I1(error_in[19]),
        .I2(target_angle[19]),
        .O(derivative1__0_carry__4_i_4_n_0));
  (* HLUTNM = "lutpair13" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__4_i_5
       (.I0(angle[23]),
        .I1(error_in[23]),
        .I2(target_angle[23]),
        .I3(derivative1__0_carry__4_i_1_n_0),
        .O(derivative1__0_carry__4_i_5_n_0));
  (* HLUTNM = "lutpair12" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__4_i_6
       (.I0(angle[22]),
        .I1(error_in[22]),
        .I2(target_angle[22]),
        .I3(derivative1__0_carry__4_i_2_n_0),
        .O(derivative1__0_carry__4_i_6_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__4_i_7
       (.I0(angle[21]),
        .I1(error_in[21]),
        .I2(target_angle[21]),
        .I3(derivative1__0_carry__4_i_3_n_0),
        .O(derivative1__0_carry__4_i_7_n_0));
  (* HLUTNM = "lutpair10" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__4_i_8
       (.I0(angle[20]),
        .I1(error_in[20]),
        .I2(target_angle[20]),
        .I3(derivative1__0_carry__4_i_4_n_0),
        .O(derivative1__0_carry__4_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry__5
       (.CI(derivative1__0_carry__4_n_0),
        .CO({derivative1__0_carry__5_n_0,derivative1__0_carry__5_n_1,derivative1__0_carry__5_n_2,derivative1__0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({derivative1__0_carry__5_i_1_n_0,derivative1__0_carry__5_i_2_n_0,derivative1__0_carry__5_i_3_n_0,derivative1__0_carry__5_i_4_n_0}),
        .O(derivative11_out[27:24]),
        .S({derivative1__0_carry__5_i_5_n_0,derivative1__0_carry__5_i_6_n_0,derivative1__0_carry__5_i_7_n_0,derivative1__0_carry__5_i_8_n_0}));
  (* HLUTNM = "lutpair16" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__5_i_1
       (.I0(angle[26]),
        .I1(error_in[26]),
        .I2(target_angle[26]),
        .O(derivative1__0_carry__5_i_1_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__5_i_2
       (.I0(angle[25]),
        .I1(error_in[25]),
        .I2(target_angle[25]),
        .O(derivative1__0_carry__5_i_2_n_0));
  (* HLUTNM = "lutpair14" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__5_i_3
       (.I0(angle[24]),
        .I1(error_in[24]),
        .I2(target_angle[24]),
        .O(derivative1__0_carry__5_i_3_n_0));
  (* HLUTNM = "lutpair13" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__5_i_4
       (.I0(angle[23]),
        .I1(error_in[23]),
        .I2(target_angle[23]),
        .O(derivative1__0_carry__5_i_4_n_0));
  (* HLUTNM = "lutpair17" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__5_i_5
       (.I0(angle[27]),
        .I1(error_in[27]),
        .I2(target_angle[27]),
        .I3(derivative1__0_carry__5_i_1_n_0),
        .O(derivative1__0_carry__5_i_5_n_0));
  (* HLUTNM = "lutpair16" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__5_i_6
       (.I0(angle[26]),
        .I1(error_in[26]),
        .I2(target_angle[26]),
        .I3(derivative1__0_carry__5_i_2_n_0),
        .O(derivative1__0_carry__5_i_6_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__5_i_7
       (.I0(angle[25]),
        .I1(error_in[25]),
        .I2(target_angle[25]),
        .I3(derivative1__0_carry__5_i_3_n_0),
        .O(derivative1__0_carry__5_i_7_n_0));
  (* HLUTNM = "lutpair14" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__5_i_8
       (.I0(angle[24]),
        .I1(error_in[24]),
        .I2(target_angle[24]),
        .I3(derivative1__0_carry__5_i_4_n_0),
        .O(derivative1__0_carry__5_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative1__0_carry__6
       (.CI(derivative1__0_carry__5_n_0),
        .CO({NLW_derivative1__0_carry__6_CO_UNCONNECTED[3],derivative1__0_carry__6_n_1,derivative1__0_carry__6_n_2,derivative1__0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,derivative1__0_carry__6_i_1_n_0,derivative1__0_carry__6_i_2_n_0,derivative1__0_carry__6_i_3_n_0}),
        .O(derivative11_out[31:28]),
        .S({derivative1__0_carry__6_i_4_n_0,derivative1__0_carry__6_i_5_n_0,derivative1__0_carry__6_i_6_n_0,derivative1__0_carry__6_i_7_n_0}));
  (* HLUTNM = "lutpair19" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__6_i_1
       (.I0(angle[29]),
        .I1(error_in[29]),
        .I2(target_angle[29]),
        .O(derivative1__0_carry__6_i_1_n_0));
  (* HLUTNM = "lutpair18" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__6_i_2
       (.I0(angle[28]),
        .I1(error_in[28]),
        .I2(target_angle[28]),
        .O(derivative1__0_carry__6_i_2_n_0));
  (* HLUTNM = "lutpair17" *) 
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry__6_i_3
       (.I0(angle[27]),
        .I1(error_in[27]),
        .I2(target_angle[27]),
        .O(derivative1__0_carry__6_i_3_n_0));
  LUT6 #(
    .INIT(64'hD42B2BD42BD4D42B)) 
    derivative1__0_carry__6_i_4
       (.I0(target_angle[30]),
        .I1(error_in[30]),
        .I2(angle[30]),
        .I3(error_in[31]),
        .I4(angle[31]),
        .I5(target_angle[31]),
        .O(derivative1__0_carry__6_i_4_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__6_i_5
       (.I0(derivative1__0_carry__6_i_1_n_0),
        .I1(error_in[30]),
        .I2(angle[30]),
        .I3(target_angle[30]),
        .O(derivative1__0_carry__6_i_5_n_0));
  (* HLUTNM = "lutpair19" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__6_i_6
       (.I0(angle[29]),
        .I1(error_in[29]),
        .I2(target_angle[29]),
        .I3(derivative1__0_carry__6_i_2_n_0),
        .O(derivative1__0_carry__6_i_6_n_0));
  (* HLUTNM = "lutpair18" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry__6_i_7
       (.I0(angle[28]),
        .I1(error_in[28]),
        .I2(target_angle[28]),
        .I3(derivative1__0_carry__6_i_3_n_0),
        .O(derivative1__0_carry__6_i_7_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry_i_1
       (.I0(angle[2]),
        .I1(error_in[2]),
        .I2(target_angle[2]),
        .O(derivative1__0_carry_i_1_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry_i_2
       (.I0(angle[1]),
        .I1(error_in[1]),
        .I2(target_angle[1]),
        .O(derivative1__0_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h71)) 
    derivative1__0_carry_i_3
       (.I0(angle[0]),
        .I1(error_in[0]),
        .I2(target_angle[0]),
        .O(derivative1__0_carry_i_3_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry_i_4
       (.I0(angle[3]),
        .I1(error_in[3]),
        .I2(target_angle[3]),
        .I3(derivative1__0_carry_i_1_n_0),
        .O(derivative1__0_carry_i_4_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry_i_5
       (.I0(angle[2]),
        .I1(error_in[2]),
        .I2(target_angle[2]),
        .I3(derivative1__0_carry_i_2_n_0),
        .O(derivative1__0_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    derivative1__0_carry_i_6
       (.I0(angle[1]),
        .I1(error_in[1]),
        .I2(target_angle[1]),
        .I3(derivative1__0_carry_i_3_n_0),
        .O(derivative1__0_carry_i_6_n_0));
  LUT3 #(
    .INIT(8'h69)) 
    derivative1__0_carry_i_7
       (.I0(angle[0]),
        .I1(error_in[0]),
        .I2(target_angle[0]),
        .O(derivative1__0_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_10 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[1]_i_5_n_4 ),
        .O(\derivative[0]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_11 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[1]_i_5_n_5 ),
        .O(\derivative[0]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_12 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[1]_i_5_n_6 ),
        .O(\derivative[0]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_13 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[1]_i_5_n_7 ),
        .O(\derivative[0]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_15 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[1]_i_10_n_4 ),
        .O(\derivative[0]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_16 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[1]_i_10_n_5 ),
        .O(\derivative[0]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_17 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[1]_i_10_n_6 ),
        .O(\derivative[0]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_18 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[1]_i_10_n_7 ),
        .O(\derivative[0]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_20 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[1]_i_15_n_4 ),
        .O(\derivative[0]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_21 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[1]_i_15_n_5 ),
        .O(\derivative[0]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_22 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[1]_i_15_n_6 ),
        .O(\derivative[0]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_23 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[1]_i_15_n_7 ),
        .O(\derivative[0]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_25 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[1]_i_20_n_4 ),
        .O(\derivative[0]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_26 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[1]_i_20_n_5 ),
        .O(\derivative[0]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_27 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[1]_i_20_n_6 ),
        .O(\derivative[0]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_28 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[1]_i_20_n_7 ),
        .O(\derivative[0]_i_28_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[0]_i_3 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(\derivative_reg[1]_i_1_n_7 ),
        .O(\derivative[0]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_30 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[1]_i_25_n_4 ),
        .O(\derivative[0]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_31 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[1]_i_25_n_5 ),
        .O(\derivative[0]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_32 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[1]_i_25_n_6 ),
        .O(\derivative[0]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_33 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[1]_i_25_n_7 ),
        .O(\derivative[0]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_35 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[1]_i_30_n_4 ),
        .O(\derivative[0]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_36 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[1]_i_30_n_5 ),
        .O(\derivative[0]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_37 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[1]_i_30_n_6 ),
        .O(\derivative[0]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_38 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[1]_i_30_n_7 ),
        .O(\derivative[0]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_39 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[1]_i_35_n_4 ),
        .O(\derivative[0]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_40 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[1]_i_35_n_5 ),
        .O(\derivative[0]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_41 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[1]_i_35_n_6 ),
        .O(\derivative[0]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_42 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[0]),
        .O(\derivative[0]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_5 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[1]_i_2_n_4 ),
        .O(\derivative[0]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_6 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[1]_i_2_n_5 ),
        .O(\derivative[0]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_7 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[1]_i_2_n_6 ),
        .O(\derivative[0]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[0]_i_8 
       (.I0(\derivative_reg[1]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[1]_i_2_n_7 ),
        .O(\derivative[0]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_11 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[11]_i_5_n_5 ),
        .O(\derivative[10]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_12 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[11]_i_5_n_6 ),
        .O(\derivative[10]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_13 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[11]_i_5_n_7 ),
        .O(\derivative[10]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_14 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[11]_i_10_n_4 ),
        .O(\derivative[10]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_16 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[11]_i_10_n_5 ),
        .O(\derivative[10]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_17 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[11]_i_10_n_6 ),
        .O(\derivative[10]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_18 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[11]_i_10_n_7 ),
        .O(\derivative[10]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_19 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[11]_i_15_n_4 ),
        .O(\derivative[10]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_21 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[11]_i_15_n_5 ),
        .O(\derivative[10]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_22 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[11]_i_15_n_6 ),
        .O(\derivative[10]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_23 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[11]_i_15_n_7 ),
        .O(\derivative[10]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_24 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[11]_i_20_n_4 ),
        .O(\derivative[10]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_26 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[11]_i_20_n_5 ),
        .O(\derivative[10]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_27 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[11]_i_20_n_6 ),
        .O(\derivative[10]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_28 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[11]_i_20_n_7 ),
        .O(\derivative[10]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_29 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[11]_i_25_n_4 ),
        .O(\derivative[10]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[10]_i_3 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(\derivative_reg[11]_i_1_n_7 ),
        .O(\derivative[10]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_31 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[11]_i_25_n_5 ),
        .O(\derivative[10]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_32 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[11]_i_25_n_6 ),
        .O(\derivative[10]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_33 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[11]_i_25_n_7 ),
        .O(\derivative[10]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_34 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[11]_i_30_n_4 ),
        .O(\derivative[10]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_36 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[11]_i_30_n_5 ),
        .O(\derivative[10]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_37 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[11]_i_30_n_6 ),
        .O(\derivative[10]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_38 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[11]_i_30_n_7 ),
        .O(\derivative[10]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_39 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[11]_i_35_n_4 ),
        .O(\derivative[10]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_4 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[11]_i_2_n_4 ),
        .O(\derivative[10]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_40 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[11]_i_35_n_5 ),
        .O(\derivative[10]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_41 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[11]_i_35_n_6 ),
        .O(\derivative[10]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_42 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[10]),
        .O(\derivative[10]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_6 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[11]_i_2_n_5 ),
        .O(\derivative[10]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_7 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[11]_i_2_n_6 ),
        .O(\derivative[10]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_8 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[11]_i_2_n_7 ),
        .O(\derivative[10]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[10]_i_9 
       (.I0(\derivative_reg[11]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[11]_i_5_n_4 ),
        .O(\derivative[10]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_11 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[12]_i_5_n_5 ),
        .O(\derivative[11]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_12 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[12]_i_5_n_6 ),
        .O(\derivative[11]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_13 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[12]_i_5_n_7 ),
        .O(\derivative[11]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_14 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[12]_i_10_n_4 ),
        .O(\derivative[11]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_16 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[12]_i_10_n_5 ),
        .O(\derivative[11]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_17 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[12]_i_10_n_6 ),
        .O(\derivative[11]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_18 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[12]_i_10_n_7 ),
        .O(\derivative[11]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_19 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[12]_i_15_n_4 ),
        .O(\derivative[11]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_21 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[12]_i_15_n_5 ),
        .O(\derivative[11]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_22 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[12]_i_15_n_6 ),
        .O(\derivative[11]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_23 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[12]_i_15_n_7 ),
        .O(\derivative[11]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_24 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[12]_i_20_n_4 ),
        .O(\derivative[11]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_26 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[12]_i_20_n_5 ),
        .O(\derivative[11]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_27 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[12]_i_20_n_6 ),
        .O(\derivative[11]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_28 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[12]_i_20_n_7 ),
        .O(\derivative[11]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_29 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[12]_i_25_n_4 ),
        .O(\derivative[11]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[11]_i_3 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(\derivative_reg[12]_i_1_n_7 ),
        .O(\derivative[11]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_31 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[12]_i_25_n_5 ),
        .O(\derivative[11]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_32 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[12]_i_25_n_6 ),
        .O(\derivative[11]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_33 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[12]_i_25_n_7 ),
        .O(\derivative[11]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_34 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[12]_i_30_n_4 ),
        .O(\derivative[11]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_36 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[12]_i_30_n_5 ),
        .O(\derivative[11]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_37 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[12]_i_30_n_6 ),
        .O(\derivative[11]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_38 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[12]_i_30_n_7 ),
        .O(\derivative[11]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_39 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[12]_i_35_n_4 ),
        .O(\derivative[11]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_4 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[12]_i_2_n_4 ),
        .O(\derivative[11]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_40 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[12]_i_35_n_5 ),
        .O(\derivative[11]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_41 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[12]_i_35_n_6 ),
        .O(\derivative[11]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_42 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[11]),
        .O(\derivative[11]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_6 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[12]_i_2_n_5 ),
        .O(\derivative[11]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_7 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[12]_i_2_n_6 ),
        .O(\derivative[11]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_8 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[12]_i_2_n_7 ),
        .O(\derivative[11]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_9 
       (.I0(\derivative_reg[12]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[12]_i_5_n_4 ),
        .O(\derivative[11]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_11 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[13]_i_5_n_5 ),
        .O(\derivative[12]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_12 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[13]_i_5_n_6 ),
        .O(\derivative[12]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_13 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[13]_i_5_n_7 ),
        .O(\derivative[12]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_14 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[13]_i_10_n_4 ),
        .O(\derivative[12]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_16 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[13]_i_10_n_5 ),
        .O(\derivative[12]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_17 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[13]_i_10_n_6 ),
        .O(\derivative[12]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_18 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[13]_i_10_n_7 ),
        .O(\derivative[12]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_19 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[13]_i_15_n_4 ),
        .O(\derivative[12]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_21 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[13]_i_15_n_5 ),
        .O(\derivative[12]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_22 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[13]_i_15_n_6 ),
        .O(\derivative[12]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_23 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[13]_i_15_n_7 ),
        .O(\derivative[12]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_24 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[13]_i_20_n_4 ),
        .O(\derivative[12]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_26 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[13]_i_20_n_5 ),
        .O(\derivative[12]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_27 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[13]_i_20_n_6 ),
        .O(\derivative[12]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_28 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[13]_i_20_n_7 ),
        .O(\derivative[12]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_29 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[13]_i_25_n_4 ),
        .O(\derivative[12]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[12]_i_3 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(\derivative_reg[13]_i_1_n_7 ),
        .O(\derivative[12]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_31 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[13]_i_25_n_5 ),
        .O(\derivative[12]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_32 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[13]_i_25_n_6 ),
        .O(\derivative[12]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_33 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[13]_i_25_n_7 ),
        .O(\derivative[12]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_34 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[13]_i_30_n_4 ),
        .O(\derivative[12]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_36 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[13]_i_30_n_5 ),
        .O(\derivative[12]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_37 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[13]_i_30_n_6 ),
        .O(\derivative[12]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_38 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[13]_i_30_n_7 ),
        .O(\derivative[12]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_39 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[13]_i_35_n_4 ),
        .O(\derivative[12]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_4 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[13]_i_2_n_4 ),
        .O(\derivative[12]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_40 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[13]_i_35_n_5 ),
        .O(\derivative[12]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_41 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[13]_i_35_n_6 ),
        .O(\derivative[12]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_42 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[12]),
        .O(\derivative[12]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_6 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[13]_i_2_n_5 ),
        .O(\derivative[12]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_7 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[13]_i_2_n_6 ),
        .O(\derivative[12]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_8 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[13]_i_2_n_7 ),
        .O(\derivative[12]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[12]_i_9 
       (.I0(\derivative_reg[13]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[13]_i_5_n_4 ),
        .O(\derivative[12]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_11 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[14]_i_5_n_5 ),
        .O(\derivative[13]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_12 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[14]_i_5_n_6 ),
        .O(\derivative[13]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_13 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[14]_i_5_n_7 ),
        .O(\derivative[13]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_14 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[14]_i_10_n_4 ),
        .O(\derivative[13]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_16 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[14]_i_10_n_5 ),
        .O(\derivative[13]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_17 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[14]_i_10_n_6 ),
        .O(\derivative[13]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_18 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[14]_i_10_n_7 ),
        .O(\derivative[13]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_19 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[14]_i_15_n_4 ),
        .O(\derivative[13]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_21 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[14]_i_15_n_5 ),
        .O(\derivative[13]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_22 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[14]_i_15_n_6 ),
        .O(\derivative[13]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_23 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[14]_i_15_n_7 ),
        .O(\derivative[13]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_24 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[14]_i_20_n_4 ),
        .O(\derivative[13]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_26 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[14]_i_20_n_5 ),
        .O(\derivative[13]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_27 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[14]_i_20_n_6 ),
        .O(\derivative[13]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_28 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[14]_i_20_n_7 ),
        .O(\derivative[13]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_29 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[14]_i_25_n_4 ),
        .O(\derivative[13]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[13]_i_3 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(\derivative_reg[14]_i_1_n_7 ),
        .O(\derivative[13]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_31 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[14]_i_25_n_5 ),
        .O(\derivative[13]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_32 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[14]_i_25_n_6 ),
        .O(\derivative[13]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_33 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[14]_i_25_n_7 ),
        .O(\derivative[13]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_34 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[14]_i_30_n_4 ),
        .O(\derivative[13]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_36 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[14]_i_30_n_5 ),
        .O(\derivative[13]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_37 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[14]_i_30_n_6 ),
        .O(\derivative[13]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_38 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[14]_i_30_n_7 ),
        .O(\derivative[13]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_39 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[14]_i_35_n_4 ),
        .O(\derivative[13]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_4 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[14]_i_2_n_4 ),
        .O(\derivative[13]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_40 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[14]_i_35_n_5 ),
        .O(\derivative[13]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_41 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[14]_i_35_n_6 ),
        .O(\derivative[13]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_42 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[13]),
        .O(\derivative[13]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_6 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[14]_i_2_n_5 ),
        .O(\derivative[13]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_7 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[14]_i_2_n_6 ),
        .O(\derivative[13]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_8 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[14]_i_2_n_7 ),
        .O(\derivative[13]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[13]_i_9 
       (.I0(\derivative_reg[14]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[14]_i_5_n_4 ),
        .O(\derivative[13]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_11 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[15]_i_5_n_5 ),
        .O(\derivative[14]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_12 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[15]_i_5_n_6 ),
        .O(\derivative[14]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_13 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[15]_i_5_n_7 ),
        .O(\derivative[14]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_14 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[15]_i_10_n_4 ),
        .O(\derivative[14]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_16 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[15]_i_10_n_5 ),
        .O(\derivative[14]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_17 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[15]_i_10_n_6 ),
        .O(\derivative[14]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_18 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[15]_i_10_n_7 ),
        .O(\derivative[14]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_19 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[15]_i_15_n_4 ),
        .O(\derivative[14]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_21 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[15]_i_15_n_5 ),
        .O(\derivative[14]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_22 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[15]_i_15_n_6 ),
        .O(\derivative[14]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_23 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[15]_i_15_n_7 ),
        .O(\derivative[14]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_24 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[15]_i_20_n_4 ),
        .O(\derivative[14]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_26 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[15]_i_20_n_5 ),
        .O(\derivative[14]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_27 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[15]_i_20_n_6 ),
        .O(\derivative[14]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_28 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[15]_i_20_n_7 ),
        .O(\derivative[14]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_29 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[15]_i_25_n_4 ),
        .O(\derivative[14]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[14]_i_3 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(\derivative_reg[15]_i_1_n_7 ),
        .O(\derivative[14]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_31 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[15]_i_25_n_5 ),
        .O(\derivative[14]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_32 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[15]_i_25_n_6 ),
        .O(\derivative[14]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_33 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[15]_i_25_n_7 ),
        .O(\derivative[14]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_34 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[15]_i_30_n_4 ),
        .O(\derivative[14]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_36 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[15]_i_30_n_5 ),
        .O(\derivative[14]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_37 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[15]_i_30_n_6 ),
        .O(\derivative[14]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_38 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[15]_i_30_n_7 ),
        .O(\derivative[14]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_39 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[15]_i_35_n_4 ),
        .O(\derivative[14]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_4 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[15]_i_2_n_4 ),
        .O(\derivative[14]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_40 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[15]_i_35_n_5 ),
        .O(\derivative[14]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_41 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[15]_i_35_n_6 ),
        .O(\derivative[14]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_42 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[14]),
        .O(\derivative[14]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_6 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[15]_i_2_n_5 ),
        .O(\derivative[14]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_7 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[15]_i_2_n_6 ),
        .O(\derivative[14]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_8 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[15]_i_2_n_7 ),
        .O(\derivative[14]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[14]_i_9 
       (.I0(\derivative_reg[15]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[15]_i_5_n_4 ),
        .O(\derivative[14]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_11 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[16]_i_5_n_5 ),
        .O(\derivative[15]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_12 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[16]_i_5_n_6 ),
        .O(\derivative[15]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_13 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[16]_i_5_n_7 ),
        .O(\derivative[15]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_14 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[16]_i_10_n_4 ),
        .O(\derivative[15]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_16 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[16]_i_10_n_5 ),
        .O(\derivative[15]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_17 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[16]_i_10_n_6 ),
        .O(\derivative[15]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_18 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[16]_i_10_n_7 ),
        .O(\derivative[15]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_19 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[16]_i_15_n_4 ),
        .O(\derivative[15]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_21 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[16]_i_15_n_5 ),
        .O(\derivative[15]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_22 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[16]_i_15_n_6 ),
        .O(\derivative[15]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_23 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[16]_i_15_n_7 ),
        .O(\derivative[15]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_24 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[16]_i_20_n_4 ),
        .O(\derivative[15]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_26 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[16]_i_20_n_5 ),
        .O(\derivative[15]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_27 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[16]_i_20_n_6 ),
        .O(\derivative[15]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_28 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[16]_i_20_n_7 ),
        .O(\derivative[15]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_29 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[16]_i_25_n_4 ),
        .O(\derivative[15]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[15]_i_3 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(\derivative_reg[16]_i_1_n_7 ),
        .O(\derivative[15]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_31 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[16]_i_25_n_5 ),
        .O(\derivative[15]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_32 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[16]_i_25_n_6 ),
        .O(\derivative[15]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_33 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[16]_i_25_n_7 ),
        .O(\derivative[15]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_34 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[16]_i_30_n_4 ),
        .O(\derivative[15]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_36 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[16]_i_30_n_5 ),
        .O(\derivative[15]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_37 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[16]_i_30_n_6 ),
        .O(\derivative[15]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_38 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[16]_i_30_n_7 ),
        .O(\derivative[15]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_39 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[16]_i_35_n_4 ),
        .O(\derivative[15]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_4 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[16]_i_2_n_4 ),
        .O(\derivative[15]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_40 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[16]_i_35_n_5 ),
        .O(\derivative[15]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_41 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[16]_i_35_n_6 ),
        .O(\derivative[15]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_42 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[15]),
        .O(\derivative[15]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_6 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[16]_i_2_n_5 ),
        .O(\derivative[15]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_7 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[16]_i_2_n_6 ),
        .O(\derivative[15]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_8 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[16]_i_2_n_7 ),
        .O(\derivative[15]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_9 
       (.I0(\derivative_reg[16]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[16]_i_5_n_4 ),
        .O(\derivative[15]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_11 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[17]_i_5_n_5 ),
        .O(\derivative[16]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_12 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[17]_i_5_n_6 ),
        .O(\derivative[16]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_13 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[17]_i_5_n_7 ),
        .O(\derivative[16]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_14 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[17]_i_10_n_4 ),
        .O(\derivative[16]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_16 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[17]_i_10_n_5 ),
        .O(\derivative[16]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_17 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[17]_i_10_n_6 ),
        .O(\derivative[16]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_18 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[17]_i_10_n_7 ),
        .O(\derivative[16]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_19 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[17]_i_15_n_4 ),
        .O(\derivative[16]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_21 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[17]_i_15_n_5 ),
        .O(\derivative[16]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_22 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[17]_i_15_n_6 ),
        .O(\derivative[16]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_23 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[17]_i_15_n_7 ),
        .O(\derivative[16]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_24 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[17]_i_20_n_4 ),
        .O(\derivative[16]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_26 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[17]_i_20_n_5 ),
        .O(\derivative[16]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_27 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[17]_i_20_n_6 ),
        .O(\derivative[16]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_28 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[17]_i_20_n_7 ),
        .O(\derivative[16]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_29 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[17]_i_25_n_4 ),
        .O(\derivative[16]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[16]_i_3 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(\derivative_reg[17]_i_1_n_7 ),
        .O(\derivative[16]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_31 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[17]_i_25_n_5 ),
        .O(\derivative[16]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_32 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[17]_i_25_n_6 ),
        .O(\derivative[16]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_33 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[17]_i_25_n_7 ),
        .O(\derivative[16]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_34 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[17]_i_30_n_4 ),
        .O(\derivative[16]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_36 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[17]_i_30_n_5 ),
        .O(\derivative[16]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_37 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[17]_i_30_n_6 ),
        .O(\derivative[16]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_38 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[17]_i_30_n_7 ),
        .O(\derivative[16]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_39 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[17]_i_35_n_4 ),
        .O(\derivative[16]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_4 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[17]_i_2_n_4 ),
        .O(\derivative[16]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_40 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[17]_i_35_n_5 ),
        .O(\derivative[16]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_41 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[17]_i_35_n_6 ),
        .O(\derivative[16]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_42 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[16]),
        .O(\derivative[16]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_6 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[17]_i_2_n_5 ),
        .O(\derivative[16]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_7 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[17]_i_2_n_6 ),
        .O(\derivative[16]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_8 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[17]_i_2_n_7 ),
        .O(\derivative[16]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[16]_i_9 
       (.I0(\derivative_reg[17]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[17]_i_5_n_4 ),
        .O(\derivative[16]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_11 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[18]_i_5_n_5 ),
        .O(\derivative[17]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_12 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[18]_i_5_n_6 ),
        .O(\derivative[17]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_13 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[18]_i_5_n_7 ),
        .O(\derivative[17]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_14 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[18]_i_10_n_4 ),
        .O(\derivative[17]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_16 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[18]_i_10_n_5 ),
        .O(\derivative[17]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_17 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[18]_i_10_n_6 ),
        .O(\derivative[17]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_18 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[18]_i_10_n_7 ),
        .O(\derivative[17]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_19 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[18]_i_15_n_4 ),
        .O(\derivative[17]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_21 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[18]_i_15_n_5 ),
        .O(\derivative[17]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_22 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[18]_i_15_n_6 ),
        .O(\derivative[17]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_23 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[18]_i_15_n_7 ),
        .O(\derivative[17]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_24 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[18]_i_20_n_4 ),
        .O(\derivative[17]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_26 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[18]_i_20_n_5 ),
        .O(\derivative[17]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_27 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[18]_i_20_n_6 ),
        .O(\derivative[17]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_28 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[18]_i_20_n_7 ),
        .O(\derivative[17]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_29 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[18]_i_25_n_4 ),
        .O(\derivative[17]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[17]_i_3 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(\derivative_reg[18]_i_1_n_7 ),
        .O(\derivative[17]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_31 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[18]_i_25_n_5 ),
        .O(\derivative[17]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_32 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[18]_i_25_n_6 ),
        .O(\derivative[17]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_33 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[18]_i_25_n_7 ),
        .O(\derivative[17]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_34 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[18]_i_30_n_4 ),
        .O(\derivative[17]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_36 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[18]_i_30_n_5 ),
        .O(\derivative[17]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_37 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[18]_i_30_n_6 ),
        .O(\derivative[17]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_38 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[18]_i_30_n_7 ),
        .O(\derivative[17]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_39 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[18]_i_35_n_4 ),
        .O(\derivative[17]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_4 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[18]_i_2_n_4 ),
        .O(\derivative[17]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_40 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[18]_i_35_n_5 ),
        .O(\derivative[17]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_41 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[18]_i_35_n_6 ),
        .O(\derivative[17]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_42 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[17]),
        .O(\derivative[17]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_6 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[18]_i_2_n_5 ),
        .O(\derivative[17]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_7 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[18]_i_2_n_6 ),
        .O(\derivative[17]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_8 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[18]_i_2_n_7 ),
        .O(\derivative[17]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[17]_i_9 
       (.I0(\derivative_reg[18]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[18]_i_5_n_4 ),
        .O(\derivative[17]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_11 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[19]_i_5_n_5 ),
        .O(\derivative[18]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_12 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[19]_i_5_n_6 ),
        .O(\derivative[18]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_13 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[19]_i_5_n_7 ),
        .O(\derivative[18]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_14 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[19]_i_10_n_4 ),
        .O(\derivative[18]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_16 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[19]_i_10_n_5 ),
        .O(\derivative[18]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_17 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[19]_i_10_n_6 ),
        .O(\derivative[18]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_18 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[19]_i_10_n_7 ),
        .O(\derivative[18]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_19 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[19]_i_15_n_4 ),
        .O(\derivative[18]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_21 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[19]_i_15_n_5 ),
        .O(\derivative[18]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_22 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[19]_i_15_n_6 ),
        .O(\derivative[18]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_23 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[19]_i_15_n_7 ),
        .O(\derivative[18]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_24 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[19]_i_20_n_4 ),
        .O(\derivative[18]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_26 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[19]_i_20_n_5 ),
        .O(\derivative[18]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_27 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[19]_i_20_n_6 ),
        .O(\derivative[18]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_28 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[19]_i_20_n_7 ),
        .O(\derivative[18]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_29 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[19]_i_25_n_4 ),
        .O(\derivative[18]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[18]_i_3 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(\derivative_reg[19]_i_1_n_7 ),
        .O(\derivative[18]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_31 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[19]_i_25_n_5 ),
        .O(\derivative[18]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_32 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[19]_i_25_n_6 ),
        .O(\derivative[18]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_33 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[19]_i_25_n_7 ),
        .O(\derivative[18]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_34 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[19]_i_30_n_4 ),
        .O(\derivative[18]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_36 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[19]_i_30_n_5 ),
        .O(\derivative[18]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_37 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[19]_i_30_n_6 ),
        .O(\derivative[18]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_38 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[19]_i_30_n_7 ),
        .O(\derivative[18]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_39 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[19]_i_35_n_4 ),
        .O(\derivative[18]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_4 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[19]_i_2_n_4 ),
        .O(\derivative[18]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_40 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[19]_i_35_n_5 ),
        .O(\derivative[18]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_41 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[19]_i_35_n_6 ),
        .O(\derivative[18]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_42 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[18]),
        .O(\derivative[18]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_6 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[19]_i_2_n_5 ),
        .O(\derivative[18]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_7 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[19]_i_2_n_6 ),
        .O(\derivative[18]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_8 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[19]_i_2_n_7 ),
        .O(\derivative[18]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[18]_i_9 
       (.I0(\derivative_reg[19]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[19]_i_5_n_4 ),
        .O(\derivative[18]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_11 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[20]_i_5_n_5 ),
        .O(\derivative[19]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_12 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[20]_i_5_n_6 ),
        .O(\derivative[19]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_13 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[20]_i_5_n_7 ),
        .O(\derivative[19]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_14 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[20]_i_10_n_4 ),
        .O(\derivative[19]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_16 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[20]_i_10_n_5 ),
        .O(\derivative[19]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_17 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[20]_i_10_n_6 ),
        .O(\derivative[19]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_18 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[20]_i_10_n_7 ),
        .O(\derivative[19]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_19 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[20]_i_15_n_4 ),
        .O(\derivative[19]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_21 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[20]_i_15_n_5 ),
        .O(\derivative[19]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_22 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[20]_i_15_n_6 ),
        .O(\derivative[19]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_23 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[20]_i_15_n_7 ),
        .O(\derivative[19]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_24 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[20]_i_20_n_4 ),
        .O(\derivative[19]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_26 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[20]_i_20_n_5 ),
        .O(\derivative[19]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_27 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[20]_i_20_n_6 ),
        .O(\derivative[19]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_28 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[20]_i_20_n_7 ),
        .O(\derivative[19]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_29 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[20]_i_25_n_4 ),
        .O(\derivative[19]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[19]_i_3 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(\derivative_reg[20]_i_1_n_7 ),
        .O(\derivative[19]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_31 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[20]_i_25_n_5 ),
        .O(\derivative[19]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_32 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[20]_i_25_n_6 ),
        .O(\derivative[19]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_33 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[20]_i_25_n_7 ),
        .O(\derivative[19]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_34 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[20]_i_30_n_4 ),
        .O(\derivative[19]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_36 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[20]_i_30_n_5 ),
        .O(\derivative[19]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_37 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[20]_i_30_n_6 ),
        .O(\derivative[19]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_38 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[20]_i_30_n_7 ),
        .O(\derivative[19]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_39 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[20]_i_35_n_4 ),
        .O(\derivative[19]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_4 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[20]_i_2_n_4 ),
        .O(\derivative[19]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_40 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[20]_i_35_n_5 ),
        .O(\derivative[19]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_41 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[20]_i_35_n_6 ),
        .O(\derivative[19]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_42 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[19]),
        .O(\derivative[19]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_6 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[20]_i_2_n_5 ),
        .O(\derivative[19]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_7 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[20]_i_2_n_6 ),
        .O(\derivative[19]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_8 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[20]_i_2_n_7 ),
        .O(\derivative[19]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_9 
       (.I0(\derivative_reg[20]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[20]_i_5_n_4 ),
        .O(\derivative[19]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_11 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[2]_i_5_n_5 ),
        .O(\derivative[1]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_12 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[2]_i_5_n_6 ),
        .O(\derivative[1]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_13 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[2]_i_5_n_7 ),
        .O(\derivative[1]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_14 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[2]_i_10_n_4 ),
        .O(\derivative[1]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_16 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[2]_i_10_n_5 ),
        .O(\derivative[1]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_17 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[2]_i_10_n_6 ),
        .O(\derivative[1]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_18 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[2]_i_10_n_7 ),
        .O(\derivative[1]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_19 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[2]_i_15_n_4 ),
        .O(\derivative[1]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_21 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[2]_i_15_n_5 ),
        .O(\derivative[1]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_22 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[2]_i_15_n_6 ),
        .O(\derivative[1]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_23 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[2]_i_15_n_7 ),
        .O(\derivative[1]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_24 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[2]_i_20_n_4 ),
        .O(\derivative[1]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_26 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[2]_i_20_n_5 ),
        .O(\derivative[1]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_27 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[2]_i_20_n_6 ),
        .O(\derivative[1]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_28 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[2]_i_20_n_7 ),
        .O(\derivative[1]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_29 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[2]_i_25_n_4 ),
        .O(\derivative[1]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[1]_i_3 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(\derivative_reg[2]_i_1_n_7 ),
        .O(\derivative[1]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_31 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[2]_i_25_n_5 ),
        .O(\derivative[1]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_32 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[2]_i_25_n_6 ),
        .O(\derivative[1]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_33 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[2]_i_25_n_7 ),
        .O(\derivative[1]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_34 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[2]_i_30_n_4 ),
        .O(\derivative[1]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_36 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[2]_i_30_n_5 ),
        .O(\derivative[1]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_37 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[2]_i_30_n_6 ),
        .O(\derivative[1]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_38 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[2]_i_30_n_7 ),
        .O(\derivative[1]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_39 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[2]_i_35_n_4 ),
        .O(\derivative[1]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_4 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[2]_i_2_n_4 ),
        .O(\derivative[1]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_40 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[2]_i_35_n_5 ),
        .O(\derivative[1]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_41 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[2]_i_35_n_6 ),
        .O(\derivative[1]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_42 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[1]),
        .O(\derivative[1]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_6 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[2]_i_2_n_5 ),
        .O(\derivative[1]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_7 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[2]_i_2_n_6 ),
        .O(\derivative[1]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_8 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[2]_i_2_n_7 ),
        .O(\derivative[1]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[1]_i_9 
       (.I0(\derivative_reg[2]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[2]_i_5_n_4 ),
        .O(\derivative[1]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_11 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[21]_i_5_n_5 ),
        .O(\derivative[20]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_12 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[21]_i_5_n_6 ),
        .O(\derivative[20]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_13 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[21]_i_5_n_7 ),
        .O(\derivative[20]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_14 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[21]_i_10_n_4 ),
        .O(\derivative[20]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_16 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[21]_i_10_n_5 ),
        .O(\derivative[20]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_17 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[21]_i_10_n_6 ),
        .O(\derivative[20]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_18 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[21]_i_10_n_7 ),
        .O(\derivative[20]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_19 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[21]_i_15_n_4 ),
        .O(\derivative[20]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_21 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[21]_i_15_n_5 ),
        .O(\derivative[20]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_22 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[21]_i_15_n_6 ),
        .O(\derivative[20]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_23 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[21]_i_15_n_7 ),
        .O(\derivative[20]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_24 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[21]_i_20_n_4 ),
        .O(\derivative[20]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_26 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[21]_i_20_n_5 ),
        .O(\derivative[20]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_27 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[21]_i_20_n_6 ),
        .O(\derivative[20]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_28 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[21]_i_20_n_7 ),
        .O(\derivative[20]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_29 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[21]_i_25_n_4 ),
        .O(\derivative[20]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[20]_i_3 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(\derivative_reg[21]_i_1_n_7 ),
        .O(\derivative[20]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_31 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[21]_i_25_n_5 ),
        .O(\derivative[20]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_32 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[21]_i_25_n_6 ),
        .O(\derivative[20]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_33 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[21]_i_25_n_7 ),
        .O(\derivative[20]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_34 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[21]_i_30_n_4 ),
        .O(\derivative[20]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_36 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[21]_i_30_n_5 ),
        .O(\derivative[20]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_37 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[21]_i_30_n_6 ),
        .O(\derivative[20]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_38 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[21]_i_30_n_7 ),
        .O(\derivative[20]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_39 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[21]_i_35_n_4 ),
        .O(\derivative[20]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_4 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[21]_i_2_n_4 ),
        .O(\derivative[20]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_40 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[21]_i_35_n_5 ),
        .O(\derivative[20]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_41 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[21]_i_35_n_6 ),
        .O(\derivative[20]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_42 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[20]),
        .O(\derivative[20]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_6 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[21]_i_2_n_5 ),
        .O(\derivative[20]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_7 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[21]_i_2_n_6 ),
        .O(\derivative[20]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_8 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[21]_i_2_n_7 ),
        .O(\derivative[20]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[20]_i_9 
       (.I0(\derivative_reg[21]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[21]_i_5_n_4 ),
        .O(\derivative[20]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_11 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[22]_i_5_n_5 ),
        .O(\derivative[21]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_12 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[22]_i_5_n_6 ),
        .O(\derivative[21]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_13 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[22]_i_5_n_7 ),
        .O(\derivative[21]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_14 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[22]_i_10_n_4 ),
        .O(\derivative[21]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_16 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[22]_i_10_n_5 ),
        .O(\derivative[21]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_17 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[22]_i_10_n_6 ),
        .O(\derivative[21]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_18 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[22]_i_10_n_7 ),
        .O(\derivative[21]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_19 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[22]_i_15_n_4 ),
        .O(\derivative[21]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_21 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[22]_i_15_n_5 ),
        .O(\derivative[21]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_22 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[22]_i_15_n_6 ),
        .O(\derivative[21]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_23 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[22]_i_15_n_7 ),
        .O(\derivative[21]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_24 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[22]_i_20_n_4 ),
        .O(\derivative[21]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_26 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[22]_i_20_n_5 ),
        .O(\derivative[21]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_27 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[22]_i_20_n_6 ),
        .O(\derivative[21]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_28 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[22]_i_20_n_7 ),
        .O(\derivative[21]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_29 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[22]_i_25_n_4 ),
        .O(\derivative[21]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[21]_i_3 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(\derivative_reg[22]_i_1_n_7 ),
        .O(\derivative[21]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_31 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[22]_i_25_n_5 ),
        .O(\derivative[21]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_32 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[22]_i_25_n_6 ),
        .O(\derivative[21]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_33 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[22]_i_25_n_7 ),
        .O(\derivative[21]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_34 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[22]_i_30_n_4 ),
        .O(\derivative[21]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_36 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[22]_i_30_n_5 ),
        .O(\derivative[21]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_37 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[22]_i_30_n_6 ),
        .O(\derivative[21]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_38 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[22]_i_30_n_7 ),
        .O(\derivative[21]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_39 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[22]_i_35_n_4 ),
        .O(\derivative[21]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_4 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[22]_i_2_n_4 ),
        .O(\derivative[21]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_40 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[22]_i_35_n_5 ),
        .O(\derivative[21]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_41 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[22]_i_35_n_6 ),
        .O(\derivative[21]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_42 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[21]),
        .O(\derivative[21]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_6 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[22]_i_2_n_5 ),
        .O(\derivative[21]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_7 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[22]_i_2_n_6 ),
        .O(\derivative[21]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_8 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[22]_i_2_n_7 ),
        .O(\derivative[21]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[21]_i_9 
       (.I0(\derivative_reg[22]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[22]_i_5_n_4 ),
        .O(\derivative[21]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_11 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[23]_i_5_n_5 ),
        .O(\derivative[22]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_12 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[23]_i_5_n_6 ),
        .O(\derivative[22]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_13 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[23]_i_5_n_7 ),
        .O(\derivative[22]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_14 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[23]_i_10_n_4 ),
        .O(\derivative[22]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_16 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[23]_i_10_n_5 ),
        .O(\derivative[22]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_17 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[23]_i_10_n_6 ),
        .O(\derivative[22]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_18 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[23]_i_10_n_7 ),
        .O(\derivative[22]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_19 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[23]_i_15_n_4 ),
        .O(\derivative[22]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_21 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[23]_i_15_n_5 ),
        .O(\derivative[22]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_22 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[23]_i_15_n_6 ),
        .O(\derivative[22]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_23 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[23]_i_15_n_7 ),
        .O(\derivative[22]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_24 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[23]_i_20_n_4 ),
        .O(\derivative[22]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_26 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[23]_i_20_n_5 ),
        .O(\derivative[22]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_27 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[23]_i_20_n_6 ),
        .O(\derivative[22]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_28 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[23]_i_20_n_7 ),
        .O(\derivative[22]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_29 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[23]_i_25_n_4 ),
        .O(\derivative[22]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[22]_i_3 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(\derivative_reg[23]_i_1_n_7 ),
        .O(\derivative[22]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_31 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[23]_i_25_n_5 ),
        .O(\derivative[22]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_32 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[23]_i_25_n_6 ),
        .O(\derivative[22]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_33 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[23]_i_25_n_7 ),
        .O(\derivative[22]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_34 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[23]_i_30_n_4 ),
        .O(\derivative[22]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_36 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[23]_i_30_n_5 ),
        .O(\derivative[22]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_37 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[23]_i_30_n_6 ),
        .O(\derivative[22]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_38 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[23]_i_30_n_7 ),
        .O(\derivative[22]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_39 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[23]_i_35_n_4 ),
        .O(\derivative[22]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_4 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[23]_i_2_n_4 ),
        .O(\derivative[22]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_40 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[23]_i_35_n_5 ),
        .O(\derivative[22]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_41 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[23]_i_35_n_6 ),
        .O(\derivative[22]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_42 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[22]),
        .O(\derivative[22]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_6 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[23]_i_2_n_5 ),
        .O(\derivative[22]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_7 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[23]_i_2_n_6 ),
        .O(\derivative[22]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_8 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[23]_i_2_n_7 ),
        .O(\derivative[22]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[22]_i_9 
       (.I0(\derivative_reg[23]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[23]_i_5_n_4 ),
        .O(\derivative[22]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_11 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[24]_i_5_n_5 ),
        .O(\derivative[23]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_12 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[24]_i_5_n_6 ),
        .O(\derivative[23]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_13 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[24]_i_5_n_7 ),
        .O(\derivative[23]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_14 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[24]_i_10_n_4 ),
        .O(\derivative[23]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_16 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[24]_i_10_n_5 ),
        .O(\derivative[23]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_17 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[24]_i_10_n_6 ),
        .O(\derivative[23]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_18 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[24]_i_10_n_7 ),
        .O(\derivative[23]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_19 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[24]_i_15_n_4 ),
        .O(\derivative[23]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_21 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[24]_i_15_n_5 ),
        .O(\derivative[23]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_22 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[24]_i_15_n_6 ),
        .O(\derivative[23]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_23 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[24]_i_15_n_7 ),
        .O(\derivative[23]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_24 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[24]_i_20_n_4 ),
        .O(\derivative[23]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_26 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[24]_i_20_n_5 ),
        .O(\derivative[23]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_27 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[24]_i_20_n_6 ),
        .O(\derivative[23]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_28 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[24]_i_20_n_7 ),
        .O(\derivative[23]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_29 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[24]_i_25_n_4 ),
        .O(\derivative[23]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[23]_i_3 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(\derivative_reg[24]_i_1_n_7 ),
        .O(\derivative[23]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_31 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[24]_i_25_n_5 ),
        .O(\derivative[23]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_32 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[24]_i_25_n_6 ),
        .O(\derivative[23]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_33 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[24]_i_25_n_7 ),
        .O(\derivative[23]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_34 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[24]_i_30_n_4 ),
        .O(\derivative[23]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_36 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[24]_i_30_n_5 ),
        .O(\derivative[23]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_37 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[24]_i_30_n_6 ),
        .O(\derivative[23]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_38 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[24]_i_30_n_7 ),
        .O(\derivative[23]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_39 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[24]_i_35_n_4 ),
        .O(\derivative[23]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_4 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[24]_i_2_n_4 ),
        .O(\derivative[23]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_40 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[24]_i_35_n_5 ),
        .O(\derivative[23]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_41 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[24]_i_35_n_6 ),
        .O(\derivative[23]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_42 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[23]),
        .O(\derivative[23]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_6 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[24]_i_2_n_5 ),
        .O(\derivative[23]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_7 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[24]_i_2_n_6 ),
        .O(\derivative[23]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_8 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[24]_i_2_n_7 ),
        .O(\derivative[23]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_9 
       (.I0(\derivative_reg[24]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[24]_i_5_n_4 ),
        .O(\derivative[23]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_11 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[25]_i_5_n_5 ),
        .O(\derivative[24]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_12 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[25]_i_5_n_6 ),
        .O(\derivative[24]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_13 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[25]_i_5_n_7 ),
        .O(\derivative[24]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_14 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[25]_i_10_n_4 ),
        .O(\derivative[24]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_16 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[25]_i_10_n_5 ),
        .O(\derivative[24]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_17 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[25]_i_10_n_6 ),
        .O(\derivative[24]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_18 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[25]_i_10_n_7 ),
        .O(\derivative[24]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_19 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[25]_i_15_n_4 ),
        .O(\derivative[24]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_21 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[25]_i_15_n_5 ),
        .O(\derivative[24]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_22 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[25]_i_15_n_6 ),
        .O(\derivative[24]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_23 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[25]_i_15_n_7 ),
        .O(\derivative[24]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_24 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[25]_i_20_n_4 ),
        .O(\derivative[24]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_26 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[25]_i_20_n_5 ),
        .O(\derivative[24]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_27 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[25]_i_20_n_6 ),
        .O(\derivative[24]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_28 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[25]_i_20_n_7 ),
        .O(\derivative[24]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_29 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[25]_i_25_n_4 ),
        .O(\derivative[24]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[24]_i_3 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(\derivative_reg[25]_i_1_n_7 ),
        .O(\derivative[24]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_31 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[25]_i_25_n_5 ),
        .O(\derivative[24]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_32 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[25]_i_25_n_6 ),
        .O(\derivative[24]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_33 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[25]_i_25_n_7 ),
        .O(\derivative[24]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_34 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[25]_i_30_n_4 ),
        .O(\derivative[24]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_36 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[25]_i_30_n_5 ),
        .O(\derivative[24]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_37 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[25]_i_30_n_6 ),
        .O(\derivative[24]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_38 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[25]_i_30_n_7 ),
        .O(\derivative[24]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_39 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[25]_i_35_n_4 ),
        .O(\derivative[24]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_4 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[25]_i_2_n_4 ),
        .O(\derivative[24]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_40 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[25]_i_35_n_5 ),
        .O(\derivative[24]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_41 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[25]_i_35_n_6 ),
        .O(\derivative[24]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_42 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[24]),
        .O(\derivative[24]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_6 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[25]_i_2_n_5 ),
        .O(\derivative[24]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_7 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[25]_i_2_n_6 ),
        .O(\derivative[24]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_8 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[25]_i_2_n_7 ),
        .O(\derivative[24]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[24]_i_9 
       (.I0(\derivative_reg[25]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[25]_i_5_n_4 ),
        .O(\derivative[24]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_11 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[26]_i_5_n_5 ),
        .O(\derivative[25]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_12 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[26]_i_5_n_6 ),
        .O(\derivative[25]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_13 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[26]_i_5_n_7 ),
        .O(\derivative[25]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_14 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[26]_i_10_n_4 ),
        .O(\derivative[25]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_16 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[26]_i_10_n_5 ),
        .O(\derivative[25]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_17 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[26]_i_10_n_6 ),
        .O(\derivative[25]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_18 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[26]_i_10_n_7 ),
        .O(\derivative[25]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_19 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[26]_i_15_n_4 ),
        .O(\derivative[25]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_21 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[26]_i_15_n_5 ),
        .O(\derivative[25]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_22 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[26]_i_15_n_6 ),
        .O(\derivative[25]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_23 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[26]_i_15_n_7 ),
        .O(\derivative[25]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_24 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[26]_i_20_n_4 ),
        .O(\derivative[25]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_26 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[26]_i_20_n_5 ),
        .O(\derivative[25]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_27 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[26]_i_20_n_6 ),
        .O(\derivative[25]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_28 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[26]_i_20_n_7 ),
        .O(\derivative[25]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_29 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[26]_i_25_n_4 ),
        .O(\derivative[25]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[25]_i_3 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(\derivative_reg[26]_i_1_n_7 ),
        .O(\derivative[25]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_31 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[26]_i_25_n_5 ),
        .O(\derivative[25]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_32 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[26]_i_25_n_6 ),
        .O(\derivative[25]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_33 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[26]_i_25_n_7 ),
        .O(\derivative[25]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_34 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[26]_i_30_n_4 ),
        .O(\derivative[25]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_36 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[26]_i_30_n_5 ),
        .O(\derivative[25]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_37 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[26]_i_30_n_6 ),
        .O(\derivative[25]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_38 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[26]_i_30_n_7 ),
        .O(\derivative[25]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_39 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[26]_i_35_n_4 ),
        .O(\derivative[25]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_4 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[26]_i_2_n_4 ),
        .O(\derivative[25]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_40 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[26]_i_35_n_5 ),
        .O(\derivative[25]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_41 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[26]_i_35_n_6 ),
        .O(\derivative[25]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_42 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[25]),
        .O(\derivative[25]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_6 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[26]_i_2_n_5 ),
        .O(\derivative[25]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_7 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[26]_i_2_n_6 ),
        .O(\derivative[25]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_8 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[26]_i_2_n_7 ),
        .O(\derivative[25]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[25]_i_9 
       (.I0(\derivative_reg[26]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[26]_i_5_n_4 ),
        .O(\derivative[25]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_11 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[27]_i_5_n_5 ),
        .O(\derivative[26]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_12 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[27]_i_5_n_6 ),
        .O(\derivative[26]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_13 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[27]_i_5_n_7 ),
        .O(\derivative[26]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_14 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[27]_i_10_n_4 ),
        .O(\derivative[26]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_16 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[27]_i_10_n_5 ),
        .O(\derivative[26]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_17 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[27]_i_10_n_6 ),
        .O(\derivative[26]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_18 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[27]_i_10_n_7 ),
        .O(\derivative[26]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_19 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[27]_i_15_n_4 ),
        .O(\derivative[26]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_21 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[27]_i_15_n_5 ),
        .O(\derivative[26]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_22 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[27]_i_15_n_6 ),
        .O(\derivative[26]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_23 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[27]_i_15_n_7 ),
        .O(\derivative[26]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_24 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[27]_i_20_n_4 ),
        .O(\derivative[26]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_26 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[27]_i_20_n_5 ),
        .O(\derivative[26]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_27 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[27]_i_20_n_6 ),
        .O(\derivative[26]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_28 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[27]_i_20_n_7 ),
        .O(\derivative[26]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_29 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[27]_i_25_n_4 ),
        .O(\derivative[26]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[26]_i_3 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(\derivative_reg[27]_i_1_n_7 ),
        .O(\derivative[26]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_31 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[27]_i_25_n_5 ),
        .O(\derivative[26]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_32 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[27]_i_25_n_6 ),
        .O(\derivative[26]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_33 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[27]_i_25_n_7 ),
        .O(\derivative[26]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_34 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[27]_i_30_n_4 ),
        .O(\derivative[26]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_36 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[27]_i_30_n_5 ),
        .O(\derivative[26]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_37 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[27]_i_30_n_6 ),
        .O(\derivative[26]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_38 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[27]_i_30_n_7 ),
        .O(\derivative[26]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_39 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[27]_i_35_n_4 ),
        .O(\derivative[26]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_4 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[27]_i_2_n_4 ),
        .O(\derivative[26]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_40 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[27]_i_35_n_5 ),
        .O(\derivative[26]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_41 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[27]_i_35_n_6 ),
        .O(\derivative[26]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_42 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[26]),
        .O(\derivative[26]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_6 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[27]_i_2_n_5 ),
        .O(\derivative[26]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_7 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[27]_i_2_n_6 ),
        .O(\derivative[26]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_8 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[27]_i_2_n_7 ),
        .O(\derivative[26]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[26]_i_9 
       (.I0(\derivative_reg[27]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[27]_i_5_n_4 ),
        .O(\derivative[26]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_11 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[28]_i_5_n_5 ),
        .O(\derivative[27]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_12 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[28]_i_5_n_6 ),
        .O(\derivative[27]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_13 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[28]_i_5_n_7 ),
        .O(\derivative[27]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_14 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[28]_i_10_n_4 ),
        .O(\derivative[27]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_16 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[28]_i_10_n_5 ),
        .O(\derivative[27]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_17 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[28]_i_10_n_6 ),
        .O(\derivative[27]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_18 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[28]_i_10_n_7 ),
        .O(\derivative[27]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_19 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[28]_i_15_n_4 ),
        .O(\derivative[27]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_21 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[28]_i_15_n_5 ),
        .O(\derivative[27]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_22 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[28]_i_15_n_6 ),
        .O(\derivative[27]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_23 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[28]_i_15_n_7 ),
        .O(\derivative[27]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_24 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[28]_i_20_n_4 ),
        .O(\derivative[27]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_26 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[28]_i_20_n_5 ),
        .O(\derivative[27]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_27 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[28]_i_20_n_6 ),
        .O(\derivative[27]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_28 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[28]_i_20_n_7 ),
        .O(\derivative[27]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_29 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[28]_i_25_n_4 ),
        .O(\derivative[27]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[27]_i_3 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(\derivative_reg[28]_i_1_n_7 ),
        .O(\derivative[27]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_31 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[28]_i_25_n_5 ),
        .O(\derivative[27]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_32 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[28]_i_25_n_6 ),
        .O(\derivative[27]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_33 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[28]_i_25_n_7 ),
        .O(\derivative[27]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_34 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[28]_i_30_n_4 ),
        .O(\derivative[27]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_36 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[28]_i_30_n_5 ),
        .O(\derivative[27]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_37 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[28]_i_30_n_6 ),
        .O(\derivative[27]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_38 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[28]_i_30_n_7 ),
        .O(\derivative[27]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_39 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[28]_i_35_n_4 ),
        .O(\derivative[27]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_4 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[28]_i_2_n_4 ),
        .O(\derivative[27]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_40 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[28]_i_35_n_5 ),
        .O(\derivative[27]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_41 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[28]_i_35_n_6 ),
        .O(\derivative[27]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_42 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[27]),
        .O(\derivative[27]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_6 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[28]_i_2_n_5 ),
        .O(\derivative[27]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_7 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[28]_i_2_n_6 ),
        .O(\derivative[27]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_8 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[28]_i_2_n_7 ),
        .O(\derivative[27]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_9 
       (.I0(\derivative_reg[28]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[28]_i_5_n_4 ),
        .O(\derivative[27]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_11 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[29]_i_5_n_5 ),
        .O(\derivative[28]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_12 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[29]_i_5_n_6 ),
        .O(\derivative[28]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_13 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[29]_i_5_n_7 ),
        .O(\derivative[28]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_14 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[29]_i_10_n_4 ),
        .O(\derivative[28]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_16 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[29]_i_10_n_5 ),
        .O(\derivative[28]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_17 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[29]_i_10_n_6 ),
        .O(\derivative[28]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_18 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[29]_i_10_n_7 ),
        .O(\derivative[28]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_19 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[29]_i_15_n_4 ),
        .O(\derivative[28]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_21 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[29]_i_15_n_5 ),
        .O(\derivative[28]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_22 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[29]_i_15_n_6 ),
        .O(\derivative[28]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_23 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[29]_i_15_n_7 ),
        .O(\derivative[28]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_24 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[29]_i_20_n_4 ),
        .O(\derivative[28]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_26 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[29]_i_20_n_5 ),
        .O(\derivative[28]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_27 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[29]_i_20_n_6 ),
        .O(\derivative[28]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_28 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[29]_i_20_n_7 ),
        .O(\derivative[28]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_29 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[29]_i_25_n_4 ),
        .O(\derivative[28]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[28]_i_3 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(\derivative_reg[29]_i_1_n_7 ),
        .O(\derivative[28]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_31 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[29]_i_25_n_5 ),
        .O(\derivative[28]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_32 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[29]_i_25_n_6 ),
        .O(\derivative[28]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_33 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[29]_i_25_n_7 ),
        .O(\derivative[28]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_34 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[29]_i_30_n_4 ),
        .O(\derivative[28]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_36 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[29]_i_30_n_5 ),
        .O(\derivative[28]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_37 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[29]_i_30_n_6 ),
        .O(\derivative[28]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_38 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[29]_i_30_n_7 ),
        .O(\derivative[28]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_39 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[29]_i_35_n_4 ),
        .O(\derivative[28]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_4 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[29]_i_2_n_4 ),
        .O(\derivative[28]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_40 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[29]_i_35_n_5 ),
        .O(\derivative[28]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_41 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[29]_i_35_n_6 ),
        .O(\derivative[28]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_42 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[28]),
        .O(\derivative[28]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_6 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[29]_i_2_n_5 ),
        .O(\derivative[28]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_7 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[29]_i_2_n_6 ),
        .O(\derivative[28]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_8 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[29]_i_2_n_7 ),
        .O(\derivative[28]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[28]_i_9 
       (.I0(\derivative_reg[29]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[29]_i_5_n_4 ),
        .O(\derivative[28]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_11 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[30]_i_5_n_5 ),
        .O(\derivative[29]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_12 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[30]_i_5_n_6 ),
        .O(\derivative[29]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_13 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[30]_i_5_n_7 ),
        .O(\derivative[29]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_14 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[30]_i_10_n_4 ),
        .O(\derivative[29]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_16 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[30]_i_10_n_5 ),
        .O(\derivative[29]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_17 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[30]_i_10_n_6 ),
        .O(\derivative[29]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_18 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[30]_i_10_n_7 ),
        .O(\derivative[29]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_19 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[30]_i_15_n_4 ),
        .O(\derivative[29]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_21 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[30]_i_15_n_5 ),
        .O(\derivative[29]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_22 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[30]_i_15_n_6 ),
        .O(\derivative[29]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_23 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[30]_i_15_n_7 ),
        .O(\derivative[29]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_24 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[30]_i_20_n_4 ),
        .O(\derivative[29]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_26 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[30]_i_20_n_5 ),
        .O(\derivative[29]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_27 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[30]_i_20_n_6 ),
        .O(\derivative[29]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_28 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[30]_i_20_n_7 ),
        .O(\derivative[29]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_29 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[30]_i_25_n_4 ),
        .O(\derivative[29]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[29]_i_3 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(\derivative_reg[30]_i_1_n_7 ),
        .O(\derivative[29]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_31 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[30]_i_25_n_5 ),
        .O(\derivative[29]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_32 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[30]_i_25_n_6 ),
        .O(\derivative[29]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_33 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[30]_i_25_n_7 ),
        .O(\derivative[29]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_34 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[30]_i_30_n_4 ),
        .O(\derivative[29]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_36 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[30]_i_30_n_5 ),
        .O(\derivative[29]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_37 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[30]_i_30_n_6 ),
        .O(\derivative[29]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_38 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[30]_i_30_n_7 ),
        .O(\derivative[29]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_39 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[30]_i_35_n_4 ),
        .O(\derivative[29]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_4 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[30]_i_2_n_4 ),
        .O(\derivative[29]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_40 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[30]_i_35_n_5 ),
        .O(\derivative[29]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_41 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[30]_i_35_n_6 ),
        .O(\derivative[29]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_42 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[29]),
        .O(\derivative[29]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_6 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[30]_i_2_n_5 ),
        .O(\derivative[29]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_7 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[30]_i_2_n_6 ),
        .O(\derivative[29]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_8 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[30]_i_2_n_7 ),
        .O(\derivative[29]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[29]_i_9 
       (.I0(\derivative_reg[30]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[30]_i_5_n_4 ),
        .O(\derivative[29]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_11 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[3]_i_5_n_5 ),
        .O(\derivative[2]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_12 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[3]_i_5_n_6 ),
        .O(\derivative[2]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_13 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[3]_i_5_n_7 ),
        .O(\derivative[2]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_14 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[3]_i_10_n_4 ),
        .O(\derivative[2]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_16 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[3]_i_10_n_5 ),
        .O(\derivative[2]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_17 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[3]_i_10_n_6 ),
        .O(\derivative[2]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_18 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[3]_i_10_n_7 ),
        .O(\derivative[2]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_19 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[3]_i_15_n_4 ),
        .O(\derivative[2]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_21 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[3]_i_15_n_5 ),
        .O(\derivative[2]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_22 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[3]_i_15_n_6 ),
        .O(\derivative[2]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_23 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[3]_i_15_n_7 ),
        .O(\derivative[2]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_24 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[3]_i_20_n_4 ),
        .O(\derivative[2]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_26 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[3]_i_20_n_5 ),
        .O(\derivative[2]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_27 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[3]_i_20_n_6 ),
        .O(\derivative[2]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_28 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[3]_i_20_n_7 ),
        .O(\derivative[2]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_29 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[3]_i_25_n_4 ),
        .O(\derivative[2]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[2]_i_3 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(\derivative_reg[3]_i_1_n_7 ),
        .O(\derivative[2]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_31 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[3]_i_25_n_5 ),
        .O(\derivative[2]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_32 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[3]_i_25_n_6 ),
        .O(\derivative[2]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_33 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[3]_i_25_n_7 ),
        .O(\derivative[2]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_34 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[3]_i_30_n_4 ),
        .O(\derivative[2]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_36 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[3]_i_30_n_5 ),
        .O(\derivative[2]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_37 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[3]_i_30_n_6 ),
        .O(\derivative[2]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_38 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[3]_i_30_n_7 ),
        .O(\derivative[2]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_39 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[3]_i_35_n_4 ),
        .O(\derivative[2]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_4 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[3]_i_2_n_4 ),
        .O(\derivative[2]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_40 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[3]_i_35_n_5 ),
        .O(\derivative[2]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_41 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[3]_i_35_n_6 ),
        .O(\derivative[2]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_42 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[2]),
        .O(\derivative[2]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_6 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[3]_i_2_n_5 ),
        .O(\derivative[2]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_7 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[3]_i_2_n_6 ),
        .O(\derivative[2]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_8 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[3]_i_2_n_7 ),
        .O(\derivative[2]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[2]_i_9 
       (.I0(\derivative_reg[3]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[3]_i_5_n_4 ),
        .O(\derivative[2]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_11 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[26]),
        .I2(\derivative_reg[31]_i_3_n_6 ),
        .O(\derivative[30]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_12 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[25]),
        .I2(\derivative_reg[31]_i_3_n_7 ),
        .O(\derivative[30]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_13 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[24]),
        .I2(\derivative_reg[31]_i_12_n_4 ),
        .O(\derivative[30]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_14 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[23]),
        .I2(\derivative_reg[31]_i_12_n_5 ),
        .O(\derivative[30]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_16 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[22]),
        .I2(\derivative_reg[31]_i_12_n_6 ),
        .O(\derivative[30]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_17 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[21]),
        .I2(\derivative_reg[31]_i_12_n_7 ),
        .O(\derivative[30]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_18 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[20]),
        .I2(\derivative_reg[31]_i_21_n_4 ),
        .O(\derivative[30]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_19 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[19]),
        .I2(\derivative_reg[31]_i_21_n_5 ),
        .O(\derivative[30]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_21 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[18]),
        .I2(\derivative_reg[31]_i_21_n_6 ),
        .O(\derivative[30]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_22 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[17]),
        .I2(\derivative_reg[31]_i_21_n_7 ),
        .O(\derivative[30]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_23 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[16]),
        .I2(\derivative_reg[31]_i_30_n_4 ),
        .O(\derivative[30]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_24 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[15]),
        .I2(\derivative_reg[31]_i_30_n_5 ),
        .O(\derivative[30]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_26 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[14]),
        .I2(\derivative_reg[31]_i_30_n_6 ),
        .O(\derivative[30]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_27 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[13]),
        .I2(\derivative_reg[31]_i_30_n_7 ),
        .O(\derivative[30]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_28 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[12]),
        .I2(\derivative_reg[31]_i_39_n_4 ),
        .O(\derivative[30]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_29 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[11]),
        .I2(\derivative_reg[31]_i_39_n_5 ),
        .O(\derivative[30]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[30]_i_3 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(\derivative_reg[31]_i_2_n_4 ),
        .O(\derivative[30]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_31 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[10]),
        .I2(\derivative_reg[31]_i_39_n_6 ),
        .O(\derivative[30]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_32 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[9]),
        .I2(\derivative_reg[31]_i_39_n_7 ),
        .O(\derivative[30]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_33 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[8]),
        .I2(\derivative_reg[31]_i_48_n_4 ),
        .O(\derivative[30]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_34 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[7]),
        .I2(\derivative_reg[31]_i_48_n_5 ),
        .O(\derivative[30]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_36 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[6]),
        .I2(\derivative_reg[31]_i_48_n_6 ),
        .O(\derivative[30]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_37 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[5]),
        .I2(\derivative_reg[31]_i_48_n_7 ),
        .O(\derivative[30]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_38 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[4]),
        .I2(\derivative_reg[31]_i_57_n_4 ),
        .O(\derivative[30]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_39 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[3]),
        .I2(\derivative_reg[31]_i_57_n_5 ),
        .O(\derivative[30]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_4 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[31]),
        .I2(\derivative_reg[31]_i_2_n_5 ),
        .O(\derivative[30]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_40 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[2]),
        .I2(\derivative_reg[31]_i_57_n_6 ),
        .O(\derivative[30]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_41 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[1]),
        .I2(\derivative_reg[31]_i_57_n_7 ),
        .O(\derivative[30]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_42 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[0]),
        .I2(derivative11_out[30]),
        .O(\derivative[30]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_6 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[30]),
        .I2(\derivative_reg[31]_i_2_n_6 ),
        .O(\derivative[30]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_7 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[29]),
        .I2(\derivative_reg[31]_i_2_n_7 ),
        .O(\derivative[30]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_8 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[28]),
        .I2(\derivative_reg[31]_i_3_n_4 ),
        .O(\derivative[30]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[30]_i_9 
       (.I0(\derivative_reg[31]_i_1_n_3 ),
        .I1(dt[27]),
        .I2(\derivative_reg[31]_i_3_n_5 ),
        .O(\derivative[30]_i_9_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_10 
       (.I0(dt[29]),
        .O(\derivative[31]_i_10_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_11 
       (.I0(dt[28]),
        .O(\derivative[31]_i_11_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_13 
       (.I0(dt[27]),
        .O(\derivative[31]_i_13_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_14 
       (.I0(dt[26]),
        .O(\derivative[31]_i_14_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_15 
       (.I0(dt[25]),
        .O(\derivative[31]_i_15_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_16 
       (.I0(dt[24]),
        .O(\derivative[31]_i_16_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_17 
       (.I0(dt[27]),
        .O(\derivative[31]_i_17_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_18 
       (.I0(dt[26]),
        .O(\derivative[31]_i_18_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_19 
       (.I0(dt[25]),
        .O(\derivative[31]_i_19_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_20 
       (.I0(dt[24]),
        .O(\derivative[31]_i_20_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_22 
       (.I0(dt[23]),
        .O(\derivative[31]_i_22_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_23 
       (.I0(dt[22]),
        .O(\derivative[31]_i_23_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_24 
       (.I0(dt[21]),
        .O(\derivative[31]_i_24_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_25 
       (.I0(dt[20]),
        .O(\derivative[31]_i_25_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_26 
       (.I0(dt[23]),
        .O(\derivative[31]_i_26_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_27 
       (.I0(dt[22]),
        .O(\derivative[31]_i_27_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_28 
       (.I0(dt[21]),
        .O(\derivative[31]_i_28_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_29 
       (.I0(dt[20]),
        .O(\derivative[31]_i_29_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_31 
       (.I0(dt[19]),
        .O(\derivative[31]_i_31_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_32 
       (.I0(dt[18]),
        .O(\derivative[31]_i_32_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_33 
       (.I0(dt[17]),
        .O(\derivative[31]_i_33_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_34 
       (.I0(dt[16]),
        .O(\derivative[31]_i_34_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_35 
       (.I0(dt[19]),
        .O(\derivative[31]_i_35_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_36 
       (.I0(dt[18]),
        .O(\derivative[31]_i_36_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_37 
       (.I0(dt[17]),
        .O(\derivative[31]_i_37_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_38 
       (.I0(dt[16]),
        .O(\derivative[31]_i_38_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_4 
       (.I0(dt[31]),
        .O(\derivative[31]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_40 
       (.I0(dt[15]),
        .O(\derivative[31]_i_40_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_41 
       (.I0(dt[14]),
        .O(\derivative[31]_i_41_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_42 
       (.I0(dt[13]),
        .O(\derivative[31]_i_42_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_43 
       (.I0(dt[12]),
        .O(\derivative[31]_i_43_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_44 
       (.I0(dt[15]),
        .O(\derivative[31]_i_44_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_45 
       (.I0(dt[14]),
        .O(\derivative[31]_i_45_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_46 
       (.I0(dt[13]),
        .O(\derivative[31]_i_46_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_47 
       (.I0(dt[12]),
        .O(\derivative[31]_i_47_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_49 
       (.I0(dt[11]),
        .O(\derivative[31]_i_49_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_5 
       (.I0(dt[30]),
        .O(\derivative[31]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_50 
       (.I0(dt[10]),
        .O(\derivative[31]_i_50_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_51 
       (.I0(dt[9]),
        .O(\derivative[31]_i_51_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_52 
       (.I0(dt[8]),
        .O(\derivative[31]_i_52_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_53 
       (.I0(dt[11]),
        .O(\derivative[31]_i_53_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_54 
       (.I0(dt[10]),
        .O(\derivative[31]_i_54_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_55 
       (.I0(dt[9]),
        .O(\derivative[31]_i_55_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_56 
       (.I0(dt[8]),
        .O(\derivative[31]_i_56_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_58 
       (.I0(dt[7]),
        .O(\derivative[31]_i_58_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_59 
       (.I0(dt[6]),
        .O(\derivative[31]_i_59_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_6 
       (.I0(dt[29]),
        .O(\derivative[31]_i_6_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_60 
       (.I0(dt[5]),
        .O(\derivative[31]_i_60_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_61 
       (.I0(dt[4]),
        .O(\derivative[31]_i_61_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_62 
       (.I0(dt[7]),
        .O(\derivative[31]_i_62_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_63 
       (.I0(dt[6]),
        .O(\derivative[31]_i_63_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_64 
       (.I0(dt[5]),
        .O(\derivative[31]_i_64_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_65 
       (.I0(dt[4]),
        .O(\derivative[31]_i_65_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_66 
       (.I0(dt[3]),
        .O(\derivative[31]_i_66_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_67 
       (.I0(dt[2]),
        .O(\derivative[31]_i_67_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_68 
       (.I0(dt[1]),
        .O(\derivative[31]_i_68_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_69 
       (.I0(dt[3]),
        .O(\derivative[31]_i_69_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_7 
       (.I0(dt[28]),
        .O(\derivative[31]_i_7_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_70 
       (.I0(dt[2]),
        .O(\derivative[31]_i_70_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_71 
       (.I0(dt[1]),
        .O(\derivative[31]_i_71_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \derivative[31]_i_72 
       (.I0(dt[0]),
        .I1(derivative11_out[31]),
        .O(\derivative[31]_i_72_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_8 
       (.I0(dt[31]),
        .O(\derivative[31]_i_8_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_9 
       (.I0(dt[30]),
        .O(\derivative[31]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_11 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[4]_i_5_n_5 ),
        .O(\derivative[3]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_12 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[4]_i_5_n_6 ),
        .O(\derivative[3]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_13 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[4]_i_5_n_7 ),
        .O(\derivative[3]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_14 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[4]_i_10_n_4 ),
        .O(\derivative[3]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_16 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[4]_i_10_n_5 ),
        .O(\derivative[3]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_17 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[4]_i_10_n_6 ),
        .O(\derivative[3]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_18 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[4]_i_10_n_7 ),
        .O(\derivative[3]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_19 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[4]_i_15_n_4 ),
        .O(\derivative[3]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_21 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[4]_i_15_n_5 ),
        .O(\derivative[3]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_22 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[4]_i_15_n_6 ),
        .O(\derivative[3]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_23 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[4]_i_15_n_7 ),
        .O(\derivative[3]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_24 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[4]_i_20_n_4 ),
        .O(\derivative[3]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_26 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[4]_i_20_n_5 ),
        .O(\derivative[3]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_27 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[4]_i_20_n_6 ),
        .O(\derivative[3]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_28 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[4]_i_20_n_7 ),
        .O(\derivative[3]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_29 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[4]_i_25_n_4 ),
        .O(\derivative[3]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[3]_i_3 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(\derivative_reg[4]_i_1_n_7 ),
        .O(\derivative[3]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_31 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[4]_i_25_n_5 ),
        .O(\derivative[3]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_32 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[4]_i_25_n_6 ),
        .O(\derivative[3]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_33 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[4]_i_25_n_7 ),
        .O(\derivative[3]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_34 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[4]_i_30_n_4 ),
        .O(\derivative[3]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_36 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[4]_i_30_n_5 ),
        .O(\derivative[3]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_37 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[4]_i_30_n_6 ),
        .O(\derivative[3]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_38 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[4]_i_30_n_7 ),
        .O(\derivative[3]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_39 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[4]_i_35_n_4 ),
        .O(\derivative[3]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_4 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[4]_i_2_n_4 ),
        .O(\derivative[3]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_40 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[4]_i_35_n_5 ),
        .O(\derivative[3]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_41 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[4]_i_35_n_6 ),
        .O(\derivative[3]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_42 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[3]),
        .O(\derivative[3]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_6 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[4]_i_2_n_5 ),
        .O(\derivative[3]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_7 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[4]_i_2_n_6 ),
        .O(\derivative[3]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_8 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[4]_i_2_n_7 ),
        .O(\derivative[3]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_9 
       (.I0(\derivative_reg[4]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[4]_i_5_n_4 ),
        .O(\derivative[3]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_11 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[5]_i_5_n_5 ),
        .O(\derivative[4]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_12 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[5]_i_5_n_6 ),
        .O(\derivative[4]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_13 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[5]_i_5_n_7 ),
        .O(\derivative[4]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_14 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[5]_i_10_n_4 ),
        .O(\derivative[4]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_16 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[5]_i_10_n_5 ),
        .O(\derivative[4]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_17 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[5]_i_10_n_6 ),
        .O(\derivative[4]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_18 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[5]_i_10_n_7 ),
        .O(\derivative[4]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_19 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[5]_i_15_n_4 ),
        .O(\derivative[4]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_21 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[5]_i_15_n_5 ),
        .O(\derivative[4]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_22 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[5]_i_15_n_6 ),
        .O(\derivative[4]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_23 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[5]_i_15_n_7 ),
        .O(\derivative[4]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_24 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[5]_i_20_n_4 ),
        .O(\derivative[4]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_26 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[5]_i_20_n_5 ),
        .O(\derivative[4]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_27 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[5]_i_20_n_6 ),
        .O(\derivative[4]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_28 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[5]_i_20_n_7 ),
        .O(\derivative[4]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_29 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[5]_i_25_n_4 ),
        .O(\derivative[4]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[4]_i_3 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(\derivative_reg[5]_i_1_n_7 ),
        .O(\derivative[4]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_31 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[5]_i_25_n_5 ),
        .O(\derivative[4]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_32 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[5]_i_25_n_6 ),
        .O(\derivative[4]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_33 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[5]_i_25_n_7 ),
        .O(\derivative[4]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_34 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[5]_i_30_n_4 ),
        .O(\derivative[4]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_36 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[5]_i_30_n_5 ),
        .O(\derivative[4]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_37 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[5]_i_30_n_6 ),
        .O(\derivative[4]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_38 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[5]_i_30_n_7 ),
        .O(\derivative[4]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_39 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[5]_i_35_n_4 ),
        .O(\derivative[4]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_4 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[5]_i_2_n_4 ),
        .O(\derivative[4]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_40 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[5]_i_35_n_5 ),
        .O(\derivative[4]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_41 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[5]_i_35_n_6 ),
        .O(\derivative[4]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_42 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[4]),
        .O(\derivative[4]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_6 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[5]_i_2_n_5 ),
        .O(\derivative[4]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_7 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[5]_i_2_n_6 ),
        .O(\derivative[4]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_8 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[5]_i_2_n_7 ),
        .O(\derivative[4]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[4]_i_9 
       (.I0(\derivative_reg[5]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[5]_i_5_n_4 ),
        .O(\derivative[4]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_11 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[6]_i_5_n_5 ),
        .O(\derivative[5]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_12 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[6]_i_5_n_6 ),
        .O(\derivative[5]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_13 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[6]_i_5_n_7 ),
        .O(\derivative[5]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_14 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[6]_i_10_n_4 ),
        .O(\derivative[5]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_16 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[6]_i_10_n_5 ),
        .O(\derivative[5]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_17 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[6]_i_10_n_6 ),
        .O(\derivative[5]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_18 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[6]_i_10_n_7 ),
        .O(\derivative[5]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_19 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[6]_i_15_n_4 ),
        .O(\derivative[5]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_21 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[6]_i_15_n_5 ),
        .O(\derivative[5]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_22 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[6]_i_15_n_6 ),
        .O(\derivative[5]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_23 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[6]_i_15_n_7 ),
        .O(\derivative[5]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_24 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[6]_i_20_n_4 ),
        .O(\derivative[5]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_26 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[6]_i_20_n_5 ),
        .O(\derivative[5]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_27 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[6]_i_20_n_6 ),
        .O(\derivative[5]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_28 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[6]_i_20_n_7 ),
        .O(\derivative[5]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_29 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[6]_i_25_n_4 ),
        .O(\derivative[5]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[5]_i_3 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(\derivative_reg[6]_i_1_n_7 ),
        .O(\derivative[5]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_31 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[6]_i_25_n_5 ),
        .O(\derivative[5]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_32 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[6]_i_25_n_6 ),
        .O(\derivative[5]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_33 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[6]_i_25_n_7 ),
        .O(\derivative[5]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_34 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[6]_i_30_n_4 ),
        .O(\derivative[5]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_36 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[6]_i_30_n_5 ),
        .O(\derivative[5]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_37 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[6]_i_30_n_6 ),
        .O(\derivative[5]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_38 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[6]_i_30_n_7 ),
        .O(\derivative[5]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_39 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[6]_i_35_n_4 ),
        .O(\derivative[5]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_4 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[6]_i_2_n_4 ),
        .O(\derivative[5]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_40 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[6]_i_35_n_5 ),
        .O(\derivative[5]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_41 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[6]_i_35_n_6 ),
        .O(\derivative[5]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_42 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[5]),
        .O(\derivative[5]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_6 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[6]_i_2_n_5 ),
        .O(\derivative[5]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_7 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[6]_i_2_n_6 ),
        .O(\derivative[5]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_8 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[6]_i_2_n_7 ),
        .O(\derivative[5]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[5]_i_9 
       (.I0(\derivative_reg[6]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[6]_i_5_n_4 ),
        .O(\derivative[5]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_11 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[7]_i_5_n_5 ),
        .O(\derivative[6]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_12 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[7]_i_5_n_6 ),
        .O(\derivative[6]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_13 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[7]_i_5_n_7 ),
        .O(\derivative[6]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_14 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[7]_i_10_n_4 ),
        .O(\derivative[6]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_16 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[7]_i_10_n_5 ),
        .O(\derivative[6]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_17 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[7]_i_10_n_6 ),
        .O(\derivative[6]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_18 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[7]_i_10_n_7 ),
        .O(\derivative[6]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_19 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[7]_i_15_n_4 ),
        .O(\derivative[6]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_21 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[7]_i_15_n_5 ),
        .O(\derivative[6]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_22 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[7]_i_15_n_6 ),
        .O(\derivative[6]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_23 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[7]_i_15_n_7 ),
        .O(\derivative[6]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_24 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[7]_i_20_n_4 ),
        .O(\derivative[6]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_26 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[7]_i_20_n_5 ),
        .O(\derivative[6]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_27 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[7]_i_20_n_6 ),
        .O(\derivative[6]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_28 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[7]_i_20_n_7 ),
        .O(\derivative[6]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_29 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[7]_i_25_n_4 ),
        .O(\derivative[6]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[6]_i_3 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(\derivative_reg[7]_i_1_n_7 ),
        .O(\derivative[6]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_31 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[7]_i_25_n_5 ),
        .O(\derivative[6]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_32 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[7]_i_25_n_6 ),
        .O(\derivative[6]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_33 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[7]_i_25_n_7 ),
        .O(\derivative[6]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_34 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[7]_i_30_n_4 ),
        .O(\derivative[6]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_36 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[7]_i_30_n_5 ),
        .O(\derivative[6]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_37 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[7]_i_30_n_6 ),
        .O(\derivative[6]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_38 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[7]_i_30_n_7 ),
        .O(\derivative[6]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_39 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[7]_i_35_n_4 ),
        .O(\derivative[6]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_4 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[7]_i_2_n_4 ),
        .O(\derivative[6]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_40 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[7]_i_35_n_5 ),
        .O(\derivative[6]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_41 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[7]_i_35_n_6 ),
        .O(\derivative[6]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_42 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[6]),
        .O(\derivative[6]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_6 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[7]_i_2_n_5 ),
        .O(\derivative[6]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_7 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[7]_i_2_n_6 ),
        .O(\derivative[6]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_8 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[7]_i_2_n_7 ),
        .O(\derivative[6]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[6]_i_9 
       (.I0(\derivative_reg[7]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[7]_i_5_n_4 ),
        .O(\derivative[6]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_11 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[8]_i_5_n_5 ),
        .O(\derivative[7]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_12 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[8]_i_5_n_6 ),
        .O(\derivative[7]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_13 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[8]_i_5_n_7 ),
        .O(\derivative[7]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_14 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[8]_i_10_n_4 ),
        .O(\derivative[7]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_16 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[8]_i_10_n_5 ),
        .O(\derivative[7]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_17 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[8]_i_10_n_6 ),
        .O(\derivative[7]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_18 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[8]_i_10_n_7 ),
        .O(\derivative[7]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_19 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[8]_i_15_n_4 ),
        .O(\derivative[7]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_21 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[8]_i_15_n_5 ),
        .O(\derivative[7]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_22 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[8]_i_15_n_6 ),
        .O(\derivative[7]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_23 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[8]_i_15_n_7 ),
        .O(\derivative[7]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_24 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[8]_i_20_n_4 ),
        .O(\derivative[7]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_26 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[8]_i_20_n_5 ),
        .O(\derivative[7]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_27 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[8]_i_20_n_6 ),
        .O(\derivative[7]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_28 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[8]_i_20_n_7 ),
        .O(\derivative[7]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_29 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[8]_i_25_n_4 ),
        .O(\derivative[7]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[7]_i_3 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(\derivative_reg[8]_i_1_n_7 ),
        .O(\derivative[7]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_31 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[8]_i_25_n_5 ),
        .O(\derivative[7]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_32 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[8]_i_25_n_6 ),
        .O(\derivative[7]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_33 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[8]_i_25_n_7 ),
        .O(\derivative[7]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_34 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[8]_i_30_n_4 ),
        .O(\derivative[7]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_36 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[8]_i_30_n_5 ),
        .O(\derivative[7]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_37 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[8]_i_30_n_6 ),
        .O(\derivative[7]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_38 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[8]_i_30_n_7 ),
        .O(\derivative[7]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_39 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[8]_i_35_n_4 ),
        .O(\derivative[7]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_4 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[8]_i_2_n_4 ),
        .O(\derivative[7]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_40 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[8]_i_35_n_5 ),
        .O(\derivative[7]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_41 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[8]_i_35_n_6 ),
        .O(\derivative[7]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_42 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[7]),
        .O(\derivative[7]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_6 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[8]_i_2_n_5 ),
        .O(\derivative[7]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_7 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[8]_i_2_n_6 ),
        .O(\derivative[7]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_8 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[8]_i_2_n_7 ),
        .O(\derivative[7]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_9 
       (.I0(\derivative_reg[8]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[8]_i_5_n_4 ),
        .O(\derivative[7]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_11 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[9]_i_5_n_5 ),
        .O(\derivative[8]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_12 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[9]_i_5_n_6 ),
        .O(\derivative[8]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_13 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[9]_i_5_n_7 ),
        .O(\derivative[8]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_14 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[9]_i_10_n_4 ),
        .O(\derivative[8]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_16 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[9]_i_10_n_5 ),
        .O(\derivative[8]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_17 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[9]_i_10_n_6 ),
        .O(\derivative[8]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_18 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[9]_i_10_n_7 ),
        .O(\derivative[8]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_19 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[9]_i_15_n_4 ),
        .O(\derivative[8]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_21 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[9]_i_15_n_5 ),
        .O(\derivative[8]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_22 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[9]_i_15_n_6 ),
        .O(\derivative[8]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_23 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[9]_i_15_n_7 ),
        .O(\derivative[8]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_24 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[9]_i_20_n_4 ),
        .O(\derivative[8]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_26 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[9]_i_20_n_5 ),
        .O(\derivative[8]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_27 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[9]_i_20_n_6 ),
        .O(\derivative[8]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_28 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[9]_i_20_n_7 ),
        .O(\derivative[8]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_29 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[9]_i_25_n_4 ),
        .O(\derivative[8]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[8]_i_3 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(\derivative_reg[9]_i_1_n_7 ),
        .O(\derivative[8]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_31 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[9]_i_25_n_5 ),
        .O(\derivative[8]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_32 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[9]_i_25_n_6 ),
        .O(\derivative[8]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_33 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[9]_i_25_n_7 ),
        .O(\derivative[8]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_34 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[9]_i_30_n_4 ),
        .O(\derivative[8]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_36 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[9]_i_30_n_5 ),
        .O(\derivative[8]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_37 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[9]_i_30_n_6 ),
        .O(\derivative[8]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_38 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[9]_i_30_n_7 ),
        .O(\derivative[8]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_39 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[9]_i_35_n_4 ),
        .O(\derivative[8]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_4 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[9]_i_2_n_4 ),
        .O(\derivative[8]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_40 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[9]_i_35_n_5 ),
        .O(\derivative[8]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_41 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[9]_i_35_n_6 ),
        .O(\derivative[8]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_42 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[8]),
        .O(\derivative[8]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_6 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[9]_i_2_n_5 ),
        .O(\derivative[8]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_7 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[9]_i_2_n_6 ),
        .O(\derivative[8]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_8 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[9]_i_2_n_7 ),
        .O(\derivative[8]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[8]_i_9 
       (.I0(\derivative_reg[9]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[9]_i_5_n_4 ),
        .O(\derivative[8]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_11 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[26]),
        .I2(\derivative_reg[10]_i_5_n_5 ),
        .O(\derivative[9]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_12 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[25]),
        .I2(\derivative_reg[10]_i_5_n_6 ),
        .O(\derivative[9]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_13 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[24]),
        .I2(\derivative_reg[10]_i_5_n_7 ),
        .O(\derivative[9]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_14 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[23]),
        .I2(\derivative_reg[10]_i_10_n_4 ),
        .O(\derivative[9]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_16 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[22]),
        .I2(\derivative_reg[10]_i_10_n_5 ),
        .O(\derivative[9]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_17 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[21]),
        .I2(\derivative_reg[10]_i_10_n_6 ),
        .O(\derivative[9]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_18 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[20]),
        .I2(\derivative_reg[10]_i_10_n_7 ),
        .O(\derivative[9]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_19 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[19]),
        .I2(\derivative_reg[10]_i_15_n_4 ),
        .O(\derivative[9]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_21 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[18]),
        .I2(\derivative_reg[10]_i_15_n_5 ),
        .O(\derivative[9]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_22 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[17]),
        .I2(\derivative_reg[10]_i_15_n_6 ),
        .O(\derivative[9]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_23 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[16]),
        .I2(\derivative_reg[10]_i_15_n_7 ),
        .O(\derivative[9]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_24 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[15]),
        .I2(\derivative_reg[10]_i_20_n_4 ),
        .O(\derivative[9]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_26 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[14]),
        .I2(\derivative_reg[10]_i_20_n_5 ),
        .O(\derivative[9]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_27 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[13]),
        .I2(\derivative_reg[10]_i_20_n_6 ),
        .O(\derivative[9]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_28 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[12]),
        .I2(\derivative_reg[10]_i_20_n_7 ),
        .O(\derivative[9]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_29 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[11]),
        .I2(\derivative_reg[10]_i_25_n_4 ),
        .O(\derivative[9]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[9]_i_3 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(\derivative_reg[10]_i_1_n_7 ),
        .O(\derivative[9]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_31 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[10]),
        .I2(\derivative_reg[10]_i_25_n_5 ),
        .O(\derivative[9]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_32 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[9]),
        .I2(\derivative_reg[10]_i_25_n_6 ),
        .O(\derivative[9]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_33 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[8]),
        .I2(\derivative_reg[10]_i_25_n_7 ),
        .O(\derivative[9]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_34 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[7]),
        .I2(\derivative_reg[10]_i_30_n_4 ),
        .O(\derivative[9]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_36 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[6]),
        .I2(\derivative_reg[10]_i_30_n_5 ),
        .O(\derivative[9]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_37 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[5]),
        .I2(\derivative_reg[10]_i_30_n_6 ),
        .O(\derivative[9]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_38 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[4]),
        .I2(\derivative_reg[10]_i_30_n_7 ),
        .O(\derivative[9]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_39 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[3]),
        .I2(\derivative_reg[10]_i_35_n_4 ),
        .O(\derivative[9]_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_4 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[31]),
        .I2(\derivative_reg[10]_i_2_n_4 ),
        .O(\derivative[9]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_40 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[2]),
        .I2(\derivative_reg[10]_i_35_n_5 ),
        .O(\derivative[9]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_41 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[1]),
        .I2(\derivative_reg[10]_i_35_n_6 ),
        .O(\derivative[9]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_42 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[0]),
        .I2(derivative11_out[9]),
        .O(\derivative[9]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_6 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[30]),
        .I2(\derivative_reg[10]_i_2_n_5 ),
        .O(\derivative[9]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_7 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[29]),
        .I2(\derivative_reg[10]_i_2_n_6 ),
        .O(\derivative[9]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_8 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[28]),
        .I2(\derivative_reg[10]_i_2_n_7 ),
        .O(\derivative[9]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[9]_i_9 
       (.I0(\derivative_reg[10]_i_1_n_2 ),
        .I1(dt[27]),
        .I2(\derivative_reg[10]_i_5_n_4 ),
        .O(\derivative[9]_i_9_n_0 ));
  FDRE \derivative_reg[0] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[0]_i_1_n_3 ),
        .Q(derivative_out[0]),
        .R(1'b0));
  CARRY4 \derivative_reg[0]_i_1 
       (.CI(\derivative_reg[0]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[0]_i_1_CO_UNCONNECTED [3:1],\derivative_reg[0]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\derivative_reg[1]_i_1_n_2 }),
        .O(\NLW_derivative_reg[0]_i_1_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\derivative[0]_i_3_n_0 }));
  CARRY4 \derivative_reg[0]_i_14 
       (.CI(\derivative_reg[0]_i_19_n_0 ),
        .CO({\derivative_reg[0]_i_14_n_0 ,\derivative_reg[0]_i_14_n_1 ,\derivative_reg[0]_i_14_n_2 ,\derivative_reg[0]_i_14_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[1]_i_15_n_4 ,\derivative_reg[1]_i_15_n_5 ,\derivative_reg[1]_i_15_n_6 ,\derivative_reg[1]_i_15_n_7 }),
        .O(\NLW_derivative_reg[0]_i_14_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_20_n_0 ,\derivative[0]_i_21_n_0 ,\derivative[0]_i_22_n_0 ,\derivative[0]_i_23_n_0 }));
  CARRY4 \derivative_reg[0]_i_19 
       (.CI(\derivative_reg[0]_i_24_n_0 ),
        .CO({\derivative_reg[0]_i_19_n_0 ,\derivative_reg[0]_i_19_n_1 ,\derivative_reg[0]_i_19_n_2 ,\derivative_reg[0]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[1]_i_20_n_4 ,\derivative_reg[1]_i_20_n_5 ,\derivative_reg[1]_i_20_n_6 ,\derivative_reg[1]_i_20_n_7 }),
        .O(\NLW_derivative_reg[0]_i_19_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_25_n_0 ,\derivative[0]_i_26_n_0 ,\derivative[0]_i_27_n_0 ,\derivative[0]_i_28_n_0 }));
  CARRY4 \derivative_reg[0]_i_2 
       (.CI(\derivative_reg[0]_i_4_n_0 ),
        .CO({\derivative_reg[0]_i_2_n_0 ,\derivative_reg[0]_i_2_n_1 ,\derivative_reg[0]_i_2_n_2 ,\derivative_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[1]_i_2_n_4 ,\derivative_reg[1]_i_2_n_5 ,\derivative_reg[1]_i_2_n_6 ,\derivative_reg[1]_i_2_n_7 }),
        .O(\NLW_derivative_reg[0]_i_2_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_5_n_0 ,\derivative[0]_i_6_n_0 ,\derivative[0]_i_7_n_0 ,\derivative[0]_i_8_n_0 }));
  CARRY4 \derivative_reg[0]_i_24 
       (.CI(\derivative_reg[0]_i_29_n_0 ),
        .CO({\derivative_reg[0]_i_24_n_0 ,\derivative_reg[0]_i_24_n_1 ,\derivative_reg[0]_i_24_n_2 ,\derivative_reg[0]_i_24_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[1]_i_25_n_4 ,\derivative_reg[1]_i_25_n_5 ,\derivative_reg[1]_i_25_n_6 ,\derivative_reg[1]_i_25_n_7 }),
        .O(\NLW_derivative_reg[0]_i_24_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_30_n_0 ,\derivative[0]_i_31_n_0 ,\derivative[0]_i_32_n_0 ,\derivative[0]_i_33_n_0 }));
  CARRY4 \derivative_reg[0]_i_29 
       (.CI(\derivative_reg[0]_i_34_n_0 ),
        .CO({\derivative_reg[0]_i_29_n_0 ,\derivative_reg[0]_i_29_n_1 ,\derivative_reg[0]_i_29_n_2 ,\derivative_reg[0]_i_29_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[1]_i_30_n_4 ,\derivative_reg[1]_i_30_n_5 ,\derivative_reg[1]_i_30_n_6 ,\derivative_reg[1]_i_30_n_7 }),
        .O(\NLW_derivative_reg[0]_i_29_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_35_n_0 ,\derivative[0]_i_36_n_0 ,\derivative[0]_i_37_n_0 ,\derivative[0]_i_38_n_0 }));
  CARRY4 \derivative_reg[0]_i_34 
       (.CI(1'b0),
        .CO({\derivative_reg[0]_i_34_n_0 ,\derivative_reg[0]_i_34_n_1 ,\derivative_reg[0]_i_34_n_2 ,\derivative_reg[0]_i_34_n_3 }),
        .CYINIT(\derivative_reg[1]_i_1_n_2 ),
        .DI({\derivative_reg[1]_i_35_n_4 ,\derivative_reg[1]_i_35_n_5 ,\derivative_reg[1]_i_35_n_6 ,derivative11_out[0]}),
        .O(\NLW_derivative_reg[0]_i_34_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_39_n_0 ,\derivative[0]_i_40_n_0 ,\derivative[0]_i_41_n_0 ,\derivative[0]_i_42_n_0 }));
  CARRY4 \derivative_reg[0]_i_4 
       (.CI(\derivative_reg[0]_i_9_n_0 ),
        .CO({\derivative_reg[0]_i_4_n_0 ,\derivative_reg[0]_i_4_n_1 ,\derivative_reg[0]_i_4_n_2 ,\derivative_reg[0]_i_4_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[1]_i_5_n_4 ,\derivative_reg[1]_i_5_n_5 ,\derivative_reg[1]_i_5_n_6 ,\derivative_reg[1]_i_5_n_7 }),
        .O(\NLW_derivative_reg[0]_i_4_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_10_n_0 ,\derivative[0]_i_11_n_0 ,\derivative[0]_i_12_n_0 ,\derivative[0]_i_13_n_0 }));
  CARRY4 \derivative_reg[0]_i_9 
       (.CI(\derivative_reg[0]_i_14_n_0 ),
        .CO({\derivative_reg[0]_i_9_n_0 ,\derivative_reg[0]_i_9_n_1 ,\derivative_reg[0]_i_9_n_2 ,\derivative_reg[0]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[1]_i_10_n_4 ,\derivative_reg[1]_i_10_n_5 ,\derivative_reg[1]_i_10_n_6 ,\derivative_reg[1]_i_10_n_7 }),
        .O(\NLW_derivative_reg[0]_i_9_O_UNCONNECTED [3:0]),
        .S({\derivative[0]_i_15_n_0 ,\derivative[0]_i_16_n_0 ,\derivative[0]_i_17_n_0 ,\derivative[0]_i_18_n_0 }));
  FDRE \derivative_reg[10] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[10]_i_1_n_2 ),
        .Q(derivative_out[10]),
        .R(1'b0));
  CARRY4 \derivative_reg[10]_i_1 
       (.CI(\derivative_reg[10]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[10]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[10]_i_1_n_2 ,\derivative_reg[10]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[11]_i_1_n_2 ,\derivative_reg[11]_i_2_n_4 }),
        .O({\NLW_derivative_reg[10]_i_1_O_UNCONNECTED [3:1],\derivative_reg[10]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[10]_i_3_n_0 ,\derivative[10]_i_4_n_0 }));
  CARRY4 \derivative_reg[10]_i_10 
       (.CI(\derivative_reg[10]_i_15_n_0 ),
        .CO({\derivative_reg[10]_i_10_n_0 ,\derivative_reg[10]_i_10_n_1 ,\derivative_reg[10]_i_10_n_2 ,\derivative_reg[10]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_10_n_5 ,\derivative_reg[11]_i_10_n_6 ,\derivative_reg[11]_i_10_n_7 ,\derivative_reg[11]_i_15_n_4 }),
        .O({\derivative_reg[10]_i_10_n_4 ,\derivative_reg[10]_i_10_n_5 ,\derivative_reg[10]_i_10_n_6 ,\derivative_reg[10]_i_10_n_7 }),
        .S({\derivative[10]_i_16_n_0 ,\derivative[10]_i_17_n_0 ,\derivative[10]_i_18_n_0 ,\derivative[10]_i_19_n_0 }));
  CARRY4 \derivative_reg[10]_i_15 
       (.CI(\derivative_reg[10]_i_20_n_0 ),
        .CO({\derivative_reg[10]_i_15_n_0 ,\derivative_reg[10]_i_15_n_1 ,\derivative_reg[10]_i_15_n_2 ,\derivative_reg[10]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_15_n_5 ,\derivative_reg[11]_i_15_n_6 ,\derivative_reg[11]_i_15_n_7 ,\derivative_reg[11]_i_20_n_4 }),
        .O({\derivative_reg[10]_i_15_n_4 ,\derivative_reg[10]_i_15_n_5 ,\derivative_reg[10]_i_15_n_6 ,\derivative_reg[10]_i_15_n_7 }),
        .S({\derivative[10]_i_21_n_0 ,\derivative[10]_i_22_n_0 ,\derivative[10]_i_23_n_0 ,\derivative[10]_i_24_n_0 }));
  CARRY4 \derivative_reg[10]_i_2 
       (.CI(\derivative_reg[10]_i_5_n_0 ),
        .CO({\derivative_reg[10]_i_2_n_0 ,\derivative_reg[10]_i_2_n_1 ,\derivative_reg[10]_i_2_n_2 ,\derivative_reg[10]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_2_n_5 ,\derivative_reg[11]_i_2_n_6 ,\derivative_reg[11]_i_2_n_7 ,\derivative_reg[11]_i_5_n_4 }),
        .O({\derivative_reg[10]_i_2_n_4 ,\derivative_reg[10]_i_2_n_5 ,\derivative_reg[10]_i_2_n_6 ,\derivative_reg[10]_i_2_n_7 }),
        .S({\derivative[10]_i_6_n_0 ,\derivative[10]_i_7_n_0 ,\derivative[10]_i_8_n_0 ,\derivative[10]_i_9_n_0 }));
  CARRY4 \derivative_reg[10]_i_20 
       (.CI(\derivative_reg[10]_i_25_n_0 ),
        .CO({\derivative_reg[10]_i_20_n_0 ,\derivative_reg[10]_i_20_n_1 ,\derivative_reg[10]_i_20_n_2 ,\derivative_reg[10]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_20_n_5 ,\derivative_reg[11]_i_20_n_6 ,\derivative_reg[11]_i_20_n_7 ,\derivative_reg[11]_i_25_n_4 }),
        .O({\derivative_reg[10]_i_20_n_4 ,\derivative_reg[10]_i_20_n_5 ,\derivative_reg[10]_i_20_n_6 ,\derivative_reg[10]_i_20_n_7 }),
        .S({\derivative[10]_i_26_n_0 ,\derivative[10]_i_27_n_0 ,\derivative[10]_i_28_n_0 ,\derivative[10]_i_29_n_0 }));
  CARRY4 \derivative_reg[10]_i_25 
       (.CI(\derivative_reg[10]_i_30_n_0 ),
        .CO({\derivative_reg[10]_i_25_n_0 ,\derivative_reg[10]_i_25_n_1 ,\derivative_reg[10]_i_25_n_2 ,\derivative_reg[10]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_25_n_5 ,\derivative_reg[11]_i_25_n_6 ,\derivative_reg[11]_i_25_n_7 ,\derivative_reg[11]_i_30_n_4 }),
        .O({\derivative_reg[10]_i_25_n_4 ,\derivative_reg[10]_i_25_n_5 ,\derivative_reg[10]_i_25_n_6 ,\derivative_reg[10]_i_25_n_7 }),
        .S({\derivative[10]_i_31_n_0 ,\derivative[10]_i_32_n_0 ,\derivative[10]_i_33_n_0 ,\derivative[10]_i_34_n_0 }));
  CARRY4 \derivative_reg[10]_i_30 
       (.CI(\derivative_reg[10]_i_35_n_0 ),
        .CO({\derivative_reg[10]_i_30_n_0 ,\derivative_reg[10]_i_30_n_1 ,\derivative_reg[10]_i_30_n_2 ,\derivative_reg[10]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_30_n_5 ,\derivative_reg[11]_i_30_n_6 ,\derivative_reg[11]_i_30_n_7 ,\derivative_reg[11]_i_35_n_4 }),
        .O({\derivative_reg[10]_i_30_n_4 ,\derivative_reg[10]_i_30_n_5 ,\derivative_reg[10]_i_30_n_6 ,\derivative_reg[10]_i_30_n_7 }),
        .S({\derivative[10]_i_36_n_0 ,\derivative[10]_i_37_n_0 ,\derivative[10]_i_38_n_0 ,\derivative[10]_i_39_n_0 }));
  CARRY4 \derivative_reg[10]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[10]_i_35_n_0 ,\derivative_reg[10]_i_35_n_1 ,\derivative_reg[10]_i_35_n_2 ,\derivative_reg[10]_i_35_n_3 }),
        .CYINIT(\derivative_reg[11]_i_1_n_2 ),
        .DI({\derivative_reg[11]_i_35_n_5 ,\derivative_reg[11]_i_35_n_6 ,derivative11_out[10],1'b0}),
        .O({\derivative_reg[10]_i_35_n_4 ,\derivative_reg[10]_i_35_n_5 ,\derivative_reg[10]_i_35_n_6 ,\NLW_derivative_reg[10]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[10]_i_40_n_0 ,\derivative[10]_i_41_n_0 ,\derivative[10]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[10]_i_5 
       (.CI(\derivative_reg[10]_i_10_n_0 ),
        .CO({\derivative_reg[10]_i_5_n_0 ,\derivative_reg[10]_i_5_n_1 ,\derivative_reg[10]_i_5_n_2 ,\derivative_reg[10]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_5_n_5 ,\derivative_reg[11]_i_5_n_6 ,\derivative_reg[11]_i_5_n_7 ,\derivative_reg[11]_i_10_n_4 }),
        .O({\derivative_reg[10]_i_5_n_4 ,\derivative_reg[10]_i_5_n_5 ,\derivative_reg[10]_i_5_n_6 ,\derivative_reg[10]_i_5_n_7 }),
        .S({\derivative[10]_i_11_n_0 ,\derivative[10]_i_12_n_0 ,\derivative[10]_i_13_n_0 ,\derivative[10]_i_14_n_0 }));
  FDRE \derivative_reg[11] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[11]_i_1_n_2 ),
        .Q(derivative_out[11]),
        .R(1'b0));
  CARRY4 \derivative_reg[11]_i_1 
       (.CI(\derivative_reg[11]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[11]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[11]_i_1_n_2 ,\derivative_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[12]_i_1_n_2 ,\derivative_reg[12]_i_2_n_4 }),
        .O({\NLW_derivative_reg[11]_i_1_O_UNCONNECTED [3:1],\derivative_reg[11]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[11]_i_3_n_0 ,\derivative[11]_i_4_n_0 }));
  CARRY4 \derivative_reg[11]_i_10 
       (.CI(\derivative_reg[11]_i_15_n_0 ),
        .CO({\derivative_reg[11]_i_10_n_0 ,\derivative_reg[11]_i_10_n_1 ,\derivative_reg[11]_i_10_n_2 ,\derivative_reg[11]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[12]_i_10_n_5 ,\derivative_reg[12]_i_10_n_6 ,\derivative_reg[12]_i_10_n_7 ,\derivative_reg[12]_i_15_n_4 }),
        .O({\derivative_reg[11]_i_10_n_4 ,\derivative_reg[11]_i_10_n_5 ,\derivative_reg[11]_i_10_n_6 ,\derivative_reg[11]_i_10_n_7 }),
        .S({\derivative[11]_i_16_n_0 ,\derivative[11]_i_17_n_0 ,\derivative[11]_i_18_n_0 ,\derivative[11]_i_19_n_0 }));
  CARRY4 \derivative_reg[11]_i_15 
       (.CI(\derivative_reg[11]_i_20_n_0 ),
        .CO({\derivative_reg[11]_i_15_n_0 ,\derivative_reg[11]_i_15_n_1 ,\derivative_reg[11]_i_15_n_2 ,\derivative_reg[11]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[12]_i_15_n_5 ,\derivative_reg[12]_i_15_n_6 ,\derivative_reg[12]_i_15_n_7 ,\derivative_reg[12]_i_20_n_4 }),
        .O({\derivative_reg[11]_i_15_n_4 ,\derivative_reg[11]_i_15_n_5 ,\derivative_reg[11]_i_15_n_6 ,\derivative_reg[11]_i_15_n_7 }),
        .S({\derivative[11]_i_21_n_0 ,\derivative[11]_i_22_n_0 ,\derivative[11]_i_23_n_0 ,\derivative[11]_i_24_n_0 }));
  CARRY4 \derivative_reg[11]_i_2 
       (.CI(\derivative_reg[11]_i_5_n_0 ),
        .CO({\derivative_reg[11]_i_2_n_0 ,\derivative_reg[11]_i_2_n_1 ,\derivative_reg[11]_i_2_n_2 ,\derivative_reg[11]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[12]_i_2_n_5 ,\derivative_reg[12]_i_2_n_6 ,\derivative_reg[12]_i_2_n_7 ,\derivative_reg[12]_i_5_n_4 }),
        .O({\derivative_reg[11]_i_2_n_4 ,\derivative_reg[11]_i_2_n_5 ,\derivative_reg[11]_i_2_n_6 ,\derivative_reg[11]_i_2_n_7 }),
        .S({\derivative[11]_i_6_n_0 ,\derivative[11]_i_7_n_0 ,\derivative[11]_i_8_n_0 ,\derivative[11]_i_9_n_0 }));
  CARRY4 \derivative_reg[11]_i_20 
       (.CI(\derivative_reg[11]_i_25_n_0 ),
        .CO({\derivative_reg[11]_i_20_n_0 ,\derivative_reg[11]_i_20_n_1 ,\derivative_reg[11]_i_20_n_2 ,\derivative_reg[11]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[12]_i_20_n_5 ,\derivative_reg[12]_i_20_n_6 ,\derivative_reg[12]_i_20_n_7 ,\derivative_reg[12]_i_25_n_4 }),
        .O({\derivative_reg[11]_i_20_n_4 ,\derivative_reg[11]_i_20_n_5 ,\derivative_reg[11]_i_20_n_6 ,\derivative_reg[11]_i_20_n_7 }),
        .S({\derivative[11]_i_26_n_0 ,\derivative[11]_i_27_n_0 ,\derivative[11]_i_28_n_0 ,\derivative[11]_i_29_n_0 }));
  CARRY4 \derivative_reg[11]_i_25 
       (.CI(\derivative_reg[11]_i_30_n_0 ),
        .CO({\derivative_reg[11]_i_25_n_0 ,\derivative_reg[11]_i_25_n_1 ,\derivative_reg[11]_i_25_n_2 ,\derivative_reg[11]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[12]_i_25_n_5 ,\derivative_reg[12]_i_25_n_6 ,\derivative_reg[12]_i_25_n_7 ,\derivative_reg[12]_i_30_n_4 }),
        .O({\derivative_reg[11]_i_25_n_4 ,\derivative_reg[11]_i_25_n_5 ,\derivative_reg[11]_i_25_n_6 ,\derivative_reg[11]_i_25_n_7 }),
        .S({\derivative[11]_i_31_n_0 ,\derivative[11]_i_32_n_0 ,\derivative[11]_i_33_n_0 ,\derivative[11]_i_34_n_0 }));
  CARRY4 \derivative_reg[11]_i_30 
       (.CI(\derivative_reg[11]_i_35_n_0 ),
        .CO({\derivative_reg[11]_i_30_n_0 ,\derivative_reg[11]_i_30_n_1 ,\derivative_reg[11]_i_30_n_2 ,\derivative_reg[11]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[12]_i_30_n_5 ,\derivative_reg[12]_i_30_n_6 ,\derivative_reg[12]_i_30_n_7 ,\derivative_reg[12]_i_35_n_4 }),
        .O({\derivative_reg[11]_i_30_n_4 ,\derivative_reg[11]_i_30_n_5 ,\derivative_reg[11]_i_30_n_6 ,\derivative_reg[11]_i_30_n_7 }),
        .S({\derivative[11]_i_36_n_0 ,\derivative[11]_i_37_n_0 ,\derivative[11]_i_38_n_0 ,\derivative[11]_i_39_n_0 }));
  CARRY4 \derivative_reg[11]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[11]_i_35_n_0 ,\derivative_reg[11]_i_35_n_1 ,\derivative_reg[11]_i_35_n_2 ,\derivative_reg[11]_i_35_n_3 }),
        .CYINIT(\derivative_reg[12]_i_1_n_2 ),
        .DI({\derivative_reg[12]_i_35_n_5 ,\derivative_reg[12]_i_35_n_6 ,derivative11_out[11],1'b0}),
        .O({\derivative_reg[11]_i_35_n_4 ,\derivative_reg[11]_i_35_n_5 ,\derivative_reg[11]_i_35_n_6 ,\NLW_derivative_reg[11]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[11]_i_40_n_0 ,\derivative[11]_i_41_n_0 ,\derivative[11]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[11]_i_5 
       (.CI(\derivative_reg[11]_i_10_n_0 ),
        .CO({\derivative_reg[11]_i_5_n_0 ,\derivative_reg[11]_i_5_n_1 ,\derivative_reg[11]_i_5_n_2 ,\derivative_reg[11]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[12]_i_5_n_5 ,\derivative_reg[12]_i_5_n_6 ,\derivative_reg[12]_i_5_n_7 ,\derivative_reg[12]_i_10_n_4 }),
        .O({\derivative_reg[11]_i_5_n_4 ,\derivative_reg[11]_i_5_n_5 ,\derivative_reg[11]_i_5_n_6 ,\derivative_reg[11]_i_5_n_7 }),
        .S({\derivative[11]_i_11_n_0 ,\derivative[11]_i_12_n_0 ,\derivative[11]_i_13_n_0 ,\derivative[11]_i_14_n_0 }));
  FDRE \derivative_reg[12] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[12]_i_1_n_2 ),
        .Q(derivative_out[12]),
        .R(1'b0));
  CARRY4 \derivative_reg[12]_i_1 
       (.CI(\derivative_reg[12]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[12]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[12]_i_1_n_2 ,\derivative_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[13]_i_1_n_2 ,\derivative_reg[13]_i_2_n_4 }),
        .O({\NLW_derivative_reg[12]_i_1_O_UNCONNECTED [3:1],\derivative_reg[12]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[12]_i_3_n_0 ,\derivative[12]_i_4_n_0 }));
  CARRY4 \derivative_reg[12]_i_10 
       (.CI(\derivative_reg[12]_i_15_n_0 ),
        .CO({\derivative_reg[12]_i_10_n_0 ,\derivative_reg[12]_i_10_n_1 ,\derivative_reg[12]_i_10_n_2 ,\derivative_reg[12]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[13]_i_10_n_5 ,\derivative_reg[13]_i_10_n_6 ,\derivative_reg[13]_i_10_n_7 ,\derivative_reg[13]_i_15_n_4 }),
        .O({\derivative_reg[12]_i_10_n_4 ,\derivative_reg[12]_i_10_n_5 ,\derivative_reg[12]_i_10_n_6 ,\derivative_reg[12]_i_10_n_7 }),
        .S({\derivative[12]_i_16_n_0 ,\derivative[12]_i_17_n_0 ,\derivative[12]_i_18_n_0 ,\derivative[12]_i_19_n_0 }));
  CARRY4 \derivative_reg[12]_i_15 
       (.CI(\derivative_reg[12]_i_20_n_0 ),
        .CO({\derivative_reg[12]_i_15_n_0 ,\derivative_reg[12]_i_15_n_1 ,\derivative_reg[12]_i_15_n_2 ,\derivative_reg[12]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[13]_i_15_n_5 ,\derivative_reg[13]_i_15_n_6 ,\derivative_reg[13]_i_15_n_7 ,\derivative_reg[13]_i_20_n_4 }),
        .O({\derivative_reg[12]_i_15_n_4 ,\derivative_reg[12]_i_15_n_5 ,\derivative_reg[12]_i_15_n_6 ,\derivative_reg[12]_i_15_n_7 }),
        .S({\derivative[12]_i_21_n_0 ,\derivative[12]_i_22_n_0 ,\derivative[12]_i_23_n_0 ,\derivative[12]_i_24_n_0 }));
  CARRY4 \derivative_reg[12]_i_2 
       (.CI(\derivative_reg[12]_i_5_n_0 ),
        .CO({\derivative_reg[12]_i_2_n_0 ,\derivative_reg[12]_i_2_n_1 ,\derivative_reg[12]_i_2_n_2 ,\derivative_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[13]_i_2_n_5 ,\derivative_reg[13]_i_2_n_6 ,\derivative_reg[13]_i_2_n_7 ,\derivative_reg[13]_i_5_n_4 }),
        .O({\derivative_reg[12]_i_2_n_4 ,\derivative_reg[12]_i_2_n_5 ,\derivative_reg[12]_i_2_n_6 ,\derivative_reg[12]_i_2_n_7 }),
        .S({\derivative[12]_i_6_n_0 ,\derivative[12]_i_7_n_0 ,\derivative[12]_i_8_n_0 ,\derivative[12]_i_9_n_0 }));
  CARRY4 \derivative_reg[12]_i_20 
       (.CI(\derivative_reg[12]_i_25_n_0 ),
        .CO({\derivative_reg[12]_i_20_n_0 ,\derivative_reg[12]_i_20_n_1 ,\derivative_reg[12]_i_20_n_2 ,\derivative_reg[12]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[13]_i_20_n_5 ,\derivative_reg[13]_i_20_n_6 ,\derivative_reg[13]_i_20_n_7 ,\derivative_reg[13]_i_25_n_4 }),
        .O({\derivative_reg[12]_i_20_n_4 ,\derivative_reg[12]_i_20_n_5 ,\derivative_reg[12]_i_20_n_6 ,\derivative_reg[12]_i_20_n_7 }),
        .S({\derivative[12]_i_26_n_0 ,\derivative[12]_i_27_n_0 ,\derivative[12]_i_28_n_0 ,\derivative[12]_i_29_n_0 }));
  CARRY4 \derivative_reg[12]_i_25 
       (.CI(\derivative_reg[12]_i_30_n_0 ),
        .CO({\derivative_reg[12]_i_25_n_0 ,\derivative_reg[12]_i_25_n_1 ,\derivative_reg[12]_i_25_n_2 ,\derivative_reg[12]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[13]_i_25_n_5 ,\derivative_reg[13]_i_25_n_6 ,\derivative_reg[13]_i_25_n_7 ,\derivative_reg[13]_i_30_n_4 }),
        .O({\derivative_reg[12]_i_25_n_4 ,\derivative_reg[12]_i_25_n_5 ,\derivative_reg[12]_i_25_n_6 ,\derivative_reg[12]_i_25_n_7 }),
        .S({\derivative[12]_i_31_n_0 ,\derivative[12]_i_32_n_0 ,\derivative[12]_i_33_n_0 ,\derivative[12]_i_34_n_0 }));
  CARRY4 \derivative_reg[12]_i_30 
       (.CI(\derivative_reg[12]_i_35_n_0 ),
        .CO({\derivative_reg[12]_i_30_n_0 ,\derivative_reg[12]_i_30_n_1 ,\derivative_reg[12]_i_30_n_2 ,\derivative_reg[12]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[13]_i_30_n_5 ,\derivative_reg[13]_i_30_n_6 ,\derivative_reg[13]_i_30_n_7 ,\derivative_reg[13]_i_35_n_4 }),
        .O({\derivative_reg[12]_i_30_n_4 ,\derivative_reg[12]_i_30_n_5 ,\derivative_reg[12]_i_30_n_6 ,\derivative_reg[12]_i_30_n_7 }),
        .S({\derivative[12]_i_36_n_0 ,\derivative[12]_i_37_n_0 ,\derivative[12]_i_38_n_0 ,\derivative[12]_i_39_n_0 }));
  CARRY4 \derivative_reg[12]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[12]_i_35_n_0 ,\derivative_reg[12]_i_35_n_1 ,\derivative_reg[12]_i_35_n_2 ,\derivative_reg[12]_i_35_n_3 }),
        .CYINIT(\derivative_reg[13]_i_1_n_2 ),
        .DI({\derivative_reg[13]_i_35_n_5 ,\derivative_reg[13]_i_35_n_6 ,derivative11_out[12],1'b0}),
        .O({\derivative_reg[12]_i_35_n_4 ,\derivative_reg[12]_i_35_n_5 ,\derivative_reg[12]_i_35_n_6 ,\NLW_derivative_reg[12]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[12]_i_40_n_0 ,\derivative[12]_i_41_n_0 ,\derivative[12]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[12]_i_5 
       (.CI(\derivative_reg[12]_i_10_n_0 ),
        .CO({\derivative_reg[12]_i_5_n_0 ,\derivative_reg[12]_i_5_n_1 ,\derivative_reg[12]_i_5_n_2 ,\derivative_reg[12]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[13]_i_5_n_5 ,\derivative_reg[13]_i_5_n_6 ,\derivative_reg[13]_i_5_n_7 ,\derivative_reg[13]_i_10_n_4 }),
        .O({\derivative_reg[12]_i_5_n_4 ,\derivative_reg[12]_i_5_n_5 ,\derivative_reg[12]_i_5_n_6 ,\derivative_reg[12]_i_5_n_7 }),
        .S({\derivative[12]_i_11_n_0 ,\derivative[12]_i_12_n_0 ,\derivative[12]_i_13_n_0 ,\derivative[12]_i_14_n_0 }));
  FDRE \derivative_reg[13] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[13]_i_1_n_2 ),
        .Q(derivative_out[13]),
        .R(1'b0));
  CARRY4 \derivative_reg[13]_i_1 
       (.CI(\derivative_reg[13]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[13]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[13]_i_1_n_2 ,\derivative_reg[13]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[14]_i_1_n_2 ,\derivative_reg[14]_i_2_n_4 }),
        .O({\NLW_derivative_reg[13]_i_1_O_UNCONNECTED [3:1],\derivative_reg[13]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[13]_i_3_n_0 ,\derivative[13]_i_4_n_0 }));
  CARRY4 \derivative_reg[13]_i_10 
       (.CI(\derivative_reg[13]_i_15_n_0 ),
        .CO({\derivative_reg[13]_i_10_n_0 ,\derivative_reg[13]_i_10_n_1 ,\derivative_reg[13]_i_10_n_2 ,\derivative_reg[13]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[14]_i_10_n_5 ,\derivative_reg[14]_i_10_n_6 ,\derivative_reg[14]_i_10_n_7 ,\derivative_reg[14]_i_15_n_4 }),
        .O({\derivative_reg[13]_i_10_n_4 ,\derivative_reg[13]_i_10_n_5 ,\derivative_reg[13]_i_10_n_6 ,\derivative_reg[13]_i_10_n_7 }),
        .S({\derivative[13]_i_16_n_0 ,\derivative[13]_i_17_n_0 ,\derivative[13]_i_18_n_0 ,\derivative[13]_i_19_n_0 }));
  CARRY4 \derivative_reg[13]_i_15 
       (.CI(\derivative_reg[13]_i_20_n_0 ),
        .CO({\derivative_reg[13]_i_15_n_0 ,\derivative_reg[13]_i_15_n_1 ,\derivative_reg[13]_i_15_n_2 ,\derivative_reg[13]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[14]_i_15_n_5 ,\derivative_reg[14]_i_15_n_6 ,\derivative_reg[14]_i_15_n_7 ,\derivative_reg[14]_i_20_n_4 }),
        .O({\derivative_reg[13]_i_15_n_4 ,\derivative_reg[13]_i_15_n_5 ,\derivative_reg[13]_i_15_n_6 ,\derivative_reg[13]_i_15_n_7 }),
        .S({\derivative[13]_i_21_n_0 ,\derivative[13]_i_22_n_0 ,\derivative[13]_i_23_n_0 ,\derivative[13]_i_24_n_0 }));
  CARRY4 \derivative_reg[13]_i_2 
       (.CI(\derivative_reg[13]_i_5_n_0 ),
        .CO({\derivative_reg[13]_i_2_n_0 ,\derivative_reg[13]_i_2_n_1 ,\derivative_reg[13]_i_2_n_2 ,\derivative_reg[13]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[14]_i_2_n_5 ,\derivative_reg[14]_i_2_n_6 ,\derivative_reg[14]_i_2_n_7 ,\derivative_reg[14]_i_5_n_4 }),
        .O({\derivative_reg[13]_i_2_n_4 ,\derivative_reg[13]_i_2_n_5 ,\derivative_reg[13]_i_2_n_6 ,\derivative_reg[13]_i_2_n_7 }),
        .S({\derivative[13]_i_6_n_0 ,\derivative[13]_i_7_n_0 ,\derivative[13]_i_8_n_0 ,\derivative[13]_i_9_n_0 }));
  CARRY4 \derivative_reg[13]_i_20 
       (.CI(\derivative_reg[13]_i_25_n_0 ),
        .CO({\derivative_reg[13]_i_20_n_0 ,\derivative_reg[13]_i_20_n_1 ,\derivative_reg[13]_i_20_n_2 ,\derivative_reg[13]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[14]_i_20_n_5 ,\derivative_reg[14]_i_20_n_6 ,\derivative_reg[14]_i_20_n_7 ,\derivative_reg[14]_i_25_n_4 }),
        .O({\derivative_reg[13]_i_20_n_4 ,\derivative_reg[13]_i_20_n_5 ,\derivative_reg[13]_i_20_n_6 ,\derivative_reg[13]_i_20_n_7 }),
        .S({\derivative[13]_i_26_n_0 ,\derivative[13]_i_27_n_0 ,\derivative[13]_i_28_n_0 ,\derivative[13]_i_29_n_0 }));
  CARRY4 \derivative_reg[13]_i_25 
       (.CI(\derivative_reg[13]_i_30_n_0 ),
        .CO({\derivative_reg[13]_i_25_n_0 ,\derivative_reg[13]_i_25_n_1 ,\derivative_reg[13]_i_25_n_2 ,\derivative_reg[13]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[14]_i_25_n_5 ,\derivative_reg[14]_i_25_n_6 ,\derivative_reg[14]_i_25_n_7 ,\derivative_reg[14]_i_30_n_4 }),
        .O({\derivative_reg[13]_i_25_n_4 ,\derivative_reg[13]_i_25_n_5 ,\derivative_reg[13]_i_25_n_6 ,\derivative_reg[13]_i_25_n_7 }),
        .S({\derivative[13]_i_31_n_0 ,\derivative[13]_i_32_n_0 ,\derivative[13]_i_33_n_0 ,\derivative[13]_i_34_n_0 }));
  CARRY4 \derivative_reg[13]_i_30 
       (.CI(\derivative_reg[13]_i_35_n_0 ),
        .CO({\derivative_reg[13]_i_30_n_0 ,\derivative_reg[13]_i_30_n_1 ,\derivative_reg[13]_i_30_n_2 ,\derivative_reg[13]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[14]_i_30_n_5 ,\derivative_reg[14]_i_30_n_6 ,\derivative_reg[14]_i_30_n_7 ,\derivative_reg[14]_i_35_n_4 }),
        .O({\derivative_reg[13]_i_30_n_4 ,\derivative_reg[13]_i_30_n_5 ,\derivative_reg[13]_i_30_n_6 ,\derivative_reg[13]_i_30_n_7 }),
        .S({\derivative[13]_i_36_n_0 ,\derivative[13]_i_37_n_0 ,\derivative[13]_i_38_n_0 ,\derivative[13]_i_39_n_0 }));
  CARRY4 \derivative_reg[13]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[13]_i_35_n_0 ,\derivative_reg[13]_i_35_n_1 ,\derivative_reg[13]_i_35_n_2 ,\derivative_reg[13]_i_35_n_3 }),
        .CYINIT(\derivative_reg[14]_i_1_n_2 ),
        .DI({\derivative_reg[14]_i_35_n_5 ,\derivative_reg[14]_i_35_n_6 ,derivative11_out[13],1'b0}),
        .O({\derivative_reg[13]_i_35_n_4 ,\derivative_reg[13]_i_35_n_5 ,\derivative_reg[13]_i_35_n_6 ,\NLW_derivative_reg[13]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[13]_i_40_n_0 ,\derivative[13]_i_41_n_0 ,\derivative[13]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[13]_i_5 
       (.CI(\derivative_reg[13]_i_10_n_0 ),
        .CO({\derivative_reg[13]_i_5_n_0 ,\derivative_reg[13]_i_5_n_1 ,\derivative_reg[13]_i_5_n_2 ,\derivative_reg[13]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[14]_i_5_n_5 ,\derivative_reg[14]_i_5_n_6 ,\derivative_reg[14]_i_5_n_7 ,\derivative_reg[14]_i_10_n_4 }),
        .O({\derivative_reg[13]_i_5_n_4 ,\derivative_reg[13]_i_5_n_5 ,\derivative_reg[13]_i_5_n_6 ,\derivative_reg[13]_i_5_n_7 }),
        .S({\derivative[13]_i_11_n_0 ,\derivative[13]_i_12_n_0 ,\derivative[13]_i_13_n_0 ,\derivative[13]_i_14_n_0 }));
  FDRE \derivative_reg[14] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[14]_i_1_n_2 ),
        .Q(derivative_out[14]),
        .R(1'b0));
  CARRY4 \derivative_reg[14]_i_1 
       (.CI(\derivative_reg[14]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[14]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[14]_i_1_n_2 ,\derivative_reg[14]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[15]_i_1_n_2 ,\derivative_reg[15]_i_2_n_4 }),
        .O({\NLW_derivative_reg[14]_i_1_O_UNCONNECTED [3:1],\derivative_reg[14]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[14]_i_3_n_0 ,\derivative[14]_i_4_n_0 }));
  CARRY4 \derivative_reg[14]_i_10 
       (.CI(\derivative_reg[14]_i_15_n_0 ),
        .CO({\derivative_reg[14]_i_10_n_0 ,\derivative_reg[14]_i_10_n_1 ,\derivative_reg[14]_i_10_n_2 ,\derivative_reg[14]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_10_n_5 ,\derivative_reg[15]_i_10_n_6 ,\derivative_reg[15]_i_10_n_7 ,\derivative_reg[15]_i_15_n_4 }),
        .O({\derivative_reg[14]_i_10_n_4 ,\derivative_reg[14]_i_10_n_5 ,\derivative_reg[14]_i_10_n_6 ,\derivative_reg[14]_i_10_n_7 }),
        .S({\derivative[14]_i_16_n_0 ,\derivative[14]_i_17_n_0 ,\derivative[14]_i_18_n_0 ,\derivative[14]_i_19_n_0 }));
  CARRY4 \derivative_reg[14]_i_15 
       (.CI(\derivative_reg[14]_i_20_n_0 ),
        .CO({\derivative_reg[14]_i_15_n_0 ,\derivative_reg[14]_i_15_n_1 ,\derivative_reg[14]_i_15_n_2 ,\derivative_reg[14]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_15_n_5 ,\derivative_reg[15]_i_15_n_6 ,\derivative_reg[15]_i_15_n_7 ,\derivative_reg[15]_i_20_n_4 }),
        .O({\derivative_reg[14]_i_15_n_4 ,\derivative_reg[14]_i_15_n_5 ,\derivative_reg[14]_i_15_n_6 ,\derivative_reg[14]_i_15_n_7 }),
        .S({\derivative[14]_i_21_n_0 ,\derivative[14]_i_22_n_0 ,\derivative[14]_i_23_n_0 ,\derivative[14]_i_24_n_0 }));
  CARRY4 \derivative_reg[14]_i_2 
       (.CI(\derivative_reg[14]_i_5_n_0 ),
        .CO({\derivative_reg[14]_i_2_n_0 ,\derivative_reg[14]_i_2_n_1 ,\derivative_reg[14]_i_2_n_2 ,\derivative_reg[14]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_2_n_5 ,\derivative_reg[15]_i_2_n_6 ,\derivative_reg[15]_i_2_n_7 ,\derivative_reg[15]_i_5_n_4 }),
        .O({\derivative_reg[14]_i_2_n_4 ,\derivative_reg[14]_i_2_n_5 ,\derivative_reg[14]_i_2_n_6 ,\derivative_reg[14]_i_2_n_7 }),
        .S({\derivative[14]_i_6_n_0 ,\derivative[14]_i_7_n_0 ,\derivative[14]_i_8_n_0 ,\derivative[14]_i_9_n_0 }));
  CARRY4 \derivative_reg[14]_i_20 
       (.CI(\derivative_reg[14]_i_25_n_0 ),
        .CO({\derivative_reg[14]_i_20_n_0 ,\derivative_reg[14]_i_20_n_1 ,\derivative_reg[14]_i_20_n_2 ,\derivative_reg[14]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_20_n_5 ,\derivative_reg[15]_i_20_n_6 ,\derivative_reg[15]_i_20_n_7 ,\derivative_reg[15]_i_25_n_4 }),
        .O({\derivative_reg[14]_i_20_n_4 ,\derivative_reg[14]_i_20_n_5 ,\derivative_reg[14]_i_20_n_6 ,\derivative_reg[14]_i_20_n_7 }),
        .S({\derivative[14]_i_26_n_0 ,\derivative[14]_i_27_n_0 ,\derivative[14]_i_28_n_0 ,\derivative[14]_i_29_n_0 }));
  CARRY4 \derivative_reg[14]_i_25 
       (.CI(\derivative_reg[14]_i_30_n_0 ),
        .CO({\derivative_reg[14]_i_25_n_0 ,\derivative_reg[14]_i_25_n_1 ,\derivative_reg[14]_i_25_n_2 ,\derivative_reg[14]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_25_n_5 ,\derivative_reg[15]_i_25_n_6 ,\derivative_reg[15]_i_25_n_7 ,\derivative_reg[15]_i_30_n_4 }),
        .O({\derivative_reg[14]_i_25_n_4 ,\derivative_reg[14]_i_25_n_5 ,\derivative_reg[14]_i_25_n_6 ,\derivative_reg[14]_i_25_n_7 }),
        .S({\derivative[14]_i_31_n_0 ,\derivative[14]_i_32_n_0 ,\derivative[14]_i_33_n_0 ,\derivative[14]_i_34_n_0 }));
  CARRY4 \derivative_reg[14]_i_30 
       (.CI(\derivative_reg[14]_i_35_n_0 ),
        .CO({\derivative_reg[14]_i_30_n_0 ,\derivative_reg[14]_i_30_n_1 ,\derivative_reg[14]_i_30_n_2 ,\derivative_reg[14]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_30_n_5 ,\derivative_reg[15]_i_30_n_6 ,\derivative_reg[15]_i_30_n_7 ,\derivative_reg[15]_i_35_n_4 }),
        .O({\derivative_reg[14]_i_30_n_4 ,\derivative_reg[14]_i_30_n_5 ,\derivative_reg[14]_i_30_n_6 ,\derivative_reg[14]_i_30_n_7 }),
        .S({\derivative[14]_i_36_n_0 ,\derivative[14]_i_37_n_0 ,\derivative[14]_i_38_n_0 ,\derivative[14]_i_39_n_0 }));
  CARRY4 \derivative_reg[14]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[14]_i_35_n_0 ,\derivative_reg[14]_i_35_n_1 ,\derivative_reg[14]_i_35_n_2 ,\derivative_reg[14]_i_35_n_3 }),
        .CYINIT(\derivative_reg[15]_i_1_n_2 ),
        .DI({\derivative_reg[15]_i_35_n_5 ,\derivative_reg[15]_i_35_n_6 ,derivative11_out[14],1'b0}),
        .O({\derivative_reg[14]_i_35_n_4 ,\derivative_reg[14]_i_35_n_5 ,\derivative_reg[14]_i_35_n_6 ,\NLW_derivative_reg[14]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[14]_i_40_n_0 ,\derivative[14]_i_41_n_0 ,\derivative[14]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[14]_i_5 
       (.CI(\derivative_reg[14]_i_10_n_0 ),
        .CO({\derivative_reg[14]_i_5_n_0 ,\derivative_reg[14]_i_5_n_1 ,\derivative_reg[14]_i_5_n_2 ,\derivative_reg[14]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_5_n_5 ,\derivative_reg[15]_i_5_n_6 ,\derivative_reg[15]_i_5_n_7 ,\derivative_reg[15]_i_10_n_4 }),
        .O({\derivative_reg[14]_i_5_n_4 ,\derivative_reg[14]_i_5_n_5 ,\derivative_reg[14]_i_5_n_6 ,\derivative_reg[14]_i_5_n_7 }),
        .S({\derivative[14]_i_11_n_0 ,\derivative[14]_i_12_n_0 ,\derivative[14]_i_13_n_0 ,\derivative[14]_i_14_n_0 }));
  FDRE \derivative_reg[15] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[15]_i_1_n_2 ),
        .Q(derivative_out[15]),
        .R(1'b0));
  CARRY4 \derivative_reg[15]_i_1 
       (.CI(\derivative_reg[15]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[15]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[15]_i_1_n_2 ,\derivative_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[16]_i_1_n_2 ,\derivative_reg[16]_i_2_n_4 }),
        .O({\NLW_derivative_reg[15]_i_1_O_UNCONNECTED [3:1],\derivative_reg[15]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[15]_i_3_n_0 ,\derivative[15]_i_4_n_0 }));
  CARRY4 \derivative_reg[15]_i_10 
       (.CI(\derivative_reg[15]_i_15_n_0 ),
        .CO({\derivative_reg[15]_i_10_n_0 ,\derivative_reg[15]_i_10_n_1 ,\derivative_reg[15]_i_10_n_2 ,\derivative_reg[15]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[16]_i_10_n_5 ,\derivative_reg[16]_i_10_n_6 ,\derivative_reg[16]_i_10_n_7 ,\derivative_reg[16]_i_15_n_4 }),
        .O({\derivative_reg[15]_i_10_n_4 ,\derivative_reg[15]_i_10_n_5 ,\derivative_reg[15]_i_10_n_6 ,\derivative_reg[15]_i_10_n_7 }),
        .S({\derivative[15]_i_16_n_0 ,\derivative[15]_i_17_n_0 ,\derivative[15]_i_18_n_0 ,\derivative[15]_i_19_n_0 }));
  CARRY4 \derivative_reg[15]_i_15 
       (.CI(\derivative_reg[15]_i_20_n_0 ),
        .CO({\derivative_reg[15]_i_15_n_0 ,\derivative_reg[15]_i_15_n_1 ,\derivative_reg[15]_i_15_n_2 ,\derivative_reg[15]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[16]_i_15_n_5 ,\derivative_reg[16]_i_15_n_6 ,\derivative_reg[16]_i_15_n_7 ,\derivative_reg[16]_i_20_n_4 }),
        .O({\derivative_reg[15]_i_15_n_4 ,\derivative_reg[15]_i_15_n_5 ,\derivative_reg[15]_i_15_n_6 ,\derivative_reg[15]_i_15_n_7 }),
        .S({\derivative[15]_i_21_n_0 ,\derivative[15]_i_22_n_0 ,\derivative[15]_i_23_n_0 ,\derivative[15]_i_24_n_0 }));
  CARRY4 \derivative_reg[15]_i_2 
       (.CI(\derivative_reg[15]_i_5_n_0 ),
        .CO({\derivative_reg[15]_i_2_n_0 ,\derivative_reg[15]_i_2_n_1 ,\derivative_reg[15]_i_2_n_2 ,\derivative_reg[15]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[16]_i_2_n_5 ,\derivative_reg[16]_i_2_n_6 ,\derivative_reg[16]_i_2_n_7 ,\derivative_reg[16]_i_5_n_4 }),
        .O({\derivative_reg[15]_i_2_n_4 ,\derivative_reg[15]_i_2_n_5 ,\derivative_reg[15]_i_2_n_6 ,\derivative_reg[15]_i_2_n_7 }),
        .S({\derivative[15]_i_6_n_0 ,\derivative[15]_i_7_n_0 ,\derivative[15]_i_8_n_0 ,\derivative[15]_i_9_n_0 }));
  CARRY4 \derivative_reg[15]_i_20 
       (.CI(\derivative_reg[15]_i_25_n_0 ),
        .CO({\derivative_reg[15]_i_20_n_0 ,\derivative_reg[15]_i_20_n_1 ,\derivative_reg[15]_i_20_n_2 ,\derivative_reg[15]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[16]_i_20_n_5 ,\derivative_reg[16]_i_20_n_6 ,\derivative_reg[16]_i_20_n_7 ,\derivative_reg[16]_i_25_n_4 }),
        .O({\derivative_reg[15]_i_20_n_4 ,\derivative_reg[15]_i_20_n_5 ,\derivative_reg[15]_i_20_n_6 ,\derivative_reg[15]_i_20_n_7 }),
        .S({\derivative[15]_i_26_n_0 ,\derivative[15]_i_27_n_0 ,\derivative[15]_i_28_n_0 ,\derivative[15]_i_29_n_0 }));
  CARRY4 \derivative_reg[15]_i_25 
       (.CI(\derivative_reg[15]_i_30_n_0 ),
        .CO({\derivative_reg[15]_i_25_n_0 ,\derivative_reg[15]_i_25_n_1 ,\derivative_reg[15]_i_25_n_2 ,\derivative_reg[15]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[16]_i_25_n_5 ,\derivative_reg[16]_i_25_n_6 ,\derivative_reg[16]_i_25_n_7 ,\derivative_reg[16]_i_30_n_4 }),
        .O({\derivative_reg[15]_i_25_n_4 ,\derivative_reg[15]_i_25_n_5 ,\derivative_reg[15]_i_25_n_6 ,\derivative_reg[15]_i_25_n_7 }),
        .S({\derivative[15]_i_31_n_0 ,\derivative[15]_i_32_n_0 ,\derivative[15]_i_33_n_0 ,\derivative[15]_i_34_n_0 }));
  CARRY4 \derivative_reg[15]_i_30 
       (.CI(\derivative_reg[15]_i_35_n_0 ),
        .CO({\derivative_reg[15]_i_30_n_0 ,\derivative_reg[15]_i_30_n_1 ,\derivative_reg[15]_i_30_n_2 ,\derivative_reg[15]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[16]_i_30_n_5 ,\derivative_reg[16]_i_30_n_6 ,\derivative_reg[16]_i_30_n_7 ,\derivative_reg[16]_i_35_n_4 }),
        .O({\derivative_reg[15]_i_30_n_4 ,\derivative_reg[15]_i_30_n_5 ,\derivative_reg[15]_i_30_n_6 ,\derivative_reg[15]_i_30_n_7 }),
        .S({\derivative[15]_i_36_n_0 ,\derivative[15]_i_37_n_0 ,\derivative[15]_i_38_n_0 ,\derivative[15]_i_39_n_0 }));
  CARRY4 \derivative_reg[15]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[15]_i_35_n_0 ,\derivative_reg[15]_i_35_n_1 ,\derivative_reg[15]_i_35_n_2 ,\derivative_reg[15]_i_35_n_3 }),
        .CYINIT(\derivative_reg[16]_i_1_n_2 ),
        .DI({\derivative_reg[16]_i_35_n_5 ,\derivative_reg[16]_i_35_n_6 ,derivative11_out[15],1'b0}),
        .O({\derivative_reg[15]_i_35_n_4 ,\derivative_reg[15]_i_35_n_5 ,\derivative_reg[15]_i_35_n_6 ,\NLW_derivative_reg[15]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[15]_i_40_n_0 ,\derivative[15]_i_41_n_0 ,\derivative[15]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[15]_i_5 
       (.CI(\derivative_reg[15]_i_10_n_0 ),
        .CO({\derivative_reg[15]_i_5_n_0 ,\derivative_reg[15]_i_5_n_1 ,\derivative_reg[15]_i_5_n_2 ,\derivative_reg[15]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[16]_i_5_n_5 ,\derivative_reg[16]_i_5_n_6 ,\derivative_reg[16]_i_5_n_7 ,\derivative_reg[16]_i_10_n_4 }),
        .O({\derivative_reg[15]_i_5_n_4 ,\derivative_reg[15]_i_5_n_5 ,\derivative_reg[15]_i_5_n_6 ,\derivative_reg[15]_i_5_n_7 }),
        .S({\derivative[15]_i_11_n_0 ,\derivative[15]_i_12_n_0 ,\derivative[15]_i_13_n_0 ,\derivative[15]_i_14_n_0 }));
  FDRE \derivative_reg[16] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[16]_i_1_n_2 ),
        .Q(derivative_out[16]),
        .R(1'b0));
  CARRY4 \derivative_reg[16]_i_1 
       (.CI(\derivative_reg[16]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[16]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[16]_i_1_n_2 ,\derivative_reg[16]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[17]_i_1_n_2 ,\derivative_reg[17]_i_2_n_4 }),
        .O({\NLW_derivative_reg[16]_i_1_O_UNCONNECTED [3:1],\derivative_reg[16]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[16]_i_3_n_0 ,\derivative[16]_i_4_n_0 }));
  CARRY4 \derivative_reg[16]_i_10 
       (.CI(\derivative_reg[16]_i_15_n_0 ),
        .CO({\derivative_reg[16]_i_10_n_0 ,\derivative_reg[16]_i_10_n_1 ,\derivative_reg[16]_i_10_n_2 ,\derivative_reg[16]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[17]_i_10_n_5 ,\derivative_reg[17]_i_10_n_6 ,\derivative_reg[17]_i_10_n_7 ,\derivative_reg[17]_i_15_n_4 }),
        .O({\derivative_reg[16]_i_10_n_4 ,\derivative_reg[16]_i_10_n_5 ,\derivative_reg[16]_i_10_n_6 ,\derivative_reg[16]_i_10_n_7 }),
        .S({\derivative[16]_i_16_n_0 ,\derivative[16]_i_17_n_0 ,\derivative[16]_i_18_n_0 ,\derivative[16]_i_19_n_0 }));
  CARRY4 \derivative_reg[16]_i_15 
       (.CI(\derivative_reg[16]_i_20_n_0 ),
        .CO({\derivative_reg[16]_i_15_n_0 ,\derivative_reg[16]_i_15_n_1 ,\derivative_reg[16]_i_15_n_2 ,\derivative_reg[16]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[17]_i_15_n_5 ,\derivative_reg[17]_i_15_n_6 ,\derivative_reg[17]_i_15_n_7 ,\derivative_reg[17]_i_20_n_4 }),
        .O({\derivative_reg[16]_i_15_n_4 ,\derivative_reg[16]_i_15_n_5 ,\derivative_reg[16]_i_15_n_6 ,\derivative_reg[16]_i_15_n_7 }),
        .S({\derivative[16]_i_21_n_0 ,\derivative[16]_i_22_n_0 ,\derivative[16]_i_23_n_0 ,\derivative[16]_i_24_n_0 }));
  CARRY4 \derivative_reg[16]_i_2 
       (.CI(\derivative_reg[16]_i_5_n_0 ),
        .CO({\derivative_reg[16]_i_2_n_0 ,\derivative_reg[16]_i_2_n_1 ,\derivative_reg[16]_i_2_n_2 ,\derivative_reg[16]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[17]_i_2_n_5 ,\derivative_reg[17]_i_2_n_6 ,\derivative_reg[17]_i_2_n_7 ,\derivative_reg[17]_i_5_n_4 }),
        .O({\derivative_reg[16]_i_2_n_4 ,\derivative_reg[16]_i_2_n_5 ,\derivative_reg[16]_i_2_n_6 ,\derivative_reg[16]_i_2_n_7 }),
        .S({\derivative[16]_i_6_n_0 ,\derivative[16]_i_7_n_0 ,\derivative[16]_i_8_n_0 ,\derivative[16]_i_9_n_0 }));
  CARRY4 \derivative_reg[16]_i_20 
       (.CI(\derivative_reg[16]_i_25_n_0 ),
        .CO({\derivative_reg[16]_i_20_n_0 ,\derivative_reg[16]_i_20_n_1 ,\derivative_reg[16]_i_20_n_2 ,\derivative_reg[16]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[17]_i_20_n_5 ,\derivative_reg[17]_i_20_n_6 ,\derivative_reg[17]_i_20_n_7 ,\derivative_reg[17]_i_25_n_4 }),
        .O({\derivative_reg[16]_i_20_n_4 ,\derivative_reg[16]_i_20_n_5 ,\derivative_reg[16]_i_20_n_6 ,\derivative_reg[16]_i_20_n_7 }),
        .S({\derivative[16]_i_26_n_0 ,\derivative[16]_i_27_n_0 ,\derivative[16]_i_28_n_0 ,\derivative[16]_i_29_n_0 }));
  CARRY4 \derivative_reg[16]_i_25 
       (.CI(\derivative_reg[16]_i_30_n_0 ),
        .CO({\derivative_reg[16]_i_25_n_0 ,\derivative_reg[16]_i_25_n_1 ,\derivative_reg[16]_i_25_n_2 ,\derivative_reg[16]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[17]_i_25_n_5 ,\derivative_reg[17]_i_25_n_6 ,\derivative_reg[17]_i_25_n_7 ,\derivative_reg[17]_i_30_n_4 }),
        .O({\derivative_reg[16]_i_25_n_4 ,\derivative_reg[16]_i_25_n_5 ,\derivative_reg[16]_i_25_n_6 ,\derivative_reg[16]_i_25_n_7 }),
        .S({\derivative[16]_i_31_n_0 ,\derivative[16]_i_32_n_0 ,\derivative[16]_i_33_n_0 ,\derivative[16]_i_34_n_0 }));
  CARRY4 \derivative_reg[16]_i_30 
       (.CI(\derivative_reg[16]_i_35_n_0 ),
        .CO({\derivative_reg[16]_i_30_n_0 ,\derivative_reg[16]_i_30_n_1 ,\derivative_reg[16]_i_30_n_2 ,\derivative_reg[16]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[17]_i_30_n_5 ,\derivative_reg[17]_i_30_n_6 ,\derivative_reg[17]_i_30_n_7 ,\derivative_reg[17]_i_35_n_4 }),
        .O({\derivative_reg[16]_i_30_n_4 ,\derivative_reg[16]_i_30_n_5 ,\derivative_reg[16]_i_30_n_6 ,\derivative_reg[16]_i_30_n_7 }),
        .S({\derivative[16]_i_36_n_0 ,\derivative[16]_i_37_n_0 ,\derivative[16]_i_38_n_0 ,\derivative[16]_i_39_n_0 }));
  CARRY4 \derivative_reg[16]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[16]_i_35_n_0 ,\derivative_reg[16]_i_35_n_1 ,\derivative_reg[16]_i_35_n_2 ,\derivative_reg[16]_i_35_n_3 }),
        .CYINIT(\derivative_reg[17]_i_1_n_2 ),
        .DI({\derivative_reg[17]_i_35_n_5 ,\derivative_reg[17]_i_35_n_6 ,derivative11_out[16],1'b0}),
        .O({\derivative_reg[16]_i_35_n_4 ,\derivative_reg[16]_i_35_n_5 ,\derivative_reg[16]_i_35_n_6 ,\NLW_derivative_reg[16]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[16]_i_40_n_0 ,\derivative[16]_i_41_n_0 ,\derivative[16]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[16]_i_5 
       (.CI(\derivative_reg[16]_i_10_n_0 ),
        .CO({\derivative_reg[16]_i_5_n_0 ,\derivative_reg[16]_i_5_n_1 ,\derivative_reg[16]_i_5_n_2 ,\derivative_reg[16]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[17]_i_5_n_5 ,\derivative_reg[17]_i_5_n_6 ,\derivative_reg[17]_i_5_n_7 ,\derivative_reg[17]_i_10_n_4 }),
        .O({\derivative_reg[16]_i_5_n_4 ,\derivative_reg[16]_i_5_n_5 ,\derivative_reg[16]_i_5_n_6 ,\derivative_reg[16]_i_5_n_7 }),
        .S({\derivative[16]_i_11_n_0 ,\derivative[16]_i_12_n_0 ,\derivative[16]_i_13_n_0 ,\derivative[16]_i_14_n_0 }));
  FDRE \derivative_reg[17] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[17]_i_1_n_2 ),
        .Q(derivative_out[17]),
        .R(1'b0));
  CARRY4 \derivative_reg[17]_i_1 
       (.CI(\derivative_reg[17]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[17]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[17]_i_1_n_2 ,\derivative_reg[17]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[18]_i_1_n_2 ,\derivative_reg[18]_i_2_n_4 }),
        .O({\NLW_derivative_reg[17]_i_1_O_UNCONNECTED [3:1],\derivative_reg[17]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[17]_i_3_n_0 ,\derivative[17]_i_4_n_0 }));
  CARRY4 \derivative_reg[17]_i_10 
       (.CI(\derivative_reg[17]_i_15_n_0 ),
        .CO({\derivative_reg[17]_i_10_n_0 ,\derivative_reg[17]_i_10_n_1 ,\derivative_reg[17]_i_10_n_2 ,\derivative_reg[17]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[18]_i_10_n_5 ,\derivative_reg[18]_i_10_n_6 ,\derivative_reg[18]_i_10_n_7 ,\derivative_reg[18]_i_15_n_4 }),
        .O({\derivative_reg[17]_i_10_n_4 ,\derivative_reg[17]_i_10_n_5 ,\derivative_reg[17]_i_10_n_6 ,\derivative_reg[17]_i_10_n_7 }),
        .S({\derivative[17]_i_16_n_0 ,\derivative[17]_i_17_n_0 ,\derivative[17]_i_18_n_0 ,\derivative[17]_i_19_n_0 }));
  CARRY4 \derivative_reg[17]_i_15 
       (.CI(\derivative_reg[17]_i_20_n_0 ),
        .CO({\derivative_reg[17]_i_15_n_0 ,\derivative_reg[17]_i_15_n_1 ,\derivative_reg[17]_i_15_n_2 ,\derivative_reg[17]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[18]_i_15_n_5 ,\derivative_reg[18]_i_15_n_6 ,\derivative_reg[18]_i_15_n_7 ,\derivative_reg[18]_i_20_n_4 }),
        .O({\derivative_reg[17]_i_15_n_4 ,\derivative_reg[17]_i_15_n_5 ,\derivative_reg[17]_i_15_n_6 ,\derivative_reg[17]_i_15_n_7 }),
        .S({\derivative[17]_i_21_n_0 ,\derivative[17]_i_22_n_0 ,\derivative[17]_i_23_n_0 ,\derivative[17]_i_24_n_0 }));
  CARRY4 \derivative_reg[17]_i_2 
       (.CI(\derivative_reg[17]_i_5_n_0 ),
        .CO({\derivative_reg[17]_i_2_n_0 ,\derivative_reg[17]_i_2_n_1 ,\derivative_reg[17]_i_2_n_2 ,\derivative_reg[17]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[18]_i_2_n_5 ,\derivative_reg[18]_i_2_n_6 ,\derivative_reg[18]_i_2_n_7 ,\derivative_reg[18]_i_5_n_4 }),
        .O({\derivative_reg[17]_i_2_n_4 ,\derivative_reg[17]_i_2_n_5 ,\derivative_reg[17]_i_2_n_6 ,\derivative_reg[17]_i_2_n_7 }),
        .S({\derivative[17]_i_6_n_0 ,\derivative[17]_i_7_n_0 ,\derivative[17]_i_8_n_0 ,\derivative[17]_i_9_n_0 }));
  CARRY4 \derivative_reg[17]_i_20 
       (.CI(\derivative_reg[17]_i_25_n_0 ),
        .CO({\derivative_reg[17]_i_20_n_0 ,\derivative_reg[17]_i_20_n_1 ,\derivative_reg[17]_i_20_n_2 ,\derivative_reg[17]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[18]_i_20_n_5 ,\derivative_reg[18]_i_20_n_6 ,\derivative_reg[18]_i_20_n_7 ,\derivative_reg[18]_i_25_n_4 }),
        .O({\derivative_reg[17]_i_20_n_4 ,\derivative_reg[17]_i_20_n_5 ,\derivative_reg[17]_i_20_n_6 ,\derivative_reg[17]_i_20_n_7 }),
        .S({\derivative[17]_i_26_n_0 ,\derivative[17]_i_27_n_0 ,\derivative[17]_i_28_n_0 ,\derivative[17]_i_29_n_0 }));
  CARRY4 \derivative_reg[17]_i_25 
       (.CI(\derivative_reg[17]_i_30_n_0 ),
        .CO({\derivative_reg[17]_i_25_n_0 ,\derivative_reg[17]_i_25_n_1 ,\derivative_reg[17]_i_25_n_2 ,\derivative_reg[17]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[18]_i_25_n_5 ,\derivative_reg[18]_i_25_n_6 ,\derivative_reg[18]_i_25_n_7 ,\derivative_reg[18]_i_30_n_4 }),
        .O({\derivative_reg[17]_i_25_n_4 ,\derivative_reg[17]_i_25_n_5 ,\derivative_reg[17]_i_25_n_6 ,\derivative_reg[17]_i_25_n_7 }),
        .S({\derivative[17]_i_31_n_0 ,\derivative[17]_i_32_n_0 ,\derivative[17]_i_33_n_0 ,\derivative[17]_i_34_n_0 }));
  CARRY4 \derivative_reg[17]_i_30 
       (.CI(\derivative_reg[17]_i_35_n_0 ),
        .CO({\derivative_reg[17]_i_30_n_0 ,\derivative_reg[17]_i_30_n_1 ,\derivative_reg[17]_i_30_n_2 ,\derivative_reg[17]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[18]_i_30_n_5 ,\derivative_reg[18]_i_30_n_6 ,\derivative_reg[18]_i_30_n_7 ,\derivative_reg[18]_i_35_n_4 }),
        .O({\derivative_reg[17]_i_30_n_4 ,\derivative_reg[17]_i_30_n_5 ,\derivative_reg[17]_i_30_n_6 ,\derivative_reg[17]_i_30_n_7 }),
        .S({\derivative[17]_i_36_n_0 ,\derivative[17]_i_37_n_0 ,\derivative[17]_i_38_n_0 ,\derivative[17]_i_39_n_0 }));
  CARRY4 \derivative_reg[17]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[17]_i_35_n_0 ,\derivative_reg[17]_i_35_n_1 ,\derivative_reg[17]_i_35_n_2 ,\derivative_reg[17]_i_35_n_3 }),
        .CYINIT(\derivative_reg[18]_i_1_n_2 ),
        .DI({\derivative_reg[18]_i_35_n_5 ,\derivative_reg[18]_i_35_n_6 ,derivative11_out[17],1'b0}),
        .O({\derivative_reg[17]_i_35_n_4 ,\derivative_reg[17]_i_35_n_5 ,\derivative_reg[17]_i_35_n_6 ,\NLW_derivative_reg[17]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[17]_i_40_n_0 ,\derivative[17]_i_41_n_0 ,\derivative[17]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[17]_i_5 
       (.CI(\derivative_reg[17]_i_10_n_0 ),
        .CO({\derivative_reg[17]_i_5_n_0 ,\derivative_reg[17]_i_5_n_1 ,\derivative_reg[17]_i_5_n_2 ,\derivative_reg[17]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[18]_i_5_n_5 ,\derivative_reg[18]_i_5_n_6 ,\derivative_reg[18]_i_5_n_7 ,\derivative_reg[18]_i_10_n_4 }),
        .O({\derivative_reg[17]_i_5_n_4 ,\derivative_reg[17]_i_5_n_5 ,\derivative_reg[17]_i_5_n_6 ,\derivative_reg[17]_i_5_n_7 }),
        .S({\derivative[17]_i_11_n_0 ,\derivative[17]_i_12_n_0 ,\derivative[17]_i_13_n_0 ,\derivative[17]_i_14_n_0 }));
  FDRE \derivative_reg[18] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[18]_i_1_n_2 ),
        .Q(derivative_out[18]),
        .R(1'b0));
  CARRY4 \derivative_reg[18]_i_1 
       (.CI(\derivative_reg[18]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[18]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[18]_i_1_n_2 ,\derivative_reg[18]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[19]_i_1_n_2 ,\derivative_reg[19]_i_2_n_4 }),
        .O({\NLW_derivative_reg[18]_i_1_O_UNCONNECTED [3:1],\derivative_reg[18]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[18]_i_3_n_0 ,\derivative[18]_i_4_n_0 }));
  CARRY4 \derivative_reg[18]_i_10 
       (.CI(\derivative_reg[18]_i_15_n_0 ),
        .CO({\derivative_reg[18]_i_10_n_0 ,\derivative_reg[18]_i_10_n_1 ,\derivative_reg[18]_i_10_n_2 ,\derivative_reg[18]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_10_n_5 ,\derivative_reg[19]_i_10_n_6 ,\derivative_reg[19]_i_10_n_7 ,\derivative_reg[19]_i_15_n_4 }),
        .O({\derivative_reg[18]_i_10_n_4 ,\derivative_reg[18]_i_10_n_5 ,\derivative_reg[18]_i_10_n_6 ,\derivative_reg[18]_i_10_n_7 }),
        .S({\derivative[18]_i_16_n_0 ,\derivative[18]_i_17_n_0 ,\derivative[18]_i_18_n_0 ,\derivative[18]_i_19_n_0 }));
  CARRY4 \derivative_reg[18]_i_15 
       (.CI(\derivative_reg[18]_i_20_n_0 ),
        .CO({\derivative_reg[18]_i_15_n_0 ,\derivative_reg[18]_i_15_n_1 ,\derivative_reg[18]_i_15_n_2 ,\derivative_reg[18]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_15_n_5 ,\derivative_reg[19]_i_15_n_6 ,\derivative_reg[19]_i_15_n_7 ,\derivative_reg[19]_i_20_n_4 }),
        .O({\derivative_reg[18]_i_15_n_4 ,\derivative_reg[18]_i_15_n_5 ,\derivative_reg[18]_i_15_n_6 ,\derivative_reg[18]_i_15_n_7 }),
        .S({\derivative[18]_i_21_n_0 ,\derivative[18]_i_22_n_0 ,\derivative[18]_i_23_n_0 ,\derivative[18]_i_24_n_0 }));
  CARRY4 \derivative_reg[18]_i_2 
       (.CI(\derivative_reg[18]_i_5_n_0 ),
        .CO({\derivative_reg[18]_i_2_n_0 ,\derivative_reg[18]_i_2_n_1 ,\derivative_reg[18]_i_2_n_2 ,\derivative_reg[18]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_2_n_5 ,\derivative_reg[19]_i_2_n_6 ,\derivative_reg[19]_i_2_n_7 ,\derivative_reg[19]_i_5_n_4 }),
        .O({\derivative_reg[18]_i_2_n_4 ,\derivative_reg[18]_i_2_n_5 ,\derivative_reg[18]_i_2_n_6 ,\derivative_reg[18]_i_2_n_7 }),
        .S({\derivative[18]_i_6_n_0 ,\derivative[18]_i_7_n_0 ,\derivative[18]_i_8_n_0 ,\derivative[18]_i_9_n_0 }));
  CARRY4 \derivative_reg[18]_i_20 
       (.CI(\derivative_reg[18]_i_25_n_0 ),
        .CO({\derivative_reg[18]_i_20_n_0 ,\derivative_reg[18]_i_20_n_1 ,\derivative_reg[18]_i_20_n_2 ,\derivative_reg[18]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_20_n_5 ,\derivative_reg[19]_i_20_n_6 ,\derivative_reg[19]_i_20_n_7 ,\derivative_reg[19]_i_25_n_4 }),
        .O({\derivative_reg[18]_i_20_n_4 ,\derivative_reg[18]_i_20_n_5 ,\derivative_reg[18]_i_20_n_6 ,\derivative_reg[18]_i_20_n_7 }),
        .S({\derivative[18]_i_26_n_0 ,\derivative[18]_i_27_n_0 ,\derivative[18]_i_28_n_0 ,\derivative[18]_i_29_n_0 }));
  CARRY4 \derivative_reg[18]_i_25 
       (.CI(\derivative_reg[18]_i_30_n_0 ),
        .CO({\derivative_reg[18]_i_25_n_0 ,\derivative_reg[18]_i_25_n_1 ,\derivative_reg[18]_i_25_n_2 ,\derivative_reg[18]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_25_n_5 ,\derivative_reg[19]_i_25_n_6 ,\derivative_reg[19]_i_25_n_7 ,\derivative_reg[19]_i_30_n_4 }),
        .O({\derivative_reg[18]_i_25_n_4 ,\derivative_reg[18]_i_25_n_5 ,\derivative_reg[18]_i_25_n_6 ,\derivative_reg[18]_i_25_n_7 }),
        .S({\derivative[18]_i_31_n_0 ,\derivative[18]_i_32_n_0 ,\derivative[18]_i_33_n_0 ,\derivative[18]_i_34_n_0 }));
  CARRY4 \derivative_reg[18]_i_30 
       (.CI(\derivative_reg[18]_i_35_n_0 ),
        .CO({\derivative_reg[18]_i_30_n_0 ,\derivative_reg[18]_i_30_n_1 ,\derivative_reg[18]_i_30_n_2 ,\derivative_reg[18]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_30_n_5 ,\derivative_reg[19]_i_30_n_6 ,\derivative_reg[19]_i_30_n_7 ,\derivative_reg[19]_i_35_n_4 }),
        .O({\derivative_reg[18]_i_30_n_4 ,\derivative_reg[18]_i_30_n_5 ,\derivative_reg[18]_i_30_n_6 ,\derivative_reg[18]_i_30_n_7 }),
        .S({\derivative[18]_i_36_n_0 ,\derivative[18]_i_37_n_0 ,\derivative[18]_i_38_n_0 ,\derivative[18]_i_39_n_0 }));
  CARRY4 \derivative_reg[18]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[18]_i_35_n_0 ,\derivative_reg[18]_i_35_n_1 ,\derivative_reg[18]_i_35_n_2 ,\derivative_reg[18]_i_35_n_3 }),
        .CYINIT(\derivative_reg[19]_i_1_n_2 ),
        .DI({\derivative_reg[19]_i_35_n_5 ,\derivative_reg[19]_i_35_n_6 ,derivative11_out[18],1'b0}),
        .O({\derivative_reg[18]_i_35_n_4 ,\derivative_reg[18]_i_35_n_5 ,\derivative_reg[18]_i_35_n_6 ,\NLW_derivative_reg[18]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[18]_i_40_n_0 ,\derivative[18]_i_41_n_0 ,\derivative[18]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[18]_i_5 
       (.CI(\derivative_reg[18]_i_10_n_0 ),
        .CO({\derivative_reg[18]_i_5_n_0 ,\derivative_reg[18]_i_5_n_1 ,\derivative_reg[18]_i_5_n_2 ,\derivative_reg[18]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_5_n_5 ,\derivative_reg[19]_i_5_n_6 ,\derivative_reg[19]_i_5_n_7 ,\derivative_reg[19]_i_10_n_4 }),
        .O({\derivative_reg[18]_i_5_n_4 ,\derivative_reg[18]_i_5_n_5 ,\derivative_reg[18]_i_5_n_6 ,\derivative_reg[18]_i_5_n_7 }),
        .S({\derivative[18]_i_11_n_0 ,\derivative[18]_i_12_n_0 ,\derivative[18]_i_13_n_0 ,\derivative[18]_i_14_n_0 }));
  FDRE \derivative_reg[19] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[19]_i_1_n_2 ),
        .Q(derivative_out[19]),
        .R(1'b0));
  CARRY4 \derivative_reg[19]_i_1 
       (.CI(\derivative_reg[19]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[19]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[19]_i_1_n_2 ,\derivative_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[20]_i_1_n_2 ,\derivative_reg[20]_i_2_n_4 }),
        .O({\NLW_derivative_reg[19]_i_1_O_UNCONNECTED [3:1],\derivative_reg[19]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[19]_i_3_n_0 ,\derivative[19]_i_4_n_0 }));
  CARRY4 \derivative_reg[19]_i_10 
       (.CI(\derivative_reg[19]_i_15_n_0 ),
        .CO({\derivative_reg[19]_i_10_n_0 ,\derivative_reg[19]_i_10_n_1 ,\derivative_reg[19]_i_10_n_2 ,\derivative_reg[19]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[20]_i_10_n_5 ,\derivative_reg[20]_i_10_n_6 ,\derivative_reg[20]_i_10_n_7 ,\derivative_reg[20]_i_15_n_4 }),
        .O({\derivative_reg[19]_i_10_n_4 ,\derivative_reg[19]_i_10_n_5 ,\derivative_reg[19]_i_10_n_6 ,\derivative_reg[19]_i_10_n_7 }),
        .S({\derivative[19]_i_16_n_0 ,\derivative[19]_i_17_n_0 ,\derivative[19]_i_18_n_0 ,\derivative[19]_i_19_n_0 }));
  CARRY4 \derivative_reg[19]_i_15 
       (.CI(\derivative_reg[19]_i_20_n_0 ),
        .CO({\derivative_reg[19]_i_15_n_0 ,\derivative_reg[19]_i_15_n_1 ,\derivative_reg[19]_i_15_n_2 ,\derivative_reg[19]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[20]_i_15_n_5 ,\derivative_reg[20]_i_15_n_6 ,\derivative_reg[20]_i_15_n_7 ,\derivative_reg[20]_i_20_n_4 }),
        .O({\derivative_reg[19]_i_15_n_4 ,\derivative_reg[19]_i_15_n_5 ,\derivative_reg[19]_i_15_n_6 ,\derivative_reg[19]_i_15_n_7 }),
        .S({\derivative[19]_i_21_n_0 ,\derivative[19]_i_22_n_0 ,\derivative[19]_i_23_n_0 ,\derivative[19]_i_24_n_0 }));
  CARRY4 \derivative_reg[19]_i_2 
       (.CI(\derivative_reg[19]_i_5_n_0 ),
        .CO({\derivative_reg[19]_i_2_n_0 ,\derivative_reg[19]_i_2_n_1 ,\derivative_reg[19]_i_2_n_2 ,\derivative_reg[19]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[20]_i_2_n_5 ,\derivative_reg[20]_i_2_n_6 ,\derivative_reg[20]_i_2_n_7 ,\derivative_reg[20]_i_5_n_4 }),
        .O({\derivative_reg[19]_i_2_n_4 ,\derivative_reg[19]_i_2_n_5 ,\derivative_reg[19]_i_2_n_6 ,\derivative_reg[19]_i_2_n_7 }),
        .S({\derivative[19]_i_6_n_0 ,\derivative[19]_i_7_n_0 ,\derivative[19]_i_8_n_0 ,\derivative[19]_i_9_n_0 }));
  CARRY4 \derivative_reg[19]_i_20 
       (.CI(\derivative_reg[19]_i_25_n_0 ),
        .CO({\derivative_reg[19]_i_20_n_0 ,\derivative_reg[19]_i_20_n_1 ,\derivative_reg[19]_i_20_n_2 ,\derivative_reg[19]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[20]_i_20_n_5 ,\derivative_reg[20]_i_20_n_6 ,\derivative_reg[20]_i_20_n_7 ,\derivative_reg[20]_i_25_n_4 }),
        .O({\derivative_reg[19]_i_20_n_4 ,\derivative_reg[19]_i_20_n_5 ,\derivative_reg[19]_i_20_n_6 ,\derivative_reg[19]_i_20_n_7 }),
        .S({\derivative[19]_i_26_n_0 ,\derivative[19]_i_27_n_0 ,\derivative[19]_i_28_n_0 ,\derivative[19]_i_29_n_0 }));
  CARRY4 \derivative_reg[19]_i_25 
       (.CI(\derivative_reg[19]_i_30_n_0 ),
        .CO({\derivative_reg[19]_i_25_n_0 ,\derivative_reg[19]_i_25_n_1 ,\derivative_reg[19]_i_25_n_2 ,\derivative_reg[19]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[20]_i_25_n_5 ,\derivative_reg[20]_i_25_n_6 ,\derivative_reg[20]_i_25_n_7 ,\derivative_reg[20]_i_30_n_4 }),
        .O({\derivative_reg[19]_i_25_n_4 ,\derivative_reg[19]_i_25_n_5 ,\derivative_reg[19]_i_25_n_6 ,\derivative_reg[19]_i_25_n_7 }),
        .S({\derivative[19]_i_31_n_0 ,\derivative[19]_i_32_n_0 ,\derivative[19]_i_33_n_0 ,\derivative[19]_i_34_n_0 }));
  CARRY4 \derivative_reg[19]_i_30 
       (.CI(\derivative_reg[19]_i_35_n_0 ),
        .CO({\derivative_reg[19]_i_30_n_0 ,\derivative_reg[19]_i_30_n_1 ,\derivative_reg[19]_i_30_n_2 ,\derivative_reg[19]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[20]_i_30_n_5 ,\derivative_reg[20]_i_30_n_6 ,\derivative_reg[20]_i_30_n_7 ,\derivative_reg[20]_i_35_n_4 }),
        .O({\derivative_reg[19]_i_30_n_4 ,\derivative_reg[19]_i_30_n_5 ,\derivative_reg[19]_i_30_n_6 ,\derivative_reg[19]_i_30_n_7 }),
        .S({\derivative[19]_i_36_n_0 ,\derivative[19]_i_37_n_0 ,\derivative[19]_i_38_n_0 ,\derivative[19]_i_39_n_0 }));
  CARRY4 \derivative_reg[19]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[19]_i_35_n_0 ,\derivative_reg[19]_i_35_n_1 ,\derivative_reg[19]_i_35_n_2 ,\derivative_reg[19]_i_35_n_3 }),
        .CYINIT(\derivative_reg[20]_i_1_n_2 ),
        .DI({\derivative_reg[20]_i_35_n_5 ,\derivative_reg[20]_i_35_n_6 ,derivative11_out[19],1'b0}),
        .O({\derivative_reg[19]_i_35_n_4 ,\derivative_reg[19]_i_35_n_5 ,\derivative_reg[19]_i_35_n_6 ,\NLW_derivative_reg[19]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[19]_i_40_n_0 ,\derivative[19]_i_41_n_0 ,\derivative[19]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[19]_i_5 
       (.CI(\derivative_reg[19]_i_10_n_0 ),
        .CO({\derivative_reg[19]_i_5_n_0 ,\derivative_reg[19]_i_5_n_1 ,\derivative_reg[19]_i_5_n_2 ,\derivative_reg[19]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[20]_i_5_n_5 ,\derivative_reg[20]_i_5_n_6 ,\derivative_reg[20]_i_5_n_7 ,\derivative_reg[20]_i_10_n_4 }),
        .O({\derivative_reg[19]_i_5_n_4 ,\derivative_reg[19]_i_5_n_5 ,\derivative_reg[19]_i_5_n_6 ,\derivative_reg[19]_i_5_n_7 }),
        .S({\derivative[19]_i_11_n_0 ,\derivative[19]_i_12_n_0 ,\derivative[19]_i_13_n_0 ,\derivative[19]_i_14_n_0 }));
  FDRE \derivative_reg[1] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[1]_i_1_n_2 ),
        .Q(derivative_out[1]),
        .R(1'b0));
  CARRY4 \derivative_reg[1]_i_1 
       (.CI(\derivative_reg[1]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[1]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[1]_i_1_n_2 ,\derivative_reg[1]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[2]_i_1_n_2 ,\derivative_reg[2]_i_2_n_4 }),
        .O({\NLW_derivative_reg[1]_i_1_O_UNCONNECTED [3:1],\derivative_reg[1]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[1]_i_3_n_0 ,\derivative[1]_i_4_n_0 }));
  CARRY4 \derivative_reg[1]_i_10 
       (.CI(\derivative_reg[1]_i_15_n_0 ),
        .CO({\derivative_reg[1]_i_10_n_0 ,\derivative_reg[1]_i_10_n_1 ,\derivative_reg[1]_i_10_n_2 ,\derivative_reg[1]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[2]_i_10_n_5 ,\derivative_reg[2]_i_10_n_6 ,\derivative_reg[2]_i_10_n_7 ,\derivative_reg[2]_i_15_n_4 }),
        .O({\derivative_reg[1]_i_10_n_4 ,\derivative_reg[1]_i_10_n_5 ,\derivative_reg[1]_i_10_n_6 ,\derivative_reg[1]_i_10_n_7 }),
        .S({\derivative[1]_i_16_n_0 ,\derivative[1]_i_17_n_0 ,\derivative[1]_i_18_n_0 ,\derivative[1]_i_19_n_0 }));
  CARRY4 \derivative_reg[1]_i_15 
       (.CI(\derivative_reg[1]_i_20_n_0 ),
        .CO({\derivative_reg[1]_i_15_n_0 ,\derivative_reg[1]_i_15_n_1 ,\derivative_reg[1]_i_15_n_2 ,\derivative_reg[1]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[2]_i_15_n_5 ,\derivative_reg[2]_i_15_n_6 ,\derivative_reg[2]_i_15_n_7 ,\derivative_reg[2]_i_20_n_4 }),
        .O({\derivative_reg[1]_i_15_n_4 ,\derivative_reg[1]_i_15_n_5 ,\derivative_reg[1]_i_15_n_6 ,\derivative_reg[1]_i_15_n_7 }),
        .S({\derivative[1]_i_21_n_0 ,\derivative[1]_i_22_n_0 ,\derivative[1]_i_23_n_0 ,\derivative[1]_i_24_n_0 }));
  CARRY4 \derivative_reg[1]_i_2 
       (.CI(\derivative_reg[1]_i_5_n_0 ),
        .CO({\derivative_reg[1]_i_2_n_0 ,\derivative_reg[1]_i_2_n_1 ,\derivative_reg[1]_i_2_n_2 ,\derivative_reg[1]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[2]_i_2_n_5 ,\derivative_reg[2]_i_2_n_6 ,\derivative_reg[2]_i_2_n_7 ,\derivative_reg[2]_i_5_n_4 }),
        .O({\derivative_reg[1]_i_2_n_4 ,\derivative_reg[1]_i_2_n_5 ,\derivative_reg[1]_i_2_n_6 ,\derivative_reg[1]_i_2_n_7 }),
        .S({\derivative[1]_i_6_n_0 ,\derivative[1]_i_7_n_0 ,\derivative[1]_i_8_n_0 ,\derivative[1]_i_9_n_0 }));
  CARRY4 \derivative_reg[1]_i_20 
       (.CI(\derivative_reg[1]_i_25_n_0 ),
        .CO({\derivative_reg[1]_i_20_n_0 ,\derivative_reg[1]_i_20_n_1 ,\derivative_reg[1]_i_20_n_2 ,\derivative_reg[1]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[2]_i_20_n_5 ,\derivative_reg[2]_i_20_n_6 ,\derivative_reg[2]_i_20_n_7 ,\derivative_reg[2]_i_25_n_4 }),
        .O({\derivative_reg[1]_i_20_n_4 ,\derivative_reg[1]_i_20_n_5 ,\derivative_reg[1]_i_20_n_6 ,\derivative_reg[1]_i_20_n_7 }),
        .S({\derivative[1]_i_26_n_0 ,\derivative[1]_i_27_n_0 ,\derivative[1]_i_28_n_0 ,\derivative[1]_i_29_n_0 }));
  CARRY4 \derivative_reg[1]_i_25 
       (.CI(\derivative_reg[1]_i_30_n_0 ),
        .CO({\derivative_reg[1]_i_25_n_0 ,\derivative_reg[1]_i_25_n_1 ,\derivative_reg[1]_i_25_n_2 ,\derivative_reg[1]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[2]_i_25_n_5 ,\derivative_reg[2]_i_25_n_6 ,\derivative_reg[2]_i_25_n_7 ,\derivative_reg[2]_i_30_n_4 }),
        .O({\derivative_reg[1]_i_25_n_4 ,\derivative_reg[1]_i_25_n_5 ,\derivative_reg[1]_i_25_n_6 ,\derivative_reg[1]_i_25_n_7 }),
        .S({\derivative[1]_i_31_n_0 ,\derivative[1]_i_32_n_0 ,\derivative[1]_i_33_n_0 ,\derivative[1]_i_34_n_0 }));
  CARRY4 \derivative_reg[1]_i_30 
       (.CI(\derivative_reg[1]_i_35_n_0 ),
        .CO({\derivative_reg[1]_i_30_n_0 ,\derivative_reg[1]_i_30_n_1 ,\derivative_reg[1]_i_30_n_2 ,\derivative_reg[1]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[2]_i_30_n_5 ,\derivative_reg[2]_i_30_n_6 ,\derivative_reg[2]_i_30_n_7 ,\derivative_reg[2]_i_35_n_4 }),
        .O({\derivative_reg[1]_i_30_n_4 ,\derivative_reg[1]_i_30_n_5 ,\derivative_reg[1]_i_30_n_6 ,\derivative_reg[1]_i_30_n_7 }),
        .S({\derivative[1]_i_36_n_0 ,\derivative[1]_i_37_n_0 ,\derivative[1]_i_38_n_0 ,\derivative[1]_i_39_n_0 }));
  CARRY4 \derivative_reg[1]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[1]_i_35_n_0 ,\derivative_reg[1]_i_35_n_1 ,\derivative_reg[1]_i_35_n_2 ,\derivative_reg[1]_i_35_n_3 }),
        .CYINIT(\derivative_reg[2]_i_1_n_2 ),
        .DI({\derivative_reg[2]_i_35_n_5 ,\derivative_reg[2]_i_35_n_6 ,derivative11_out[1],1'b0}),
        .O({\derivative_reg[1]_i_35_n_4 ,\derivative_reg[1]_i_35_n_5 ,\derivative_reg[1]_i_35_n_6 ,\NLW_derivative_reg[1]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[1]_i_40_n_0 ,\derivative[1]_i_41_n_0 ,\derivative[1]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[1]_i_5 
       (.CI(\derivative_reg[1]_i_10_n_0 ),
        .CO({\derivative_reg[1]_i_5_n_0 ,\derivative_reg[1]_i_5_n_1 ,\derivative_reg[1]_i_5_n_2 ,\derivative_reg[1]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[2]_i_5_n_5 ,\derivative_reg[2]_i_5_n_6 ,\derivative_reg[2]_i_5_n_7 ,\derivative_reg[2]_i_10_n_4 }),
        .O({\derivative_reg[1]_i_5_n_4 ,\derivative_reg[1]_i_5_n_5 ,\derivative_reg[1]_i_5_n_6 ,\derivative_reg[1]_i_5_n_7 }),
        .S({\derivative[1]_i_11_n_0 ,\derivative[1]_i_12_n_0 ,\derivative[1]_i_13_n_0 ,\derivative[1]_i_14_n_0 }));
  FDRE \derivative_reg[20] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[20]_i_1_n_2 ),
        .Q(derivative_out[20]),
        .R(1'b0));
  CARRY4 \derivative_reg[20]_i_1 
       (.CI(\derivative_reg[20]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[20]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[20]_i_1_n_2 ,\derivative_reg[20]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[21]_i_1_n_2 ,\derivative_reg[21]_i_2_n_4 }),
        .O({\NLW_derivative_reg[20]_i_1_O_UNCONNECTED [3:1],\derivative_reg[20]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[20]_i_3_n_0 ,\derivative[20]_i_4_n_0 }));
  CARRY4 \derivative_reg[20]_i_10 
       (.CI(\derivative_reg[20]_i_15_n_0 ),
        .CO({\derivative_reg[20]_i_10_n_0 ,\derivative_reg[20]_i_10_n_1 ,\derivative_reg[20]_i_10_n_2 ,\derivative_reg[20]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[21]_i_10_n_5 ,\derivative_reg[21]_i_10_n_6 ,\derivative_reg[21]_i_10_n_7 ,\derivative_reg[21]_i_15_n_4 }),
        .O({\derivative_reg[20]_i_10_n_4 ,\derivative_reg[20]_i_10_n_5 ,\derivative_reg[20]_i_10_n_6 ,\derivative_reg[20]_i_10_n_7 }),
        .S({\derivative[20]_i_16_n_0 ,\derivative[20]_i_17_n_0 ,\derivative[20]_i_18_n_0 ,\derivative[20]_i_19_n_0 }));
  CARRY4 \derivative_reg[20]_i_15 
       (.CI(\derivative_reg[20]_i_20_n_0 ),
        .CO({\derivative_reg[20]_i_15_n_0 ,\derivative_reg[20]_i_15_n_1 ,\derivative_reg[20]_i_15_n_2 ,\derivative_reg[20]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[21]_i_15_n_5 ,\derivative_reg[21]_i_15_n_6 ,\derivative_reg[21]_i_15_n_7 ,\derivative_reg[21]_i_20_n_4 }),
        .O({\derivative_reg[20]_i_15_n_4 ,\derivative_reg[20]_i_15_n_5 ,\derivative_reg[20]_i_15_n_6 ,\derivative_reg[20]_i_15_n_7 }),
        .S({\derivative[20]_i_21_n_0 ,\derivative[20]_i_22_n_0 ,\derivative[20]_i_23_n_0 ,\derivative[20]_i_24_n_0 }));
  CARRY4 \derivative_reg[20]_i_2 
       (.CI(\derivative_reg[20]_i_5_n_0 ),
        .CO({\derivative_reg[20]_i_2_n_0 ,\derivative_reg[20]_i_2_n_1 ,\derivative_reg[20]_i_2_n_2 ,\derivative_reg[20]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[21]_i_2_n_5 ,\derivative_reg[21]_i_2_n_6 ,\derivative_reg[21]_i_2_n_7 ,\derivative_reg[21]_i_5_n_4 }),
        .O({\derivative_reg[20]_i_2_n_4 ,\derivative_reg[20]_i_2_n_5 ,\derivative_reg[20]_i_2_n_6 ,\derivative_reg[20]_i_2_n_7 }),
        .S({\derivative[20]_i_6_n_0 ,\derivative[20]_i_7_n_0 ,\derivative[20]_i_8_n_0 ,\derivative[20]_i_9_n_0 }));
  CARRY4 \derivative_reg[20]_i_20 
       (.CI(\derivative_reg[20]_i_25_n_0 ),
        .CO({\derivative_reg[20]_i_20_n_0 ,\derivative_reg[20]_i_20_n_1 ,\derivative_reg[20]_i_20_n_2 ,\derivative_reg[20]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[21]_i_20_n_5 ,\derivative_reg[21]_i_20_n_6 ,\derivative_reg[21]_i_20_n_7 ,\derivative_reg[21]_i_25_n_4 }),
        .O({\derivative_reg[20]_i_20_n_4 ,\derivative_reg[20]_i_20_n_5 ,\derivative_reg[20]_i_20_n_6 ,\derivative_reg[20]_i_20_n_7 }),
        .S({\derivative[20]_i_26_n_0 ,\derivative[20]_i_27_n_0 ,\derivative[20]_i_28_n_0 ,\derivative[20]_i_29_n_0 }));
  CARRY4 \derivative_reg[20]_i_25 
       (.CI(\derivative_reg[20]_i_30_n_0 ),
        .CO({\derivative_reg[20]_i_25_n_0 ,\derivative_reg[20]_i_25_n_1 ,\derivative_reg[20]_i_25_n_2 ,\derivative_reg[20]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[21]_i_25_n_5 ,\derivative_reg[21]_i_25_n_6 ,\derivative_reg[21]_i_25_n_7 ,\derivative_reg[21]_i_30_n_4 }),
        .O({\derivative_reg[20]_i_25_n_4 ,\derivative_reg[20]_i_25_n_5 ,\derivative_reg[20]_i_25_n_6 ,\derivative_reg[20]_i_25_n_7 }),
        .S({\derivative[20]_i_31_n_0 ,\derivative[20]_i_32_n_0 ,\derivative[20]_i_33_n_0 ,\derivative[20]_i_34_n_0 }));
  CARRY4 \derivative_reg[20]_i_30 
       (.CI(\derivative_reg[20]_i_35_n_0 ),
        .CO({\derivative_reg[20]_i_30_n_0 ,\derivative_reg[20]_i_30_n_1 ,\derivative_reg[20]_i_30_n_2 ,\derivative_reg[20]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[21]_i_30_n_5 ,\derivative_reg[21]_i_30_n_6 ,\derivative_reg[21]_i_30_n_7 ,\derivative_reg[21]_i_35_n_4 }),
        .O({\derivative_reg[20]_i_30_n_4 ,\derivative_reg[20]_i_30_n_5 ,\derivative_reg[20]_i_30_n_6 ,\derivative_reg[20]_i_30_n_7 }),
        .S({\derivative[20]_i_36_n_0 ,\derivative[20]_i_37_n_0 ,\derivative[20]_i_38_n_0 ,\derivative[20]_i_39_n_0 }));
  CARRY4 \derivative_reg[20]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[20]_i_35_n_0 ,\derivative_reg[20]_i_35_n_1 ,\derivative_reg[20]_i_35_n_2 ,\derivative_reg[20]_i_35_n_3 }),
        .CYINIT(\derivative_reg[21]_i_1_n_2 ),
        .DI({\derivative_reg[21]_i_35_n_5 ,\derivative_reg[21]_i_35_n_6 ,derivative11_out[20],1'b0}),
        .O({\derivative_reg[20]_i_35_n_4 ,\derivative_reg[20]_i_35_n_5 ,\derivative_reg[20]_i_35_n_6 ,\NLW_derivative_reg[20]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[20]_i_40_n_0 ,\derivative[20]_i_41_n_0 ,\derivative[20]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[20]_i_5 
       (.CI(\derivative_reg[20]_i_10_n_0 ),
        .CO({\derivative_reg[20]_i_5_n_0 ,\derivative_reg[20]_i_5_n_1 ,\derivative_reg[20]_i_5_n_2 ,\derivative_reg[20]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[21]_i_5_n_5 ,\derivative_reg[21]_i_5_n_6 ,\derivative_reg[21]_i_5_n_7 ,\derivative_reg[21]_i_10_n_4 }),
        .O({\derivative_reg[20]_i_5_n_4 ,\derivative_reg[20]_i_5_n_5 ,\derivative_reg[20]_i_5_n_6 ,\derivative_reg[20]_i_5_n_7 }),
        .S({\derivative[20]_i_11_n_0 ,\derivative[20]_i_12_n_0 ,\derivative[20]_i_13_n_0 ,\derivative[20]_i_14_n_0 }));
  FDRE \derivative_reg[21] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[21]_i_1_n_2 ),
        .Q(derivative_out[21]),
        .R(1'b0));
  CARRY4 \derivative_reg[21]_i_1 
       (.CI(\derivative_reg[21]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[21]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[21]_i_1_n_2 ,\derivative_reg[21]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[22]_i_1_n_2 ,\derivative_reg[22]_i_2_n_4 }),
        .O({\NLW_derivative_reg[21]_i_1_O_UNCONNECTED [3:1],\derivative_reg[21]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[21]_i_3_n_0 ,\derivative[21]_i_4_n_0 }));
  CARRY4 \derivative_reg[21]_i_10 
       (.CI(\derivative_reg[21]_i_15_n_0 ),
        .CO({\derivative_reg[21]_i_10_n_0 ,\derivative_reg[21]_i_10_n_1 ,\derivative_reg[21]_i_10_n_2 ,\derivative_reg[21]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[22]_i_10_n_5 ,\derivative_reg[22]_i_10_n_6 ,\derivative_reg[22]_i_10_n_7 ,\derivative_reg[22]_i_15_n_4 }),
        .O({\derivative_reg[21]_i_10_n_4 ,\derivative_reg[21]_i_10_n_5 ,\derivative_reg[21]_i_10_n_6 ,\derivative_reg[21]_i_10_n_7 }),
        .S({\derivative[21]_i_16_n_0 ,\derivative[21]_i_17_n_0 ,\derivative[21]_i_18_n_0 ,\derivative[21]_i_19_n_0 }));
  CARRY4 \derivative_reg[21]_i_15 
       (.CI(\derivative_reg[21]_i_20_n_0 ),
        .CO({\derivative_reg[21]_i_15_n_0 ,\derivative_reg[21]_i_15_n_1 ,\derivative_reg[21]_i_15_n_2 ,\derivative_reg[21]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[22]_i_15_n_5 ,\derivative_reg[22]_i_15_n_6 ,\derivative_reg[22]_i_15_n_7 ,\derivative_reg[22]_i_20_n_4 }),
        .O({\derivative_reg[21]_i_15_n_4 ,\derivative_reg[21]_i_15_n_5 ,\derivative_reg[21]_i_15_n_6 ,\derivative_reg[21]_i_15_n_7 }),
        .S({\derivative[21]_i_21_n_0 ,\derivative[21]_i_22_n_0 ,\derivative[21]_i_23_n_0 ,\derivative[21]_i_24_n_0 }));
  CARRY4 \derivative_reg[21]_i_2 
       (.CI(\derivative_reg[21]_i_5_n_0 ),
        .CO({\derivative_reg[21]_i_2_n_0 ,\derivative_reg[21]_i_2_n_1 ,\derivative_reg[21]_i_2_n_2 ,\derivative_reg[21]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[22]_i_2_n_5 ,\derivative_reg[22]_i_2_n_6 ,\derivative_reg[22]_i_2_n_7 ,\derivative_reg[22]_i_5_n_4 }),
        .O({\derivative_reg[21]_i_2_n_4 ,\derivative_reg[21]_i_2_n_5 ,\derivative_reg[21]_i_2_n_6 ,\derivative_reg[21]_i_2_n_7 }),
        .S({\derivative[21]_i_6_n_0 ,\derivative[21]_i_7_n_0 ,\derivative[21]_i_8_n_0 ,\derivative[21]_i_9_n_0 }));
  CARRY4 \derivative_reg[21]_i_20 
       (.CI(\derivative_reg[21]_i_25_n_0 ),
        .CO({\derivative_reg[21]_i_20_n_0 ,\derivative_reg[21]_i_20_n_1 ,\derivative_reg[21]_i_20_n_2 ,\derivative_reg[21]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[22]_i_20_n_5 ,\derivative_reg[22]_i_20_n_6 ,\derivative_reg[22]_i_20_n_7 ,\derivative_reg[22]_i_25_n_4 }),
        .O({\derivative_reg[21]_i_20_n_4 ,\derivative_reg[21]_i_20_n_5 ,\derivative_reg[21]_i_20_n_6 ,\derivative_reg[21]_i_20_n_7 }),
        .S({\derivative[21]_i_26_n_0 ,\derivative[21]_i_27_n_0 ,\derivative[21]_i_28_n_0 ,\derivative[21]_i_29_n_0 }));
  CARRY4 \derivative_reg[21]_i_25 
       (.CI(\derivative_reg[21]_i_30_n_0 ),
        .CO({\derivative_reg[21]_i_25_n_0 ,\derivative_reg[21]_i_25_n_1 ,\derivative_reg[21]_i_25_n_2 ,\derivative_reg[21]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[22]_i_25_n_5 ,\derivative_reg[22]_i_25_n_6 ,\derivative_reg[22]_i_25_n_7 ,\derivative_reg[22]_i_30_n_4 }),
        .O({\derivative_reg[21]_i_25_n_4 ,\derivative_reg[21]_i_25_n_5 ,\derivative_reg[21]_i_25_n_6 ,\derivative_reg[21]_i_25_n_7 }),
        .S({\derivative[21]_i_31_n_0 ,\derivative[21]_i_32_n_0 ,\derivative[21]_i_33_n_0 ,\derivative[21]_i_34_n_0 }));
  CARRY4 \derivative_reg[21]_i_30 
       (.CI(\derivative_reg[21]_i_35_n_0 ),
        .CO({\derivative_reg[21]_i_30_n_0 ,\derivative_reg[21]_i_30_n_1 ,\derivative_reg[21]_i_30_n_2 ,\derivative_reg[21]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[22]_i_30_n_5 ,\derivative_reg[22]_i_30_n_6 ,\derivative_reg[22]_i_30_n_7 ,\derivative_reg[22]_i_35_n_4 }),
        .O({\derivative_reg[21]_i_30_n_4 ,\derivative_reg[21]_i_30_n_5 ,\derivative_reg[21]_i_30_n_6 ,\derivative_reg[21]_i_30_n_7 }),
        .S({\derivative[21]_i_36_n_0 ,\derivative[21]_i_37_n_0 ,\derivative[21]_i_38_n_0 ,\derivative[21]_i_39_n_0 }));
  CARRY4 \derivative_reg[21]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[21]_i_35_n_0 ,\derivative_reg[21]_i_35_n_1 ,\derivative_reg[21]_i_35_n_2 ,\derivative_reg[21]_i_35_n_3 }),
        .CYINIT(\derivative_reg[22]_i_1_n_2 ),
        .DI({\derivative_reg[22]_i_35_n_5 ,\derivative_reg[22]_i_35_n_6 ,derivative11_out[21],1'b0}),
        .O({\derivative_reg[21]_i_35_n_4 ,\derivative_reg[21]_i_35_n_5 ,\derivative_reg[21]_i_35_n_6 ,\NLW_derivative_reg[21]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[21]_i_40_n_0 ,\derivative[21]_i_41_n_0 ,\derivative[21]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[21]_i_5 
       (.CI(\derivative_reg[21]_i_10_n_0 ),
        .CO({\derivative_reg[21]_i_5_n_0 ,\derivative_reg[21]_i_5_n_1 ,\derivative_reg[21]_i_5_n_2 ,\derivative_reg[21]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[22]_i_5_n_5 ,\derivative_reg[22]_i_5_n_6 ,\derivative_reg[22]_i_5_n_7 ,\derivative_reg[22]_i_10_n_4 }),
        .O({\derivative_reg[21]_i_5_n_4 ,\derivative_reg[21]_i_5_n_5 ,\derivative_reg[21]_i_5_n_6 ,\derivative_reg[21]_i_5_n_7 }),
        .S({\derivative[21]_i_11_n_0 ,\derivative[21]_i_12_n_0 ,\derivative[21]_i_13_n_0 ,\derivative[21]_i_14_n_0 }));
  FDRE \derivative_reg[22] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[22]_i_1_n_2 ),
        .Q(derivative_out[22]),
        .R(1'b0));
  CARRY4 \derivative_reg[22]_i_1 
       (.CI(\derivative_reg[22]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[22]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[22]_i_1_n_2 ,\derivative_reg[22]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[23]_i_1_n_2 ,\derivative_reg[23]_i_2_n_4 }),
        .O({\NLW_derivative_reg[22]_i_1_O_UNCONNECTED [3:1],\derivative_reg[22]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[22]_i_3_n_0 ,\derivative[22]_i_4_n_0 }));
  CARRY4 \derivative_reg[22]_i_10 
       (.CI(\derivative_reg[22]_i_15_n_0 ),
        .CO({\derivative_reg[22]_i_10_n_0 ,\derivative_reg[22]_i_10_n_1 ,\derivative_reg[22]_i_10_n_2 ,\derivative_reg[22]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_10_n_5 ,\derivative_reg[23]_i_10_n_6 ,\derivative_reg[23]_i_10_n_7 ,\derivative_reg[23]_i_15_n_4 }),
        .O({\derivative_reg[22]_i_10_n_4 ,\derivative_reg[22]_i_10_n_5 ,\derivative_reg[22]_i_10_n_6 ,\derivative_reg[22]_i_10_n_7 }),
        .S({\derivative[22]_i_16_n_0 ,\derivative[22]_i_17_n_0 ,\derivative[22]_i_18_n_0 ,\derivative[22]_i_19_n_0 }));
  CARRY4 \derivative_reg[22]_i_15 
       (.CI(\derivative_reg[22]_i_20_n_0 ),
        .CO({\derivative_reg[22]_i_15_n_0 ,\derivative_reg[22]_i_15_n_1 ,\derivative_reg[22]_i_15_n_2 ,\derivative_reg[22]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_15_n_5 ,\derivative_reg[23]_i_15_n_6 ,\derivative_reg[23]_i_15_n_7 ,\derivative_reg[23]_i_20_n_4 }),
        .O({\derivative_reg[22]_i_15_n_4 ,\derivative_reg[22]_i_15_n_5 ,\derivative_reg[22]_i_15_n_6 ,\derivative_reg[22]_i_15_n_7 }),
        .S({\derivative[22]_i_21_n_0 ,\derivative[22]_i_22_n_0 ,\derivative[22]_i_23_n_0 ,\derivative[22]_i_24_n_0 }));
  CARRY4 \derivative_reg[22]_i_2 
       (.CI(\derivative_reg[22]_i_5_n_0 ),
        .CO({\derivative_reg[22]_i_2_n_0 ,\derivative_reg[22]_i_2_n_1 ,\derivative_reg[22]_i_2_n_2 ,\derivative_reg[22]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_2_n_5 ,\derivative_reg[23]_i_2_n_6 ,\derivative_reg[23]_i_2_n_7 ,\derivative_reg[23]_i_5_n_4 }),
        .O({\derivative_reg[22]_i_2_n_4 ,\derivative_reg[22]_i_2_n_5 ,\derivative_reg[22]_i_2_n_6 ,\derivative_reg[22]_i_2_n_7 }),
        .S({\derivative[22]_i_6_n_0 ,\derivative[22]_i_7_n_0 ,\derivative[22]_i_8_n_0 ,\derivative[22]_i_9_n_0 }));
  CARRY4 \derivative_reg[22]_i_20 
       (.CI(\derivative_reg[22]_i_25_n_0 ),
        .CO({\derivative_reg[22]_i_20_n_0 ,\derivative_reg[22]_i_20_n_1 ,\derivative_reg[22]_i_20_n_2 ,\derivative_reg[22]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_20_n_5 ,\derivative_reg[23]_i_20_n_6 ,\derivative_reg[23]_i_20_n_7 ,\derivative_reg[23]_i_25_n_4 }),
        .O({\derivative_reg[22]_i_20_n_4 ,\derivative_reg[22]_i_20_n_5 ,\derivative_reg[22]_i_20_n_6 ,\derivative_reg[22]_i_20_n_7 }),
        .S({\derivative[22]_i_26_n_0 ,\derivative[22]_i_27_n_0 ,\derivative[22]_i_28_n_0 ,\derivative[22]_i_29_n_0 }));
  CARRY4 \derivative_reg[22]_i_25 
       (.CI(\derivative_reg[22]_i_30_n_0 ),
        .CO({\derivative_reg[22]_i_25_n_0 ,\derivative_reg[22]_i_25_n_1 ,\derivative_reg[22]_i_25_n_2 ,\derivative_reg[22]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_25_n_5 ,\derivative_reg[23]_i_25_n_6 ,\derivative_reg[23]_i_25_n_7 ,\derivative_reg[23]_i_30_n_4 }),
        .O({\derivative_reg[22]_i_25_n_4 ,\derivative_reg[22]_i_25_n_5 ,\derivative_reg[22]_i_25_n_6 ,\derivative_reg[22]_i_25_n_7 }),
        .S({\derivative[22]_i_31_n_0 ,\derivative[22]_i_32_n_0 ,\derivative[22]_i_33_n_0 ,\derivative[22]_i_34_n_0 }));
  CARRY4 \derivative_reg[22]_i_30 
       (.CI(\derivative_reg[22]_i_35_n_0 ),
        .CO({\derivative_reg[22]_i_30_n_0 ,\derivative_reg[22]_i_30_n_1 ,\derivative_reg[22]_i_30_n_2 ,\derivative_reg[22]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_30_n_5 ,\derivative_reg[23]_i_30_n_6 ,\derivative_reg[23]_i_30_n_7 ,\derivative_reg[23]_i_35_n_4 }),
        .O({\derivative_reg[22]_i_30_n_4 ,\derivative_reg[22]_i_30_n_5 ,\derivative_reg[22]_i_30_n_6 ,\derivative_reg[22]_i_30_n_7 }),
        .S({\derivative[22]_i_36_n_0 ,\derivative[22]_i_37_n_0 ,\derivative[22]_i_38_n_0 ,\derivative[22]_i_39_n_0 }));
  CARRY4 \derivative_reg[22]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[22]_i_35_n_0 ,\derivative_reg[22]_i_35_n_1 ,\derivative_reg[22]_i_35_n_2 ,\derivative_reg[22]_i_35_n_3 }),
        .CYINIT(\derivative_reg[23]_i_1_n_2 ),
        .DI({\derivative_reg[23]_i_35_n_5 ,\derivative_reg[23]_i_35_n_6 ,derivative11_out[22],1'b0}),
        .O({\derivative_reg[22]_i_35_n_4 ,\derivative_reg[22]_i_35_n_5 ,\derivative_reg[22]_i_35_n_6 ,\NLW_derivative_reg[22]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[22]_i_40_n_0 ,\derivative[22]_i_41_n_0 ,\derivative[22]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[22]_i_5 
       (.CI(\derivative_reg[22]_i_10_n_0 ),
        .CO({\derivative_reg[22]_i_5_n_0 ,\derivative_reg[22]_i_5_n_1 ,\derivative_reg[22]_i_5_n_2 ,\derivative_reg[22]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_5_n_5 ,\derivative_reg[23]_i_5_n_6 ,\derivative_reg[23]_i_5_n_7 ,\derivative_reg[23]_i_10_n_4 }),
        .O({\derivative_reg[22]_i_5_n_4 ,\derivative_reg[22]_i_5_n_5 ,\derivative_reg[22]_i_5_n_6 ,\derivative_reg[22]_i_5_n_7 }),
        .S({\derivative[22]_i_11_n_0 ,\derivative[22]_i_12_n_0 ,\derivative[22]_i_13_n_0 ,\derivative[22]_i_14_n_0 }));
  FDRE \derivative_reg[23] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[23]_i_1_n_2 ),
        .Q(derivative_out[23]),
        .R(1'b0));
  CARRY4 \derivative_reg[23]_i_1 
       (.CI(\derivative_reg[23]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[23]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[23]_i_1_n_2 ,\derivative_reg[23]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[24]_i_1_n_2 ,\derivative_reg[24]_i_2_n_4 }),
        .O({\NLW_derivative_reg[23]_i_1_O_UNCONNECTED [3:1],\derivative_reg[23]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[23]_i_3_n_0 ,\derivative[23]_i_4_n_0 }));
  CARRY4 \derivative_reg[23]_i_10 
       (.CI(\derivative_reg[23]_i_15_n_0 ),
        .CO({\derivative_reg[23]_i_10_n_0 ,\derivative_reg[23]_i_10_n_1 ,\derivative_reg[23]_i_10_n_2 ,\derivative_reg[23]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[24]_i_10_n_5 ,\derivative_reg[24]_i_10_n_6 ,\derivative_reg[24]_i_10_n_7 ,\derivative_reg[24]_i_15_n_4 }),
        .O({\derivative_reg[23]_i_10_n_4 ,\derivative_reg[23]_i_10_n_5 ,\derivative_reg[23]_i_10_n_6 ,\derivative_reg[23]_i_10_n_7 }),
        .S({\derivative[23]_i_16_n_0 ,\derivative[23]_i_17_n_0 ,\derivative[23]_i_18_n_0 ,\derivative[23]_i_19_n_0 }));
  CARRY4 \derivative_reg[23]_i_15 
       (.CI(\derivative_reg[23]_i_20_n_0 ),
        .CO({\derivative_reg[23]_i_15_n_0 ,\derivative_reg[23]_i_15_n_1 ,\derivative_reg[23]_i_15_n_2 ,\derivative_reg[23]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[24]_i_15_n_5 ,\derivative_reg[24]_i_15_n_6 ,\derivative_reg[24]_i_15_n_7 ,\derivative_reg[24]_i_20_n_4 }),
        .O({\derivative_reg[23]_i_15_n_4 ,\derivative_reg[23]_i_15_n_5 ,\derivative_reg[23]_i_15_n_6 ,\derivative_reg[23]_i_15_n_7 }),
        .S({\derivative[23]_i_21_n_0 ,\derivative[23]_i_22_n_0 ,\derivative[23]_i_23_n_0 ,\derivative[23]_i_24_n_0 }));
  CARRY4 \derivative_reg[23]_i_2 
       (.CI(\derivative_reg[23]_i_5_n_0 ),
        .CO({\derivative_reg[23]_i_2_n_0 ,\derivative_reg[23]_i_2_n_1 ,\derivative_reg[23]_i_2_n_2 ,\derivative_reg[23]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[24]_i_2_n_5 ,\derivative_reg[24]_i_2_n_6 ,\derivative_reg[24]_i_2_n_7 ,\derivative_reg[24]_i_5_n_4 }),
        .O({\derivative_reg[23]_i_2_n_4 ,\derivative_reg[23]_i_2_n_5 ,\derivative_reg[23]_i_2_n_6 ,\derivative_reg[23]_i_2_n_7 }),
        .S({\derivative[23]_i_6_n_0 ,\derivative[23]_i_7_n_0 ,\derivative[23]_i_8_n_0 ,\derivative[23]_i_9_n_0 }));
  CARRY4 \derivative_reg[23]_i_20 
       (.CI(\derivative_reg[23]_i_25_n_0 ),
        .CO({\derivative_reg[23]_i_20_n_0 ,\derivative_reg[23]_i_20_n_1 ,\derivative_reg[23]_i_20_n_2 ,\derivative_reg[23]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[24]_i_20_n_5 ,\derivative_reg[24]_i_20_n_6 ,\derivative_reg[24]_i_20_n_7 ,\derivative_reg[24]_i_25_n_4 }),
        .O({\derivative_reg[23]_i_20_n_4 ,\derivative_reg[23]_i_20_n_5 ,\derivative_reg[23]_i_20_n_6 ,\derivative_reg[23]_i_20_n_7 }),
        .S({\derivative[23]_i_26_n_0 ,\derivative[23]_i_27_n_0 ,\derivative[23]_i_28_n_0 ,\derivative[23]_i_29_n_0 }));
  CARRY4 \derivative_reg[23]_i_25 
       (.CI(\derivative_reg[23]_i_30_n_0 ),
        .CO({\derivative_reg[23]_i_25_n_0 ,\derivative_reg[23]_i_25_n_1 ,\derivative_reg[23]_i_25_n_2 ,\derivative_reg[23]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[24]_i_25_n_5 ,\derivative_reg[24]_i_25_n_6 ,\derivative_reg[24]_i_25_n_7 ,\derivative_reg[24]_i_30_n_4 }),
        .O({\derivative_reg[23]_i_25_n_4 ,\derivative_reg[23]_i_25_n_5 ,\derivative_reg[23]_i_25_n_6 ,\derivative_reg[23]_i_25_n_7 }),
        .S({\derivative[23]_i_31_n_0 ,\derivative[23]_i_32_n_0 ,\derivative[23]_i_33_n_0 ,\derivative[23]_i_34_n_0 }));
  CARRY4 \derivative_reg[23]_i_30 
       (.CI(\derivative_reg[23]_i_35_n_0 ),
        .CO({\derivative_reg[23]_i_30_n_0 ,\derivative_reg[23]_i_30_n_1 ,\derivative_reg[23]_i_30_n_2 ,\derivative_reg[23]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[24]_i_30_n_5 ,\derivative_reg[24]_i_30_n_6 ,\derivative_reg[24]_i_30_n_7 ,\derivative_reg[24]_i_35_n_4 }),
        .O({\derivative_reg[23]_i_30_n_4 ,\derivative_reg[23]_i_30_n_5 ,\derivative_reg[23]_i_30_n_6 ,\derivative_reg[23]_i_30_n_7 }),
        .S({\derivative[23]_i_36_n_0 ,\derivative[23]_i_37_n_0 ,\derivative[23]_i_38_n_0 ,\derivative[23]_i_39_n_0 }));
  CARRY4 \derivative_reg[23]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[23]_i_35_n_0 ,\derivative_reg[23]_i_35_n_1 ,\derivative_reg[23]_i_35_n_2 ,\derivative_reg[23]_i_35_n_3 }),
        .CYINIT(\derivative_reg[24]_i_1_n_2 ),
        .DI({\derivative_reg[24]_i_35_n_5 ,\derivative_reg[24]_i_35_n_6 ,derivative11_out[23],1'b0}),
        .O({\derivative_reg[23]_i_35_n_4 ,\derivative_reg[23]_i_35_n_5 ,\derivative_reg[23]_i_35_n_6 ,\NLW_derivative_reg[23]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[23]_i_40_n_0 ,\derivative[23]_i_41_n_0 ,\derivative[23]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[23]_i_5 
       (.CI(\derivative_reg[23]_i_10_n_0 ),
        .CO({\derivative_reg[23]_i_5_n_0 ,\derivative_reg[23]_i_5_n_1 ,\derivative_reg[23]_i_5_n_2 ,\derivative_reg[23]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[24]_i_5_n_5 ,\derivative_reg[24]_i_5_n_6 ,\derivative_reg[24]_i_5_n_7 ,\derivative_reg[24]_i_10_n_4 }),
        .O({\derivative_reg[23]_i_5_n_4 ,\derivative_reg[23]_i_5_n_5 ,\derivative_reg[23]_i_5_n_6 ,\derivative_reg[23]_i_5_n_7 }),
        .S({\derivative[23]_i_11_n_0 ,\derivative[23]_i_12_n_0 ,\derivative[23]_i_13_n_0 ,\derivative[23]_i_14_n_0 }));
  FDRE \derivative_reg[24] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[24]_i_1_n_2 ),
        .Q(derivative_out[24]),
        .R(1'b0));
  CARRY4 \derivative_reg[24]_i_1 
       (.CI(\derivative_reg[24]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[24]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[24]_i_1_n_2 ,\derivative_reg[24]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[25]_i_1_n_2 ,\derivative_reg[25]_i_2_n_4 }),
        .O({\NLW_derivative_reg[24]_i_1_O_UNCONNECTED [3:1],\derivative_reg[24]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[24]_i_3_n_0 ,\derivative[24]_i_4_n_0 }));
  CARRY4 \derivative_reg[24]_i_10 
       (.CI(\derivative_reg[24]_i_15_n_0 ),
        .CO({\derivative_reg[24]_i_10_n_0 ,\derivative_reg[24]_i_10_n_1 ,\derivative_reg[24]_i_10_n_2 ,\derivative_reg[24]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[25]_i_10_n_5 ,\derivative_reg[25]_i_10_n_6 ,\derivative_reg[25]_i_10_n_7 ,\derivative_reg[25]_i_15_n_4 }),
        .O({\derivative_reg[24]_i_10_n_4 ,\derivative_reg[24]_i_10_n_5 ,\derivative_reg[24]_i_10_n_6 ,\derivative_reg[24]_i_10_n_7 }),
        .S({\derivative[24]_i_16_n_0 ,\derivative[24]_i_17_n_0 ,\derivative[24]_i_18_n_0 ,\derivative[24]_i_19_n_0 }));
  CARRY4 \derivative_reg[24]_i_15 
       (.CI(\derivative_reg[24]_i_20_n_0 ),
        .CO({\derivative_reg[24]_i_15_n_0 ,\derivative_reg[24]_i_15_n_1 ,\derivative_reg[24]_i_15_n_2 ,\derivative_reg[24]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[25]_i_15_n_5 ,\derivative_reg[25]_i_15_n_6 ,\derivative_reg[25]_i_15_n_7 ,\derivative_reg[25]_i_20_n_4 }),
        .O({\derivative_reg[24]_i_15_n_4 ,\derivative_reg[24]_i_15_n_5 ,\derivative_reg[24]_i_15_n_6 ,\derivative_reg[24]_i_15_n_7 }),
        .S({\derivative[24]_i_21_n_0 ,\derivative[24]_i_22_n_0 ,\derivative[24]_i_23_n_0 ,\derivative[24]_i_24_n_0 }));
  CARRY4 \derivative_reg[24]_i_2 
       (.CI(\derivative_reg[24]_i_5_n_0 ),
        .CO({\derivative_reg[24]_i_2_n_0 ,\derivative_reg[24]_i_2_n_1 ,\derivative_reg[24]_i_2_n_2 ,\derivative_reg[24]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[25]_i_2_n_5 ,\derivative_reg[25]_i_2_n_6 ,\derivative_reg[25]_i_2_n_7 ,\derivative_reg[25]_i_5_n_4 }),
        .O({\derivative_reg[24]_i_2_n_4 ,\derivative_reg[24]_i_2_n_5 ,\derivative_reg[24]_i_2_n_6 ,\derivative_reg[24]_i_2_n_7 }),
        .S({\derivative[24]_i_6_n_0 ,\derivative[24]_i_7_n_0 ,\derivative[24]_i_8_n_0 ,\derivative[24]_i_9_n_0 }));
  CARRY4 \derivative_reg[24]_i_20 
       (.CI(\derivative_reg[24]_i_25_n_0 ),
        .CO({\derivative_reg[24]_i_20_n_0 ,\derivative_reg[24]_i_20_n_1 ,\derivative_reg[24]_i_20_n_2 ,\derivative_reg[24]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[25]_i_20_n_5 ,\derivative_reg[25]_i_20_n_6 ,\derivative_reg[25]_i_20_n_7 ,\derivative_reg[25]_i_25_n_4 }),
        .O({\derivative_reg[24]_i_20_n_4 ,\derivative_reg[24]_i_20_n_5 ,\derivative_reg[24]_i_20_n_6 ,\derivative_reg[24]_i_20_n_7 }),
        .S({\derivative[24]_i_26_n_0 ,\derivative[24]_i_27_n_0 ,\derivative[24]_i_28_n_0 ,\derivative[24]_i_29_n_0 }));
  CARRY4 \derivative_reg[24]_i_25 
       (.CI(\derivative_reg[24]_i_30_n_0 ),
        .CO({\derivative_reg[24]_i_25_n_0 ,\derivative_reg[24]_i_25_n_1 ,\derivative_reg[24]_i_25_n_2 ,\derivative_reg[24]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[25]_i_25_n_5 ,\derivative_reg[25]_i_25_n_6 ,\derivative_reg[25]_i_25_n_7 ,\derivative_reg[25]_i_30_n_4 }),
        .O({\derivative_reg[24]_i_25_n_4 ,\derivative_reg[24]_i_25_n_5 ,\derivative_reg[24]_i_25_n_6 ,\derivative_reg[24]_i_25_n_7 }),
        .S({\derivative[24]_i_31_n_0 ,\derivative[24]_i_32_n_0 ,\derivative[24]_i_33_n_0 ,\derivative[24]_i_34_n_0 }));
  CARRY4 \derivative_reg[24]_i_30 
       (.CI(\derivative_reg[24]_i_35_n_0 ),
        .CO({\derivative_reg[24]_i_30_n_0 ,\derivative_reg[24]_i_30_n_1 ,\derivative_reg[24]_i_30_n_2 ,\derivative_reg[24]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[25]_i_30_n_5 ,\derivative_reg[25]_i_30_n_6 ,\derivative_reg[25]_i_30_n_7 ,\derivative_reg[25]_i_35_n_4 }),
        .O({\derivative_reg[24]_i_30_n_4 ,\derivative_reg[24]_i_30_n_5 ,\derivative_reg[24]_i_30_n_6 ,\derivative_reg[24]_i_30_n_7 }),
        .S({\derivative[24]_i_36_n_0 ,\derivative[24]_i_37_n_0 ,\derivative[24]_i_38_n_0 ,\derivative[24]_i_39_n_0 }));
  CARRY4 \derivative_reg[24]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[24]_i_35_n_0 ,\derivative_reg[24]_i_35_n_1 ,\derivative_reg[24]_i_35_n_2 ,\derivative_reg[24]_i_35_n_3 }),
        .CYINIT(\derivative_reg[25]_i_1_n_2 ),
        .DI({\derivative_reg[25]_i_35_n_5 ,\derivative_reg[25]_i_35_n_6 ,derivative11_out[24],1'b0}),
        .O({\derivative_reg[24]_i_35_n_4 ,\derivative_reg[24]_i_35_n_5 ,\derivative_reg[24]_i_35_n_6 ,\NLW_derivative_reg[24]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[24]_i_40_n_0 ,\derivative[24]_i_41_n_0 ,\derivative[24]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[24]_i_5 
       (.CI(\derivative_reg[24]_i_10_n_0 ),
        .CO({\derivative_reg[24]_i_5_n_0 ,\derivative_reg[24]_i_5_n_1 ,\derivative_reg[24]_i_5_n_2 ,\derivative_reg[24]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[25]_i_5_n_5 ,\derivative_reg[25]_i_5_n_6 ,\derivative_reg[25]_i_5_n_7 ,\derivative_reg[25]_i_10_n_4 }),
        .O({\derivative_reg[24]_i_5_n_4 ,\derivative_reg[24]_i_5_n_5 ,\derivative_reg[24]_i_5_n_6 ,\derivative_reg[24]_i_5_n_7 }),
        .S({\derivative[24]_i_11_n_0 ,\derivative[24]_i_12_n_0 ,\derivative[24]_i_13_n_0 ,\derivative[24]_i_14_n_0 }));
  FDRE \derivative_reg[25] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[25]_i_1_n_2 ),
        .Q(derivative_out[25]),
        .R(1'b0));
  CARRY4 \derivative_reg[25]_i_1 
       (.CI(\derivative_reg[25]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[25]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[25]_i_1_n_2 ,\derivative_reg[25]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[26]_i_1_n_2 ,\derivative_reg[26]_i_2_n_4 }),
        .O({\NLW_derivative_reg[25]_i_1_O_UNCONNECTED [3:1],\derivative_reg[25]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[25]_i_3_n_0 ,\derivative[25]_i_4_n_0 }));
  CARRY4 \derivative_reg[25]_i_10 
       (.CI(\derivative_reg[25]_i_15_n_0 ),
        .CO({\derivative_reg[25]_i_10_n_0 ,\derivative_reg[25]_i_10_n_1 ,\derivative_reg[25]_i_10_n_2 ,\derivative_reg[25]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[26]_i_10_n_5 ,\derivative_reg[26]_i_10_n_6 ,\derivative_reg[26]_i_10_n_7 ,\derivative_reg[26]_i_15_n_4 }),
        .O({\derivative_reg[25]_i_10_n_4 ,\derivative_reg[25]_i_10_n_5 ,\derivative_reg[25]_i_10_n_6 ,\derivative_reg[25]_i_10_n_7 }),
        .S({\derivative[25]_i_16_n_0 ,\derivative[25]_i_17_n_0 ,\derivative[25]_i_18_n_0 ,\derivative[25]_i_19_n_0 }));
  CARRY4 \derivative_reg[25]_i_15 
       (.CI(\derivative_reg[25]_i_20_n_0 ),
        .CO({\derivative_reg[25]_i_15_n_0 ,\derivative_reg[25]_i_15_n_1 ,\derivative_reg[25]_i_15_n_2 ,\derivative_reg[25]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[26]_i_15_n_5 ,\derivative_reg[26]_i_15_n_6 ,\derivative_reg[26]_i_15_n_7 ,\derivative_reg[26]_i_20_n_4 }),
        .O({\derivative_reg[25]_i_15_n_4 ,\derivative_reg[25]_i_15_n_5 ,\derivative_reg[25]_i_15_n_6 ,\derivative_reg[25]_i_15_n_7 }),
        .S({\derivative[25]_i_21_n_0 ,\derivative[25]_i_22_n_0 ,\derivative[25]_i_23_n_0 ,\derivative[25]_i_24_n_0 }));
  CARRY4 \derivative_reg[25]_i_2 
       (.CI(\derivative_reg[25]_i_5_n_0 ),
        .CO({\derivative_reg[25]_i_2_n_0 ,\derivative_reg[25]_i_2_n_1 ,\derivative_reg[25]_i_2_n_2 ,\derivative_reg[25]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[26]_i_2_n_5 ,\derivative_reg[26]_i_2_n_6 ,\derivative_reg[26]_i_2_n_7 ,\derivative_reg[26]_i_5_n_4 }),
        .O({\derivative_reg[25]_i_2_n_4 ,\derivative_reg[25]_i_2_n_5 ,\derivative_reg[25]_i_2_n_6 ,\derivative_reg[25]_i_2_n_7 }),
        .S({\derivative[25]_i_6_n_0 ,\derivative[25]_i_7_n_0 ,\derivative[25]_i_8_n_0 ,\derivative[25]_i_9_n_0 }));
  CARRY4 \derivative_reg[25]_i_20 
       (.CI(\derivative_reg[25]_i_25_n_0 ),
        .CO({\derivative_reg[25]_i_20_n_0 ,\derivative_reg[25]_i_20_n_1 ,\derivative_reg[25]_i_20_n_2 ,\derivative_reg[25]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[26]_i_20_n_5 ,\derivative_reg[26]_i_20_n_6 ,\derivative_reg[26]_i_20_n_7 ,\derivative_reg[26]_i_25_n_4 }),
        .O({\derivative_reg[25]_i_20_n_4 ,\derivative_reg[25]_i_20_n_5 ,\derivative_reg[25]_i_20_n_6 ,\derivative_reg[25]_i_20_n_7 }),
        .S({\derivative[25]_i_26_n_0 ,\derivative[25]_i_27_n_0 ,\derivative[25]_i_28_n_0 ,\derivative[25]_i_29_n_0 }));
  CARRY4 \derivative_reg[25]_i_25 
       (.CI(\derivative_reg[25]_i_30_n_0 ),
        .CO({\derivative_reg[25]_i_25_n_0 ,\derivative_reg[25]_i_25_n_1 ,\derivative_reg[25]_i_25_n_2 ,\derivative_reg[25]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[26]_i_25_n_5 ,\derivative_reg[26]_i_25_n_6 ,\derivative_reg[26]_i_25_n_7 ,\derivative_reg[26]_i_30_n_4 }),
        .O({\derivative_reg[25]_i_25_n_4 ,\derivative_reg[25]_i_25_n_5 ,\derivative_reg[25]_i_25_n_6 ,\derivative_reg[25]_i_25_n_7 }),
        .S({\derivative[25]_i_31_n_0 ,\derivative[25]_i_32_n_0 ,\derivative[25]_i_33_n_0 ,\derivative[25]_i_34_n_0 }));
  CARRY4 \derivative_reg[25]_i_30 
       (.CI(\derivative_reg[25]_i_35_n_0 ),
        .CO({\derivative_reg[25]_i_30_n_0 ,\derivative_reg[25]_i_30_n_1 ,\derivative_reg[25]_i_30_n_2 ,\derivative_reg[25]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[26]_i_30_n_5 ,\derivative_reg[26]_i_30_n_6 ,\derivative_reg[26]_i_30_n_7 ,\derivative_reg[26]_i_35_n_4 }),
        .O({\derivative_reg[25]_i_30_n_4 ,\derivative_reg[25]_i_30_n_5 ,\derivative_reg[25]_i_30_n_6 ,\derivative_reg[25]_i_30_n_7 }),
        .S({\derivative[25]_i_36_n_0 ,\derivative[25]_i_37_n_0 ,\derivative[25]_i_38_n_0 ,\derivative[25]_i_39_n_0 }));
  CARRY4 \derivative_reg[25]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[25]_i_35_n_0 ,\derivative_reg[25]_i_35_n_1 ,\derivative_reg[25]_i_35_n_2 ,\derivative_reg[25]_i_35_n_3 }),
        .CYINIT(\derivative_reg[26]_i_1_n_2 ),
        .DI({\derivative_reg[26]_i_35_n_5 ,\derivative_reg[26]_i_35_n_6 ,derivative11_out[25],1'b0}),
        .O({\derivative_reg[25]_i_35_n_4 ,\derivative_reg[25]_i_35_n_5 ,\derivative_reg[25]_i_35_n_6 ,\NLW_derivative_reg[25]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[25]_i_40_n_0 ,\derivative[25]_i_41_n_0 ,\derivative[25]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[25]_i_5 
       (.CI(\derivative_reg[25]_i_10_n_0 ),
        .CO({\derivative_reg[25]_i_5_n_0 ,\derivative_reg[25]_i_5_n_1 ,\derivative_reg[25]_i_5_n_2 ,\derivative_reg[25]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[26]_i_5_n_5 ,\derivative_reg[26]_i_5_n_6 ,\derivative_reg[26]_i_5_n_7 ,\derivative_reg[26]_i_10_n_4 }),
        .O({\derivative_reg[25]_i_5_n_4 ,\derivative_reg[25]_i_5_n_5 ,\derivative_reg[25]_i_5_n_6 ,\derivative_reg[25]_i_5_n_7 }),
        .S({\derivative[25]_i_11_n_0 ,\derivative[25]_i_12_n_0 ,\derivative[25]_i_13_n_0 ,\derivative[25]_i_14_n_0 }));
  FDRE \derivative_reg[26] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[26]_i_1_n_2 ),
        .Q(derivative_out[26]),
        .R(1'b0));
  CARRY4 \derivative_reg[26]_i_1 
       (.CI(\derivative_reg[26]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[26]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[26]_i_1_n_2 ,\derivative_reg[26]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[27]_i_1_n_2 ,\derivative_reg[27]_i_2_n_4 }),
        .O({\NLW_derivative_reg[26]_i_1_O_UNCONNECTED [3:1],\derivative_reg[26]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[26]_i_3_n_0 ,\derivative[26]_i_4_n_0 }));
  CARRY4 \derivative_reg[26]_i_10 
       (.CI(\derivative_reg[26]_i_15_n_0 ),
        .CO({\derivative_reg[26]_i_10_n_0 ,\derivative_reg[26]_i_10_n_1 ,\derivative_reg[26]_i_10_n_2 ,\derivative_reg[26]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_10_n_5 ,\derivative_reg[27]_i_10_n_6 ,\derivative_reg[27]_i_10_n_7 ,\derivative_reg[27]_i_15_n_4 }),
        .O({\derivative_reg[26]_i_10_n_4 ,\derivative_reg[26]_i_10_n_5 ,\derivative_reg[26]_i_10_n_6 ,\derivative_reg[26]_i_10_n_7 }),
        .S({\derivative[26]_i_16_n_0 ,\derivative[26]_i_17_n_0 ,\derivative[26]_i_18_n_0 ,\derivative[26]_i_19_n_0 }));
  CARRY4 \derivative_reg[26]_i_15 
       (.CI(\derivative_reg[26]_i_20_n_0 ),
        .CO({\derivative_reg[26]_i_15_n_0 ,\derivative_reg[26]_i_15_n_1 ,\derivative_reg[26]_i_15_n_2 ,\derivative_reg[26]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_15_n_5 ,\derivative_reg[27]_i_15_n_6 ,\derivative_reg[27]_i_15_n_7 ,\derivative_reg[27]_i_20_n_4 }),
        .O({\derivative_reg[26]_i_15_n_4 ,\derivative_reg[26]_i_15_n_5 ,\derivative_reg[26]_i_15_n_6 ,\derivative_reg[26]_i_15_n_7 }),
        .S({\derivative[26]_i_21_n_0 ,\derivative[26]_i_22_n_0 ,\derivative[26]_i_23_n_0 ,\derivative[26]_i_24_n_0 }));
  CARRY4 \derivative_reg[26]_i_2 
       (.CI(\derivative_reg[26]_i_5_n_0 ),
        .CO({\derivative_reg[26]_i_2_n_0 ,\derivative_reg[26]_i_2_n_1 ,\derivative_reg[26]_i_2_n_2 ,\derivative_reg[26]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_2_n_5 ,\derivative_reg[27]_i_2_n_6 ,\derivative_reg[27]_i_2_n_7 ,\derivative_reg[27]_i_5_n_4 }),
        .O({\derivative_reg[26]_i_2_n_4 ,\derivative_reg[26]_i_2_n_5 ,\derivative_reg[26]_i_2_n_6 ,\derivative_reg[26]_i_2_n_7 }),
        .S({\derivative[26]_i_6_n_0 ,\derivative[26]_i_7_n_0 ,\derivative[26]_i_8_n_0 ,\derivative[26]_i_9_n_0 }));
  CARRY4 \derivative_reg[26]_i_20 
       (.CI(\derivative_reg[26]_i_25_n_0 ),
        .CO({\derivative_reg[26]_i_20_n_0 ,\derivative_reg[26]_i_20_n_1 ,\derivative_reg[26]_i_20_n_2 ,\derivative_reg[26]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_20_n_5 ,\derivative_reg[27]_i_20_n_6 ,\derivative_reg[27]_i_20_n_7 ,\derivative_reg[27]_i_25_n_4 }),
        .O({\derivative_reg[26]_i_20_n_4 ,\derivative_reg[26]_i_20_n_5 ,\derivative_reg[26]_i_20_n_6 ,\derivative_reg[26]_i_20_n_7 }),
        .S({\derivative[26]_i_26_n_0 ,\derivative[26]_i_27_n_0 ,\derivative[26]_i_28_n_0 ,\derivative[26]_i_29_n_0 }));
  CARRY4 \derivative_reg[26]_i_25 
       (.CI(\derivative_reg[26]_i_30_n_0 ),
        .CO({\derivative_reg[26]_i_25_n_0 ,\derivative_reg[26]_i_25_n_1 ,\derivative_reg[26]_i_25_n_2 ,\derivative_reg[26]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_25_n_5 ,\derivative_reg[27]_i_25_n_6 ,\derivative_reg[27]_i_25_n_7 ,\derivative_reg[27]_i_30_n_4 }),
        .O({\derivative_reg[26]_i_25_n_4 ,\derivative_reg[26]_i_25_n_5 ,\derivative_reg[26]_i_25_n_6 ,\derivative_reg[26]_i_25_n_7 }),
        .S({\derivative[26]_i_31_n_0 ,\derivative[26]_i_32_n_0 ,\derivative[26]_i_33_n_0 ,\derivative[26]_i_34_n_0 }));
  CARRY4 \derivative_reg[26]_i_30 
       (.CI(\derivative_reg[26]_i_35_n_0 ),
        .CO({\derivative_reg[26]_i_30_n_0 ,\derivative_reg[26]_i_30_n_1 ,\derivative_reg[26]_i_30_n_2 ,\derivative_reg[26]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_30_n_5 ,\derivative_reg[27]_i_30_n_6 ,\derivative_reg[27]_i_30_n_7 ,\derivative_reg[27]_i_35_n_4 }),
        .O({\derivative_reg[26]_i_30_n_4 ,\derivative_reg[26]_i_30_n_5 ,\derivative_reg[26]_i_30_n_6 ,\derivative_reg[26]_i_30_n_7 }),
        .S({\derivative[26]_i_36_n_0 ,\derivative[26]_i_37_n_0 ,\derivative[26]_i_38_n_0 ,\derivative[26]_i_39_n_0 }));
  CARRY4 \derivative_reg[26]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[26]_i_35_n_0 ,\derivative_reg[26]_i_35_n_1 ,\derivative_reg[26]_i_35_n_2 ,\derivative_reg[26]_i_35_n_3 }),
        .CYINIT(\derivative_reg[27]_i_1_n_2 ),
        .DI({\derivative_reg[27]_i_35_n_5 ,\derivative_reg[27]_i_35_n_6 ,derivative11_out[26],1'b0}),
        .O({\derivative_reg[26]_i_35_n_4 ,\derivative_reg[26]_i_35_n_5 ,\derivative_reg[26]_i_35_n_6 ,\NLW_derivative_reg[26]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[26]_i_40_n_0 ,\derivative[26]_i_41_n_0 ,\derivative[26]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[26]_i_5 
       (.CI(\derivative_reg[26]_i_10_n_0 ),
        .CO({\derivative_reg[26]_i_5_n_0 ,\derivative_reg[26]_i_5_n_1 ,\derivative_reg[26]_i_5_n_2 ,\derivative_reg[26]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_5_n_5 ,\derivative_reg[27]_i_5_n_6 ,\derivative_reg[27]_i_5_n_7 ,\derivative_reg[27]_i_10_n_4 }),
        .O({\derivative_reg[26]_i_5_n_4 ,\derivative_reg[26]_i_5_n_5 ,\derivative_reg[26]_i_5_n_6 ,\derivative_reg[26]_i_5_n_7 }),
        .S({\derivative[26]_i_11_n_0 ,\derivative[26]_i_12_n_0 ,\derivative[26]_i_13_n_0 ,\derivative[26]_i_14_n_0 }));
  FDRE \derivative_reg[27] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[27]_i_1_n_2 ),
        .Q(derivative_out[27]),
        .R(1'b0));
  CARRY4 \derivative_reg[27]_i_1 
       (.CI(\derivative_reg[27]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[27]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[27]_i_1_n_2 ,\derivative_reg[27]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[28]_i_1_n_2 ,\derivative_reg[28]_i_2_n_4 }),
        .O({\NLW_derivative_reg[27]_i_1_O_UNCONNECTED [3:1],\derivative_reg[27]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[27]_i_3_n_0 ,\derivative[27]_i_4_n_0 }));
  CARRY4 \derivative_reg[27]_i_10 
       (.CI(\derivative_reg[27]_i_15_n_0 ),
        .CO({\derivative_reg[27]_i_10_n_0 ,\derivative_reg[27]_i_10_n_1 ,\derivative_reg[27]_i_10_n_2 ,\derivative_reg[27]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[28]_i_10_n_5 ,\derivative_reg[28]_i_10_n_6 ,\derivative_reg[28]_i_10_n_7 ,\derivative_reg[28]_i_15_n_4 }),
        .O({\derivative_reg[27]_i_10_n_4 ,\derivative_reg[27]_i_10_n_5 ,\derivative_reg[27]_i_10_n_6 ,\derivative_reg[27]_i_10_n_7 }),
        .S({\derivative[27]_i_16_n_0 ,\derivative[27]_i_17_n_0 ,\derivative[27]_i_18_n_0 ,\derivative[27]_i_19_n_0 }));
  CARRY4 \derivative_reg[27]_i_15 
       (.CI(\derivative_reg[27]_i_20_n_0 ),
        .CO({\derivative_reg[27]_i_15_n_0 ,\derivative_reg[27]_i_15_n_1 ,\derivative_reg[27]_i_15_n_2 ,\derivative_reg[27]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[28]_i_15_n_5 ,\derivative_reg[28]_i_15_n_6 ,\derivative_reg[28]_i_15_n_7 ,\derivative_reg[28]_i_20_n_4 }),
        .O({\derivative_reg[27]_i_15_n_4 ,\derivative_reg[27]_i_15_n_5 ,\derivative_reg[27]_i_15_n_6 ,\derivative_reg[27]_i_15_n_7 }),
        .S({\derivative[27]_i_21_n_0 ,\derivative[27]_i_22_n_0 ,\derivative[27]_i_23_n_0 ,\derivative[27]_i_24_n_0 }));
  CARRY4 \derivative_reg[27]_i_2 
       (.CI(\derivative_reg[27]_i_5_n_0 ),
        .CO({\derivative_reg[27]_i_2_n_0 ,\derivative_reg[27]_i_2_n_1 ,\derivative_reg[27]_i_2_n_2 ,\derivative_reg[27]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[28]_i_2_n_5 ,\derivative_reg[28]_i_2_n_6 ,\derivative_reg[28]_i_2_n_7 ,\derivative_reg[28]_i_5_n_4 }),
        .O({\derivative_reg[27]_i_2_n_4 ,\derivative_reg[27]_i_2_n_5 ,\derivative_reg[27]_i_2_n_6 ,\derivative_reg[27]_i_2_n_7 }),
        .S({\derivative[27]_i_6_n_0 ,\derivative[27]_i_7_n_0 ,\derivative[27]_i_8_n_0 ,\derivative[27]_i_9_n_0 }));
  CARRY4 \derivative_reg[27]_i_20 
       (.CI(\derivative_reg[27]_i_25_n_0 ),
        .CO({\derivative_reg[27]_i_20_n_0 ,\derivative_reg[27]_i_20_n_1 ,\derivative_reg[27]_i_20_n_2 ,\derivative_reg[27]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[28]_i_20_n_5 ,\derivative_reg[28]_i_20_n_6 ,\derivative_reg[28]_i_20_n_7 ,\derivative_reg[28]_i_25_n_4 }),
        .O({\derivative_reg[27]_i_20_n_4 ,\derivative_reg[27]_i_20_n_5 ,\derivative_reg[27]_i_20_n_6 ,\derivative_reg[27]_i_20_n_7 }),
        .S({\derivative[27]_i_26_n_0 ,\derivative[27]_i_27_n_0 ,\derivative[27]_i_28_n_0 ,\derivative[27]_i_29_n_0 }));
  CARRY4 \derivative_reg[27]_i_25 
       (.CI(\derivative_reg[27]_i_30_n_0 ),
        .CO({\derivative_reg[27]_i_25_n_0 ,\derivative_reg[27]_i_25_n_1 ,\derivative_reg[27]_i_25_n_2 ,\derivative_reg[27]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[28]_i_25_n_5 ,\derivative_reg[28]_i_25_n_6 ,\derivative_reg[28]_i_25_n_7 ,\derivative_reg[28]_i_30_n_4 }),
        .O({\derivative_reg[27]_i_25_n_4 ,\derivative_reg[27]_i_25_n_5 ,\derivative_reg[27]_i_25_n_6 ,\derivative_reg[27]_i_25_n_7 }),
        .S({\derivative[27]_i_31_n_0 ,\derivative[27]_i_32_n_0 ,\derivative[27]_i_33_n_0 ,\derivative[27]_i_34_n_0 }));
  CARRY4 \derivative_reg[27]_i_30 
       (.CI(\derivative_reg[27]_i_35_n_0 ),
        .CO({\derivative_reg[27]_i_30_n_0 ,\derivative_reg[27]_i_30_n_1 ,\derivative_reg[27]_i_30_n_2 ,\derivative_reg[27]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[28]_i_30_n_5 ,\derivative_reg[28]_i_30_n_6 ,\derivative_reg[28]_i_30_n_7 ,\derivative_reg[28]_i_35_n_4 }),
        .O({\derivative_reg[27]_i_30_n_4 ,\derivative_reg[27]_i_30_n_5 ,\derivative_reg[27]_i_30_n_6 ,\derivative_reg[27]_i_30_n_7 }),
        .S({\derivative[27]_i_36_n_0 ,\derivative[27]_i_37_n_0 ,\derivative[27]_i_38_n_0 ,\derivative[27]_i_39_n_0 }));
  CARRY4 \derivative_reg[27]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[27]_i_35_n_0 ,\derivative_reg[27]_i_35_n_1 ,\derivative_reg[27]_i_35_n_2 ,\derivative_reg[27]_i_35_n_3 }),
        .CYINIT(\derivative_reg[28]_i_1_n_2 ),
        .DI({\derivative_reg[28]_i_35_n_5 ,\derivative_reg[28]_i_35_n_6 ,derivative11_out[27],1'b0}),
        .O({\derivative_reg[27]_i_35_n_4 ,\derivative_reg[27]_i_35_n_5 ,\derivative_reg[27]_i_35_n_6 ,\NLW_derivative_reg[27]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[27]_i_40_n_0 ,\derivative[27]_i_41_n_0 ,\derivative[27]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[27]_i_5 
       (.CI(\derivative_reg[27]_i_10_n_0 ),
        .CO({\derivative_reg[27]_i_5_n_0 ,\derivative_reg[27]_i_5_n_1 ,\derivative_reg[27]_i_5_n_2 ,\derivative_reg[27]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[28]_i_5_n_5 ,\derivative_reg[28]_i_5_n_6 ,\derivative_reg[28]_i_5_n_7 ,\derivative_reg[28]_i_10_n_4 }),
        .O({\derivative_reg[27]_i_5_n_4 ,\derivative_reg[27]_i_5_n_5 ,\derivative_reg[27]_i_5_n_6 ,\derivative_reg[27]_i_5_n_7 }),
        .S({\derivative[27]_i_11_n_0 ,\derivative[27]_i_12_n_0 ,\derivative[27]_i_13_n_0 ,\derivative[27]_i_14_n_0 }));
  FDRE \derivative_reg[28] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[28]_i_1_n_2 ),
        .Q(derivative_out[28]),
        .R(1'b0));
  CARRY4 \derivative_reg[28]_i_1 
       (.CI(\derivative_reg[28]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[28]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[28]_i_1_n_2 ,\derivative_reg[28]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[29]_i_1_n_2 ,\derivative_reg[29]_i_2_n_4 }),
        .O({\NLW_derivative_reg[28]_i_1_O_UNCONNECTED [3:1],\derivative_reg[28]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[28]_i_3_n_0 ,\derivative[28]_i_4_n_0 }));
  CARRY4 \derivative_reg[28]_i_10 
       (.CI(\derivative_reg[28]_i_15_n_0 ),
        .CO({\derivative_reg[28]_i_10_n_0 ,\derivative_reg[28]_i_10_n_1 ,\derivative_reg[28]_i_10_n_2 ,\derivative_reg[28]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[29]_i_10_n_5 ,\derivative_reg[29]_i_10_n_6 ,\derivative_reg[29]_i_10_n_7 ,\derivative_reg[29]_i_15_n_4 }),
        .O({\derivative_reg[28]_i_10_n_4 ,\derivative_reg[28]_i_10_n_5 ,\derivative_reg[28]_i_10_n_6 ,\derivative_reg[28]_i_10_n_7 }),
        .S({\derivative[28]_i_16_n_0 ,\derivative[28]_i_17_n_0 ,\derivative[28]_i_18_n_0 ,\derivative[28]_i_19_n_0 }));
  CARRY4 \derivative_reg[28]_i_15 
       (.CI(\derivative_reg[28]_i_20_n_0 ),
        .CO({\derivative_reg[28]_i_15_n_0 ,\derivative_reg[28]_i_15_n_1 ,\derivative_reg[28]_i_15_n_2 ,\derivative_reg[28]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[29]_i_15_n_5 ,\derivative_reg[29]_i_15_n_6 ,\derivative_reg[29]_i_15_n_7 ,\derivative_reg[29]_i_20_n_4 }),
        .O({\derivative_reg[28]_i_15_n_4 ,\derivative_reg[28]_i_15_n_5 ,\derivative_reg[28]_i_15_n_6 ,\derivative_reg[28]_i_15_n_7 }),
        .S({\derivative[28]_i_21_n_0 ,\derivative[28]_i_22_n_0 ,\derivative[28]_i_23_n_0 ,\derivative[28]_i_24_n_0 }));
  CARRY4 \derivative_reg[28]_i_2 
       (.CI(\derivative_reg[28]_i_5_n_0 ),
        .CO({\derivative_reg[28]_i_2_n_0 ,\derivative_reg[28]_i_2_n_1 ,\derivative_reg[28]_i_2_n_2 ,\derivative_reg[28]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[29]_i_2_n_5 ,\derivative_reg[29]_i_2_n_6 ,\derivative_reg[29]_i_2_n_7 ,\derivative_reg[29]_i_5_n_4 }),
        .O({\derivative_reg[28]_i_2_n_4 ,\derivative_reg[28]_i_2_n_5 ,\derivative_reg[28]_i_2_n_6 ,\derivative_reg[28]_i_2_n_7 }),
        .S({\derivative[28]_i_6_n_0 ,\derivative[28]_i_7_n_0 ,\derivative[28]_i_8_n_0 ,\derivative[28]_i_9_n_0 }));
  CARRY4 \derivative_reg[28]_i_20 
       (.CI(\derivative_reg[28]_i_25_n_0 ),
        .CO({\derivative_reg[28]_i_20_n_0 ,\derivative_reg[28]_i_20_n_1 ,\derivative_reg[28]_i_20_n_2 ,\derivative_reg[28]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[29]_i_20_n_5 ,\derivative_reg[29]_i_20_n_6 ,\derivative_reg[29]_i_20_n_7 ,\derivative_reg[29]_i_25_n_4 }),
        .O({\derivative_reg[28]_i_20_n_4 ,\derivative_reg[28]_i_20_n_5 ,\derivative_reg[28]_i_20_n_6 ,\derivative_reg[28]_i_20_n_7 }),
        .S({\derivative[28]_i_26_n_0 ,\derivative[28]_i_27_n_0 ,\derivative[28]_i_28_n_0 ,\derivative[28]_i_29_n_0 }));
  CARRY4 \derivative_reg[28]_i_25 
       (.CI(\derivative_reg[28]_i_30_n_0 ),
        .CO({\derivative_reg[28]_i_25_n_0 ,\derivative_reg[28]_i_25_n_1 ,\derivative_reg[28]_i_25_n_2 ,\derivative_reg[28]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[29]_i_25_n_5 ,\derivative_reg[29]_i_25_n_6 ,\derivative_reg[29]_i_25_n_7 ,\derivative_reg[29]_i_30_n_4 }),
        .O({\derivative_reg[28]_i_25_n_4 ,\derivative_reg[28]_i_25_n_5 ,\derivative_reg[28]_i_25_n_6 ,\derivative_reg[28]_i_25_n_7 }),
        .S({\derivative[28]_i_31_n_0 ,\derivative[28]_i_32_n_0 ,\derivative[28]_i_33_n_0 ,\derivative[28]_i_34_n_0 }));
  CARRY4 \derivative_reg[28]_i_30 
       (.CI(\derivative_reg[28]_i_35_n_0 ),
        .CO({\derivative_reg[28]_i_30_n_0 ,\derivative_reg[28]_i_30_n_1 ,\derivative_reg[28]_i_30_n_2 ,\derivative_reg[28]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[29]_i_30_n_5 ,\derivative_reg[29]_i_30_n_6 ,\derivative_reg[29]_i_30_n_7 ,\derivative_reg[29]_i_35_n_4 }),
        .O({\derivative_reg[28]_i_30_n_4 ,\derivative_reg[28]_i_30_n_5 ,\derivative_reg[28]_i_30_n_6 ,\derivative_reg[28]_i_30_n_7 }),
        .S({\derivative[28]_i_36_n_0 ,\derivative[28]_i_37_n_0 ,\derivative[28]_i_38_n_0 ,\derivative[28]_i_39_n_0 }));
  CARRY4 \derivative_reg[28]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[28]_i_35_n_0 ,\derivative_reg[28]_i_35_n_1 ,\derivative_reg[28]_i_35_n_2 ,\derivative_reg[28]_i_35_n_3 }),
        .CYINIT(\derivative_reg[29]_i_1_n_2 ),
        .DI({\derivative_reg[29]_i_35_n_5 ,\derivative_reg[29]_i_35_n_6 ,derivative11_out[28],1'b0}),
        .O({\derivative_reg[28]_i_35_n_4 ,\derivative_reg[28]_i_35_n_5 ,\derivative_reg[28]_i_35_n_6 ,\NLW_derivative_reg[28]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[28]_i_40_n_0 ,\derivative[28]_i_41_n_0 ,\derivative[28]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[28]_i_5 
       (.CI(\derivative_reg[28]_i_10_n_0 ),
        .CO({\derivative_reg[28]_i_5_n_0 ,\derivative_reg[28]_i_5_n_1 ,\derivative_reg[28]_i_5_n_2 ,\derivative_reg[28]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[29]_i_5_n_5 ,\derivative_reg[29]_i_5_n_6 ,\derivative_reg[29]_i_5_n_7 ,\derivative_reg[29]_i_10_n_4 }),
        .O({\derivative_reg[28]_i_5_n_4 ,\derivative_reg[28]_i_5_n_5 ,\derivative_reg[28]_i_5_n_6 ,\derivative_reg[28]_i_5_n_7 }),
        .S({\derivative[28]_i_11_n_0 ,\derivative[28]_i_12_n_0 ,\derivative[28]_i_13_n_0 ,\derivative[28]_i_14_n_0 }));
  FDRE \derivative_reg[29] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[29]_i_1_n_2 ),
        .Q(derivative_out[29]),
        .R(1'b0));
  CARRY4 \derivative_reg[29]_i_1 
       (.CI(\derivative_reg[29]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[29]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[29]_i_1_n_2 ,\derivative_reg[29]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[30]_i_1_n_2 ,\derivative_reg[30]_i_2_n_4 }),
        .O({\NLW_derivative_reg[29]_i_1_O_UNCONNECTED [3:1],\derivative_reg[29]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[29]_i_3_n_0 ,\derivative[29]_i_4_n_0 }));
  CARRY4 \derivative_reg[29]_i_10 
       (.CI(\derivative_reg[29]_i_15_n_0 ),
        .CO({\derivative_reg[29]_i_10_n_0 ,\derivative_reg[29]_i_10_n_1 ,\derivative_reg[29]_i_10_n_2 ,\derivative_reg[29]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[30]_i_10_n_5 ,\derivative_reg[30]_i_10_n_6 ,\derivative_reg[30]_i_10_n_7 ,\derivative_reg[30]_i_15_n_4 }),
        .O({\derivative_reg[29]_i_10_n_4 ,\derivative_reg[29]_i_10_n_5 ,\derivative_reg[29]_i_10_n_6 ,\derivative_reg[29]_i_10_n_7 }),
        .S({\derivative[29]_i_16_n_0 ,\derivative[29]_i_17_n_0 ,\derivative[29]_i_18_n_0 ,\derivative[29]_i_19_n_0 }));
  CARRY4 \derivative_reg[29]_i_15 
       (.CI(\derivative_reg[29]_i_20_n_0 ),
        .CO({\derivative_reg[29]_i_15_n_0 ,\derivative_reg[29]_i_15_n_1 ,\derivative_reg[29]_i_15_n_2 ,\derivative_reg[29]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[30]_i_15_n_5 ,\derivative_reg[30]_i_15_n_6 ,\derivative_reg[30]_i_15_n_7 ,\derivative_reg[30]_i_20_n_4 }),
        .O({\derivative_reg[29]_i_15_n_4 ,\derivative_reg[29]_i_15_n_5 ,\derivative_reg[29]_i_15_n_6 ,\derivative_reg[29]_i_15_n_7 }),
        .S({\derivative[29]_i_21_n_0 ,\derivative[29]_i_22_n_0 ,\derivative[29]_i_23_n_0 ,\derivative[29]_i_24_n_0 }));
  CARRY4 \derivative_reg[29]_i_2 
       (.CI(\derivative_reg[29]_i_5_n_0 ),
        .CO({\derivative_reg[29]_i_2_n_0 ,\derivative_reg[29]_i_2_n_1 ,\derivative_reg[29]_i_2_n_2 ,\derivative_reg[29]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[30]_i_2_n_5 ,\derivative_reg[30]_i_2_n_6 ,\derivative_reg[30]_i_2_n_7 ,\derivative_reg[30]_i_5_n_4 }),
        .O({\derivative_reg[29]_i_2_n_4 ,\derivative_reg[29]_i_2_n_5 ,\derivative_reg[29]_i_2_n_6 ,\derivative_reg[29]_i_2_n_7 }),
        .S({\derivative[29]_i_6_n_0 ,\derivative[29]_i_7_n_0 ,\derivative[29]_i_8_n_0 ,\derivative[29]_i_9_n_0 }));
  CARRY4 \derivative_reg[29]_i_20 
       (.CI(\derivative_reg[29]_i_25_n_0 ),
        .CO({\derivative_reg[29]_i_20_n_0 ,\derivative_reg[29]_i_20_n_1 ,\derivative_reg[29]_i_20_n_2 ,\derivative_reg[29]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[30]_i_20_n_5 ,\derivative_reg[30]_i_20_n_6 ,\derivative_reg[30]_i_20_n_7 ,\derivative_reg[30]_i_25_n_4 }),
        .O({\derivative_reg[29]_i_20_n_4 ,\derivative_reg[29]_i_20_n_5 ,\derivative_reg[29]_i_20_n_6 ,\derivative_reg[29]_i_20_n_7 }),
        .S({\derivative[29]_i_26_n_0 ,\derivative[29]_i_27_n_0 ,\derivative[29]_i_28_n_0 ,\derivative[29]_i_29_n_0 }));
  CARRY4 \derivative_reg[29]_i_25 
       (.CI(\derivative_reg[29]_i_30_n_0 ),
        .CO({\derivative_reg[29]_i_25_n_0 ,\derivative_reg[29]_i_25_n_1 ,\derivative_reg[29]_i_25_n_2 ,\derivative_reg[29]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[30]_i_25_n_5 ,\derivative_reg[30]_i_25_n_6 ,\derivative_reg[30]_i_25_n_7 ,\derivative_reg[30]_i_30_n_4 }),
        .O({\derivative_reg[29]_i_25_n_4 ,\derivative_reg[29]_i_25_n_5 ,\derivative_reg[29]_i_25_n_6 ,\derivative_reg[29]_i_25_n_7 }),
        .S({\derivative[29]_i_31_n_0 ,\derivative[29]_i_32_n_0 ,\derivative[29]_i_33_n_0 ,\derivative[29]_i_34_n_0 }));
  CARRY4 \derivative_reg[29]_i_30 
       (.CI(\derivative_reg[29]_i_35_n_0 ),
        .CO({\derivative_reg[29]_i_30_n_0 ,\derivative_reg[29]_i_30_n_1 ,\derivative_reg[29]_i_30_n_2 ,\derivative_reg[29]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[30]_i_30_n_5 ,\derivative_reg[30]_i_30_n_6 ,\derivative_reg[30]_i_30_n_7 ,\derivative_reg[30]_i_35_n_4 }),
        .O({\derivative_reg[29]_i_30_n_4 ,\derivative_reg[29]_i_30_n_5 ,\derivative_reg[29]_i_30_n_6 ,\derivative_reg[29]_i_30_n_7 }),
        .S({\derivative[29]_i_36_n_0 ,\derivative[29]_i_37_n_0 ,\derivative[29]_i_38_n_0 ,\derivative[29]_i_39_n_0 }));
  CARRY4 \derivative_reg[29]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[29]_i_35_n_0 ,\derivative_reg[29]_i_35_n_1 ,\derivative_reg[29]_i_35_n_2 ,\derivative_reg[29]_i_35_n_3 }),
        .CYINIT(\derivative_reg[30]_i_1_n_2 ),
        .DI({\derivative_reg[30]_i_35_n_5 ,\derivative_reg[30]_i_35_n_6 ,derivative11_out[29],1'b0}),
        .O({\derivative_reg[29]_i_35_n_4 ,\derivative_reg[29]_i_35_n_5 ,\derivative_reg[29]_i_35_n_6 ,\NLW_derivative_reg[29]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[29]_i_40_n_0 ,\derivative[29]_i_41_n_0 ,\derivative[29]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[29]_i_5 
       (.CI(\derivative_reg[29]_i_10_n_0 ),
        .CO({\derivative_reg[29]_i_5_n_0 ,\derivative_reg[29]_i_5_n_1 ,\derivative_reg[29]_i_5_n_2 ,\derivative_reg[29]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[30]_i_5_n_5 ,\derivative_reg[30]_i_5_n_6 ,\derivative_reg[30]_i_5_n_7 ,\derivative_reg[30]_i_10_n_4 }),
        .O({\derivative_reg[29]_i_5_n_4 ,\derivative_reg[29]_i_5_n_5 ,\derivative_reg[29]_i_5_n_6 ,\derivative_reg[29]_i_5_n_7 }),
        .S({\derivative[29]_i_11_n_0 ,\derivative[29]_i_12_n_0 ,\derivative[29]_i_13_n_0 ,\derivative[29]_i_14_n_0 }));
  FDRE \derivative_reg[2] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[2]_i_1_n_2 ),
        .Q(derivative_out[2]),
        .R(1'b0));
  CARRY4 \derivative_reg[2]_i_1 
       (.CI(\derivative_reg[2]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[2]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[2]_i_1_n_2 ,\derivative_reg[2]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[3]_i_1_n_2 ,\derivative_reg[3]_i_2_n_4 }),
        .O({\NLW_derivative_reg[2]_i_1_O_UNCONNECTED [3:1],\derivative_reg[2]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[2]_i_3_n_0 ,\derivative[2]_i_4_n_0 }));
  CARRY4 \derivative_reg[2]_i_10 
       (.CI(\derivative_reg[2]_i_15_n_0 ),
        .CO({\derivative_reg[2]_i_10_n_0 ,\derivative_reg[2]_i_10_n_1 ,\derivative_reg[2]_i_10_n_2 ,\derivative_reg[2]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_10_n_5 ,\derivative_reg[3]_i_10_n_6 ,\derivative_reg[3]_i_10_n_7 ,\derivative_reg[3]_i_15_n_4 }),
        .O({\derivative_reg[2]_i_10_n_4 ,\derivative_reg[2]_i_10_n_5 ,\derivative_reg[2]_i_10_n_6 ,\derivative_reg[2]_i_10_n_7 }),
        .S({\derivative[2]_i_16_n_0 ,\derivative[2]_i_17_n_0 ,\derivative[2]_i_18_n_0 ,\derivative[2]_i_19_n_0 }));
  CARRY4 \derivative_reg[2]_i_15 
       (.CI(\derivative_reg[2]_i_20_n_0 ),
        .CO({\derivative_reg[2]_i_15_n_0 ,\derivative_reg[2]_i_15_n_1 ,\derivative_reg[2]_i_15_n_2 ,\derivative_reg[2]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_15_n_5 ,\derivative_reg[3]_i_15_n_6 ,\derivative_reg[3]_i_15_n_7 ,\derivative_reg[3]_i_20_n_4 }),
        .O({\derivative_reg[2]_i_15_n_4 ,\derivative_reg[2]_i_15_n_5 ,\derivative_reg[2]_i_15_n_6 ,\derivative_reg[2]_i_15_n_7 }),
        .S({\derivative[2]_i_21_n_0 ,\derivative[2]_i_22_n_0 ,\derivative[2]_i_23_n_0 ,\derivative[2]_i_24_n_0 }));
  CARRY4 \derivative_reg[2]_i_2 
       (.CI(\derivative_reg[2]_i_5_n_0 ),
        .CO({\derivative_reg[2]_i_2_n_0 ,\derivative_reg[2]_i_2_n_1 ,\derivative_reg[2]_i_2_n_2 ,\derivative_reg[2]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_2_n_5 ,\derivative_reg[3]_i_2_n_6 ,\derivative_reg[3]_i_2_n_7 ,\derivative_reg[3]_i_5_n_4 }),
        .O({\derivative_reg[2]_i_2_n_4 ,\derivative_reg[2]_i_2_n_5 ,\derivative_reg[2]_i_2_n_6 ,\derivative_reg[2]_i_2_n_7 }),
        .S({\derivative[2]_i_6_n_0 ,\derivative[2]_i_7_n_0 ,\derivative[2]_i_8_n_0 ,\derivative[2]_i_9_n_0 }));
  CARRY4 \derivative_reg[2]_i_20 
       (.CI(\derivative_reg[2]_i_25_n_0 ),
        .CO({\derivative_reg[2]_i_20_n_0 ,\derivative_reg[2]_i_20_n_1 ,\derivative_reg[2]_i_20_n_2 ,\derivative_reg[2]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_20_n_5 ,\derivative_reg[3]_i_20_n_6 ,\derivative_reg[3]_i_20_n_7 ,\derivative_reg[3]_i_25_n_4 }),
        .O({\derivative_reg[2]_i_20_n_4 ,\derivative_reg[2]_i_20_n_5 ,\derivative_reg[2]_i_20_n_6 ,\derivative_reg[2]_i_20_n_7 }),
        .S({\derivative[2]_i_26_n_0 ,\derivative[2]_i_27_n_0 ,\derivative[2]_i_28_n_0 ,\derivative[2]_i_29_n_0 }));
  CARRY4 \derivative_reg[2]_i_25 
       (.CI(\derivative_reg[2]_i_30_n_0 ),
        .CO({\derivative_reg[2]_i_25_n_0 ,\derivative_reg[2]_i_25_n_1 ,\derivative_reg[2]_i_25_n_2 ,\derivative_reg[2]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_25_n_5 ,\derivative_reg[3]_i_25_n_6 ,\derivative_reg[3]_i_25_n_7 ,\derivative_reg[3]_i_30_n_4 }),
        .O({\derivative_reg[2]_i_25_n_4 ,\derivative_reg[2]_i_25_n_5 ,\derivative_reg[2]_i_25_n_6 ,\derivative_reg[2]_i_25_n_7 }),
        .S({\derivative[2]_i_31_n_0 ,\derivative[2]_i_32_n_0 ,\derivative[2]_i_33_n_0 ,\derivative[2]_i_34_n_0 }));
  CARRY4 \derivative_reg[2]_i_30 
       (.CI(\derivative_reg[2]_i_35_n_0 ),
        .CO({\derivative_reg[2]_i_30_n_0 ,\derivative_reg[2]_i_30_n_1 ,\derivative_reg[2]_i_30_n_2 ,\derivative_reg[2]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_30_n_5 ,\derivative_reg[3]_i_30_n_6 ,\derivative_reg[3]_i_30_n_7 ,\derivative_reg[3]_i_35_n_4 }),
        .O({\derivative_reg[2]_i_30_n_4 ,\derivative_reg[2]_i_30_n_5 ,\derivative_reg[2]_i_30_n_6 ,\derivative_reg[2]_i_30_n_7 }),
        .S({\derivative[2]_i_36_n_0 ,\derivative[2]_i_37_n_0 ,\derivative[2]_i_38_n_0 ,\derivative[2]_i_39_n_0 }));
  CARRY4 \derivative_reg[2]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[2]_i_35_n_0 ,\derivative_reg[2]_i_35_n_1 ,\derivative_reg[2]_i_35_n_2 ,\derivative_reg[2]_i_35_n_3 }),
        .CYINIT(\derivative_reg[3]_i_1_n_2 ),
        .DI({\derivative_reg[3]_i_35_n_5 ,\derivative_reg[3]_i_35_n_6 ,derivative11_out[2],1'b0}),
        .O({\derivative_reg[2]_i_35_n_4 ,\derivative_reg[2]_i_35_n_5 ,\derivative_reg[2]_i_35_n_6 ,\NLW_derivative_reg[2]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[2]_i_40_n_0 ,\derivative[2]_i_41_n_0 ,\derivative[2]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[2]_i_5 
       (.CI(\derivative_reg[2]_i_10_n_0 ),
        .CO({\derivative_reg[2]_i_5_n_0 ,\derivative_reg[2]_i_5_n_1 ,\derivative_reg[2]_i_5_n_2 ,\derivative_reg[2]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_5_n_5 ,\derivative_reg[3]_i_5_n_6 ,\derivative_reg[3]_i_5_n_7 ,\derivative_reg[3]_i_10_n_4 }),
        .O({\derivative_reg[2]_i_5_n_4 ,\derivative_reg[2]_i_5_n_5 ,\derivative_reg[2]_i_5_n_6 ,\derivative_reg[2]_i_5_n_7 }),
        .S({\derivative[2]_i_11_n_0 ,\derivative[2]_i_12_n_0 ,\derivative[2]_i_13_n_0 ,\derivative[2]_i_14_n_0 }));
  FDRE \derivative_reg[30] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[30]_i_1_n_2 ),
        .Q(derivative_out[30]),
        .R(1'b0));
  CARRY4 \derivative_reg[30]_i_1 
       (.CI(\derivative_reg[30]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[30]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[30]_i_1_n_2 ,\derivative_reg[30]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[31]_i_1_n_3 ,\derivative_reg[31]_i_2_n_5 }),
        .O({\NLW_derivative_reg[30]_i_1_O_UNCONNECTED [3:1],\derivative_reg[30]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[30]_i_3_n_0 ,\derivative[30]_i_4_n_0 }));
  CARRY4 \derivative_reg[30]_i_10 
       (.CI(\derivative_reg[30]_i_15_n_0 ),
        .CO({\derivative_reg[30]_i_10_n_0 ,\derivative_reg[30]_i_10_n_1 ,\derivative_reg[30]_i_10_n_2 ,\derivative_reg[30]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_12_n_6 ,\derivative_reg[31]_i_12_n_7 ,\derivative_reg[31]_i_21_n_4 ,\derivative_reg[31]_i_21_n_5 }),
        .O({\derivative_reg[30]_i_10_n_4 ,\derivative_reg[30]_i_10_n_5 ,\derivative_reg[30]_i_10_n_6 ,\derivative_reg[30]_i_10_n_7 }),
        .S({\derivative[30]_i_16_n_0 ,\derivative[30]_i_17_n_0 ,\derivative[30]_i_18_n_0 ,\derivative[30]_i_19_n_0 }));
  CARRY4 \derivative_reg[30]_i_15 
       (.CI(\derivative_reg[30]_i_20_n_0 ),
        .CO({\derivative_reg[30]_i_15_n_0 ,\derivative_reg[30]_i_15_n_1 ,\derivative_reg[30]_i_15_n_2 ,\derivative_reg[30]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_21_n_6 ,\derivative_reg[31]_i_21_n_7 ,\derivative_reg[31]_i_30_n_4 ,\derivative_reg[31]_i_30_n_5 }),
        .O({\derivative_reg[30]_i_15_n_4 ,\derivative_reg[30]_i_15_n_5 ,\derivative_reg[30]_i_15_n_6 ,\derivative_reg[30]_i_15_n_7 }),
        .S({\derivative[30]_i_21_n_0 ,\derivative[30]_i_22_n_0 ,\derivative[30]_i_23_n_0 ,\derivative[30]_i_24_n_0 }));
  CARRY4 \derivative_reg[30]_i_2 
       (.CI(\derivative_reg[30]_i_5_n_0 ),
        .CO({\derivative_reg[30]_i_2_n_0 ,\derivative_reg[30]_i_2_n_1 ,\derivative_reg[30]_i_2_n_2 ,\derivative_reg[30]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_2_n_6 ,\derivative_reg[31]_i_2_n_7 ,\derivative_reg[31]_i_3_n_4 ,\derivative_reg[31]_i_3_n_5 }),
        .O({\derivative_reg[30]_i_2_n_4 ,\derivative_reg[30]_i_2_n_5 ,\derivative_reg[30]_i_2_n_6 ,\derivative_reg[30]_i_2_n_7 }),
        .S({\derivative[30]_i_6_n_0 ,\derivative[30]_i_7_n_0 ,\derivative[30]_i_8_n_0 ,\derivative[30]_i_9_n_0 }));
  CARRY4 \derivative_reg[30]_i_20 
       (.CI(\derivative_reg[30]_i_25_n_0 ),
        .CO({\derivative_reg[30]_i_20_n_0 ,\derivative_reg[30]_i_20_n_1 ,\derivative_reg[30]_i_20_n_2 ,\derivative_reg[30]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_30_n_6 ,\derivative_reg[31]_i_30_n_7 ,\derivative_reg[31]_i_39_n_4 ,\derivative_reg[31]_i_39_n_5 }),
        .O({\derivative_reg[30]_i_20_n_4 ,\derivative_reg[30]_i_20_n_5 ,\derivative_reg[30]_i_20_n_6 ,\derivative_reg[30]_i_20_n_7 }),
        .S({\derivative[30]_i_26_n_0 ,\derivative[30]_i_27_n_0 ,\derivative[30]_i_28_n_0 ,\derivative[30]_i_29_n_0 }));
  CARRY4 \derivative_reg[30]_i_25 
       (.CI(\derivative_reg[30]_i_30_n_0 ),
        .CO({\derivative_reg[30]_i_25_n_0 ,\derivative_reg[30]_i_25_n_1 ,\derivative_reg[30]_i_25_n_2 ,\derivative_reg[30]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_39_n_6 ,\derivative_reg[31]_i_39_n_7 ,\derivative_reg[31]_i_48_n_4 ,\derivative_reg[31]_i_48_n_5 }),
        .O({\derivative_reg[30]_i_25_n_4 ,\derivative_reg[30]_i_25_n_5 ,\derivative_reg[30]_i_25_n_6 ,\derivative_reg[30]_i_25_n_7 }),
        .S({\derivative[30]_i_31_n_0 ,\derivative[30]_i_32_n_0 ,\derivative[30]_i_33_n_0 ,\derivative[30]_i_34_n_0 }));
  CARRY4 \derivative_reg[30]_i_30 
       (.CI(\derivative_reg[30]_i_35_n_0 ),
        .CO({\derivative_reg[30]_i_30_n_0 ,\derivative_reg[30]_i_30_n_1 ,\derivative_reg[30]_i_30_n_2 ,\derivative_reg[30]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_48_n_6 ,\derivative_reg[31]_i_48_n_7 ,\derivative_reg[31]_i_57_n_4 ,\derivative_reg[31]_i_57_n_5 }),
        .O({\derivative_reg[30]_i_30_n_4 ,\derivative_reg[30]_i_30_n_5 ,\derivative_reg[30]_i_30_n_6 ,\derivative_reg[30]_i_30_n_7 }),
        .S({\derivative[30]_i_36_n_0 ,\derivative[30]_i_37_n_0 ,\derivative[30]_i_38_n_0 ,\derivative[30]_i_39_n_0 }));
  CARRY4 \derivative_reg[30]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[30]_i_35_n_0 ,\derivative_reg[30]_i_35_n_1 ,\derivative_reg[30]_i_35_n_2 ,\derivative_reg[30]_i_35_n_3 }),
        .CYINIT(\derivative_reg[31]_i_1_n_3 ),
        .DI({\derivative_reg[31]_i_57_n_6 ,\derivative_reg[31]_i_57_n_7 ,derivative11_out[30],1'b0}),
        .O({\derivative_reg[30]_i_35_n_4 ,\derivative_reg[30]_i_35_n_5 ,\derivative_reg[30]_i_35_n_6 ,\NLW_derivative_reg[30]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[30]_i_40_n_0 ,\derivative[30]_i_41_n_0 ,\derivative[30]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[30]_i_5 
       (.CI(\derivative_reg[30]_i_10_n_0 ),
        .CO({\derivative_reg[30]_i_5_n_0 ,\derivative_reg[30]_i_5_n_1 ,\derivative_reg[30]_i_5_n_2 ,\derivative_reg[30]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_3_n_6 ,\derivative_reg[31]_i_3_n_7 ,\derivative_reg[31]_i_12_n_4 ,\derivative_reg[31]_i_12_n_5 }),
        .O({\derivative_reg[30]_i_5_n_4 ,\derivative_reg[30]_i_5_n_5 ,\derivative_reg[30]_i_5_n_6 ,\derivative_reg[30]_i_5_n_7 }),
        .S({\derivative[30]_i_11_n_0 ,\derivative[30]_i_12_n_0 ,\derivative[30]_i_13_n_0 ,\derivative[30]_i_14_n_0 }));
  FDRE \derivative_reg[31] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[31]_i_1_n_3 ),
        .Q(derivative_out[31]),
        .R(1'b0));
  CARRY4 \derivative_reg[31]_i_1 
       (.CI(\derivative_reg[31]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_1_CO_UNCONNECTED [3:1],\derivative_reg[31]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_derivative_reg[31]_i_1_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  CARRY4 \derivative_reg[31]_i_12 
       (.CI(\derivative_reg[31]_i_21_n_0 ),
        .CO({\derivative_reg[31]_i_12_n_0 ,\derivative_reg[31]_i_12_n_1 ,\derivative_reg[31]_i_12_n_2 ,\derivative_reg[31]_i_12_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_22_n_0 ,\derivative[31]_i_23_n_0 ,\derivative[31]_i_24_n_0 ,\derivative[31]_i_25_n_0 }),
        .O({\derivative_reg[31]_i_12_n_4 ,\derivative_reg[31]_i_12_n_5 ,\derivative_reg[31]_i_12_n_6 ,\derivative_reg[31]_i_12_n_7 }),
        .S({\derivative[31]_i_26_n_0 ,\derivative[31]_i_27_n_0 ,\derivative[31]_i_28_n_0 ,\derivative[31]_i_29_n_0 }));
  CARRY4 \derivative_reg[31]_i_2 
       (.CI(\derivative_reg[31]_i_3_n_0 ),
        .CO({\derivative_reg[31]_i_2_n_0 ,\derivative_reg[31]_i_2_n_1 ,\derivative_reg[31]_i_2_n_2 ,\derivative_reg[31]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_4_n_0 ,\derivative[31]_i_5_n_0 ,\derivative[31]_i_6_n_0 ,\derivative[31]_i_7_n_0 }),
        .O({\derivative_reg[31]_i_2_n_4 ,\derivative_reg[31]_i_2_n_5 ,\derivative_reg[31]_i_2_n_6 ,\derivative_reg[31]_i_2_n_7 }),
        .S({\derivative[31]_i_8_n_0 ,\derivative[31]_i_9_n_0 ,\derivative[31]_i_10_n_0 ,\derivative[31]_i_11_n_0 }));
  CARRY4 \derivative_reg[31]_i_21 
       (.CI(\derivative_reg[31]_i_30_n_0 ),
        .CO({\derivative_reg[31]_i_21_n_0 ,\derivative_reg[31]_i_21_n_1 ,\derivative_reg[31]_i_21_n_2 ,\derivative_reg[31]_i_21_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_31_n_0 ,\derivative[31]_i_32_n_0 ,\derivative[31]_i_33_n_0 ,\derivative[31]_i_34_n_0 }),
        .O({\derivative_reg[31]_i_21_n_4 ,\derivative_reg[31]_i_21_n_5 ,\derivative_reg[31]_i_21_n_6 ,\derivative_reg[31]_i_21_n_7 }),
        .S({\derivative[31]_i_35_n_0 ,\derivative[31]_i_36_n_0 ,\derivative[31]_i_37_n_0 ,\derivative[31]_i_38_n_0 }));
  CARRY4 \derivative_reg[31]_i_3 
       (.CI(\derivative_reg[31]_i_12_n_0 ),
        .CO({\derivative_reg[31]_i_3_n_0 ,\derivative_reg[31]_i_3_n_1 ,\derivative_reg[31]_i_3_n_2 ,\derivative_reg[31]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_13_n_0 ,\derivative[31]_i_14_n_0 ,\derivative[31]_i_15_n_0 ,\derivative[31]_i_16_n_0 }),
        .O({\derivative_reg[31]_i_3_n_4 ,\derivative_reg[31]_i_3_n_5 ,\derivative_reg[31]_i_3_n_6 ,\derivative_reg[31]_i_3_n_7 }),
        .S({\derivative[31]_i_17_n_0 ,\derivative[31]_i_18_n_0 ,\derivative[31]_i_19_n_0 ,\derivative[31]_i_20_n_0 }));
  CARRY4 \derivative_reg[31]_i_30 
       (.CI(\derivative_reg[31]_i_39_n_0 ),
        .CO({\derivative_reg[31]_i_30_n_0 ,\derivative_reg[31]_i_30_n_1 ,\derivative_reg[31]_i_30_n_2 ,\derivative_reg[31]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_40_n_0 ,\derivative[31]_i_41_n_0 ,\derivative[31]_i_42_n_0 ,\derivative[31]_i_43_n_0 }),
        .O({\derivative_reg[31]_i_30_n_4 ,\derivative_reg[31]_i_30_n_5 ,\derivative_reg[31]_i_30_n_6 ,\derivative_reg[31]_i_30_n_7 }),
        .S({\derivative[31]_i_44_n_0 ,\derivative[31]_i_45_n_0 ,\derivative[31]_i_46_n_0 ,\derivative[31]_i_47_n_0 }));
  CARRY4 \derivative_reg[31]_i_39 
       (.CI(\derivative_reg[31]_i_48_n_0 ),
        .CO({\derivative_reg[31]_i_39_n_0 ,\derivative_reg[31]_i_39_n_1 ,\derivative_reg[31]_i_39_n_2 ,\derivative_reg[31]_i_39_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_49_n_0 ,\derivative[31]_i_50_n_0 ,\derivative[31]_i_51_n_0 ,\derivative[31]_i_52_n_0 }),
        .O({\derivative_reg[31]_i_39_n_4 ,\derivative_reg[31]_i_39_n_5 ,\derivative_reg[31]_i_39_n_6 ,\derivative_reg[31]_i_39_n_7 }),
        .S({\derivative[31]_i_53_n_0 ,\derivative[31]_i_54_n_0 ,\derivative[31]_i_55_n_0 ,\derivative[31]_i_56_n_0 }));
  CARRY4 \derivative_reg[31]_i_48 
       (.CI(\derivative_reg[31]_i_57_n_0 ),
        .CO({\derivative_reg[31]_i_48_n_0 ,\derivative_reg[31]_i_48_n_1 ,\derivative_reg[31]_i_48_n_2 ,\derivative_reg[31]_i_48_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_58_n_0 ,\derivative[31]_i_59_n_0 ,\derivative[31]_i_60_n_0 ,\derivative[31]_i_61_n_0 }),
        .O({\derivative_reg[31]_i_48_n_4 ,\derivative_reg[31]_i_48_n_5 ,\derivative_reg[31]_i_48_n_6 ,\derivative_reg[31]_i_48_n_7 }),
        .S({\derivative[31]_i_62_n_0 ,\derivative[31]_i_63_n_0 ,\derivative[31]_i_64_n_0 ,\derivative[31]_i_65_n_0 }));
  CARRY4 \derivative_reg[31]_i_57 
       (.CI(1'b0),
        .CO({\derivative_reg[31]_i_57_n_0 ,\derivative_reg[31]_i_57_n_1 ,\derivative_reg[31]_i_57_n_2 ,\derivative_reg[31]_i_57_n_3 }),
        .CYINIT(1'b1),
        .DI({\derivative[31]_i_66_n_0 ,\derivative[31]_i_67_n_0 ,\derivative[31]_i_68_n_0 ,derivative11_out[31]}),
        .O({\derivative_reg[31]_i_57_n_4 ,\derivative_reg[31]_i_57_n_5 ,\derivative_reg[31]_i_57_n_6 ,\derivative_reg[31]_i_57_n_7 }),
        .S({\derivative[31]_i_69_n_0 ,\derivative[31]_i_70_n_0 ,\derivative[31]_i_71_n_0 ,\derivative[31]_i_72_n_0 }));
  FDRE \derivative_reg[3] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[3]_i_1_n_2 ),
        .Q(derivative_out[3]),
        .R(1'b0));
  CARRY4 \derivative_reg[3]_i_1 
       (.CI(\derivative_reg[3]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[3]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[3]_i_1_n_2 ,\derivative_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[4]_i_1_n_2 ,\derivative_reg[4]_i_2_n_4 }),
        .O({\NLW_derivative_reg[3]_i_1_O_UNCONNECTED [3:1],\derivative_reg[3]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[3]_i_3_n_0 ,\derivative[3]_i_4_n_0 }));
  CARRY4 \derivative_reg[3]_i_10 
       (.CI(\derivative_reg[3]_i_15_n_0 ),
        .CO({\derivative_reg[3]_i_10_n_0 ,\derivative_reg[3]_i_10_n_1 ,\derivative_reg[3]_i_10_n_2 ,\derivative_reg[3]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[4]_i_10_n_5 ,\derivative_reg[4]_i_10_n_6 ,\derivative_reg[4]_i_10_n_7 ,\derivative_reg[4]_i_15_n_4 }),
        .O({\derivative_reg[3]_i_10_n_4 ,\derivative_reg[3]_i_10_n_5 ,\derivative_reg[3]_i_10_n_6 ,\derivative_reg[3]_i_10_n_7 }),
        .S({\derivative[3]_i_16_n_0 ,\derivative[3]_i_17_n_0 ,\derivative[3]_i_18_n_0 ,\derivative[3]_i_19_n_0 }));
  CARRY4 \derivative_reg[3]_i_15 
       (.CI(\derivative_reg[3]_i_20_n_0 ),
        .CO({\derivative_reg[3]_i_15_n_0 ,\derivative_reg[3]_i_15_n_1 ,\derivative_reg[3]_i_15_n_2 ,\derivative_reg[3]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[4]_i_15_n_5 ,\derivative_reg[4]_i_15_n_6 ,\derivative_reg[4]_i_15_n_7 ,\derivative_reg[4]_i_20_n_4 }),
        .O({\derivative_reg[3]_i_15_n_4 ,\derivative_reg[3]_i_15_n_5 ,\derivative_reg[3]_i_15_n_6 ,\derivative_reg[3]_i_15_n_7 }),
        .S({\derivative[3]_i_21_n_0 ,\derivative[3]_i_22_n_0 ,\derivative[3]_i_23_n_0 ,\derivative[3]_i_24_n_0 }));
  CARRY4 \derivative_reg[3]_i_2 
       (.CI(\derivative_reg[3]_i_5_n_0 ),
        .CO({\derivative_reg[3]_i_2_n_0 ,\derivative_reg[3]_i_2_n_1 ,\derivative_reg[3]_i_2_n_2 ,\derivative_reg[3]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[4]_i_2_n_5 ,\derivative_reg[4]_i_2_n_6 ,\derivative_reg[4]_i_2_n_7 ,\derivative_reg[4]_i_5_n_4 }),
        .O({\derivative_reg[3]_i_2_n_4 ,\derivative_reg[3]_i_2_n_5 ,\derivative_reg[3]_i_2_n_6 ,\derivative_reg[3]_i_2_n_7 }),
        .S({\derivative[3]_i_6_n_0 ,\derivative[3]_i_7_n_0 ,\derivative[3]_i_8_n_0 ,\derivative[3]_i_9_n_0 }));
  CARRY4 \derivative_reg[3]_i_20 
       (.CI(\derivative_reg[3]_i_25_n_0 ),
        .CO({\derivative_reg[3]_i_20_n_0 ,\derivative_reg[3]_i_20_n_1 ,\derivative_reg[3]_i_20_n_2 ,\derivative_reg[3]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[4]_i_20_n_5 ,\derivative_reg[4]_i_20_n_6 ,\derivative_reg[4]_i_20_n_7 ,\derivative_reg[4]_i_25_n_4 }),
        .O({\derivative_reg[3]_i_20_n_4 ,\derivative_reg[3]_i_20_n_5 ,\derivative_reg[3]_i_20_n_6 ,\derivative_reg[3]_i_20_n_7 }),
        .S({\derivative[3]_i_26_n_0 ,\derivative[3]_i_27_n_0 ,\derivative[3]_i_28_n_0 ,\derivative[3]_i_29_n_0 }));
  CARRY4 \derivative_reg[3]_i_25 
       (.CI(\derivative_reg[3]_i_30_n_0 ),
        .CO({\derivative_reg[3]_i_25_n_0 ,\derivative_reg[3]_i_25_n_1 ,\derivative_reg[3]_i_25_n_2 ,\derivative_reg[3]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[4]_i_25_n_5 ,\derivative_reg[4]_i_25_n_6 ,\derivative_reg[4]_i_25_n_7 ,\derivative_reg[4]_i_30_n_4 }),
        .O({\derivative_reg[3]_i_25_n_4 ,\derivative_reg[3]_i_25_n_5 ,\derivative_reg[3]_i_25_n_6 ,\derivative_reg[3]_i_25_n_7 }),
        .S({\derivative[3]_i_31_n_0 ,\derivative[3]_i_32_n_0 ,\derivative[3]_i_33_n_0 ,\derivative[3]_i_34_n_0 }));
  CARRY4 \derivative_reg[3]_i_30 
       (.CI(\derivative_reg[3]_i_35_n_0 ),
        .CO({\derivative_reg[3]_i_30_n_0 ,\derivative_reg[3]_i_30_n_1 ,\derivative_reg[3]_i_30_n_2 ,\derivative_reg[3]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[4]_i_30_n_5 ,\derivative_reg[4]_i_30_n_6 ,\derivative_reg[4]_i_30_n_7 ,\derivative_reg[4]_i_35_n_4 }),
        .O({\derivative_reg[3]_i_30_n_4 ,\derivative_reg[3]_i_30_n_5 ,\derivative_reg[3]_i_30_n_6 ,\derivative_reg[3]_i_30_n_7 }),
        .S({\derivative[3]_i_36_n_0 ,\derivative[3]_i_37_n_0 ,\derivative[3]_i_38_n_0 ,\derivative[3]_i_39_n_0 }));
  CARRY4 \derivative_reg[3]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[3]_i_35_n_0 ,\derivative_reg[3]_i_35_n_1 ,\derivative_reg[3]_i_35_n_2 ,\derivative_reg[3]_i_35_n_3 }),
        .CYINIT(\derivative_reg[4]_i_1_n_2 ),
        .DI({\derivative_reg[4]_i_35_n_5 ,\derivative_reg[4]_i_35_n_6 ,derivative11_out[3],1'b0}),
        .O({\derivative_reg[3]_i_35_n_4 ,\derivative_reg[3]_i_35_n_5 ,\derivative_reg[3]_i_35_n_6 ,\NLW_derivative_reg[3]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[3]_i_40_n_0 ,\derivative[3]_i_41_n_0 ,\derivative[3]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[3]_i_5 
       (.CI(\derivative_reg[3]_i_10_n_0 ),
        .CO({\derivative_reg[3]_i_5_n_0 ,\derivative_reg[3]_i_5_n_1 ,\derivative_reg[3]_i_5_n_2 ,\derivative_reg[3]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[4]_i_5_n_5 ,\derivative_reg[4]_i_5_n_6 ,\derivative_reg[4]_i_5_n_7 ,\derivative_reg[4]_i_10_n_4 }),
        .O({\derivative_reg[3]_i_5_n_4 ,\derivative_reg[3]_i_5_n_5 ,\derivative_reg[3]_i_5_n_6 ,\derivative_reg[3]_i_5_n_7 }),
        .S({\derivative[3]_i_11_n_0 ,\derivative[3]_i_12_n_0 ,\derivative[3]_i_13_n_0 ,\derivative[3]_i_14_n_0 }));
  FDRE \derivative_reg[4] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[4]_i_1_n_2 ),
        .Q(derivative_out[4]),
        .R(1'b0));
  CARRY4 \derivative_reg[4]_i_1 
       (.CI(\derivative_reg[4]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[4]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[4]_i_1_n_2 ,\derivative_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[5]_i_1_n_2 ,\derivative_reg[5]_i_2_n_4 }),
        .O({\NLW_derivative_reg[4]_i_1_O_UNCONNECTED [3:1],\derivative_reg[4]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[4]_i_3_n_0 ,\derivative[4]_i_4_n_0 }));
  CARRY4 \derivative_reg[4]_i_10 
       (.CI(\derivative_reg[4]_i_15_n_0 ),
        .CO({\derivative_reg[4]_i_10_n_0 ,\derivative_reg[4]_i_10_n_1 ,\derivative_reg[4]_i_10_n_2 ,\derivative_reg[4]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[5]_i_10_n_5 ,\derivative_reg[5]_i_10_n_6 ,\derivative_reg[5]_i_10_n_7 ,\derivative_reg[5]_i_15_n_4 }),
        .O({\derivative_reg[4]_i_10_n_4 ,\derivative_reg[4]_i_10_n_5 ,\derivative_reg[4]_i_10_n_6 ,\derivative_reg[4]_i_10_n_7 }),
        .S({\derivative[4]_i_16_n_0 ,\derivative[4]_i_17_n_0 ,\derivative[4]_i_18_n_0 ,\derivative[4]_i_19_n_0 }));
  CARRY4 \derivative_reg[4]_i_15 
       (.CI(\derivative_reg[4]_i_20_n_0 ),
        .CO({\derivative_reg[4]_i_15_n_0 ,\derivative_reg[4]_i_15_n_1 ,\derivative_reg[4]_i_15_n_2 ,\derivative_reg[4]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[5]_i_15_n_5 ,\derivative_reg[5]_i_15_n_6 ,\derivative_reg[5]_i_15_n_7 ,\derivative_reg[5]_i_20_n_4 }),
        .O({\derivative_reg[4]_i_15_n_4 ,\derivative_reg[4]_i_15_n_5 ,\derivative_reg[4]_i_15_n_6 ,\derivative_reg[4]_i_15_n_7 }),
        .S({\derivative[4]_i_21_n_0 ,\derivative[4]_i_22_n_0 ,\derivative[4]_i_23_n_0 ,\derivative[4]_i_24_n_0 }));
  CARRY4 \derivative_reg[4]_i_2 
       (.CI(\derivative_reg[4]_i_5_n_0 ),
        .CO({\derivative_reg[4]_i_2_n_0 ,\derivative_reg[4]_i_2_n_1 ,\derivative_reg[4]_i_2_n_2 ,\derivative_reg[4]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[5]_i_2_n_5 ,\derivative_reg[5]_i_2_n_6 ,\derivative_reg[5]_i_2_n_7 ,\derivative_reg[5]_i_5_n_4 }),
        .O({\derivative_reg[4]_i_2_n_4 ,\derivative_reg[4]_i_2_n_5 ,\derivative_reg[4]_i_2_n_6 ,\derivative_reg[4]_i_2_n_7 }),
        .S({\derivative[4]_i_6_n_0 ,\derivative[4]_i_7_n_0 ,\derivative[4]_i_8_n_0 ,\derivative[4]_i_9_n_0 }));
  CARRY4 \derivative_reg[4]_i_20 
       (.CI(\derivative_reg[4]_i_25_n_0 ),
        .CO({\derivative_reg[4]_i_20_n_0 ,\derivative_reg[4]_i_20_n_1 ,\derivative_reg[4]_i_20_n_2 ,\derivative_reg[4]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[5]_i_20_n_5 ,\derivative_reg[5]_i_20_n_6 ,\derivative_reg[5]_i_20_n_7 ,\derivative_reg[5]_i_25_n_4 }),
        .O({\derivative_reg[4]_i_20_n_4 ,\derivative_reg[4]_i_20_n_5 ,\derivative_reg[4]_i_20_n_6 ,\derivative_reg[4]_i_20_n_7 }),
        .S({\derivative[4]_i_26_n_0 ,\derivative[4]_i_27_n_0 ,\derivative[4]_i_28_n_0 ,\derivative[4]_i_29_n_0 }));
  CARRY4 \derivative_reg[4]_i_25 
       (.CI(\derivative_reg[4]_i_30_n_0 ),
        .CO({\derivative_reg[4]_i_25_n_0 ,\derivative_reg[4]_i_25_n_1 ,\derivative_reg[4]_i_25_n_2 ,\derivative_reg[4]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[5]_i_25_n_5 ,\derivative_reg[5]_i_25_n_6 ,\derivative_reg[5]_i_25_n_7 ,\derivative_reg[5]_i_30_n_4 }),
        .O({\derivative_reg[4]_i_25_n_4 ,\derivative_reg[4]_i_25_n_5 ,\derivative_reg[4]_i_25_n_6 ,\derivative_reg[4]_i_25_n_7 }),
        .S({\derivative[4]_i_31_n_0 ,\derivative[4]_i_32_n_0 ,\derivative[4]_i_33_n_0 ,\derivative[4]_i_34_n_0 }));
  CARRY4 \derivative_reg[4]_i_30 
       (.CI(\derivative_reg[4]_i_35_n_0 ),
        .CO({\derivative_reg[4]_i_30_n_0 ,\derivative_reg[4]_i_30_n_1 ,\derivative_reg[4]_i_30_n_2 ,\derivative_reg[4]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[5]_i_30_n_5 ,\derivative_reg[5]_i_30_n_6 ,\derivative_reg[5]_i_30_n_7 ,\derivative_reg[5]_i_35_n_4 }),
        .O({\derivative_reg[4]_i_30_n_4 ,\derivative_reg[4]_i_30_n_5 ,\derivative_reg[4]_i_30_n_6 ,\derivative_reg[4]_i_30_n_7 }),
        .S({\derivative[4]_i_36_n_0 ,\derivative[4]_i_37_n_0 ,\derivative[4]_i_38_n_0 ,\derivative[4]_i_39_n_0 }));
  CARRY4 \derivative_reg[4]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[4]_i_35_n_0 ,\derivative_reg[4]_i_35_n_1 ,\derivative_reg[4]_i_35_n_2 ,\derivative_reg[4]_i_35_n_3 }),
        .CYINIT(\derivative_reg[5]_i_1_n_2 ),
        .DI({\derivative_reg[5]_i_35_n_5 ,\derivative_reg[5]_i_35_n_6 ,derivative11_out[4],1'b0}),
        .O({\derivative_reg[4]_i_35_n_4 ,\derivative_reg[4]_i_35_n_5 ,\derivative_reg[4]_i_35_n_6 ,\NLW_derivative_reg[4]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[4]_i_40_n_0 ,\derivative[4]_i_41_n_0 ,\derivative[4]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[4]_i_5 
       (.CI(\derivative_reg[4]_i_10_n_0 ),
        .CO({\derivative_reg[4]_i_5_n_0 ,\derivative_reg[4]_i_5_n_1 ,\derivative_reg[4]_i_5_n_2 ,\derivative_reg[4]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[5]_i_5_n_5 ,\derivative_reg[5]_i_5_n_6 ,\derivative_reg[5]_i_5_n_7 ,\derivative_reg[5]_i_10_n_4 }),
        .O({\derivative_reg[4]_i_5_n_4 ,\derivative_reg[4]_i_5_n_5 ,\derivative_reg[4]_i_5_n_6 ,\derivative_reg[4]_i_5_n_7 }),
        .S({\derivative[4]_i_11_n_0 ,\derivative[4]_i_12_n_0 ,\derivative[4]_i_13_n_0 ,\derivative[4]_i_14_n_0 }));
  FDRE \derivative_reg[5] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[5]_i_1_n_2 ),
        .Q(derivative_out[5]),
        .R(1'b0));
  CARRY4 \derivative_reg[5]_i_1 
       (.CI(\derivative_reg[5]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[5]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[5]_i_1_n_2 ,\derivative_reg[5]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[6]_i_1_n_2 ,\derivative_reg[6]_i_2_n_4 }),
        .O({\NLW_derivative_reg[5]_i_1_O_UNCONNECTED [3:1],\derivative_reg[5]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[5]_i_3_n_0 ,\derivative[5]_i_4_n_0 }));
  CARRY4 \derivative_reg[5]_i_10 
       (.CI(\derivative_reg[5]_i_15_n_0 ),
        .CO({\derivative_reg[5]_i_10_n_0 ,\derivative_reg[5]_i_10_n_1 ,\derivative_reg[5]_i_10_n_2 ,\derivative_reg[5]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[6]_i_10_n_5 ,\derivative_reg[6]_i_10_n_6 ,\derivative_reg[6]_i_10_n_7 ,\derivative_reg[6]_i_15_n_4 }),
        .O({\derivative_reg[5]_i_10_n_4 ,\derivative_reg[5]_i_10_n_5 ,\derivative_reg[5]_i_10_n_6 ,\derivative_reg[5]_i_10_n_7 }),
        .S({\derivative[5]_i_16_n_0 ,\derivative[5]_i_17_n_0 ,\derivative[5]_i_18_n_0 ,\derivative[5]_i_19_n_0 }));
  CARRY4 \derivative_reg[5]_i_15 
       (.CI(\derivative_reg[5]_i_20_n_0 ),
        .CO({\derivative_reg[5]_i_15_n_0 ,\derivative_reg[5]_i_15_n_1 ,\derivative_reg[5]_i_15_n_2 ,\derivative_reg[5]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[6]_i_15_n_5 ,\derivative_reg[6]_i_15_n_6 ,\derivative_reg[6]_i_15_n_7 ,\derivative_reg[6]_i_20_n_4 }),
        .O({\derivative_reg[5]_i_15_n_4 ,\derivative_reg[5]_i_15_n_5 ,\derivative_reg[5]_i_15_n_6 ,\derivative_reg[5]_i_15_n_7 }),
        .S({\derivative[5]_i_21_n_0 ,\derivative[5]_i_22_n_0 ,\derivative[5]_i_23_n_0 ,\derivative[5]_i_24_n_0 }));
  CARRY4 \derivative_reg[5]_i_2 
       (.CI(\derivative_reg[5]_i_5_n_0 ),
        .CO({\derivative_reg[5]_i_2_n_0 ,\derivative_reg[5]_i_2_n_1 ,\derivative_reg[5]_i_2_n_2 ,\derivative_reg[5]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[6]_i_2_n_5 ,\derivative_reg[6]_i_2_n_6 ,\derivative_reg[6]_i_2_n_7 ,\derivative_reg[6]_i_5_n_4 }),
        .O({\derivative_reg[5]_i_2_n_4 ,\derivative_reg[5]_i_2_n_5 ,\derivative_reg[5]_i_2_n_6 ,\derivative_reg[5]_i_2_n_7 }),
        .S({\derivative[5]_i_6_n_0 ,\derivative[5]_i_7_n_0 ,\derivative[5]_i_8_n_0 ,\derivative[5]_i_9_n_0 }));
  CARRY4 \derivative_reg[5]_i_20 
       (.CI(\derivative_reg[5]_i_25_n_0 ),
        .CO({\derivative_reg[5]_i_20_n_0 ,\derivative_reg[5]_i_20_n_1 ,\derivative_reg[5]_i_20_n_2 ,\derivative_reg[5]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[6]_i_20_n_5 ,\derivative_reg[6]_i_20_n_6 ,\derivative_reg[6]_i_20_n_7 ,\derivative_reg[6]_i_25_n_4 }),
        .O({\derivative_reg[5]_i_20_n_4 ,\derivative_reg[5]_i_20_n_5 ,\derivative_reg[5]_i_20_n_6 ,\derivative_reg[5]_i_20_n_7 }),
        .S({\derivative[5]_i_26_n_0 ,\derivative[5]_i_27_n_0 ,\derivative[5]_i_28_n_0 ,\derivative[5]_i_29_n_0 }));
  CARRY4 \derivative_reg[5]_i_25 
       (.CI(\derivative_reg[5]_i_30_n_0 ),
        .CO({\derivative_reg[5]_i_25_n_0 ,\derivative_reg[5]_i_25_n_1 ,\derivative_reg[5]_i_25_n_2 ,\derivative_reg[5]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[6]_i_25_n_5 ,\derivative_reg[6]_i_25_n_6 ,\derivative_reg[6]_i_25_n_7 ,\derivative_reg[6]_i_30_n_4 }),
        .O({\derivative_reg[5]_i_25_n_4 ,\derivative_reg[5]_i_25_n_5 ,\derivative_reg[5]_i_25_n_6 ,\derivative_reg[5]_i_25_n_7 }),
        .S({\derivative[5]_i_31_n_0 ,\derivative[5]_i_32_n_0 ,\derivative[5]_i_33_n_0 ,\derivative[5]_i_34_n_0 }));
  CARRY4 \derivative_reg[5]_i_30 
       (.CI(\derivative_reg[5]_i_35_n_0 ),
        .CO({\derivative_reg[5]_i_30_n_0 ,\derivative_reg[5]_i_30_n_1 ,\derivative_reg[5]_i_30_n_2 ,\derivative_reg[5]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[6]_i_30_n_5 ,\derivative_reg[6]_i_30_n_6 ,\derivative_reg[6]_i_30_n_7 ,\derivative_reg[6]_i_35_n_4 }),
        .O({\derivative_reg[5]_i_30_n_4 ,\derivative_reg[5]_i_30_n_5 ,\derivative_reg[5]_i_30_n_6 ,\derivative_reg[5]_i_30_n_7 }),
        .S({\derivative[5]_i_36_n_0 ,\derivative[5]_i_37_n_0 ,\derivative[5]_i_38_n_0 ,\derivative[5]_i_39_n_0 }));
  CARRY4 \derivative_reg[5]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[5]_i_35_n_0 ,\derivative_reg[5]_i_35_n_1 ,\derivative_reg[5]_i_35_n_2 ,\derivative_reg[5]_i_35_n_3 }),
        .CYINIT(\derivative_reg[6]_i_1_n_2 ),
        .DI({\derivative_reg[6]_i_35_n_5 ,\derivative_reg[6]_i_35_n_6 ,derivative11_out[5],1'b0}),
        .O({\derivative_reg[5]_i_35_n_4 ,\derivative_reg[5]_i_35_n_5 ,\derivative_reg[5]_i_35_n_6 ,\NLW_derivative_reg[5]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[5]_i_40_n_0 ,\derivative[5]_i_41_n_0 ,\derivative[5]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[5]_i_5 
       (.CI(\derivative_reg[5]_i_10_n_0 ),
        .CO({\derivative_reg[5]_i_5_n_0 ,\derivative_reg[5]_i_5_n_1 ,\derivative_reg[5]_i_5_n_2 ,\derivative_reg[5]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[6]_i_5_n_5 ,\derivative_reg[6]_i_5_n_6 ,\derivative_reg[6]_i_5_n_7 ,\derivative_reg[6]_i_10_n_4 }),
        .O({\derivative_reg[5]_i_5_n_4 ,\derivative_reg[5]_i_5_n_5 ,\derivative_reg[5]_i_5_n_6 ,\derivative_reg[5]_i_5_n_7 }),
        .S({\derivative[5]_i_11_n_0 ,\derivative[5]_i_12_n_0 ,\derivative[5]_i_13_n_0 ,\derivative[5]_i_14_n_0 }));
  FDRE \derivative_reg[6] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[6]_i_1_n_2 ),
        .Q(derivative_out[6]),
        .R(1'b0));
  CARRY4 \derivative_reg[6]_i_1 
       (.CI(\derivative_reg[6]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[6]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[6]_i_1_n_2 ,\derivative_reg[6]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[7]_i_1_n_2 ,\derivative_reg[7]_i_2_n_4 }),
        .O({\NLW_derivative_reg[6]_i_1_O_UNCONNECTED [3:1],\derivative_reg[6]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[6]_i_3_n_0 ,\derivative[6]_i_4_n_0 }));
  CARRY4 \derivative_reg[6]_i_10 
       (.CI(\derivative_reg[6]_i_15_n_0 ),
        .CO({\derivative_reg[6]_i_10_n_0 ,\derivative_reg[6]_i_10_n_1 ,\derivative_reg[6]_i_10_n_2 ,\derivative_reg[6]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_10_n_5 ,\derivative_reg[7]_i_10_n_6 ,\derivative_reg[7]_i_10_n_7 ,\derivative_reg[7]_i_15_n_4 }),
        .O({\derivative_reg[6]_i_10_n_4 ,\derivative_reg[6]_i_10_n_5 ,\derivative_reg[6]_i_10_n_6 ,\derivative_reg[6]_i_10_n_7 }),
        .S({\derivative[6]_i_16_n_0 ,\derivative[6]_i_17_n_0 ,\derivative[6]_i_18_n_0 ,\derivative[6]_i_19_n_0 }));
  CARRY4 \derivative_reg[6]_i_15 
       (.CI(\derivative_reg[6]_i_20_n_0 ),
        .CO({\derivative_reg[6]_i_15_n_0 ,\derivative_reg[6]_i_15_n_1 ,\derivative_reg[6]_i_15_n_2 ,\derivative_reg[6]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_15_n_5 ,\derivative_reg[7]_i_15_n_6 ,\derivative_reg[7]_i_15_n_7 ,\derivative_reg[7]_i_20_n_4 }),
        .O({\derivative_reg[6]_i_15_n_4 ,\derivative_reg[6]_i_15_n_5 ,\derivative_reg[6]_i_15_n_6 ,\derivative_reg[6]_i_15_n_7 }),
        .S({\derivative[6]_i_21_n_0 ,\derivative[6]_i_22_n_0 ,\derivative[6]_i_23_n_0 ,\derivative[6]_i_24_n_0 }));
  CARRY4 \derivative_reg[6]_i_2 
       (.CI(\derivative_reg[6]_i_5_n_0 ),
        .CO({\derivative_reg[6]_i_2_n_0 ,\derivative_reg[6]_i_2_n_1 ,\derivative_reg[6]_i_2_n_2 ,\derivative_reg[6]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_2_n_5 ,\derivative_reg[7]_i_2_n_6 ,\derivative_reg[7]_i_2_n_7 ,\derivative_reg[7]_i_5_n_4 }),
        .O({\derivative_reg[6]_i_2_n_4 ,\derivative_reg[6]_i_2_n_5 ,\derivative_reg[6]_i_2_n_6 ,\derivative_reg[6]_i_2_n_7 }),
        .S({\derivative[6]_i_6_n_0 ,\derivative[6]_i_7_n_0 ,\derivative[6]_i_8_n_0 ,\derivative[6]_i_9_n_0 }));
  CARRY4 \derivative_reg[6]_i_20 
       (.CI(\derivative_reg[6]_i_25_n_0 ),
        .CO({\derivative_reg[6]_i_20_n_0 ,\derivative_reg[6]_i_20_n_1 ,\derivative_reg[6]_i_20_n_2 ,\derivative_reg[6]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_20_n_5 ,\derivative_reg[7]_i_20_n_6 ,\derivative_reg[7]_i_20_n_7 ,\derivative_reg[7]_i_25_n_4 }),
        .O({\derivative_reg[6]_i_20_n_4 ,\derivative_reg[6]_i_20_n_5 ,\derivative_reg[6]_i_20_n_6 ,\derivative_reg[6]_i_20_n_7 }),
        .S({\derivative[6]_i_26_n_0 ,\derivative[6]_i_27_n_0 ,\derivative[6]_i_28_n_0 ,\derivative[6]_i_29_n_0 }));
  CARRY4 \derivative_reg[6]_i_25 
       (.CI(\derivative_reg[6]_i_30_n_0 ),
        .CO({\derivative_reg[6]_i_25_n_0 ,\derivative_reg[6]_i_25_n_1 ,\derivative_reg[6]_i_25_n_2 ,\derivative_reg[6]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_25_n_5 ,\derivative_reg[7]_i_25_n_6 ,\derivative_reg[7]_i_25_n_7 ,\derivative_reg[7]_i_30_n_4 }),
        .O({\derivative_reg[6]_i_25_n_4 ,\derivative_reg[6]_i_25_n_5 ,\derivative_reg[6]_i_25_n_6 ,\derivative_reg[6]_i_25_n_7 }),
        .S({\derivative[6]_i_31_n_0 ,\derivative[6]_i_32_n_0 ,\derivative[6]_i_33_n_0 ,\derivative[6]_i_34_n_0 }));
  CARRY4 \derivative_reg[6]_i_30 
       (.CI(\derivative_reg[6]_i_35_n_0 ),
        .CO({\derivative_reg[6]_i_30_n_0 ,\derivative_reg[6]_i_30_n_1 ,\derivative_reg[6]_i_30_n_2 ,\derivative_reg[6]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_30_n_5 ,\derivative_reg[7]_i_30_n_6 ,\derivative_reg[7]_i_30_n_7 ,\derivative_reg[7]_i_35_n_4 }),
        .O({\derivative_reg[6]_i_30_n_4 ,\derivative_reg[6]_i_30_n_5 ,\derivative_reg[6]_i_30_n_6 ,\derivative_reg[6]_i_30_n_7 }),
        .S({\derivative[6]_i_36_n_0 ,\derivative[6]_i_37_n_0 ,\derivative[6]_i_38_n_0 ,\derivative[6]_i_39_n_0 }));
  CARRY4 \derivative_reg[6]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[6]_i_35_n_0 ,\derivative_reg[6]_i_35_n_1 ,\derivative_reg[6]_i_35_n_2 ,\derivative_reg[6]_i_35_n_3 }),
        .CYINIT(\derivative_reg[7]_i_1_n_2 ),
        .DI({\derivative_reg[7]_i_35_n_5 ,\derivative_reg[7]_i_35_n_6 ,derivative11_out[6],1'b0}),
        .O({\derivative_reg[6]_i_35_n_4 ,\derivative_reg[6]_i_35_n_5 ,\derivative_reg[6]_i_35_n_6 ,\NLW_derivative_reg[6]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[6]_i_40_n_0 ,\derivative[6]_i_41_n_0 ,\derivative[6]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[6]_i_5 
       (.CI(\derivative_reg[6]_i_10_n_0 ),
        .CO({\derivative_reg[6]_i_5_n_0 ,\derivative_reg[6]_i_5_n_1 ,\derivative_reg[6]_i_5_n_2 ,\derivative_reg[6]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_5_n_5 ,\derivative_reg[7]_i_5_n_6 ,\derivative_reg[7]_i_5_n_7 ,\derivative_reg[7]_i_10_n_4 }),
        .O({\derivative_reg[6]_i_5_n_4 ,\derivative_reg[6]_i_5_n_5 ,\derivative_reg[6]_i_5_n_6 ,\derivative_reg[6]_i_5_n_7 }),
        .S({\derivative[6]_i_11_n_0 ,\derivative[6]_i_12_n_0 ,\derivative[6]_i_13_n_0 ,\derivative[6]_i_14_n_0 }));
  FDRE \derivative_reg[7] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[7]_i_1_n_2 ),
        .Q(derivative_out[7]),
        .R(1'b0));
  CARRY4 \derivative_reg[7]_i_1 
       (.CI(\derivative_reg[7]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[7]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[7]_i_1_n_2 ,\derivative_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[8]_i_1_n_2 ,\derivative_reg[8]_i_2_n_4 }),
        .O({\NLW_derivative_reg[7]_i_1_O_UNCONNECTED [3:1],\derivative_reg[7]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[7]_i_3_n_0 ,\derivative[7]_i_4_n_0 }));
  CARRY4 \derivative_reg[7]_i_10 
       (.CI(\derivative_reg[7]_i_15_n_0 ),
        .CO({\derivative_reg[7]_i_10_n_0 ,\derivative_reg[7]_i_10_n_1 ,\derivative_reg[7]_i_10_n_2 ,\derivative_reg[7]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[8]_i_10_n_5 ,\derivative_reg[8]_i_10_n_6 ,\derivative_reg[8]_i_10_n_7 ,\derivative_reg[8]_i_15_n_4 }),
        .O({\derivative_reg[7]_i_10_n_4 ,\derivative_reg[7]_i_10_n_5 ,\derivative_reg[7]_i_10_n_6 ,\derivative_reg[7]_i_10_n_7 }),
        .S({\derivative[7]_i_16_n_0 ,\derivative[7]_i_17_n_0 ,\derivative[7]_i_18_n_0 ,\derivative[7]_i_19_n_0 }));
  CARRY4 \derivative_reg[7]_i_15 
       (.CI(\derivative_reg[7]_i_20_n_0 ),
        .CO({\derivative_reg[7]_i_15_n_0 ,\derivative_reg[7]_i_15_n_1 ,\derivative_reg[7]_i_15_n_2 ,\derivative_reg[7]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[8]_i_15_n_5 ,\derivative_reg[8]_i_15_n_6 ,\derivative_reg[8]_i_15_n_7 ,\derivative_reg[8]_i_20_n_4 }),
        .O({\derivative_reg[7]_i_15_n_4 ,\derivative_reg[7]_i_15_n_5 ,\derivative_reg[7]_i_15_n_6 ,\derivative_reg[7]_i_15_n_7 }),
        .S({\derivative[7]_i_21_n_0 ,\derivative[7]_i_22_n_0 ,\derivative[7]_i_23_n_0 ,\derivative[7]_i_24_n_0 }));
  CARRY4 \derivative_reg[7]_i_2 
       (.CI(\derivative_reg[7]_i_5_n_0 ),
        .CO({\derivative_reg[7]_i_2_n_0 ,\derivative_reg[7]_i_2_n_1 ,\derivative_reg[7]_i_2_n_2 ,\derivative_reg[7]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[8]_i_2_n_5 ,\derivative_reg[8]_i_2_n_6 ,\derivative_reg[8]_i_2_n_7 ,\derivative_reg[8]_i_5_n_4 }),
        .O({\derivative_reg[7]_i_2_n_4 ,\derivative_reg[7]_i_2_n_5 ,\derivative_reg[7]_i_2_n_6 ,\derivative_reg[7]_i_2_n_7 }),
        .S({\derivative[7]_i_6_n_0 ,\derivative[7]_i_7_n_0 ,\derivative[7]_i_8_n_0 ,\derivative[7]_i_9_n_0 }));
  CARRY4 \derivative_reg[7]_i_20 
       (.CI(\derivative_reg[7]_i_25_n_0 ),
        .CO({\derivative_reg[7]_i_20_n_0 ,\derivative_reg[7]_i_20_n_1 ,\derivative_reg[7]_i_20_n_2 ,\derivative_reg[7]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[8]_i_20_n_5 ,\derivative_reg[8]_i_20_n_6 ,\derivative_reg[8]_i_20_n_7 ,\derivative_reg[8]_i_25_n_4 }),
        .O({\derivative_reg[7]_i_20_n_4 ,\derivative_reg[7]_i_20_n_5 ,\derivative_reg[7]_i_20_n_6 ,\derivative_reg[7]_i_20_n_7 }),
        .S({\derivative[7]_i_26_n_0 ,\derivative[7]_i_27_n_0 ,\derivative[7]_i_28_n_0 ,\derivative[7]_i_29_n_0 }));
  CARRY4 \derivative_reg[7]_i_25 
       (.CI(\derivative_reg[7]_i_30_n_0 ),
        .CO({\derivative_reg[7]_i_25_n_0 ,\derivative_reg[7]_i_25_n_1 ,\derivative_reg[7]_i_25_n_2 ,\derivative_reg[7]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[8]_i_25_n_5 ,\derivative_reg[8]_i_25_n_6 ,\derivative_reg[8]_i_25_n_7 ,\derivative_reg[8]_i_30_n_4 }),
        .O({\derivative_reg[7]_i_25_n_4 ,\derivative_reg[7]_i_25_n_5 ,\derivative_reg[7]_i_25_n_6 ,\derivative_reg[7]_i_25_n_7 }),
        .S({\derivative[7]_i_31_n_0 ,\derivative[7]_i_32_n_0 ,\derivative[7]_i_33_n_0 ,\derivative[7]_i_34_n_0 }));
  CARRY4 \derivative_reg[7]_i_30 
       (.CI(\derivative_reg[7]_i_35_n_0 ),
        .CO({\derivative_reg[7]_i_30_n_0 ,\derivative_reg[7]_i_30_n_1 ,\derivative_reg[7]_i_30_n_2 ,\derivative_reg[7]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[8]_i_30_n_5 ,\derivative_reg[8]_i_30_n_6 ,\derivative_reg[8]_i_30_n_7 ,\derivative_reg[8]_i_35_n_4 }),
        .O({\derivative_reg[7]_i_30_n_4 ,\derivative_reg[7]_i_30_n_5 ,\derivative_reg[7]_i_30_n_6 ,\derivative_reg[7]_i_30_n_7 }),
        .S({\derivative[7]_i_36_n_0 ,\derivative[7]_i_37_n_0 ,\derivative[7]_i_38_n_0 ,\derivative[7]_i_39_n_0 }));
  CARRY4 \derivative_reg[7]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[7]_i_35_n_0 ,\derivative_reg[7]_i_35_n_1 ,\derivative_reg[7]_i_35_n_2 ,\derivative_reg[7]_i_35_n_3 }),
        .CYINIT(\derivative_reg[8]_i_1_n_2 ),
        .DI({\derivative_reg[8]_i_35_n_5 ,\derivative_reg[8]_i_35_n_6 ,derivative11_out[7],1'b0}),
        .O({\derivative_reg[7]_i_35_n_4 ,\derivative_reg[7]_i_35_n_5 ,\derivative_reg[7]_i_35_n_6 ,\NLW_derivative_reg[7]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[7]_i_40_n_0 ,\derivative[7]_i_41_n_0 ,\derivative[7]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[7]_i_5 
       (.CI(\derivative_reg[7]_i_10_n_0 ),
        .CO({\derivative_reg[7]_i_5_n_0 ,\derivative_reg[7]_i_5_n_1 ,\derivative_reg[7]_i_5_n_2 ,\derivative_reg[7]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[8]_i_5_n_5 ,\derivative_reg[8]_i_5_n_6 ,\derivative_reg[8]_i_5_n_7 ,\derivative_reg[8]_i_10_n_4 }),
        .O({\derivative_reg[7]_i_5_n_4 ,\derivative_reg[7]_i_5_n_5 ,\derivative_reg[7]_i_5_n_6 ,\derivative_reg[7]_i_5_n_7 }),
        .S({\derivative[7]_i_11_n_0 ,\derivative[7]_i_12_n_0 ,\derivative[7]_i_13_n_0 ,\derivative[7]_i_14_n_0 }));
  FDRE \derivative_reg[8] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[8]_i_1_n_2 ),
        .Q(derivative_out[8]),
        .R(1'b0));
  CARRY4 \derivative_reg[8]_i_1 
       (.CI(\derivative_reg[8]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[8]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[8]_i_1_n_2 ,\derivative_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[9]_i_1_n_2 ,\derivative_reg[9]_i_2_n_4 }),
        .O({\NLW_derivative_reg[8]_i_1_O_UNCONNECTED [3:1],\derivative_reg[8]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[8]_i_3_n_0 ,\derivative[8]_i_4_n_0 }));
  CARRY4 \derivative_reg[8]_i_10 
       (.CI(\derivative_reg[8]_i_15_n_0 ),
        .CO({\derivative_reg[8]_i_10_n_0 ,\derivative_reg[8]_i_10_n_1 ,\derivative_reg[8]_i_10_n_2 ,\derivative_reg[8]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[9]_i_10_n_5 ,\derivative_reg[9]_i_10_n_6 ,\derivative_reg[9]_i_10_n_7 ,\derivative_reg[9]_i_15_n_4 }),
        .O({\derivative_reg[8]_i_10_n_4 ,\derivative_reg[8]_i_10_n_5 ,\derivative_reg[8]_i_10_n_6 ,\derivative_reg[8]_i_10_n_7 }),
        .S({\derivative[8]_i_16_n_0 ,\derivative[8]_i_17_n_0 ,\derivative[8]_i_18_n_0 ,\derivative[8]_i_19_n_0 }));
  CARRY4 \derivative_reg[8]_i_15 
       (.CI(\derivative_reg[8]_i_20_n_0 ),
        .CO({\derivative_reg[8]_i_15_n_0 ,\derivative_reg[8]_i_15_n_1 ,\derivative_reg[8]_i_15_n_2 ,\derivative_reg[8]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[9]_i_15_n_5 ,\derivative_reg[9]_i_15_n_6 ,\derivative_reg[9]_i_15_n_7 ,\derivative_reg[9]_i_20_n_4 }),
        .O({\derivative_reg[8]_i_15_n_4 ,\derivative_reg[8]_i_15_n_5 ,\derivative_reg[8]_i_15_n_6 ,\derivative_reg[8]_i_15_n_7 }),
        .S({\derivative[8]_i_21_n_0 ,\derivative[8]_i_22_n_0 ,\derivative[8]_i_23_n_0 ,\derivative[8]_i_24_n_0 }));
  CARRY4 \derivative_reg[8]_i_2 
       (.CI(\derivative_reg[8]_i_5_n_0 ),
        .CO({\derivative_reg[8]_i_2_n_0 ,\derivative_reg[8]_i_2_n_1 ,\derivative_reg[8]_i_2_n_2 ,\derivative_reg[8]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[9]_i_2_n_5 ,\derivative_reg[9]_i_2_n_6 ,\derivative_reg[9]_i_2_n_7 ,\derivative_reg[9]_i_5_n_4 }),
        .O({\derivative_reg[8]_i_2_n_4 ,\derivative_reg[8]_i_2_n_5 ,\derivative_reg[8]_i_2_n_6 ,\derivative_reg[8]_i_2_n_7 }),
        .S({\derivative[8]_i_6_n_0 ,\derivative[8]_i_7_n_0 ,\derivative[8]_i_8_n_0 ,\derivative[8]_i_9_n_0 }));
  CARRY4 \derivative_reg[8]_i_20 
       (.CI(\derivative_reg[8]_i_25_n_0 ),
        .CO({\derivative_reg[8]_i_20_n_0 ,\derivative_reg[8]_i_20_n_1 ,\derivative_reg[8]_i_20_n_2 ,\derivative_reg[8]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[9]_i_20_n_5 ,\derivative_reg[9]_i_20_n_6 ,\derivative_reg[9]_i_20_n_7 ,\derivative_reg[9]_i_25_n_4 }),
        .O({\derivative_reg[8]_i_20_n_4 ,\derivative_reg[8]_i_20_n_5 ,\derivative_reg[8]_i_20_n_6 ,\derivative_reg[8]_i_20_n_7 }),
        .S({\derivative[8]_i_26_n_0 ,\derivative[8]_i_27_n_0 ,\derivative[8]_i_28_n_0 ,\derivative[8]_i_29_n_0 }));
  CARRY4 \derivative_reg[8]_i_25 
       (.CI(\derivative_reg[8]_i_30_n_0 ),
        .CO({\derivative_reg[8]_i_25_n_0 ,\derivative_reg[8]_i_25_n_1 ,\derivative_reg[8]_i_25_n_2 ,\derivative_reg[8]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[9]_i_25_n_5 ,\derivative_reg[9]_i_25_n_6 ,\derivative_reg[9]_i_25_n_7 ,\derivative_reg[9]_i_30_n_4 }),
        .O({\derivative_reg[8]_i_25_n_4 ,\derivative_reg[8]_i_25_n_5 ,\derivative_reg[8]_i_25_n_6 ,\derivative_reg[8]_i_25_n_7 }),
        .S({\derivative[8]_i_31_n_0 ,\derivative[8]_i_32_n_0 ,\derivative[8]_i_33_n_0 ,\derivative[8]_i_34_n_0 }));
  CARRY4 \derivative_reg[8]_i_30 
       (.CI(\derivative_reg[8]_i_35_n_0 ),
        .CO({\derivative_reg[8]_i_30_n_0 ,\derivative_reg[8]_i_30_n_1 ,\derivative_reg[8]_i_30_n_2 ,\derivative_reg[8]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[9]_i_30_n_5 ,\derivative_reg[9]_i_30_n_6 ,\derivative_reg[9]_i_30_n_7 ,\derivative_reg[9]_i_35_n_4 }),
        .O({\derivative_reg[8]_i_30_n_4 ,\derivative_reg[8]_i_30_n_5 ,\derivative_reg[8]_i_30_n_6 ,\derivative_reg[8]_i_30_n_7 }),
        .S({\derivative[8]_i_36_n_0 ,\derivative[8]_i_37_n_0 ,\derivative[8]_i_38_n_0 ,\derivative[8]_i_39_n_0 }));
  CARRY4 \derivative_reg[8]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[8]_i_35_n_0 ,\derivative_reg[8]_i_35_n_1 ,\derivative_reg[8]_i_35_n_2 ,\derivative_reg[8]_i_35_n_3 }),
        .CYINIT(\derivative_reg[9]_i_1_n_2 ),
        .DI({\derivative_reg[9]_i_35_n_5 ,\derivative_reg[9]_i_35_n_6 ,derivative11_out[8],1'b0}),
        .O({\derivative_reg[8]_i_35_n_4 ,\derivative_reg[8]_i_35_n_5 ,\derivative_reg[8]_i_35_n_6 ,\NLW_derivative_reg[8]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[8]_i_40_n_0 ,\derivative[8]_i_41_n_0 ,\derivative[8]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[8]_i_5 
       (.CI(\derivative_reg[8]_i_10_n_0 ),
        .CO({\derivative_reg[8]_i_5_n_0 ,\derivative_reg[8]_i_5_n_1 ,\derivative_reg[8]_i_5_n_2 ,\derivative_reg[8]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[9]_i_5_n_5 ,\derivative_reg[9]_i_5_n_6 ,\derivative_reg[9]_i_5_n_7 ,\derivative_reg[9]_i_10_n_4 }),
        .O({\derivative_reg[8]_i_5_n_4 ,\derivative_reg[8]_i_5_n_5 ,\derivative_reg[8]_i_5_n_6 ,\derivative_reg[8]_i_5_n_7 }),
        .S({\derivative[8]_i_11_n_0 ,\derivative[8]_i_12_n_0 ,\derivative[8]_i_13_n_0 ,\derivative[8]_i_14_n_0 }));
  FDRE \derivative_reg[9] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(\derivative_reg[9]_i_1_n_2 ),
        .Q(derivative_out[9]),
        .R(1'b0));
  CARRY4 \derivative_reg[9]_i_1 
       (.CI(\derivative_reg[9]_i_2_n_0 ),
        .CO({\NLW_derivative_reg[9]_i_1_CO_UNCONNECTED [3:2],\derivative_reg[9]_i_1_n_2 ,\derivative_reg[9]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\derivative_reg[10]_i_1_n_2 ,\derivative_reg[10]_i_2_n_4 }),
        .O({\NLW_derivative_reg[9]_i_1_O_UNCONNECTED [3:1],\derivative_reg[9]_i_1_n_7 }),
        .S({1'b0,1'b0,\derivative[9]_i_3_n_0 ,\derivative[9]_i_4_n_0 }));
  CARRY4 \derivative_reg[9]_i_10 
       (.CI(\derivative_reg[9]_i_15_n_0 ),
        .CO({\derivative_reg[9]_i_10_n_0 ,\derivative_reg[9]_i_10_n_1 ,\derivative_reg[9]_i_10_n_2 ,\derivative_reg[9]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[10]_i_10_n_5 ,\derivative_reg[10]_i_10_n_6 ,\derivative_reg[10]_i_10_n_7 ,\derivative_reg[10]_i_15_n_4 }),
        .O({\derivative_reg[9]_i_10_n_4 ,\derivative_reg[9]_i_10_n_5 ,\derivative_reg[9]_i_10_n_6 ,\derivative_reg[9]_i_10_n_7 }),
        .S({\derivative[9]_i_16_n_0 ,\derivative[9]_i_17_n_0 ,\derivative[9]_i_18_n_0 ,\derivative[9]_i_19_n_0 }));
  CARRY4 \derivative_reg[9]_i_15 
       (.CI(\derivative_reg[9]_i_20_n_0 ),
        .CO({\derivative_reg[9]_i_15_n_0 ,\derivative_reg[9]_i_15_n_1 ,\derivative_reg[9]_i_15_n_2 ,\derivative_reg[9]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[10]_i_15_n_5 ,\derivative_reg[10]_i_15_n_6 ,\derivative_reg[10]_i_15_n_7 ,\derivative_reg[10]_i_20_n_4 }),
        .O({\derivative_reg[9]_i_15_n_4 ,\derivative_reg[9]_i_15_n_5 ,\derivative_reg[9]_i_15_n_6 ,\derivative_reg[9]_i_15_n_7 }),
        .S({\derivative[9]_i_21_n_0 ,\derivative[9]_i_22_n_0 ,\derivative[9]_i_23_n_0 ,\derivative[9]_i_24_n_0 }));
  CARRY4 \derivative_reg[9]_i_2 
       (.CI(\derivative_reg[9]_i_5_n_0 ),
        .CO({\derivative_reg[9]_i_2_n_0 ,\derivative_reg[9]_i_2_n_1 ,\derivative_reg[9]_i_2_n_2 ,\derivative_reg[9]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[10]_i_2_n_5 ,\derivative_reg[10]_i_2_n_6 ,\derivative_reg[10]_i_2_n_7 ,\derivative_reg[10]_i_5_n_4 }),
        .O({\derivative_reg[9]_i_2_n_4 ,\derivative_reg[9]_i_2_n_5 ,\derivative_reg[9]_i_2_n_6 ,\derivative_reg[9]_i_2_n_7 }),
        .S({\derivative[9]_i_6_n_0 ,\derivative[9]_i_7_n_0 ,\derivative[9]_i_8_n_0 ,\derivative[9]_i_9_n_0 }));
  CARRY4 \derivative_reg[9]_i_20 
       (.CI(\derivative_reg[9]_i_25_n_0 ),
        .CO({\derivative_reg[9]_i_20_n_0 ,\derivative_reg[9]_i_20_n_1 ,\derivative_reg[9]_i_20_n_2 ,\derivative_reg[9]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[10]_i_20_n_5 ,\derivative_reg[10]_i_20_n_6 ,\derivative_reg[10]_i_20_n_7 ,\derivative_reg[10]_i_25_n_4 }),
        .O({\derivative_reg[9]_i_20_n_4 ,\derivative_reg[9]_i_20_n_5 ,\derivative_reg[9]_i_20_n_6 ,\derivative_reg[9]_i_20_n_7 }),
        .S({\derivative[9]_i_26_n_0 ,\derivative[9]_i_27_n_0 ,\derivative[9]_i_28_n_0 ,\derivative[9]_i_29_n_0 }));
  CARRY4 \derivative_reg[9]_i_25 
       (.CI(\derivative_reg[9]_i_30_n_0 ),
        .CO({\derivative_reg[9]_i_25_n_0 ,\derivative_reg[9]_i_25_n_1 ,\derivative_reg[9]_i_25_n_2 ,\derivative_reg[9]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[10]_i_25_n_5 ,\derivative_reg[10]_i_25_n_6 ,\derivative_reg[10]_i_25_n_7 ,\derivative_reg[10]_i_30_n_4 }),
        .O({\derivative_reg[9]_i_25_n_4 ,\derivative_reg[9]_i_25_n_5 ,\derivative_reg[9]_i_25_n_6 ,\derivative_reg[9]_i_25_n_7 }),
        .S({\derivative[9]_i_31_n_0 ,\derivative[9]_i_32_n_0 ,\derivative[9]_i_33_n_0 ,\derivative[9]_i_34_n_0 }));
  CARRY4 \derivative_reg[9]_i_30 
       (.CI(\derivative_reg[9]_i_35_n_0 ),
        .CO({\derivative_reg[9]_i_30_n_0 ,\derivative_reg[9]_i_30_n_1 ,\derivative_reg[9]_i_30_n_2 ,\derivative_reg[9]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[10]_i_30_n_5 ,\derivative_reg[10]_i_30_n_6 ,\derivative_reg[10]_i_30_n_7 ,\derivative_reg[10]_i_35_n_4 }),
        .O({\derivative_reg[9]_i_30_n_4 ,\derivative_reg[9]_i_30_n_5 ,\derivative_reg[9]_i_30_n_6 ,\derivative_reg[9]_i_30_n_7 }),
        .S({\derivative[9]_i_36_n_0 ,\derivative[9]_i_37_n_0 ,\derivative[9]_i_38_n_0 ,\derivative[9]_i_39_n_0 }));
  CARRY4 \derivative_reg[9]_i_35 
       (.CI(1'b0),
        .CO({\derivative_reg[9]_i_35_n_0 ,\derivative_reg[9]_i_35_n_1 ,\derivative_reg[9]_i_35_n_2 ,\derivative_reg[9]_i_35_n_3 }),
        .CYINIT(\derivative_reg[10]_i_1_n_2 ),
        .DI({\derivative_reg[10]_i_35_n_5 ,\derivative_reg[10]_i_35_n_6 ,derivative11_out[9],1'b0}),
        .O({\derivative_reg[9]_i_35_n_4 ,\derivative_reg[9]_i_35_n_5 ,\derivative_reg[9]_i_35_n_6 ,\NLW_derivative_reg[9]_i_35_O_UNCONNECTED [0]}),
        .S({\derivative[9]_i_40_n_0 ,\derivative[9]_i_41_n_0 ,\derivative[9]_i_42_n_0 ,1'b1}));
  CARRY4 \derivative_reg[9]_i_5 
       (.CI(\derivative_reg[9]_i_10_n_0 ),
        .CO({\derivative_reg[9]_i_5_n_0 ,\derivative_reg[9]_i_5_n_1 ,\derivative_reg[9]_i_5_n_2 ,\derivative_reg[9]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[10]_i_5_n_5 ,\derivative_reg[10]_i_5_n_6 ,\derivative_reg[10]_i_5_n_7 ,\derivative_reg[10]_i_10_n_4 }),
        .O({\derivative_reg[9]_i_5_n_4 ,\derivative_reg[9]_i_5_n_5 ,\derivative_reg[9]_i_5_n_6 ,\derivative_reg[9]_i_5_n_7 }),
        .S({\derivative[9]_i_11_n_0 ,\derivative[9]_i_12_n_0 ,\derivative[9]_i_13_n_0 ,\derivative[9]_i_14_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry
       (.CI(1'b0),
        .CO({error0_carry_n_0,error0_carry_n_1,error0_carry_n_2,error0_carry_n_3}),
        .CYINIT(1'b1),
        .DI(target_angle[3:0]),
        .O(error02_out[3:0]),
        .S({error0_carry_i_1_n_0,error0_carry_i_2_n_0,error0_carry_i_3_n_0,error0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__0
       (.CI(error0_carry_n_0),
        .CO({error0_carry__0_n_0,error0_carry__0_n_1,error0_carry__0_n_2,error0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(target_angle[7:4]),
        .O(error02_out[7:4]),
        .S({error0_carry__0_i_1_n_0,error0_carry__0_i_2_n_0,error0_carry__0_i_3_n_0,error0_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__0_i_1
       (.I0(target_angle[7]),
        .I1(angle[7]),
        .O(error0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__0_i_2
       (.I0(target_angle[6]),
        .I1(angle[6]),
        .O(error0_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__0_i_3
       (.I0(target_angle[5]),
        .I1(angle[5]),
        .O(error0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__0_i_4
       (.I0(target_angle[4]),
        .I1(angle[4]),
        .O(error0_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__1
       (.CI(error0_carry__0_n_0),
        .CO({error0_carry__1_n_0,error0_carry__1_n_1,error0_carry__1_n_2,error0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(target_angle[11:8]),
        .O(error02_out[11:8]),
        .S({error0_carry__1_i_1_n_0,error0_carry__1_i_2_n_0,error0_carry__1_i_3_n_0,error0_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__1_i_1
       (.I0(target_angle[11]),
        .I1(angle[11]),
        .O(error0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__1_i_2
       (.I0(target_angle[10]),
        .I1(angle[10]),
        .O(error0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__1_i_3
       (.I0(target_angle[9]),
        .I1(angle[9]),
        .O(error0_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__1_i_4
       (.I0(target_angle[8]),
        .I1(angle[8]),
        .O(error0_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__2
       (.CI(error0_carry__1_n_0),
        .CO({error0_carry__2_n_0,error0_carry__2_n_1,error0_carry__2_n_2,error0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(target_angle[15:12]),
        .O(error02_out[15:12]),
        .S({error0_carry__2_i_1_n_0,error0_carry__2_i_2_n_0,error0_carry__2_i_3_n_0,error0_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__2_i_1
       (.I0(target_angle[15]),
        .I1(angle[15]),
        .O(error0_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__2_i_2
       (.I0(target_angle[14]),
        .I1(angle[14]),
        .O(error0_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__2_i_3
       (.I0(target_angle[13]),
        .I1(angle[13]),
        .O(error0_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__2_i_4
       (.I0(target_angle[12]),
        .I1(angle[12]),
        .O(error0_carry__2_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__3
       (.CI(error0_carry__2_n_0),
        .CO({error0_carry__3_n_0,error0_carry__3_n_1,error0_carry__3_n_2,error0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(target_angle[19:16]),
        .O(error02_out[19:16]),
        .S({error0_carry__3_i_1_n_0,error0_carry__3_i_2_n_0,error0_carry__3_i_3_n_0,error0_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__3_i_1
       (.I0(target_angle[19]),
        .I1(angle[19]),
        .O(error0_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__3_i_2
       (.I0(target_angle[18]),
        .I1(angle[18]),
        .O(error0_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__3_i_3
       (.I0(target_angle[17]),
        .I1(angle[17]),
        .O(error0_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__3_i_4
       (.I0(target_angle[16]),
        .I1(angle[16]),
        .O(error0_carry__3_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__4
       (.CI(error0_carry__3_n_0),
        .CO({error0_carry__4_n_0,error0_carry__4_n_1,error0_carry__4_n_2,error0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(target_angle[23:20]),
        .O(error02_out[23:20]),
        .S({error0_carry__4_i_1_n_0,error0_carry__4_i_2_n_0,error0_carry__4_i_3_n_0,error0_carry__4_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__4_i_1
       (.I0(target_angle[23]),
        .I1(angle[23]),
        .O(error0_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__4_i_2
       (.I0(target_angle[22]),
        .I1(angle[22]),
        .O(error0_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__4_i_3
       (.I0(target_angle[21]),
        .I1(angle[21]),
        .O(error0_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__4_i_4
       (.I0(target_angle[20]),
        .I1(angle[20]),
        .O(error0_carry__4_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__5
       (.CI(error0_carry__4_n_0),
        .CO({error0_carry__5_n_0,error0_carry__5_n_1,error0_carry__5_n_2,error0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(target_angle[27:24]),
        .O(error02_out[27:24]),
        .S({error0_carry__5_i_1_n_0,error0_carry__5_i_2_n_0,error0_carry__5_i_3_n_0,error0_carry__5_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__5_i_1
       (.I0(target_angle[27]),
        .I1(angle[27]),
        .O(error0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__5_i_2
       (.I0(target_angle[26]),
        .I1(angle[26]),
        .O(error0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__5_i_3
       (.I0(target_angle[25]),
        .I1(angle[25]),
        .O(error0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__5_i_4
       (.I0(target_angle[24]),
        .I1(angle[24]),
        .O(error0_carry__5_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__6
       (.CI(error0_carry__5_n_0),
        .CO({NLW_error0_carry__6_CO_UNCONNECTED[3],error0_carry__6_n_1,error0_carry__6_n_2,error0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,target_angle[30:28]}),
        .O(error02_out[31:28]),
        .S({error0_carry__6_i_1_n_0,error0_carry__6_i_2_n_0,error0_carry__6_i_3_n_0,error0_carry__6_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__6_i_1
       (.I0(target_angle[31]),
        .I1(angle[31]),
        .O(error0_carry__6_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__6_i_2
       (.I0(target_angle[30]),
        .I1(angle[30]),
        .O(error0_carry__6_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__6_i_3
       (.I0(target_angle[29]),
        .I1(angle[29]),
        .O(error0_carry__6_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry__6_i_4
       (.I0(target_angle[28]),
        .I1(angle[28]),
        .O(error0_carry__6_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1
       (.I0(target_angle[3]),
        .I1(angle[3]),
        .O(error0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2
       (.I0(target_angle[2]),
        .I1(angle[2]),
        .O(error0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3
       (.I0(target_angle[1]),
        .I1(angle[1]),
        .O(error0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4
       (.I0(target_angle[0]),
        .I1(angle[0]),
        .O(error0_carry_i_4_n_0));
  FDRE \error_reg[0] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[0]),
        .Q(error_out[0]),
        .R(1'b0));
  FDRE \error_reg[10] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[10]),
        .Q(error_out[10]),
        .R(1'b0));
  FDRE \error_reg[11] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[11]),
        .Q(error_out[11]),
        .R(1'b0));
  FDRE \error_reg[12] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[12]),
        .Q(error_out[12]),
        .R(1'b0));
  FDRE \error_reg[13] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[13]),
        .Q(error_out[13]),
        .R(1'b0));
  FDRE \error_reg[14] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[14]),
        .Q(error_out[14]),
        .R(1'b0));
  FDRE \error_reg[15] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[15]),
        .Q(error_out[15]),
        .R(1'b0));
  FDRE \error_reg[16] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[16]),
        .Q(error_out[16]),
        .R(1'b0));
  FDRE \error_reg[17] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[17]),
        .Q(error_out[17]),
        .R(1'b0));
  FDRE \error_reg[18] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[18]),
        .Q(error_out[18]),
        .R(1'b0));
  FDRE \error_reg[19] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[19]),
        .Q(error_out[19]),
        .R(1'b0));
  FDRE \error_reg[1] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[1]),
        .Q(error_out[1]),
        .R(1'b0));
  FDRE \error_reg[20] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[20]),
        .Q(error_out[20]),
        .R(1'b0));
  FDRE \error_reg[21] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[21]),
        .Q(error_out[21]),
        .R(1'b0));
  FDRE \error_reg[22] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[22]),
        .Q(error_out[22]),
        .R(1'b0));
  FDRE \error_reg[23] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[23]),
        .Q(error_out[23]),
        .R(1'b0));
  FDRE \error_reg[24] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[24]),
        .Q(error_out[24]),
        .R(1'b0));
  FDRE \error_reg[25] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[25]),
        .Q(error_out[25]),
        .R(1'b0));
  FDRE \error_reg[26] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[26]),
        .Q(error_out[26]),
        .R(1'b0));
  FDRE \error_reg[27] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[27]),
        .Q(error_out[27]),
        .R(1'b0));
  FDRE \error_reg[28] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[28]),
        .Q(error_out[28]),
        .R(1'b0));
  FDRE \error_reg[29] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[29]),
        .Q(error_out[29]),
        .R(1'b0));
  FDRE \error_reg[2] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[2]),
        .Q(error_out[2]),
        .R(1'b0));
  FDRE \error_reg[30] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[30]),
        .Q(error_out[30]),
        .R(1'b0));
  FDRE \error_reg[31] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[31]),
        .Q(error_out[31]),
        .R(1'b0));
  FDRE \error_reg[3] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[3]),
        .Q(error_out[3]),
        .R(1'b0));
  FDRE \error_reg[4] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[4]),
        .Q(error_out[4]),
        .R(1'b0));
  FDRE \error_reg[5] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[5]),
        .Q(error_out[5]),
        .R(1'b0));
  FDRE \error_reg[6] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[6]),
        .Q(error_out[6]),
        .R(1'b0));
  FDRE \error_reg[7] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[7]),
        .Q(error_out[7]),
        .R(1'b0));
  FDRE \error_reg[8] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[8]),
        .Q(error_out[8]),
        .R(1'b0));
  FDRE \error_reg[9] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(error02_out[9]),
        .Q(error_out[9]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry
       (.CI(1'b0),
        .CO({integral0_carry_n_0,integral0_carry_n_1,integral0_carry_n_2,integral0_carry_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[3:0]),
        .O(integral0[3:0]),
        .S({integral0_carry_i_1_n_0,integral0_carry_i_2_n_0,integral0_carry_i_3_n_0,integral0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__0
       (.CI(integral0_carry_n_0),
        .CO({integral0_carry__0_n_0,integral0_carry__0_n_1,integral0_carry__0_n_2,integral0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[7:4]),
        .O(integral0[7:4]),
        .S({integral0_carry__0_i_1_n_0,integral0_carry__0_i_2_n_0,integral0_carry__0_i_3_n_0,integral0_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_1
       (.I0(integral_in[7]),
        .I1(integral1__0_n_98),
        .O(integral0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_2
       (.I0(integral_in[6]),
        .I1(integral1__0_n_99),
        .O(integral0_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_3
       (.I0(integral_in[5]),
        .I1(integral1__0_n_100),
        .O(integral0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__0_i_4
       (.I0(integral_in[4]),
        .I1(integral1__0_n_101),
        .O(integral0_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__1
       (.CI(integral0_carry__0_n_0),
        .CO({integral0_carry__1_n_0,integral0_carry__1_n_1,integral0_carry__1_n_2,integral0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[11:8]),
        .O(integral0[11:8]),
        .S({integral0_carry__1_i_1_n_0,integral0_carry__1_i_2_n_0,integral0_carry__1_i_3_n_0,integral0_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_1
       (.I0(integral_in[11]),
        .I1(integral1__0_n_94),
        .O(integral0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_2
       (.I0(integral_in[10]),
        .I1(integral1__0_n_95),
        .O(integral0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_3
       (.I0(integral_in[9]),
        .I1(integral1__0_n_96),
        .O(integral0_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__1_i_4
       (.I0(integral_in[8]),
        .I1(integral1__0_n_97),
        .O(integral0_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__2
       (.CI(integral0_carry__1_n_0),
        .CO({integral0_carry__2_n_0,integral0_carry__2_n_1,integral0_carry__2_n_2,integral0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[15:12]),
        .O(integral0[15:12]),
        .S({integral0_carry__2_i_1_n_0,integral0_carry__2_i_2_n_0,integral0_carry__2_i_3_n_0,integral0_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_1
       (.I0(integral_in[15]),
        .I1(integral1__0_n_90),
        .O(integral0_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_2
       (.I0(integral_in[14]),
        .I1(integral1__0_n_91),
        .O(integral0_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_3
       (.I0(integral_in[13]),
        .I1(integral1__0_n_92),
        .O(integral0_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__2_i_4
       (.I0(integral_in[12]),
        .I1(integral1__0_n_93),
        .O(integral0_carry__2_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__3
       (.CI(integral0_carry__2_n_0),
        .CO({integral0_carry__3_n_0,integral0_carry__3_n_1,integral0_carry__3_n_2,integral0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[19:16]),
        .O(integral0[19:16]),
        .S({integral0_carry__3_i_1_n_0,integral0_carry__3_i_2_n_0,integral0_carry__3_i_3_n_0,integral0_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_1
       (.I0(integral_in[19]),
        .I1(integral1_carry_n_4),
        .O(integral0_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_2
       (.I0(integral_in[18]),
        .I1(integral1_carry_n_5),
        .O(integral0_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_3
       (.I0(integral_in[17]),
        .I1(integral1_carry_n_6),
        .O(integral0_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__3_i_4
       (.I0(integral_in[16]),
        .I1(integral1_carry_n_7),
        .O(integral0_carry__3_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__4
       (.CI(integral0_carry__3_n_0),
        .CO({integral0_carry__4_n_0,integral0_carry__4_n_1,integral0_carry__4_n_2,integral0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[23:20]),
        .O(integral0[23:20]),
        .S({integral0_carry__4_i_1_n_0,integral0_carry__4_i_2_n_0,integral0_carry__4_i_3_n_0,integral0_carry__4_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_1
       (.I0(integral_in[23]),
        .I1(integral1_carry__0_n_4),
        .O(integral0_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_2
       (.I0(integral_in[22]),
        .I1(integral1_carry__0_n_5),
        .O(integral0_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_3
       (.I0(integral_in[21]),
        .I1(integral1_carry__0_n_6),
        .O(integral0_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__4_i_4
       (.I0(integral_in[20]),
        .I1(integral1_carry__0_n_7),
        .O(integral0_carry__4_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__5
       (.CI(integral0_carry__4_n_0),
        .CO({integral0_carry__5_n_0,integral0_carry__5_n_1,integral0_carry__5_n_2,integral0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[27:24]),
        .O(integral0[27:24]),
        .S({integral0_carry__5_i_1_n_0,integral0_carry__5_i_2_n_0,integral0_carry__5_i_3_n_0,integral0_carry__5_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__5_i_1
       (.I0(integral_in[27]),
        .I1(integral1_carry__1_n_4),
        .O(integral0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__5_i_2
       (.I0(integral_in[26]),
        .I1(integral1_carry__1_n_5),
        .O(integral0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__5_i_3
       (.I0(integral_in[25]),
        .I1(integral1_carry__1_n_6),
        .O(integral0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__5_i_4
       (.I0(integral_in[24]),
        .I1(integral1_carry__1_n_7),
        .O(integral0_carry__5_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__6
       (.CI(integral0_carry__5_n_0),
        .CO({NLW_integral0_carry__6_CO_UNCONNECTED[3],integral0_carry__6_n_1,integral0_carry__6_n_2,integral0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,integral_in[30:28]}),
        .O(integral0[31:28]),
        .S({integral0_carry__6_i_1_n_0,integral0_carry__6_i_2_n_0,integral0_carry__6_i_3_n_0,integral0_carry__6_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__6_i_1
       (.I0(integral_in[31]),
        .I1(integral1_carry__2_n_4),
        .O(integral0_carry__6_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__6_i_2
       (.I0(integral_in[30]),
        .I1(integral1_carry__2_n_5),
        .O(integral0_carry__6_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__6_i_3
       (.I0(integral_in[29]),
        .I1(integral1_carry__2_n_6),
        .O(integral0_carry__6_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry__6_i_4
       (.I0(integral_in[28]),
        .I1(integral1_carry__2_n_7),
        .O(integral0_carry__6_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1
       (.I0(integral_in[3]),
        .I1(integral1__0_n_102),
        .O(integral0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2
       (.I0(integral_in[2]),
        .I1(integral1__0_n_103),
        .O(integral0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3
       (.I0(integral_in[1]),
        .I1(integral1__0_n_104),
        .O(integral0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4
       (.I0(integral_in[0]),
        .I1(integral1__0_n_105),
        .O(integral0_carry_i_4_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 16x18 4}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    integral1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dt[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_integral1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,error02_out[31:17]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_integral1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_integral1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_integral1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_integral1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_integral1_OVERFLOW_UNCONNECTED),
        .P({integral1_n_58,integral1_n_59,integral1_n_60,integral1_n_61,integral1_n_62,integral1_n_63,integral1_n_64,integral1_n_65,integral1_n_66,integral1_n_67,integral1_n_68,integral1_n_69,integral1_n_70,integral1_n_71,integral1_n_72,integral1_n_73,integral1_n_74,integral1_n_75,integral1_n_76,integral1_n_77,integral1_n_78,integral1_n_79,integral1_n_80,integral1_n_81,integral1_n_82,integral1_n_83,integral1_n_84,integral1_n_85,integral1_n_86,integral1_n_87,integral1_n_88,integral1_n_89,integral1_n_90,integral1_n_91,integral1_n_92,integral1_n_93,integral1_n_94,integral1_n_95,integral1_n_96,integral1_n_97,integral1_n_98,integral1_n_99,integral1_n_100,integral1_n_101,integral1_n_102,integral1_n_103,integral1_n_104,integral1_n_105}),
        .PATTERNBDETECT(NLW_integral1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_integral1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({integral1_n_106,integral1_n_107,integral1_n_108,integral1_n_109,integral1_n_110,integral1_n_111,integral1_n_112,integral1_n_113,integral1_n_114,integral1_n_115,integral1_n_116,integral1_n_117,integral1_n_118,integral1_n_119,integral1_n_120,integral1_n_121,integral1_n_122,integral1_n_123,integral1_n_124,integral1_n_125,integral1_n_126,integral1_n_127,integral1_n_128,integral1_n_129,integral1_n_130,integral1_n_131,integral1_n_132,integral1_n_133,integral1_n_134,integral1_n_135,integral1_n_136,integral1_n_137,integral1_n_138,integral1_n_139,integral1_n_140,integral1_n_141,integral1_n_142,integral1_n_143,integral1_n_144,integral1_n_145,integral1_n_146,integral1_n_147,integral1_n_148,integral1_n_149,integral1_n_150,integral1_n_151,integral1_n_152,integral1_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_integral1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 18x18 4}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    integral1__0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,error02_out[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_integral1__0_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,dt[16:0]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_integral1__0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_integral1__0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_integral1__0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_integral1__0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_integral1__0_OVERFLOW_UNCONNECTED),
        .P({integral1__0_n_58,integral1__0_n_59,integral1__0_n_60,integral1__0_n_61,integral1__0_n_62,integral1__0_n_63,integral1__0_n_64,integral1__0_n_65,integral1__0_n_66,integral1__0_n_67,integral1__0_n_68,integral1__0_n_69,integral1__0_n_70,integral1__0_n_71,integral1__0_n_72,integral1__0_n_73,integral1__0_n_74,integral1__0_n_75,integral1__0_n_76,integral1__0_n_77,integral1__0_n_78,integral1__0_n_79,integral1__0_n_80,integral1__0_n_81,integral1__0_n_82,integral1__0_n_83,integral1__0_n_84,integral1__0_n_85,integral1__0_n_86,integral1__0_n_87,integral1__0_n_88,integral1__0_n_89,integral1__0_n_90,integral1__0_n_91,integral1__0_n_92,integral1__0_n_93,integral1__0_n_94,integral1__0_n_95,integral1__0_n_96,integral1__0_n_97,integral1__0_n_98,integral1__0_n_99,integral1__0_n_100,integral1__0_n_101,integral1__0_n_102,integral1__0_n_103,integral1__0_n_104,integral1__0_n_105}),
        .PATTERNBDETECT(NLW_integral1__0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_integral1__0_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({integral1__0_n_106,integral1__0_n_107,integral1__0_n_108,integral1__0_n_109,integral1__0_n_110,integral1__0_n_111,integral1__0_n_112,integral1__0_n_113,integral1__0_n_114,integral1__0_n_115,integral1__0_n_116,integral1__0_n_117,integral1__0_n_118,integral1__0_n_119,integral1__0_n_120,integral1__0_n_121,integral1__0_n_122,integral1__0_n_123,integral1__0_n_124,integral1__0_n_125,integral1__0_n_126,integral1__0_n_127,integral1__0_n_128,integral1__0_n_129,integral1__0_n_130,integral1__0_n_131,integral1__0_n_132,integral1__0_n_133,integral1__0_n_134,integral1__0_n_135,integral1__0_n_136,integral1__0_n_137,integral1__0_n_138,integral1__0_n_139,integral1__0_n_140,integral1__0_n_141,integral1__0_n_142,integral1__0_n_143,integral1__0_n_144,integral1__0_n_145,integral1__0_n_146,integral1__0_n_147,integral1__0_n_148,integral1__0_n_149,integral1__0_n_150,integral1__0_n_151,integral1__0_n_152,integral1__0_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_integral1__0_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 18x16 4}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    integral1__1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,error02_out[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_integral1__1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,dt[31:17]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_integral1__1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_integral1__1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_integral1__1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_integral1__1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_integral1__1_OVERFLOW_UNCONNECTED),
        .P({integral1__1_n_58,integral1__1_n_59,integral1__1_n_60,integral1__1_n_61,integral1__1_n_62,integral1__1_n_63,integral1__1_n_64,integral1__1_n_65,integral1__1_n_66,integral1__1_n_67,integral1__1_n_68,integral1__1_n_69,integral1__1_n_70,integral1__1_n_71,integral1__1_n_72,integral1__1_n_73,integral1__1_n_74,integral1__1_n_75,integral1__1_n_76,integral1__1_n_77,integral1__1_n_78,integral1__1_n_79,integral1__1_n_80,integral1__1_n_81,integral1__1_n_82,integral1__1_n_83,integral1__1_n_84,integral1__1_n_85,integral1__1_n_86,integral1__1_n_87,integral1__1_n_88,integral1__1_n_89,integral1__1_n_90,integral1__1_n_91,integral1__1_n_92,integral1__1_n_93,integral1__1_n_94,integral1__1_n_95,integral1__1_n_96,integral1__1_n_97,integral1__1_n_98,integral1__1_n_99,integral1__1_n_100,integral1__1_n_101,integral1__1_n_102,integral1__1_n_103,integral1__1_n_104,integral1__1_n_105}),
        .PATTERNBDETECT(NLW_integral1__1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_integral1__1_PATTERNDETECT_UNCONNECTED),
        .PCIN({integral1__0_n_106,integral1__0_n_107,integral1__0_n_108,integral1__0_n_109,integral1__0_n_110,integral1__0_n_111,integral1__0_n_112,integral1__0_n_113,integral1__0_n_114,integral1__0_n_115,integral1__0_n_116,integral1__0_n_117,integral1__0_n_118,integral1__0_n_119,integral1__0_n_120,integral1__0_n_121,integral1__0_n_122,integral1__0_n_123,integral1__0_n_124,integral1__0_n_125,integral1__0_n_126,integral1__0_n_127,integral1__0_n_128,integral1__0_n_129,integral1__0_n_130,integral1__0_n_131,integral1__0_n_132,integral1__0_n_133,integral1__0_n_134,integral1__0_n_135,integral1__0_n_136,integral1__0_n_137,integral1__0_n_138,integral1__0_n_139,integral1__0_n_140,integral1__0_n_141,integral1__0_n_142,integral1__0_n_143,integral1__0_n_144,integral1__0_n_145,integral1__0_n_146,integral1__0_n_147,integral1__0_n_148,integral1__0_n_149,integral1__0_n_150,integral1__0_n_151,integral1__0_n_152,integral1__0_n_153}),
        .PCOUT(NLW_integral1__1_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_integral1__1_UNDERFLOW_UNCONNECTED));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry
       (.CI(1'b0),
        .CO({integral1_carry_n_0,integral1_carry_n_1,integral1_carry_n_2,integral1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({integral1__1_n_103,integral1__1_n_104,integral1__1_n_105,1'b0}),
        .O({integral1_carry_n_4,integral1_carry_n_5,integral1_carry_n_6,integral1_carry_n_7}),
        .S({integral1_carry_i_1_n_0,integral1_carry_i_2_n_0,integral1_carry_i_3_n_0,integral1__0_n_89}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry__0
       (.CI(integral1_carry_n_0),
        .CO({integral1_carry__0_n_0,integral1_carry__0_n_1,integral1_carry__0_n_2,integral1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({integral1__1_n_99,integral1__1_n_100,integral1__1_n_101,integral1__1_n_102}),
        .O({integral1_carry__0_n_4,integral1_carry__0_n_5,integral1_carry__0_n_6,integral1_carry__0_n_7}),
        .S({integral1_carry__0_i_1_n_0,integral1_carry__0_i_2_n_0,integral1_carry__0_i_3_n_0,integral1_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_1
       (.I0(integral1__1_n_99),
        .I1(integral1_n_99),
        .O(integral1_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_2
       (.I0(integral1__1_n_100),
        .I1(integral1_n_100),
        .O(integral1_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_3
       (.I0(integral1__1_n_101),
        .I1(integral1_n_101),
        .O(integral1_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_4
       (.I0(integral1__1_n_102),
        .I1(integral1_n_102),
        .O(integral1_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry__1
       (.CI(integral1_carry__0_n_0),
        .CO({integral1_carry__1_n_0,integral1_carry__1_n_1,integral1_carry__1_n_2,integral1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({integral1__1_n_95,integral1__1_n_96,integral1__1_n_97,integral1__1_n_98}),
        .O({integral1_carry__1_n_4,integral1_carry__1_n_5,integral1_carry__1_n_6,integral1_carry__1_n_7}),
        .S({integral1_carry__1_i_1_n_0,integral1_carry__1_i_2_n_0,integral1_carry__1_i_3_n_0,integral1_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_1
       (.I0(integral1__1_n_95),
        .I1(integral1_n_95),
        .O(integral1_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_2
       (.I0(integral1__1_n_96),
        .I1(integral1_n_96),
        .O(integral1_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_3
       (.I0(integral1__1_n_97),
        .I1(integral1_n_97),
        .O(integral1_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_4
       (.I0(integral1__1_n_98),
        .I1(integral1_n_98),
        .O(integral1_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry__2
       (.CI(integral1_carry__1_n_0),
        .CO({NLW_integral1_carry__2_CO_UNCONNECTED[3],integral1_carry__2_n_1,integral1_carry__2_n_2,integral1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,integral1__1_n_92,integral1__1_n_93,integral1__1_n_94}),
        .O({integral1_carry__2_n_4,integral1_carry__2_n_5,integral1_carry__2_n_6,integral1_carry__2_n_7}),
        .S({integral1_carry__2_i_1_n_0,integral1_carry__2_i_2_n_0,integral1_carry__2_i_3_n_0,integral1_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_1
       (.I0(integral1__1_n_91),
        .I1(integral1_n_91),
        .O(integral1_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_2
       (.I0(integral1__1_n_92),
        .I1(integral1_n_92),
        .O(integral1_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_3
       (.I0(integral1__1_n_93),
        .I1(integral1_n_93),
        .O(integral1_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_4
       (.I0(integral1__1_n_94),
        .I1(integral1_n_94),
        .O(integral1_carry__2_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry_i_1
       (.I0(integral1__1_n_103),
        .I1(integral1_n_103),
        .O(integral1_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry_i_2
       (.I0(integral1__1_n_104),
        .I1(integral1_n_104),
        .O(integral1_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry_i_3
       (.I0(integral1__1_n_105),
        .I1(integral1_n_105),
        .O(integral1_carry_i_3_n_0));
  FDRE \integral_reg[0] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[0]),
        .Q(integral_out[0]),
        .R(new_target_angle_available));
  FDRE \integral_reg[10] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[10]),
        .Q(integral_out[10]),
        .R(new_target_angle_available));
  FDRE \integral_reg[11] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[11]),
        .Q(integral_out[11]),
        .R(new_target_angle_available));
  FDRE \integral_reg[12] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[12]),
        .Q(integral_out[12]),
        .R(new_target_angle_available));
  FDRE \integral_reg[13] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[13]),
        .Q(integral_out[13]),
        .R(new_target_angle_available));
  FDRE \integral_reg[14] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[14]),
        .Q(integral_out[14]),
        .R(new_target_angle_available));
  FDRE \integral_reg[15] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[15]),
        .Q(integral_out[15]),
        .R(new_target_angle_available));
  FDRE \integral_reg[16] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[16]),
        .Q(integral_out[16]),
        .R(new_target_angle_available));
  FDRE \integral_reg[17] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[17]),
        .Q(integral_out[17]),
        .R(new_target_angle_available));
  FDRE \integral_reg[18] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[18]),
        .Q(integral_out[18]),
        .R(new_target_angle_available));
  FDRE \integral_reg[19] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[19]),
        .Q(integral_out[19]),
        .R(new_target_angle_available));
  FDRE \integral_reg[1] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[1]),
        .Q(integral_out[1]),
        .R(new_target_angle_available));
  FDRE \integral_reg[20] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[20]),
        .Q(integral_out[20]),
        .R(new_target_angle_available));
  FDRE \integral_reg[21] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[21]),
        .Q(integral_out[21]),
        .R(new_target_angle_available));
  FDRE \integral_reg[22] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[22]),
        .Q(integral_out[22]),
        .R(new_target_angle_available));
  FDRE \integral_reg[23] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[23]),
        .Q(integral_out[23]),
        .R(new_target_angle_available));
  FDRE \integral_reg[24] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[24]),
        .Q(integral_out[24]),
        .R(new_target_angle_available));
  FDRE \integral_reg[25] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[25]),
        .Q(integral_out[25]),
        .R(new_target_angle_available));
  FDRE \integral_reg[26] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[26]),
        .Q(integral_out[26]),
        .R(new_target_angle_available));
  FDRE \integral_reg[27] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[27]),
        .Q(integral_out[27]),
        .R(new_target_angle_available));
  FDRE \integral_reg[28] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[28]),
        .Q(integral_out[28]),
        .R(new_target_angle_available));
  FDRE \integral_reg[29] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[29]),
        .Q(integral_out[29]),
        .R(new_target_angle_available));
  FDRE \integral_reg[2] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[2]),
        .Q(integral_out[2]),
        .R(new_target_angle_available));
  FDRE \integral_reg[30] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[30]),
        .Q(integral_out[30]),
        .R(new_target_angle_available));
  FDRE \integral_reg[31] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[31]),
        .Q(integral_out[31]),
        .R(new_target_angle_available));
  FDRE \integral_reg[3] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[3]),
        .Q(integral_out[3]),
        .R(new_target_angle_available));
  FDRE \integral_reg[4] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[4]),
        .Q(integral_out[4]),
        .R(new_target_angle_available));
  FDRE \integral_reg[5] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[5]),
        .Q(integral_out[5]),
        .R(new_target_angle_available));
  FDRE \integral_reg[6] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[6]),
        .Q(integral_out[6]),
        .R(new_target_angle_available));
  FDRE \integral_reg[7] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[7]),
        .Q(integral_out[7]),
        .R(new_target_angle_available));
  FDRE \integral_reg[8] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[8]),
        .Q(integral_out[8]),
        .R(new_target_angle_available));
  FDRE \integral_reg[9] 
       (.C(new_angle_available),
        .CE(1'b1),
        .D(integral0[9]),
        .Q(integral_out[9]),
        .R(new_target_angle_available));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
