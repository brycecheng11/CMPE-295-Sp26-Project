// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Sep 21 21:48:48 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_k_math_0_0_sim_netlist.v
// Design      : design_1_k_math_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_k_math_0_0,k_math,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "k_math,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clock,
    kp_in,
    ki_in,
    kd_in,
    kp_out,
    ki_out,
    kd_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN design_1_sys_clock, INSERT_VIP 0" *) input [0:0]clock;
  input [11:0]kp_in;
  input [11:0]ki_in;
  input [11:0]kd_in;
  output [8:0]kp_out;
  output [8:0]ki_out;
  output [8:0]kd_out;

  wire \<const0> ;
  wire [0:0]clock;
  wire [11:0]kd_in;
  wire [7:0]\^kd_out ;
  wire [11:0]ki_in;
  wire [7:0]\^ki_out ;
  wire [11:0]kp_in;
  wire [7:0]\^kp_out ;

  assign kd_out[8] = \<const0> ;
  assign kd_out[7:0] = \^kd_out [7:0];
  assign ki_out[8] = \<const0> ;
  assign ki_out[7:0] = \^ki_out [7:0];
  assign kp_out[8] = \<const0> ;
  assign kp_out[7:0] = \^kp_out [7:0];
  GND GND
       (.G(\<const0> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_k_math inst
       (.clock(clock),
        .kd_in(kd_in[11:4]),
        .kd_out(\^kd_out ),
        .ki_in(ki_in[11:4]),
        .ki_out(\^ki_out ),
        .kp_in(kp_in[11:4]),
        .kp_out(\^kp_out ));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_k_math
   (kp_out,
    ki_out,
    kd_out,
    kp_in,
    clock,
    ki_in,
    kd_in);
  output [7:0]kp_out;
  output [7:0]ki_out;
  output [7:0]kd_out;
  input [7:0]kp_in;
  input [0:0]clock;
  input [7:0]ki_in;
  input [7:0]kd_in;

  wire [0:0]clock;
  wire [7:0]kd_in;
  wire [7:0]kd_out;
  wire [7:0]ki_in;
  wire [7:0]ki_out;
  wire [7:0]kp_in;
  wire [7:0]kp_out;

  FDRE \kd_signed_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[0]),
        .Q(kd_out[0]),
        .R(1'b0));
  FDRE \kd_signed_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[1]),
        .Q(kd_out[1]),
        .R(1'b0));
  FDRE \kd_signed_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[2]),
        .Q(kd_out[2]),
        .R(1'b0));
  FDRE \kd_signed_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[3]),
        .Q(kd_out[3]),
        .R(1'b0));
  FDRE \kd_signed_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[4]),
        .Q(kd_out[4]),
        .R(1'b0));
  FDRE \kd_signed_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[5]),
        .Q(kd_out[5]),
        .R(1'b0));
  FDRE \kd_signed_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[6]),
        .Q(kd_out[6]),
        .R(1'b0));
  FDRE \kd_signed_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(kd_in[7]),
        .Q(kd_out[7]),
        .R(1'b0));
  FDRE \ki_signed_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[0]),
        .Q(ki_out[0]),
        .R(1'b0));
  FDRE \ki_signed_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[1]),
        .Q(ki_out[1]),
        .R(1'b0));
  FDRE \ki_signed_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[2]),
        .Q(ki_out[2]),
        .R(1'b0));
  FDRE \ki_signed_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[3]),
        .Q(ki_out[3]),
        .R(1'b0));
  FDRE \ki_signed_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[4]),
        .Q(ki_out[4]),
        .R(1'b0));
  FDRE \ki_signed_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[5]),
        .Q(ki_out[5]),
        .R(1'b0));
  FDRE \ki_signed_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[6]),
        .Q(ki_out[6]),
        .R(1'b0));
  FDRE \ki_signed_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(ki_in[7]),
        .Q(ki_out[7]),
        .R(1'b0));
  FDRE \kp_signed_reg[0] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[0]),
        .Q(kp_out[0]),
        .R(1'b0));
  FDRE \kp_signed_reg[1] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[1]),
        .Q(kp_out[1]),
        .R(1'b0));
  FDRE \kp_signed_reg[2] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[2]),
        .Q(kp_out[2]),
        .R(1'b0));
  FDRE \kp_signed_reg[3] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[3]),
        .Q(kp_out[3]),
        .R(1'b0));
  FDRE \kp_signed_reg[4] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[4]),
        .Q(kp_out[4]),
        .R(1'b0));
  FDRE \kp_signed_reg[5] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[5]),
        .Q(kp_out[5]),
        .R(1'b0));
  FDRE \kp_signed_reg[6] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[6]),
        .Q(kp_out[6]),
        .R(1'b0));
  FDRE \kp_signed_reg[7] 
       (.C(clock),
        .CE(1'b1),
        .D(kp_in[7]),
        .Q(kp_out[7]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
