-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Mon Nov  9 23:27:03 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_expand_time_initial_math_0_0_stub.vhdl
-- Design      : pid_expand_time_initial_math_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clock : in STD_LOGIC;
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    target_angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    new_target_angle_available : in STD_LOGIC;
    ps_ready_in : in STD_LOGIC;
    timestamp_new : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    timestamp_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    ps_ready_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    timestamp_out : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock,angle[31:0],target_angle[31:0],new_target_angle_available,ps_ready_in,timestamp_new[31:0],error_in[31:0],integral_in[31:0],timestamp_in[31:0],ps_ready_out[31:0],error_out[31:0],integral_out[31:0],derivative_out[31:0],timestamp_out[31:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "initial_math,Vivado 2021.1";
begin
end;
