-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Tue Nov 24 12:52:23 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ pid_expand_time_term_calculation_0_0_stub.vhdl
-- Design      : pid_expand_time_term_calculation_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clock : in STD_LOGIC;
    ps_ready_in : in STD_LOGIC;
    angle : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral : in STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ps_ready_out : out STD_LOGIC;
    p_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock,ps_ready_in,angle[31:0],error[31:0],integral[31:0],derivative[31:0],kp[8:0],ki[8:0],kd[8:0],ps_ready_out,p_term[31:0],i_term[31:0],d_term[31:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "term_calculation,Vivado 2021.1";
begin
end;
