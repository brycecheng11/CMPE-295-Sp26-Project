`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 04:59:40 PM
// Design Name: 
// Module Name: term_calculation
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module term_calculation(
    input                   clock, 
    
    input                   ps_ready_in, 
    
    input   signed  [31:0]  error,
    input   signed  [31:0]  integral, 
    input   signed  [31:0]  derivative, 
    
    input   signed   [8:0]  kp,
    input   signed   [8:0]  ki,
    input   signed   [8:0]  kd,
    
    output                  ps_ready_out,

    output          [31:0]  p_term, 
    output          [31:0]  i_term,
    output          [31:0]  d_term
    );
    
    reg             [31:0]  ps_ready; 
    
    reg     signed  [31:0]  p_term_interim; 
    reg     signed  [31:0]  i_term_interim; 
    reg     signed  [31:0]  d_term_interim; 
    
    
    assign ps_ready_out = ps_ready; 
    
    assign p_term = p_term_interim; 
    assign i_term = i_term_interim; 
    assign d_term = d_term_interim;
    
    initial begin 
        ps_ready <= 0; 
        p_term_interim <= 0; 
        i_term_interim <= 0; 
        d_term_interim <= 0; 
    end
    
    always @(posedge clock) begin 
        ps_ready <= ps_ready_in; 
        if (ps_ready) begin
            p_term_interim <= (kp * error) << 7; 
            i_term_interim <= ki * integral; 
            d_term_interim <= kd * derivative; 
        end
    end
    
endmodule
