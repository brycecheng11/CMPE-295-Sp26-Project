`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/04/2026 02:02:55 AM
// Design Name: 
// Module Name: prev_value_flip_flop
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module prev_value_flip_flop(
    input                   clock, 
    input                   new_target_angle_available, 
    input   signed  [31:0]  error_in, 
    input   signed  [31:0]  integral_in, 
    input           [31:0]  timestamp_in, 
    
    
    output  signed  [31:0]  error_out, 
    output  signed  [31:0]  integral_out, 
    output          [31:0]  timestamp_out

    );
    
    reg     signed  [31:0]  error;
    reg     signed  [31:0]  integral;
    reg     signed  [31:0]  timestamp; 
    
    assign error_out = error;
    assign integral_out = integral; 
    assign timestamp_out = timestamp; 
    
    initial begin 
        error <= 0; 
        integral <= 0; 
        timestamp <= 0; 
    end 
        
    always @ (posedge clock) begin 
        error <= error_in; 
        timestamp <= timestamp_in; 
        if (new_target_angle_available == 1'b1) begin 
            integral <= 0; 
        end
        else begin 
            if (integral_in == 32'sd0) begin 
                integral <= 32'sd1; 
            end 
            else begin
                integral <= integral_in; 
            end
        end 
    end 
    
    
endmodule
