`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/02/2026 04:59:40 PM
// Design Name: 
// Module Name: initial_math
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module initial_math(
    input                   clock,
    input   signed  [31:0]  angle,
    
    input   signed  [31:0]  target_angle, 
    input                   new_target_angle_available,
    
    input                   ps_ready_in, 
    input           [31:0]  timestamp_new,
    
    input   signed  [31:0]  error_in,
    input   signed  [31:0]  integral_in,
    input           [31:0]  timestamp_in, 
    
    output          [31:0]  ps_ready_out,
    
    output  signed  [31:0]  error_out,
    output  signed  [31:0]  integral_out, 
    output  signed  [31:0]  derivative_out,
    output          [31:0]  timestamp_out
    );
    
    reg                     clock_count; 
    reg                     ps_ready;
    
    reg     signed  [31:0]  error;
    reg     signed  [31:0]  integral; 
    reg     signed  [31:0]  derivative;
    reg             [31:0]  timestamp_saved; 
    reg     signed  [31:0]  dt; 
    
    reg     signed  [31:0]  saved_target_angle; 
    
    assign ps_ready_out = ps_ready; 
    assign error_out = error; 
    assign integral_out = integral; 
    assign derivative_out = derivative; 
    assign timestamp_out = timestamp_saved; 
    
    initial begin 
        ps_ready <= 0; 
        error <= 0; 
        integral <= 0; 
        derivative <= 0; 
        timestamp_saved <= 0; 
        dt <= 0; 
        saved_target_angle <= 0; 
        clock_count <= 0; 
    end 
    
    always @(posedge clock) begin 
        ps_ready <= ps_ready_in; 
        if (ps_ready) begin 
            timestamp_saved <= timestamp_new;
            if (timestamp_new > timestamp_in) begin 
                dt = $signed(timestamp_new - timestamp_in); 
            end 
            else begin 
                dt = $signed(~(timestamp_new - timestamp_in) + 1);
            end 
            if (clock_count == 0) begin 
                clock_count <= 1; 
                integral <= 0;
            end 
            else begin 
                if (new_target_angle_available == 1'b1) begin 
                    clock_count <= 0; 
                    saved_target_angle <= target_angle; 
                    integral <= 0;
                end 
                else begin 
                    error <= saved_target_angle - angle; 
                    integral <= integral_in + (error * dt); 
                    if (dt == 32'd0) begin 
                        derivative <= 0; 
                    end
                    else begin 
                        derivative <= (error - error_in) / dt; 
                    end
                end 
            end
        end
    end
    
    
    
endmodule
