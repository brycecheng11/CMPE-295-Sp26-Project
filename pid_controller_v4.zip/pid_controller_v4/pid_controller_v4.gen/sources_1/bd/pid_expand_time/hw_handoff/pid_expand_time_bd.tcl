
################################################################
# This is a generated script based on design: pid_expand_time
#
# Though there are limitations about the generated script,
# the main purpose of this utility is to make learning
# IP Integrator Tcl commands easier.
################################################################

namespace eval _tcl {
proc get_script_folder {} {
   set script_path [file normalize [info script]]
   set script_folder [file dirname $script_path]
   return $script_folder
}
}
variable script_folder
set script_folder [_tcl::get_script_folder]

################################################################
# Check if script is running in correct Vivado version.
################################################################
set scripts_vivado_version 2021.1
set current_vivado_version [version -short]

if { [string first $scripts_vivado_version $current_vivado_version] == -1 } {
   puts ""
   catch {common::send_gid_msg -ssname BD::TCL -id 2041 -severity "ERROR" "This script was generated using Vivado <$scripts_vivado_version> and is being run in <$current_vivado_version> of Vivado. Please run the script in Vivado <$scripts_vivado_version> then open the design in Vivado <$current_vivado_version>. Upgrade the design by running \"Tools => Report => Report IP Status...\", then run write_bd_tcl to create an updated script."}

   return 1
}

################################################################
# START
################################################################

# To test this script, run the following commands from Vivado Tcl console:
# source pid_expand_time_script.tcl


# The design that will be created by this Tcl script contains the following 
# module references:
# initial_math, k_math, prev_value_flip_flop, term_calculation, velocity_calculation

# Please add the sources of those modules before sourcing this Tcl script.

# If there is no project opened, this script will create a
# project, but make sure you do not have an existing project
# <./myproj/project_1.xpr> in the current working folder.

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
   create_project project_1 myproj -part xc7z020clg400-1
   set_property BOARD_PART digilentinc.com:zybo-z7-20:part0:1.2 [current_project]
}


# CHANGE DESIGN NAME HERE
variable design_name
set design_name pid_expand_time

# If you do not already have an existing IP Integrator design open,
# you can create a design using the following command:
#    create_bd_design $design_name

# Creating design if needed
set errMsg ""
set nRet 0

set cur_design [current_bd_design -quiet]
set list_cells [get_bd_cells -quiet]

if { ${design_name} eq "" } {
   # USE CASES:
   #    1) Design_name not set

   set errMsg "Please set the variable <design_name> to a non-empty value."
   set nRet 1

} elseif { ${cur_design} ne "" && ${list_cells} eq "" } {
   # USE CASES:
   #    2): Current design opened AND is empty AND names same.
   #    3): Current design opened AND is empty AND names diff; design_name NOT in project.
   #    4): Current design opened AND is empty AND names diff; design_name exists in project.

   if { $cur_design ne $design_name } {
      common::send_gid_msg -ssname BD::TCL -id 2001 -severity "INFO" "Changing value of <design_name> from <$design_name> to <$cur_design> since current design is empty."
      set design_name [get_property NAME $cur_design]
   }
   common::send_gid_msg -ssname BD::TCL -id 2002 -severity "INFO" "Constructing design in IPI design <$cur_design>..."

} elseif { ${cur_design} ne "" && $list_cells ne "" && $cur_design eq $design_name } {
   # USE CASES:
   #    5) Current design opened AND has components AND same names.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 1
} elseif { [get_files -quiet ${design_name}.bd] ne "" } {
   # USE CASES: 
   #    6) Current opened design, has components, but diff names, design_name exists in project.
   #    7) No opened design, design_name exists in project.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 2

} else {
   # USE CASES:
   #    8) No opened design, design_name not in project.
   #    9) Current opened design, has components, but diff names, design_name not in project.

   common::send_gid_msg -ssname BD::TCL -id 2003 -severity "INFO" "Currently there is no design <$design_name> in project, so creating one..."

   create_bd_design $design_name

   common::send_gid_msg -ssname BD::TCL -id 2004 -severity "INFO" "Making design <$design_name> as current_bd_design."
   current_bd_design $design_name

}

common::send_gid_msg -ssname BD::TCL -id 2005 -severity "INFO" "Currently the variable <design_name> is equal to \"$design_name\"."

if { $nRet != 0 } {
   catch {common::send_gid_msg -ssname BD::TCL -id 2006 -severity "ERROR" $errMsg}
   return $nRet
}

##################################################################
# DESIGN PROCs
##################################################################



# Procedure to create entire design; Provide argument to make
# procedure reusable. If parentCell is "", will use root.
proc create_root_design { parentCell } {

  variable script_folder
  variable design_name

  if { $parentCell eq "" } {
     set parentCell [get_bd_cells /]
  }

  # Get object for parentCell
  set parentObj [get_bd_cells $parentCell]
  if { $parentObj == "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2090 -severity "ERROR" "Unable to find parent cell <$parentCell>!"}
     return
  }

  # Make sure parentObj is hier blk
  set parentType [get_property TYPE $parentObj]
  if { $parentType ne "hier" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2091 -severity "ERROR" "Parent <$parentObj> has TYPE = <$parentType>. Expected to be <hier>."}
     return
  }

  # Save current instance; Restore later
  set oldCurInst [current_bd_instance .]

  # Set parent object as current
  current_bd_instance $parentObj


  # Create interface ports

  # Create ports
  set angle_0 [ create_bd_port -dir I -from 31 -to 0 angle_0 ]
  set d_term_0 [ create_bd_port -dir O -from 31 -to 0 d_term_0 ]
  set i_term_0 [ create_bd_port -dir O -from 31 -to 0 i_term_0 ]
  set kd_in_0 [ create_bd_port -dir I -from 11 -to 0 kd_in_0 ]
  set ki_in_0 [ create_bd_port -dir I -from 11 -to 0 ki_in_0 ]
  set kp_in_0 [ create_bd_port -dir I -from 11 -to 0 kp_in_0 ]
  set new_target_angle_available_0 [ create_bd_port -dir I new_target_angle_available_0 ]
  set new_velocity_available_0 [ create_bd_port -dir O new_velocity_available_0 ]
  set output_velocity_0 [ create_bd_port -dir O -from 31 -to 0 output_velocity_0 ]
  set p_term_0 [ create_bd_port -dir O -from 31 -to 0 p_term_0 ]
  set ps_ready_0 [ create_bd_port -dir I ps_ready_0 ]
  set sys_clk [ create_bd_port -dir I -type clk sys_clk ]
  set target_angle_0 [ create_bd_port -dir I -from 31 -to 0 target_angle_0 ]
  set timestamp_new_0 [ create_bd_port -dir I -from 31 -to 0 timestamp_new_0 ]

  # Create instance: initial_math_0, and set properties
  set block_name initial_math
  set block_cell_name initial_math_0
  if { [catch {set initial_math_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $initial_math_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: k_math_0, and set properties
  set block_name k_math
  set block_cell_name k_math_0
  if { [catch {set k_math_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $k_math_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: prev_value_flip_flop_0, and set properties
  set block_name prev_value_flip_flop
  set block_cell_name prev_value_flip_flop_0
  if { [catch {set prev_value_flip_flop_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $prev_value_flip_flop_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: term_calculation_0, and set properties
  set block_name term_calculation
  set block_cell_name term_calculation_0
  if { [catch {set term_calculation_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $term_calculation_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: velocity_calculation_0, and set properties
  set block_name velocity_calculation
  set block_cell_name velocity_calculation_0
  if { [catch {set velocity_calculation_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $velocity_calculation_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create port connections
  connect_bd_net -net angle_0_1 [get_bd_ports angle_0] [get_bd_pins initial_math_0/angle]
  connect_bd_net -net clock_0_1 [get_bd_ports sys_clk] [get_bd_pins initial_math_0/clock] [get_bd_pins k_math_0/clock] [get_bd_pins prev_value_flip_flop_0/clock] [get_bd_pins term_calculation_0/clock] [get_bd_pins velocity_calculation_0/clock]
  connect_bd_net -net initial_math_0_angle_out [get_bd_pins initial_math_0/angle_out] [get_bd_pins term_calculation_0/angle]
  connect_bd_net -net initial_math_0_derivative_out [get_bd_pins initial_math_0/derivative_out] [get_bd_pins term_calculation_0/derivative]
  connect_bd_net -net initial_math_0_error_out [get_bd_pins initial_math_0/error_out] [get_bd_pins prev_value_flip_flop_0/error_in] [get_bd_pins term_calculation_0/error]
  connect_bd_net -net initial_math_0_integral_out [get_bd_pins initial_math_0/integral_out] [get_bd_pins prev_value_flip_flop_0/integral_in] [get_bd_pins term_calculation_0/integral]
  connect_bd_net -net initial_math_0_ps_ready_out [get_bd_pins initial_math_0/ps_ready_out] [get_bd_pins term_calculation_0/ps_ready_in]
  connect_bd_net -net initial_math_0_timestamp_out [get_bd_pins initial_math_0/timestamp_out] [get_bd_pins prev_value_flip_flop_0/timestamp_in]
  connect_bd_net -net k_math_0_kd_out [get_bd_pins k_math_0/kd_out] [get_bd_pins term_calculation_0/kd]
  connect_bd_net -net k_math_0_ki_out [get_bd_pins k_math_0/ki_out] [get_bd_pins term_calculation_0/ki]
  connect_bd_net -net k_math_0_kp_out [get_bd_pins k_math_0/kp_out] [get_bd_pins term_calculation_0/kp]
  connect_bd_net -net kd_in_0_1 [get_bd_ports kd_in_0] [get_bd_pins k_math_0/kd_in]
  connect_bd_net -net ki_in_0_1 [get_bd_ports ki_in_0] [get_bd_pins k_math_0/ki_in]
  connect_bd_net -net kp_in_0_1 [get_bd_ports kp_in_0] [get_bd_pins k_math_0/kp_in]
  connect_bd_net -net new_target_angle_available_0_1 [get_bd_ports new_target_angle_available_0] [get_bd_pins initial_math_0/new_target_angle_available] [get_bd_pins prev_value_flip_flop_0/new_target_angle_available]
  connect_bd_net -net prev_value_flip_flop_0_error_out [get_bd_pins initial_math_0/error_in] [get_bd_pins prev_value_flip_flop_0/error_out]
  connect_bd_net -net prev_value_flip_flop_0_integral_out [get_bd_pins initial_math_0/integral_in] [get_bd_pins prev_value_flip_flop_0/integral_out]
  connect_bd_net -net prev_value_flip_flop_0_timestamp_out [get_bd_pins initial_math_0/timestamp_in] [get_bd_pins prev_value_flip_flop_0/timestamp_out]
  connect_bd_net -net ps_ready_in_0_1 [get_bd_ports ps_ready_0] [get_bd_pins initial_math_0/ps_ready_in]
  connect_bd_net -net target_angle_0_1 [get_bd_ports target_angle_0] [get_bd_pins initial_math_0/target_angle]
  connect_bd_net -net term_calculation_0_d_term [get_bd_ports d_term_0] [get_bd_pins term_calculation_0/d_term] [get_bd_pins velocity_calculation_0/d_term]
  connect_bd_net -net term_calculation_0_i_term [get_bd_ports i_term_0] [get_bd_pins term_calculation_0/i_term] [get_bd_pins velocity_calculation_0/i_term]
  connect_bd_net -net term_calculation_0_p_term [get_bd_ports p_term_0] [get_bd_pins term_calculation_0/p_term] [get_bd_pins velocity_calculation_0/p_term]
  connect_bd_net -net term_calculation_0_ps_ready_out [get_bd_pins term_calculation_0/ps_ready_out] [get_bd_pins velocity_calculation_0/ps_ready]
  connect_bd_net -net timestamp_new_0_1 [get_bd_ports timestamp_new_0] [get_bd_pins initial_math_0/timestamp_new]
  connect_bd_net -net velocity_calculation_0_new_velocity_available [get_bd_ports new_velocity_available_0] [get_bd_pins velocity_calculation_0/new_velocity_available]
  connect_bd_net -net velocity_calculation_0_output_velocity [get_bd_ports output_velocity_0] [get_bd_pins velocity_calculation_0/output_velocity]

  # Create address segments


  # Restore current instance
  current_bd_instance $oldCurInst

  validate_bd_design
  save_bd_design
}
# End of create_root_design()


##################################################################
# MAIN FLOW
##################################################################

create_root_design ""


