// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Nov  9 23:21:50 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Xilinx/Projects/pid_controller_v4/pid_controller_v4.gen/sources_1/bd/pid_expand_time/ip/pid_expand_time_velocity_calculation_0_0/pid_expand_time_velocity_calculation_0_0_stub.v
// Design      : pid_expand_time_velocity_calculation_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "velocity_calculation,Vivado 2021.1" *)
module pid_expand_time_velocity_calculation_0_0(clock, ps_ready, p_term, i_term, d_term, 
  output_velocity, new_velocity_available)
/* synthesis syn_black_box black_box_pad_pin="clock,ps_ready,p_term[31:0],i_term[31:0],d_term[31:0],output_velocity[31:0],new_velocity_available" */;
  input clock;
  input ps_ready;
  input [31:0]p_term;
  input [31:0]i_term;
  input [31:0]d_term;
  output [31:0]output_velocity;
  output new_velocity_available;
endmodule
