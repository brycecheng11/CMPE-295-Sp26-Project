-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Mon Nov  9 23:21:50 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Xilinx/Projects/pid_controller_v4/pid_controller_v4.gen/sources_1/bd/pid_expand_time/ip/pid_expand_time_prev_value_flip_flop_0_0/pid_expand_time_prev_value_flip_flop_0_0_stub.vhdl
-- Design      : pid_expand_time_prev_value_flip_flop_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity pid_expand_time_prev_value_flip_flop_0_0 is
  Port ( 
    clock : in STD_LOGIC;
    new_target_angle_available : in STD_LOGIC;
    error_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    timestamp_in : in STD_LOGIC_VECTOR ( 31 downto 0 );
    error_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    integral_out : out STD_LOGIC_VECTOR ( 31 downto 0 );
    timestamp_out : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end pid_expand_time_prev_value_flip_flop_0_0;

architecture stub of pid_expand_time_prev_value_flip_flop_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock,new_target_angle_available,error_in[31:0],integral_in[31:0],timestamp_in[31:0],error_out[31:0],integral_out[31:0],timestamp_out[31:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "prev_value_flip_flop,Vivado 2021.1";
begin
end;
