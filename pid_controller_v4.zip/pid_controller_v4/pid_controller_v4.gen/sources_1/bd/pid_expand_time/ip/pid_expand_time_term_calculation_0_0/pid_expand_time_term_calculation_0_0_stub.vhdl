-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Sun Nov 22 15:40:49 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Xilinx/Projects/pid_controller_v4/pid_controller_v4.gen/sources_1/bd/pid_expand_time/ip/pid_expand_time_term_calculation_0_0/pid_expand_time_term_calculation_0_0_stub.vhdl
-- Design      : pid_expand_time_term_calculation_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity pid_expand_time_term_calculation_0_0 is
  Port ( 
    clock : in STD_LOGIC;
    ps_ready_in : in STD_LOGIC;
    error : in STD_LOGIC_VECTOR ( 31 downto 0 );
    integral : in STD_LOGIC_VECTOR ( 31 downto 0 );
    derivative : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ki : in STD_LOGIC_VECTOR ( 8 downto 0 );
    kd : in STD_LOGIC_VECTOR ( 8 downto 0 );
    ps_ready_out : out STD_LOGIC;
    p_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    i_term : out STD_LOGIC_VECTOR ( 31 downto 0 );
    d_term : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end pid_expand_time_term_calculation_0_0;

architecture stub of pid_expand_time_term_calculation_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock,ps_ready_in,error[31:0],integral[31:0],derivative[31:0],kp[8:0],ki[8:0],kd[8:0],ps_ready_out,p_term[31:0],i_term[31:0],d_term[31:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "term_calculation,Vivado 2021.1";
begin
end;
