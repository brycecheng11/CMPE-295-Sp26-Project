-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
-- Date        : Mon Nov  9 23:21:48 2026
-- Host        : Dell-XPS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Xilinx/Projects/pid_controller_v4/pid_controller_v4.gen/sources_1/bd/pid_expand_time/ip/pid_expand_time_k_math_0_0/pid_expand_time_k_math_0_0_stub.vhdl
-- Design      : pid_expand_time_k_math_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity pid_expand_time_k_math_0_0 is
  Port ( 
    clock : in STD_LOGIC;
    kp_in : in STD_LOGIC_VECTOR ( 11 downto 0 );
    ki_in : in STD_LOGIC_VECTOR ( 11 downto 0 );
    kd_in : in STD_LOGIC_VECTOR ( 11 downto 0 );
    kp_out : out STD_LOGIC_VECTOR ( 8 downto 0 );
    ki_out : out STD_LOGIC_VECTOR ( 8 downto 0 );
    kd_out : out STD_LOGIC_VECTOR ( 8 downto 0 )
  );

end pid_expand_time_k_math_0_0;

architecture stub of pid_expand_time_k_math_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clock,kp_in[11:0],ki_in[11:0],kd_in[11:0],kp_out[8:0],ki_out[8:0],kd_out[8:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "k_math,Vivado 2021.1";
begin
end;
