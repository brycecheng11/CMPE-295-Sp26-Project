// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
// Date        : Mon Nov  9 23:52:42 2026
// Host        : Dell-XPS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Xilinx/Projects/pid_controller_v4/pid_controller_v4.gen/sources_1/bd/pid_expand_time/ip/pid_expand_time_initial_math_0_0/pid_expand_time_initial_math_0_0_sim_netlist.v
// Design      : pid_expand_time_initial_math_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "pid_expand_time_initial_math_0_0,initial_math,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "initial_math,Vivado 2021.1" *) 
(* NotValidForBitStream *)
module pid_expand_time_initial_math_0_0
   (clock,
    angle,
    target_angle,
    new_target_angle_available,
    ps_ready_in,
    timestamp_new,
    error_in,
    integral_in,
    timestamp_in,
    ps_ready_out,
    error_out,
    integral_out,
    derivative_out,
    timestamp_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_expand_time_clock_0, INSERT_VIP 0" *) input clock;
  input [31:0]angle;
  input [31:0]target_angle;
  input new_target_angle_available;
  input ps_ready_in;
  input [31:0]timestamp_new;
  input [31:0]error_in;
  input [31:0]integral_in;
  input [31:0]timestamp_in;
  output [31:0]ps_ready_out;
  output [31:0]error_out;
  output [31:0]integral_out;
  output [31:0]derivative_out;
  output [31:0]timestamp_out;

  wire \<const0> ;
  wire [31:0]angle;
  wire clock;
  wire [31:0]derivative_out;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire new_target_angle_available;
  wire ps_ready_in;
  wire [0:0]\^ps_ready_out ;
  wire [31:0]target_angle;
  wire [31:0]timestamp_in;
  wire [31:0]timestamp_new;
  wire [31:0]timestamp_out;

  assign ps_ready_out[31] = \<const0> ;
  assign ps_ready_out[30] = \<const0> ;
  assign ps_ready_out[29] = \<const0> ;
  assign ps_ready_out[28] = \<const0> ;
  assign ps_ready_out[27] = \<const0> ;
  assign ps_ready_out[26] = \<const0> ;
  assign ps_ready_out[25] = \<const0> ;
  assign ps_ready_out[24] = \<const0> ;
  assign ps_ready_out[23] = \<const0> ;
  assign ps_ready_out[22] = \<const0> ;
  assign ps_ready_out[21] = \<const0> ;
  assign ps_ready_out[20] = \<const0> ;
  assign ps_ready_out[19] = \<const0> ;
  assign ps_ready_out[18] = \<const0> ;
  assign ps_ready_out[17] = \<const0> ;
  assign ps_ready_out[16] = \<const0> ;
  assign ps_ready_out[15] = \<const0> ;
  assign ps_ready_out[14] = \<const0> ;
  assign ps_ready_out[13] = \<const0> ;
  assign ps_ready_out[12] = \<const0> ;
  assign ps_ready_out[11] = \<const0> ;
  assign ps_ready_out[10] = \<const0> ;
  assign ps_ready_out[9] = \<const0> ;
  assign ps_ready_out[8] = \<const0> ;
  assign ps_ready_out[7] = \<const0> ;
  assign ps_ready_out[6] = \<const0> ;
  assign ps_ready_out[5] = \<const0> ;
  assign ps_ready_out[4] = \<const0> ;
  assign ps_ready_out[3] = \<const0> ;
  assign ps_ready_out[2] = \<const0> ;
  assign ps_ready_out[1] = \<const0> ;
  assign ps_ready_out[0] = \^ps_ready_out [0];
  GND GND
       (.G(\<const0> ));
  pid_expand_time_initial_math_0_0_initial_math inst
       (.angle(angle),
        .clock(clock),
        .derivative_out(derivative_out),
        .error_in(error_in),
        .error_out(error_out),
        .integral_in(integral_in),
        .integral_out(integral_out),
        .new_target_angle_available(new_target_angle_available),
        .ps_ready_in(ps_ready_in),
        .ps_ready_out(\^ps_ready_out ),
        .target_angle(target_angle),
        .timestamp_in(timestamp_in),
        .timestamp_new(timestamp_new),
        .timestamp_out(timestamp_out));
endmodule

(* ORIG_REF_NAME = "initial_math" *) 
module pid_expand_time_initial_math_0_0_initial_math
   (error_out,
    ps_ready_out,
    integral_out,
    derivative_out,
    timestamp_out,
    timestamp_new,
    timestamp_in,
    error_in,
    angle,
    ps_ready_in,
    clock,
    target_angle,
    new_target_angle_available,
    integral_in);
  output [31:0]error_out;
  output [0:0]ps_ready_out;
  output [31:0]integral_out;
  output [31:0]derivative_out;
  output [31:0]timestamp_out;
  input [31:0]timestamp_new;
  input [31:0]timestamp_in;
  input [31:0]error_in;
  input [31:0]angle;
  input ps_ready_in;
  input clock;
  input [31:0]target_angle;
  input new_target_angle_available;
  input [31:0]integral_in;

  wire [31:0]angle;
  wire clock;
  wire clock_count_i_1_n_0;
  wire clock_count_reg_n_0;
  wire [31:0]derivative1;
  wire [31:1]derivative20_in;
  wire [31:0]derivative4__93;
  wire derivative4_carry__0_n_0;
  wire derivative4_carry__0_n_1;
  wire derivative4_carry__0_n_2;
  wire derivative4_carry__0_n_3;
  wire derivative4_carry__1_n_0;
  wire derivative4_carry__1_n_1;
  wire derivative4_carry__1_n_2;
  wire derivative4_carry__1_n_3;
  wire derivative4_carry__2_n_0;
  wire derivative4_carry__2_n_1;
  wire derivative4_carry__2_n_2;
  wire derivative4_carry__2_n_3;
  wire derivative4_carry__3_n_0;
  wire derivative4_carry__3_n_1;
  wire derivative4_carry__3_n_2;
  wire derivative4_carry__3_n_3;
  wire derivative4_carry__4_n_0;
  wire derivative4_carry__4_n_1;
  wire derivative4_carry__4_n_2;
  wire derivative4_carry__4_n_3;
  wire derivative4_carry__5_n_0;
  wire derivative4_carry__5_n_1;
  wire derivative4_carry__5_n_2;
  wire derivative4_carry__5_n_3;
  wire derivative4_carry__6_n_1;
  wire derivative4_carry__6_n_2;
  wire derivative4_carry__6_n_3;
  wire derivative4_carry_i_1__0_n_0;
  wire derivative4_carry_i_1__1_n_0;
  wire derivative4_carry_i_1__2_n_0;
  wire derivative4_carry_i_1__3_n_0;
  wire derivative4_carry_i_1__4_n_0;
  wire derivative4_carry_i_1__5_n_0;
  wire derivative4_carry_i_1__6_n_0;
  wire derivative4_carry_i_1_n_0;
  wire derivative4_carry_i_2__0_n_0;
  wire derivative4_carry_i_2__1_n_0;
  wire derivative4_carry_i_2__2_n_0;
  wire derivative4_carry_i_2__3_n_0;
  wire derivative4_carry_i_2__4_n_0;
  wire derivative4_carry_i_2__5_n_0;
  wire derivative4_carry_i_2__6_n_0;
  wire derivative4_carry_i_2_n_0;
  wire derivative4_carry_i_3__0_n_0;
  wire derivative4_carry_i_3__1_n_0;
  wire derivative4_carry_i_3__2_n_0;
  wire derivative4_carry_i_3__3_n_0;
  wire derivative4_carry_i_3__4_n_0;
  wire derivative4_carry_i_3__5_n_0;
  wire derivative4_carry_i_3__6_n_0;
  wire derivative4_carry_i_3_n_0;
  wire derivative4_carry_i_4__0_n_0;
  wire derivative4_carry_i_4__1_n_0;
  wire derivative4_carry_i_4__2_n_0;
  wire derivative4_carry_i_4__3_n_0;
  wire derivative4_carry_i_4__4_n_0;
  wire derivative4_carry_i_4__5_n_0;
  wire derivative4_carry_i_4__6_n_0;
  wire derivative4_carry_i_4_n_0;
  wire derivative4_carry_n_0;
  wire derivative4_carry_n_1;
  wire derivative4_carry_n_2;
  wire derivative4_carry_n_3;
  wire \derivative[11]_i_100_n_0 ;
  wire \derivative[11]_i_101_n_0 ;
  wire \derivative[11]_i_103_n_0 ;
  wire \derivative[11]_i_104_n_0 ;
  wire \derivative[11]_i_105_n_0 ;
  wire \derivative[11]_i_106_n_0 ;
  wire \derivative[11]_i_108_n_0 ;
  wire \derivative[11]_i_109_n_0 ;
  wire \derivative[11]_i_110_n_0 ;
  wire \derivative[11]_i_111_n_0 ;
  wire \derivative[11]_i_113_n_0 ;
  wire \derivative[11]_i_114_n_0 ;
  wire \derivative[11]_i_115_n_0 ;
  wire \derivative[11]_i_116_n_0 ;
  wire \derivative[11]_i_118_n_0 ;
  wire \derivative[11]_i_119_n_0 ;
  wire \derivative[11]_i_11_n_0 ;
  wire \derivative[11]_i_120_n_0 ;
  wire \derivative[11]_i_121_n_0 ;
  wire \derivative[11]_i_123_n_0 ;
  wire \derivative[11]_i_124_n_0 ;
  wire \derivative[11]_i_125_n_0 ;
  wire \derivative[11]_i_126_n_0 ;
  wire \derivative[11]_i_128_n_0 ;
  wire \derivative[11]_i_129_n_0 ;
  wire \derivative[11]_i_12_n_0 ;
  wire \derivative[11]_i_130_n_0 ;
  wire \derivative[11]_i_131_n_0 ;
  wire \derivative[11]_i_133_n_0 ;
  wire \derivative[11]_i_134_n_0 ;
  wire \derivative[11]_i_135_n_0 ;
  wire \derivative[11]_i_136_n_0 ;
  wire \derivative[11]_i_138_n_0 ;
  wire \derivative[11]_i_139_n_0 ;
  wire \derivative[11]_i_140_n_0 ;
  wire \derivative[11]_i_141_n_0 ;
  wire \derivative[11]_i_143_n_0 ;
  wire \derivative[11]_i_144_n_0 ;
  wire \derivative[11]_i_145_n_0 ;
  wire \derivative[11]_i_146_n_0 ;
  wire \derivative[11]_i_148_n_0 ;
  wire \derivative[11]_i_149_n_0 ;
  wire \derivative[11]_i_14_n_0 ;
  wire \derivative[11]_i_150_n_0 ;
  wire \derivative[11]_i_151_n_0 ;
  wire \derivative[11]_i_153_n_0 ;
  wire \derivative[11]_i_154_n_0 ;
  wire \derivative[11]_i_155_n_0 ;
  wire \derivative[11]_i_156_n_0 ;
  wire \derivative[11]_i_158_n_0 ;
  wire \derivative[11]_i_159_n_0 ;
  wire \derivative[11]_i_15_n_0 ;
  wire \derivative[11]_i_160_n_0 ;
  wire \derivative[11]_i_161_n_0 ;
  wire \derivative[11]_i_163_n_0 ;
  wire \derivative[11]_i_164_n_0 ;
  wire \derivative[11]_i_165_n_0 ;
  wire \derivative[11]_i_167_n_0 ;
  wire \derivative[11]_i_168_n_0 ;
  wire \derivative[11]_i_169_n_0 ;
  wire \derivative[11]_i_171_n_0 ;
  wire \derivative[11]_i_172_n_0 ;
  wire \derivative[11]_i_173_n_0 ;
  wire \derivative[11]_i_175_n_0 ;
  wire \derivative[11]_i_176_n_0 ;
  wire \derivative[11]_i_177_n_0 ;
  wire \derivative[11]_i_179_n_0 ;
  wire \derivative[11]_i_17_n_0 ;
  wire \derivative[11]_i_180_n_0 ;
  wire \derivative[11]_i_181_n_0 ;
  wire \derivative[11]_i_182_n_0 ;
  wire \derivative[11]_i_18_n_0 ;
  wire \derivative[11]_i_20_n_0 ;
  wire \derivative[11]_i_21_n_0 ;
  wire \derivative[11]_i_23_n_0 ;
  wire \derivative[11]_i_24_n_0 ;
  wire \derivative[11]_i_25_n_0 ;
  wire \derivative[11]_i_26_n_0 ;
  wire \derivative[11]_i_28_n_0 ;
  wire \derivative[11]_i_29_n_0 ;
  wire \derivative[11]_i_2_n_0 ;
  wire \derivative[11]_i_30_n_0 ;
  wire \derivative[11]_i_31_n_0 ;
  wire \derivative[11]_i_33_n_0 ;
  wire \derivative[11]_i_34_n_0 ;
  wire \derivative[11]_i_35_n_0 ;
  wire \derivative[11]_i_36_n_0 ;
  wire \derivative[11]_i_38_n_0 ;
  wire \derivative[11]_i_39_n_0 ;
  wire \derivative[11]_i_3_n_0 ;
  wire \derivative[11]_i_40_n_0 ;
  wire \derivative[11]_i_41_n_0 ;
  wire \derivative[11]_i_43_n_0 ;
  wire \derivative[11]_i_44_n_0 ;
  wire \derivative[11]_i_45_n_0 ;
  wire \derivative[11]_i_46_n_0 ;
  wire \derivative[11]_i_48_n_0 ;
  wire \derivative[11]_i_49_n_0 ;
  wire \derivative[11]_i_4_n_0 ;
  wire \derivative[11]_i_50_n_0 ;
  wire \derivative[11]_i_51_n_0 ;
  wire \derivative[11]_i_53_n_0 ;
  wire \derivative[11]_i_54_n_0 ;
  wire \derivative[11]_i_55_n_0 ;
  wire \derivative[11]_i_56_n_0 ;
  wire \derivative[11]_i_58_n_0 ;
  wire \derivative[11]_i_59_n_0 ;
  wire \derivative[11]_i_5_n_0 ;
  wire \derivative[11]_i_60_n_0 ;
  wire \derivative[11]_i_61_n_0 ;
  wire \derivative[11]_i_63_n_0 ;
  wire \derivative[11]_i_64_n_0 ;
  wire \derivative[11]_i_65_n_0 ;
  wire \derivative[11]_i_66_n_0 ;
  wire \derivative[11]_i_68_n_0 ;
  wire \derivative[11]_i_69_n_0 ;
  wire \derivative[11]_i_70_n_0 ;
  wire \derivative[11]_i_71_n_0 ;
  wire \derivative[11]_i_73_n_0 ;
  wire \derivative[11]_i_74_n_0 ;
  wire \derivative[11]_i_75_n_0 ;
  wire \derivative[11]_i_76_n_0 ;
  wire \derivative[11]_i_78_n_0 ;
  wire \derivative[11]_i_79_n_0 ;
  wire \derivative[11]_i_80_n_0 ;
  wire \derivative[11]_i_81_n_0 ;
  wire \derivative[11]_i_83_n_0 ;
  wire \derivative[11]_i_84_n_0 ;
  wire \derivative[11]_i_85_n_0 ;
  wire \derivative[11]_i_86_n_0 ;
  wire \derivative[11]_i_88_n_0 ;
  wire \derivative[11]_i_89_n_0 ;
  wire \derivative[11]_i_90_n_0 ;
  wire \derivative[11]_i_91_n_0 ;
  wire \derivative[11]_i_93_n_0 ;
  wire \derivative[11]_i_94_n_0 ;
  wire \derivative[11]_i_95_n_0 ;
  wire \derivative[11]_i_96_n_0 ;
  wire \derivative[11]_i_98_n_0 ;
  wire \derivative[11]_i_99_n_0 ;
  wire \derivative[15]_i_100_n_0 ;
  wire \derivative[15]_i_101_n_0 ;
  wire \derivative[15]_i_103_n_0 ;
  wire \derivative[15]_i_104_n_0 ;
  wire \derivative[15]_i_105_n_0 ;
  wire \derivative[15]_i_106_n_0 ;
  wire \derivative[15]_i_108_n_0 ;
  wire \derivative[15]_i_109_n_0 ;
  wire \derivative[15]_i_110_n_0 ;
  wire \derivative[15]_i_111_n_0 ;
  wire \derivative[15]_i_113_n_0 ;
  wire \derivative[15]_i_114_n_0 ;
  wire \derivative[15]_i_115_n_0 ;
  wire \derivative[15]_i_116_n_0 ;
  wire \derivative[15]_i_118_n_0 ;
  wire \derivative[15]_i_119_n_0 ;
  wire \derivative[15]_i_11_n_0 ;
  wire \derivative[15]_i_120_n_0 ;
  wire \derivative[15]_i_121_n_0 ;
  wire \derivative[15]_i_123_n_0 ;
  wire \derivative[15]_i_124_n_0 ;
  wire \derivative[15]_i_125_n_0 ;
  wire \derivative[15]_i_126_n_0 ;
  wire \derivative[15]_i_128_n_0 ;
  wire \derivative[15]_i_129_n_0 ;
  wire \derivative[15]_i_12_n_0 ;
  wire \derivative[15]_i_130_n_0 ;
  wire \derivative[15]_i_131_n_0 ;
  wire \derivative[15]_i_133_n_0 ;
  wire \derivative[15]_i_134_n_0 ;
  wire \derivative[15]_i_135_n_0 ;
  wire \derivative[15]_i_136_n_0 ;
  wire \derivative[15]_i_138_n_0 ;
  wire \derivative[15]_i_139_n_0 ;
  wire \derivative[15]_i_140_n_0 ;
  wire \derivative[15]_i_141_n_0 ;
  wire \derivative[15]_i_143_n_0 ;
  wire \derivative[15]_i_144_n_0 ;
  wire \derivative[15]_i_145_n_0 ;
  wire \derivative[15]_i_146_n_0 ;
  wire \derivative[15]_i_148_n_0 ;
  wire \derivative[15]_i_149_n_0 ;
  wire \derivative[15]_i_14_n_0 ;
  wire \derivative[15]_i_150_n_0 ;
  wire \derivative[15]_i_151_n_0 ;
  wire \derivative[15]_i_153_n_0 ;
  wire \derivative[15]_i_154_n_0 ;
  wire \derivative[15]_i_155_n_0 ;
  wire \derivative[15]_i_156_n_0 ;
  wire \derivative[15]_i_158_n_0 ;
  wire \derivative[15]_i_159_n_0 ;
  wire \derivative[15]_i_15_n_0 ;
  wire \derivative[15]_i_160_n_0 ;
  wire \derivative[15]_i_161_n_0 ;
  wire \derivative[15]_i_163_n_0 ;
  wire \derivative[15]_i_164_n_0 ;
  wire \derivative[15]_i_165_n_0 ;
  wire \derivative[15]_i_167_n_0 ;
  wire \derivative[15]_i_168_n_0 ;
  wire \derivative[15]_i_169_n_0 ;
  wire \derivative[15]_i_171_n_0 ;
  wire \derivative[15]_i_172_n_0 ;
  wire \derivative[15]_i_173_n_0 ;
  wire \derivative[15]_i_175_n_0 ;
  wire \derivative[15]_i_176_n_0 ;
  wire \derivative[15]_i_177_n_0 ;
  wire \derivative[15]_i_179_n_0 ;
  wire \derivative[15]_i_17_n_0 ;
  wire \derivative[15]_i_180_n_0 ;
  wire \derivative[15]_i_181_n_0 ;
  wire \derivative[15]_i_182_n_0 ;
  wire \derivative[15]_i_18_n_0 ;
  wire \derivative[15]_i_20_n_0 ;
  wire \derivative[15]_i_21_n_0 ;
  wire \derivative[15]_i_23_n_0 ;
  wire \derivative[15]_i_24_n_0 ;
  wire \derivative[15]_i_25_n_0 ;
  wire \derivative[15]_i_26_n_0 ;
  wire \derivative[15]_i_28_n_0 ;
  wire \derivative[15]_i_29_n_0 ;
  wire \derivative[15]_i_2_n_0 ;
  wire \derivative[15]_i_30_n_0 ;
  wire \derivative[15]_i_31_n_0 ;
  wire \derivative[15]_i_33_n_0 ;
  wire \derivative[15]_i_34_n_0 ;
  wire \derivative[15]_i_35_n_0 ;
  wire \derivative[15]_i_36_n_0 ;
  wire \derivative[15]_i_38_n_0 ;
  wire \derivative[15]_i_39_n_0 ;
  wire \derivative[15]_i_3_n_0 ;
  wire \derivative[15]_i_40_n_0 ;
  wire \derivative[15]_i_41_n_0 ;
  wire \derivative[15]_i_43_n_0 ;
  wire \derivative[15]_i_44_n_0 ;
  wire \derivative[15]_i_45_n_0 ;
  wire \derivative[15]_i_46_n_0 ;
  wire \derivative[15]_i_48_n_0 ;
  wire \derivative[15]_i_49_n_0 ;
  wire \derivative[15]_i_4_n_0 ;
  wire \derivative[15]_i_50_n_0 ;
  wire \derivative[15]_i_51_n_0 ;
  wire \derivative[15]_i_53_n_0 ;
  wire \derivative[15]_i_54_n_0 ;
  wire \derivative[15]_i_55_n_0 ;
  wire \derivative[15]_i_56_n_0 ;
  wire \derivative[15]_i_58_n_0 ;
  wire \derivative[15]_i_59_n_0 ;
  wire \derivative[15]_i_5_n_0 ;
  wire \derivative[15]_i_60_n_0 ;
  wire \derivative[15]_i_61_n_0 ;
  wire \derivative[15]_i_63_n_0 ;
  wire \derivative[15]_i_64_n_0 ;
  wire \derivative[15]_i_65_n_0 ;
  wire \derivative[15]_i_66_n_0 ;
  wire \derivative[15]_i_68_n_0 ;
  wire \derivative[15]_i_69_n_0 ;
  wire \derivative[15]_i_70_n_0 ;
  wire \derivative[15]_i_71_n_0 ;
  wire \derivative[15]_i_73_n_0 ;
  wire \derivative[15]_i_74_n_0 ;
  wire \derivative[15]_i_75_n_0 ;
  wire \derivative[15]_i_76_n_0 ;
  wire \derivative[15]_i_78_n_0 ;
  wire \derivative[15]_i_79_n_0 ;
  wire \derivative[15]_i_80_n_0 ;
  wire \derivative[15]_i_81_n_0 ;
  wire \derivative[15]_i_83_n_0 ;
  wire \derivative[15]_i_84_n_0 ;
  wire \derivative[15]_i_85_n_0 ;
  wire \derivative[15]_i_86_n_0 ;
  wire \derivative[15]_i_88_n_0 ;
  wire \derivative[15]_i_89_n_0 ;
  wire \derivative[15]_i_90_n_0 ;
  wire \derivative[15]_i_91_n_0 ;
  wire \derivative[15]_i_93_n_0 ;
  wire \derivative[15]_i_94_n_0 ;
  wire \derivative[15]_i_95_n_0 ;
  wire \derivative[15]_i_96_n_0 ;
  wire \derivative[15]_i_98_n_0 ;
  wire \derivative[15]_i_99_n_0 ;
  wire \derivative[19]_i_100_n_0 ;
  wire \derivative[19]_i_101_n_0 ;
  wire \derivative[19]_i_103_n_0 ;
  wire \derivative[19]_i_104_n_0 ;
  wire \derivative[19]_i_105_n_0 ;
  wire \derivative[19]_i_106_n_0 ;
  wire \derivative[19]_i_108_n_0 ;
  wire \derivative[19]_i_109_n_0 ;
  wire \derivative[19]_i_110_n_0 ;
  wire \derivative[19]_i_111_n_0 ;
  wire \derivative[19]_i_113_n_0 ;
  wire \derivative[19]_i_114_n_0 ;
  wire \derivative[19]_i_115_n_0 ;
  wire \derivative[19]_i_116_n_0 ;
  wire \derivative[19]_i_118_n_0 ;
  wire \derivative[19]_i_119_n_0 ;
  wire \derivative[19]_i_11_n_0 ;
  wire \derivative[19]_i_120_n_0 ;
  wire \derivative[19]_i_121_n_0 ;
  wire \derivative[19]_i_123_n_0 ;
  wire \derivative[19]_i_124_n_0 ;
  wire \derivative[19]_i_125_n_0 ;
  wire \derivative[19]_i_126_n_0 ;
  wire \derivative[19]_i_128_n_0 ;
  wire \derivative[19]_i_129_n_0 ;
  wire \derivative[19]_i_12_n_0 ;
  wire \derivative[19]_i_130_n_0 ;
  wire \derivative[19]_i_131_n_0 ;
  wire \derivative[19]_i_133_n_0 ;
  wire \derivative[19]_i_134_n_0 ;
  wire \derivative[19]_i_135_n_0 ;
  wire \derivative[19]_i_136_n_0 ;
  wire \derivative[19]_i_138_n_0 ;
  wire \derivative[19]_i_139_n_0 ;
  wire \derivative[19]_i_140_n_0 ;
  wire \derivative[19]_i_141_n_0 ;
  wire \derivative[19]_i_143_n_0 ;
  wire \derivative[19]_i_144_n_0 ;
  wire \derivative[19]_i_145_n_0 ;
  wire \derivative[19]_i_146_n_0 ;
  wire \derivative[19]_i_148_n_0 ;
  wire \derivative[19]_i_149_n_0 ;
  wire \derivative[19]_i_14_n_0 ;
  wire \derivative[19]_i_150_n_0 ;
  wire \derivative[19]_i_151_n_0 ;
  wire \derivative[19]_i_153_n_0 ;
  wire \derivative[19]_i_154_n_0 ;
  wire \derivative[19]_i_155_n_0 ;
  wire \derivative[19]_i_156_n_0 ;
  wire \derivative[19]_i_158_n_0 ;
  wire \derivative[19]_i_159_n_0 ;
  wire \derivative[19]_i_15_n_0 ;
  wire \derivative[19]_i_160_n_0 ;
  wire \derivative[19]_i_161_n_0 ;
  wire \derivative[19]_i_163_n_0 ;
  wire \derivative[19]_i_164_n_0 ;
  wire \derivative[19]_i_165_n_0 ;
  wire \derivative[19]_i_167_n_0 ;
  wire \derivative[19]_i_168_n_0 ;
  wire \derivative[19]_i_169_n_0 ;
  wire \derivative[19]_i_171_n_0 ;
  wire \derivative[19]_i_172_n_0 ;
  wire \derivative[19]_i_173_n_0 ;
  wire \derivative[19]_i_175_n_0 ;
  wire \derivative[19]_i_176_n_0 ;
  wire \derivative[19]_i_177_n_0 ;
  wire \derivative[19]_i_179_n_0 ;
  wire \derivative[19]_i_17_n_0 ;
  wire \derivative[19]_i_180_n_0 ;
  wire \derivative[19]_i_181_n_0 ;
  wire \derivative[19]_i_182_n_0 ;
  wire \derivative[19]_i_18_n_0 ;
  wire \derivative[19]_i_20_n_0 ;
  wire \derivative[19]_i_21_n_0 ;
  wire \derivative[19]_i_23_n_0 ;
  wire \derivative[19]_i_24_n_0 ;
  wire \derivative[19]_i_25_n_0 ;
  wire \derivative[19]_i_26_n_0 ;
  wire \derivative[19]_i_28_n_0 ;
  wire \derivative[19]_i_29_n_0 ;
  wire \derivative[19]_i_2_n_0 ;
  wire \derivative[19]_i_30_n_0 ;
  wire \derivative[19]_i_31_n_0 ;
  wire \derivative[19]_i_33_n_0 ;
  wire \derivative[19]_i_34_n_0 ;
  wire \derivative[19]_i_35_n_0 ;
  wire \derivative[19]_i_36_n_0 ;
  wire \derivative[19]_i_38_n_0 ;
  wire \derivative[19]_i_39_n_0 ;
  wire \derivative[19]_i_3_n_0 ;
  wire \derivative[19]_i_40_n_0 ;
  wire \derivative[19]_i_41_n_0 ;
  wire \derivative[19]_i_43_n_0 ;
  wire \derivative[19]_i_44_n_0 ;
  wire \derivative[19]_i_45_n_0 ;
  wire \derivative[19]_i_46_n_0 ;
  wire \derivative[19]_i_48_n_0 ;
  wire \derivative[19]_i_49_n_0 ;
  wire \derivative[19]_i_4_n_0 ;
  wire \derivative[19]_i_50_n_0 ;
  wire \derivative[19]_i_51_n_0 ;
  wire \derivative[19]_i_53_n_0 ;
  wire \derivative[19]_i_54_n_0 ;
  wire \derivative[19]_i_55_n_0 ;
  wire \derivative[19]_i_56_n_0 ;
  wire \derivative[19]_i_58_n_0 ;
  wire \derivative[19]_i_59_n_0 ;
  wire \derivative[19]_i_5_n_0 ;
  wire \derivative[19]_i_60_n_0 ;
  wire \derivative[19]_i_61_n_0 ;
  wire \derivative[19]_i_63_n_0 ;
  wire \derivative[19]_i_64_n_0 ;
  wire \derivative[19]_i_65_n_0 ;
  wire \derivative[19]_i_66_n_0 ;
  wire \derivative[19]_i_68_n_0 ;
  wire \derivative[19]_i_69_n_0 ;
  wire \derivative[19]_i_70_n_0 ;
  wire \derivative[19]_i_71_n_0 ;
  wire \derivative[19]_i_73_n_0 ;
  wire \derivative[19]_i_74_n_0 ;
  wire \derivative[19]_i_75_n_0 ;
  wire \derivative[19]_i_76_n_0 ;
  wire \derivative[19]_i_78_n_0 ;
  wire \derivative[19]_i_79_n_0 ;
  wire \derivative[19]_i_80_n_0 ;
  wire \derivative[19]_i_81_n_0 ;
  wire \derivative[19]_i_83_n_0 ;
  wire \derivative[19]_i_84_n_0 ;
  wire \derivative[19]_i_85_n_0 ;
  wire \derivative[19]_i_86_n_0 ;
  wire \derivative[19]_i_88_n_0 ;
  wire \derivative[19]_i_89_n_0 ;
  wire \derivative[19]_i_90_n_0 ;
  wire \derivative[19]_i_91_n_0 ;
  wire \derivative[19]_i_93_n_0 ;
  wire \derivative[19]_i_94_n_0 ;
  wire \derivative[19]_i_95_n_0 ;
  wire \derivative[19]_i_96_n_0 ;
  wire \derivative[19]_i_98_n_0 ;
  wire \derivative[19]_i_99_n_0 ;
  wire \derivative[23]_i_100_n_0 ;
  wire \derivative[23]_i_101_n_0 ;
  wire \derivative[23]_i_103_n_0 ;
  wire \derivative[23]_i_104_n_0 ;
  wire \derivative[23]_i_105_n_0 ;
  wire \derivative[23]_i_106_n_0 ;
  wire \derivative[23]_i_108_n_0 ;
  wire \derivative[23]_i_109_n_0 ;
  wire \derivative[23]_i_110_n_0 ;
  wire \derivative[23]_i_111_n_0 ;
  wire \derivative[23]_i_113_n_0 ;
  wire \derivative[23]_i_114_n_0 ;
  wire \derivative[23]_i_115_n_0 ;
  wire \derivative[23]_i_116_n_0 ;
  wire \derivative[23]_i_118_n_0 ;
  wire \derivative[23]_i_119_n_0 ;
  wire \derivative[23]_i_11_n_0 ;
  wire \derivative[23]_i_120_n_0 ;
  wire \derivative[23]_i_121_n_0 ;
  wire \derivative[23]_i_123_n_0 ;
  wire \derivative[23]_i_124_n_0 ;
  wire \derivative[23]_i_125_n_0 ;
  wire \derivative[23]_i_126_n_0 ;
  wire \derivative[23]_i_128_n_0 ;
  wire \derivative[23]_i_129_n_0 ;
  wire \derivative[23]_i_12_n_0 ;
  wire \derivative[23]_i_130_n_0 ;
  wire \derivative[23]_i_131_n_0 ;
  wire \derivative[23]_i_133_n_0 ;
  wire \derivative[23]_i_134_n_0 ;
  wire \derivative[23]_i_135_n_0 ;
  wire \derivative[23]_i_136_n_0 ;
  wire \derivative[23]_i_138_n_0 ;
  wire \derivative[23]_i_139_n_0 ;
  wire \derivative[23]_i_140_n_0 ;
  wire \derivative[23]_i_141_n_0 ;
  wire \derivative[23]_i_143_n_0 ;
  wire \derivative[23]_i_144_n_0 ;
  wire \derivative[23]_i_145_n_0 ;
  wire \derivative[23]_i_146_n_0 ;
  wire \derivative[23]_i_148_n_0 ;
  wire \derivative[23]_i_149_n_0 ;
  wire \derivative[23]_i_14_n_0 ;
  wire \derivative[23]_i_150_n_0 ;
  wire \derivative[23]_i_151_n_0 ;
  wire \derivative[23]_i_153_n_0 ;
  wire \derivative[23]_i_154_n_0 ;
  wire \derivative[23]_i_155_n_0 ;
  wire \derivative[23]_i_156_n_0 ;
  wire \derivative[23]_i_158_n_0 ;
  wire \derivative[23]_i_159_n_0 ;
  wire \derivative[23]_i_15_n_0 ;
  wire \derivative[23]_i_160_n_0 ;
  wire \derivative[23]_i_161_n_0 ;
  wire \derivative[23]_i_163_n_0 ;
  wire \derivative[23]_i_164_n_0 ;
  wire \derivative[23]_i_165_n_0 ;
  wire \derivative[23]_i_167_n_0 ;
  wire \derivative[23]_i_168_n_0 ;
  wire \derivative[23]_i_169_n_0 ;
  wire \derivative[23]_i_171_n_0 ;
  wire \derivative[23]_i_172_n_0 ;
  wire \derivative[23]_i_173_n_0 ;
  wire \derivative[23]_i_175_n_0 ;
  wire \derivative[23]_i_176_n_0 ;
  wire \derivative[23]_i_177_n_0 ;
  wire \derivative[23]_i_179_n_0 ;
  wire \derivative[23]_i_17_n_0 ;
  wire \derivative[23]_i_180_n_0 ;
  wire \derivative[23]_i_181_n_0 ;
  wire \derivative[23]_i_182_n_0 ;
  wire \derivative[23]_i_18_n_0 ;
  wire \derivative[23]_i_20_n_0 ;
  wire \derivative[23]_i_21_n_0 ;
  wire \derivative[23]_i_23_n_0 ;
  wire \derivative[23]_i_24_n_0 ;
  wire \derivative[23]_i_25_n_0 ;
  wire \derivative[23]_i_26_n_0 ;
  wire \derivative[23]_i_28_n_0 ;
  wire \derivative[23]_i_29_n_0 ;
  wire \derivative[23]_i_2_n_0 ;
  wire \derivative[23]_i_30_n_0 ;
  wire \derivative[23]_i_31_n_0 ;
  wire \derivative[23]_i_33_n_0 ;
  wire \derivative[23]_i_34_n_0 ;
  wire \derivative[23]_i_35_n_0 ;
  wire \derivative[23]_i_36_n_0 ;
  wire \derivative[23]_i_38_n_0 ;
  wire \derivative[23]_i_39_n_0 ;
  wire \derivative[23]_i_3_n_0 ;
  wire \derivative[23]_i_40_n_0 ;
  wire \derivative[23]_i_41_n_0 ;
  wire \derivative[23]_i_43_n_0 ;
  wire \derivative[23]_i_44_n_0 ;
  wire \derivative[23]_i_45_n_0 ;
  wire \derivative[23]_i_46_n_0 ;
  wire \derivative[23]_i_48_n_0 ;
  wire \derivative[23]_i_49_n_0 ;
  wire \derivative[23]_i_4_n_0 ;
  wire \derivative[23]_i_50_n_0 ;
  wire \derivative[23]_i_51_n_0 ;
  wire \derivative[23]_i_53_n_0 ;
  wire \derivative[23]_i_54_n_0 ;
  wire \derivative[23]_i_55_n_0 ;
  wire \derivative[23]_i_56_n_0 ;
  wire \derivative[23]_i_58_n_0 ;
  wire \derivative[23]_i_59_n_0 ;
  wire \derivative[23]_i_5_n_0 ;
  wire \derivative[23]_i_60_n_0 ;
  wire \derivative[23]_i_61_n_0 ;
  wire \derivative[23]_i_63_n_0 ;
  wire \derivative[23]_i_64_n_0 ;
  wire \derivative[23]_i_65_n_0 ;
  wire \derivative[23]_i_66_n_0 ;
  wire \derivative[23]_i_68_n_0 ;
  wire \derivative[23]_i_69_n_0 ;
  wire \derivative[23]_i_70_n_0 ;
  wire \derivative[23]_i_71_n_0 ;
  wire \derivative[23]_i_73_n_0 ;
  wire \derivative[23]_i_74_n_0 ;
  wire \derivative[23]_i_75_n_0 ;
  wire \derivative[23]_i_76_n_0 ;
  wire \derivative[23]_i_78_n_0 ;
  wire \derivative[23]_i_79_n_0 ;
  wire \derivative[23]_i_80_n_0 ;
  wire \derivative[23]_i_81_n_0 ;
  wire \derivative[23]_i_83_n_0 ;
  wire \derivative[23]_i_84_n_0 ;
  wire \derivative[23]_i_85_n_0 ;
  wire \derivative[23]_i_86_n_0 ;
  wire \derivative[23]_i_88_n_0 ;
  wire \derivative[23]_i_89_n_0 ;
  wire \derivative[23]_i_90_n_0 ;
  wire \derivative[23]_i_91_n_0 ;
  wire \derivative[23]_i_93_n_0 ;
  wire \derivative[23]_i_94_n_0 ;
  wire \derivative[23]_i_95_n_0 ;
  wire \derivative[23]_i_96_n_0 ;
  wire \derivative[23]_i_98_n_0 ;
  wire \derivative[23]_i_99_n_0 ;
  wire \derivative[27]_i_100_n_0 ;
  wire \derivative[27]_i_101_n_0 ;
  wire \derivative[27]_i_103_n_0 ;
  wire \derivative[27]_i_104_n_0 ;
  wire \derivative[27]_i_105_n_0 ;
  wire \derivative[27]_i_106_n_0 ;
  wire \derivative[27]_i_108_n_0 ;
  wire \derivative[27]_i_109_n_0 ;
  wire \derivative[27]_i_110_n_0 ;
  wire \derivative[27]_i_111_n_0 ;
  wire \derivative[27]_i_113_n_0 ;
  wire \derivative[27]_i_114_n_0 ;
  wire \derivative[27]_i_115_n_0 ;
  wire \derivative[27]_i_116_n_0 ;
  wire \derivative[27]_i_118_n_0 ;
  wire \derivative[27]_i_119_n_0 ;
  wire \derivative[27]_i_11_n_0 ;
  wire \derivative[27]_i_120_n_0 ;
  wire \derivative[27]_i_121_n_0 ;
  wire \derivative[27]_i_123_n_0 ;
  wire \derivative[27]_i_124_n_0 ;
  wire \derivative[27]_i_125_n_0 ;
  wire \derivative[27]_i_126_n_0 ;
  wire \derivative[27]_i_128_n_0 ;
  wire \derivative[27]_i_129_n_0 ;
  wire \derivative[27]_i_12_n_0 ;
  wire \derivative[27]_i_130_n_0 ;
  wire \derivative[27]_i_131_n_0 ;
  wire \derivative[27]_i_133_n_0 ;
  wire \derivative[27]_i_134_n_0 ;
  wire \derivative[27]_i_135_n_0 ;
  wire \derivative[27]_i_136_n_0 ;
  wire \derivative[27]_i_138_n_0 ;
  wire \derivative[27]_i_139_n_0 ;
  wire \derivative[27]_i_140_n_0 ;
  wire \derivative[27]_i_141_n_0 ;
  wire \derivative[27]_i_143_n_0 ;
  wire \derivative[27]_i_144_n_0 ;
  wire \derivative[27]_i_145_n_0 ;
  wire \derivative[27]_i_146_n_0 ;
  wire \derivative[27]_i_148_n_0 ;
  wire \derivative[27]_i_149_n_0 ;
  wire \derivative[27]_i_14_n_0 ;
  wire \derivative[27]_i_150_n_0 ;
  wire \derivative[27]_i_151_n_0 ;
  wire \derivative[27]_i_153_n_0 ;
  wire \derivative[27]_i_154_n_0 ;
  wire \derivative[27]_i_155_n_0 ;
  wire \derivative[27]_i_156_n_0 ;
  wire \derivative[27]_i_158_n_0 ;
  wire \derivative[27]_i_159_n_0 ;
  wire \derivative[27]_i_15_n_0 ;
  wire \derivative[27]_i_160_n_0 ;
  wire \derivative[27]_i_161_n_0 ;
  wire \derivative[27]_i_163_n_0 ;
  wire \derivative[27]_i_164_n_0 ;
  wire \derivative[27]_i_165_n_0 ;
  wire \derivative[27]_i_167_n_0 ;
  wire \derivative[27]_i_168_n_0 ;
  wire \derivative[27]_i_169_n_0 ;
  wire \derivative[27]_i_171_n_0 ;
  wire \derivative[27]_i_172_n_0 ;
  wire \derivative[27]_i_173_n_0 ;
  wire \derivative[27]_i_175_n_0 ;
  wire \derivative[27]_i_176_n_0 ;
  wire \derivative[27]_i_177_n_0 ;
  wire \derivative[27]_i_179_n_0 ;
  wire \derivative[27]_i_17_n_0 ;
  wire \derivative[27]_i_180_n_0 ;
  wire \derivative[27]_i_181_n_0 ;
  wire \derivative[27]_i_182_n_0 ;
  wire \derivative[27]_i_18_n_0 ;
  wire \derivative[27]_i_20_n_0 ;
  wire \derivative[27]_i_21_n_0 ;
  wire \derivative[27]_i_23_n_0 ;
  wire \derivative[27]_i_24_n_0 ;
  wire \derivative[27]_i_25_n_0 ;
  wire \derivative[27]_i_26_n_0 ;
  wire \derivative[27]_i_28_n_0 ;
  wire \derivative[27]_i_29_n_0 ;
  wire \derivative[27]_i_2_n_0 ;
  wire \derivative[27]_i_30_n_0 ;
  wire \derivative[27]_i_31_n_0 ;
  wire \derivative[27]_i_33_n_0 ;
  wire \derivative[27]_i_34_n_0 ;
  wire \derivative[27]_i_35_n_0 ;
  wire \derivative[27]_i_36_n_0 ;
  wire \derivative[27]_i_38_n_0 ;
  wire \derivative[27]_i_39_n_0 ;
  wire \derivative[27]_i_3_n_0 ;
  wire \derivative[27]_i_40_n_0 ;
  wire \derivative[27]_i_41_n_0 ;
  wire \derivative[27]_i_43_n_0 ;
  wire \derivative[27]_i_44_n_0 ;
  wire \derivative[27]_i_45_n_0 ;
  wire \derivative[27]_i_46_n_0 ;
  wire \derivative[27]_i_48_n_0 ;
  wire \derivative[27]_i_49_n_0 ;
  wire \derivative[27]_i_4_n_0 ;
  wire \derivative[27]_i_50_n_0 ;
  wire \derivative[27]_i_51_n_0 ;
  wire \derivative[27]_i_53_n_0 ;
  wire \derivative[27]_i_54_n_0 ;
  wire \derivative[27]_i_55_n_0 ;
  wire \derivative[27]_i_56_n_0 ;
  wire \derivative[27]_i_58_n_0 ;
  wire \derivative[27]_i_59_n_0 ;
  wire \derivative[27]_i_5_n_0 ;
  wire \derivative[27]_i_60_n_0 ;
  wire \derivative[27]_i_61_n_0 ;
  wire \derivative[27]_i_63_n_0 ;
  wire \derivative[27]_i_64_n_0 ;
  wire \derivative[27]_i_65_n_0 ;
  wire \derivative[27]_i_66_n_0 ;
  wire \derivative[27]_i_68_n_0 ;
  wire \derivative[27]_i_69_n_0 ;
  wire \derivative[27]_i_70_n_0 ;
  wire \derivative[27]_i_71_n_0 ;
  wire \derivative[27]_i_73_n_0 ;
  wire \derivative[27]_i_74_n_0 ;
  wire \derivative[27]_i_75_n_0 ;
  wire \derivative[27]_i_76_n_0 ;
  wire \derivative[27]_i_78_n_0 ;
  wire \derivative[27]_i_79_n_0 ;
  wire \derivative[27]_i_80_n_0 ;
  wire \derivative[27]_i_81_n_0 ;
  wire \derivative[27]_i_83_n_0 ;
  wire \derivative[27]_i_84_n_0 ;
  wire \derivative[27]_i_85_n_0 ;
  wire \derivative[27]_i_86_n_0 ;
  wire \derivative[27]_i_88_n_0 ;
  wire \derivative[27]_i_89_n_0 ;
  wire \derivative[27]_i_90_n_0 ;
  wire \derivative[27]_i_91_n_0 ;
  wire \derivative[27]_i_93_n_0 ;
  wire \derivative[27]_i_94_n_0 ;
  wire \derivative[27]_i_95_n_0 ;
  wire \derivative[27]_i_96_n_0 ;
  wire \derivative[27]_i_98_n_0 ;
  wire \derivative[27]_i_99_n_0 ;
  wire \derivative[31]_i_100_n_0 ;
  wire \derivative[31]_i_102_n_0 ;
  wire \derivative[31]_i_103_n_0 ;
  wire \derivative[31]_i_104_n_0 ;
  wire \derivative[31]_i_105_n_0 ;
  wire \derivative[31]_i_107_n_0 ;
  wire \derivative[31]_i_108_n_0 ;
  wire \derivative[31]_i_109_n_0 ;
  wire \derivative[31]_i_10_n_0 ;
  wire \derivative[31]_i_110_n_0 ;
  wire \derivative[31]_i_111_n_0 ;
  wire \derivative[31]_i_112_n_0 ;
  wire \derivative[31]_i_113_n_0 ;
  wire \derivative[31]_i_114_n_0 ;
  wire \derivative[31]_i_116_n_0 ;
  wire \derivative[31]_i_117_n_0 ;
  wire \derivative[31]_i_118_n_0 ;
  wire \derivative[31]_i_119_n_0 ;
  wire \derivative[31]_i_11_n_0 ;
  wire \derivative[31]_i_121_n_0 ;
  wire \derivative[31]_i_122_n_0 ;
  wire \derivative[31]_i_123_n_0 ;
  wire \derivative[31]_i_124_n_0 ;
  wire \derivative[31]_i_126_n_0 ;
  wire \derivative[31]_i_127_n_0 ;
  wire \derivative[31]_i_128_n_0 ;
  wire \derivative[31]_i_129_n_0 ;
  wire \derivative[31]_i_12_n_0 ;
  wire \derivative[31]_i_130_n_0 ;
  wire \derivative[31]_i_131_n_0 ;
  wire \derivative[31]_i_132_n_0 ;
  wire \derivative[31]_i_133_n_0 ;
  wire \derivative[31]_i_135_n_0 ;
  wire \derivative[31]_i_136_n_0 ;
  wire \derivative[31]_i_137_n_0 ;
  wire \derivative[31]_i_138_n_0 ;
  wire \derivative[31]_i_13_n_0 ;
  wire \derivative[31]_i_140_n_0 ;
  wire \derivative[31]_i_141_n_0 ;
  wire \derivative[31]_i_142_n_0 ;
  wire \derivative[31]_i_143_n_0 ;
  wire \derivative[31]_i_144_n_0 ;
  wire \derivative[31]_i_145_n_0 ;
  wire \derivative[31]_i_146_n_0 ;
  wire \derivative[31]_i_147_n_0 ;
  wire \derivative[31]_i_149_n_0 ;
  wire \derivative[31]_i_14_n_0 ;
  wire \derivative[31]_i_150_n_0 ;
  wire \derivative[31]_i_151_n_0 ;
  wire \derivative[31]_i_152_n_0 ;
  wire \derivative[31]_i_154_n_0 ;
  wire \derivative[31]_i_155_n_0 ;
  wire \derivative[31]_i_156_n_0 ;
  wire \derivative[31]_i_157_n_0 ;
  wire \derivative[31]_i_159_n_0 ;
  wire \derivative[31]_i_15_n_0 ;
  wire \derivative[31]_i_160_n_0 ;
  wire \derivative[31]_i_161_n_0 ;
  wire \derivative[31]_i_162_n_0 ;
  wire \derivative[31]_i_163_n_0 ;
  wire \derivative[31]_i_164_n_0 ;
  wire \derivative[31]_i_165_n_0 ;
  wire \derivative[31]_i_166_n_0 ;
  wire \derivative[31]_i_168_n_0 ;
  wire \derivative[31]_i_169_n_0 ;
  wire \derivative[31]_i_16_n_0 ;
  wire \derivative[31]_i_170_n_0 ;
  wire \derivative[31]_i_171_n_0 ;
  wire \derivative[31]_i_173_n_0 ;
  wire \derivative[31]_i_174_n_0 ;
  wire \derivative[31]_i_175_n_0 ;
  wire \derivative[31]_i_176_n_0 ;
  wire \derivative[31]_i_177_n_0 ;
  wire \derivative[31]_i_178_n_0 ;
  wire \derivative[31]_i_179_n_0 ;
  wire \derivative[31]_i_17_n_0 ;
  wire \derivative[31]_i_180_n_0 ;
  wire \derivative[31]_i_182_n_0 ;
  wire \derivative[31]_i_183_n_0 ;
  wire \derivative[31]_i_184_n_0 ;
  wire \derivative[31]_i_185_n_0 ;
  wire \derivative[31]_i_187_n_0 ;
  wire \derivative[31]_i_188_n_0 ;
  wire \derivative[31]_i_189_n_0 ;
  wire \derivative[31]_i_18_n_0 ;
  wire \derivative[31]_i_190_n_0 ;
  wire \derivative[31]_i_192_n_0 ;
  wire \derivative[31]_i_193_n_0 ;
  wire \derivative[31]_i_194_n_0 ;
  wire \derivative[31]_i_195_n_0 ;
  wire \derivative[31]_i_196_n_0 ;
  wire \derivative[31]_i_197_n_0 ;
  wire \derivative[31]_i_198_n_0 ;
  wire \derivative[31]_i_199_n_0 ;
  wire \derivative[31]_i_19_n_0 ;
  wire \derivative[31]_i_1_n_0 ;
  wire \derivative[31]_i_201_n_0 ;
  wire \derivative[31]_i_202_n_0 ;
  wire \derivative[31]_i_203_n_0 ;
  wire \derivative[31]_i_204_n_0 ;
  wire \derivative[31]_i_206_n_0 ;
  wire \derivative[31]_i_207_n_0 ;
  wire \derivative[31]_i_208_n_0 ;
  wire \derivative[31]_i_209_n_0 ;
  wire \derivative[31]_i_20_n_0 ;
  wire \derivative[31]_i_210_n_0 ;
  wire \derivative[31]_i_211_n_0 ;
  wire \derivative[31]_i_212_n_0 ;
  wire \derivative[31]_i_213_n_0 ;
  wire \derivative[31]_i_215_n_0 ;
  wire \derivative[31]_i_216_n_0 ;
  wire \derivative[31]_i_217_n_0 ;
  wire \derivative[31]_i_218_n_0 ;
  wire \derivative[31]_i_220_n_0 ;
  wire \derivative[31]_i_221_n_0 ;
  wire \derivative[31]_i_222_n_0 ;
  wire \derivative[31]_i_223_n_0 ;
  wire \derivative[31]_i_225_n_0 ;
  wire \derivative[31]_i_226_n_0 ;
  wire \derivative[31]_i_227_n_0 ;
  wire \derivative[31]_i_228_n_0 ;
  wire \derivative[31]_i_229_n_0 ;
  wire \derivative[31]_i_230_n_0 ;
  wire \derivative[31]_i_231_n_0 ;
  wire \derivative[31]_i_232_n_0 ;
  wire \derivative[31]_i_234_n_0 ;
  wire \derivative[31]_i_235_n_0 ;
  wire \derivative[31]_i_236_n_0 ;
  wire \derivative[31]_i_237_n_0 ;
  wire \derivative[31]_i_239_n_0 ;
  wire \derivative[31]_i_240_n_0 ;
  wire \derivative[31]_i_241_n_0 ;
  wire \derivative[31]_i_242_n_0 ;
  wire \derivative[31]_i_243_n_0 ;
  wire \derivative[31]_i_244_n_0 ;
  wire \derivative[31]_i_245_n_0 ;
  wire \derivative[31]_i_246_n_0 ;
  wire \derivative[31]_i_248_n_0 ;
  wire \derivative[31]_i_249_n_0 ;
  wire \derivative[31]_i_250_n_0 ;
  wire \derivative[31]_i_251_n_0 ;
  wire \derivative[31]_i_253_n_0 ;
  wire \derivative[31]_i_254_n_0 ;
  wire \derivative[31]_i_255_n_0 ;
  wire \derivative[31]_i_256_n_0 ;
  wire \derivative[31]_i_257_n_0 ;
  wire \derivative[31]_i_258_n_0 ;
  wire \derivative[31]_i_259_n_0 ;
  wire \derivative[31]_i_261_n_0 ;
  wire \derivative[31]_i_262_n_0 ;
  wire \derivative[31]_i_263_n_0 ;
  wire \derivative[31]_i_264_n_0 ;
  wire \derivative[31]_i_266_n_0 ;
  wire \derivative[31]_i_267_n_0 ;
  wire \derivative[31]_i_268_n_0 ;
  wire \derivative[31]_i_269_n_0 ;
  wire \derivative[31]_i_271_n_0 ;
  wire \derivative[31]_i_272_n_0 ;
  wire \derivative[31]_i_273_n_0 ;
  wire \derivative[31]_i_274_n_0 ;
  wire \derivative[31]_i_275_n_0 ;
  wire \derivative[31]_i_276_n_0 ;
  wire \derivative[31]_i_277_n_0 ;
  wire \derivative[31]_i_279_n_0 ;
  wire \derivative[31]_i_27_n_0 ;
  wire \derivative[31]_i_280_n_0 ;
  wire \derivative[31]_i_281_n_0 ;
  wire \derivative[31]_i_283_n_0 ;
  wire \derivative[31]_i_284_n_0 ;
  wire \derivative[31]_i_285_n_0 ;
  wire \derivative[31]_i_287_n_0 ;
  wire \derivative[31]_i_288_n_0 ;
  wire \derivative[31]_i_289_n_0 ;
  wire \derivative[31]_i_28_n_0 ;
  wire \derivative[31]_i_290_n_0 ;
  wire \derivative[31]_i_291_n_0 ;
  wire \derivative[31]_i_292_n_0 ;
  wire \derivative[31]_i_293_n_0 ;
  wire \derivative[31]_i_295_n_0 ;
  wire \derivative[31]_i_296_n_0 ;
  wire \derivative[31]_i_297_n_0 ;
  wire \derivative[31]_i_298_n_0 ;
  wire \derivative[31]_i_299_n_0 ;
  wire \derivative[31]_i_300_n_0 ;
  wire \derivative[31]_i_301_n_0 ;
  wire \derivative[31]_i_30_n_0 ;
  wire \derivative[31]_i_31_n_0 ;
  wire \derivative[31]_i_33_n_0 ;
  wire \derivative[31]_i_34_n_0 ;
  wire \derivative[31]_i_36_n_0 ;
  wire \derivative[31]_i_37_n_0 ;
  wire \derivative[31]_i_38_n_0 ;
  wire \derivative[31]_i_39_n_0 ;
  wire \derivative[31]_i_3_n_0 ;
  wire \derivative[31]_i_40_n_0 ;
  wire \derivative[31]_i_41_n_0 ;
  wire \derivative[31]_i_42_n_0 ;
  wire \derivative[31]_i_43_n_0 ;
  wire \derivative[31]_i_45_n_0 ;
  wire \derivative[31]_i_46_n_0 ;
  wire \derivative[31]_i_47_n_0 ;
  wire \derivative[31]_i_48_n_0 ;
  wire \derivative[31]_i_4_n_0 ;
  wire \derivative[31]_i_51_n_0 ;
  wire \derivative[31]_i_52_n_0 ;
  wire \derivative[31]_i_53_n_0 ;
  wire \derivative[31]_i_54_n_0 ;
  wire \derivative[31]_i_56_n_0 ;
  wire \derivative[31]_i_57_n_0 ;
  wire \derivative[31]_i_58_n_0 ;
  wire \derivative[31]_i_59_n_0 ;
  wire \derivative[31]_i_5_n_0 ;
  wire \derivative[31]_i_61_n_0 ;
  wire \derivative[31]_i_62_n_0 ;
  wire \derivative[31]_i_63_n_0 ;
  wire \derivative[31]_i_64_n_0 ;
  wire \derivative[31]_i_65_n_0 ;
  wire \derivative[31]_i_66_n_0 ;
  wire \derivative[31]_i_67_n_0 ;
  wire \derivative[31]_i_68_n_0 ;
  wire \derivative[31]_i_6_n_0 ;
  wire \derivative[31]_i_71_n_0 ;
  wire \derivative[31]_i_72_n_0 ;
  wire \derivative[31]_i_73_n_0 ;
  wire \derivative[31]_i_74_n_0 ;
  wire \derivative[31]_i_75_n_0 ;
  wire \derivative[31]_i_76_n_0 ;
  wire \derivative[31]_i_77_n_0 ;
  wire \derivative[31]_i_78_n_0 ;
  wire \derivative[31]_i_79_n_0 ;
  wire \derivative[31]_i_7_n_0 ;
  wire \derivative[31]_i_80_n_0 ;
  wire \derivative[31]_i_81_n_0 ;
  wire \derivative[31]_i_83_n_0 ;
  wire \derivative[31]_i_84_n_0 ;
  wire \derivative[31]_i_85_n_0 ;
  wire \derivative[31]_i_86_n_0 ;
  wire \derivative[31]_i_88_n_0 ;
  wire \derivative[31]_i_89_n_0 ;
  wire \derivative[31]_i_8_n_0 ;
  wire \derivative[31]_i_90_n_0 ;
  wire \derivative[31]_i_91_n_0 ;
  wire \derivative[31]_i_93_n_0 ;
  wire \derivative[31]_i_94_n_0 ;
  wire \derivative[31]_i_95_n_0 ;
  wire \derivative[31]_i_96_n_0 ;
  wire \derivative[31]_i_97_n_0 ;
  wire \derivative[31]_i_98_n_0 ;
  wire \derivative[31]_i_99_n_0 ;
  wire \derivative[31]_i_9_n_0 ;
  wire \derivative[3]_i_100_n_0 ;
  wire \derivative[3]_i_101_n_0 ;
  wire \derivative[3]_i_103_n_0 ;
  wire \derivative[3]_i_104_n_0 ;
  wire \derivative[3]_i_105_n_0 ;
  wire \derivative[3]_i_106_n_0 ;
  wire \derivative[3]_i_108_n_0 ;
  wire \derivative[3]_i_109_n_0 ;
  wire \derivative[3]_i_110_n_0 ;
  wire \derivative[3]_i_111_n_0 ;
  wire \derivative[3]_i_113_n_0 ;
  wire \derivative[3]_i_114_n_0 ;
  wire \derivative[3]_i_115_n_0 ;
  wire \derivative[3]_i_116_n_0 ;
  wire \derivative[3]_i_118_n_0 ;
  wire \derivative[3]_i_119_n_0 ;
  wire \derivative[3]_i_120_n_0 ;
  wire \derivative[3]_i_121_n_0 ;
  wire \derivative[3]_i_123_n_0 ;
  wire \derivative[3]_i_124_n_0 ;
  wire \derivative[3]_i_125_n_0 ;
  wire \derivative[3]_i_126_n_0 ;
  wire \derivative[3]_i_128_n_0 ;
  wire \derivative[3]_i_129_n_0 ;
  wire \derivative[3]_i_12_n_0 ;
  wire \derivative[3]_i_130_n_0 ;
  wire \derivative[3]_i_131_n_0 ;
  wire \derivative[3]_i_133_n_0 ;
  wire \derivative[3]_i_134_n_0 ;
  wire \derivative[3]_i_135_n_0 ;
  wire \derivative[3]_i_136_n_0 ;
  wire \derivative[3]_i_138_n_0 ;
  wire \derivative[3]_i_139_n_0 ;
  wire \derivative[3]_i_13_n_0 ;
  wire \derivative[3]_i_140_n_0 ;
  wire \derivative[3]_i_141_n_0 ;
  wire \derivative[3]_i_143_n_0 ;
  wire \derivative[3]_i_144_n_0 ;
  wire \derivative[3]_i_145_n_0 ;
  wire \derivative[3]_i_146_n_0 ;
  wire \derivative[3]_i_148_n_0 ;
  wire \derivative[3]_i_149_n_0 ;
  wire \derivative[3]_i_150_n_0 ;
  wire \derivative[3]_i_151_n_0 ;
  wire \derivative[3]_i_153_n_0 ;
  wire \derivative[3]_i_154_n_0 ;
  wire \derivative[3]_i_155_n_0 ;
  wire \derivative[3]_i_156_n_0 ;
  wire \derivative[3]_i_158_n_0 ;
  wire \derivative[3]_i_159_n_0 ;
  wire \derivative[3]_i_15_n_0 ;
  wire \derivative[3]_i_160_n_0 ;
  wire \derivative[3]_i_161_n_0 ;
  wire \derivative[3]_i_163_n_0 ;
  wire \derivative[3]_i_164_n_0 ;
  wire \derivative[3]_i_165_n_0 ;
  wire \derivative[3]_i_167_n_0 ;
  wire \derivative[3]_i_168_n_0 ;
  wire \derivative[3]_i_169_n_0 ;
  wire \derivative[3]_i_16_n_0 ;
  wire \derivative[3]_i_171_n_0 ;
  wire \derivative[3]_i_172_n_0 ;
  wire \derivative[3]_i_173_n_0 ;
  wire \derivative[3]_i_174_n_0 ;
  wire \derivative[3]_i_175_n_0 ;
  wire \derivative[3]_i_176_n_0 ;
  wire \derivative[3]_i_177_n_0 ;
  wire \derivative[3]_i_18_n_0 ;
  wire \derivative[3]_i_19_n_0 ;
  wire \derivative[3]_i_21_n_0 ;
  wire \derivative[3]_i_23_n_0 ;
  wire \derivative[3]_i_24_n_0 ;
  wire \derivative[3]_i_25_n_0 ;
  wire \derivative[3]_i_26_n_0 ;
  wire \derivative[3]_i_28_n_0 ;
  wire \derivative[3]_i_29_n_0 ;
  wire \derivative[3]_i_30_n_0 ;
  wire \derivative[3]_i_31_n_0 ;
  wire \derivative[3]_i_33_n_0 ;
  wire \derivative[3]_i_34_n_0 ;
  wire \derivative[3]_i_35_n_0 ;
  wire \derivative[3]_i_36_n_0 ;
  wire \derivative[3]_i_38_n_0 ;
  wire \derivative[3]_i_39_n_0 ;
  wire \derivative[3]_i_3_n_0 ;
  wire \derivative[3]_i_40_n_0 ;
  wire \derivative[3]_i_41_n_0 ;
  wire \derivative[3]_i_43_n_0 ;
  wire \derivative[3]_i_44_n_0 ;
  wire \derivative[3]_i_45_n_0 ;
  wire \derivative[3]_i_46_n_0 ;
  wire \derivative[3]_i_48_n_0 ;
  wire \derivative[3]_i_49_n_0 ;
  wire \derivative[3]_i_4_n_0 ;
  wire \derivative[3]_i_50_n_0 ;
  wire \derivative[3]_i_51_n_0 ;
  wire \derivative[3]_i_53_n_0 ;
  wire \derivative[3]_i_54_n_0 ;
  wire \derivative[3]_i_55_n_0 ;
  wire \derivative[3]_i_56_n_0 ;
  wire \derivative[3]_i_58_n_0 ;
  wire \derivative[3]_i_59_n_0 ;
  wire \derivative[3]_i_5_n_0 ;
  wire \derivative[3]_i_60_n_0 ;
  wire \derivative[3]_i_61_n_0 ;
  wire \derivative[3]_i_63_n_0 ;
  wire \derivative[3]_i_64_n_0 ;
  wire \derivative[3]_i_65_n_0 ;
  wire \derivative[3]_i_66_n_0 ;
  wire \derivative[3]_i_68_n_0 ;
  wire \derivative[3]_i_69_n_0 ;
  wire \derivative[3]_i_6_n_0 ;
  wire \derivative[3]_i_70_n_0 ;
  wire \derivative[3]_i_71_n_0 ;
  wire \derivative[3]_i_73_n_0 ;
  wire \derivative[3]_i_74_n_0 ;
  wire \derivative[3]_i_75_n_0 ;
  wire \derivative[3]_i_76_n_0 ;
  wire \derivative[3]_i_78_n_0 ;
  wire \derivative[3]_i_79_n_0 ;
  wire \derivative[3]_i_80_n_0 ;
  wire \derivative[3]_i_81_n_0 ;
  wire \derivative[3]_i_83_n_0 ;
  wire \derivative[3]_i_84_n_0 ;
  wire \derivative[3]_i_85_n_0 ;
  wire \derivative[3]_i_86_n_0 ;
  wire \derivative[3]_i_88_n_0 ;
  wire \derivative[3]_i_89_n_0 ;
  wire \derivative[3]_i_90_n_0 ;
  wire \derivative[3]_i_91_n_0 ;
  wire \derivative[3]_i_93_n_0 ;
  wire \derivative[3]_i_94_n_0 ;
  wire \derivative[3]_i_95_n_0 ;
  wire \derivative[3]_i_96_n_0 ;
  wire \derivative[3]_i_98_n_0 ;
  wire \derivative[3]_i_99_n_0 ;
  wire \derivative[7]_i_100_n_0 ;
  wire \derivative[7]_i_101_n_0 ;
  wire \derivative[7]_i_103_n_0 ;
  wire \derivative[7]_i_104_n_0 ;
  wire \derivative[7]_i_105_n_0 ;
  wire \derivative[7]_i_106_n_0 ;
  wire \derivative[7]_i_108_n_0 ;
  wire \derivative[7]_i_109_n_0 ;
  wire \derivative[7]_i_110_n_0 ;
  wire \derivative[7]_i_111_n_0 ;
  wire \derivative[7]_i_113_n_0 ;
  wire \derivative[7]_i_114_n_0 ;
  wire \derivative[7]_i_115_n_0 ;
  wire \derivative[7]_i_116_n_0 ;
  wire \derivative[7]_i_118_n_0 ;
  wire \derivative[7]_i_119_n_0 ;
  wire \derivative[7]_i_11_n_0 ;
  wire \derivative[7]_i_120_n_0 ;
  wire \derivative[7]_i_121_n_0 ;
  wire \derivative[7]_i_123_n_0 ;
  wire \derivative[7]_i_124_n_0 ;
  wire \derivative[7]_i_125_n_0 ;
  wire \derivative[7]_i_126_n_0 ;
  wire \derivative[7]_i_128_n_0 ;
  wire \derivative[7]_i_129_n_0 ;
  wire \derivative[7]_i_12_n_0 ;
  wire \derivative[7]_i_130_n_0 ;
  wire \derivative[7]_i_131_n_0 ;
  wire \derivative[7]_i_133_n_0 ;
  wire \derivative[7]_i_134_n_0 ;
  wire \derivative[7]_i_135_n_0 ;
  wire \derivative[7]_i_136_n_0 ;
  wire \derivative[7]_i_138_n_0 ;
  wire \derivative[7]_i_139_n_0 ;
  wire \derivative[7]_i_140_n_0 ;
  wire \derivative[7]_i_141_n_0 ;
  wire \derivative[7]_i_143_n_0 ;
  wire \derivative[7]_i_144_n_0 ;
  wire \derivative[7]_i_145_n_0 ;
  wire \derivative[7]_i_146_n_0 ;
  wire \derivative[7]_i_148_n_0 ;
  wire \derivative[7]_i_149_n_0 ;
  wire \derivative[7]_i_14_n_0 ;
  wire \derivative[7]_i_150_n_0 ;
  wire \derivative[7]_i_151_n_0 ;
  wire \derivative[7]_i_153_n_0 ;
  wire \derivative[7]_i_154_n_0 ;
  wire \derivative[7]_i_155_n_0 ;
  wire \derivative[7]_i_156_n_0 ;
  wire \derivative[7]_i_158_n_0 ;
  wire \derivative[7]_i_159_n_0 ;
  wire \derivative[7]_i_15_n_0 ;
  wire \derivative[7]_i_160_n_0 ;
  wire \derivative[7]_i_161_n_0 ;
  wire \derivative[7]_i_163_n_0 ;
  wire \derivative[7]_i_164_n_0 ;
  wire \derivative[7]_i_165_n_0 ;
  wire \derivative[7]_i_167_n_0 ;
  wire \derivative[7]_i_168_n_0 ;
  wire \derivative[7]_i_169_n_0 ;
  wire \derivative[7]_i_171_n_0 ;
  wire \derivative[7]_i_172_n_0 ;
  wire \derivative[7]_i_173_n_0 ;
  wire \derivative[7]_i_175_n_0 ;
  wire \derivative[7]_i_176_n_0 ;
  wire \derivative[7]_i_177_n_0 ;
  wire \derivative[7]_i_179_n_0 ;
  wire \derivative[7]_i_17_n_0 ;
  wire \derivative[7]_i_180_n_0 ;
  wire \derivative[7]_i_181_n_0 ;
  wire \derivative[7]_i_182_n_0 ;
  wire \derivative[7]_i_183_n_0 ;
  wire \derivative[7]_i_18_n_0 ;
  wire \derivative[7]_i_20_n_0 ;
  wire \derivative[7]_i_21_n_0 ;
  wire \derivative[7]_i_23_n_0 ;
  wire \derivative[7]_i_24_n_0 ;
  wire \derivative[7]_i_25_n_0 ;
  wire \derivative[7]_i_26_n_0 ;
  wire \derivative[7]_i_28_n_0 ;
  wire \derivative[7]_i_29_n_0 ;
  wire \derivative[7]_i_2_n_0 ;
  wire \derivative[7]_i_30_n_0 ;
  wire \derivative[7]_i_31_n_0 ;
  wire \derivative[7]_i_33_n_0 ;
  wire \derivative[7]_i_34_n_0 ;
  wire \derivative[7]_i_35_n_0 ;
  wire \derivative[7]_i_36_n_0 ;
  wire \derivative[7]_i_38_n_0 ;
  wire \derivative[7]_i_39_n_0 ;
  wire \derivative[7]_i_3_n_0 ;
  wire \derivative[7]_i_40_n_0 ;
  wire \derivative[7]_i_41_n_0 ;
  wire \derivative[7]_i_43_n_0 ;
  wire \derivative[7]_i_44_n_0 ;
  wire \derivative[7]_i_45_n_0 ;
  wire \derivative[7]_i_46_n_0 ;
  wire \derivative[7]_i_48_n_0 ;
  wire \derivative[7]_i_49_n_0 ;
  wire \derivative[7]_i_4_n_0 ;
  wire \derivative[7]_i_50_n_0 ;
  wire \derivative[7]_i_51_n_0 ;
  wire \derivative[7]_i_53_n_0 ;
  wire \derivative[7]_i_54_n_0 ;
  wire \derivative[7]_i_55_n_0 ;
  wire \derivative[7]_i_56_n_0 ;
  wire \derivative[7]_i_58_n_0 ;
  wire \derivative[7]_i_59_n_0 ;
  wire \derivative[7]_i_5_n_0 ;
  wire \derivative[7]_i_60_n_0 ;
  wire \derivative[7]_i_61_n_0 ;
  wire \derivative[7]_i_63_n_0 ;
  wire \derivative[7]_i_64_n_0 ;
  wire \derivative[7]_i_65_n_0 ;
  wire \derivative[7]_i_66_n_0 ;
  wire \derivative[7]_i_68_n_0 ;
  wire \derivative[7]_i_69_n_0 ;
  wire \derivative[7]_i_70_n_0 ;
  wire \derivative[7]_i_71_n_0 ;
  wire \derivative[7]_i_73_n_0 ;
  wire \derivative[7]_i_74_n_0 ;
  wire \derivative[7]_i_75_n_0 ;
  wire \derivative[7]_i_76_n_0 ;
  wire \derivative[7]_i_78_n_0 ;
  wire \derivative[7]_i_79_n_0 ;
  wire \derivative[7]_i_80_n_0 ;
  wire \derivative[7]_i_81_n_0 ;
  wire \derivative[7]_i_83_n_0 ;
  wire \derivative[7]_i_84_n_0 ;
  wire \derivative[7]_i_85_n_0 ;
  wire \derivative[7]_i_86_n_0 ;
  wire \derivative[7]_i_88_n_0 ;
  wire \derivative[7]_i_89_n_0 ;
  wire \derivative[7]_i_90_n_0 ;
  wire \derivative[7]_i_91_n_0 ;
  wire \derivative[7]_i_93_n_0 ;
  wire \derivative[7]_i_94_n_0 ;
  wire \derivative[7]_i_95_n_0 ;
  wire \derivative[7]_i_96_n_0 ;
  wire \derivative[7]_i_98_n_0 ;
  wire \derivative[7]_i_99_n_0 ;
  wire [31:0]derivative_out;
  wire \derivative_reg[11]_i_102_n_0 ;
  wire \derivative_reg[11]_i_102_n_1 ;
  wire \derivative_reg[11]_i_102_n_2 ;
  wire \derivative_reg[11]_i_102_n_3 ;
  wire \derivative_reg[11]_i_102_n_4 ;
  wire \derivative_reg[11]_i_102_n_5 ;
  wire \derivative_reg[11]_i_102_n_6 ;
  wire \derivative_reg[11]_i_102_n_7 ;
  wire \derivative_reg[11]_i_107_n_0 ;
  wire \derivative_reg[11]_i_107_n_1 ;
  wire \derivative_reg[11]_i_107_n_2 ;
  wire \derivative_reg[11]_i_107_n_3 ;
  wire \derivative_reg[11]_i_107_n_4 ;
  wire \derivative_reg[11]_i_107_n_5 ;
  wire \derivative_reg[11]_i_107_n_6 ;
  wire \derivative_reg[11]_i_107_n_7 ;
  wire \derivative_reg[11]_i_10_n_0 ;
  wire \derivative_reg[11]_i_10_n_1 ;
  wire \derivative_reg[11]_i_10_n_2 ;
  wire \derivative_reg[11]_i_10_n_3 ;
  wire \derivative_reg[11]_i_10_n_4 ;
  wire \derivative_reg[11]_i_10_n_5 ;
  wire \derivative_reg[11]_i_10_n_6 ;
  wire \derivative_reg[11]_i_10_n_7 ;
  wire \derivative_reg[11]_i_112_n_0 ;
  wire \derivative_reg[11]_i_112_n_1 ;
  wire \derivative_reg[11]_i_112_n_2 ;
  wire \derivative_reg[11]_i_112_n_3 ;
  wire \derivative_reg[11]_i_112_n_4 ;
  wire \derivative_reg[11]_i_112_n_5 ;
  wire \derivative_reg[11]_i_112_n_6 ;
  wire \derivative_reg[11]_i_112_n_7 ;
  wire \derivative_reg[11]_i_117_n_0 ;
  wire \derivative_reg[11]_i_117_n_1 ;
  wire \derivative_reg[11]_i_117_n_2 ;
  wire \derivative_reg[11]_i_117_n_3 ;
  wire \derivative_reg[11]_i_117_n_4 ;
  wire \derivative_reg[11]_i_117_n_5 ;
  wire \derivative_reg[11]_i_117_n_6 ;
  wire \derivative_reg[11]_i_117_n_7 ;
  wire \derivative_reg[11]_i_122_n_0 ;
  wire \derivative_reg[11]_i_122_n_1 ;
  wire \derivative_reg[11]_i_122_n_2 ;
  wire \derivative_reg[11]_i_122_n_3 ;
  wire \derivative_reg[11]_i_122_n_4 ;
  wire \derivative_reg[11]_i_122_n_5 ;
  wire \derivative_reg[11]_i_122_n_6 ;
  wire \derivative_reg[11]_i_122_n_7 ;
  wire \derivative_reg[11]_i_127_n_0 ;
  wire \derivative_reg[11]_i_127_n_1 ;
  wire \derivative_reg[11]_i_127_n_2 ;
  wire \derivative_reg[11]_i_127_n_3 ;
  wire \derivative_reg[11]_i_127_n_4 ;
  wire \derivative_reg[11]_i_127_n_5 ;
  wire \derivative_reg[11]_i_127_n_6 ;
  wire \derivative_reg[11]_i_127_n_7 ;
  wire \derivative_reg[11]_i_132_n_0 ;
  wire \derivative_reg[11]_i_132_n_1 ;
  wire \derivative_reg[11]_i_132_n_2 ;
  wire \derivative_reg[11]_i_132_n_3 ;
  wire \derivative_reg[11]_i_132_n_4 ;
  wire \derivative_reg[11]_i_132_n_5 ;
  wire \derivative_reg[11]_i_132_n_6 ;
  wire \derivative_reg[11]_i_132_n_7 ;
  wire \derivative_reg[11]_i_137_n_0 ;
  wire \derivative_reg[11]_i_137_n_1 ;
  wire \derivative_reg[11]_i_137_n_2 ;
  wire \derivative_reg[11]_i_137_n_3 ;
  wire \derivative_reg[11]_i_137_n_4 ;
  wire \derivative_reg[11]_i_137_n_5 ;
  wire \derivative_reg[11]_i_137_n_6 ;
  wire \derivative_reg[11]_i_137_n_7 ;
  wire \derivative_reg[11]_i_13_n_0 ;
  wire \derivative_reg[11]_i_13_n_1 ;
  wire \derivative_reg[11]_i_13_n_2 ;
  wire \derivative_reg[11]_i_13_n_3 ;
  wire \derivative_reg[11]_i_13_n_4 ;
  wire \derivative_reg[11]_i_13_n_5 ;
  wire \derivative_reg[11]_i_13_n_6 ;
  wire \derivative_reg[11]_i_13_n_7 ;
  wire \derivative_reg[11]_i_142_n_0 ;
  wire \derivative_reg[11]_i_142_n_1 ;
  wire \derivative_reg[11]_i_142_n_2 ;
  wire \derivative_reg[11]_i_142_n_3 ;
  wire \derivative_reg[11]_i_142_n_4 ;
  wire \derivative_reg[11]_i_142_n_5 ;
  wire \derivative_reg[11]_i_142_n_6 ;
  wire \derivative_reg[11]_i_147_n_0 ;
  wire \derivative_reg[11]_i_147_n_1 ;
  wire \derivative_reg[11]_i_147_n_2 ;
  wire \derivative_reg[11]_i_147_n_3 ;
  wire \derivative_reg[11]_i_147_n_4 ;
  wire \derivative_reg[11]_i_147_n_5 ;
  wire \derivative_reg[11]_i_147_n_6 ;
  wire \derivative_reg[11]_i_152_n_0 ;
  wire \derivative_reg[11]_i_152_n_1 ;
  wire \derivative_reg[11]_i_152_n_2 ;
  wire \derivative_reg[11]_i_152_n_3 ;
  wire \derivative_reg[11]_i_152_n_4 ;
  wire \derivative_reg[11]_i_152_n_5 ;
  wire \derivative_reg[11]_i_152_n_6 ;
  wire \derivative_reg[11]_i_157_n_0 ;
  wire \derivative_reg[11]_i_157_n_1 ;
  wire \derivative_reg[11]_i_157_n_2 ;
  wire \derivative_reg[11]_i_157_n_3 ;
  wire \derivative_reg[11]_i_157_n_4 ;
  wire \derivative_reg[11]_i_157_n_5 ;
  wire \derivative_reg[11]_i_157_n_6 ;
  wire \derivative_reg[11]_i_16_n_0 ;
  wire \derivative_reg[11]_i_16_n_1 ;
  wire \derivative_reg[11]_i_16_n_2 ;
  wire \derivative_reg[11]_i_16_n_3 ;
  wire \derivative_reg[11]_i_16_n_4 ;
  wire \derivative_reg[11]_i_16_n_5 ;
  wire \derivative_reg[11]_i_16_n_6 ;
  wire \derivative_reg[11]_i_16_n_7 ;
  wire \derivative_reg[11]_i_178_n_0 ;
  wire \derivative_reg[11]_i_178_n_1 ;
  wire \derivative_reg[11]_i_178_n_2 ;
  wire \derivative_reg[11]_i_178_n_3 ;
  wire \derivative_reg[11]_i_178_n_4 ;
  wire \derivative_reg[11]_i_178_n_5 ;
  wire \derivative_reg[11]_i_178_n_6 ;
  wire \derivative_reg[11]_i_178_n_7 ;
  wire \derivative_reg[11]_i_19_n_0 ;
  wire \derivative_reg[11]_i_19_n_1 ;
  wire \derivative_reg[11]_i_19_n_2 ;
  wire \derivative_reg[11]_i_19_n_3 ;
  wire \derivative_reg[11]_i_19_n_4 ;
  wire \derivative_reg[11]_i_19_n_5 ;
  wire \derivative_reg[11]_i_19_n_6 ;
  wire \derivative_reg[11]_i_19_n_7 ;
  wire \derivative_reg[11]_i_1_n_0 ;
  wire \derivative_reg[11]_i_1_n_1 ;
  wire \derivative_reg[11]_i_1_n_2 ;
  wire \derivative_reg[11]_i_1_n_3 ;
  wire \derivative_reg[11]_i_1_n_4 ;
  wire \derivative_reg[11]_i_1_n_5 ;
  wire \derivative_reg[11]_i_1_n_6 ;
  wire \derivative_reg[11]_i_1_n_7 ;
  wire \derivative_reg[11]_i_22_n_0 ;
  wire \derivative_reg[11]_i_22_n_1 ;
  wire \derivative_reg[11]_i_22_n_2 ;
  wire \derivative_reg[11]_i_22_n_3 ;
  wire \derivative_reg[11]_i_22_n_4 ;
  wire \derivative_reg[11]_i_22_n_5 ;
  wire \derivative_reg[11]_i_22_n_6 ;
  wire \derivative_reg[11]_i_22_n_7 ;
  wire \derivative_reg[11]_i_27_n_0 ;
  wire \derivative_reg[11]_i_27_n_1 ;
  wire \derivative_reg[11]_i_27_n_2 ;
  wire \derivative_reg[11]_i_27_n_3 ;
  wire \derivative_reg[11]_i_27_n_4 ;
  wire \derivative_reg[11]_i_27_n_5 ;
  wire \derivative_reg[11]_i_27_n_6 ;
  wire \derivative_reg[11]_i_27_n_7 ;
  wire \derivative_reg[11]_i_32_n_0 ;
  wire \derivative_reg[11]_i_32_n_1 ;
  wire \derivative_reg[11]_i_32_n_2 ;
  wire \derivative_reg[11]_i_32_n_3 ;
  wire \derivative_reg[11]_i_32_n_4 ;
  wire \derivative_reg[11]_i_32_n_5 ;
  wire \derivative_reg[11]_i_32_n_6 ;
  wire \derivative_reg[11]_i_32_n_7 ;
  wire \derivative_reg[11]_i_37_n_0 ;
  wire \derivative_reg[11]_i_37_n_1 ;
  wire \derivative_reg[11]_i_37_n_2 ;
  wire \derivative_reg[11]_i_37_n_3 ;
  wire \derivative_reg[11]_i_37_n_4 ;
  wire \derivative_reg[11]_i_37_n_5 ;
  wire \derivative_reg[11]_i_37_n_6 ;
  wire \derivative_reg[11]_i_37_n_7 ;
  wire \derivative_reg[11]_i_42_n_0 ;
  wire \derivative_reg[11]_i_42_n_1 ;
  wire \derivative_reg[11]_i_42_n_2 ;
  wire \derivative_reg[11]_i_42_n_3 ;
  wire \derivative_reg[11]_i_42_n_4 ;
  wire \derivative_reg[11]_i_42_n_5 ;
  wire \derivative_reg[11]_i_42_n_6 ;
  wire \derivative_reg[11]_i_42_n_7 ;
  wire \derivative_reg[11]_i_47_n_0 ;
  wire \derivative_reg[11]_i_47_n_1 ;
  wire \derivative_reg[11]_i_47_n_2 ;
  wire \derivative_reg[11]_i_47_n_3 ;
  wire \derivative_reg[11]_i_47_n_4 ;
  wire \derivative_reg[11]_i_47_n_5 ;
  wire \derivative_reg[11]_i_47_n_6 ;
  wire \derivative_reg[11]_i_47_n_7 ;
  wire \derivative_reg[11]_i_52_n_0 ;
  wire \derivative_reg[11]_i_52_n_1 ;
  wire \derivative_reg[11]_i_52_n_2 ;
  wire \derivative_reg[11]_i_52_n_3 ;
  wire \derivative_reg[11]_i_52_n_4 ;
  wire \derivative_reg[11]_i_52_n_5 ;
  wire \derivative_reg[11]_i_52_n_6 ;
  wire \derivative_reg[11]_i_52_n_7 ;
  wire \derivative_reg[11]_i_57_n_0 ;
  wire \derivative_reg[11]_i_57_n_1 ;
  wire \derivative_reg[11]_i_57_n_2 ;
  wire \derivative_reg[11]_i_57_n_3 ;
  wire \derivative_reg[11]_i_57_n_4 ;
  wire \derivative_reg[11]_i_57_n_5 ;
  wire \derivative_reg[11]_i_57_n_6 ;
  wire \derivative_reg[11]_i_57_n_7 ;
  wire \derivative_reg[11]_i_62_n_0 ;
  wire \derivative_reg[11]_i_62_n_1 ;
  wire \derivative_reg[11]_i_62_n_2 ;
  wire \derivative_reg[11]_i_62_n_3 ;
  wire \derivative_reg[11]_i_62_n_4 ;
  wire \derivative_reg[11]_i_62_n_5 ;
  wire \derivative_reg[11]_i_62_n_6 ;
  wire \derivative_reg[11]_i_62_n_7 ;
  wire \derivative_reg[11]_i_67_n_0 ;
  wire \derivative_reg[11]_i_67_n_1 ;
  wire \derivative_reg[11]_i_67_n_2 ;
  wire \derivative_reg[11]_i_67_n_3 ;
  wire \derivative_reg[11]_i_67_n_4 ;
  wire \derivative_reg[11]_i_67_n_5 ;
  wire \derivative_reg[11]_i_67_n_6 ;
  wire \derivative_reg[11]_i_67_n_7 ;
  wire \derivative_reg[11]_i_6_n_3 ;
  wire \derivative_reg[11]_i_6_n_7 ;
  wire \derivative_reg[11]_i_72_n_0 ;
  wire \derivative_reg[11]_i_72_n_1 ;
  wire \derivative_reg[11]_i_72_n_2 ;
  wire \derivative_reg[11]_i_72_n_3 ;
  wire \derivative_reg[11]_i_72_n_4 ;
  wire \derivative_reg[11]_i_72_n_5 ;
  wire \derivative_reg[11]_i_72_n_6 ;
  wire \derivative_reg[11]_i_72_n_7 ;
  wire \derivative_reg[11]_i_77_n_0 ;
  wire \derivative_reg[11]_i_77_n_1 ;
  wire \derivative_reg[11]_i_77_n_2 ;
  wire \derivative_reg[11]_i_77_n_3 ;
  wire \derivative_reg[11]_i_77_n_4 ;
  wire \derivative_reg[11]_i_77_n_5 ;
  wire \derivative_reg[11]_i_77_n_6 ;
  wire \derivative_reg[11]_i_77_n_7 ;
  wire \derivative_reg[11]_i_7_n_3 ;
  wire \derivative_reg[11]_i_7_n_7 ;
  wire \derivative_reg[11]_i_82_n_0 ;
  wire \derivative_reg[11]_i_82_n_1 ;
  wire \derivative_reg[11]_i_82_n_2 ;
  wire \derivative_reg[11]_i_82_n_3 ;
  wire \derivative_reg[11]_i_82_n_4 ;
  wire \derivative_reg[11]_i_82_n_5 ;
  wire \derivative_reg[11]_i_82_n_6 ;
  wire \derivative_reg[11]_i_82_n_7 ;
  wire \derivative_reg[11]_i_87_n_0 ;
  wire \derivative_reg[11]_i_87_n_1 ;
  wire \derivative_reg[11]_i_87_n_2 ;
  wire \derivative_reg[11]_i_87_n_3 ;
  wire \derivative_reg[11]_i_87_n_4 ;
  wire \derivative_reg[11]_i_87_n_5 ;
  wire \derivative_reg[11]_i_87_n_6 ;
  wire \derivative_reg[11]_i_87_n_7 ;
  wire \derivative_reg[11]_i_8_n_3 ;
  wire \derivative_reg[11]_i_8_n_7 ;
  wire \derivative_reg[11]_i_92_n_0 ;
  wire \derivative_reg[11]_i_92_n_1 ;
  wire \derivative_reg[11]_i_92_n_2 ;
  wire \derivative_reg[11]_i_92_n_3 ;
  wire \derivative_reg[11]_i_92_n_4 ;
  wire \derivative_reg[11]_i_92_n_5 ;
  wire \derivative_reg[11]_i_92_n_6 ;
  wire \derivative_reg[11]_i_92_n_7 ;
  wire \derivative_reg[11]_i_97_n_0 ;
  wire \derivative_reg[11]_i_97_n_1 ;
  wire \derivative_reg[11]_i_97_n_2 ;
  wire \derivative_reg[11]_i_97_n_3 ;
  wire \derivative_reg[11]_i_97_n_4 ;
  wire \derivative_reg[11]_i_97_n_5 ;
  wire \derivative_reg[11]_i_97_n_6 ;
  wire \derivative_reg[11]_i_97_n_7 ;
  wire \derivative_reg[11]_i_9_n_3 ;
  wire \derivative_reg[11]_i_9_n_7 ;
  wire \derivative_reg[15]_i_102_n_0 ;
  wire \derivative_reg[15]_i_102_n_1 ;
  wire \derivative_reg[15]_i_102_n_2 ;
  wire \derivative_reg[15]_i_102_n_3 ;
  wire \derivative_reg[15]_i_102_n_4 ;
  wire \derivative_reg[15]_i_102_n_5 ;
  wire \derivative_reg[15]_i_102_n_6 ;
  wire \derivative_reg[15]_i_102_n_7 ;
  wire \derivative_reg[15]_i_107_n_0 ;
  wire \derivative_reg[15]_i_107_n_1 ;
  wire \derivative_reg[15]_i_107_n_2 ;
  wire \derivative_reg[15]_i_107_n_3 ;
  wire \derivative_reg[15]_i_107_n_4 ;
  wire \derivative_reg[15]_i_107_n_5 ;
  wire \derivative_reg[15]_i_107_n_6 ;
  wire \derivative_reg[15]_i_107_n_7 ;
  wire \derivative_reg[15]_i_10_n_0 ;
  wire \derivative_reg[15]_i_10_n_1 ;
  wire \derivative_reg[15]_i_10_n_2 ;
  wire \derivative_reg[15]_i_10_n_3 ;
  wire \derivative_reg[15]_i_10_n_4 ;
  wire \derivative_reg[15]_i_10_n_5 ;
  wire \derivative_reg[15]_i_10_n_6 ;
  wire \derivative_reg[15]_i_10_n_7 ;
  wire \derivative_reg[15]_i_112_n_0 ;
  wire \derivative_reg[15]_i_112_n_1 ;
  wire \derivative_reg[15]_i_112_n_2 ;
  wire \derivative_reg[15]_i_112_n_3 ;
  wire \derivative_reg[15]_i_112_n_4 ;
  wire \derivative_reg[15]_i_112_n_5 ;
  wire \derivative_reg[15]_i_112_n_6 ;
  wire \derivative_reg[15]_i_112_n_7 ;
  wire \derivative_reg[15]_i_117_n_0 ;
  wire \derivative_reg[15]_i_117_n_1 ;
  wire \derivative_reg[15]_i_117_n_2 ;
  wire \derivative_reg[15]_i_117_n_3 ;
  wire \derivative_reg[15]_i_117_n_4 ;
  wire \derivative_reg[15]_i_117_n_5 ;
  wire \derivative_reg[15]_i_117_n_6 ;
  wire \derivative_reg[15]_i_117_n_7 ;
  wire \derivative_reg[15]_i_122_n_0 ;
  wire \derivative_reg[15]_i_122_n_1 ;
  wire \derivative_reg[15]_i_122_n_2 ;
  wire \derivative_reg[15]_i_122_n_3 ;
  wire \derivative_reg[15]_i_122_n_4 ;
  wire \derivative_reg[15]_i_122_n_5 ;
  wire \derivative_reg[15]_i_122_n_6 ;
  wire \derivative_reg[15]_i_122_n_7 ;
  wire \derivative_reg[15]_i_127_n_0 ;
  wire \derivative_reg[15]_i_127_n_1 ;
  wire \derivative_reg[15]_i_127_n_2 ;
  wire \derivative_reg[15]_i_127_n_3 ;
  wire \derivative_reg[15]_i_127_n_4 ;
  wire \derivative_reg[15]_i_127_n_5 ;
  wire \derivative_reg[15]_i_127_n_6 ;
  wire \derivative_reg[15]_i_127_n_7 ;
  wire \derivative_reg[15]_i_132_n_0 ;
  wire \derivative_reg[15]_i_132_n_1 ;
  wire \derivative_reg[15]_i_132_n_2 ;
  wire \derivative_reg[15]_i_132_n_3 ;
  wire \derivative_reg[15]_i_132_n_4 ;
  wire \derivative_reg[15]_i_132_n_5 ;
  wire \derivative_reg[15]_i_132_n_6 ;
  wire \derivative_reg[15]_i_132_n_7 ;
  wire \derivative_reg[15]_i_137_n_0 ;
  wire \derivative_reg[15]_i_137_n_1 ;
  wire \derivative_reg[15]_i_137_n_2 ;
  wire \derivative_reg[15]_i_137_n_3 ;
  wire \derivative_reg[15]_i_137_n_4 ;
  wire \derivative_reg[15]_i_137_n_5 ;
  wire \derivative_reg[15]_i_137_n_6 ;
  wire \derivative_reg[15]_i_137_n_7 ;
  wire \derivative_reg[15]_i_13_n_0 ;
  wire \derivative_reg[15]_i_13_n_1 ;
  wire \derivative_reg[15]_i_13_n_2 ;
  wire \derivative_reg[15]_i_13_n_3 ;
  wire \derivative_reg[15]_i_13_n_4 ;
  wire \derivative_reg[15]_i_13_n_5 ;
  wire \derivative_reg[15]_i_13_n_6 ;
  wire \derivative_reg[15]_i_13_n_7 ;
  wire \derivative_reg[15]_i_142_n_0 ;
  wire \derivative_reg[15]_i_142_n_1 ;
  wire \derivative_reg[15]_i_142_n_2 ;
  wire \derivative_reg[15]_i_142_n_3 ;
  wire \derivative_reg[15]_i_142_n_4 ;
  wire \derivative_reg[15]_i_142_n_5 ;
  wire \derivative_reg[15]_i_142_n_6 ;
  wire \derivative_reg[15]_i_147_n_0 ;
  wire \derivative_reg[15]_i_147_n_1 ;
  wire \derivative_reg[15]_i_147_n_2 ;
  wire \derivative_reg[15]_i_147_n_3 ;
  wire \derivative_reg[15]_i_147_n_4 ;
  wire \derivative_reg[15]_i_147_n_5 ;
  wire \derivative_reg[15]_i_147_n_6 ;
  wire \derivative_reg[15]_i_152_n_0 ;
  wire \derivative_reg[15]_i_152_n_1 ;
  wire \derivative_reg[15]_i_152_n_2 ;
  wire \derivative_reg[15]_i_152_n_3 ;
  wire \derivative_reg[15]_i_152_n_4 ;
  wire \derivative_reg[15]_i_152_n_5 ;
  wire \derivative_reg[15]_i_152_n_6 ;
  wire \derivative_reg[15]_i_157_n_0 ;
  wire \derivative_reg[15]_i_157_n_1 ;
  wire \derivative_reg[15]_i_157_n_2 ;
  wire \derivative_reg[15]_i_157_n_3 ;
  wire \derivative_reg[15]_i_157_n_4 ;
  wire \derivative_reg[15]_i_157_n_5 ;
  wire \derivative_reg[15]_i_157_n_6 ;
  wire \derivative_reg[15]_i_16_n_0 ;
  wire \derivative_reg[15]_i_16_n_1 ;
  wire \derivative_reg[15]_i_16_n_2 ;
  wire \derivative_reg[15]_i_16_n_3 ;
  wire \derivative_reg[15]_i_16_n_4 ;
  wire \derivative_reg[15]_i_16_n_5 ;
  wire \derivative_reg[15]_i_16_n_6 ;
  wire \derivative_reg[15]_i_16_n_7 ;
  wire \derivative_reg[15]_i_178_n_0 ;
  wire \derivative_reg[15]_i_178_n_1 ;
  wire \derivative_reg[15]_i_178_n_2 ;
  wire \derivative_reg[15]_i_178_n_3 ;
  wire \derivative_reg[15]_i_178_n_4 ;
  wire \derivative_reg[15]_i_178_n_5 ;
  wire \derivative_reg[15]_i_178_n_6 ;
  wire \derivative_reg[15]_i_178_n_7 ;
  wire \derivative_reg[15]_i_19_n_0 ;
  wire \derivative_reg[15]_i_19_n_1 ;
  wire \derivative_reg[15]_i_19_n_2 ;
  wire \derivative_reg[15]_i_19_n_3 ;
  wire \derivative_reg[15]_i_19_n_4 ;
  wire \derivative_reg[15]_i_19_n_5 ;
  wire \derivative_reg[15]_i_19_n_6 ;
  wire \derivative_reg[15]_i_19_n_7 ;
  wire \derivative_reg[15]_i_1_n_0 ;
  wire \derivative_reg[15]_i_1_n_1 ;
  wire \derivative_reg[15]_i_1_n_2 ;
  wire \derivative_reg[15]_i_1_n_3 ;
  wire \derivative_reg[15]_i_1_n_4 ;
  wire \derivative_reg[15]_i_1_n_5 ;
  wire \derivative_reg[15]_i_1_n_6 ;
  wire \derivative_reg[15]_i_1_n_7 ;
  wire \derivative_reg[15]_i_22_n_0 ;
  wire \derivative_reg[15]_i_22_n_1 ;
  wire \derivative_reg[15]_i_22_n_2 ;
  wire \derivative_reg[15]_i_22_n_3 ;
  wire \derivative_reg[15]_i_22_n_4 ;
  wire \derivative_reg[15]_i_22_n_5 ;
  wire \derivative_reg[15]_i_22_n_6 ;
  wire \derivative_reg[15]_i_22_n_7 ;
  wire \derivative_reg[15]_i_27_n_0 ;
  wire \derivative_reg[15]_i_27_n_1 ;
  wire \derivative_reg[15]_i_27_n_2 ;
  wire \derivative_reg[15]_i_27_n_3 ;
  wire \derivative_reg[15]_i_27_n_4 ;
  wire \derivative_reg[15]_i_27_n_5 ;
  wire \derivative_reg[15]_i_27_n_6 ;
  wire \derivative_reg[15]_i_27_n_7 ;
  wire \derivative_reg[15]_i_32_n_0 ;
  wire \derivative_reg[15]_i_32_n_1 ;
  wire \derivative_reg[15]_i_32_n_2 ;
  wire \derivative_reg[15]_i_32_n_3 ;
  wire \derivative_reg[15]_i_32_n_4 ;
  wire \derivative_reg[15]_i_32_n_5 ;
  wire \derivative_reg[15]_i_32_n_6 ;
  wire \derivative_reg[15]_i_32_n_7 ;
  wire \derivative_reg[15]_i_37_n_0 ;
  wire \derivative_reg[15]_i_37_n_1 ;
  wire \derivative_reg[15]_i_37_n_2 ;
  wire \derivative_reg[15]_i_37_n_3 ;
  wire \derivative_reg[15]_i_37_n_4 ;
  wire \derivative_reg[15]_i_37_n_5 ;
  wire \derivative_reg[15]_i_37_n_6 ;
  wire \derivative_reg[15]_i_37_n_7 ;
  wire \derivative_reg[15]_i_42_n_0 ;
  wire \derivative_reg[15]_i_42_n_1 ;
  wire \derivative_reg[15]_i_42_n_2 ;
  wire \derivative_reg[15]_i_42_n_3 ;
  wire \derivative_reg[15]_i_42_n_4 ;
  wire \derivative_reg[15]_i_42_n_5 ;
  wire \derivative_reg[15]_i_42_n_6 ;
  wire \derivative_reg[15]_i_42_n_7 ;
  wire \derivative_reg[15]_i_47_n_0 ;
  wire \derivative_reg[15]_i_47_n_1 ;
  wire \derivative_reg[15]_i_47_n_2 ;
  wire \derivative_reg[15]_i_47_n_3 ;
  wire \derivative_reg[15]_i_47_n_4 ;
  wire \derivative_reg[15]_i_47_n_5 ;
  wire \derivative_reg[15]_i_47_n_6 ;
  wire \derivative_reg[15]_i_47_n_7 ;
  wire \derivative_reg[15]_i_52_n_0 ;
  wire \derivative_reg[15]_i_52_n_1 ;
  wire \derivative_reg[15]_i_52_n_2 ;
  wire \derivative_reg[15]_i_52_n_3 ;
  wire \derivative_reg[15]_i_52_n_4 ;
  wire \derivative_reg[15]_i_52_n_5 ;
  wire \derivative_reg[15]_i_52_n_6 ;
  wire \derivative_reg[15]_i_52_n_7 ;
  wire \derivative_reg[15]_i_57_n_0 ;
  wire \derivative_reg[15]_i_57_n_1 ;
  wire \derivative_reg[15]_i_57_n_2 ;
  wire \derivative_reg[15]_i_57_n_3 ;
  wire \derivative_reg[15]_i_57_n_4 ;
  wire \derivative_reg[15]_i_57_n_5 ;
  wire \derivative_reg[15]_i_57_n_6 ;
  wire \derivative_reg[15]_i_57_n_7 ;
  wire \derivative_reg[15]_i_62_n_0 ;
  wire \derivative_reg[15]_i_62_n_1 ;
  wire \derivative_reg[15]_i_62_n_2 ;
  wire \derivative_reg[15]_i_62_n_3 ;
  wire \derivative_reg[15]_i_62_n_4 ;
  wire \derivative_reg[15]_i_62_n_5 ;
  wire \derivative_reg[15]_i_62_n_6 ;
  wire \derivative_reg[15]_i_62_n_7 ;
  wire \derivative_reg[15]_i_67_n_0 ;
  wire \derivative_reg[15]_i_67_n_1 ;
  wire \derivative_reg[15]_i_67_n_2 ;
  wire \derivative_reg[15]_i_67_n_3 ;
  wire \derivative_reg[15]_i_67_n_4 ;
  wire \derivative_reg[15]_i_67_n_5 ;
  wire \derivative_reg[15]_i_67_n_6 ;
  wire \derivative_reg[15]_i_67_n_7 ;
  wire \derivative_reg[15]_i_6_n_3 ;
  wire \derivative_reg[15]_i_6_n_7 ;
  wire \derivative_reg[15]_i_72_n_0 ;
  wire \derivative_reg[15]_i_72_n_1 ;
  wire \derivative_reg[15]_i_72_n_2 ;
  wire \derivative_reg[15]_i_72_n_3 ;
  wire \derivative_reg[15]_i_72_n_4 ;
  wire \derivative_reg[15]_i_72_n_5 ;
  wire \derivative_reg[15]_i_72_n_6 ;
  wire \derivative_reg[15]_i_72_n_7 ;
  wire \derivative_reg[15]_i_77_n_0 ;
  wire \derivative_reg[15]_i_77_n_1 ;
  wire \derivative_reg[15]_i_77_n_2 ;
  wire \derivative_reg[15]_i_77_n_3 ;
  wire \derivative_reg[15]_i_77_n_4 ;
  wire \derivative_reg[15]_i_77_n_5 ;
  wire \derivative_reg[15]_i_77_n_6 ;
  wire \derivative_reg[15]_i_77_n_7 ;
  wire \derivative_reg[15]_i_7_n_3 ;
  wire \derivative_reg[15]_i_7_n_7 ;
  wire \derivative_reg[15]_i_82_n_0 ;
  wire \derivative_reg[15]_i_82_n_1 ;
  wire \derivative_reg[15]_i_82_n_2 ;
  wire \derivative_reg[15]_i_82_n_3 ;
  wire \derivative_reg[15]_i_82_n_4 ;
  wire \derivative_reg[15]_i_82_n_5 ;
  wire \derivative_reg[15]_i_82_n_6 ;
  wire \derivative_reg[15]_i_82_n_7 ;
  wire \derivative_reg[15]_i_87_n_0 ;
  wire \derivative_reg[15]_i_87_n_1 ;
  wire \derivative_reg[15]_i_87_n_2 ;
  wire \derivative_reg[15]_i_87_n_3 ;
  wire \derivative_reg[15]_i_87_n_4 ;
  wire \derivative_reg[15]_i_87_n_5 ;
  wire \derivative_reg[15]_i_87_n_6 ;
  wire \derivative_reg[15]_i_87_n_7 ;
  wire \derivative_reg[15]_i_8_n_3 ;
  wire \derivative_reg[15]_i_8_n_7 ;
  wire \derivative_reg[15]_i_92_n_0 ;
  wire \derivative_reg[15]_i_92_n_1 ;
  wire \derivative_reg[15]_i_92_n_2 ;
  wire \derivative_reg[15]_i_92_n_3 ;
  wire \derivative_reg[15]_i_92_n_4 ;
  wire \derivative_reg[15]_i_92_n_5 ;
  wire \derivative_reg[15]_i_92_n_6 ;
  wire \derivative_reg[15]_i_92_n_7 ;
  wire \derivative_reg[15]_i_97_n_0 ;
  wire \derivative_reg[15]_i_97_n_1 ;
  wire \derivative_reg[15]_i_97_n_2 ;
  wire \derivative_reg[15]_i_97_n_3 ;
  wire \derivative_reg[15]_i_97_n_4 ;
  wire \derivative_reg[15]_i_97_n_5 ;
  wire \derivative_reg[15]_i_97_n_6 ;
  wire \derivative_reg[15]_i_97_n_7 ;
  wire \derivative_reg[15]_i_9_n_3 ;
  wire \derivative_reg[15]_i_9_n_7 ;
  wire \derivative_reg[19]_i_102_n_0 ;
  wire \derivative_reg[19]_i_102_n_1 ;
  wire \derivative_reg[19]_i_102_n_2 ;
  wire \derivative_reg[19]_i_102_n_3 ;
  wire \derivative_reg[19]_i_102_n_4 ;
  wire \derivative_reg[19]_i_102_n_5 ;
  wire \derivative_reg[19]_i_102_n_6 ;
  wire \derivative_reg[19]_i_102_n_7 ;
  wire \derivative_reg[19]_i_107_n_0 ;
  wire \derivative_reg[19]_i_107_n_1 ;
  wire \derivative_reg[19]_i_107_n_2 ;
  wire \derivative_reg[19]_i_107_n_3 ;
  wire \derivative_reg[19]_i_107_n_4 ;
  wire \derivative_reg[19]_i_107_n_5 ;
  wire \derivative_reg[19]_i_107_n_6 ;
  wire \derivative_reg[19]_i_107_n_7 ;
  wire \derivative_reg[19]_i_10_n_0 ;
  wire \derivative_reg[19]_i_10_n_1 ;
  wire \derivative_reg[19]_i_10_n_2 ;
  wire \derivative_reg[19]_i_10_n_3 ;
  wire \derivative_reg[19]_i_10_n_4 ;
  wire \derivative_reg[19]_i_10_n_5 ;
  wire \derivative_reg[19]_i_10_n_6 ;
  wire \derivative_reg[19]_i_10_n_7 ;
  wire \derivative_reg[19]_i_112_n_0 ;
  wire \derivative_reg[19]_i_112_n_1 ;
  wire \derivative_reg[19]_i_112_n_2 ;
  wire \derivative_reg[19]_i_112_n_3 ;
  wire \derivative_reg[19]_i_112_n_4 ;
  wire \derivative_reg[19]_i_112_n_5 ;
  wire \derivative_reg[19]_i_112_n_6 ;
  wire \derivative_reg[19]_i_112_n_7 ;
  wire \derivative_reg[19]_i_117_n_0 ;
  wire \derivative_reg[19]_i_117_n_1 ;
  wire \derivative_reg[19]_i_117_n_2 ;
  wire \derivative_reg[19]_i_117_n_3 ;
  wire \derivative_reg[19]_i_117_n_4 ;
  wire \derivative_reg[19]_i_117_n_5 ;
  wire \derivative_reg[19]_i_117_n_6 ;
  wire \derivative_reg[19]_i_117_n_7 ;
  wire \derivative_reg[19]_i_122_n_0 ;
  wire \derivative_reg[19]_i_122_n_1 ;
  wire \derivative_reg[19]_i_122_n_2 ;
  wire \derivative_reg[19]_i_122_n_3 ;
  wire \derivative_reg[19]_i_122_n_4 ;
  wire \derivative_reg[19]_i_122_n_5 ;
  wire \derivative_reg[19]_i_122_n_6 ;
  wire \derivative_reg[19]_i_122_n_7 ;
  wire \derivative_reg[19]_i_127_n_0 ;
  wire \derivative_reg[19]_i_127_n_1 ;
  wire \derivative_reg[19]_i_127_n_2 ;
  wire \derivative_reg[19]_i_127_n_3 ;
  wire \derivative_reg[19]_i_127_n_4 ;
  wire \derivative_reg[19]_i_127_n_5 ;
  wire \derivative_reg[19]_i_127_n_6 ;
  wire \derivative_reg[19]_i_127_n_7 ;
  wire \derivative_reg[19]_i_132_n_0 ;
  wire \derivative_reg[19]_i_132_n_1 ;
  wire \derivative_reg[19]_i_132_n_2 ;
  wire \derivative_reg[19]_i_132_n_3 ;
  wire \derivative_reg[19]_i_132_n_4 ;
  wire \derivative_reg[19]_i_132_n_5 ;
  wire \derivative_reg[19]_i_132_n_6 ;
  wire \derivative_reg[19]_i_132_n_7 ;
  wire \derivative_reg[19]_i_137_n_0 ;
  wire \derivative_reg[19]_i_137_n_1 ;
  wire \derivative_reg[19]_i_137_n_2 ;
  wire \derivative_reg[19]_i_137_n_3 ;
  wire \derivative_reg[19]_i_137_n_4 ;
  wire \derivative_reg[19]_i_137_n_5 ;
  wire \derivative_reg[19]_i_137_n_6 ;
  wire \derivative_reg[19]_i_137_n_7 ;
  wire \derivative_reg[19]_i_13_n_0 ;
  wire \derivative_reg[19]_i_13_n_1 ;
  wire \derivative_reg[19]_i_13_n_2 ;
  wire \derivative_reg[19]_i_13_n_3 ;
  wire \derivative_reg[19]_i_13_n_4 ;
  wire \derivative_reg[19]_i_13_n_5 ;
  wire \derivative_reg[19]_i_13_n_6 ;
  wire \derivative_reg[19]_i_13_n_7 ;
  wire \derivative_reg[19]_i_142_n_0 ;
  wire \derivative_reg[19]_i_142_n_1 ;
  wire \derivative_reg[19]_i_142_n_2 ;
  wire \derivative_reg[19]_i_142_n_3 ;
  wire \derivative_reg[19]_i_142_n_4 ;
  wire \derivative_reg[19]_i_142_n_5 ;
  wire \derivative_reg[19]_i_142_n_6 ;
  wire \derivative_reg[19]_i_147_n_0 ;
  wire \derivative_reg[19]_i_147_n_1 ;
  wire \derivative_reg[19]_i_147_n_2 ;
  wire \derivative_reg[19]_i_147_n_3 ;
  wire \derivative_reg[19]_i_147_n_4 ;
  wire \derivative_reg[19]_i_147_n_5 ;
  wire \derivative_reg[19]_i_147_n_6 ;
  wire \derivative_reg[19]_i_152_n_0 ;
  wire \derivative_reg[19]_i_152_n_1 ;
  wire \derivative_reg[19]_i_152_n_2 ;
  wire \derivative_reg[19]_i_152_n_3 ;
  wire \derivative_reg[19]_i_152_n_4 ;
  wire \derivative_reg[19]_i_152_n_5 ;
  wire \derivative_reg[19]_i_152_n_6 ;
  wire \derivative_reg[19]_i_157_n_0 ;
  wire \derivative_reg[19]_i_157_n_1 ;
  wire \derivative_reg[19]_i_157_n_2 ;
  wire \derivative_reg[19]_i_157_n_3 ;
  wire \derivative_reg[19]_i_157_n_4 ;
  wire \derivative_reg[19]_i_157_n_5 ;
  wire \derivative_reg[19]_i_157_n_6 ;
  wire \derivative_reg[19]_i_16_n_0 ;
  wire \derivative_reg[19]_i_16_n_1 ;
  wire \derivative_reg[19]_i_16_n_2 ;
  wire \derivative_reg[19]_i_16_n_3 ;
  wire \derivative_reg[19]_i_16_n_4 ;
  wire \derivative_reg[19]_i_16_n_5 ;
  wire \derivative_reg[19]_i_16_n_6 ;
  wire \derivative_reg[19]_i_16_n_7 ;
  wire \derivative_reg[19]_i_178_n_0 ;
  wire \derivative_reg[19]_i_178_n_1 ;
  wire \derivative_reg[19]_i_178_n_2 ;
  wire \derivative_reg[19]_i_178_n_3 ;
  wire \derivative_reg[19]_i_178_n_4 ;
  wire \derivative_reg[19]_i_178_n_5 ;
  wire \derivative_reg[19]_i_178_n_6 ;
  wire \derivative_reg[19]_i_178_n_7 ;
  wire \derivative_reg[19]_i_19_n_0 ;
  wire \derivative_reg[19]_i_19_n_1 ;
  wire \derivative_reg[19]_i_19_n_2 ;
  wire \derivative_reg[19]_i_19_n_3 ;
  wire \derivative_reg[19]_i_19_n_4 ;
  wire \derivative_reg[19]_i_19_n_5 ;
  wire \derivative_reg[19]_i_19_n_6 ;
  wire \derivative_reg[19]_i_19_n_7 ;
  wire \derivative_reg[19]_i_1_n_0 ;
  wire \derivative_reg[19]_i_1_n_1 ;
  wire \derivative_reg[19]_i_1_n_2 ;
  wire \derivative_reg[19]_i_1_n_3 ;
  wire \derivative_reg[19]_i_1_n_4 ;
  wire \derivative_reg[19]_i_1_n_5 ;
  wire \derivative_reg[19]_i_1_n_6 ;
  wire \derivative_reg[19]_i_1_n_7 ;
  wire \derivative_reg[19]_i_22_n_0 ;
  wire \derivative_reg[19]_i_22_n_1 ;
  wire \derivative_reg[19]_i_22_n_2 ;
  wire \derivative_reg[19]_i_22_n_3 ;
  wire \derivative_reg[19]_i_22_n_4 ;
  wire \derivative_reg[19]_i_22_n_5 ;
  wire \derivative_reg[19]_i_22_n_6 ;
  wire \derivative_reg[19]_i_22_n_7 ;
  wire \derivative_reg[19]_i_27_n_0 ;
  wire \derivative_reg[19]_i_27_n_1 ;
  wire \derivative_reg[19]_i_27_n_2 ;
  wire \derivative_reg[19]_i_27_n_3 ;
  wire \derivative_reg[19]_i_27_n_4 ;
  wire \derivative_reg[19]_i_27_n_5 ;
  wire \derivative_reg[19]_i_27_n_6 ;
  wire \derivative_reg[19]_i_27_n_7 ;
  wire \derivative_reg[19]_i_32_n_0 ;
  wire \derivative_reg[19]_i_32_n_1 ;
  wire \derivative_reg[19]_i_32_n_2 ;
  wire \derivative_reg[19]_i_32_n_3 ;
  wire \derivative_reg[19]_i_32_n_4 ;
  wire \derivative_reg[19]_i_32_n_5 ;
  wire \derivative_reg[19]_i_32_n_6 ;
  wire \derivative_reg[19]_i_32_n_7 ;
  wire \derivative_reg[19]_i_37_n_0 ;
  wire \derivative_reg[19]_i_37_n_1 ;
  wire \derivative_reg[19]_i_37_n_2 ;
  wire \derivative_reg[19]_i_37_n_3 ;
  wire \derivative_reg[19]_i_37_n_4 ;
  wire \derivative_reg[19]_i_37_n_5 ;
  wire \derivative_reg[19]_i_37_n_6 ;
  wire \derivative_reg[19]_i_37_n_7 ;
  wire \derivative_reg[19]_i_42_n_0 ;
  wire \derivative_reg[19]_i_42_n_1 ;
  wire \derivative_reg[19]_i_42_n_2 ;
  wire \derivative_reg[19]_i_42_n_3 ;
  wire \derivative_reg[19]_i_42_n_4 ;
  wire \derivative_reg[19]_i_42_n_5 ;
  wire \derivative_reg[19]_i_42_n_6 ;
  wire \derivative_reg[19]_i_42_n_7 ;
  wire \derivative_reg[19]_i_47_n_0 ;
  wire \derivative_reg[19]_i_47_n_1 ;
  wire \derivative_reg[19]_i_47_n_2 ;
  wire \derivative_reg[19]_i_47_n_3 ;
  wire \derivative_reg[19]_i_47_n_4 ;
  wire \derivative_reg[19]_i_47_n_5 ;
  wire \derivative_reg[19]_i_47_n_6 ;
  wire \derivative_reg[19]_i_47_n_7 ;
  wire \derivative_reg[19]_i_52_n_0 ;
  wire \derivative_reg[19]_i_52_n_1 ;
  wire \derivative_reg[19]_i_52_n_2 ;
  wire \derivative_reg[19]_i_52_n_3 ;
  wire \derivative_reg[19]_i_52_n_4 ;
  wire \derivative_reg[19]_i_52_n_5 ;
  wire \derivative_reg[19]_i_52_n_6 ;
  wire \derivative_reg[19]_i_52_n_7 ;
  wire \derivative_reg[19]_i_57_n_0 ;
  wire \derivative_reg[19]_i_57_n_1 ;
  wire \derivative_reg[19]_i_57_n_2 ;
  wire \derivative_reg[19]_i_57_n_3 ;
  wire \derivative_reg[19]_i_57_n_4 ;
  wire \derivative_reg[19]_i_57_n_5 ;
  wire \derivative_reg[19]_i_57_n_6 ;
  wire \derivative_reg[19]_i_57_n_7 ;
  wire \derivative_reg[19]_i_62_n_0 ;
  wire \derivative_reg[19]_i_62_n_1 ;
  wire \derivative_reg[19]_i_62_n_2 ;
  wire \derivative_reg[19]_i_62_n_3 ;
  wire \derivative_reg[19]_i_62_n_4 ;
  wire \derivative_reg[19]_i_62_n_5 ;
  wire \derivative_reg[19]_i_62_n_6 ;
  wire \derivative_reg[19]_i_62_n_7 ;
  wire \derivative_reg[19]_i_67_n_0 ;
  wire \derivative_reg[19]_i_67_n_1 ;
  wire \derivative_reg[19]_i_67_n_2 ;
  wire \derivative_reg[19]_i_67_n_3 ;
  wire \derivative_reg[19]_i_67_n_4 ;
  wire \derivative_reg[19]_i_67_n_5 ;
  wire \derivative_reg[19]_i_67_n_6 ;
  wire \derivative_reg[19]_i_67_n_7 ;
  wire \derivative_reg[19]_i_6_n_3 ;
  wire \derivative_reg[19]_i_6_n_7 ;
  wire \derivative_reg[19]_i_72_n_0 ;
  wire \derivative_reg[19]_i_72_n_1 ;
  wire \derivative_reg[19]_i_72_n_2 ;
  wire \derivative_reg[19]_i_72_n_3 ;
  wire \derivative_reg[19]_i_72_n_4 ;
  wire \derivative_reg[19]_i_72_n_5 ;
  wire \derivative_reg[19]_i_72_n_6 ;
  wire \derivative_reg[19]_i_72_n_7 ;
  wire \derivative_reg[19]_i_77_n_0 ;
  wire \derivative_reg[19]_i_77_n_1 ;
  wire \derivative_reg[19]_i_77_n_2 ;
  wire \derivative_reg[19]_i_77_n_3 ;
  wire \derivative_reg[19]_i_77_n_4 ;
  wire \derivative_reg[19]_i_77_n_5 ;
  wire \derivative_reg[19]_i_77_n_6 ;
  wire \derivative_reg[19]_i_77_n_7 ;
  wire \derivative_reg[19]_i_7_n_3 ;
  wire \derivative_reg[19]_i_7_n_7 ;
  wire \derivative_reg[19]_i_82_n_0 ;
  wire \derivative_reg[19]_i_82_n_1 ;
  wire \derivative_reg[19]_i_82_n_2 ;
  wire \derivative_reg[19]_i_82_n_3 ;
  wire \derivative_reg[19]_i_82_n_4 ;
  wire \derivative_reg[19]_i_82_n_5 ;
  wire \derivative_reg[19]_i_82_n_6 ;
  wire \derivative_reg[19]_i_82_n_7 ;
  wire \derivative_reg[19]_i_87_n_0 ;
  wire \derivative_reg[19]_i_87_n_1 ;
  wire \derivative_reg[19]_i_87_n_2 ;
  wire \derivative_reg[19]_i_87_n_3 ;
  wire \derivative_reg[19]_i_87_n_4 ;
  wire \derivative_reg[19]_i_87_n_5 ;
  wire \derivative_reg[19]_i_87_n_6 ;
  wire \derivative_reg[19]_i_87_n_7 ;
  wire \derivative_reg[19]_i_8_n_3 ;
  wire \derivative_reg[19]_i_8_n_7 ;
  wire \derivative_reg[19]_i_92_n_0 ;
  wire \derivative_reg[19]_i_92_n_1 ;
  wire \derivative_reg[19]_i_92_n_2 ;
  wire \derivative_reg[19]_i_92_n_3 ;
  wire \derivative_reg[19]_i_92_n_4 ;
  wire \derivative_reg[19]_i_92_n_5 ;
  wire \derivative_reg[19]_i_92_n_6 ;
  wire \derivative_reg[19]_i_92_n_7 ;
  wire \derivative_reg[19]_i_97_n_0 ;
  wire \derivative_reg[19]_i_97_n_1 ;
  wire \derivative_reg[19]_i_97_n_2 ;
  wire \derivative_reg[19]_i_97_n_3 ;
  wire \derivative_reg[19]_i_97_n_4 ;
  wire \derivative_reg[19]_i_97_n_5 ;
  wire \derivative_reg[19]_i_97_n_6 ;
  wire \derivative_reg[19]_i_97_n_7 ;
  wire \derivative_reg[19]_i_9_n_3 ;
  wire \derivative_reg[19]_i_9_n_7 ;
  wire \derivative_reg[23]_i_102_n_0 ;
  wire \derivative_reg[23]_i_102_n_1 ;
  wire \derivative_reg[23]_i_102_n_2 ;
  wire \derivative_reg[23]_i_102_n_3 ;
  wire \derivative_reg[23]_i_102_n_4 ;
  wire \derivative_reg[23]_i_102_n_5 ;
  wire \derivative_reg[23]_i_102_n_6 ;
  wire \derivative_reg[23]_i_102_n_7 ;
  wire \derivative_reg[23]_i_107_n_0 ;
  wire \derivative_reg[23]_i_107_n_1 ;
  wire \derivative_reg[23]_i_107_n_2 ;
  wire \derivative_reg[23]_i_107_n_3 ;
  wire \derivative_reg[23]_i_107_n_4 ;
  wire \derivative_reg[23]_i_107_n_5 ;
  wire \derivative_reg[23]_i_107_n_6 ;
  wire \derivative_reg[23]_i_107_n_7 ;
  wire \derivative_reg[23]_i_10_n_0 ;
  wire \derivative_reg[23]_i_10_n_1 ;
  wire \derivative_reg[23]_i_10_n_2 ;
  wire \derivative_reg[23]_i_10_n_3 ;
  wire \derivative_reg[23]_i_10_n_4 ;
  wire \derivative_reg[23]_i_10_n_5 ;
  wire \derivative_reg[23]_i_10_n_6 ;
  wire \derivative_reg[23]_i_10_n_7 ;
  wire \derivative_reg[23]_i_112_n_0 ;
  wire \derivative_reg[23]_i_112_n_1 ;
  wire \derivative_reg[23]_i_112_n_2 ;
  wire \derivative_reg[23]_i_112_n_3 ;
  wire \derivative_reg[23]_i_112_n_4 ;
  wire \derivative_reg[23]_i_112_n_5 ;
  wire \derivative_reg[23]_i_112_n_6 ;
  wire \derivative_reg[23]_i_112_n_7 ;
  wire \derivative_reg[23]_i_117_n_0 ;
  wire \derivative_reg[23]_i_117_n_1 ;
  wire \derivative_reg[23]_i_117_n_2 ;
  wire \derivative_reg[23]_i_117_n_3 ;
  wire \derivative_reg[23]_i_117_n_4 ;
  wire \derivative_reg[23]_i_117_n_5 ;
  wire \derivative_reg[23]_i_117_n_6 ;
  wire \derivative_reg[23]_i_117_n_7 ;
  wire \derivative_reg[23]_i_122_n_0 ;
  wire \derivative_reg[23]_i_122_n_1 ;
  wire \derivative_reg[23]_i_122_n_2 ;
  wire \derivative_reg[23]_i_122_n_3 ;
  wire \derivative_reg[23]_i_122_n_4 ;
  wire \derivative_reg[23]_i_122_n_5 ;
  wire \derivative_reg[23]_i_122_n_6 ;
  wire \derivative_reg[23]_i_122_n_7 ;
  wire \derivative_reg[23]_i_127_n_0 ;
  wire \derivative_reg[23]_i_127_n_1 ;
  wire \derivative_reg[23]_i_127_n_2 ;
  wire \derivative_reg[23]_i_127_n_3 ;
  wire \derivative_reg[23]_i_127_n_4 ;
  wire \derivative_reg[23]_i_127_n_5 ;
  wire \derivative_reg[23]_i_127_n_6 ;
  wire \derivative_reg[23]_i_127_n_7 ;
  wire \derivative_reg[23]_i_132_n_0 ;
  wire \derivative_reg[23]_i_132_n_1 ;
  wire \derivative_reg[23]_i_132_n_2 ;
  wire \derivative_reg[23]_i_132_n_3 ;
  wire \derivative_reg[23]_i_132_n_4 ;
  wire \derivative_reg[23]_i_132_n_5 ;
  wire \derivative_reg[23]_i_132_n_6 ;
  wire \derivative_reg[23]_i_132_n_7 ;
  wire \derivative_reg[23]_i_137_n_0 ;
  wire \derivative_reg[23]_i_137_n_1 ;
  wire \derivative_reg[23]_i_137_n_2 ;
  wire \derivative_reg[23]_i_137_n_3 ;
  wire \derivative_reg[23]_i_137_n_4 ;
  wire \derivative_reg[23]_i_137_n_5 ;
  wire \derivative_reg[23]_i_137_n_6 ;
  wire \derivative_reg[23]_i_137_n_7 ;
  wire \derivative_reg[23]_i_13_n_0 ;
  wire \derivative_reg[23]_i_13_n_1 ;
  wire \derivative_reg[23]_i_13_n_2 ;
  wire \derivative_reg[23]_i_13_n_3 ;
  wire \derivative_reg[23]_i_13_n_4 ;
  wire \derivative_reg[23]_i_13_n_5 ;
  wire \derivative_reg[23]_i_13_n_6 ;
  wire \derivative_reg[23]_i_13_n_7 ;
  wire \derivative_reg[23]_i_142_n_0 ;
  wire \derivative_reg[23]_i_142_n_1 ;
  wire \derivative_reg[23]_i_142_n_2 ;
  wire \derivative_reg[23]_i_142_n_3 ;
  wire \derivative_reg[23]_i_142_n_4 ;
  wire \derivative_reg[23]_i_142_n_5 ;
  wire \derivative_reg[23]_i_142_n_6 ;
  wire \derivative_reg[23]_i_147_n_0 ;
  wire \derivative_reg[23]_i_147_n_1 ;
  wire \derivative_reg[23]_i_147_n_2 ;
  wire \derivative_reg[23]_i_147_n_3 ;
  wire \derivative_reg[23]_i_147_n_4 ;
  wire \derivative_reg[23]_i_147_n_5 ;
  wire \derivative_reg[23]_i_147_n_6 ;
  wire \derivative_reg[23]_i_152_n_0 ;
  wire \derivative_reg[23]_i_152_n_1 ;
  wire \derivative_reg[23]_i_152_n_2 ;
  wire \derivative_reg[23]_i_152_n_3 ;
  wire \derivative_reg[23]_i_152_n_4 ;
  wire \derivative_reg[23]_i_152_n_5 ;
  wire \derivative_reg[23]_i_152_n_6 ;
  wire \derivative_reg[23]_i_157_n_0 ;
  wire \derivative_reg[23]_i_157_n_1 ;
  wire \derivative_reg[23]_i_157_n_2 ;
  wire \derivative_reg[23]_i_157_n_3 ;
  wire \derivative_reg[23]_i_157_n_4 ;
  wire \derivative_reg[23]_i_157_n_5 ;
  wire \derivative_reg[23]_i_157_n_6 ;
  wire \derivative_reg[23]_i_16_n_0 ;
  wire \derivative_reg[23]_i_16_n_1 ;
  wire \derivative_reg[23]_i_16_n_2 ;
  wire \derivative_reg[23]_i_16_n_3 ;
  wire \derivative_reg[23]_i_16_n_4 ;
  wire \derivative_reg[23]_i_16_n_5 ;
  wire \derivative_reg[23]_i_16_n_6 ;
  wire \derivative_reg[23]_i_16_n_7 ;
  wire \derivative_reg[23]_i_178_n_0 ;
  wire \derivative_reg[23]_i_178_n_1 ;
  wire \derivative_reg[23]_i_178_n_2 ;
  wire \derivative_reg[23]_i_178_n_3 ;
  wire \derivative_reg[23]_i_178_n_4 ;
  wire \derivative_reg[23]_i_178_n_5 ;
  wire \derivative_reg[23]_i_178_n_6 ;
  wire \derivative_reg[23]_i_178_n_7 ;
  wire \derivative_reg[23]_i_19_n_0 ;
  wire \derivative_reg[23]_i_19_n_1 ;
  wire \derivative_reg[23]_i_19_n_2 ;
  wire \derivative_reg[23]_i_19_n_3 ;
  wire \derivative_reg[23]_i_19_n_4 ;
  wire \derivative_reg[23]_i_19_n_5 ;
  wire \derivative_reg[23]_i_19_n_6 ;
  wire \derivative_reg[23]_i_19_n_7 ;
  wire \derivative_reg[23]_i_1_n_0 ;
  wire \derivative_reg[23]_i_1_n_1 ;
  wire \derivative_reg[23]_i_1_n_2 ;
  wire \derivative_reg[23]_i_1_n_3 ;
  wire \derivative_reg[23]_i_1_n_4 ;
  wire \derivative_reg[23]_i_1_n_5 ;
  wire \derivative_reg[23]_i_1_n_6 ;
  wire \derivative_reg[23]_i_1_n_7 ;
  wire \derivative_reg[23]_i_22_n_0 ;
  wire \derivative_reg[23]_i_22_n_1 ;
  wire \derivative_reg[23]_i_22_n_2 ;
  wire \derivative_reg[23]_i_22_n_3 ;
  wire \derivative_reg[23]_i_22_n_4 ;
  wire \derivative_reg[23]_i_22_n_5 ;
  wire \derivative_reg[23]_i_22_n_6 ;
  wire \derivative_reg[23]_i_22_n_7 ;
  wire \derivative_reg[23]_i_27_n_0 ;
  wire \derivative_reg[23]_i_27_n_1 ;
  wire \derivative_reg[23]_i_27_n_2 ;
  wire \derivative_reg[23]_i_27_n_3 ;
  wire \derivative_reg[23]_i_27_n_4 ;
  wire \derivative_reg[23]_i_27_n_5 ;
  wire \derivative_reg[23]_i_27_n_6 ;
  wire \derivative_reg[23]_i_27_n_7 ;
  wire \derivative_reg[23]_i_32_n_0 ;
  wire \derivative_reg[23]_i_32_n_1 ;
  wire \derivative_reg[23]_i_32_n_2 ;
  wire \derivative_reg[23]_i_32_n_3 ;
  wire \derivative_reg[23]_i_32_n_4 ;
  wire \derivative_reg[23]_i_32_n_5 ;
  wire \derivative_reg[23]_i_32_n_6 ;
  wire \derivative_reg[23]_i_32_n_7 ;
  wire \derivative_reg[23]_i_37_n_0 ;
  wire \derivative_reg[23]_i_37_n_1 ;
  wire \derivative_reg[23]_i_37_n_2 ;
  wire \derivative_reg[23]_i_37_n_3 ;
  wire \derivative_reg[23]_i_37_n_4 ;
  wire \derivative_reg[23]_i_37_n_5 ;
  wire \derivative_reg[23]_i_37_n_6 ;
  wire \derivative_reg[23]_i_37_n_7 ;
  wire \derivative_reg[23]_i_42_n_0 ;
  wire \derivative_reg[23]_i_42_n_1 ;
  wire \derivative_reg[23]_i_42_n_2 ;
  wire \derivative_reg[23]_i_42_n_3 ;
  wire \derivative_reg[23]_i_42_n_4 ;
  wire \derivative_reg[23]_i_42_n_5 ;
  wire \derivative_reg[23]_i_42_n_6 ;
  wire \derivative_reg[23]_i_42_n_7 ;
  wire \derivative_reg[23]_i_47_n_0 ;
  wire \derivative_reg[23]_i_47_n_1 ;
  wire \derivative_reg[23]_i_47_n_2 ;
  wire \derivative_reg[23]_i_47_n_3 ;
  wire \derivative_reg[23]_i_47_n_4 ;
  wire \derivative_reg[23]_i_47_n_5 ;
  wire \derivative_reg[23]_i_47_n_6 ;
  wire \derivative_reg[23]_i_47_n_7 ;
  wire \derivative_reg[23]_i_52_n_0 ;
  wire \derivative_reg[23]_i_52_n_1 ;
  wire \derivative_reg[23]_i_52_n_2 ;
  wire \derivative_reg[23]_i_52_n_3 ;
  wire \derivative_reg[23]_i_52_n_4 ;
  wire \derivative_reg[23]_i_52_n_5 ;
  wire \derivative_reg[23]_i_52_n_6 ;
  wire \derivative_reg[23]_i_52_n_7 ;
  wire \derivative_reg[23]_i_57_n_0 ;
  wire \derivative_reg[23]_i_57_n_1 ;
  wire \derivative_reg[23]_i_57_n_2 ;
  wire \derivative_reg[23]_i_57_n_3 ;
  wire \derivative_reg[23]_i_57_n_4 ;
  wire \derivative_reg[23]_i_57_n_5 ;
  wire \derivative_reg[23]_i_57_n_6 ;
  wire \derivative_reg[23]_i_57_n_7 ;
  wire \derivative_reg[23]_i_62_n_0 ;
  wire \derivative_reg[23]_i_62_n_1 ;
  wire \derivative_reg[23]_i_62_n_2 ;
  wire \derivative_reg[23]_i_62_n_3 ;
  wire \derivative_reg[23]_i_62_n_4 ;
  wire \derivative_reg[23]_i_62_n_5 ;
  wire \derivative_reg[23]_i_62_n_6 ;
  wire \derivative_reg[23]_i_62_n_7 ;
  wire \derivative_reg[23]_i_67_n_0 ;
  wire \derivative_reg[23]_i_67_n_1 ;
  wire \derivative_reg[23]_i_67_n_2 ;
  wire \derivative_reg[23]_i_67_n_3 ;
  wire \derivative_reg[23]_i_67_n_4 ;
  wire \derivative_reg[23]_i_67_n_5 ;
  wire \derivative_reg[23]_i_67_n_6 ;
  wire \derivative_reg[23]_i_67_n_7 ;
  wire \derivative_reg[23]_i_6_n_3 ;
  wire \derivative_reg[23]_i_6_n_7 ;
  wire \derivative_reg[23]_i_72_n_0 ;
  wire \derivative_reg[23]_i_72_n_1 ;
  wire \derivative_reg[23]_i_72_n_2 ;
  wire \derivative_reg[23]_i_72_n_3 ;
  wire \derivative_reg[23]_i_72_n_4 ;
  wire \derivative_reg[23]_i_72_n_5 ;
  wire \derivative_reg[23]_i_72_n_6 ;
  wire \derivative_reg[23]_i_72_n_7 ;
  wire \derivative_reg[23]_i_77_n_0 ;
  wire \derivative_reg[23]_i_77_n_1 ;
  wire \derivative_reg[23]_i_77_n_2 ;
  wire \derivative_reg[23]_i_77_n_3 ;
  wire \derivative_reg[23]_i_77_n_4 ;
  wire \derivative_reg[23]_i_77_n_5 ;
  wire \derivative_reg[23]_i_77_n_6 ;
  wire \derivative_reg[23]_i_77_n_7 ;
  wire \derivative_reg[23]_i_7_n_3 ;
  wire \derivative_reg[23]_i_7_n_7 ;
  wire \derivative_reg[23]_i_82_n_0 ;
  wire \derivative_reg[23]_i_82_n_1 ;
  wire \derivative_reg[23]_i_82_n_2 ;
  wire \derivative_reg[23]_i_82_n_3 ;
  wire \derivative_reg[23]_i_82_n_4 ;
  wire \derivative_reg[23]_i_82_n_5 ;
  wire \derivative_reg[23]_i_82_n_6 ;
  wire \derivative_reg[23]_i_82_n_7 ;
  wire \derivative_reg[23]_i_87_n_0 ;
  wire \derivative_reg[23]_i_87_n_1 ;
  wire \derivative_reg[23]_i_87_n_2 ;
  wire \derivative_reg[23]_i_87_n_3 ;
  wire \derivative_reg[23]_i_87_n_4 ;
  wire \derivative_reg[23]_i_87_n_5 ;
  wire \derivative_reg[23]_i_87_n_6 ;
  wire \derivative_reg[23]_i_87_n_7 ;
  wire \derivative_reg[23]_i_8_n_3 ;
  wire \derivative_reg[23]_i_8_n_7 ;
  wire \derivative_reg[23]_i_92_n_0 ;
  wire \derivative_reg[23]_i_92_n_1 ;
  wire \derivative_reg[23]_i_92_n_2 ;
  wire \derivative_reg[23]_i_92_n_3 ;
  wire \derivative_reg[23]_i_92_n_4 ;
  wire \derivative_reg[23]_i_92_n_5 ;
  wire \derivative_reg[23]_i_92_n_6 ;
  wire \derivative_reg[23]_i_92_n_7 ;
  wire \derivative_reg[23]_i_97_n_0 ;
  wire \derivative_reg[23]_i_97_n_1 ;
  wire \derivative_reg[23]_i_97_n_2 ;
  wire \derivative_reg[23]_i_97_n_3 ;
  wire \derivative_reg[23]_i_97_n_4 ;
  wire \derivative_reg[23]_i_97_n_5 ;
  wire \derivative_reg[23]_i_97_n_6 ;
  wire \derivative_reg[23]_i_97_n_7 ;
  wire \derivative_reg[23]_i_9_n_3 ;
  wire \derivative_reg[23]_i_9_n_7 ;
  wire \derivative_reg[27]_i_102_n_0 ;
  wire \derivative_reg[27]_i_102_n_1 ;
  wire \derivative_reg[27]_i_102_n_2 ;
  wire \derivative_reg[27]_i_102_n_3 ;
  wire \derivative_reg[27]_i_102_n_4 ;
  wire \derivative_reg[27]_i_102_n_5 ;
  wire \derivative_reg[27]_i_102_n_6 ;
  wire \derivative_reg[27]_i_102_n_7 ;
  wire \derivative_reg[27]_i_107_n_0 ;
  wire \derivative_reg[27]_i_107_n_1 ;
  wire \derivative_reg[27]_i_107_n_2 ;
  wire \derivative_reg[27]_i_107_n_3 ;
  wire \derivative_reg[27]_i_107_n_4 ;
  wire \derivative_reg[27]_i_107_n_5 ;
  wire \derivative_reg[27]_i_107_n_6 ;
  wire \derivative_reg[27]_i_107_n_7 ;
  wire \derivative_reg[27]_i_10_n_0 ;
  wire \derivative_reg[27]_i_10_n_1 ;
  wire \derivative_reg[27]_i_10_n_2 ;
  wire \derivative_reg[27]_i_10_n_3 ;
  wire \derivative_reg[27]_i_10_n_4 ;
  wire \derivative_reg[27]_i_10_n_5 ;
  wire \derivative_reg[27]_i_10_n_6 ;
  wire \derivative_reg[27]_i_10_n_7 ;
  wire \derivative_reg[27]_i_112_n_0 ;
  wire \derivative_reg[27]_i_112_n_1 ;
  wire \derivative_reg[27]_i_112_n_2 ;
  wire \derivative_reg[27]_i_112_n_3 ;
  wire \derivative_reg[27]_i_112_n_4 ;
  wire \derivative_reg[27]_i_112_n_5 ;
  wire \derivative_reg[27]_i_112_n_6 ;
  wire \derivative_reg[27]_i_112_n_7 ;
  wire \derivative_reg[27]_i_117_n_0 ;
  wire \derivative_reg[27]_i_117_n_1 ;
  wire \derivative_reg[27]_i_117_n_2 ;
  wire \derivative_reg[27]_i_117_n_3 ;
  wire \derivative_reg[27]_i_117_n_4 ;
  wire \derivative_reg[27]_i_117_n_5 ;
  wire \derivative_reg[27]_i_117_n_6 ;
  wire \derivative_reg[27]_i_117_n_7 ;
  wire \derivative_reg[27]_i_122_n_0 ;
  wire \derivative_reg[27]_i_122_n_1 ;
  wire \derivative_reg[27]_i_122_n_2 ;
  wire \derivative_reg[27]_i_122_n_3 ;
  wire \derivative_reg[27]_i_122_n_4 ;
  wire \derivative_reg[27]_i_122_n_5 ;
  wire \derivative_reg[27]_i_122_n_6 ;
  wire \derivative_reg[27]_i_122_n_7 ;
  wire \derivative_reg[27]_i_127_n_0 ;
  wire \derivative_reg[27]_i_127_n_1 ;
  wire \derivative_reg[27]_i_127_n_2 ;
  wire \derivative_reg[27]_i_127_n_3 ;
  wire \derivative_reg[27]_i_127_n_4 ;
  wire \derivative_reg[27]_i_127_n_5 ;
  wire \derivative_reg[27]_i_127_n_6 ;
  wire \derivative_reg[27]_i_127_n_7 ;
  wire \derivative_reg[27]_i_132_n_0 ;
  wire \derivative_reg[27]_i_132_n_1 ;
  wire \derivative_reg[27]_i_132_n_2 ;
  wire \derivative_reg[27]_i_132_n_3 ;
  wire \derivative_reg[27]_i_132_n_4 ;
  wire \derivative_reg[27]_i_132_n_5 ;
  wire \derivative_reg[27]_i_132_n_6 ;
  wire \derivative_reg[27]_i_132_n_7 ;
  wire \derivative_reg[27]_i_137_n_0 ;
  wire \derivative_reg[27]_i_137_n_1 ;
  wire \derivative_reg[27]_i_137_n_2 ;
  wire \derivative_reg[27]_i_137_n_3 ;
  wire \derivative_reg[27]_i_137_n_4 ;
  wire \derivative_reg[27]_i_137_n_5 ;
  wire \derivative_reg[27]_i_137_n_6 ;
  wire \derivative_reg[27]_i_137_n_7 ;
  wire \derivative_reg[27]_i_13_n_0 ;
  wire \derivative_reg[27]_i_13_n_1 ;
  wire \derivative_reg[27]_i_13_n_2 ;
  wire \derivative_reg[27]_i_13_n_3 ;
  wire \derivative_reg[27]_i_13_n_4 ;
  wire \derivative_reg[27]_i_13_n_5 ;
  wire \derivative_reg[27]_i_13_n_6 ;
  wire \derivative_reg[27]_i_13_n_7 ;
  wire \derivative_reg[27]_i_142_n_0 ;
  wire \derivative_reg[27]_i_142_n_1 ;
  wire \derivative_reg[27]_i_142_n_2 ;
  wire \derivative_reg[27]_i_142_n_3 ;
  wire \derivative_reg[27]_i_142_n_4 ;
  wire \derivative_reg[27]_i_142_n_5 ;
  wire \derivative_reg[27]_i_142_n_6 ;
  wire \derivative_reg[27]_i_147_n_0 ;
  wire \derivative_reg[27]_i_147_n_1 ;
  wire \derivative_reg[27]_i_147_n_2 ;
  wire \derivative_reg[27]_i_147_n_3 ;
  wire \derivative_reg[27]_i_147_n_4 ;
  wire \derivative_reg[27]_i_147_n_5 ;
  wire \derivative_reg[27]_i_147_n_6 ;
  wire \derivative_reg[27]_i_152_n_0 ;
  wire \derivative_reg[27]_i_152_n_1 ;
  wire \derivative_reg[27]_i_152_n_2 ;
  wire \derivative_reg[27]_i_152_n_3 ;
  wire \derivative_reg[27]_i_152_n_4 ;
  wire \derivative_reg[27]_i_152_n_5 ;
  wire \derivative_reg[27]_i_152_n_6 ;
  wire \derivative_reg[27]_i_157_n_0 ;
  wire \derivative_reg[27]_i_157_n_1 ;
  wire \derivative_reg[27]_i_157_n_2 ;
  wire \derivative_reg[27]_i_157_n_3 ;
  wire \derivative_reg[27]_i_157_n_4 ;
  wire \derivative_reg[27]_i_157_n_5 ;
  wire \derivative_reg[27]_i_157_n_6 ;
  wire \derivative_reg[27]_i_16_n_0 ;
  wire \derivative_reg[27]_i_16_n_1 ;
  wire \derivative_reg[27]_i_16_n_2 ;
  wire \derivative_reg[27]_i_16_n_3 ;
  wire \derivative_reg[27]_i_16_n_4 ;
  wire \derivative_reg[27]_i_16_n_5 ;
  wire \derivative_reg[27]_i_16_n_6 ;
  wire \derivative_reg[27]_i_16_n_7 ;
  wire \derivative_reg[27]_i_178_n_0 ;
  wire \derivative_reg[27]_i_178_n_1 ;
  wire \derivative_reg[27]_i_178_n_2 ;
  wire \derivative_reg[27]_i_178_n_3 ;
  wire \derivative_reg[27]_i_178_n_4 ;
  wire \derivative_reg[27]_i_178_n_5 ;
  wire \derivative_reg[27]_i_178_n_6 ;
  wire \derivative_reg[27]_i_178_n_7 ;
  wire \derivative_reg[27]_i_19_n_0 ;
  wire \derivative_reg[27]_i_19_n_1 ;
  wire \derivative_reg[27]_i_19_n_2 ;
  wire \derivative_reg[27]_i_19_n_3 ;
  wire \derivative_reg[27]_i_19_n_4 ;
  wire \derivative_reg[27]_i_19_n_5 ;
  wire \derivative_reg[27]_i_19_n_6 ;
  wire \derivative_reg[27]_i_19_n_7 ;
  wire \derivative_reg[27]_i_1_n_0 ;
  wire \derivative_reg[27]_i_1_n_1 ;
  wire \derivative_reg[27]_i_1_n_2 ;
  wire \derivative_reg[27]_i_1_n_3 ;
  wire \derivative_reg[27]_i_1_n_4 ;
  wire \derivative_reg[27]_i_1_n_5 ;
  wire \derivative_reg[27]_i_1_n_6 ;
  wire \derivative_reg[27]_i_1_n_7 ;
  wire \derivative_reg[27]_i_22_n_0 ;
  wire \derivative_reg[27]_i_22_n_1 ;
  wire \derivative_reg[27]_i_22_n_2 ;
  wire \derivative_reg[27]_i_22_n_3 ;
  wire \derivative_reg[27]_i_22_n_4 ;
  wire \derivative_reg[27]_i_22_n_5 ;
  wire \derivative_reg[27]_i_22_n_6 ;
  wire \derivative_reg[27]_i_22_n_7 ;
  wire \derivative_reg[27]_i_27_n_0 ;
  wire \derivative_reg[27]_i_27_n_1 ;
  wire \derivative_reg[27]_i_27_n_2 ;
  wire \derivative_reg[27]_i_27_n_3 ;
  wire \derivative_reg[27]_i_27_n_4 ;
  wire \derivative_reg[27]_i_27_n_5 ;
  wire \derivative_reg[27]_i_27_n_6 ;
  wire \derivative_reg[27]_i_27_n_7 ;
  wire \derivative_reg[27]_i_32_n_0 ;
  wire \derivative_reg[27]_i_32_n_1 ;
  wire \derivative_reg[27]_i_32_n_2 ;
  wire \derivative_reg[27]_i_32_n_3 ;
  wire \derivative_reg[27]_i_32_n_4 ;
  wire \derivative_reg[27]_i_32_n_5 ;
  wire \derivative_reg[27]_i_32_n_6 ;
  wire \derivative_reg[27]_i_32_n_7 ;
  wire \derivative_reg[27]_i_37_n_0 ;
  wire \derivative_reg[27]_i_37_n_1 ;
  wire \derivative_reg[27]_i_37_n_2 ;
  wire \derivative_reg[27]_i_37_n_3 ;
  wire \derivative_reg[27]_i_37_n_4 ;
  wire \derivative_reg[27]_i_37_n_5 ;
  wire \derivative_reg[27]_i_37_n_6 ;
  wire \derivative_reg[27]_i_37_n_7 ;
  wire \derivative_reg[27]_i_42_n_0 ;
  wire \derivative_reg[27]_i_42_n_1 ;
  wire \derivative_reg[27]_i_42_n_2 ;
  wire \derivative_reg[27]_i_42_n_3 ;
  wire \derivative_reg[27]_i_42_n_4 ;
  wire \derivative_reg[27]_i_42_n_5 ;
  wire \derivative_reg[27]_i_42_n_6 ;
  wire \derivative_reg[27]_i_42_n_7 ;
  wire \derivative_reg[27]_i_47_n_0 ;
  wire \derivative_reg[27]_i_47_n_1 ;
  wire \derivative_reg[27]_i_47_n_2 ;
  wire \derivative_reg[27]_i_47_n_3 ;
  wire \derivative_reg[27]_i_47_n_4 ;
  wire \derivative_reg[27]_i_47_n_5 ;
  wire \derivative_reg[27]_i_47_n_6 ;
  wire \derivative_reg[27]_i_47_n_7 ;
  wire \derivative_reg[27]_i_52_n_0 ;
  wire \derivative_reg[27]_i_52_n_1 ;
  wire \derivative_reg[27]_i_52_n_2 ;
  wire \derivative_reg[27]_i_52_n_3 ;
  wire \derivative_reg[27]_i_52_n_4 ;
  wire \derivative_reg[27]_i_52_n_5 ;
  wire \derivative_reg[27]_i_52_n_6 ;
  wire \derivative_reg[27]_i_52_n_7 ;
  wire \derivative_reg[27]_i_57_n_0 ;
  wire \derivative_reg[27]_i_57_n_1 ;
  wire \derivative_reg[27]_i_57_n_2 ;
  wire \derivative_reg[27]_i_57_n_3 ;
  wire \derivative_reg[27]_i_57_n_4 ;
  wire \derivative_reg[27]_i_57_n_5 ;
  wire \derivative_reg[27]_i_57_n_6 ;
  wire \derivative_reg[27]_i_57_n_7 ;
  wire \derivative_reg[27]_i_62_n_0 ;
  wire \derivative_reg[27]_i_62_n_1 ;
  wire \derivative_reg[27]_i_62_n_2 ;
  wire \derivative_reg[27]_i_62_n_3 ;
  wire \derivative_reg[27]_i_62_n_4 ;
  wire \derivative_reg[27]_i_62_n_5 ;
  wire \derivative_reg[27]_i_62_n_6 ;
  wire \derivative_reg[27]_i_62_n_7 ;
  wire \derivative_reg[27]_i_67_n_0 ;
  wire \derivative_reg[27]_i_67_n_1 ;
  wire \derivative_reg[27]_i_67_n_2 ;
  wire \derivative_reg[27]_i_67_n_3 ;
  wire \derivative_reg[27]_i_67_n_4 ;
  wire \derivative_reg[27]_i_67_n_5 ;
  wire \derivative_reg[27]_i_67_n_6 ;
  wire \derivative_reg[27]_i_67_n_7 ;
  wire \derivative_reg[27]_i_6_n_3 ;
  wire \derivative_reg[27]_i_6_n_7 ;
  wire \derivative_reg[27]_i_72_n_0 ;
  wire \derivative_reg[27]_i_72_n_1 ;
  wire \derivative_reg[27]_i_72_n_2 ;
  wire \derivative_reg[27]_i_72_n_3 ;
  wire \derivative_reg[27]_i_72_n_4 ;
  wire \derivative_reg[27]_i_72_n_5 ;
  wire \derivative_reg[27]_i_72_n_6 ;
  wire \derivative_reg[27]_i_72_n_7 ;
  wire \derivative_reg[27]_i_77_n_0 ;
  wire \derivative_reg[27]_i_77_n_1 ;
  wire \derivative_reg[27]_i_77_n_2 ;
  wire \derivative_reg[27]_i_77_n_3 ;
  wire \derivative_reg[27]_i_77_n_4 ;
  wire \derivative_reg[27]_i_77_n_5 ;
  wire \derivative_reg[27]_i_77_n_6 ;
  wire \derivative_reg[27]_i_77_n_7 ;
  wire \derivative_reg[27]_i_7_n_3 ;
  wire \derivative_reg[27]_i_7_n_7 ;
  wire \derivative_reg[27]_i_82_n_0 ;
  wire \derivative_reg[27]_i_82_n_1 ;
  wire \derivative_reg[27]_i_82_n_2 ;
  wire \derivative_reg[27]_i_82_n_3 ;
  wire \derivative_reg[27]_i_82_n_4 ;
  wire \derivative_reg[27]_i_82_n_5 ;
  wire \derivative_reg[27]_i_82_n_6 ;
  wire \derivative_reg[27]_i_82_n_7 ;
  wire \derivative_reg[27]_i_87_n_0 ;
  wire \derivative_reg[27]_i_87_n_1 ;
  wire \derivative_reg[27]_i_87_n_2 ;
  wire \derivative_reg[27]_i_87_n_3 ;
  wire \derivative_reg[27]_i_87_n_4 ;
  wire \derivative_reg[27]_i_87_n_5 ;
  wire \derivative_reg[27]_i_87_n_6 ;
  wire \derivative_reg[27]_i_87_n_7 ;
  wire \derivative_reg[27]_i_8_n_3 ;
  wire \derivative_reg[27]_i_8_n_7 ;
  wire \derivative_reg[27]_i_92_n_0 ;
  wire \derivative_reg[27]_i_92_n_1 ;
  wire \derivative_reg[27]_i_92_n_2 ;
  wire \derivative_reg[27]_i_92_n_3 ;
  wire \derivative_reg[27]_i_92_n_4 ;
  wire \derivative_reg[27]_i_92_n_5 ;
  wire \derivative_reg[27]_i_92_n_6 ;
  wire \derivative_reg[27]_i_92_n_7 ;
  wire \derivative_reg[27]_i_97_n_0 ;
  wire \derivative_reg[27]_i_97_n_1 ;
  wire \derivative_reg[27]_i_97_n_2 ;
  wire \derivative_reg[27]_i_97_n_3 ;
  wire \derivative_reg[27]_i_97_n_4 ;
  wire \derivative_reg[27]_i_97_n_5 ;
  wire \derivative_reg[27]_i_97_n_6 ;
  wire \derivative_reg[27]_i_97_n_7 ;
  wire \derivative_reg[27]_i_9_n_3 ;
  wire \derivative_reg[27]_i_9_n_7 ;
  wire \derivative_reg[31]_i_101_n_0 ;
  wire \derivative_reg[31]_i_101_n_1 ;
  wire \derivative_reg[31]_i_101_n_2 ;
  wire \derivative_reg[31]_i_101_n_3 ;
  wire \derivative_reg[31]_i_101_n_4 ;
  wire \derivative_reg[31]_i_101_n_5 ;
  wire \derivative_reg[31]_i_101_n_6 ;
  wire \derivative_reg[31]_i_101_n_7 ;
  wire \derivative_reg[31]_i_106_n_0 ;
  wire \derivative_reg[31]_i_106_n_1 ;
  wire \derivative_reg[31]_i_106_n_2 ;
  wire \derivative_reg[31]_i_106_n_3 ;
  wire \derivative_reg[31]_i_106_n_4 ;
  wire \derivative_reg[31]_i_106_n_5 ;
  wire \derivative_reg[31]_i_106_n_6 ;
  wire \derivative_reg[31]_i_106_n_7 ;
  wire \derivative_reg[31]_i_115_n_0 ;
  wire \derivative_reg[31]_i_115_n_1 ;
  wire \derivative_reg[31]_i_115_n_2 ;
  wire \derivative_reg[31]_i_115_n_3 ;
  wire \derivative_reg[31]_i_115_n_4 ;
  wire \derivative_reg[31]_i_115_n_5 ;
  wire \derivative_reg[31]_i_115_n_6 ;
  wire \derivative_reg[31]_i_115_n_7 ;
  wire \derivative_reg[31]_i_120_n_0 ;
  wire \derivative_reg[31]_i_120_n_1 ;
  wire \derivative_reg[31]_i_120_n_2 ;
  wire \derivative_reg[31]_i_120_n_3 ;
  wire \derivative_reg[31]_i_120_n_4 ;
  wire \derivative_reg[31]_i_120_n_5 ;
  wire \derivative_reg[31]_i_120_n_6 ;
  wire \derivative_reg[31]_i_120_n_7 ;
  wire \derivative_reg[31]_i_125_n_0 ;
  wire \derivative_reg[31]_i_125_n_1 ;
  wire \derivative_reg[31]_i_125_n_2 ;
  wire \derivative_reg[31]_i_125_n_3 ;
  wire \derivative_reg[31]_i_125_n_4 ;
  wire \derivative_reg[31]_i_125_n_5 ;
  wire \derivative_reg[31]_i_125_n_6 ;
  wire \derivative_reg[31]_i_125_n_7 ;
  wire \derivative_reg[31]_i_134_n_0 ;
  wire \derivative_reg[31]_i_134_n_1 ;
  wire \derivative_reg[31]_i_134_n_2 ;
  wire \derivative_reg[31]_i_134_n_3 ;
  wire \derivative_reg[31]_i_134_n_4 ;
  wire \derivative_reg[31]_i_134_n_5 ;
  wire \derivative_reg[31]_i_134_n_6 ;
  wire \derivative_reg[31]_i_134_n_7 ;
  wire \derivative_reg[31]_i_139_n_0 ;
  wire \derivative_reg[31]_i_139_n_1 ;
  wire \derivative_reg[31]_i_139_n_2 ;
  wire \derivative_reg[31]_i_139_n_3 ;
  wire \derivative_reg[31]_i_139_n_4 ;
  wire \derivative_reg[31]_i_139_n_5 ;
  wire \derivative_reg[31]_i_139_n_6 ;
  wire \derivative_reg[31]_i_139_n_7 ;
  wire \derivative_reg[31]_i_148_n_0 ;
  wire \derivative_reg[31]_i_148_n_1 ;
  wire \derivative_reg[31]_i_148_n_2 ;
  wire \derivative_reg[31]_i_148_n_3 ;
  wire \derivative_reg[31]_i_148_n_4 ;
  wire \derivative_reg[31]_i_148_n_5 ;
  wire \derivative_reg[31]_i_148_n_6 ;
  wire \derivative_reg[31]_i_148_n_7 ;
  wire \derivative_reg[31]_i_153_n_0 ;
  wire \derivative_reg[31]_i_153_n_1 ;
  wire \derivative_reg[31]_i_153_n_2 ;
  wire \derivative_reg[31]_i_153_n_3 ;
  wire \derivative_reg[31]_i_153_n_4 ;
  wire \derivative_reg[31]_i_153_n_5 ;
  wire \derivative_reg[31]_i_153_n_6 ;
  wire \derivative_reg[31]_i_153_n_7 ;
  wire \derivative_reg[31]_i_158_n_0 ;
  wire \derivative_reg[31]_i_158_n_1 ;
  wire \derivative_reg[31]_i_158_n_2 ;
  wire \derivative_reg[31]_i_158_n_3 ;
  wire \derivative_reg[31]_i_158_n_4 ;
  wire \derivative_reg[31]_i_158_n_5 ;
  wire \derivative_reg[31]_i_158_n_6 ;
  wire \derivative_reg[31]_i_158_n_7 ;
  wire \derivative_reg[31]_i_167_n_0 ;
  wire \derivative_reg[31]_i_167_n_1 ;
  wire \derivative_reg[31]_i_167_n_2 ;
  wire \derivative_reg[31]_i_167_n_3 ;
  wire \derivative_reg[31]_i_167_n_4 ;
  wire \derivative_reg[31]_i_167_n_5 ;
  wire \derivative_reg[31]_i_167_n_6 ;
  wire \derivative_reg[31]_i_167_n_7 ;
  wire \derivative_reg[31]_i_172_n_0 ;
  wire \derivative_reg[31]_i_172_n_1 ;
  wire \derivative_reg[31]_i_172_n_2 ;
  wire \derivative_reg[31]_i_172_n_3 ;
  wire \derivative_reg[31]_i_172_n_4 ;
  wire \derivative_reg[31]_i_172_n_5 ;
  wire \derivative_reg[31]_i_172_n_6 ;
  wire \derivative_reg[31]_i_172_n_7 ;
  wire \derivative_reg[31]_i_181_n_0 ;
  wire \derivative_reg[31]_i_181_n_1 ;
  wire \derivative_reg[31]_i_181_n_2 ;
  wire \derivative_reg[31]_i_181_n_3 ;
  wire \derivative_reg[31]_i_181_n_4 ;
  wire \derivative_reg[31]_i_181_n_5 ;
  wire \derivative_reg[31]_i_181_n_6 ;
  wire \derivative_reg[31]_i_181_n_7 ;
  wire \derivative_reg[31]_i_186_n_0 ;
  wire \derivative_reg[31]_i_186_n_1 ;
  wire \derivative_reg[31]_i_186_n_2 ;
  wire \derivative_reg[31]_i_186_n_3 ;
  wire \derivative_reg[31]_i_186_n_4 ;
  wire \derivative_reg[31]_i_186_n_5 ;
  wire \derivative_reg[31]_i_186_n_6 ;
  wire \derivative_reg[31]_i_186_n_7 ;
  wire \derivative_reg[31]_i_191_n_0 ;
  wire \derivative_reg[31]_i_191_n_1 ;
  wire \derivative_reg[31]_i_191_n_2 ;
  wire \derivative_reg[31]_i_191_n_3 ;
  wire \derivative_reg[31]_i_191_n_4 ;
  wire \derivative_reg[31]_i_191_n_5 ;
  wire \derivative_reg[31]_i_191_n_6 ;
  wire \derivative_reg[31]_i_191_n_7 ;
  wire \derivative_reg[31]_i_200_n_0 ;
  wire \derivative_reg[31]_i_200_n_1 ;
  wire \derivative_reg[31]_i_200_n_2 ;
  wire \derivative_reg[31]_i_200_n_3 ;
  wire \derivative_reg[31]_i_200_n_4 ;
  wire \derivative_reg[31]_i_200_n_5 ;
  wire \derivative_reg[31]_i_200_n_6 ;
  wire \derivative_reg[31]_i_200_n_7 ;
  wire \derivative_reg[31]_i_205_n_0 ;
  wire \derivative_reg[31]_i_205_n_1 ;
  wire \derivative_reg[31]_i_205_n_2 ;
  wire \derivative_reg[31]_i_205_n_3 ;
  wire \derivative_reg[31]_i_205_n_4 ;
  wire \derivative_reg[31]_i_205_n_5 ;
  wire \derivative_reg[31]_i_205_n_6 ;
  wire \derivative_reg[31]_i_205_n_7 ;
  wire \derivative_reg[31]_i_214_n_0 ;
  wire \derivative_reg[31]_i_214_n_1 ;
  wire \derivative_reg[31]_i_214_n_2 ;
  wire \derivative_reg[31]_i_214_n_3 ;
  wire \derivative_reg[31]_i_214_n_4 ;
  wire \derivative_reg[31]_i_214_n_5 ;
  wire \derivative_reg[31]_i_214_n_6 ;
  wire \derivative_reg[31]_i_214_n_7 ;
  wire \derivative_reg[31]_i_219_n_0 ;
  wire \derivative_reg[31]_i_219_n_1 ;
  wire \derivative_reg[31]_i_219_n_2 ;
  wire \derivative_reg[31]_i_219_n_3 ;
  wire \derivative_reg[31]_i_219_n_4 ;
  wire \derivative_reg[31]_i_219_n_5 ;
  wire \derivative_reg[31]_i_219_n_6 ;
  wire \derivative_reg[31]_i_219_n_7 ;
  wire \derivative_reg[31]_i_224_n_0 ;
  wire \derivative_reg[31]_i_224_n_1 ;
  wire \derivative_reg[31]_i_224_n_2 ;
  wire \derivative_reg[31]_i_224_n_3 ;
  wire \derivative_reg[31]_i_224_n_4 ;
  wire \derivative_reg[31]_i_224_n_5 ;
  wire \derivative_reg[31]_i_224_n_6 ;
  wire \derivative_reg[31]_i_224_n_7 ;
  wire \derivative_reg[31]_i_22_n_3 ;
  wire \derivative_reg[31]_i_22_n_7 ;
  wire \derivative_reg[31]_i_233_n_0 ;
  wire \derivative_reg[31]_i_233_n_1 ;
  wire \derivative_reg[31]_i_233_n_2 ;
  wire \derivative_reg[31]_i_233_n_3 ;
  wire \derivative_reg[31]_i_233_n_4 ;
  wire \derivative_reg[31]_i_233_n_5 ;
  wire \derivative_reg[31]_i_233_n_6 ;
  wire \derivative_reg[31]_i_233_n_7 ;
  wire \derivative_reg[31]_i_238_n_0 ;
  wire \derivative_reg[31]_i_238_n_1 ;
  wire \derivative_reg[31]_i_238_n_2 ;
  wire \derivative_reg[31]_i_238_n_3 ;
  wire \derivative_reg[31]_i_238_n_4 ;
  wire \derivative_reg[31]_i_238_n_5 ;
  wire \derivative_reg[31]_i_238_n_6 ;
  wire \derivative_reg[31]_i_23_n_3 ;
  wire \derivative_reg[31]_i_23_n_7 ;
  wire \derivative_reg[31]_i_247_n_0 ;
  wire \derivative_reg[31]_i_247_n_1 ;
  wire \derivative_reg[31]_i_247_n_2 ;
  wire \derivative_reg[31]_i_247_n_3 ;
  wire \derivative_reg[31]_i_247_n_4 ;
  wire \derivative_reg[31]_i_247_n_5 ;
  wire \derivative_reg[31]_i_247_n_6 ;
  wire \derivative_reg[31]_i_24_n_3 ;
  wire \derivative_reg[31]_i_24_n_7 ;
  wire \derivative_reg[31]_i_252_n_0 ;
  wire \derivative_reg[31]_i_252_n_1 ;
  wire \derivative_reg[31]_i_252_n_2 ;
  wire \derivative_reg[31]_i_252_n_3 ;
  wire \derivative_reg[31]_i_252_n_4 ;
  wire \derivative_reg[31]_i_252_n_5 ;
  wire \derivative_reg[31]_i_252_n_6 ;
  wire \derivative_reg[31]_i_25_n_0 ;
  wire \derivative_reg[31]_i_25_n_1 ;
  wire \derivative_reg[31]_i_25_n_2 ;
  wire \derivative_reg[31]_i_25_n_3 ;
  wire \derivative_reg[31]_i_25_n_4 ;
  wire \derivative_reg[31]_i_25_n_5 ;
  wire \derivative_reg[31]_i_25_n_6 ;
  wire \derivative_reg[31]_i_25_n_7 ;
  wire \derivative_reg[31]_i_265_n_0 ;
  wire \derivative_reg[31]_i_265_n_1 ;
  wire \derivative_reg[31]_i_265_n_2 ;
  wire \derivative_reg[31]_i_265_n_3 ;
  wire \derivative_reg[31]_i_265_n_4 ;
  wire \derivative_reg[31]_i_265_n_5 ;
  wire \derivative_reg[31]_i_265_n_6 ;
  wire \derivative_reg[31]_i_265_n_7 ;
  wire \derivative_reg[31]_i_26_n_0 ;
  wire \derivative_reg[31]_i_26_n_1 ;
  wire \derivative_reg[31]_i_26_n_2 ;
  wire \derivative_reg[31]_i_26_n_3 ;
  wire \derivative_reg[31]_i_26_n_4 ;
  wire \derivative_reg[31]_i_26_n_5 ;
  wire \derivative_reg[31]_i_26_n_6 ;
  wire \derivative_reg[31]_i_26_n_7 ;
  wire \derivative_reg[31]_i_286_n_2 ;
  wire \derivative_reg[31]_i_286_n_3 ;
  wire \derivative_reg[31]_i_286_n_5 ;
  wire \derivative_reg[31]_i_286_n_6 ;
  wire \derivative_reg[31]_i_286_n_7 ;
  wire \derivative_reg[31]_i_294_n_0 ;
  wire \derivative_reg[31]_i_294_n_1 ;
  wire \derivative_reg[31]_i_294_n_2 ;
  wire \derivative_reg[31]_i_294_n_3 ;
  wire \derivative_reg[31]_i_294_n_4 ;
  wire \derivative_reg[31]_i_294_n_5 ;
  wire \derivative_reg[31]_i_294_n_6 ;
  wire \derivative_reg[31]_i_294_n_7 ;
  wire \derivative_reg[31]_i_29_n_0 ;
  wire \derivative_reg[31]_i_29_n_1 ;
  wire \derivative_reg[31]_i_29_n_2 ;
  wire \derivative_reg[31]_i_29_n_3 ;
  wire \derivative_reg[31]_i_29_n_4 ;
  wire \derivative_reg[31]_i_29_n_5 ;
  wire \derivative_reg[31]_i_29_n_6 ;
  wire \derivative_reg[31]_i_29_n_7 ;
  wire \derivative_reg[31]_i_2_n_1 ;
  wire \derivative_reg[31]_i_2_n_2 ;
  wire \derivative_reg[31]_i_2_n_3 ;
  wire \derivative_reg[31]_i_2_n_4 ;
  wire \derivative_reg[31]_i_2_n_5 ;
  wire \derivative_reg[31]_i_2_n_6 ;
  wire \derivative_reg[31]_i_2_n_7 ;
  wire \derivative_reg[31]_i_32_n_0 ;
  wire \derivative_reg[31]_i_32_n_1 ;
  wire \derivative_reg[31]_i_32_n_2 ;
  wire \derivative_reg[31]_i_32_n_3 ;
  wire \derivative_reg[31]_i_32_n_4 ;
  wire \derivative_reg[31]_i_32_n_5 ;
  wire \derivative_reg[31]_i_32_n_6 ;
  wire \derivative_reg[31]_i_32_n_7 ;
  wire \derivative_reg[31]_i_35_n_0 ;
  wire \derivative_reg[31]_i_35_n_1 ;
  wire \derivative_reg[31]_i_35_n_2 ;
  wire \derivative_reg[31]_i_35_n_3 ;
  wire \derivative_reg[31]_i_35_n_4 ;
  wire \derivative_reg[31]_i_35_n_5 ;
  wire \derivative_reg[31]_i_35_n_6 ;
  wire \derivative_reg[31]_i_35_n_7 ;
  wire \derivative_reg[31]_i_44_n_0 ;
  wire \derivative_reg[31]_i_44_n_1 ;
  wire \derivative_reg[31]_i_44_n_2 ;
  wire \derivative_reg[31]_i_44_n_3 ;
  wire \derivative_reg[31]_i_44_n_4 ;
  wire \derivative_reg[31]_i_44_n_5 ;
  wire \derivative_reg[31]_i_44_n_6 ;
  wire \derivative_reg[31]_i_44_n_7 ;
  wire \derivative_reg[31]_i_49_n_2 ;
  wire \derivative_reg[31]_i_49_n_3 ;
  wire \derivative_reg[31]_i_49_n_5 ;
  wire \derivative_reg[31]_i_49_n_6 ;
  wire \derivative_reg[31]_i_49_n_7 ;
  wire \derivative_reg[31]_i_50_n_0 ;
  wire \derivative_reg[31]_i_50_n_1 ;
  wire \derivative_reg[31]_i_50_n_2 ;
  wire \derivative_reg[31]_i_50_n_3 ;
  wire \derivative_reg[31]_i_50_n_4 ;
  wire \derivative_reg[31]_i_50_n_5 ;
  wire \derivative_reg[31]_i_50_n_6 ;
  wire \derivative_reg[31]_i_50_n_7 ;
  wire \derivative_reg[31]_i_55_n_0 ;
  wire \derivative_reg[31]_i_55_n_1 ;
  wire \derivative_reg[31]_i_55_n_2 ;
  wire \derivative_reg[31]_i_55_n_3 ;
  wire \derivative_reg[31]_i_55_n_4 ;
  wire \derivative_reg[31]_i_55_n_5 ;
  wire \derivative_reg[31]_i_55_n_6 ;
  wire \derivative_reg[31]_i_55_n_7 ;
  wire \derivative_reg[31]_i_60_n_0 ;
  wire \derivative_reg[31]_i_60_n_1 ;
  wire \derivative_reg[31]_i_60_n_2 ;
  wire \derivative_reg[31]_i_60_n_3 ;
  wire \derivative_reg[31]_i_60_n_4 ;
  wire \derivative_reg[31]_i_60_n_5 ;
  wire \derivative_reg[31]_i_60_n_6 ;
  wire \derivative_reg[31]_i_60_n_7 ;
  wire \derivative_reg[31]_i_69_n_0 ;
  wire \derivative_reg[31]_i_69_n_1 ;
  wire \derivative_reg[31]_i_69_n_2 ;
  wire \derivative_reg[31]_i_69_n_3 ;
  wire \derivative_reg[31]_i_69_n_4 ;
  wire \derivative_reg[31]_i_69_n_5 ;
  wire \derivative_reg[31]_i_69_n_6 ;
  wire \derivative_reg[31]_i_69_n_7 ;
  wire \derivative_reg[31]_i_70_n_0 ;
  wire \derivative_reg[31]_i_70_n_1 ;
  wire \derivative_reg[31]_i_70_n_2 ;
  wire \derivative_reg[31]_i_70_n_3 ;
  wire \derivative_reg[31]_i_70_n_4 ;
  wire \derivative_reg[31]_i_70_n_5 ;
  wire \derivative_reg[31]_i_70_n_6 ;
  wire \derivative_reg[31]_i_70_n_7 ;
  wire \derivative_reg[31]_i_82_n_0 ;
  wire \derivative_reg[31]_i_82_n_1 ;
  wire \derivative_reg[31]_i_82_n_2 ;
  wire \derivative_reg[31]_i_82_n_3 ;
  wire \derivative_reg[31]_i_82_n_4 ;
  wire \derivative_reg[31]_i_82_n_5 ;
  wire \derivative_reg[31]_i_82_n_6 ;
  wire \derivative_reg[31]_i_82_n_7 ;
  wire \derivative_reg[31]_i_87_n_0 ;
  wire \derivative_reg[31]_i_87_n_1 ;
  wire \derivative_reg[31]_i_87_n_2 ;
  wire \derivative_reg[31]_i_87_n_3 ;
  wire \derivative_reg[31]_i_87_n_4 ;
  wire \derivative_reg[31]_i_87_n_5 ;
  wire \derivative_reg[31]_i_87_n_6 ;
  wire \derivative_reg[31]_i_87_n_7 ;
  wire \derivative_reg[31]_i_92_n_0 ;
  wire \derivative_reg[31]_i_92_n_1 ;
  wire \derivative_reg[31]_i_92_n_2 ;
  wire \derivative_reg[31]_i_92_n_3 ;
  wire \derivative_reg[31]_i_92_n_4 ;
  wire \derivative_reg[31]_i_92_n_5 ;
  wire \derivative_reg[31]_i_92_n_6 ;
  wire \derivative_reg[31]_i_92_n_7 ;
  wire \derivative_reg[3]_i_102_n_0 ;
  wire \derivative_reg[3]_i_102_n_1 ;
  wire \derivative_reg[3]_i_102_n_2 ;
  wire \derivative_reg[3]_i_102_n_3 ;
  wire \derivative_reg[3]_i_102_n_4 ;
  wire \derivative_reg[3]_i_102_n_5 ;
  wire \derivative_reg[3]_i_102_n_6 ;
  wire \derivative_reg[3]_i_102_n_7 ;
  wire \derivative_reg[3]_i_107_n_0 ;
  wire \derivative_reg[3]_i_107_n_1 ;
  wire \derivative_reg[3]_i_107_n_2 ;
  wire \derivative_reg[3]_i_107_n_3 ;
  wire \derivative_reg[3]_i_107_n_4 ;
  wire \derivative_reg[3]_i_107_n_5 ;
  wire \derivative_reg[3]_i_107_n_6 ;
  wire \derivative_reg[3]_i_107_n_7 ;
  wire \derivative_reg[3]_i_112_n_0 ;
  wire \derivative_reg[3]_i_112_n_1 ;
  wire \derivative_reg[3]_i_112_n_2 ;
  wire \derivative_reg[3]_i_112_n_3 ;
  wire \derivative_reg[3]_i_112_n_4 ;
  wire \derivative_reg[3]_i_112_n_5 ;
  wire \derivative_reg[3]_i_112_n_6 ;
  wire \derivative_reg[3]_i_112_n_7 ;
  wire \derivative_reg[3]_i_117_n_0 ;
  wire \derivative_reg[3]_i_117_n_1 ;
  wire \derivative_reg[3]_i_117_n_2 ;
  wire \derivative_reg[3]_i_117_n_3 ;
  wire \derivative_reg[3]_i_11_n_0 ;
  wire \derivative_reg[3]_i_11_n_1 ;
  wire \derivative_reg[3]_i_11_n_2 ;
  wire \derivative_reg[3]_i_11_n_3 ;
  wire \derivative_reg[3]_i_11_n_4 ;
  wire \derivative_reg[3]_i_11_n_5 ;
  wire \derivative_reg[3]_i_11_n_6 ;
  wire \derivative_reg[3]_i_11_n_7 ;
  wire \derivative_reg[3]_i_122_n_0 ;
  wire \derivative_reg[3]_i_122_n_1 ;
  wire \derivative_reg[3]_i_122_n_2 ;
  wire \derivative_reg[3]_i_122_n_3 ;
  wire \derivative_reg[3]_i_122_n_4 ;
  wire \derivative_reg[3]_i_122_n_5 ;
  wire \derivative_reg[3]_i_122_n_6 ;
  wire \derivative_reg[3]_i_122_n_7 ;
  wire \derivative_reg[3]_i_127_n_0 ;
  wire \derivative_reg[3]_i_127_n_1 ;
  wire \derivative_reg[3]_i_127_n_2 ;
  wire \derivative_reg[3]_i_127_n_3 ;
  wire \derivative_reg[3]_i_127_n_4 ;
  wire \derivative_reg[3]_i_127_n_5 ;
  wire \derivative_reg[3]_i_127_n_6 ;
  wire \derivative_reg[3]_i_127_n_7 ;
  wire \derivative_reg[3]_i_132_n_0 ;
  wire \derivative_reg[3]_i_132_n_1 ;
  wire \derivative_reg[3]_i_132_n_2 ;
  wire \derivative_reg[3]_i_132_n_3 ;
  wire \derivative_reg[3]_i_132_n_4 ;
  wire \derivative_reg[3]_i_132_n_5 ;
  wire \derivative_reg[3]_i_132_n_6 ;
  wire \derivative_reg[3]_i_132_n_7 ;
  wire \derivative_reg[3]_i_137_n_0 ;
  wire \derivative_reg[3]_i_137_n_1 ;
  wire \derivative_reg[3]_i_137_n_2 ;
  wire \derivative_reg[3]_i_137_n_3 ;
  wire \derivative_reg[3]_i_142_n_0 ;
  wire \derivative_reg[3]_i_142_n_1 ;
  wire \derivative_reg[3]_i_142_n_2 ;
  wire \derivative_reg[3]_i_142_n_3 ;
  wire \derivative_reg[3]_i_142_n_4 ;
  wire \derivative_reg[3]_i_142_n_5 ;
  wire \derivative_reg[3]_i_142_n_6 ;
  wire \derivative_reg[3]_i_147_n_0 ;
  wire \derivative_reg[3]_i_147_n_1 ;
  wire \derivative_reg[3]_i_147_n_2 ;
  wire \derivative_reg[3]_i_147_n_3 ;
  wire \derivative_reg[3]_i_147_n_4 ;
  wire \derivative_reg[3]_i_147_n_5 ;
  wire \derivative_reg[3]_i_147_n_6 ;
  wire \derivative_reg[3]_i_14_n_0 ;
  wire \derivative_reg[3]_i_14_n_1 ;
  wire \derivative_reg[3]_i_14_n_2 ;
  wire \derivative_reg[3]_i_14_n_3 ;
  wire \derivative_reg[3]_i_14_n_4 ;
  wire \derivative_reg[3]_i_14_n_5 ;
  wire \derivative_reg[3]_i_14_n_6 ;
  wire \derivative_reg[3]_i_14_n_7 ;
  wire \derivative_reg[3]_i_152_n_0 ;
  wire \derivative_reg[3]_i_152_n_1 ;
  wire \derivative_reg[3]_i_152_n_2 ;
  wire \derivative_reg[3]_i_152_n_3 ;
  wire \derivative_reg[3]_i_152_n_4 ;
  wire \derivative_reg[3]_i_152_n_5 ;
  wire \derivative_reg[3]_i_152_n_6 ;
  wire \derivative_reg[3]_i_157_n_0 ;
  wire \derivative_reg[3]_i_157_n_1 ;
  wire \derivative_reg[3]_i_157_n_2 ;
  wire \derivative_reg[3]_i_157_n_3 ;
  wire \derivative_reg[3]_i_17_n_0 ;
  wire \derivative_reg[3]_i_17_n_1 ;
  wire \derivative_reg[3]_i_17_n_2 ;
  wire \derivative_reg[3]_i_17_n_3 ;
  wire \derivative_reg[3]_i_17_n_4 ;
  wire \derivative_reg[3]_i_17_n_5 ;
  wire \derivative_reg[3]_i_17_n_6 ;
  wire \derivative_reg[3]_i_17_n_7 ;
  wire \derivative_reg[3]_i_1_n_0 ;
  wire \derivative_reg[3]_i_1_n_1 ;
  wire \derivative_reg[3]_i_1_n_2 ;
  wire \derivative_reg[3]_i_1_n_3 ;
  wire \derivative_reg[3]_i_1_n_4 ;
  wire \derivative_reg[3]_i_1_n_5 ;
  wire \derivative_reg[3]_i_1_n_6 ;
  wire \derivative_reg[3]_i_1_n_7 ;
  wire \derivative_reg[3]_i_20_n_0 ;
  wire \derivative_reg[3]_i_20_n_1 ;
  wire \derivative_reg[3]_i_20_n_2 ;
  wire \derivative_reg[3]_i_20_n_3 ;
  wire \derivative_reg[3]_i_22_n_0 ;
  wire \derivative_reg[3]_i_22_n_1 ;
  wire \derivative_reg[3]_i_22_n_2 ;
  wire \derivative_reg[3]_i_22_n_3 ;
  wire \derivative_reg[3]_i_22_n_4 ;
  wire \derivative_reg[3]_i_22_n_5 ;
  wire \derivative_reg[3]_i_22_n_6 ;
  wire \derivative_reg[3]_i_22_n_7 ;
  wire \derivative_reg[3]_i_27_n_0 ;
  wire \derivative_reg[3]_i_27_n_1 ;
  wire \derivative_reg[3]_i_27_n_2 ;
  wire \derivative_reg[3]_i_27_n_3 ;
  wire \derivative_reg[3]_i_27_n_4 ;
  wire \derivative_reg[3]_i_27_n_5 ;
  wire \derivative_reg[3]_i_27_n_6 ;
  wire \derivative_reg[3]_i_27_n_7 ;
  wire \derivative_reg[3]_i_32_n_0 ;
  wire \derivative_reg[3]_i_32_n_1 ;
  wire \derivative_reg[3]_i_32_n_2 ;
  wire \derivative_reg[3]_i_32_n_3 ;
  wire \derivative_reg[3]_i_32_n_4 ;
  wire \derivative_reg[3]_i_32_n_5 ;
  wire \derivative_reg[3]_i_32_n_6 ;
  wire \derivative_reg[3]_i_32_n_7 ;
  wire \derivative_reg[3]_i_37_n_0 ;
  wire \derivative_reg[3]_i_37_n_1 ;
  wire \derivative_reg[3]_i_37_n_2 ;
  wire \derivative_reg[3]_i_37_n_3 ;
  wire \derivative_reg[3]_i_42_n_0 ;
  wire \derivative_reg[3]_i_42_n_1 ;
  wire \derivative_reg[3]_i_42_n_2 ;
  wire \derivative_reg[3]_i_42_n_3 ;
  wire \derivative_reg[3]_i_42_n_4 ;
  wire \derivative_reg[3]_i_42_n_5 ;
  wire \derivative_reg[3]_i_42_n_6 ;
  wire \derivative_reg[3]_i_42_n_7 ;
  wire \derivative_reg[3]_i_47_n_0 ;
  wire \derivative_reg[3]_i_47_n_1 ;
  wire \derivative_reg[3]_i_47_n_2 ;
  wire \derivative_reg[3]_i_47_n_3 ;
  wire \derivative_reg[3]_i_47_n_4 ;
  wire \derivative_reg[3]_i_47_n_5 ;
  wire \derivative_reg[3]_i_47_n_6 ;
  wire \derivative_reg[3]_i_47_n_7 ;
  wire \derivative_reg[3]_i_52_n_0 ;
  wire \derivative_reg[3]_i_52_n_1 ;
  wire \derivative_reg[3]_i_52_n_2 ;
  wire \derivative_reg[3]_i_52_n_3 ;
  wire \derivative_reg[3]_i_52_n_4 ;
  wire \derivative_reg[3]_i_52_n_5 ;
  wire \derivative_reg[3]_i_52_n_6 ;
  wire \derivative_reg[3]_i_52_n_7 ;
  wire \derivative_reg[3]_i_57_n_0 ;
  wire \derivative_reg[3]_i_57_n_1 ;
  wire \derivative_reg[3]_i_57_n_2 ;
  wire \derivative_reg[3]_i_57_n_3 ;
  wire \derivative_reg[3]_i_62_n_0 ;
  wire \derivative_reg[3]_i_62_n_1 ;
  wire \derivative_reg[3]_i_62_n_2 ;
  wire \derivative_reg[3]_i_62_n_3 ;
  wire \derivative_reg[3]_i_62_n_4 ;
  wire \derivative_reg[3]_i_62_n_5 ;
  wire \derivative_reg[3]_i_62_n_6 ;
  wire \derivative_reg[3]_i_62_n_7 ;
  wire \derivative_reg[3]_i_67_n_0 ;
  wire \derivative_reg[3]_i_67_n_1 ;
  wire \derivative_reg[3]_i_67_n_2 ;
  wire \derivative_reg[3]_i_67_n_3 ;
  wire \derivative_reg[3]_i_67_n_4 ;
  wire \derivative_reg[3]_i_67_n_5 ;
  wire \derivative_reg[3]_i_67_n_6 ;
  wire \derivative_reg[3]_i_67_n_7 ;
  wire \derivative_reg[3]_i_72_n_0 ;
  wire \derivative_reg[3]_i_72_n_1 ;
  wire \derivative_reg[3]_i_72_n_2 ;
  wire \derivative_reg[3]_i_72_n_3 ;
  wire \derivative_reg[3]_i_72_n_4 ;
  wire \derivative_reg[3]_i_72_n_5 ;
  wire \derivative_reg[3]_i_72_n_6 ;
  wire \derivative_reg[3]_i_72_n_7 ;
  wire \derivative_reg[3]_i_77_n_0 ;
  wire \derivative_reg[3]_i_77_n_1 ;
  wire \derivative_reg[3]_i_77_n_2 ;
  wire \derivative_reg[3]_i_77_n_3 ;
  wire \derivative_reg[3]_i_7_n_3 ;
  wire \derivative_reg[3]_i_7_n_7 ;
  wire \derivative_reg[3]_i_82_n_0 ;
  wire \derivative_reg[3]_i_82_n_1 ;
  wire \derivative_reg[3]_i_82_n_2 ;
  wire \derivative_reg[3]_i_82_n_3 ;
  wire \derivative_reg[3]_i_82_n_4 ;
  wire \derivative_reg[3]_i_82_n_5 ;
  wire \derivative_reg[3]_i_82_n_6 ;
  wire \derivative_reg[3]_i_82_n_7 ;
  wire \derivative_reg[3]_i_87_n_0 ;
  wire \derivative_reg[3]_i_87_n_1 ;
  wire \derivative_reg[3]_i_87_n_2 ;
  wire \derivative_reg[3]_i_87_n_3 ;
  wire \derivative_reg[3]_i_87_n_4 ;
  wire \derivative_reg[3]_i_87_n_5 ;
  wire \derivative_reg[3]_i_87_n_6 ;
  wire \derivative_reg[3]_i_87_n_7 ;
  wire \derivative_reg[3]_i_8_n_3 ;
  wire \derivative_reg[3]_i_8_n_7 ;
  wire \derivative_reg[3]_i_92_n_0 ;
  wire \derivative_reg[3]_i_92_n_1 ;
  wire \derivative_reg[3]_i_92_n_2 ;
  wire \derivative_reg[3]_i_92_n_3 ;
  wire \derivative_reg[3]_i_92_n_4 ;
  wire \derivative_reg[3]_i_92_n_5 ;
  wire \derivative_reg[3]_i_92_n_6 ;
  wire \derivative_reg[3]_i_92_n_7 ;
  wire \derivative_reg[3]_i_97_n_0 ;
  wire \derivative_reg[3]_i_97_n_1 ;
  wire \derivative_reg[3]_i_97_n_2 ;
  wire \derivative_reg[3]_i_97_n_3 ;
  wire \derivative_reg[3]_i_9_n_3 ;
  wire \derivative_reg[3]_i_9_n_7 ;
  wire \derivative_reg[7]_i_102_n_0 ;
  wire \derivative_reg[7]_i_102_n_1 ;
  wire \derivative_reg[7]_i_102_n_2 ;
  wire \derivative_reg[7]_i_102_n_3 ;
  wire \derivative_reg[7]_i_102_n_4 ;
  wire \derivative_reg[7]_i_102_n_5 ;
  wire \derivative_reg[7]_i_102_n_6 ;
  wire \derivative_reg[7]_i_102_n_7 ;
  wire \derivative_reg[7]_i_107_n_0 ;
  wire \derivative_reg[7]_i_107_n_1 ;
  wire \derivative_reg[7]_i_107_n_2 ;
  wire \derivative_reg[7]_i_107_n_3 ;
  wire \derivative_reg[7]_i_107_n_4 ;
  wire \derivative_reg[7]_i_107_n_5 ;
  wire \derivative_reg[7]_i_107_n_6 ;
  wire \derivative_reg[7]_i_107_n_7 ;
  wire \derivative_reg[7]_i_10_n_0 ;
  wire \derivative_reg[7]_i_10_n_1 ;
  wire \derivative_reg[7]_i_10_n_2 ;
  wire \derivative_reg[7]_i_10_n_3 ;
  wire \derivative_reg[7]_i_10_n_4 ;
  wire \derivative_reg[7]_i_10_n_5 ;
  wire \derivative_reg[7]_i_10_n_6 ;
  wire \derivative_reg[7]_i_10_n_7 ;
  wire \derivative_reg[7]_i_112_n_0 ;
  wire \derivative_reg[7]_i_112_n_1 ;
  wire \derivative_reg[7]_i_112_n_2 ;
  wire \derivative_reg[7]_i_112_n_3 ;
  wire \derivative_reg[7]_i_112_n_4 ;
  wire \derivative_reg[7]_i_112_n_5 ;
  wire \derivative_reg[7]_i_112_n_6 ;
  wire \derivative_reg[7]_i_112_n_7 ;
  wire \derivative_reg[7]_i_117_n_0 ;
  wire \derivative_reg[7]_i_117_n_1 ;
  wire \derivative_reg[7]_i_117_n_2 ;
  wire \derivative_reg[7]_i_117_n_3 ;
  wire \derivative_reg[7]_i_117_n_4 ;
  wire \derivative_reg[7]_i_117_n_5 ;
  wire \derivative_reg[7]_i_117_n_6 ;
  wire \derivative_reg[7]_i_117_n_7 ;
  wire \derivative_reg[7]_i_122_n_0 ;
  wire \derivative_reg[7]_i_122_n_1 ;
  wire \derivative_reg[7]_i_122_n_2 ;
  wire \derivative_reg[7]_i_122_n_3 ;
  wire \derivative_reg[7]_i_122_n_4 ;
  wire \derivative_reg[7]_i_122_n_5 ;
  wire \derivative_reg[7]_i_122_n_6 ;
  wire \derivative_reg[7]_i_122_n_7 ;
  wire \derivative_reg[7]_i_127_n_0 ;
  wire \derivative_reg[7]_i_127_n_1 ;
  wire \derivative_reg[7]_i_127_n_2 ;
  wire \derivative_reg[7]_i_127_n_3 ;
  wire \derivative_reg[7]_i_127_n_4 ;
  wire \derivative_reg[7]_i_127_n_5 ;
  wire \derivative_reg[7]_i_127_n_6 ;
  wire \derivative_reg[7]_i_127_n_7 ;
  wire \derivative_reg[7]_i_132_n_0 ;
  wire \derivative_reg[7]_i_132_n_1 ;
  wire \derivative_reg[7]_i_132_n_2 ;
  wire \derivative_reg[7]_i_132_n_3 ;
  wire \derivative_reg[7]_i_132_n_4 ;
  wire \derivative_reg[7]_i_132_n_5 ;
  wire \derivative_reg[7]_i_132_n_6 ;
  wire \derivative_reg[7]_i_132_n_7 ;
  wire \derivative_reg[7]_i_137_n_0 ;
  wire \derivative_reg[7]_i_137_n_1 ;
  wire \derivative_reg[7]_i_137_n_2 ;
  wire \derivative_reg[7]_i_137_n_3 ;
  wire \derivative_reg[7]_i_137_n_4 ;
  wire \derivative_reg[7]_i_137_n_5 ;
  wire \derivative_reg[7]_i_137_n_6 ;
  wire \derivative_reg[7]_i_137_n_7 ;
  wire \derivative_reg[7]_i_13_n_0 ;
  wire \derivative_reg[7]_i_13_n_1 ;
  wire \derivative_reg[7]_i_13_n_2 ;
  wire \derivative_reg[7]_i_13_n_3 ;
  wire \derivative_reg[7]_i_13_n_4 ;
  wire \derivative_reg[7]_i_13_n_5 ;
  wire \derivative_reg[7]_i_13_n_6 ;
  wire \derivative_reg[7]_i_13_n_7 ;
  wire \derivative_reg[7]_i_142_n_0 ;
  wire \derivative_reg[7]_i_142_n_1 ;
  wire \derivative_reg[7]_i_142_n_2 ;
  wire \derivative_reg[7]_i_142_n_3 ;
  wire \derivative_reg[7]_i_142_n_4 ;
  wire \derivative_reg[7]_i_142_n_5 ;
  wire \derivative_reg[7]_i_142_n_6 ;
  wire \derivative_reg[7]_i_147_n_0 ;
  wire \derivative_reg[7]_i_147_n_1 ;
  wire \derivative_reg[7]_i_147_n_2 ;
  wire \derivative_reg[7]_i_147_n_3 ;
  wire \derivative_reg[7]_i_147_n_4 ;
  wire \derivative_reg[7]_i_147_n_5 ;
  wire \derivative_reg[7]_i_147_n_6 ;
  wire \derivative_reg[7]_i_152_n_0 ;
  wire \derivative_reg[7]_i_152_n_1 ;
  wire \derivative_reg[7]_i_152_n_2 ;
  wire \derivative_reg[7]_i_152_n_3 ;
  wire \derivative_reg[7]_i_152_n_4 ;
  wire \derivative_reg[7]_i_152_n_5 ;
  wire \derivative_reg[7]_i_152_n_6 ;
  wire \derivative_reg[7]_i_157_n_0 ;
  wire \derivative_reg[7]_i_157_n_1 ;
  wire \derivative_reg[7]_i_157_n_2 ;
  wire \derivative_reg[7]_i_157_n_3 ;
  wire \derivative_reg[7]_i_157_n_4 ;
  wire \derivative_reg[7]_i_157_n_5 ;
  wire \derivative_reg[7]_i_157_n_6 ;
  wire \derivative_reg[7]_i_16_n_0 ;
  wire \derivative_reg[7]_i_16_n_1 ;
  wire \derivative_reg[7]_i_16_n_2 ;
  wire \derivative_reg[7]_i_16_n_3 ;
  wire \derivative_reg[7]_i_16_n_4 ;
  wire \derivative_reg[7]_i_16_n_5 ;
  wire \derivative_reg[7]_i_16_n_6 ;
  wire \derivative_reg[7]_i_16_n_7 ;
  wire \derivative_reg[7]_i_178_n_0 ;
  wire \derivative_reg[7]_i_178_n_1 ;
  wire \derivative_reg[7]_i_178_n_2 ;
  wire \derivative_reg[7]_i_178_n_3 ;
  wire \derivative_reg[7]_i_178_n_4 ;
  wire \derivative_reg[7]_i_178_n_5 ;
  wire \derivative_reg[7]_i_178_n_6 ;
  wire \derivative_reg[7]_i_178_n_7 ;
  wire \derivative_reg[7]_i_19_n_0 ;
  wire \derivative_reg[7]_i_19_n_1 ;
  wire \derivative_reg[7]_i_19_n_2 ;
  wire \derivative_reg[7]_i_19_n_3 ;
  wire \derivative_reg[7]_i_19_n_4 ;
  wire \derivative_reg[7]_i_19_n_5 ;
  wire \derivative_reg[7]_i_19_n_6 ;
  wire \derivative_reg[7]_i_19_n_7 ;
  wire \derivative_reg[7]_i_1_n_0 ;
  wire \derivative_reg[7]_i_1_n_1 ;
  wire \derivative_reg[7]_i_1_n_2 ;
  wire \derivative_reg[7]_i_1_n_3 ;
  wire \derivative_reg[7]_i_1_n_4 ;
  wire \derivative_reg[7]_i_1_n_5 ;
  wire \derivative_reg[7]_i_1_n_6 ;
  wire \derivative_reg[7]_i_1_n_7 ;
  wire \derivative_reg[7]_i_22_n_0 ;
  wire \derivative_reg[7]_i_22_n_1 ;
  wire \derivative_reg[7]_i_22_n_2 ;
  wire \derivative_reg[7]_i_22_n_3 ;
  wire \derivative_reg[7]_i_22_n_4 ;
  wire \derivative_reg[7]_i_22_n_5 ;
  wire \derivative_reg[7]_i_22_n_6 ;
  wire \derivative_reg[7]_i_22_n_7 ;
  wire \derivative_reg[7]_i_27_n_0 ;
  wire \derivative_reg[7]_i_27_n_1 ;
  wire \derivative_reg[7]_i_27_n_2 ;
  wire \derivative_reg[7]_i_27_n_3 ;
  wire \derivative_reg[7]_i_27_n_4 ;
  wire \derivative_reg[7]_i_27_n_5 ;
  wire \derivative_reg[7]_i_27_n_6 ;
  wire \derivative_reg[7]_i_27_n_7 ;
  wire \derivative_reg[7]_i_32_n_0 ;
  wire \derivative_reg[7]_i_32_n_1 ;
  wire \derivative_reg[7]_i_32_n_2 ;
  wire \derivative_reg[7]_i_32_n_3 ;
  wire \derivative_reg[7]_i_32_n_4 ;
  wire \derivative_reg[7]_i_32_n_5 ;
  wire \derivative_reg[7]_i_32_n_6 ;
  wire \derivative_reg[7]_i_32_n_7 ;
  wire \derivative_reg[7]_i_37_n_0 ;
  wire \derivative_reg[7]_i_37_n_1 ;
  wire \derivative_reg[7]_i_37_n_2 ;
  wire \derivative_reg[7]_i_37_n_3 ;
  wire \derivative_reg[7]_i_37_n_4 ;
  wire \derivative_reg[7]_i_37_n_5 ;
  wire \derivative_reg[7]_i_37_n_6 ;
  wire \derivative_reg[7]_i_37_n_7 ;
  wire \derivative_reg[7]_i_42_n_0 ;
  wire \derivative_reg[7]_i_42_n_1 ;
  wire \derivative_reg[7]_i_42_n_2 ;
  wire \derivative_reg[7]_i_42_n_3 ;
  wire \derivative_reg[7]_i_42_n_4 ;
  wire \derivative_reg[7]_i_42_n_5 ;
  wire \derivative_reg[7]_i_42_n_6 ;
  wire \derivative_reg[7]_i_42_n_7 ;
  wire \derivative_reg[7]_i_47_n_0 ;
  wire \derivative_reg[7]_i_47_n_1 ;
  wire \derivative_reg[7]_i_47_n_2 ;
  wire \derivative_reg[7]_i_47_n_3 ;
  wire \derivative_reg[7]_i_47_n_4 ;
  wire \derivative_reg[7]_i_47_n_5 ;
  wire \derivative_reg[7]_i_47_n_6 ;
  wire \derivative_reg[7]_i_47_n_7 ;
  wire \derivative_reg[7]_i_52_n_0 ;
  wire \derivative_reg[7]_i_52_n_1 ;
  wire \derivative_reg[7]_i_52_n_2 ;
  wire \derivative_reg[7]_i_52_n_3 ;
  wire \derivative_reg[7]_i_52_n_4 ;
  wire \derivative_reg[7]_i_52_n_5 ;
  wire \derivative_reg[7]_i_52_n_6 ;
  wire \derivative_reg[7]_i_52_n_7 ;
  wire \derivative_reg[7]_i_57_n_0 ;
  wire \derivative_reg[7]_i_57_n_1 ;
  wire \derivative_reg[7]_i_57_n_2 ;
  wire \derivative_reg[7]_i_57_n_3 ;
  wire \derivative_reg[7]_i_57_n_4 ;
  wire \derivative_reg[7]_i_57_n_5 ;
  wire \derivative_reg[7]_i_57_n_6 ;
  wire \derivative_reg[7]_i_57_n_7 ;
  wire \derivative_reg[7]_i_62_n_0 ;
  wire \derivative_reg[7]_i_62_n_1 ;
  wire \derivative_reg[7]_i_62_n_2 ;
  wire \derivative_reg[7]_i_62_n_3 ;
  wire \derivative_reg[7]_i_62_n_4 ;
  wire \derivative_reg[7]_i_62_n_5 ;
  wire \derivative_reg[7]_i_62_n_6 ;
  wire \derivative_reg[7]_i_62_n_7 ;
  wire \derivative_reg[7]_i_67_n_0 ;
  wire \derivative_reg[7]_i_67_n_1 ;
  wire \derivative_reg[7]_i_67_n_2 ;
  wire \derivative_reg[7]_i_67_n_3 ;
  wire \derivative_reg[7]_i_67_n_4 ;
  wire \derivative_reg[7]_i_67_n_5 ;
  wire \derivative_reg[7]_i_67_n_6 ;
  wire \derivative_reg[7]_i_67_n_7 ;
  wire \derivative_reg[7]_i_6_n_3 ;
  wire \derivative_reg[7]_i_6_n_7 ;
  wire \derivative_reg[7]_i_72_n_0 ;
  wire \derivative_reg[7]_i_72_n_1 ;
  wire \derivative_reg[7]_i_72_n_2 ;
  wire \derivative_reg[7]_i_72_n_3 ;
  wire \derivative_reg[7]_i_72_n_4 ;
  wire \derivative_reg[7]_i_72_n_5 ;
  wire \derivative_reg[7]_i_72_n_6 ;
  wire \derivative_reg[7]_i_72_n_7 ;
  wire \derivative_reg[7]_i_77_n_0 ;
  wire \derivative_reg[7]_i_77_n_1 ;
  wire \derivative_reg[7]_i_77_n_2 ;
  wire \derivative_reg[7]_i_77_n_3 ;
  wire \derivative_reg[7]_i_77_n_4 ;
  wire \derivative_reg[7]_i_77_n_5 ;
  wire \derivative_reg[7]_i_77_n_6 ;
  wire \derivative_reg[7]_i_77_n_7 ;
  wire \derivative_reg[7]_i_7_n_3 ;
  wire \derivative_reg[7]_i_7_n_7 ;
  wire \derivative_reg[7]_i_82_n_0 ;
  wire \derivative_reg[7]_i_82_n_1 ;
  wire \derivative_reg[7]_i_82_n_2 ;
  wire \derivative_reg[7]_i_82_n_3 ;
  wire \derivative_reg[7]_i_82_n_4 ;
  wire \derivative_reg[7]_i_82_n_5 ;
  wire \derivative_reg[7]_i_82_n_6 ;
  wire \derivative_reg[7]_i_82_n_7 ;
  wire \derivative_reg[7]_i_87_n_0 ;
  wire \derivative_reg[7]_i_87_n_1 ;
  wire \derivative_reg[7]_i_87_n_2 ;
  wire \derivative_reg[7]_i_87_n_3 ;
  wire \derivative_reg[7]_i_87_n_4 ;
  wire \derivative_reg[7]_i_87_n_5 ;
  wire \derivative_reg[7]_i_87_n_6 ;
  wire \derivative_reg[7]_i_87_n_7 ;
  wire \derivative_reg[7]_i_8_n_3 ;
  wire \derivative_reg[7]_i_8_n_7 ;
  wire \derivative_reg[7]_i_92_n_0 ;
  wire \derivative_reg[7]_i_92_n_1 ;
  wire \derivative_reg[7]_i_92_n_2 ;
  wire \derivative_reg[7]_i_92_n_3 ;
  wire \derivative_reg[7]_i_92_n_4 ;
  wire \derivative_reg[7]_i_92_n_5 ;
  wire \derivative_reg[7]_i_92_n_6 ;
  wire \derivative_reg[7]_i_92_n_7 ;
  wire \derivative_reg[7]_i_97_n_0 ;
  wire \derivative_reg[7]_i_97_n_1 ;
  wire \derivative_reg[7]_i_97_n_2 ;
  wire \derivative_reg[7]_i_97_n_3 ;
  wire \derivative_reg[7]_i_97_n_4 ;
  wire \derivative_reg[7]_i_97_n_5 ;
  wire \derivative_reg[7]_i_97_n_6 ;
  wire \derivative_reg[7]_i_97_n_7 ;
  wire \derivative_reg[7]_i_9_n_3 ;
  wire \derivative_reg[7]_i_9_n_7 ;
  wire [31:0]dt00_in;
  wire [31:1]dt0__93;
  wire dt0_carry__0_i_1_n_0;
  wire dt0_carry__0_i_2_n_0;
  wire dt0_carry__0_i_3_n_0;
  wire dt0_carry__0_i_4_n_0;
  wire dt0_carry__0_n_0;
  wire dt0_carry__0_n_1;
  wire dt0_carry__0_n_2;
  wire dt0_carry__0_n_3;
  wire dt0_carry__1_i_1_n_0;
  wire dt0_carry__1_i_2_n_0;
  wire dt0_carry__1_i_3_n_0;
  wire dt0_carry__1_i_4_n_0;
  wire dt0_carry__1_n_0;
  wire dt0_carry__1_n_1;
  wire dt0_carry__1_n_2;
  wire dt0_carry__1_n_3;
  wire dt0_carry__2_i_1_n_0;
  wire dt0_carry__2_i_2_n_0;
  wire dt0_carry__2_i_3_n_0;
  wire dt0_carry__2_i_4_n_0;
  wire dt0_carry__2_n_0;
  wire dt0_carry__2_n_1;
  wire dt0_carry__2_n_2;
  wire dt0_carry__2_n_3;
  wire dt0_carry__3_i_1_n_0;
  wire dt0_carry__3_i_2_n_0;
  wire dt0_carry__3_i_3_n_0;
  wire dt0_carry__3_i_4_n_0;
  wire dt0_carry__3_n_0;
  wire dt0_carry__3_n_1;
  wire dt0_carry__3_n_2;
  wire dt0_carry__3_n_3;
  wire dt0_carry__4_i_1_n_0;
  wire dt0_carry__4_i_2_n_0;
  wire dt0_carry__4_i_3_n_0;
  wire dt0_carry__4_i_4_n_0;
  wire dt0_carry__4_n_0;
  wire dt0_carry__4_n_1;
  wire dt0_carry__4_n_2;
  wire dt0_carry__4_n_3;
  wire dt0_carry__5_i_1_n_0;
  wire dt0_carry__5_i_2_n_0;
  wire dt0_carry__5_i_3_n_0;
  wire dt0_carry__5_i_4_n_0;
  wire dt0_carry__5_n_0;
  wire dt0_carry__5_n_1;
  wire dt0_carry__5_n_2;
  wire dt0_carry__5_n_3;
  wire dt0_carry__6_i_1_n_0;
  wire dt0_carry__6_i_2_n_0;
  wire dt0_carry__6_i_3_n_0;
  wire dt0_carry__6_i_4_n_0;
  wire dt0_carry__6_n_1;
  wire dt0_carry__6_n_2;
  wire dt0_carry__6_n_3;
  wire dt0_carry_i_1_n_0;
  wire dt0_carry_i_2_n_0;
  wire dt0_carry_i_3_n_0;
  wire dt0_carry_i_4_n_0;
  wire dt0_carry_n_0;
  wire dt0_carry_n_1;
  wire dt0_carry_n_2;
  wire dt0_carry_n_3;
  wire dt1__15;
  wire dt1_carry__0_i_1_n_0;
  wire dt1_carry__0_i_2_n_0;
  wire dt1_carry__0_i_3_n_0;
  wire dt1_carry__0_i_4_n_0;
  wire dt1_carry__0_i_5_n_0;
  wire dt1_carry__0_i_6_n_0;
  wire dt1_carry__0_i_7_n_0;
  wire dt1_carry__0_i_8_n_0;
  wire dt1_carry__0_n_0;
  wire dt1_carry__0_n_1;
  wire dt1_carry__0_n_2;
  wire dt1_carry__0_n_3;
  wire dt1_carry__1_i_1_n_0;
  wire dt1_carry__1_i_2_n_0;
  wire dt1_carry__1_i_3_n_0;
  wire dt1_carry__1_i_4_n_0;
  wire dt1_carry__1_i_5_n_0;
  wire dt1_carry__1_i_6_n_0;
  wire dt1_carry__1_i_7_n_0;
  wire dt1_carry__1_i_8_n_0;
  wire dt1_carry__1_n_0;
  wire dt1_carry__1_n_1;
  wire dt1_carry__1_n_2;
  wire dt1_carry__1_n_3;
  wire dt1_carry__2_i_1_n_0;
  wire dt1_carry__2_i_2_n_0;
  wire dt1_carry__2_i_3_n_0;
  wire dt1_carry__2_i_4_n_0;
  wire dt1_carry__2_i_5_n_0;
  wire dt1_carry__2_i_6_n_0;
  wire dt1_carry__2_i_7_n_0;
  wire dt1_carry__2_i_8_n_0;
  wire dt1_carry__2_n_1;
  wire dt1_carry__2_n_2;
  wire dt1_carry__2_n_3;
  wire dt1_carry_i_1_n_0;
  wire dt1_carry_i_2_n_0;
  wire dt1_carry_i_3_n_0;
  wire dt1_carry_i_4_n_0;
  wire dt1_carry_i_5_n_0;
  wire dt1_carry_i_6_n_0;
  wire dt1_carry_i_7_n_0;
  wire dt1_carry_i_8_n_0;
  wire dt1_carry_n_0;
  wire dt1_carry_n_1;
  wire dt1_carry_n_2;
  wire dt1_carry_n_3;
  wire error;
  wire [31:0]error0;
  wire error0_carry__0_n_0;
  wire error0_carry__0_n_1;
  wire error0_carry__0_n_2;
  wire error0_carry__0_n_3;
  wire error0_carry__1_n_0;
  wire error0_carry__1_n_1;
  wire error0_carry__1_n_2;
  wire error0_carry__1_n_3;
  wire error0_carry__2_n_0;
  wire error0_carry__2_n_1;
  wire error0_carry__2_n_2;
  wire error0_carry__2_n_3;
  wire error0_carry__3_n_0;
  wire error0_carry__3_n_1;
  wire error0_carry__3_n_2;
  wire error0_carry__3_n_3;
  wire error0_carry__4_n_0;
  wire error0_carry__4_n_1;
  wire error0_carry__4_n_2;
  wire error0_carry__4_n_3;
  wire error0_carry__5_n_0;
  wire error0_carry__5_n_1;
  wire error0_carry__5_n_2;
  wire error0_carry__5_n_3;
  wire error0_carry__6_n_1;
  wire error0_carry__6_n_2;
  wire error0_carry__6_n_3;
  wire error0_carry_i_1__0_n_0;
  wire error0_carry_i_1__1_n_0;
  wire error0_carry_i_1__2_n_0;
  wire error0_carry_i_1__3_n_0;
  wire error0_carry_i_1__4_n_0;
  wire error0_carry_i_1__5_n_0;
  wire error0_carry_i_1__6_n_0;
  wire error0_carry_i_1_n_0;
  wire error0_carry_i_2__0_n_0;
  wire error0_carry_i_2__1_n_0;
  wire error0_carry_i_2__2_n_0;
  wire error0_carry_i_2__3_n_0;
  wire error0_carry_i_2__4_n_0;
  wire error0_carry_i_2__5_n_0;
  wire error0_carry_i_2__6_n_0;
  wire error0_carry_i_2_n_0;
  wire error0_carry_i_3__0_n_0;
  wire error0_carry_i_3__1_n_0;
  wire error0_carry_i_3__2_n_0;
  wire error0_carry_i_3__3_n_0;
  wire error0_carry_i_3__4_n_0;
  wire error0_carry_i_3__5_n_0;
  wire error0_carry_i_3__6_n_0;
  wire error0_carry_i_3_n_0;
  wire error0_carry_i_4__0_n_0;
  wire error0_carry_i_4__1_n_0;
  wire error0_carry_i_4__2_n_0;
  wire error0_carry_i_4__3_n_0;
  wire error0_carry_i_4__4_n_0;
  wire error0_carry_i_4__5_n_0;
  wire error0_carry_i_4__6_n_0;
  wire error0_carry_i_4_n_0;
  wire error0_carry_n_0;
  wire error0_carry_n_1;
  wire error0_carry_n_2;
  wire error0_carry_n_3;
  wire [31:0]error_in;
  wire [31:0]error_out;
  wire integral;
  wire integral0_carry__0_n_0;
  wire integral0_carry__0_n_1;
  wire integral0_carry__0_n_2;
  wire integral0_carry__0_n_3;
  wire integral0_carry__0_n_4;
  wire integral0_carry__0_n_5;
  wire integral0_carry__0_n_6;
  wire integral0_carry__0_n_7;
  wire integral0_carry__1_n_0;
  wire integral0_carry__1_n_1;
  wire integral0_carry__1_n_2;
  wire integral0_carry__1_n_3;
  wire integral0_carry__1_n_4;
  wire integral0_carry__1_n_5;
  wire integral0_carry__1_n_6;
  wire integral0_carry__1_n_7;
  wire integral0_carry__2_n_0;
  wire integral0_carry__2_n_1;
  wire integral0_carry__2_n_2;
  wire integral0_carry__2_n_3;
  wire integral0_carry__2_n_4;
  wire integral0_carry__2_n_5;
  wire integral0_carry__2_n_6;
  wire integral0_carry__2_n_7;
  wire integral0_carry__3_n_0;
  wire integral0_carry__3_n_1;
  wire integral0_carry__3_n_2;
  wire integral0_carry__3_n_3;
  wire integral0_carry__3_n_4;
  wire integral0_carry__3_n_5;
  wire integral0_carry__3_n_6;
  wire integral0_carry__3_n_7;
  wire integral0_carry__4_n_0;
  wire integral0_carry__4_n_1;
  wire integral0_carry__4_n_2;
  wire integral0_carry__4_n_3;
  wire integral0_carry__4_n_4;
  wire integral0_carry__4_n_5;
  wire integral0_carry__4_n_6;
  wire integral0_carry__4_n_7;
  wire integral0_carry__5_n_0;
  wire integral0_carry__5_n_1;
  wire integral0_carry__5_n_2;
  wire integral0_carry__5_n_3;
  wire integral0_carry__5_n_4;
  wire integral0_carry__5_n_5;
  wire integral0_carry__5_n_6;
  wire integral0_carry__5_n_7;
  wire integral0_carry__6_n_1;
  wire integral0_carry__6_n_2;
  wire integral0_carry__6_n_3;
  wire integral0_carry__6_n_4;
  wire integral0_carry__6_n_5;
  wire integral0_carry__6_n_6;
  wire integral0_carry__6_n_7;
  wire integral0_carry_i_1__0_n_0;
  wire integral0_carry_i_1__1_n_0;
  wire integral0_carry_i_1__2_n_0;
  wire integral0_carry_i_1__3_n_0;
  wire integral0_carry_i_1__4_n_0;
  wire integral0_carry_i_1__5_n_0;
  wire integral0_carry_i_1__6_n_0;
  wire integral0_carry_i_1_n_0;
  wire integral0_carry_i_2__0_n_0;
  wire integral0_carry_i_2__1_n_0;
  wire integral0_carry_i_2__2_n_0;
  wire integral0_carry_i_2__3_n_0;
  wire integral0_carry_i_2__4_n_0;
  wire integral0_carry_i_2__5_n_0;
  wire integral0_carry_i_2__6_n_0;
  wire integral0_carry_i_2_n_0;
  wire integral0_carry_i_3__0_n_0;
  wire integral0_carry_i_3__1_n_0;
  wire integral0_carry_i_3__2_n_0;
  wire integral0_carry_i_3__3_n_0;
  wire integral0_carry_i_3__4_n_0;
  wire integral0_carry_i_3__5_n_0;
  wire integral0_carry_i_3__6_n_0;
  wire integral0_carry_i_3_n_0;
  wire integral0_carry_i_4__0_n_0;
  wire integral0_carry_i_4__1_n_0;
  wire integral0_carry_i_4__2_n_0;
  wire integral0_carry_i_4__3_n_0;
  wire integral0_carry_i_4__4_n_0;
  wire integral0_carry_i_4__5_n_0;
  wire integral0_carry_i_4__6_n_0;
  wire integral0_carry_i_4_n_0;
  wire integral0_carry_n_0;
  wire integral0_carry_n_1;
  wire integral0_carry_n_2;
  wire integral0_carry_n_3;
  wire integral0_carry_n_4;
  wire integral0_carry_n_5;
  wire integral0_carry_n_6;
  wire integral0_carry_n_7;
  wire integral1__0_n_100;
  wire integral1__0_n_101;
  wire integral1__0_n_102;
  wire integral1__0_n_103;
  wire integral1__0_n_104;
  wire integral1__0_n_105;
  wire integral1__0_n_106;
  wire integral1__0_n_107;
  wire integral1__0_n_108;
  wire integral1__0_n_109;
  wire integral1__0_n_110;
  wire integral1__0_n_111;
  wire integral1__0_n_112;
  wire integral1__0_n_113;
  wire integral1__0_n_114;
  wire integral1__0_n_115;
  wire integral1__0_n_116;
  wire integral1__0_n_117;
  wire integral1__0_n_118;
  wire integral1__0_n_119;
  wire integral1__0_n_120;
  wire integral1__0_n_121;
  wire integral1__0_n_122;
  wire integral1__0_n_123;
  wire integral1__0_n_124;
  wire integral1__0_n_125;
  wire integral1__0_n_126;
  wire integral1__0_n_127;
  wire integral1__0_n_128;
  wire integral1__0_n_129;
  wire integral1__0_n_130;
  wire integral1__0_n_131;
  wire integral1__0_n_132;
  wire integral1__0_n_133;
  wire integral1__0_n_134;
  wire integral1__0_n_135;
  wire integral1__0_n_136;
  wire integral1__0_n_137;
  wire integral1__0_n_138;
  wire integral1__0_n_139;
  wire integral1__0_n_140;
  wire integral1__0_n_141;
  wire integral1__0_n_142;
  wire integral1__0_n_143;
  wire integral1__0_n_144;
  wire integral1__0_n_145;
  wire integral1__0_n_146;
  wire integral1__0_n_147;
  wire integral1__0_n_148;
  wire integral1__0_n_149;
  wire integral1__0_n_150;
  wire integral1__0_n_151;
  wire integral1__0_n_152;
  wire integral1__0_n_153;
  wire integral1__0_n_58;
  wire integral1__0_n_59;
  wire integral1__0_n_60;
  wire integral1__0_n_61;
  wire integral1__0_n_62;
  wire integral1__0_n_63;
  wire integral1__0_n_64;
  wire integral1__0_n_65;
  wire integral1__0_n_66;
  wire integral1__0_n_67;
  wire integral1__0_n_68;
  wire integral1__0_n_69;
  wire integral1__0_n_70;
  wire integral1__0_n_71;
  wire integral1__0_n_72;
  wire integral1__0_n_73;
  wire integral1__0_n_74;
  wire integral1__0_n_75;
  wire integral1__0_n_76;
  wire integral1__0_n_77;
  wire integral1__0_n_78;
  wire integral1__0_n_79;
  wire integral1__0_n_80;
  wire integral1__0_n_81;
  wire integral1__0_n_82;
  wire integral1__0_n_83;
  wire integral1__0_n_84;
  wire integral1__0_n_85;
  wire integral1__0_n_86;
  wire integral1__0_n_87;
  wire integral1__0_n_88;
  wire integral1__0_n_89;
  wire integral1__0_n_90;
  wire integral1__0_n_91;
  wire integral1__0_n_92;
  wire integral1__0_n_93;
  wire integral1__0_n_94;
  wire integral1__0_n_95;
  wire integral1__0_n_96;
  wire integral1__0_n_97;
  wire integral1__0_n_98;
  wire integral1__0_n_99;
  wire integral1__1_n_100;
  wire integral1__1_n_101;
  wire integral1__1_n_102;
  wire integral1__1_n_103;
  wire integral1__1_n_104;
  wire integral1__1_n_105;
  wire integral1__1_n_58;
  wire integral1__1_n_59;
  wire integral1__1_n_60;
  wire integral1__1_n_61;
  wire integral1__1_n_62;
  wire integral1__1_n_63;
  wire integral1__1_n_64;
  wire integral1__1_n_65;
  wire integral1__1_n_66;
  wire integral1__1_n_67;
  wire integral1__1_n_68;
  wire integral1__1_n_69;
  wire integral1__1_n_70;
  wire integral1__1_n_71;
  wire integral1__1_n_72;
  wire integral1__1_n_73;
  wire integral1__1_n_74;
  wire integral1__1_n_75;
  wire integral1__1_n_76;
  wire integral1__1_n_77;
  wire integral1__1_n_78;
  wire integral1__1_n_79;
  wire integral1__1_n_80;
  wire integral1__1_n_81;
  wire integral1__1_n_82;
  wire integral1__1_n_83;
  wire integral1__1_n_84;
  wire integral1__1_n_85;
  wire integral1__1_n_86;
  wire integral1__1_n_87;
  wire integral1__1_n_88;
  wire integral1__1_n_89;
  wire integral1__1_n_90;
  wire integral1__1_n_91;
  wire integral1__1_n_92;
  wire integral1__1_n_93;
  wire integral1__1_n_94;
  wire integral1__1_n_95;
  wire integral1__1_n_96;
  wire integral1__1_n_97;
  wire integral1__1_n_98;
  wire integral1__1_n_99;
  wire integral1_carry__0_i_1_n_0;
  wire integral1_carry__0_i_2_n_0;
  wire integral1_carry__0_i_3_n_0;
  wire integral1_carry__0_i_4_n_0;
  wire integral1_carry__0_n_0;
  wire integral1_carry__0_n_1;
  wire integral1_carry__0_n_2;
  wire integral1_carry__0_n_3;
  wire integral1_carry__0_n_4;
  wire integral1_carry__0_n_5;
  wire integral1_carry__0_n_6;
  wire integral1_carry__0_n_7;
  wire integral1_carry__1_i_1_n_0;
  wire integral1_carry__1_i_2_n_0;
  wire integral1_carry__1_i_3_n_0;
  wire integral1_carry__1_i_4_n_0;
  wire integral1_carry__1_n_0;
  wire integral1_carry__1_n_1;
  wire integral1_carry__1_n_2;
  wire integral1_carry__1_n_3;
  wire integral1_carry__1_n_4;
  wire integral1_carry__1_n_5;
  wire integral1_carry__1_n_6;
  wire integral1_carry__1_n_7;
  wire integral1_carry__2_i_1_n_0;
  wire integral1_carry__2_i_2_n_0;
  wire integral1_carry__2_i_3_n_0;
  wire integral1_carry__2_i_4_n_0;
  wire integral1_carry__2_n_1;
  wire integral1_carry__2_n_2;
  wire integral1_carry__2_n_3;
  wire integral1_carry__2_n_4;
  wire integral1_carry__2_n_5;
  wire integral1_carry__2_n_6;
  wire integral1_carry__2_n_7;
  wire integral1_carry_i_1_n_0;
  wire integral1_carry_i_2_n_0;
  wire integral1_carry_i_3_n_0;
  wire integral1_carry_n_0;
  wire integral1_carry_n_1;
  wire integral1_carry_n_2;
  wire integral1_carry_n_3;
  wire integral1_carry_n_4;
  wire integral1_carry_n_5;
  wire integral1_carry_n_6;
  wire integral1_carry_n_7;
  wire integral1_i_16__0_n_2;
  wire integral1_i_16__0_n_3;
  wire integral1_i_17__0_n_0;
  wire integral1_i_17__0_n_1;
  wire integral1_i_17__0_n_2;
  wire integral1_i_17__0_n_3;
  wire integral1_i_18__0_n_0;
  wire integral1_i_18__0_n_1;
  wire integral1_i_18__0_n_2;
  wire integral1_i_18__0_n_3;
  wire integral1_i_18_n_0;
  wire integral1_i_18_n_1;
  wire integral1_i_18_n_2;
  wire integral1_i_18_n_3;
  wire integral1_i_19__0_n_0;
  wire integral1_i_19__0_n_1;
  wire integral1_i_19__0_n_2;
  wire integral1_i_19__0_n_3;
  wire integral1_i_19_n_0;
  wire integral1_i_19_n_1;
  wire integral1_i_19_n_2;
  wire integral1_i_19_n_3;
  wire integral1_i_20__0_n_0;
  wire integral1_i_20__0_n_1;
  wire integral1_i_20__0_n_2;
  wire integral1_i_20__0_n_3;
  wire integral1_i_20_n_0;
  wire integral1_i_21__0_n_0;
  wire integral1_i_21__0_n_1;
  wire integral1_i_21__0_n_2;
  wire integral1_i_21__0_n_3;
  wire integral1_i_21_n_0;
  wire integral1_i_22__0_n_0;
  wire integral1_i_22_n_0;
  wire integral1_i_23__0_n_0;
  wire integral1_i_23_n_0;
  wire integral1_i_24__0_n_0;
  wire integral1_i_24_n_0;
  wire integral1_i_25__0_n_0;
  wire integral1_i_25_n_0;
  wire integral1_i_26__0_n_0;
  wire integral1_i_26_n_0;
  wire integral1_i_27__0_n_0;
  wire integral1_i_27_n_0;
  wire integral1_i_28__0_n_0;
  wire integral1_i_28_n_0;
  wire integral1_i_29__0_n_0;
  wire integral1_i_29_n_0;
  wire integral1_i_30__0_n_0;
  wire integral1_i_30_n_0;
  wire integral1_i_31__0_n_0;
  wire integral1_i_31_n_0;
  wire integral1_i_32__0_n_0;
  wire integral1_i_32_n_0;
  wire integral1_i_33__0_n_0;
  wire integral1_i_33_n_0;
  wire integral1_i_34__0_n_0;
  wire integral1_i_34_n_0;
  wire integral1_i_35_n_0;
  wire integral1_i_36_n_0;
  wire integral1_i_37_n_0;
  wire integral1_i_38_n_0;
  wire integral1_n_100;
  wire integral1_n_101;
  wire integral1_n_102;
  wire integral1_n_103;
  wire integral1_n_104;
  wire integral1_n_105;
  wire integral1_n_106;
  wire integral1_n_107;
  wire integral1_n_108;
  wire integral1_n_109;
  wire integral1_n_110;
  wire integral1_n_111;
  wire integral1_n_112;
  wire integral1_n_113;
  wire integral1_n_114;
  wire integral1_n_115;
  wire integral1_n_116;
  wire integral1_n_117;
  wire integral1_n_118;
  wire integral1_n_119;
  wire integral1_n_120;
  wire integral1_n_121;
  wire integral1_n_122;
  wire integral1_n_123;
  wire integral1_n_124;
  wire integral1_n_125;
  wire integral1_n_126;
  wire integral1_n_127;
  wire integral1_n_128;
  wire integral1_n_129;
  wire integral1_n_130;
  wire integral1_n_131;
  wire integral1_n_132;
  wire integral1_n_133;
  wire integral1_n_134;
  wire integral1_n_135;
  wire integral1_n_136;
  wire integral1_n_137;
  wire integral1_n_138;
  wire integral1_n_139;
  wire integral1_n_140;
  wire integral1_n_141;
  wire integral1_n_142;
  wire integral1_n_143;
  wire integral1_n_144;
  wire integral1_n_145;
  wire integral1_n_146;
  wire integral1_n_147;
  wire integral1_n_148;
  wire integral1_n_149;
  wire integral1_n_150;
  wire integral1_n_151;
  wire integral1_n_152;
  wire integral1_n_153;
  wire integral1_n_58;
  wire integral1_n_59;
  wire integral1_n_60;
  wire integral1_n_61;
  wire integral1_n_62;
  wire integral1_n_63;
  wire integral1_n_64;
  wire integral1_n_65;
  wire integral1_n_66;
  wire integral1_n_67;
  wire integral1_n_68;
  wire integral1_n_69;
  wire integral1_n_70;
  wire integral1_n_71;
  wire integral1_n_72;
  wire integral1_n_73;
  wire integral1_n_74;
  wire integral1_n_75;
  wire integral1_n_76;
  wire integral1_n_77;
  wire integral1_n_78;
  wire integral1_n_79;
  wire integral1_n_80;
  wire integral1_n_81;
  wire integral1_n_82;
  wire integral1_n_83;
  wire integral1_n_84;
  wire integral1_n_85;
  wire integral1_n_86;
  wire integral1_n_87;
  wire integral1_n_88;
  wire integral1_n_89;
  wire integral1_n_90;
  wire integral1_n_91;
  wire integral1_n_92;
  wire integral1_n_93;
  wire integral1_n_94;
  wire integral1_n_95;
  wire integral1_n_96;
  wire integral1_n_97;
  wire integral1_n_98;
  wire integral1_n_99;
  wire [31:0]integral_in;
  wire [31:0]integral_out;
  wire new_target_angle_available;
  wire p_0_out;
  wire ps_ready_in;
  wire [0:0]ps_ready_out;
  wire saved_target_angle;
  wire \saved_target_angle_reg_n_0_[0] ;
  wire \saved_target_angle_reg_n_0_[10] ;
  wire \saved_target_angle_reg_n_0_[11] ;
  wire \saved_target_angle_reg_n_0_[12] ;
  wire \saved_target_angle_reg_n_0_[13] ;
  wire \saved_target_angle_reg_n_0_[14] ;
  wire \saved_target_angle_reg_n_0_[15] ;
  wire \saved_target_angle_reg_n_0_[16] ;
  wire \saved_target_angle_reg_n_0_[17] ;
  wire \saved_target_angle_reg_n_0_[18] ;
  wire \saved_target_angle_reg_n_0_[19] ;
  wire \saved_target_angle_reg_n_0_[1] ;
  wire \saved_target_angle_reg_n_0_[20] ;
  wire \saved_target_angle_reg_n_0_[21] ;
  wire \saved_target_angle_reg_n_0_[22] ;
  wire \saved_target_angle_reg_n_0_[23] ;
  wire \saved_target_angle_reg_n_0_[24] ;
  wire \saved_target_angle_reg_n_0_[25] ;
  wire \saved_target_angle_reg_n_0_[26] ;
  wire \saved_target_angle_reg_n_0_[27] ;
  wire \saved_target_angle_reg_n_0_[28] ;
  wire \saved_target_angle_reg_n_0_[29] ;
  wire \saved_target_angle_reg_n_0_[2] ;
  wire \saved_target_angle_reg_n_0_[30] ;
  wire \saved_target_angle_reg_n_0_[31] ;
  wire \saved_target_angle_reg_n_0_[3] ;
  wire \saved_target_angle_reg_n_0_[4] ;
  wire \saved_target_angle_reg_n_0_[5] ;
  wire \saved_target_angle_reg_n_0_[6] ;
  wire \saved_target_angle_reg_n_0_[7] ;
  wire \saved_target_angle_reg_n_0_[8] ;
  wire \saved_target_angle_reg_n_0_[9] ;
  wire [31:0]sel0;
  wire [31:0]target_angle;
  wire [31:0]timestamp_in;
  wire [31:0]timestamp_new;
  wire [31:0]timestamp_out;
  wire [3:3]NLW_derivative4_carry__6_CO_UNCONNECTED;
  wire [0:0]\NLW_derivative_reg[11]_i_142_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[11]_i_147_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[11]_i_152_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[11]_i_157_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[11]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[11]_i_6_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[11]_i_7_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[11]_i_7_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[11]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[11]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[11]_i_9_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[11]_i_9_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[15]_i_142_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[15]_i_147_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[15]_i_152_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[15]_i_157_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[15]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[15]_i_6_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[15]_i_7_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[15]_i_7_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[15]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[15]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[15]_i_9_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[15]_i_9_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[19]_i_142_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[19]_i_147_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[19]_i_152_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[19]_i_157_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[19]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[19]_i_6_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[19]_i_7_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[19]_i_7_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[19]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[19]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[19]_i_9_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[19]_i_9_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[23]_i_142_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[23]_i_147_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[23]_i_152_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[23]_i_157_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[23]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[23]_i_6_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[23]_i_7_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[23]_i_7_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[23]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[23]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[23]_i_9_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[23]_i_9_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[27]_i_142_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[27]_i_147_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[27]_i_152_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[27]_i_157_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[27]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[27]_i_6_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[27]_i_7_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[27]_i_7_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[27]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[27]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[27]_i_9_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[27]_i_9_O_UNCONNECTED ;
  wire [3:3]\NLW_derivative_reg[31]_i_2_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[31]_i_21_CO_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[31]_i_21_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[31]_i_22_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[31]_i_22_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[31]_i_23_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[31]_i_23_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[31]_i_238_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[31]_i_24_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[31]_i_24_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[31]_i_247_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[31]_i_252_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[31]_i_286_CO_UNCONNECTED ;
  wire [3:3]\NLW_derivative_reg[31]_i_286_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[31]_i_49_CO_UNCONNECTED ;
  wire [3:3]\NLW_derivative_reg[31]_i_49_O_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[3]_i_10_CO_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_117_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_137_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[3]_i_142_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[3]_i_147_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[3]_i_152_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_157_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_20_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_37_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_57_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[3]_i_7_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[3]_i_7_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_77_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[3]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[3]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[3]_i_9_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[3]_i_9_O_UNCONNECTED ;
  wire [3:0]\NLW_derivative_reg[3]_i_97_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[7]_i_142_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[7]_i_147_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[7]_i_152_O_UNCONNECTED ;
  wire [0:0]\NLW_derivative_reg[7]_i_157_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[7]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[7]_i_6_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[7]_i_7_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[7]_i_7_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[7]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[7]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_derivative_reg[7]_i_9_CO_UNCONNECTED ;
  wire [3:1]\NLW_derivative_reg[7]_i_9_O_UNCONNECTED ;
  wire [3:3]NLW_dt0_carry__6_CO_UNCONNECTED;
  wire [3:0]NLW_dt1_carry_O_UNCONNECTED;
  wire [3:0]NLW_dt1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_dt1_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_dt1_carry__2_O_UNCONNECTED;
  wire [3:3]NLW_error0_carry__6_CO_UNCONNECTED;
  wire [3:3]NLW_integral0_carry__6_CO_UNCONNECTED;
  wire NLW_integral1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_integral1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_integral1_OVERFLOW_UNCONNECTED;
  wire NLW_integral1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_integral1_PATTERNDETECT_UNCONNECTED;
  wire NLW_integral1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_integral1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_integral1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_integral1_CARRYOUT_UNCONNECTED;
  wire NLW_integral1__0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_integral1__0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_integral1__0_OVERFLOW_UNCONNECTED;
  wire NLW_integral1__0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_integral1__0_PATTERNDETECT_UNCONNECTED;
  wire NLW_integral1__0_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_integral1__0_ACOUT_UNCONNECTED;
  wire [17:0]NLW_integral1__0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_integral1__0_CARRYOUT_UNCONNECTED;
  wire NLW_integral1__1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_integral1__1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_integral1__1_OVERFLOW_UNCONNECTED;
  wire NLW_integral1__1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_integral1__1_PATTERNDETECT_UNCONNECTED;
  wire NLW_integral1__1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_integral1__1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_integral1__1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_integral1__1_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_integral1__1_PCOUT_UNCONNECTED;
  wire [3:3]NLW_integral1_carry__2_CO_UNCONNECTED;
  wire [3:2]NLW_integral1_i_16__0_CO_UNCONNECTED;
  wire [3:3]NLW_integral1_i_16__0_O_UNCONNECTED;

  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h7A)) 
    clock_count_i_1
       (.I0(ps_ready_out),
        .I1(new_target_angle_available),
        .I2(clock_count_reg_n_0),
        .O(clock_count_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    clock_count_reg
       (.C(clock),
        .CE(1'b1),
        .D(clock_count_i_1_n_0),
        .Q(clock_count_reg_n_0),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry
       (.CI(1'b0),
        .CO({derivative4_carry_n_0,derivative4_carry_n_1,derivative4_carry_n_2,derivative4_carry_n_3}),
        .CYINIT(1'b1),
        .DI(error_out[3:0]),
        .O(derivative4__93[3:0]),
        .S({derivative4_carry_i_1__6_n_0,derivative4_carry_i_2__6_n_0,derivative4_carry_i_3__6_n_0,derivative4_carry_i_4__6_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry__0
       (.CI(derivative4_carry_n_0),
        .CO({derivative4_carry__0_n_0,derivative4_carry__0_n_1,derivative4_carry__0_n_2,derivative4_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(error_out[7:4]),
        .O(derivative4__93[7:4]),
        .S({derivative4_carry_i_1__5_n_0,derivative4_carry_i_2__5_n_0,derivative4_carry_i_3__5_n_0,derivative4_carry_i_4__5_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry__1
       (.CI(derivative4_carry__0_n_0),
        .CO({derivative4_carry__1_n_0,derivative4_carry__1_n_1,derivative4_carry__1_n_2,derivative4_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(error_out[11:8]),
        .O(derivative4__93[11:8]),
        .S({derivative4_carry_i_1__4_n_0,derivative4_carry_i_2__4_n_0,derivative4_carry_i_3__4_n_0,derivative4_carry_i_4__4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry__2
       (.CI(derivative4_carry__1_n_0),
        .CO({derivative4_carry__2_n_0,derivative4_carry__2_n_1,derivative4_carry__2_n_2,derivative4_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(error_out[15:12]),
        .O(derivative4__93[15:12]),
        .S({derivative4_carry_i_1__3_n_0,derivative4_carry_i_2__3_n_0,derivative4_carry_i_3__3_n_0,derivative4_carry_i_4__3_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry__3
       (.CI(derivative4_carry__2_n_0),
        .CO({derivative4_carry__3_n_0,derivative4_carry__3_n_1,derivative4_carry__3_n_2,derivative4_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(error_out[19:16]),
        .O(derivative4__93[19:16]),
        .S({derivative4_carry_i_1__2_n_0,derivative4_carry_i_2__2_n_0,derivative4_carry_i_3__2_n_0,derivative4_carry_i_4__2_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry__4
       (.CI(derivative4_carry__3_n_0),
        .CO({derivative4_carry__4_n_0,derivative4_carry__4_n_1,derivative4_carry__4_n_2,derivative4_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(error_out[23:20]),
        .O(derivative4__93[23:20]),
        .S({derivative4_carry_i_1__1_n_0,derivative4_carry_i_2__1_n_0,derivative4_carry_i_3__1_n_0,derivative4_carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry__5
       (.CI(derivative4_carry__4_n_0),
        .CO({derivative4_carry__5_n_0,derivative4_carry__5_n_1,derivative4_carry__5_n_2,derivative4_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(error_out[27:24]),
        .O(derivative4__93[27:24]),
        .S({derivative4_carry_i_1__0_n_0,derivative4_carry_i_2__0_n_0,derivative4_carry_i_3__0_n_0,derivative4_carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 derivative4_carry__6
       (.CI(derivative4_carry__5_n_0),
        .CO({NLW_derivative4_carry__6_CO_UNCONNECTED[3],derivative4_carry__6_n_1,derivative4_carry__6_n_2,derivative4_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,error_out[30:28]}),
        .O(derivative4__93[31:28]),
        .S({derivative4_carry_i_1_n_0,derivative4_carry_i_2_n_0,derivative4_carry_i_3_n_0,derivative4_carry_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1
       (.I0(error_out[31]),
        .I1(error_in[31]),
        .O(derivative4_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1__0
       (.I0(error_out[27]),
        .I1(error_in[27]),
        .O(derivative4_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1__1
       (.I0(error_out[23]),
        .I1(error_in[23]),
        .O(derivative4_carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1__2
       (.I0(error_out[19]),
        .I1(error_in[19]),
        .O(derivative4_carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1__3
       (.I0(error_out[15]),
        .I1(error_in[15]),
        .O(derivative4_carry_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1__4
       (.I0(error_out[11]),
        .I1(error_in[11]),
        .O(derivative4_carry_i_1__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1__5
       (.I0(error_out[7]),
        .I1(error_in[7]),
        .O(derivative4_carry_i_1__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_1__6
       (.I0(error_out[3]),
        .I1(error_in[3]),
        .O(derivative4_carry_i_1__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2
       (.I0(error_out[30]),
        .I1(error_in[30]),
        .O(derivative4_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2__0
       (.I0(error_out[26]),
        .I1(error_in[26]),
        .O(derivative4_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2__1
       (.I0(error_out[22]),
        .I1(error_in[22]),
        .O(derivative4_carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2__2
       (.I0(error_out[18]),
        .I1(error_in[18]),
        .O(derivative4_carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2__3
       (.I0(error_out[14]),
        .I1(error_in[14]),
        .O(derivative4_carry_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2__4
       (.I0(error_out[10]),
        .I1(error_in[10]),
        .O(derivative4_carry_i_2__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2__5
       (.I0(error_out[6]),
        .I1(error_in[6]),
        .O(derivative4_carry_i_2__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_2__6
       (.I0(error_out[2]),
        .I1(error_in[2]),
        .O(derivative4_carry_i_2__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3
       (.I0(error_out[29]),
        .I1(error_in[29]),
        .O(derivative4_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3__0
       (.I0(error_out[25]),
        .I1(error_in[25]),
        .O(derivative4_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3__1
       (.I0(error_out[21]),
        .I1(error_in[21]),
        .O(derivative4_carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3__2
       (.I0(error_out[17]),
        .I1(error_in[17]),
        .O(derivative4_carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3__3
       (.I0(error_out[13]),
        .I1(error_in[13]),
        .O(derivative4_carry_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3__4
       (.I0(error_out[9]),
        .I1(error_in[9]),
        .O(derivative4_carry_i_3__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3__5
       (.I0(error_out[5]),
        .I1(error_in[5]),
        .O(derivative4_carry_i_3__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_3__6
       (.I0(error_out[1]),
        .I1(error_in[1]),
        .O(derivative4_carry_i_3__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4
       (.I0(error_out[28]),
        .I1(error_in[28]),
        .O(derivative4_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4__0
       (.I0(error_out[24]),
        .I1(error_in[24]),
        .O(derivative4_carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4__1
       (.I0(error_out[20]),
        .I1(error_in[20]),
        .O(derivative4_carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4__2
       (.I0(error_out[16]),
        .I1(error_in[16]),
        .O(derivative4_carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4__3
       (.I0(error_out[12]),
        .I1(error_in[12]),
        .O(derivative4_carry_i_4__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4__4
       (.I0(error_out[8]),
        .I1(error_in[8]),
        .O(derivative4_carry_i_4__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4__5
       (.I0(error_out[4]),
        .I1(error_in[4]),
        .O(derivative4_carry_i_4__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    derivative4_carry_i_4__6
       (.I0(error_out[0]),
        .I1(error_in[0]),
        .O(derivative4_carry_i_4__6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_100 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[11]_i_72_n_7 ),
        .O(\derivative[11]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_101 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[11]_i_92_n_4 ),
        .O(\derivative[11]_i_101_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_103 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[15]_i_97_n_5 ),
        .O(\derivative[11]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_104 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[15]_i_97_n_6 ),
        .O(\derivative[11]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_105 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[15]_i_97_n_7 ),
        .O(\derivative[11]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_106 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[15]_i_117_n_4 ),
        .O(\derivative[11]_i_106_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_108 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[11]_i_82_n_5 ),
        .O(\derivative[11]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_109 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[11]_i_82_n_6 ),
        .O(\derivative[11]_i_109_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[11]_i_11 
       (.I0(derivative1[12]),
        .I1(\derivative_reg[15]_i_9_n_7 ),
        .O(\derivative[11]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_110 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[11]_i_82_n_7 ),
        .O(\derivative[11]_i_110_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_111 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[11]_i_102_n_4 ),
        .O(\derivative[11]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_113 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[11]_i_87_n_5 ),
        .O(\derivative[11]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_114 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[11]_i_87_n_6 ),
        .O(\derivative[11]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_115 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[11]_i_87_n_7 ),
        .O(\derivative[11]_i_115_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_116 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[11]_i_107_n_4 ),
        .O(\derivative[11]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_118 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[11]_i_92_n_5 ),
        .O(\derivative[11]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_119 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[11]_i_92_n_6 ),
        .O(\derivative[11]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[11]_i_12 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[12]),
        .I5(\derivative_reg[15]_i_19_n_4 ),
        .O(\derivative[11]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_120 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[11]_i_92_n_7 ),
        .O(\derivative[11]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_121 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[11]_i_112_n_4 ),
        .O(\derivative[11]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_123 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[15]_i_117_n_5 ),
        .O(\derivative[11]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_124 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[15]_i_117_n_6 ),
        .O(\derivative[11]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_125 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[15]_i_117_n_7 ),
        .O(\derivative[11]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_126 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[15]_i_137_n_4 ),
        .O(\derivative[11]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_128 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[11]_i_102_n_5 ),
        .O(\derivative[11]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_129 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[11]_i_102_n_6 ),
        .O(\derivative[11]_i_129_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_130 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[11]_i_102_n_7 ),
        .O(\derivative[11]_i_130_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_131 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[11]_i_122_n_4 ),
        .O(\derivative[11]_i_131_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_133 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[11]_i_107_n_5 ),
        .O(\derivative[11]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_134 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[11]_i_107_n_6 ),
        .O(\derivative[11]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_135 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[11]_i_107_n_7 ),
        .O(\derivative[11]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_136 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[11]_i_127_n_4 ),
        .O(\derivative[11]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_138 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[11]_i_112_n_5 ),
        .O(\derivative[11]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_139 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[11]_i_112_n_6 ),
        .O(\derivative[11]_i_139_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[11]_i_14 
       (.I0(derivative1[11]),
        .I1(\derivative_reg[11]_i_6_n_7 ),
        .O(\derivative[11]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_140 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[11]_i_112_n_7 ),
        .O(\derivative[11]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_141 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[11]_i_132_n_4 ),
        .O(\derivative[11]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_143 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[15]_i_137_n_5 ),
        .O(\derivative[11]_i_143_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_144 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[15]_i_137_n_6 ),
        .O(\derivative[11]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_145 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[15]_i_137_n_7 ),
        .O(\derivative[11]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_146 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[15]_i_157_n_4 ),
        .O(\derivative[11]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_148 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[11]_i_122_n_5 ),
        .O(\derivative[11]_i_148_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_149 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[11]_i_122_n_6 ),
        .O(\derivative[11]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[11]_i_15 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[11]),
        .I5(\derivative_reg[11]_i_10_n_4 ),
        .O(\derivative[11]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_150 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[11]_i_122_n_7 ),
        .O(\derivative[11]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_151 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[11]_i_142_n_4 ),
        .O(\derivative[11]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_153 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[11]_i_127_n_5 ),
        .O(\derivative[11]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_154 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[11]_i_127_n_6 ),
        .O(\derivative[11]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_155 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[11]_i_127_n_7 ),
        .O(\derivative[11]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_156 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[11]_i_147_n_4 ),
        .O(\derivative[11]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_158 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[11]_i_132_n_5 ),
        .O(\derivative[11]_i_158_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_159 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[11]_i_132_n_6 ),
        .O(\derivative[11]_i_159_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_160 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[11]_i_132_n_7 ),
        .O(\derivative[11]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_161 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[11]_i_152_n_4 ),
        .O(\derivative[11]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[11]_i_162 
       (.I0(\derivative_reg[15]_i_178_n_5 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[11]),
        .O(derivative20_in[11]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_163 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[15]_i_157_n_5 ),
        .O(\derivative[11]_i_163_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_164 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[15]_i_157_n_6 ),
        .O(\derivative[11]_i_164_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[11]_i_165 
       (.I0(derivative1[12]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[11]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[15]_i_178_n_5 ),
        .O(\derivative[11]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[11]_i_166 
       (.I0(\derivative_reg[15]_i_178_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[10]),
        .O(derivative20_in[10]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_167 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[11]_i_142_n_5 ),
        .O(\derivative[11]_i_167_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_168 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[11]_i_142_n_6 ),
        .O(\derivative[11]_i_168_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[11]_i_169 
       (.I0(derivative1[11]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[10]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[15]_i_178_n_6 ),
        .O(\derivative[11]_i_169_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[11]_i_17 
       (.I0(derivative1[10]),
        .I1(\derivative_reg[11]_i_7_n_7 ),
        .O(\derivative[11]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[11]_i_170 
       (.I0(\derivative_reg[15]_i_178_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[9]),
        .O(derivative20_in[9]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_171 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[11]_i_147_n_5 ),
        .O(\derivative[11]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_172 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[11]_i_147_n_6 ),
        .O(\derivative[11]_i_172_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[11]_i_173 
       (.I0(derivative1[10]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[9]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[15]_i_178_n_7 ),
        .O(\derivative[11]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[11]_i_174 
       (.I0(\derivative_reg[11]_i_178_n_4 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[8]),
        .O(derivative20_in[8]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_175 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[11]_i_152_n_5 ),
        .O(\derivative[11]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_176 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[11]_i_152_n_6 ),
        .O(\derivative[11]_i_176_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[11]_i_177 
       (.I0(derivative1[9]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[8]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[11]_i_178_n_4 ),
        .O(\derivative[11]_i_177_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[11]_i_179 
       (.I0(derivative4__93[8]),
        .O(\derivative[11]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[11]_i_18 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[10]),
        .I5(\derivative_reg[11]_i_13_n_4 ),
        .O(\derivative[11]_i_18_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[11]_i_180 
       (.I0(derivative4__93[7]),
        .O(\derivative[11]_i_180_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[11]_i_181 
       (.I0(derivative4__93[6]),
        .O(\derivative[11]_i_181_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[11]_i_182 
       (.I0(derivative4__93[5]),
        .O(\derivative[11]_i_182_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[11]_i_2 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[11]),
        .O(\derivative[11]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[11]_i_20 
       (.I0(derivative1[9]),
        .I1(\derivative_reg[11]_i_8_n_7 ),
        .O(\derivative[11]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[11]_i_21 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[9]),
        .I5(\derivative_reg[11]_i_16_n_4 ),
        .O(\derivative[11]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_23 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[15]_i_19_n_5 ),
        .O(\derivative[11]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_24 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[15]_i_19_n_6 ),
        .O(\derivative[11]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_25 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[15]_i_19_n_7 ),
        .O(\derivative[11]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_26 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[15]_i_37_n_4 ),
        .O(\derivative[11]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_28 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[11]_i_10_n_5 ),
        .O(\derivative[11]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_29 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[11]_i_10_n_6 ),
        .O(\derivative[11]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[11]_i_3 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[10]),
        .O(\derivative[11]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_30 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[11]_i_10_n_7 ),
        .O(\derivative[11]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_31 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[11]_i_22_n_4 ),
        .O(\derivative[11]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_33 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[11]_i_13_n_5 ),
        .O(\derivative[11]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_34 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[11]_i_13_n_6 ),
        .O(\derivative[11]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_35 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[11]_i_13_n_7 ),
        .O(\derivative[11]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_36 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[11]_i_27_n_4 ),
        .O(\derivative[11]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_38 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[11]_i_16_n_5 ),
        .O(\derivative[11]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_39 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[11]_i_16_n_6 ),
        .O(\derivative[11]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[11]_i_4 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[9]),
        .O(\derivative[11]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_40 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[11]_i_16_n_7 ),
        .O(\derivative[11]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_41 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[11]_i_32_n_4 ),
        .O(\derivative[11]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_43 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[15]_i_37_n_5 ),
        .O(\derivative[11]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_44 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[15]_i_37_n_6 ),
        .O(\derivative[11]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_45 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[15]_i_37_n_7 ),
        .O(\derivative[11]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_46 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[15]_i_57_n_4 ),
        .O(\derivative[11]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_48 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[11]_i_22_n_5 ),
        .O(\derivative[11]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_49 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[11]_i_22_n_6 ),
        .O(\derivative[11]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[11]_i_5 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[8]),
        .O(\derivative[11]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_50 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[11]_i_22_n_7 ),
        .O(\derivative[11]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_51 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[11]_i_42_n_4 ),
        .O(\derivative[11]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_53 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[11]_i_27_n_5 ),
        .O(\derivative[11]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_54 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[11]_i_27_n_6 ),
        .O(\derivative[11]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_55 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[11]_i_27_n_7 ),
        .O(\derivative[11]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_56 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[11]_i_47_n_4 ),
        .O(\derivative[11]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_58 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[11]_i_32_n_5 ),
        .O(\derivative[11]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_59 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[11]_i_32_n_6 ),
        .O(\derivative[11]_i_59_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_60 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[11]_i_32_n_7 ),
        .O(\derivative[11]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_61 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[11]_i_52_n_4 ),
        .O(\derivative[11]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_63 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[15]_i_57_n_5 ),
        .O(\derivative[11]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_64 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[15]_i_57_n_6 ),
        .O(\derivative[11]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_65 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[15]_i_57_n_7 ),
        .O(\derivative[11]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_66 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[15]_i_77_n_4 ),
        .O(\derivative[11]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_68 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[11]_i_42_n_5 ),
        .O(\derivative[11]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_69 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[11]_i_42_n_6 ),
        .O(\derivative[11]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_70 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[11]_i_42_n_7 ),
        .O(\derivative[11]_i_70_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_71 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[11]_i_62_n_4 ),
        .O(\derivative[11]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_73 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[11]_i_47_n_5 ),
        .O(\derivative[11]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_74 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[11]_i_47_n_6 ),
        .O(\derivative[11]_i_74_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_75 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[11]_i_47_n_7 ),
        .O(\derivative[11]_i_75_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_76 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[11]_i_67_n_4 ),
        .O(\derivative[11]_i_76_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_78 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[11]_i_52_n_5 ),
        .O(\derivative[11]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_79 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[11]_i_52_n_6 ),
        .O(\derivative[11]_i_79_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_80 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[11]_i_52_n_7 ),
        .O(\derivative[11]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_81 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[11]_i_72_n_4 ),
        .O(\derivative[11]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_83 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[15]_i_77_n_5 ),
        .O(\derivative[11]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_84 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[15]_i_77_n_6 ),
        .O(\derivative[11]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_85 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[15]_i_77_n_7 ),
        .O(\derivative[11]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_86 
       (.I0(derivative1[12]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[15]_i_97_n_4 ),
        .O(\derivative[11]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_88 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[11]_i_62_n_5 ),
        .O(\derivative[11]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_89 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[11]_i_62_n_6 ),
        .O(\derivative[11]_i_89_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_90 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[11]_i_62_n_7 ),
        .O(\derivative[11]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_91 
       (.I0(derivative1[11]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[11]_i_82_n_4 ),
        .O(\derivative[11]_i_91_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_93 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[11]_i_67_n_5 ),
        .O(\derivative[11]_i_93_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_94 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[11]_i_67_n_6 ),
        .O(\derivative[11]_i_94_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_95 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[11]_i_67_n_7 ),
        .O(\derivative[11]_i_95_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_96 
       (.I0(derivative1[10]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[11]_i_87_n_4 ),
        .O(\derivative[11]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_98 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[11]_i_72_n_5 ),
        .O(\derivative[11]_i_98_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[11]_i_99 
       (.I0(derivative1[9]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[11]_i_72_n_6 ),
        .O(\derivative[11]_i_99_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_100 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[15]_i_72_n_7 ),
        .O(\derivative[15]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_101 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[15]_i_92_n_4 ),
        .O(\derivative[15]_i_101_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_103 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[19]_i_97_n_5 ),
        .O(\derivative[15]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_104 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[19]_i_97_n_6 ),
        .O(\derivative[15]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_105 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[19]_i_97_n_7 ),
        .O(\derivative[15]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_106 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[19]_i_117_n_4 ),
        .O(\derivative[15]_i_106_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_108 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[15]_i_82_n_5 ),
        .O(\derivative[15]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_109 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[15]_i_82_n_6 ),
        .O(\derivative[15]_i_109_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[15]_i_11 
       (.I0(derivative1[16]),
        .I1(\derivative_reg[19]_i_9_n_7 ),
        .O(\derivative[15]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_110 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[15]_i_82_n_7 ),
        .O(\derivative[15]_i_110_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_111 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[15]_i_102_n_4 ),
        .O(\derivative[15]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_113 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[15]_i_87_n_5 ),
        .O(\derivative[15]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_114 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[15]_i_87_n_6 ),
        .O(\derivative[15]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_115 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[15]_i_87_n_7 ),
        .O(\derivative[15]_i_115_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_116 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[15]_i_107_n_4 ),
        .O(\derivative[15]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_118 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[15]_i_92_n_5 ),
        .O(\derivative[15]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_119 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[15]_i_92_n_6 ),
        .O(\derivative[15]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[15]_i_12 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[16]),
        .I5(\derivative_reg[19]_i_19_n_4 ),
        .O(\derivative[15]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_120 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[15]_i_92_n_7 ),
        .O(\derivative[15]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_121 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[15]_i_112_n_4 ),
        .O(\derivative[15]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_123 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[19]_i_117_n_5 ),
        .O(\derivative[15]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_124 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[19]_i_117_n_6 ),
        .O(\derivative[15]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_125 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[19]_i_117_n_7 ),
        .O(\derivative[15]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_126 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[19]_i_137_n_4 ),
        .O(\derivative[15]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_128 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[15]_i_102_n_5 ),
        .O(\derivative[15]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_129 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[15]_i_102_n_6 ),
        .O(\derivative[15]_i_129_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_130 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[15]_i_102_n_7 ),
        .O(\derivative[15]_i_130_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_131 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[15]_i_122_n_4 ),
        .O(\derivative[15]_i_131_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_133 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[15]_i_107_n_5 ),
        .O(\derivative[15]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_134 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[15]_i_107_n_6 ),
        .O(\derivative[15]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_135 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[15]_i_107_n_7 ),
        .O(\derivative[15]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_136 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[15]_i_127_n_4 ),
        .O(\derivative[15]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_138 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[15]_i_112_n_5 ),
        .O(\derivative[15]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_139 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[15]_i_112_n_6 ),
        .O(\derivative[15]_i_139_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[15]_i_14 
       (.I0(derivative1[15]),
        .I1(\derivative_reg[15]_i_6_n_7 ),
        .O(\derivative[15]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_140 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[15]_i_112_n_7 ),
        .O(\derivative[15]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_141 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[15]_i_132_n_4 ),
        .O(\derivative[15]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_143 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[19]_i_137_n_5 ),
        .O(\derivative[15]_i_143_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_144 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[19]_i_137_n_6 ),
        .O(\derivative[15]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_145 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[19]_i_137_n_7 ),
        .O(\derivative[15]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_146 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[19]_i_157_n_4 ),
        .O(\derivative[15]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_148 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[15]_i_122_n_5 ),
        .O(\derivative[15]_i_148_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_149 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[15]_i_122_n_6 ),
        .O(\derivative[15]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[15]_i_15 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[15]),
        .I5(\derivative_reg[15]_i_10_n_4 ),
        .O(\derivative[15]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_150 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[15]_i_122_n_7 ),
        .O(\derivative[15]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_151 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[15]_i_142_n_4 ),
        .O(\derivative[15]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_153 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[15]_i_127_n_5 ),
        .O(\derivative[15]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_154 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[15]_i_127_n_6 ),
        .O(\derivative[15]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_155 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[15]_i_127_n_7 ),
        .O(\derivative[15]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_156 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[15]_i_147_n_4 ),
        .O(\derivative[15]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_158 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[15]_i_132_n_5 ),
        .O(\derivative[15]_i_158_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_159 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[15]_i_132_n_6 ),
        .O(\derivative[15]_i_159_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_160 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[15]_i_132_n_7 ),
        .O(\derivative[15]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_161 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[15]_i_152_n_4 ),
        .O(\derivative[15]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[15]_i_162 
       (.I0(\derivative_reg[19]_i_178_n_5 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[15]),
        .O(derivative20_in[15]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_163 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[19]_i_157_n_5 ),
        .O(\derivative[15]_i_163_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_164 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[19]_i_157_n_6 ),
        .O(\derivative[15]_i_164_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[15]_i_165 
       (.I0(derivative1[16]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[15]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[19]_i_178_n_5 ),
        .O(\derivative[15]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[15]_i_166 
       (.I0(\derivative_reg[19]_i_178_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[14]),
        .O(derivative20_in[14]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_167 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[15]_i_142_n_5 ),
        .O(\derivative[15]_i_167_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_168 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[15]_i_142_n_6 ),
        .O(\derivative[15]_i_168_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[15]_i_169 
       (.I0(derivative1[15]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[14]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[19]_i_178_n_6 ),
        .O(\derivative[15]_i_169_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[15]_i_17 
       (.I0(derivative1[14]),
        .I1(\derivative_reg[15]_i_7_n_7 ),
        .O(\derivative[15]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[15]_i_170 
       (.I0(\derivative_reg[19]_i_178_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[13]),
        .O(derivative20_in[13]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_171 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[15]_i_147_n_5 ),
        .O(\derivative[15]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_172 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[15]_i_147_n_6 ),
        .O(\derivative[15]_i_172_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[15]_i_173 
       (.I0(derivative1[14]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[13]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[19]_i_178_n_7 ),
        .O(\derivative[15]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[15]_i_174 
       (.I0(\derivative_reg[15]_i_178_n_4 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[12]),
        .O(derivative20_in[12]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_175 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[15]_i_152_n_5 ),
        .O(\derivative[15]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_176 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[15]_i_152_n_6 ),
        .O(\derivative[15]_i_176_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[15]_i_177 
       (.I0(derivative1[13]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[12]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[15]_i_178_n_4 ),
        .O(\derivative[15]_i_177_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[15]_i_179 
       (.I0(derivative4__93[12]),
        .O(\derivative[15]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[15]_i_18 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[14]),
        .I5(\derivative_reg[15]_i_13_n_4 ),
        .O(\derivative[15]_i_18_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[15]_i_180 
       (.I0(derivative4__93[11]),
        .O(\derivative[15]_i_180_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[15]_i_181 
       (.I0(derivative4__93[10]),
        .O(\derivative[15]_i_181_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[15]_i_182 
       (.I0(derivative4__93[9]),
        .O(\derivative[15]_i_182_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[15]_i_2 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[15]),
        .O(\derivative[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[15]_i_20 
       (.I0(derivative1[13]),
        .I1(\derivative_reg[15]_i_8_n_7 ),
        .O(\derivative[15]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[15]_i_21 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[13]),
        .I5(\derivative_reg[15]_i_16_n_4 ),
        .O(\derivative[15]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_23 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[19]_i_19_n_5 ),
        .O(\derivative[15]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_24 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[19]_i_19_n_6 ),
        .O(\derivative[15]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_25 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[19]_i_19_n_7 ),
        .O(\derivative[15]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_26 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[19]_i_37_n_4 ),
        .O(\derivative[15]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_28 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[15]_i_10_n_5 ),
        .O(\derivative[15]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_29 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[15]_i_10_n_6 ),
        .O(\derivative[15]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[15]_i_3 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[14]),
        .O(\derivative[15]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_30 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[15]_i_10_n_7 ),
        .O(\derivative[15]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_31 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[15]_i_22_n_4 ),
        .O(\derivative[15]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_33 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[15]_i_13_n_5 ),
        .O(\derivative[15]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_34 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[15]_i_13_n_6 ),
        .O(\derivative[15]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_35 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[15]_i_13_n_7 ),
        .O(\derivative[15]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_36 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[15]_i_27_n_4 ),
        .O(\derivative[15]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_38 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[15]_i_16_n_5 ),
        .O(\derivative[15]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_39 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[15]_i_16_n_6 ),
        .O(\derivative[15]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[15]_i_4 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[13]),
        .O(\derivative[15]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_40 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[15]_i_16_n_7 ),
        .O(\derivative[15]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_41 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[15]_i_32_n_4 ),
        .O(\derivative[15]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_43 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[19]_i_37_n_5 ),
        .O(\derivative[15]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_44 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[19]_i_37_n_6 ),
        .O(\derivative[15]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_45 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[19]_i_37_n_7 ),
        .O(\derivative[15]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_46 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[19]_i_57_n_4 ),
        .O(\derivative[15]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_48 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[15]_i_22_n_5 ),
        .O(\derivative[15]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_49 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[15]_i_22_n_6 ),
        .O(\derivative[15]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[15]_i_5 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[12]),
        .O(\derivative[15]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_50 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[15]_i_22_n_7 ),
        .O(\derivative[15]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_51 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[15]_i_42_n_4 ),
        .O(\derivative[15]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_53 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[15]_i_27_n_5 ),
        .O(\derivative[15]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_54 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[15]_i_27_n_6 ),
        .O(\derivative[15]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_55 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[15]_i_27_n_7 ),
        .O(\derivative[15]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_56 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[15]_i_47_n_4 ),
        .O(\derivative[15]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_58 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[15]_i_32_n_5 ),
        .O(\derivative[15]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_59 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[15]_i_32_n_6 ),
        .O(\derivative[15]_i_59_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_60 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[15]_i_32_n_7 ),
        .O(\derivative[15]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_61 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[15]_i_52_n_4 ),
        .O(\derivative[15]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_63 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[19]_i_57_n_5 ),
        .O(\derivative[15]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_64 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[19]_i_57_n_6 ),
        .O(\derivative[15]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_65 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[19]_i_57_n_7 ),
        .O(\derivative[15]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_66 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[19]_i_77_n_4 ),
        .O(\derivative[15]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_68 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[15]_i_42_n_5 ),
        .O(\derivative[15]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_69 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[15]_i_42_n_6 ),
        .O(\derivative[15]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_70 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[15]_i_42_n_7 ),
        .O(\derivative[15]_i_70_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_71 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[15]_i_62_n_4 ),
        .O(\derivative[15]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_73 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[15]_i_47_n_5 ),
        .O(\derivative[15]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_74 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[15]_i_47_n_6 ),
        .O(\derivative[15]_i_74_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_75 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[15]_i_47_n_7 ),
        .O(\derivative[15]_i_75_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_76 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[15]_i_67_n_4 ),
        .O(\derivative[15]_i_76_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_78 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[15]_i_52_n_5 ),
        .O(\derivative[15]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_79 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[15]_i_52_n_6 ),
        .O(\derivative[15]_i_79_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_80 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[15]_i_52_n_7 ),
        .O(\derivative[15]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_81 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[15]_i_72_n_4 ),
        .O(\derivative[15]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_83 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[19]_i_77_n_5 ),
        .O(\derivative[15]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_84 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[19]_i_77_n_6 ),
        .O(\derivative[15]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_85 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[19]_i_77_n_7 ),
        .O(\derivative[15]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_86 
       (.I0(derivative1[16]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[19]_i_97_n_4 ),
        .O(\derivative[15]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_88 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[15]_i_62_n_5 ),
        .O(\derivative[15]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_89 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[15]_i_62_n_6 ),
        .O(\derivative[15]_i_89_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_90 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[15]_i_62_n_7 ),
        .O(\derivative[15]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_91 
       (.I0(derivative1[15]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[15]_i_82_n_4 ),
        .O(\derivative[15]_i_91_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_93 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[15]_i_67_n_5 ),
        .O(\derivative[15]_i_93_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_94 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[15]_i_67_n_6 ),
        .O(\derivative[15]_i_94_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_95 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[15]_i_67_n_7 ),
        .O(\derivative[15]_i_95_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_96 
       (.I0(derivative1[14]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[15]_i_87_n_4 ),
        .O(\derivative[15]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_98 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[15]_i_72_n_5 ),
        .O(\derivative[15]_i_98_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[15]_i_99 
       (.I0(derivative1[13]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[15]_i_72_n_6 ),
        .O(\derivative[15]_i_99_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_100 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[19]_i_72_n_7 ),
        .O(\derivative[19]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_101 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[19]_i_92_n_4 ),
        .O(\derivative[19]_i_101_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_103 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[23]_i_97_n_5 ),
        .O(\derivative[19]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_104 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[23]_i_97_n_6 ),
        .O(\derivative[19]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_105 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[23]_i_97_n_7 ),
        .O(\derivative[19]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_106 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[23]_i_117_n_4 ),
        .O(\derivative[19]_i_106_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_108 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[19]_i_82_n_5 ),
        .O(\derivative[19]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_109 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[19]_i_82_n_6 ),
        .O(\derivative[19]_i_109_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[19]_i_11 
       (.I0(derivative1[20]),
        .I1(\derivative_reg[23]_i_9_n_7 ),
        .O(\derivative[19]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_110 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[19]_i_82_n_7 ),
        .O(\derivative[19]_i_110_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_111 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[19]_i_102_n_4 ),
        .O(\derivative[19]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_113 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[19]_i_87_n_5 ),
        .O(\derivative[19]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_114 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[19]_i_87_n_6 ),
        .O(\derivative[19]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_115 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[19]_i_87_n_7 ),
        .O(\derivative[19]_i_115_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_116 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[19]_i_107_n_4 ),
        .O(\derivative[19]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_118 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[19]_i_92_n_5 ),
        .O(\derivative[19]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_119 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[19]_i_92_n_6 ),
        .O(\derivative[19]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[19]_i_12 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[20]),
        .I5(\derivative_reg[23]_i_19_n_4 ),
        .O(\derivative[19]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_120 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[19]_i_92_n_7 ),
        .O(\derivative[19]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_121 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[19]_i_112_n_4 ),
        .O(\derivative[19]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_123 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[23]_i_117_n_5 ),
        .O(\derivative[19]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_124 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[23]_i_117_n_6 ),
        .O(\derivative[19]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_125 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[23]_i_117_n_7 ),
        .O(\derivative[19]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_126 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[23]_i_137_n_4 ),
        .O(\derivative[19]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_128 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[19]_i_102_n_5 ),
        .O(\derivative[19]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_129 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[19]_i_102_n_6 ),
        .O(\derivative[19]_i_129_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_130 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[19]_i_102_n_7 ),
        .O(\derivative[19]_i_130_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_131 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[19]_i_122_n_4 ),
        .O(\derivative[19]_i_131_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_133 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[19]_i_107_n_5 ),
        .O(\derivative[19]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_134 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[19]_i_107_n_6 ),
        .O(\derivative[19]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_135 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[19]_i_107_n_7 ),
        .O(\derivative[19]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_136 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[19]_i_127_n_4 ),
        .O(\derivative[19]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_138 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[19]_i_112_n_5 ),
        .O(\derivative[19]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_139 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[19]_i_112_n_6 ),
        .O(\derivative[19]_i_139_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[19]_i_14 
       (.I0(derivative1[19]),
        .I1(\derivative_reg[19]_i_6_n_7 ),
        .O(\derivative[19]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_140 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[19]_i_112_n_7 ),
        .O(\derivative[19]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_141 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[19]_i_132_n_4 ),
        .O(\derivative[19]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_143 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[23]_i_137_n_5 ),
        .O(\derivative[19]_i_143_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_144 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[23]_i_137_n_6 ),
        .O(\derivative[19]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_145 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[23]_i_137_n_7 ),
        .O(\derivative[19]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_146 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[23]_i_157_n_4 ),
        .O(\derivative[19]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_148 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[19]_i_122_n_5 ),
        .O(\derivative[19]_i_148_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_149 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[19]_i_122_n_6 ),
        .O(\derivative[19]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[19]_i_15 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[19]),
        .I5(\derivative_reg[19]_i_10_n_4 ),
        .O(\derivative[19]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_150 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[19]_i_122_n_7 ),
        .O(\derivative[19]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_151 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[19]_i_142_n_4 ),
        .O(\derivative[19]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_153 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[19]_i_127_n_5 ),
        .O(\derivative[19]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_154 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[19]_i_127_n_6 ),
        .O(\derivative[19]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_155 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[19]_i_127_n_7 ),
        .O(\derivative[19]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_156 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[19]_i_147_n_4 ),
        .O(\derivative[19]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_158 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[19]_i_132_n_5 ),
        .O(\derivative[19]_i_158_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_159 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[19]_i_132_n_6 ),
        .O(\derivative[19]_i_159_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_160 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[19]_i_132_n_7 ),
        .O(\derivative[19]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_161 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[19]_i_152_n_4 ),
        .O(\derivative[19]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[19]_i_162 
       (.I0(\derivative_reg[23]_i_178_n_5 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[19]),
        .O(derivative20_in[19]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_163 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[23]_i_157_n_5 ),
        .O(\derivative[19]_i_163_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_164 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[23]_i_157_n_6 ),
        .O(\derivative[19]_i_164_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[19]_i_165 
       (.I0(derivative1[20]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[19]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[23]_i_178_n_5 ),
        .O(\derivative[19]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[19]_i_166 
       (.I0(\derivative_reg[23]_i_178_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[18]),
        .O(derivative20_in[18]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_167 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[19]_i_142_n_5 ),
        .O(\derivative[19]_i_167_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_168 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[19]_i_142_n_6 ),
        .O(\derivative[19]_i_168_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[19]_i_169 
       (.I0(derivative1[19]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[18]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[23]_i_178_n_6 ),
        .O(\derivative[19]_i_169_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[19]_i_17 
       (.I0(derivative1[18]),
        .I1(\derivative_reg[19]_i_7_n_7 ),
        .O(\derivative[19]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[19]_i_170 
       (.I0(\derivative_reg[23]_i_178_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[17]),
        .O(derivative20_in[17]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_171 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[19]_i_147_n_5 ),
        .O(\derivative[19]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_172 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[19]_i_147_n_6 ),
        .O(\derivative[19]_i_172_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[19]_i_173 
       (.I0(derivative1[18]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[17]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[23]_i_178_n_7 ),
        .O(\derivative[19]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[19]_i_174 
       (.I0(\derivative_reg[19]_i_178_n_4 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[16]),
        .O(derivative20_in[16]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_175 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[19]_i_152_n_5 ),
        .O(\derivative[19]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_176 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[19]_i_152_n_6 ),
        .O(\derivative[19]_i_176_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[19]_i_177 
       (.I0(derivative1[17]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[16]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[19]_i_178_n_4 ),
        .O(\derivative[19]_i_177_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[19]_i_179 
       (.I0(derivative4__93[16]),
        .O(\derivative[19]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[19]_i_18 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[18]),
        .I5(\derivative_reg[19]_i_13_n_4 ),
        .O(\derivative[19]_i_18_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[19]_i_180 
       (.I0(derivative4__93[15]),
        .O(\derivative[19]_i_180_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[19]_i_181 
       (.I0(derivative4__93[14]),
        .O(\derivative[19]_i_181_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[19]_i_182 
       (.I0(derivative4__93[13]),
        .O(\derivative[19]_i_182_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[19]_i_2 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[19]),
        .O(\derivative[19]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[19]_i_20 
       (.I0(derivative1[17]),
        .I1(\derivative_reg[19]_i_8_n_7 ),
        .O(\derivative[19]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[19]_i_21 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[17]),
        .I5(\derivative_reg[19]_i_16_n_4 ),
        .O(\derivative[19]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_23 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[23]_i_19_n_5 ),
        .O(\derivative[19]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_24 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[23]_i_19_n_6 ),
        .O(\derivative[19]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_25 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[23]_i_19_n_7 ),
        .O(\derivative[19]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_26 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[23]_i_37_n_4 ),
        .O(\derivative[19]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_28 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[19]_i_10_n_5 ),
        .O(\derivative[19]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_29 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[19]_i_10_n_6 ),
        .O(\derivative[19]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[19]_i_3 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[18]),
        .O(\derivative[19]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_30 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[19]_i_10_n_7 ),
        .O(\derivative[19]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_31 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[19]_i_22_n_4 ),
        .O(\derivative[19]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_33 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[19]_i_13_n_5 ),
        .O(\derivative[19]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_34 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[19]_i_13_n_6 ),
        .O(\derivative[19]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_35 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[19]_i_13_n_7 ),
        .O(\derivative[19]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_36 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[19]_i_27_n_4 ),
        .O(\derivative[19]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_38 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[19]_i_16_n_5 ),
        .O(\derivative[19]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_39 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[19]_i_16_n_6 ),
        .O(\derivative[19]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[19]_i_4 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[17]),
        .O(\derivative[19]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_40 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[19]_i_16_n_7 ),
        .O(\derivative[19]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_41 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[19]_i_32_n_4 ),
        .O(\derivative[19]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_43 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[23]_i_37_n_5 ),
        .O(\derivative[19]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_44 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[23]_i_37_n_6 ),
        .O(\derivative[19]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_45 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[23]_i_37_n_7 ),
        .O(\derivative[19]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_46 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[23]_i_57_n_4 ),
        .O(\derivative[19]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_48 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[19]_i_22_n_5 ),
        .O(\derivative[19]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_49 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[19]_i_22_n_6 ),
        .O(\derivative[19]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[19]_i_5 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[16]),
        .O(\derivative[19]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_50 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[19]_i_22_n_7 ),
        .O(\derivative[19]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_51 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[19]_i_42_n_4 ),
        .O(\derivative[19]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_53 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[19]_i_27_n_5 ),
        .O(\derivative[19]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_54 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[19]_i_27_n_6 ),
        .O(\derivative[19]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_55 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[19]_i_27_n_7 ),
        .O(\derivative[19]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_56 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[19]_i_47_n_4 ),
        .O(\derivative[19]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_58 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[19]_i_32_n_5 ),
        .O(\derivative[19]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_59 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[19]_i_32_n_6 ),
        .O(\derivative[19]_i_59_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_60 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[19]_i_32_n_7 ),
        .O(\derivative[19]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_61 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[19]_i_52_n_4 ),
        .O(\derivative[19]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_63 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[23]_i_57_n_5 ),
        .O(\derivative[19]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_64 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[23]_i_57_n_6 ),
        .O(\derivative[19]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_65 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[23]_i_57_n_7 ),
        .O(\derivative[19]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_66 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[23]_i_77_n_4 ),
        .O(\derivative[19]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_68 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[19]_i_42_n_5 ),
        .O(\derivative[19]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_69 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[19]_i_42_n_6 ),
        .O(\derivative[19]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_70 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[19]_i_42_n_7 ),
        .O(\derivative[19]_i_70_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_71 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[19]_i_62_n_4 ),
        .O(\derivative[19]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_73 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[19]_i_47_n_5 ),
        .O(\derivative[19]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_74 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[19]_i_47_n_6 ),
        .O(\derivative[19]_i_74_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_75 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[19]_i_47_n_7 ),
        .O(\derivative[19]_i_75_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_76 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[19]_i_67_n_4 ),
        .O(\derivative[19]_i_76_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_78 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[19]_i_52_n_5 ),
        .O(\derivative[19]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_79 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[19]_i_52_n_6 ),
        .O(\derivative[19]_i_79_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_80 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[19]_i_52_n_7 ),
        .O(\derivative[19]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_81 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[19]_i_72_n_4 ),
        .O(\derivative[19]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_83 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[23]_i_77_n_5 ),
        .O(\derivative[19]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_84 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[23]_i_77_n_6 ),
        .O(\derivative[19]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_85 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[23]_i_77_n_7 ),
        .O(\derivative[19]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_86 
       (.I0(derivative1[20]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[23]_i_97_n_4 ),
        .O(\derivative[19]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_88 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[19]_i_62_n_5 ),
        .O(\derivative[19]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_89 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[19]_i_62_n_6 ),
        .O(\derivative[19]_i_89_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_90 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[19]_i_62_n_7 ),
        .O(\derivative[19]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_91 
       (.I0(derivative1[19]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[19]_i_82_n_4 ),
        .O(\derivative[19]_i_91_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_93 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[19]_i_67_n_5 ),
        .O(\derivative[19]_i_93_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_94 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[19]_i_67_n_6 ),
        .O(\derivative[19]_i_94_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_95 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[19]_i_67_n_7 ),
        .O(\derivative[19]_i_95_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_96 
       (.I0(derivative1[18]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[19]_i_87_n_4 ),
        .O(\derivative[19]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_98 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[19]_i_72_n_5 ),
        .O(\derivative[19]_i_98_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[19]_i_99 
       (.I0(derivative1[17]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[19]_i_72_n_6 ),
        .O(\derivative[19]_i_99_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_100 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[23]_i_72_n_7 ),
        .O(\derivative[23]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_101 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[23]_i_92_n_4 ),
        .O(\derivative[23]_i_101_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_103 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[27]_i_97_n_5 ),
        .O(\derivative[23]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_104 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[27]_i_97_n_6 ),
        .O(\derivative[23]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_105 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[27]_i_97_n_7 ),
        .O(\derivative[23]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_106 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[27]_i_117_n_4 ),
        .O(\derivative[23]_i_106_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_108 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[23]_i_82_n_5 ),
        .O(\derivative[23]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_109 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[23]_i_82_n_6 ),
        .O(\derivative[23]_i_109_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[23]_i_11 
       (.I0(derivative1[24]),
        .I1(\derivative_reg[27]_i_9_n_7 ),
        .O(\derivative[23]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_110 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[23]_i_82_n_7 ),
        .O(\derivative[23]_i_110_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_111 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[23]_i_102_n_4 ),
        .O(\derivative[23]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_113 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[23]_i_87_n_5 ),
        .O(\derivative[23]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_114 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[23]_i_87_n_6 ),
        .O(\derivative[23]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_115 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[23]_i_87_n_7 ),
        .O(\derivative[23]_i_115_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_116 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[23]_i_107_n_4 ),
        .O(\derivative[23]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_118 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[23]_i_92_n_5 ),
        .O(\derivative[23]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_119 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[23]_i_92_n_6 ),
        .O(\derivative[23]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[23]_i_12 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[24]),
        .I5(\derivative_reg[27]_i_19_n_4 ),
        .O(\derivative[23]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_120 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[23]_i_92_n_7 ),
        .O(\derivative[23]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_121 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[23]_i_112_n_4 ),
        .O(\derivative[23]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_123 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[27]_i_117_n_5 ),
        .O(\derivative[23]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_124 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[27]_i_117_n_6 ),
        .O(\derivative[23]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_125 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[27]_i_117_n_7 ),
        .O(\derivative[23]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_126 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[27]_i_137_n_4 ),
        .O(\derivative[23]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_128 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[23]_i_102_n_5 ),
        .O(\derivative[23]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_129 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[23]_i_102_n_6 ),
        .O(\derivative[23]_i_129_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_130 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[23]_i_102_n_7 ),
        .O(\derivative[23]_i_130_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_131 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[23]_i_122_n_4 ),
        .O(\derivative[23]_i_131_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_133 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[23]_i_107_n_5 ),
        .O(\derivative[23]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_134 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[23]_i_107_n_6 ),
        .O(\derivative[23]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_135 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[23]_i_107_n_7 ),
        .O(\derivative[23]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_136 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[23]_i_127_n_4 ),
        .O(\derivative[23]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_138 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[23]_i_112_n_5 ),
        .O(\derivative[23]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_139 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[23]_i_112_n_6 ),
        .O(\derivative[23]_i_139_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[23]_i_14 
       (.I0(derivative1[23]),
        .I1(\derivative_reg[23]_i_6_n_7 ),
        .O(\derivative[23]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_140 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[23]_i_112_n_7 ),
        .O(\derivative[23]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_141 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[23]_i_132_n_4 ),
        .O(\derivative[23]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_143 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[27]_i_137_n_5 ),
        .O(\derivative[23]_i_143_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_144 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[27]_i_137_n_6 ),
        .O(\derivative[23]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_145 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[27]_i_137_n_7 ),
        .O(\derivative[23]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_146 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[27]_i_157_n_4 ),
        .O(\derivative[23]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_148 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[23]_i_122_n_5 ),
        .O(\derivative[23]_i_148_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_149 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[23]_i_122_n_6 ),
        .O(\derivative[23]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[23]_i_15 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[23]),
        .I5(\derivative_reg[23]_i_10_n_4 ),
        .O(\derivative[23]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_150 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[23]_i_122_n_7 ),
        .O(\derivative[23]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_151 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[23]_i_142_n_4 ),
        .O(\derivative[23]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_153 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[23]_i_127_n_5 ),
        .O(\derivative[23]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_154 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[23]_i_127_n_6 ),
        .O(\derivative[23]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_155 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[23]_i_127_n_7 ),
        .O(\derivative[23]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_156 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[23]_i_147_n_4 ),
        .O(\derivative[23]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_158 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[23]_i_132_n_5 ),
        .O(\derivative[23]_i_158_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_159 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[23]_i_132_n_6 ),
        .O(\derivative[23]_i_159_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_160 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[23]_i_132_n_7 ),
        .O(\derivative[23]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_161 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[23]_i_152_n_4 ),
        .O(\derivative[23]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[23]_i_162 
       (.I0(\derivative_reg[27]_i_178_n_5 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[23]),
        .O(derivative20_in[23]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_163 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[27]_i_157_n_5 ),
        .O(\derivative[23]_i_163_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_164 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[27]_i_157_n_6 ),
        .O(\derivative[23]_i_164_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[23]_i_165 
       (.I0(derivative1[24]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[23]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[27]_i_178_n_5 ),
        .O(\derivative[23]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[23]_i_166 
       (.I0(\derivative_reg[27]_i_178_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[22]),
        .O(derivative20_in[22]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_167 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[23]_i_142_n_5 ),
        .O(\derivative[23]_i_167_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_168 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[23]_i_142_n_6 ),
        .O(\derivative[23]_i_168_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[23]_i_169 
       (.I0(derivative1[23]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[22]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[27]_i_178_n_6 ),
        .O(\derivative[23]_i_169_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[23]_i_17 
       (.I0(derivative1[22]),
        .I1(\derivative_reg[23]_i_7_n_7 ),
        .O(\derivative[23]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[23]_i_170 
       (.I0(\derivative_reg[27]_i_178_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[21]),
        .O(derivative20_in[21]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_171 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[23]_i_147_n_5 ),
        .O(\derivative[23]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_172 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[23]_i_147_n_6 ),
        .O(\derivative[23]_i_172_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[23]_i_173 
       (.I0(derivative1[22]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[21]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[27]_i_178_n_7 ),
        .O(\derivative[23]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[23]_i_174 
       (.I0(\derivative_reg[23]_i_178_n_4 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[20]),
        .O(derivative20_in[20]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_175 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[23]_i_152_n_5 ),
        .O(\derivative[23]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_176 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[23]_i_152_n_6 ),
        .O(\derivative[23]_i_176_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[23]_i_177 
       (.I0(derivative1[21]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[20]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[23]_i_178_n_4 ),
        .O(\derivative[23]_i_177_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[23]_i_179 
       (.I0(derivative4__93[20]),
        .O(\derivative[23]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[23]_i_18 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[22]),
        .I5(\derivative_reg[23]_i_13_n_4 ),
        .O(\derivative[23]_i_18_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[23]_i_180 
       (.I0(derivative4__93[19]),
        .O(\derivative[23]_i_180_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[23]_i_181 
       (.I0(derivative4__93[18]),
        .O(\derivative[23]_i_181_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[23]_i_182 
       (.I0(derivative4__93[17]),
        .O(\derivative[23]_i_182_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[23]_i_2 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[23]),
        .O(\derivative[23]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[23]_i_20 
       (.I0(derivative1[21]),
        .I1(\derivative_reg[23]_i_8_n_7 ),
        .O(\derivative[23]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[23]_i_21 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[21]),
        .I5(\derivative_reg[23]_i_16_n_4 ),
        .O(\derivative[23]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_23 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[27]_i_19_n_5 ),
        .O(\derivative[23]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_24 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[27]_i_19_n_6 ),
        .O(\derivative[23]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_25 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[27]_i_19_n_7 ),
        .O(\derivative[23]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_26 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[27]_i_37_n_4 ),
        .O(\derivative[23]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_28 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[23]_i_10_n_5 ),
        .O(\derivative[23]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_29 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[23]_i_10_n_6 ),
        .O(\derivative[23]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[23]_i_3 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[22]),
        .O(\derivative[23]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_30 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[23]_i_10_n_7 ),
        .O(\derivative[23]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_31 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[23]_i_22_n_4 ),
        .O(\derivative[23]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_33 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[23]_i_13_n_5 ),
        .O(\derivative[23]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_34 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[23]_i_13_n_6 ),
        .O(\derivative[23]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_35 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[23]_i_13_n_7 ),
        .O(\derivative[23]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_36 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[23]_i_27_n_4 ),
        .O(\derivative[23]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_38 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[23]_i_16_n_5 ),
        .O(\derivative[23]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_39 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[23]_i_16_n_6 ),
        .O(\derivative[23]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[23]_i_4 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[21]),
        .O(\derivative[23]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_40 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[23]_i_16_n_7 ),
        .O(\derivative[23]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_41 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[23]_i_32_n_4 ),
        .O(\derivative[23]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_43 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[27]_i_37_n_5 ),
        .O(\derivative[23]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_44 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[27]_i_37_n_6 ),
        .O(\derivative[23]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_45 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[27]_i_37_n_7 ),
        .O(\derivative[23]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_46 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[27]_i_57_n_4 ),
        .O(\derivative[23]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_48 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[23]_i_22_n_5 ),
        .O(\derivative[23]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_49 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[23]_i_22_n_6 ),
        .O(\derivative[23]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[23]_i_5 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[20]),
        .O(\derivative[23]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_50 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[23]_i_22_n_7 ),
        .O(\derivative[23]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_51 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[23]_i_42_n_4 ),
        .O(\derivative[23]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_53 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[23]_i_27_n_5 ),
        .O(\derivative[23]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_54 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[23]_i_27_n_6 ),
        .O(\derivative[23]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_55 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[23]_i_27_n_7 ),
        .O(\derivative[23]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_56 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[23]_i_47_n_4 ),
        .O(\derivative[23]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_58 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[23]_i_32_n_5 ),
        .O(\derivative[23]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_59 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[23]_i_32_n_6 ),
        .O(\derivative[23]_i_59_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_60 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[23]_i_32_n_7 ),
        .O(\derivative[23]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_61 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[23]_i_52_n_4 ),
        .O(\derivative[23]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_63 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[27]_i_57_n_5 ),
        .O(\derivative[23]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_64 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[27]_i_57_n_6 ),
        .O(\derivative[23]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_65 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[27]_i_57_n_7 ),
        .O(\derivative[23]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_66 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[27]_i_77_n_4 ),
        .O(\derivative[23]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_68 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[23]_i_42_n_5 ),
        .O(\derivative[23]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_69 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[23]_i_42_n_6 ),
        .O(\derivative[23]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_70 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[23]_i_42_n_7 ),
        .O(\derivative[23]_i_70_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_71 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[23]_i_62_n_4 ),
        .O(\derivative[23]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_73 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[23]_i_47_n_5 ),
        .O(\derivative[23]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_74 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[23]_i_47_n_6 ),
        .O(\derivative[23]_i_74_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_75 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[23]_i_47_n_7 ),
        .O(\derivative[23]_i_75_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_76 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[23]_i_67_n_4 ),
        .O(\derivative[23]_i_76_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_78 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[23]_i_52_n_5 ),
        .O(\derivative[23]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_79 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[23]_i_52_n_6 ),
        .O(\derivative[23]_i_79_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_80 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[23]_i_52_n_7 ),
        .O(\derivative[23]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_81 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[23]_i_72_n_4 ),
        .O(\derivative[23]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_83 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[27]_i_77_n_5 ),
        .O(\derivative[23]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_84 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[27]_i_77_n_6 ),
        .O(\derivative[23]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_85 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[27]_i_77_n_7 ),
        .O(\derivative[23]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_86 
       (.I0(derivative1[24]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[27]_i_97_n_4 ),
        .O(\derivative[23]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_88 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[23]_i_62_n_5 ),
        .O(\derivative[23]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_89 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[23]_i_62_n_6 ),
        .O(\derivative[23]_i_89_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_90 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[23]_i_62_n_7 ),
        .O(\derivative[23]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_91 
       (.I0(derivative1[23]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[23]_i_82_n_4 ),
        .O(\derivative[23]_i_91_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_93 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[23]_i_67_n_5 ),
        .O(\derivative[23]_i_93_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_94 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[23]_i_67_n_6 ),
        .O(\derivative[23]_i_94_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_95 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[23]_i_67_n_7 ),
        .O(\derivative[23]_i_95_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_96 
       (.I0(derivative1[22]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[23]_i_87_n_4 ),
        .O(\derivative[23]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_98 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[23]_i_72_n_5 ),
        .O(\derivative[23]_i_98_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[23]_i_99 
       (.I0(derivative1[21]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[23]_i_72_n_6 ),
        .O(\derivative[23]_i_99_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_100 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[27]_i_72_n_7 ),
        .O(\derivative[27]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_101 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[27]_i_92_n_4 ),
        .O(\derivative[27]_i_101_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_103 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[31]_i_153_n_5 ),
        .O(\derivative[27]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_104 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[31]_i_153_n_6 ),
        .O(\derivative[27]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_105 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[31]_i_153_n_7 ),
        .O(\derivative[27]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_106 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[31]_i_186_n_4 ),
        .O(\derivative[27]_i_106_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_108 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[27]_i_82_n_5 ),
        .O(\derivative[27]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_109 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[27]_i_82_n_6 ),
        .O(\derivative[27]_i_109_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[27]_i_11 
       (.I0(derivative1[28]),
        .I1(\derivative_reg[31]_i_24_n_7 ),
        .O(\derivative[27]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_110 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[27]_i_82_n_7 ),
        .O(\derivative[27]_i_110_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_111 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[27]_i_102_n_4 ),
        .O(\derivative[27]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_113 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[27]_i_87_n_5 ),
        .O(\derivative[27]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_114 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[27]_i_87_n_6 ),
        .O(\derivative[27]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_115 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[27]_i_87_n_7 ),
        .O(\derivative[27]_i_115_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_116 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[27]_i_107_n_4 ),
        .O(\derivative[27]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_118 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[27]_i_92_n_5 ),
        .O(\derivative[27]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_119 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[27]_i_92_n_6 ),
        .O(\derivative[27]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[27]_i_12 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[28]),
        .I5(\derivative_reg[31]_i_32_n_4 ),
        .O(\derivative[27]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_120 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[27]_i_92_n_7 ),
        .O(\derivative[27]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_121 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[27]_i_112_n_4 ),
        .O(\derivative[27]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_123 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[31]_i_186_n_5 ),
        .O(\derivative[27]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_124 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[31]_i_186_n_6 ),
        .O(\derivative[27]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_125 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[31]_i_186_n_7 ),
        .O(\derivative[27]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_126 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[31]_i_219_n_4 ),
        .O(\derivative[27]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_128 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[27]_i_102_n_5 ),
        .O(\derivative[27]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_129 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[27]_i_102_n_6 ),
        .O(\derivative[27]_i_129_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_130 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[27]_i_102_n_7 ),
        .O(\derivative[27]_i_130_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_131 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[27]_i_122_n_4 ),
        .O(\derivative[27]_i_131_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_133 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[27]_i_107_n_5 ),
        .O(\derivative[27]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_134 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[27]_i_107_n_6 ),
        .O(\derivative[27]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_135 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[27]_i_107_n_7 ),
        .O(\derivative[27]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_136 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[27]_i_127_n_4 ),
        .O(\derivative[27]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_138 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[27]_i_112_n_5 ),
        .O(\derivative[27]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_139 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[27]_i_112_n_6 ),
        .O(\derivative[27]_i_139_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[27]_i_14 
       (.I0(derivative1[27]),
        .I1(\derivative_reg[27]_i_6_n_7 ),
        .O(\derivative[27]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_140 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[27]_i_112_n_7 ),
        .O(\derivative[27]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_141 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[27]_i_132_n_4 ),
        .O(\derivative[27]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_143 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[31]_i_219_n_5 ),
        .O(\derivative[27]_i_143_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_144 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[31]_i_219_n_6 ),
        .O(\derivative[27]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_145 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[31]_i_219_n_7 ),
        .O(\derivative[27]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_146 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[31]_i_252_n_4 ),
        .O(\derivative[27]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_148 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[27]_i_122_n_5 ),
        .O(\derivative[27]_i_148_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_149 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[27]_i_122_n_6 ),
        .O(\derivative[27]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[27]_i_15 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[27]),
        .I5(\derivative_reg[27]_i_10_n_4 ),
        .O(\derivative[27]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_150 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[27]_i_122_n_7 ),
        .O(\derivative[27]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_151 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[27]_i_142_n_4 ),
        .O(\derivative[27]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_153 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[27]_i_127_n_5 ),
        .O(\derivative[27]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_154 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[27]_i_127_n_6 ),
        .O(\derivative[27]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_155 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[27]_i_127_n_7 ),
        .O(\derivative[27]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_156 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[27]_i_147_n_4 ),
        .O(\derivative[27]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_158 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[27]_i_132_n_5 ),
        .O(\derivative[27]_i_158_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_159 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[27]_i_132_n_6 ),
        .O(\derivative[27]_i_159_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_160 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[27]_i_132_n_7 ),
        .O(\derivative[27]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_161 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[27]_i_152_n_4 ),
        .O(\derivative[27]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[27]_i_162 
       (.I0(\derivative_reg[31]_i_294_n_5 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[27]),
        .O(derivative20_in[27]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_163 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[31]_i_252_n_5 ),
        .O(\derivative[27]_i_163_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_164 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[31]_i_252_n_6 ),
        .O(\derivative[27]_i_164_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[27]_i_165 
       (.I0(derivative1[28]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[27]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[31]_i_294_n_5 ),
        .O(\derivative[27]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[27]_i_166 
       (.I0(\derivative_reg[31]_i_294_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[26]),
        .O(derivative20_in[26]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_167 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[27]_i_142_n_5 ),
        .O(\derivative[27]_i_167_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_168 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[27]_i_142_n_6 ),
        .O(\derivative[27]_i_168_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[27]_i_169 
       (.I0(derivative1[27]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[26]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[31]_i_294_n_6 ),
        .O(\derivative[27]_i_169_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[27]_i_17 
       (.I0(derivative1[26]),
        .I1(\derivative_reg[27]_i_7_n_7 ),
        .O(\derivative[27]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[27]_i_170 
       (.I0(\derivative_reg[31]_i_294_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[25]),
        .O(derivative20_in[25]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_171 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[27]_i_147_n_5 ),
        .O(\derivative[27]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_172 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[27]_i_147_n_6 ),
        .O(\derivative[27]_i_172_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[27]_i_173 
       (.I0(derivative1[26]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[25]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[31]_i_294_n_7 ),
        .O(\derivative[27]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[27]_i_174 
       (.I0(\derivative_reg[27]_i_178_n_4 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[24]),
        .O(derivative20_in[24]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_175 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[27]_i_152_n_5 ),
        .O(\derivative[27]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_176 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[27]_i_152_n_6 ),
        .O(\derivative[27]_i_176_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[27]_i_177 
       (.I0(derivative1[25]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[24]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[27]_i_178_n_4 ),
        .O(\derivative[27]_i_177_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[27]_i_179 
       (.I0(derivative4__93[24]),
        .O(\derivative[27]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[27]_i_18 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[26]),
        .I5(\derivative_reg[27]_i_13_n_4 ),
        .O(\derivative[27]_i_18_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[27]_i_180 
       (.I0(derivative4__93[23]),
        .O(\derivative[27]_i_180_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[27]_i_181 
       (.I0(derivative4__93[22]),
        .O(\derivative[27]_i_181_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[27]_i_182 
       (.I0(derivative4__93[21]),
        .O(\derivative[27]_i_182_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[27]_i_2 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[27]),
        .O(\derivative[27]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[27]_i_20 
       (.I0(derivative1[25]),
        .I1(\derivative_reg[27]_i_8_n_7 ),
        .O(\derivative[27]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[27]_i_21 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[25]),
        .I5(\derivative_reg[27]_i_16_n_4 ),
        .O(\derivative[27]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_23 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[31]_i_32_n_5 ),
        .O(\derivative[27]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_24 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[31]_i_32_n_6 ),
        .O(\derivative[27]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_25 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[31]_i_32_n_7 ),
        .O(\derivative[27]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_26 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[31]_i_55_n_4 ),
        .O(\derivative[27]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_28 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[27]_i_10_n_5 ),
        .O(\derivative[27]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_29 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[27]_i_10_n_6 ),
        .O(\derivative[27]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[27]_i_3 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[26]),
        .O(\derivative[27]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_30 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[27]_i_10_n_7 ),
        .O(\derivative[27]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_31 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[27]_i_22_n_4 ),
        .O(\derivative[27]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_33 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[27]_i_13_n_5 ),
        .O(\derivative[27]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_34 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[27]_i_13_n_6 ),
        .O(\derivative[27]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_35 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[27]_i_13_n_7 ),
        .O(\derivative[27]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_36 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[27]_i_27_n_4 ),
        .O(\derivative[27]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_38 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[27]_i_16_n_5 ),
        .O(\derivative[27]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_39 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[27]_i_16_n_6 ),
        .O(\derivative[27]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[27]_i_4 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[25]),
        .O(\derivative[27]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_40 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[27]_i_16_n_7 ),
        .O(\derivative[27]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_41 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[27]_i_32_n_4 ),
        .O(\derivative[27]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_43 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[31]_i_55_n_5 ),
        .O(\derivative[27]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_44 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[31]_i_55_n_6 ),
        .O(\derivative[27]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_45 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[31]_i_55_n_7 ),
        .O(\derivative[27]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_46 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[31]_i_87_n_4 ),
        .O(\derivative[27]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_48 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[27]_i_22_n_5 ),
        .O(\derivative[27]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_49 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[27]_i_22_n_6 ),
        .O(\derivative[27]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[27]_i_5 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[24]),
        .O(\derivative[27]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_50 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[27]_i_22_n_7 ),
        .O(\derivative[27]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_51 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[27]_i_42_n_4 ),
        .O(\derivative[27]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_53 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[27]_i_27_n_5 ),
        .O(\derivative[27]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_54 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[27]_i_27_n_6 ),
        .O(\derivative[27]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_55 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[27]_i_27_n_7 ),
        .O(\derivative[27]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_56 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[27]_i_47_n_4 ),
        .O(\derivative[27]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_58 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[27]_i_32_n_5 ),
        .O(\derivative[27]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_59 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[27]_i_32_n_6 ),
        .O(\derivative[27]_i_59_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_60 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[27]_i_32_n_7 ),
        .O(\derivative[27]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_61 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[27]_i_52_n_4 ),
        .O(\derivative[27]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_63 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[31]_i_87_n_5 ),
        .O(\derivative[27]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_64 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[31]_i_87_n_6 ),
        .O(\derivative[27]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_65 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[31]_i_87_n_7 ),
        .O(\derivative[27]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_66 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[31]_i_120_n_4 ),
        .O(\derivative[27]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_68 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[27]_i_42_n_5 ),
        .O(\derivative[27]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_69 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[27]_i_42_n_6 ),
        .O(\derivative[27]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_70 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[27]_i_42_n_7 ),
        .O(\derivative[27]_i_70_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_71 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[27]_i_62_n_4 ),
        .O(\derivative[27]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_73 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[27]_i_47_n_5 ),
        .O(\derivative[27]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_74 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[27]_i_47_n_6 ),
        .O(\derivative[27]_i_74_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_75 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[27]_i_47_n_7 ),
        .O(\derivative[27]_i_75_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_76 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[27]_i_67_n_4 ),
        .O(\derivative[27]_i_76_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_78 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[27]_i_52_n_5 ),
        .O(\derivative[27]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_79 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[27]_i_52_n_6 ),
        .O(\derivative[27]_i_79_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_80 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[27]_i_52_n_7 ),
        .O(\derivative[27]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_81 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[27]_i_72_n_4 ),
        .O(\derivative[27]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_83 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[31]_i_120_n_5 ),
        .O(\derivative[27]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_84 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[31]_i_120_n_6 ),
        .O(\derivative[27]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_85 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[31]_i_120_n_7 ),
        .O(\derivative[27]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_86 
       (.I0(derivative1[28]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[31]_i_153_n_4 ),
        .O(\derivative[27]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_88 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[27]_i_62_n_5 ),
        .O(\derivative[27]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_89 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[27]_i_62_n_6 ),
        .O(\derivative[27]_i_89_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_90 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[27]_i_62_n_7 ),
        .O(\derivative[27]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_91 
       (.I0(derivative1[27]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[27]_i_82_n_4 ),
        .O(\derivative[27]_i_91_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_93 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[27]_i_67_n_5 ),
        .O(\derivative[27]_i_93_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_94 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[27]_i_67_n_6 ),
        .O(\derivative[27]_i_94_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_95 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[27]_i_67_n_7 ),
        .O(\derivative[27]_i_95_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_96 
       (.I0(derivative1[26]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[27]_i_87_n_4 ),
        .O(\derivative[27]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_98 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[27]_i_72_n_5 ),
        .O(\derivative[27]_i_98_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[27]_i_99 
       (.I0(derivative1[25]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[27]_i_72_n_6 ),
        .O(\derivative[27]_i_99_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF80000000)) 
    \derivative[31]_i_1 
       (.I0(\derivative[31]_i_3_n_0 ),
        .I1(\derivative[31]_i_4_n_0 ),
        .I2(\derivative[31]_i_5_n_0 ),
        .I3(\derivative[31]_i_6_n_0 ),
        .I4(\derivative[31]_i_7_n_0 ),
        .I5(\derivative[31]_i_8_n_0 ),
        .O(\derivative[31]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[31]_i_10 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[30]),
        .O(\derivative[31]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_100 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_4 ),
        .I4(dt00_in[20]),
        .I5(dt0__93[20]),
        .O(\derivative[31]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_102 
       (.I0(dt00_in[28]),
        .I1(dt1__15),
        .I2(dt0__93[28]),
        .O(\derivative[31]_i_102_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_103 
       (.I0(dt00_in[27]),
        .I1(dt1__15),
        .I2(dt0__93[27]),
        .O(\derivative[31]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_104 
       (.I0(dt00_in[26]),
        .I1(dt1__15),
        .I2(dt0__93[26]),
        .O(\derivative[31]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_105 
       (.I0(dt00_in[25]),
        .I1(dt1__15),
        .I2(dt0__93[25]),
        .O(\derivative[31]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_107 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[31]_i_60_n_6 ),
        .O(\derivative[31]_i_107_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_108 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[31]_i_60_n_7 ),
        .O(\derivative[31]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_109 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[31]_i_92_n_4 ),
        .O(\derivative[31]_i_109_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[31]_i_11 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[29]),
        .O(\derivative[31]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_110 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[31]_i_92_n_5 ),
        .O(\derivative[31]_i_110_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_111 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[26]),
        .I4(dt00_in[26]),
        .I5(\derivative_reg[31]_i_69_n_6 ),
        .O(\derivative[31]_i_111_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_112 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[25]),
        .I4(dt00_in[25]),
        .I5(\derivative_reg[31]_i_69_n_7 ),
        .O(\derivative[31]_i_112_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_113 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[24]),
        .I4(dt00_in[24]),
        .I5(\derivative_reg[31]_i_101_n_4 ),
        .O(\derivative[31]_i_113_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_114 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[23]),
        .I4(dt00_in[23]),
        .I5(\derivative_reg[31]_i_101_n_5 ),
        .O(\derivative[31]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_116 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[31]_i_70_n_5 ),
        .O(\derivative[31]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_117 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[31]_i_70_n_6 ),
        .O(\derivative[31]_i_117_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_118 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[31]_i_70_n_7 ),
        .O(\derivative[31]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_119 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[31]_i_106_n_4 ),
        .O(\derivative[31]_i_119_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[31]_i_12 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[28]),
        .O(\derivative[31]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_121 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[31]_i_82_n_5 ),
        .O(\derivative[31]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_122 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[31]_i_82_n_6 ),
        .O(\derivative[31]_i_122_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_123 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[31]_i_82_n_7 ),
        .O(\derivative[31]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_124 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[31]_i_115_n_4 ),
        .O(\derivative[31]_i_124_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_126 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_5 ),
        .I4(dt00_in[19]),
        .I5(dt0__93[19]),
        .O(\derivative[31]_i_126_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_127 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_6 ),
        .I4(dt00_in[18]),
        .I5(dt0__93[18]),
        .O(\derivative[31]_i_127_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_128 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_7 ),
        .I4(dt00_in[17]),
        .I5(dt0__93[17]),
        .O(\derivative[31]_i_128_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_129 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_4 ),
        .I4(dt00_in[16]),
        .I5(dt0__93[16]),
        .O(\derivative[31]_i_129_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \derivative[31]_i_13 
       (.I0(new_target_angle_available),
        .I1(clock_count_reg_n_0),
        .O(\derivative[31]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_130 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_5 ),
        .I4(dt00_in[19]),
        .I5(dt0__93[19]),
        .O(\derivative[31]_i_130_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_131 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_6 ),
        .I4(dt00_in[18]),
        .I5(dt0__93[18]),
        .O(\derivative[31]_i_131_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_132 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_7 ),
        .I4(dt00_in[17]),
        .I5(dt0__93[17]),
        .O(\derivative[31]_i_132_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_133 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_4 ),
        .I4(dt00_in[16]),
        .I5(dt0__93[16]),
        .O(\derivative[31]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_135 
       (.I0(dt00_in[24]),
        .I1(dt1__15),
        .I2(dt0__93[24]),
        .O(\derivative[31]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_136 
       (.I0(dt00_in[23]),
        .I1(dt1__15),
        .I2(dt0__93[23]),
        .O(\derivative[31]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_137 
       (.I0(dt00_in[22]),
        .I1(dt1__15),
        .I2(dt0__93[22]),
        .O(\derivative[31]_i_137_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_138 
       (.I0(dt00_in[21]),
        .I1(dt1__15),
        .I2(dt0__93[21]),
        .O(\derivative[31]_i_138_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_14 
       (.I0(dt00_in[4]),
        .I1(dt00_in[5]),
        .I2(dt00_in[2]),
        .I3(dt00_in[3]),
        .I4(dt00_in[7]),
        .I5(dt00_in[6]),
        .O(\derivative[31]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_140 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[31]_i_92_n_6 ),
        .O(\derivative[31]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_141 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[31]_i_92_n_7 ),
        .O(\derivative[31]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_142 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[31]_i_125_n_4 ),
        .O(\derivative[31]_i_142_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_143 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[31]_i_125_n_5 ),
        .O(\derivative[31]_i_143_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_144 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[22]),
        .I4(dt00_in[22]),
        .I5(\derivative_reg[31]_i_101_n_6 ),
        .O(\derivative[31]_i_144_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_145 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[21]),
        .I4(dt00_in[21]),
        .I5(\derivative_reg[31]_i_101_n_7 ),
        .O(\derivative[31]_i_145_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_146 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[20]),
        .I4(dt00_in[20]),
        .I5(\derivative_reg[31]_i_134_n_4 ),
        .O(\derivative[31]_i_146_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_147 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[19]),
        .I4(dt00_in[19]),
        .I5(\derivative_reg[31]_i_134_n_5 ),
        .O(\derivative[31]_i_147_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_149 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[31]_i_106_n_5 ),
        .O(\derivative[31]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_15 
       (.I0(dt0__93[16]),
        .I1(dt0__93[17]),
        .I2(dt0__93[14]),
        .I3(dt0__93[15]),
        .I4(dt0__93[19]),
        .I5(dt0__93[18]),
        .O(\derivative[31]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_150 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[31]_i_106_n_6 ),
        .O(\derivative[31]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_151 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[31]_i_106_n_7 ),
        .O(\derivative[31]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_152 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[31]_i_139_n_4 ),
        .O(\derivative[31]_i_152_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_154 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[31]_i_115_n_5 ),
        .O(\derivative[31]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_155 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[31]_i_115_n_6 ),
        .O(\derivative[31]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_156 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[31]_i_115_n_7 ),
        .O(\derivative[31]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_157 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[31]_i_148_n_4 ),
        .O(\derivative[31]_i_157_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_159 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_5 ),
        .I4(dt00_in[15]),
        .I5(dt0__93[15]),
        .O(\derivative[31]_i_159_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_16 
       (.I0(dt0__93[10]),
        .I1(dt0__93[11]),
        .I2(dt0__93[8]),
        .I3(dt0__93[9]),
        .I4(dt0__93[13]),
        .I5(dt0__93[12]),
        .O(\derivative[31]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_160 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_6 ),
        .I4(dt00_in[14]),
        .I5(dt0__93[14]),
        .O(\derivative[31]_i_160_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_161 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_7 ),
        .I4(dt00_in[13]),
        .I5(dt0__93[13]),
        .O(\derivative[31]_i_161_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_162 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_4 ),
        .I4(dt00_in[12]),
        .I5(dt0__93[12]),
        .O(\derivative[31]_i_162_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_163 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_5 ),
        .I4(dt00_in[15]),
        .I5(dt0__93[15]),
        .O(\derivative[31]_i_163_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_164 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_6 ),
        .I4(dt00_in[14]),
        .I5(dt0__93[14]),
        .O(\derivative[31]_i_164_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_165 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_167_n_7 ),
        .I4(dt00_in[13]),
        .I5(dt0__93[13]),
        .O(\derivative[31]_i_165_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_166 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_4 ),
        .I4(dt00_in[12]),
        .I5(dt0__93[12]),
        .O(\derivative[31]_i_166_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_168 
       (.I0(dt00_in[20]),
        .I1(dt1__15),
        .I2(dt0__93[20]),
        .O(\derivative[31]_i_168_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_169 
       (.I0(dt00_in[19]),
        .I1(dt1__15),
        .I2(dt0__93[19]),
        .O(\derivative[31]_i_169_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_17 
       (.I0(dt0__93[22]),
        .I1(dt0__93[23]),
        .I2(dt0__93[20]),
        .I3(dt0__93[21]),
        .I4(dt0__93[25]),
        .I5(dt0__93[24]),
        .O(\derivative[31]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_170 
       (.I0(dt00_in[18]),
        .I1(dt1__15),
        .I2(dt0__93[18]),
        .O(\derivative[31]_i_170_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_171 
       (.I0(dt00_in[17]),
        .I1(dt1__15),
        .I2(dt0__93[17]),
        .O(\derivative[31]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_173 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[31]_i_125_n_6 ),
        .O(\derivative[31]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_174 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[31]_i_125_n_7 ),
        .O(\derivative[31]_i_174_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_175 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[31]_i_158_n_4 ),
        .O(\derivative[31]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_176 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[31]_i_158_n_5 ),
        .O(\derivative[31]_i_176_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_177 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[18]),
        .I4(dt00_in[18]),
        .I5(\derivative_reg[31]_i_134_n_6 ),
        .O(\derivative[31]_i_177_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_178 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[17]),
        .I4(dt00_in[17]),
        .I5(\derivative_reg[31]_i_134_n_7 ),
        .O(\derivative[31]_i_178_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_179 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[16]),
        .I4(dt00_in[16]),
        .I5(\derivative_reg[31]_i_167_n_4 ),
        .O(\derivative[31]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_18 
       (.I0(dt0__93[28]),
        .I1(dt0__93[29]),
        .I2(dt0__93[26]),
        .I3(dt0__93[27]),
        .I4(dt0__93[31]),
        .I5(dt0__93[30]),
        .O(\derivative[31]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_180 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[15]),
        .I4(dt00_in[15]),
        .I5(\derivative_reg[31]_i_167_n_5 ),
        .O(\derivative[31]_i_180_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_182 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[31]_i_139_n_5 ),
        .O(\derivative[31]_i_182_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_183 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[31]_i_139_n_6 ),
        .O(\derivative[31]_i_183_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_184 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[31]_i_139_n_7 ),
        .O(\derivative[31]_i_184_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_185 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[31]_i_172_n_4 ),
        .O(\derivative[31]_i_185_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_187 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[31]_i_148_n_5 ),
        .O(\derivative[31]_i_187_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_188 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[31]_i_148_n_6 ),
        .O(\derivative[31]_i_188_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_189 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[31]_i_148_n_7 ),
        .O(\derivative[31]_i_189_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_19 
       (.I0(dt0__93[4]),
        .I1(dt0__93[5]),
        .I2(dt0__93[2]),
        .I3(dt0__93[3]),
        .I4(dt0__93[7]),
        .I5(dt0__93[6]),
        .O(\derivative[31]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_190 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[31]_i_181_n_4 ),
        .O(\derivative[31]_i_190_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_192 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_5 ),
        .I4(dt00_in[11]),
        .I5(dt0__93[11]),
        .O(\derivative[31]_i_192_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_193 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_6 ),
        .I4(dt00_in[10]),
        .I5(dt0__93[10]),
        .O(\derivative[31]_i_193_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_194 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_7 ),
        .I4(dt00_in[9]),
        .I5(dt0__93[9]),
        .O(\derivative[31]_i_194_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_195 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_4 ),
        .I4(dt00_in[8]),
        .I5(dt0__93[8]),
        .O(\derivative[31]_i_195_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_196 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_5 ),
        .I4(dt00_in[11]),
        .I5(dt0__93[11]),
        .O(\derivative[31]_i_196_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_197 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_6 ),
        .I4(dt00_in[10]),
        .I5(dt0__93[10]),
        .O(\derivative[31]_i_197_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_198 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_200_n_7 ),
        .I4(dt00_in[9]),
        .I5(dt0__93[9]),
        .O(\derivative[31]_i_198_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_199 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_4 ),
        .I4(dt00_in[8]),
        .I5(dt0__93[8]),
        .O(\derivative[31]_i_199_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000020000)) 
    \derivative[31]_i_20 
       (.I0(ps_ready_out),
        .I1(dt0__93[1]),
        .I2(dt1__15),
        .I3(dt00_in[0]),
        .I4(clock_count_reg_n_0),
        .I5(new_target_angle_available),
        .O(\derivative[31]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_201 
       (.I0(dt00_in[16]),
        .I1(dt1__15),
        .I2(dt0__93[16]),
        .O(\derivative[31]_i_201_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_202 
       (.I0(dt00_in[15]),
        .I1(dt1__15),
        .I2(dt0__93[15]),
        .O(\derivative[31]_i_202_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_203 
       (.I0(dt00_in[14]),
        .I1(dt1__15),
        .I2(dt0__93[14]),
        .O(\derivative[31]_i_203_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_204 
       (.I0(dt00_in[13]),
        .I1(dt1__15),
        .I2(dt0__93[13]),
        .O(\derivative[31]_i_204_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_206 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[31]_i_158_n_6 ),
        .O(\derivative[31]_i_206_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_207 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[31]_i_158_n_7 ),
        .O(\derivative[31]_i_207_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_208 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[31]_i_191_n_4 ),
        .O(\derivative[31]_i_208_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_209 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[31]_i_191_n_5 ),
        .O(\derivative[31]_i_209_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_210 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[14]),
        .I4(dt00_in[14]),
        .I5(\derivative_reg[31]_i_167_n_6 ),
        .O(\derivative[31]_i_210_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_211 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[13]),
        .I4(dt00_in[13]),
        .I5(\derivative_reg[31]_i_167_n_7 ),
        .O(\derivative[31]_i_211_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_212 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[12]),
        .I4(dt00_in[12]),
        .I5(\derivative_reg[31]_i_200_n_4 ),
        .O(\derivative[31]_i_212_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_213 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[11]),
        .I4(dt00_in[11]),
        .I5(\derivative_reg[31]_i_200_n_5 ),
        .O(\derivative[31]_i_213_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_215 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[31]_i_172_n_5 ),
        .O(\derivative[31]_i_215_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_216 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[31]_i_172_n_6 ),
        .O(\derivative[31]_i_216_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_217 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[31]_i_172_n_7 ),
        .O(\derivative[31]_i_217_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_218 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[31]_i_205_n_4 ),
        .O(\derivative[31]_i_218_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_220 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[31]_i_181_n_5 ),
        .O(\derivative[31]_i_220_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_221 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[31]_i_181_n_6 ),
        .O(\derivative[31]_i_221_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_222 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[31]_i_181_n_7 ),
        .O(\derivative[31]_i_222_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_223 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[31]_i_214_n_4 ),
        .O(\derivative[31]_i_223_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_225 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_5 ),
        .I4(dt00_in[7]),
        .I5(dt0__93[7]),
        .O(\derivative[31]_i_225_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_226 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_6 ),
        .I4(dt00_in[6]),
        .I5(dt0__93[6]),
        .O(\derivative[31]_i_226_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_227 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_7 ),
        .I4(dt00_in[5]),
        .I5(dt0__93[5]),
        .O(\derivative[31]_i_227_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_228 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_4 ),
        .I4(dt00_in[4]),
        .I5(dt0__93[4]),
        .O(\derivative[31]_i_228_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_229 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_5 ),
        .I4(dt00_in[7]),
        .I5(dt0__93[7]),
        .O(\derivative[31]_i_229_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_230 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_6 ),
        .I4(dt00_in[6]),
        .I5(dt0__93[6]),
        .O(\derivative[31]_i_230_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_231 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_233_n_7 ),
        .I4(dt00_in[5]),
        .I5(dt0__93[5]),
        .O(\derivative[31]_i_231_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_232 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_4 ),
        .I4(dt00_in[4]),
        .I5(dt0__93[4]),
        .O(\derivative[31]_i_232_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_234 
       (.I0(dt00_in[12]),
        .I1(dt1__15),
        .I2(dt0__93[12]),
        .O(\derivative[31]_i_234_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_235 
       (.I0(dt00_in[11]),
        .I1(dt1__15),
        .I2(dt0__93[11]),
        .O(\derivative[31]_i_235_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_236 
       (.I0(dt00_in[10]),
        .I1(dt1__15),
        .I2(dt0__93[10]),
        .O(\derivative[31]_i_236_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_237 
       (.I0(dt00_in[9]),
        .I1(dt1__15),
        .I2(dt0__93[9]),
        .O(\derivative[31]_i_237_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_239 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[31]_i_191_n_6 ),
        .O(\derivative[31]_i_239_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_240 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[31]_i_191_n_7 ),
        .O(\derivative[31]_i_240_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_241 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[31]_i_224_n_4 ),
        .O(\derivative[31]_i_241_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_242 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[31]_i_224_n_5 ),
        .O(\derivative[31]_i_242_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_243 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[10]),
        .I4(dt00_in[10]),
        .I5(\derivative_reg[31]_i_200_n_6 ),
        .O(\derivative[31]_i_243_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_244 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[9]),
        .I4(dt00_in[9]),
        .I5(\derivative_reg[31]_i_200_n_7 ),
        .O(\derivative[31]_i_244_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_245 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[8]),
        .I4(dt00_in[8]),
        .I5(\derivative_reg[31]_i_233_n_4 ),
        .O(\derivative[31]_i_245_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_246 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[7]),
        .I4(dt00_in[7]),
        .I5(\derivative_reg[31]_i_233_n_5 ),
        .O(\derivative[31]_i_246_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_248 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[31]_i_205_n_5 ),
        .O(\derivative[31]_i_248_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_249 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[31]_i_205_n_6 ),
        .O(\derivative[31]_i_249_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_250 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[31]_i_205_n_7 ),
        .O(\derivative[31]_i_250_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_251 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[31]_i_238_n_4 ),
        .O(\derivative[31]_i_251_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_253 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[31]_i_214_n_5 ),
        .O(\derivative[31]_i_253_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_254 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[31]_i_214_n_6 ),
        .O(\derivative[31]_i_254_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_255 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[31]_i_214_n_7 ),
        .O(\derivative[31]_i_255_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_256 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[31]_i_247_n_4 ),
        .O(\derivative[31]_i_256_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_257 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_5 ),
        .I4(dt00_in[3]),
        .I5(dt0__93[3]),
        .O(\derivative[31]_i_257_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_258 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_6 ),
        .I4(dt00_in[2]),
        .I5(dt0__93[2]),
        .O(\derivative[31]_i_258_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_259 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_7 ),
        .I4(dt00_in[1]),
        .I5(dt0__93[1]),
        .O(\derivative[31]_i_259_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \derivative[31]_i_260 
       (.I0(\derivative_reg[31]_i_286_n_5 ),
        .I1(derivative4__93[31]),
        .O(derivative20_in[31]));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_261 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_5 ),
        .I4(dt00_in[3]),
        .I5(dt0__93[3]),
        .O(\derivative[31]_i_261_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_262 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_6 ),
        .I4(dt00_in[2]),
        .I5(dt0__93[2]),
        .O(\derivative[31]_i_262_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_263 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_265_n_7 ),
        .I4(dt00_in[1]),
        .I5(dt0__93[1]),
        .O(\derivative[31]_i_263_n_0 ));
  LUT3 #(
    .INIT(8'h95)) 
    \derivative[31]_i_264 
       (.I0(dt00_in[0]),
        .I1(derivative4__93[31]),
        .I2(\derivative_reg[31]_i_286_n_5 ),
        .O(\derivative[31]_i_264_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_266 
       (.I0(dt00_in[8]),
        .I1(dt1__15),
        .I2(dt0__93[8]),
        .O(\derivative[31]_i_266_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_267 
       (.I0(dt00_in[7]),
        .I1(dt1__15),
        .I2(dt0__93[7]),
        .O(\derivative[31]_i_267_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_268 
       (.I0(dt00_in[6]),
        .I1(dt1__15),
        .I2(dt0__93[6]),
        .O(\derivative[31]_i_268_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_269 
       (.I0(dt00_in[5]),
        .I1(dt1__15),
        .I2(dt0__93[5]),
        .O(\derivative[31]_i_269_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[31]_i_27 
       (.I0(derivative1[31]),
        .I1(\derivative_reg[31]_i_25_n_4 ),
        .O(\derivative[31]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[31]_i_270 
       (.I0(\derivative_reg[31]_i_286_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[30]),
        .O(derivative20_in[30]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_271 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[31]_i_224_n_6 ),
        .O(\derivative[31]_i_271_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_272 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[31]_i_224_n_7 ),
        .O(\derivative[31]_i_272_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[31]_i_273 
       (.I0(derivative1[31]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[30]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[31]_i_286_n_6 ),
        .O(\derivative[31]_i_273_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_274 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[6]),
        .I4(dt00_in[6]),
        .I5(\derivative_reg[31]_i_233_n_6 ),
        .O(\derivative[31]_i_274_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_275 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[5]),
        .I4(dt00_in[5]),
        .I5(\derivative_reg[31]_i_233_n_7 ),
        .O(\derivative[31]_i_275_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_276 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[4]),
        .I4(dt00_in[4]),
        .I5(\derivative_reg[31]_i_265_n_4 ),
        .O(\derivative[31]_i_276_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_277 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[3]),
        .I4(dt00_in[3]),
        .I5(\derivative_reg[31]_i_265_n_5 ),
        .O(\derivative[31]_i_277_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[31]_i_278 
       (.I0(\derivative_reg[31]_i_286_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[29]),
        .O(derivative20_in[29]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_279 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[31]_i_238_n_5 ),
        .O(\derivative[31]_i_279_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[31]_i_28 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[31]),
        .I5(\derivative_reg[31]_i_25_n_5 ),
        .O(\derivative[31]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_280 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[31]_i_238_n_6 ),
        .O(\derivative[31]_i_280_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[31]_i_281 
       (.I0(derivative1[30]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[29]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[31]_i_286_n_7 ),
        .O(\derivative[31]_i_281_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[31]_i_282 
       (.I0(\derivative_reg[31]_i_294_n_4 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[28]),
        .O(derivative20_in[28]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_283 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[31]_i_247_n_5 ),
        .O(\derivative[31]_i_283_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_284 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[31]_i_247_n_6 ),
        .O(\derivative[31]_i_284_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[31]_i_285 
       (.I0(derivative1[29]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[28]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[31]_i_294_n_4 ),
        .O(\derivative[31]_i_285_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_287 
       (.I0(dt00_in[0]),
        .O(\derivative[31]_i_287_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_288 
       (.I0(dt00_in[4]),
        .I1(dt1__15),
        .I2(dt0__93[4]),
        .O(\derivative[31]_i_288_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_289 
       (.I0(dt00_in[3]),
        .I1(dt1__15),
        .I2(dt0__93[3]),
        .O(\derivative[31]_i_289_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_290 
       (.I0(dt00_in[2]),
        .I1(dt1__15),
        .I2(dt0__93[2]),
        .O(\derivative[31]_i_290_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_291 
       (.I0(dt00_in[1]),
        .I1(dt1__15),
        .I2(dt0__93[1]),
        .O(\derivative[31]_i_291_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_292 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[2]),
        .I4(dt00_in[2]),
        .I5(\derivative_reg[31]_i_265_n_6 ),
        .O(\derivative[31]_i_292_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_293 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[1]),
        .I4(dt00_in[1]),
        .I5(\derivative_reg[31]_i_265_n_7 ),
        .O(\derivative[31]_i_293_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_295 
       (.I0(derivative4__93[31]),
        .O(\derivative[31]_i_295_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_296 
       (.I0(derivative4__93[30]),
        .O(\derivative[31]_i_296_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_297 
       (.I0(derivative4__93[29]),
        .O(\derivative[31]_i_297_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_298 
       (.I0(derivative4__93[28]),
        .O(\derivative[31]_i_298_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_299 
       (.I0(derivative4__93[27]),
        .O(\derivative[31]_i_299_n_0 ));
  LUT6 #(
    .INIT(64'h0010000000000000)) 
    \derivative[31]_i_3 
       (.I0(\derivative[31]_i_13_n_0 ),
        .I1(dt00_in[1]),
        .I2(dt1__15),
        .I3(dt00_in[0]),
        .I4(ps_ready_out),
        .I5(\derivative[31]_i_14_n_0 ),
        .O(\derivative[31]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[31]_i_30 
       (.I0(derivative1[30]),
        .I1(\derivative_reg[31]_i_22_n_7 ),
        .O(\derivative[31]_i_30_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_300 
       (.I0(derivative4__93[26]),
        .O(\derivative[31]_i_300_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[31]_i_301 
       (.I0(derivative4__93[25]),
        .O(\derivative[31]_i_301_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[31]_i_31 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[30]),
        .I5(\derivative_reg[31]_i_26_n_4 ),
        .O(\derivative[31]_i_31_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[31]_i_33 
       (.I0(derivative1[29]),
        .I1(\derivative_reg[31]_i_23_n_7 ),
        .O(\derivative[31]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[31]_i_34 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[29]),
        .I5(\derivative_reg[31]_i_29_n_4 ),
        .O(\derivative[31]_i_34_n_0 ));
  LUT4 #(
    .INIT(16'h757F)) 
    \derivative[31]_i_36 
       (.I0(\derivative_reg[31]_i_49_n_5 ),
        .I1(dt00_in[31]),
        .I2(dt1__15),
        .I3(dt0__93[31]),
        .O(\derivative[31]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'h45407570454F757F)) 
    \derivative[31]_i_37 
       (.I0(\derivative_reg[31]_i_49_n_6 ),
        .I1(dt00_in[31]),
        .I2(dt1__15),
        .I3(dt0__93[31]),
        .I4(dt00_in[30]),
        .I5(dt0__93[30]),
        .O(\derivative[31]_i_37_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_38 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_7 ),
        .I4(dt00_in[29]),
        .I5(dt0__93[29]),
        .O(\derivative[31]_i_38_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_39 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_4 ),
        .I4(dt00_in[28]),
        .I5(dt0__93[28]),
        .O(\derivative[31]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_4 
       (.I0(dt00_in[16]),
        .I1(dt00_in[17]),
        .I2(dt00_in[14]),
        .I3(dt00_in[15]),
        .I4(dt00_in[19]),
        .I5(dt00_in[18]),
        .O(\derivative[31]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h757F)) 
    \derivative[31]_i_40 
       (.I0(\derivative_reg[31]_i_49_n_5 ),
        .I1(dt00_in[31]),
        .I2(dt1__15),
        .I3(dt0__93[31]),
        .O(\derivative[31]_i_40_n_0 ));
  LUT6 #(
    .INIT(64'h45407570454F757F)) 
    \derivative[31]_i_41 
       (.I0(\derivative_reg[31]_i_49_n_6 ),
        .I1(dt00_in[31]),
        .I2(dt1__15),
        .I3(dt0__93[31]),
        .I4(dt00_in[30]),
        .I5(dt0__93[30]),
        .O(\derivative[31]_i_41_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_42 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_7 ),
        .I4(dt00_in[29]),
        .I5(dt0__93[29]),
        .O(\derivative[31]_i_42_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_43 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_4 ),
        .I4(dt00_in[28]),
        .I5(dt0__93[28]),
        .O(\derivative[31]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_45 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[31]_i_25_n_6 ),
        .O(\derivative[31]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_46 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[31]_i_25_n_7 ),
        .O(\derivative[31]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_47 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[31]_i_35_n_4 ),
        .O(\derivative[31]_i_47_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_48 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[31]_i_35_n_5 ),
        .O(\derivative[31]_i_48_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_5 
       (.I0(dt00_in[28]),
        .I1(dt00_in[29]),
        .I2(dt00_in[26]),
        .I3(dt00_in[27]),
        .I4(dt00_in[31]),
        .I5(dt00_in[30]),
        .O(\derivative[31]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_51 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[31]_i_26_n_5 ),
        .O(\derivative[31]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_52 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[31]_i_26_n_6 ),
        .O(\derivative[31]_i_52_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_53 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[31]_i_26_n_7 ),
        .O(\derivative[31]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_54 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[31]_i_44_n_4 ),
        .O(\derivative[31]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_56 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[31]_i_29_n_5 ),
        .O(\derivative[31]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_57 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[31]_i_29_n_6 ),
        .O(\derivative[31]_i_57_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_58 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[31]_i_29_n_7 ),
        .O(\derivative[31]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_59 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[31]_i_50_n_4 ),
        .O(\derivative[31]_i_59_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_6 
       (.I0(dt00_in[10]),
        .I1(dt00_in[11]),
        .I2(dt00_in[8]),
        .I3(dt00_in[9]),
        .I4(dt00_in[13]),
        .I5(dt00_in[12]),
        .O(\derivative[31]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_61 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_5 ),
        .I4(dt00_in[27]),
        .I5(dt0__93[27]),
        .O(\derivative[31]_i_61_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_62 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_6 ),
        .I4(dt00_in[26]),
        .I5(dt0__93[26]),
        .O(\derivative[31]_i_62_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_63 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_7 ),
        .I4(dt00_in[25]),
        .I5(dt0__93[25]),
        .O(\derivative[31]_i_63_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_64 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_4 ),
        .I4(dt00_in[24]),
        .I5(dt0__93[24]),
        .O(\derivative[31]_i_64_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_65 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_5 ),
        .I4(dt00_in[27]),
        .I5(dt0__93[27]),
        .O(\derivative[31]_i_65_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_66 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_6 ),
        .I4(dt00_in[26]),
        .I5(dt0__93[26]),
        .O(\derivative[31]_i_66_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_67 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_69_n_7 ),
        .I4(dt00_in[25]),
        .I5(dt0__93[25]),
        .O(\derivative[31]_i_67_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_68 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_4 ),
        .I4(dt00_in[24]),
        .I5(dt0__93[24]),
        .O(\derivative[31]_i_68_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \derivative[31]_i_7 
       (.I0(dt00_in[22]),
        .I1(dt00_in[23]),
        .I2(dt00_in[20]),
        .I3(dt00_in[21]),
        .I4(dt00_in[25]),
        .I5(dt00_in[24]),
        .O(\derivative[31]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_71 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[31]_i_35_n_6 ),
        .O(\derivative[31]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_72 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[31]_i_35_n_7 ),
        .O(\derivative[31]_i_72_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_73 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[31]_i_60_n_4 ),
        .O(\derivative[31]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_74 
       (.I0(derivative1[31]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[31]_i_60_n_5 ),
        .O(\derivative[31]_i_74_n_0 ));
  LUT6 #(
    .INIT(64'hFFFACCFA000ACC0A)) 
    \derivative[31]_i_75 
       (.I0(dt0__93[30]),
        .I1(dt00_in[30]),
        .I2(dt0__93[31]),
        .I3(dt1__15),
        .I4(dt00_in[31]),
        .I5(\derivative_reg[31]_i_49_n_6 ),
        .O(\derivative[31]_i_75_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_76 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[29]),
        .I4(dt00_in[29]),
        .I5(\derivative_reg[31]_i_49_n_7 ),
        .O(\derivative[31]_i_76_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_77 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[28]),
        .I4(dt00_in[28]),
        .I5(\derivative_reg[31]_i_69_n_4 ),
        .O(\derivative[31]_i_77_n_0 ));
  LUT6 #(
    .INIT(64'hFFEEF3E21D0C1100)) 
    \derivative[31]_i_78 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(dt0__93[27]),
        .I4(dt00_in[27]),
        .I5(\derivative_reg[31]_i_69_n_5 ),
        .O(\derivative[31]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_79 
       (.I0(dt00_in[31]),
        .I1(dt1__15),
        .I2(dt0__93[31]),
        .O(\derivative[31]_i_79_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \derivative[31]_i_8 
       (.I0(\derivative[31]_i_15_n_0 ),
        .I1(\derivative[31]_i_16_n_0 ),
        .I2(\derivative[31]_i_17_n_0 ),
        .I3(\derivative[31]_i_18_n_0 ),
        .I4(\derivative[31]_i_19_n_0 ),
        .I5(\derivative[31]_i_20_n_0 ),
        .O(\derivative[31]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_80 
       (.I0(dt00_in[30]),
        .I1(dt1__15),
        .I2(dt0__93[30]),
        .O(\derivative[31]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \derivative[31]_i_81 
       (.I0(dt00_in[29]),
        .I1(dt1__15),
        .I2(dt0__93[29]),
        .O(\derivative[31]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_83 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[31]_i_44_n_5 ),
        .O(\derivative[31]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_84 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[31]_i_44_n_6 ),
        .O(\derivative[31]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_85 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[31]_i_44_n_7 ),
        .O(\derivative[31]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_86 
       (.I0(derivative1[30]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[31]_i_70_n_4 ),
        .O(\derivative[31]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_88 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[31]_i_50_n_5 ),
        .O(\derivative[31]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_89 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[31]_i_50_n_6 ),
        .O(\derivative[31]_i_89_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[31]_i_9 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[31]),
        .O(\derivative[31]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_90 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[31]_i_50_n_7 ),
        .O(\derivative[31]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[31]_i_91 
       (.I0(derivative1[29]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[31]_i_82_n_4 ),
        .O(\derivative[31]_i_91_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_93 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_5 ),
        .I4(dt00_in[23]),
        .I5(dt0__93[23]),
        .O(\derivative[31]_i_93_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_94 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_6 ),
        .I4(dt00_in[22]),
        .I5(dt0__93[22]),
        .O(\derivative[31]_i_94_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_95 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_7 ),
        .I4(dt00_in[21]),
        .I5(dt0__93[21]),
        .O(\derivative[31]_i_95_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_96 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_134_n_4 ),
        .I4(dt00_in[20]),
        .I5(dt0__93[20]),
        .O(\derivative[31]_i_96_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_97 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_5 ),
        .I4(dt00_in[23]),
        .I5(dt0__93[23]),
        .O(\derivative[31]_i_97_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_98 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_6 ),
        .I4(dt00_in[22]),
        .I5(dt0__93[22]),
        .O(\derivative[31]_i_98_n_0 ));
  LUT6 #(
    .INIT(64'h00E20CEE11F31DFF)) 
    \derivative[31]_i_99 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_101_n_7 ),
        .I4(dt00_in[21]),
        .I5(dt0__93[21]),
        .O(\derivative[31]_i_99_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_100 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[3]_i_72_n_6 ),
        .O(\derivative[3]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_101 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[3]_i_72_n_7 ),
        .O(\derivative[3]_i_101_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_103 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[7]_i_97_n_5 ),
        .O(\derivative[3]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_104 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[7]_i_97_n_6 ),
        .O(\derivative[3]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_105 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[7]_i_97_n_7 ),
        .O(\derivative[3]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_106 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[7]_i_117_n_4 ),
        .O(\derivative[3]_i_106_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_108 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[3]_i_82_n_5 ),
        .O(\derivative[3]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_109 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[3]_i_82_n_6 ),
        .O(\derivative[3]_i_109_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_110 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[3]_i_82_n_7 ),
        .O(\derivative[3]_i_110_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_111 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[3]_i_102_n_4 ),
        .O(\derivative[3]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_113 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[3]_i_87_n_5 ),
        .O(\derivative[3]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_114 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[3]_i_87_n_6 ),
        .O(\derivative[3]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_115 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[3]_i_87_n_7 ),
        .O(\derivative[3]_i_115_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_116 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[3]_i_107_n_4 ),
        .O(\derivative[3]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_118 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[3]_i_92_n_4 ),
        .O(\derivative[3]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_119 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[3]_i_92_n_5 ),
        .O(\derivative[3]_i_119_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[3]_i_12 
       (.I0(derivative1[4]),
        .I1(\derivative_reg[7]_i_9_n_7 ),
        .O(\derivative[3]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_120 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[3]_i_92_n_6 ),
        .O(\derivative[3]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_121 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[3]_i_92_n_7 ),
        .O(\derivative[3]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_123 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[7]_i_117_n_5 ),
        .O(\derivative[3]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_124 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[7]_i_117_n_6 ),
        .O(\derivative[3]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_125 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[7]_i_117_n_7 ),
        .O(\derivative[3]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_126 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[7]_i_137_n_4 ),
        .O(\derivative[3]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_128 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[3]_i_102_n_5 ),
        .O(\derivative[3]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_129 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[3]_i_102_n_6 ),
        .O(\derivative[3]_i_129_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[3]_i_13 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[4]),
        .I5(\derivative_reg[7]_i_19_n_4 ),
        .O(\derivative[3]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_130 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[3]_i_102_n_7 ),
        .O(\derivative[3]_i_130_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_131 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[3]_i_122_n_4 ),
        .O(\derivative[3]_i_131_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_133 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[3]_i_107_n_5 ),
        .O(\derivative[3]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_134 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[3]_i_107_n_6 ),
        .O(\derivative[3]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_135 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[3]_i_107_n_7 ),
        .O(\derivative[3]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_136 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[3]_i_127_n_4 ),
        .O(\derivative[3]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_138 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[3]_i_112_n_4 ),
        .O(\derivative[3]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_139 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[3]_i_112_n_5 ),
        .O(\derivative[3]_i_139_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_140 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[3]_i_112_n_6 ),
        .O(\derivative[3]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_141 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[3]_i_112_n_7 ),
        .O(\derivative[3]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_143 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[7]_i_137_n_5 ),
        .O(\derivative[3]_i_143_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_144 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[7]_i_137_n_6 ),
        .O(\derivative[3]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_145 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[7]_i_137_n_7 ),
        .O(\derivative[3]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_146 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[7]_i_157_n_4 ),
        .O(\derivative[3]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_148 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[3]_i_122_n_5 ),
        .O(\derivative[3]_i_148_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_149 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[3]_i_122_n_6 ),
        .O(\derivative[3]_i_149_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[3]_i_15 
       (.I0(derivative1[3]),
        .I1(\derivative_reg[3]_i_7_n_7 ),
        .O(\derivative[3]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_150 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[3]_i_122_n_7 ),
        .O(\derivative[3]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_151 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[3]_i_142_n_4 ),
        .O(\derivative[3]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_153 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[3]_i_127_n_5 ),
        .O(\derivative[3]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_154 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[3]_i_127_n_6 ),
        .O(\derivative[3]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_155 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[3]_i_127_n_7 ),
        .O(\derivative[3]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_156 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[3]_i_147_n_4 ),
        .O(\derivative[3]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_158 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[3]_i_132_n_4 ),
        .O(\derivative[3]_i_158_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_159 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[3]_i_132_n_5 ),
        .O(\derivative[3]_i_159_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[3]_i_16 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[3]),
        .I5(\derivative_reg[3]_i_11_n_4 ),
        .O(\derivative[3]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_160 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[3]_i_132_n_6 ),
        .O(\derivative[3]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_161 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[3]_i_132_n_7 ),
        .O(\derivative[3]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[3]_i_162 
       (.I0(\derivative_reg[7]_i_178_n_5 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[3]),
        .O(derivative20_in[3]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_163 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[7]_i_157_n_5 ),
        .O(\derivative[3]_i_163_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_164 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[7]_i_157_n_6 ),
        .O(\derivative[3]_i_164_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[3]_i_165 
       (.I0(derivative1[4]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[3]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[7]_i_178_n_5 ),
        .O(\derivative[3]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[3]_i_166 
       (.I0(\derivative_reg[7]_i_178_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[2]),
        .O(derivative20_in[2]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_167 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[3]_i_142_n_5 ),
        .O(\derivative[3]_i_167_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_168 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[3]_i_142_n_6 ),
        .O(\derivative[3]_i_168_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[3]_i_169 
       (.I0(derivative1[3]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[2]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[7]_i_178_n_6 ),
        .O(\derivative[3]_i_169_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[3]_i_170 
       (.I0(\derivative_reg[7]_i_178_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[1]),
        .O(derivative20_in[1]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_171 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[3]_i_147_n_5 ),
        .O(\derivative[3]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_172 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[3]_i_147_n_6 ),
        .O(\derivative[3]_i_172_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[3]_i_173 
       (.I0(derivative1[2]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[1]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[7]_i_178_n_7 ),
        .O(\derivative[3]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_174 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[3]_i_152_n_4 ),
        .O(\derivative[3]_i_174_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_175 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[3]_i_152_n_5 ),
        .O(\derivative[3]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_176 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[3]_i_152_n_6 ),
        .O(\derivative[3]_i_176_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_177 
       (.I0(derivative1[1]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[0]),
        .O(\derivative[3]_i_177_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[3]_i_18 
       (.I0(derivative1[2]),
        .I1(\derivative_reg[3]_i_8_n_7 ),
        .O(\derivative[3]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[3]_i_19 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[2]),
        .I5(\derivative_reg[3]_i_14_n_4 ),
        .O(\derivative[3]_i_19_n_0 ));
  LUT4 #(
    .INIT(16'h1DE2)) 
    \derivative[3]_i_2 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .O(p_0_out));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[3]_i_21 
       (.I0(derivative1[1]),
        .I1(\derivative_reg[3]_i_9_n_7 ),
        .O(\derivative[3]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_23 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[7]_i_19_n_5 ),
        .O(\derivative[3]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_24 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[7]_i_19_n_6 ),
        .O(\derivative[3]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_25 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[7]_i_19_n_7 ),
        .O(\derivative[3]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_26 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[7]_i_37_n_4 ),
        .O(\derivative[3]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_28 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[3]_i_11_n_5 ),
        .O(\derivative[3]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_29 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[3]_i_11_n_6 ),
        .O(\derivative[3]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[3]_i_3 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[3]),
        .O(\derivative[3]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_30 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[3]_i_11_n_7 ),
        .O(\derivative[3]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_31 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[3]_i_22_n_4 ),
        .O(\derivative[3]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_33 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[3]_i_14_n_5 ),
        .O(\derivative[3]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_34 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[3]_i_14_n_6 ),
        .O(\derivative[3]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_35 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[3]_i_14_n_7 ),
        .O(\derivative[3]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_36 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[3]_i_27_n_4 ),
        .O(\derivative[3]_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[3]_i_38 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[1]),
        .I5(\derivative_reg[3]_i_17_n_4 ),
        .O(\derivative[3]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_39 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[3]_i_17_n_5 ),
        .O(\derivative[3]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[3]_i_4 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[2]),
        .O(\derivative[3]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_40 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[3]_i_17_n_6 ),
        .O(\derivative[3]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_41 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[3]_i_17_n_7 ),
        .O(\derivative[3]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_43 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[7]_i_37_n_5 ),
        .O(\derivative[3]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_44 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[7]_i_37_n_6 ),
        .O(\derivative[3]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_45 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[7]_i_37_n_7 ),
        .O(\derivative[3]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_46 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[7]_i_57_n_4 ),
        .O(\derivative[3]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_48 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[3]_i_22_n_5 ),
        .O(\derivative[3]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_49 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[3]_i_22_n_6 ),
        .O(\derivative[3]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[3]_i_5 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[1]),
        .O(\derivative[3]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_50 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[3]_i_22_n_7 ),
        .O(\derivative[3]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_51 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[3]_i_42_n_4 ),
        .O(\derivative[3]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_53 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[3]_i_27_n_5 ),
        .O(\derivative[3]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_54 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[3]_i_27_n_6 ),
        .O(\derivative[3]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_55 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[3]_i_27_n_7 ),
        .O(\derivative[3]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_56 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[3]_i_47_n_4 ),
        .O(\derivative[3]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_58 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[3]_i_32_n_4 ),
        .O(\derivative[3]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_59 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[3]_i_32_n_5 ),
        .O(\derivative[3]_i_59_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \derivative[3]_i_6 
       (.I0(derivative1[0]),
        .O(\derivative[3]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_60 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[3]_i_32_n_6 ),
        .O(\derivative[3]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_61 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[3]_i_32_n_7 ),
        .O(\derivative[3]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_63 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[7]_i_57_n_5 ),
        .O(\derivative[3]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_64 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[7]_i_57_n_6 ),
        .O(\derivative[3]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_65 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[7]_i_57_n_7 ),
        .O(\derivative[3]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_66 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[7]_i_77_n_4 ),
        .O(\derivative[3]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_68 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[3]_i_42_n_5 ),
        .O(\derivative[3]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_69 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[3]_i_42_n_6 ),
        .O(\derivative[3]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_70 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[3]_i_42_n_7 ),
        .O(\derivative[3]_i_70_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_71 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[3]_i_62_n_4 ),
        .O(\derivative[3]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_73 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[3]_i_47_n_5 ),
        .O(\derivative[3]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_74 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[3]_i_47_n_6 ),
        .O(\derivative[3]_i_74_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_75 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[3]_i_47_n_7 ),
        .O(\derivative[3]_i_75_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_76 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[3]_i_67_n_4 ),
        .O(\derivative[3]_i_76_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_78 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[3]_i_52_n_4 ),
        .O(\derivative[3]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_79 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[3]_i_52_n_5 ),
        .O(\derivative[3]_i_79_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_80 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[3]_i_52_n_6 ),
        .O(\derivative[3]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_81 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[3]_i_52_n_7 ),
        .O(\derivative[3]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_83 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[7]_i_77_n_5 ),
        .O(\derivative[3]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_84 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[7]_i_77_n_6 ),
        .O(\derivative[3]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_85 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[7]_i_77_n_7 ),
        .O(\derivative[3]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_86 
       (.I0(derivative1[4]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[7]_i_97_n_4 ),
        .O(\derivative[3]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_88 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[3]_i_62_n_5 ),
        .O(\derivative[3]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_89 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[3]_i_62_n_6 ),
        .O(\derivative[3]_i_89_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_90 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[3]_i_62_n_7 ),
        .O(\derivative[3]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_91 
       (.I0(derivative1[3]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[3]_i_82_n_4 ),
        .O(\derivative[3]_i_91_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_93 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[3]_i_67_n_5 ),
        .O(\derivative[3]_i_93_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_94 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[3]_i_67_n_6 ),
        .O(\derivative[3]_i_94_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_95 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[3]_i_67_n_7 ),
        .O(\derivative[3]_i_95_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_96 
       (.I0(derivative1[2]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[3]_i_87_n_4 ),
        .O(\derivative[3]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_98 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[3]_i_72_n_4 ),
        .O(\derivative[3]_i_98_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[3]_i_99 
       (.I0(derivative1[1]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[3]_i_72_n_5 ),
        .O(\derivative[3]_i_99_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_100 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[7]_i_72_n_7 ),
        .O(\derivative[7]_i_100_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_101 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[7]_i_92_n_4 ),
        .O(\derivative[7]_i_101_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_103 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[11]_i_97_n_5 ),
        .O(\derivative[7]_i_103_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_104 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[11]_i_97_n_6 ),
        .O(\derivative[7]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_105 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[11]_i_97_n_7 ),
        .O(\derivative[7]_i_105_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_106 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[11]_i_117_n_4 ),
        .O(\derivative[7]_i_106_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_108 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[7]_i_82_n_5 ),
        .O(\derivative[7]_i_108_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_109 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[7]_i_82_n_6 ),
        .O(\derivative[7]_i_109_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[7]_i_11 
       (.I0(derivative1[8]),
        .I1(\derivative_reg[11]_i_9_n_7 ),
        .O(\derivative[7]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_110 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[7]_i_82_n_7 ),
        .O(\derivative[7]_i_110_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_111 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[7]_i_102_n_4 ),
        .O(\derivative[7]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_113 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[7]_i_87_n_5 ),
        .O(\derivative[7]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_114 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[7]_i_87_n_6 ),
        .O(\derivative[7]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_115 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[7]_i_87_n_7 ),
        .O(\derivative[7]_i_115_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_116 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[7]_i_107_n_4 ),
        .O(\derivative[7]_i_116_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_118 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_210_n_0 ),
        .I2(\derivative_reg[7]_i_92_n_5 ),
        .O(\derivative[7]_i_118_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_119 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_211_n_0 ),
        .I2(\derivative_reg[7]_i_92_n_6 ),
        .O(\derivative[7]_i_119_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[7]_i_12 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[8]),
        .I5(\derivative_reg[11]_i_19_n_4 ),
        .O(\derivative[7]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_120 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_212_n_0 ),
        .I2(\derivative_reg[7]_i_92_n_7 ),
        .O(\derivative[7]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_121 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_213_n_0 ),
        .I2(\derivative_reg[7]_i_112_n_4 ),
        .O(\derivative[7]_i_121_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_123 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[11]_i_117_n_5 ),
        .O(\derivative[7]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_124 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[11]_i_117_n_6 ),
        .O(\derivative[7]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_125 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[11]_i_117_n_7 ),
        .O(\derivative[7]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_126 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[11]_i_137_n_4 ),
        .O(\derivative[7]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_128 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[7]_i_102_n_5 ),
        .O(\derivative[7]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_129 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[7]_i_102_n_6 ),
        .O(\derivative[7]_i_129_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_130 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[7]_i_102_n_7 ),
        .O(\derivative[7]_i_130_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_131 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[7]_i_122_n_4 ),
        .O(\derivative[7]_i_131_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_133 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[7]_i_107_n_5 ),
        .O(\derivative[7]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_134 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[7]_i_107_n_6 ),
        .O(\derivative[7]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_135 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[7]_i_107_n_7 ),
        .O(\derivative[7]_i_135_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_136 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[7]_i_127_n_4 ),
        .O(\derivative[7]_i_136_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_138 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_243_n_0 ),
        .I2(\derivative_reg[7]_i_112_n_5 ),
        .O(\derivative[7]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_139 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_244_n_0 ),
        .I2(\derivative_reg[7]_i_112_n_6 ),
        .O(\derivative[7]_i_139_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[7]_i_14 
       (.I0(derivative1[7]),
        .I1(\derivative_reg[7]_i_6_n_7 ),
        .O(\derivative[7]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_140 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_245_n_0 ),
        .I2(\derivative_reg[7]_i_112_n_7 ),
        .O(\derivative[7]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_141 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_246_n_0 ),
        .I2(\derivative_reg[7]_i_132_n_4 ),
        .O(\derivative[7]_i_141_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_143 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[11]_i_137_n_5 ),
        .O(\derivative[7]_i_143_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_144 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[11]_i_137_n_6 ),
        .O(\derivative[7]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_145 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[11]_i_137_n_7 ),
        .O(\derivative[7]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_146 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[11]_i_157_n_4 ),
        .O(\derivative[7]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_148 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[7]_i_122_n_5 ),
        .O(\derivative[7]_i_148_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_149 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[7]_i_122_n_6 ),
        .O(\derivative[7]_i_149_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[7]_i_15 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[7]),
        .I5(\derivative_reg[7]_i_10_n_4 ),
        .O(\derivative[7]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_150 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[7]_i_122_n_7 ),
        .O(\derivative[7]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_151 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[7]_i_142_n_4 ),
        .O(\derivative[7]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_153 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[7]_i_127_n_5 ),
        .O(\derivative[7]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_154 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[7]_i_127_n_6 ),
        .O(\derivative[7]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_155 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[7]_i_127_n_7 ),
        .O(\derivative[7]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_156 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[7]_i_147_n_4 ),
        .O(\derivative[7]_i_156_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_158 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_274_n_0 ),
        .I2(\derivative_reg[7]_i_132_n_5 ),
        .O(\derivative[7]_i_158_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_159 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_275_n_0 ),
        .I2(\derivative_reg[7]_i_132_n_6 ),
        .O(\derivative[7]_i_159_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_160 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_276_n_0 ),
        .I2(\derivative_reg[7]_i_132_n_7 ),
        .O(\derivative[7]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_161 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_277_n_0 ),
        .I2(\derivative_reg[7]_i_152_n_4 ),
        .O(\derivative[7]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[7]_i_162 
       (.I0(\derivative_reg[11]_i_178_n_5 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[7]),
        .O(derivative20_in[7]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_163 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[11]_i_157_n_5 ),
        .O(\derivative[7]_i_163_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_164 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[11]_i_157_n_6 ),
        .O(\derivative[7]_i_164_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[7]_i_165 
       (.I0(derivative1[8]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[7]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[11]_i_178_n_5 ),
        .O(\derivative[7]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[7]_i_166 
       (.I0(\derivative_reg[11]_i_178_n_6 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[6]),
        .O(derivative20_in[6]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_167 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[7]_i_142_n_5 ),
        .O(\derivative[7]_i_167_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_168 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[7]_i_142_n_6 ),
        .O(\derivative[7]_i_168_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[7]_i_169 
       (.I0(derivative1[7]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[6]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[11]_i_178_n_6 ),
        .O(\derivative[7]_i_169_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[7]_i_17 
       (.I0(derivative1[6]),
        .I1(\derivative_reg[7]_i_7_n_7 ),
        .O(\derivative[7]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[7]_i_170 
       (.I0(\derivative_reg[11]_i_178_n_7 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[5]),
        .O(derivative20_in[5]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_171 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[7]_i_147_n_5 ),
        .O(\derivative[7]_i_171_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_172 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[7]_i_147_n_6 ),
        .O(\derivative[7]_i_172_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[7]_i_173 
       (.I0(derivative1[6]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[5]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[11]_i_178_n_7 ),
        .O(\derivative[7]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \derivative[7]_i_174 
       (.I0(\derivative_reg[7]_i_178_n_4 ),
        .I1(derivative4__93[31]),
        .I2(derivative4__93[4]),
        .O(derivative20_in[4]));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_175 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_292_n_0 ),
        .I2(\derivative_reg[7]_i_152_n_5 ),
        .O(\derivative[7]_i_175_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_176 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_293_n_0 ),
        .I2(\derivative_reg[7]_i_152_n_6 ),
        .O(\derivative[7]_i_176_n_0 ));
  LUT5 #(
    .INIT(32'h99966696)) 
    \derivative[7]_i_177 
       (.I0(derivative1[5]),
        .I1(dt00_in[0]),
        .I2(derivative4__93[4]),
        .I3(derivative4__93[31]),
        .I4(\derivative_reg[7]_i_178_n_4 ),
        .O(\derivative[7]_i_177_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[7]_i_179 
       (.I0(derivative4__93[0]),
        .O(\derivative[7]_i_179_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[7]_i_18 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[6]),
        .I5(\derivative_reg[7]_i_13_n_4 ),
        .O(\derivative[7]_i_18_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[7]_i_180 
       (.I0(derivative4__93[4]),
        .O(\derivative[7]_i_180_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[7]_i_181 
       (.I0(derivative4__93[3]),
        .O(\derivative[7]_i_181_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[7]_i_182 
       (.I0(derivative4__93[2]),
        .O(\derivative[7]_i_182_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \derivative[7]_i_183 
       (.I0(derivative4__93[1]),
        .O(\derivative[7]_i_183_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[7]_i_2 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[7]),
        .O(\derivative[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \derivative[7]_i_20 
       (.I0(derivative1[5]),
        .I1(\derivative_reg[7]_i_8_n_7 ),
        .O(\derivative[7]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hE2001DFF1DFFE200)) 
    \derivative[7]_i_21 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(\derivative_reg[31]_i_49_n_5 ),
        .I4(derivative1[5]),
        .I5(\derivative_reg[7]_i_16_n_4 ),
        .O(\derivative[7]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_23 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[11]_i_19_n_5 ),
        .O(\derivative[7]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_24 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[11]_i_19_n_6 ),
        .O(\derivative[7]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_25 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[11]_i_19_n_7 ),
        .O(\derivative[7]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_26 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[11]_i_37_n_4 ),
        .O(\derivative[7]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_28 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[7]_i_10_n_5 ),
        .O(\derivative[7]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_29 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[7]_i_10_n_6 ),
        .O(\derivative[7]_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[7]_i_3 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[6]),
        .O(\derivative[7]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_30 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[7]_i_10_n_7 ),
        .O(\derivative[7]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_31 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[7]_i_22_n_4 ),
        .O(\derivative[7]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_33 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[7]_i_13_n_5 ),
        .O(\derivative[7]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_34 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[7]_i_13_n_6 ),
        .O(\derivative[7]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_35 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[7]_i_13_n_7 ),
        .O(\derivative[7]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_36 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[7]_i_27_n_4 ),
        .O(\derivative[7]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_38 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_75_n_0 ),
        .I2(\derivative_reg[7]_i_16_n_5 ),
        .O(\derivative[7]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_39 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_76_n_0 ),
        .I2(\derivative_reg[7]_i_16_n_6 ),
        .O(\derivative[7]_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[7]_i_4 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[5]),
        .O(\derivative[7]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_40 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_77_n_0 ),
        .I2(\derivative_reg[7]_i_16_n_7 ),
        .O(\derivative[7]_i_40_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_41 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_78_n_0 ),
        .I2(\derivative_reg[7]_i_32_n_4 ),
        .O(\derivative[7]_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_43 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[11]_i_37_n_5 ),
        .O(\derivative[7]_i_43_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_44 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[11]_i_37_n_6 ),
        .O(\derivative[7]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_45 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[11]_i_37_n_7 ),
        .O(\derivative[7]_i_45_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_46 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[11]_i_57_n_4 ),
        .O(\derivative[7]_i_46_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_48 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[7]_i_22_n_5 ),
        .O(\derivative[7]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_49 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[7]_i_22_n_6 ),
        .O(\derivative[7]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'hE21D1DE2)) 
    \derivative[7]_i_5 
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .I3(derivative4__93[31]),
        .I4(derivative1[4]),
        .O(\derivative[7]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_50 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[7]_i_22_n_7 ),
        .O(\derivative[7]_i_50_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_51 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[7]_i_42_n_4 ),
        .O(\derivative[7]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_53 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[7]_i_27_n_5 ),
        .O(\derivative[7]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_54 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[7]_i_27_n_6 ),
        .O(\derivative[7]_i_54_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_55 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[7]_i_27_n_7 ),
        .O(\derivative[7]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_56 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[7]_i_47_n_4 ),
        .O(\derivative[7]_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_58 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_111_n_0 ),
        .I2(\derivative_reg[7]_i_32_n_5 ),
        .O(\derivative[7]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_59 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_112_n_0 ),
        .I2(\derivative_reg[7]_i_32_n_6 ),
        .O(\derivative[7]_i_59_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_60 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_113_n_0 ),
        .I2(\derivative_reg[7]_i_32_n_7 ),
        .O(\derivative[7]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_61 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_114_n_0 ),
        .I2(\derivative_reg[7]_i_52_n_4 ),
        .O(\derivative[7]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_63 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[11]_i_57_n_5 ),
        .O(\derivative[7]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_64 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[11]_i_57_n_6 ),
        .O(\derivative[7]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_65 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[11]_i_57_n_7 ),
        .O(\derivative[7]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_66 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[11]_i_77_n_4 ),
        .O(\derivative[7]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_68 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[7]_i_42_n_5 ),
        .O(\derivative[7]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_69 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[7]_i_42_n_6 ),
        .O(\derivative[7]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_70 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[7]_i_42_n_7 ),
        .O(\derivative[7]_i_70_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_71 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[7]_i_62_n_4 ),
        .O(\derivative[7]_i_71_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_73 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[7]_i_47_n_5 ),
        .O(\derivative[7]_i_73_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_74 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[7]_i_47_n_6 ),
        .O(\derivative[7]_i_74_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_75 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[7]_i_47_n_7 ),
        .O(\derivative[7]_i_75_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_76 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[7]_i_67_n_4 ),
        .O(\derivative[7]_i_76_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_78 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_144_n_0 ),
        .I2(\derivative_reg[7]_i_52_n_5 ),
        .O(\derivative[7]_i_78_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_79 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_145_n_0 ),
        .I2(\derivative_reg[7]_i_52_n_6 ),
        .O(\derivative[7]_i_79_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_80 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_146_n_0 ),
        .I2(\derivative_reg[7]_i_52_n_7 ),
        .O(\derivative[7]_i_80_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_81 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_147_n_0 ),
        .I2(\derivative_reg[7]_i_72_n_4 ),
        .O(\derivative[7]_i_81_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_83 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[11]_i_77_n_5 ),
        .O(\derivative[7]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_84 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[11]_i_77_n_6 ),
        .O(\derivative[7]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_85 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[11]_i_77_n_7 ),
        .O(\derivative[7]_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_86 
       (.I0(derivative1[8]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[11]_i_97_n_4 ),
        .O(\derivative[7]_i_86_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_88 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[7]_i_62_n_5 ),
        .O(\derivative[7]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_89 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[7]_i_62_n_6 ),
        .O(\derivative[7]_i_89_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_90 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[7]_i_62_n_7 ),
        .O(\derivative[7]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_91 
       (.I0(derivative1[7]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[7]_i_82_n_4 ),
        .O(\derivative[7]_i_91_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_93 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[7]_i_67_n_5 ),
        .O(\derivative[7]_i_93_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_94 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[7]_i_67_n_6 ),
        .O(\derivative[7]_i_94_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_95 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_179_n_0 ),
        .I2(\derivative_reg[7]_i_67_n_7 ),
        .O(\derivative[7]_i_95_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_96 
       (.I0(derivative1[6]),
        .I1(\derivative[31]_i_180_n_0 ),
        .I2(\derivative_reg[7]_i_87_n_4 ),
        .O(\derivative[7]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_98 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_177_n_0 ),
        .I2(\derivative_reg[7]_i_72_n_5 ),
        .O(\derivative[7]_i_98_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \derivative[7]_i_99 
       (.I0(derivative1[5]),
        .I1(\derivative[31]_i_178_n_0 ),
        .I2(\derivative_reg[7]_i_72_n_6 ),
        .O(\derivative[7]_i_99_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[0] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[3]_i_1_n_7 ),
        .Q(derivative_out[0]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[10] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[11]_i_1_n_5 ),
        .Q(derivative_out[10]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[11] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[11]_i_1_n_4 ),
        .Q(derivative_out[11]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[11]_i_1 
       (.CI(\derivative_reg[7]_i_1_n_0 ),
        .CO({\derivative_reg[11]_i_1_n_0 ,\derivative_reg[11]_i_1_n_1 ,\derivative_reg[11]_i_1_n_2 ,\derivative_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[11]_i_1_n_4 ,\derivative_reg[11]_i_1_n_5 ,\derivative_reg[11]_i_1_n_6 ,\derivative_reg[11]_i_1_n_7 }),
        .S({\derivative[11]_i_2_n_0 ,\derivative[11]_i_3_n_0 ,\derivative[11]_i_4_n_0 ,\derivative[11]_i_5_n_0 }));
  CARRY4 \derivative_reg[11]_i_10 
       (.CI(\derivative_reg[11]_i_22_n_0 ),
        .CO({\derivative_reg[11]_i_10_n_0 ,\derivative_reg[11]_i_10_n_1 ,\derivative_reg[11]_i_10_n_2 ,\derivative_reg[11]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_19_n_5 ,\derivative_reg[15]_i_19_n_6 ,\derivative_reg[15]_i_19_n_7 ,\derivative_reg[15]_i_37_n_4 }),
        .O({\derivative_reg[11]_i_10_n_4 ,\derivative_reg[11]_i_10_n_5 ,\derivative_reg[11]_i_10_n_6 ,\derivative_reg[11]_i_10_n_7 }),
        .S({\derivative[11]_i_23_n_0 ,\derivative[11]_i_24_n_0 ,\derivative[11]_i_25_n_0 ,\derivative[11]_i_26_n_0 }));
  CARRY4 \derivative_reg[11]_i_102 
       (.CI(\derivative_reg[11]_i_122_n_0 ),
        .CO({\derivative_reg[11]_i_102_n_0 ,\derivative_reg[11]_i_102_n_1 ,\derivative_reg[11]_i_102_n_2 ,\derivative_reg[11]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_117_n_5 ,\derivative_reg[15]_i_117_n_6 ,\derivative_reg[15]_i_117_n_7 ,\derivative_reg[15]_i_137_n_4 }),
        .O({\derivative_reg[11]_i_102_n_4 ,\derivative_reg[11]_i_102_n_5 ,\derivative_reg[11]_i_102_n_6 ,\derivative_reg[11]_i_102_n_7 }),
        .S({\derivative[11]_i_123_n_0 ,\derivative[11]_i_124_n_0 ,\derivative[11]_i_125_n_0 ,\derivative[11]_i_126_n_0 }));
  CARRY4 \derivative_reg[11]_i_107 
       (.CI(\derivative_reg[11]_i_127_n_0 ),
        .CO({\derivative_reg[11]_i_107_n_0 ,\derivative_reg[11]_i_107_n_1 ,\derivative_reg[11]_i_107_n_2 ,\derivative_reg[11]_i_107_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_102_n_5 ,\derivative_reg[11]_i_102_n_6 ,\derivative_reg[11]_i_102_n_7 ,\derivative_reg[11]_i_122_n_4 }),
        .O({\derivative_reg[11]_i_107_n_4 ,\derivative_reg[11]_i_107_n_5 ,\derivative_reg[11]_i_107_n_6 ,\derivative_reg[11]_i_107_n_7 }),
        .S({\derivative[11]_i_128_n_0 ,\derivative[11]_i_129_n_0 ,\derivative[11]_i_130_n_0 ,\derivative[11]_i_131_n_0 }));
  CARRY4 \derivative_reg[11]_i_112 
       (.CI(\derivative_reg[11]_i_132_n_0 ),
        .CO({\derivative_reg[11]_i_112_n_0 ,\derivative_reg[11]_i_112_n_1 ,\derivative_reg[11]_i_112_n_2 ,\derivative_reg[11]_i_112_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_107_n_5 ,\derivative_reg[11]_i_107_n_6 ,\derivative_reg[11]_i_107_n_7 ,\derivative_reg[11]_i_127_n_4 }),
        .O({\derivative_reg[11]_i_112_n_4 ,\derivative_reg[11]_i_112_n_5 ,\derivative_reg[11]_i_112_n_6 ,\derivative_reg[11]_i_112_n_7 }),
        .S({\derivative[11]_i_133_n_0 ,\derivative[11]_i_134_n_0 ,\derivative[11]_i_135_n_0 ,\derivative[11]_i_136_n_0 }));
  CARRY4 \derivative_reg[11]_i_117 
       (.CI(\derivative_reg[11]_i_137_n_0 ),
        .CO({\derivative_reg[11]_i_117_n_0 ,\derivative_reg[11]_i_117_n_1 ,\derivative_reg[11]_i_117_n_2 ,\derivative_reg[11]_i_117_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_112_n_5 ,\derivative_reg[11]_i_112_n_6 ,\derivative_reg[11]_i_112_n_7 ,\derivative_reg[11]_i_132_n_4 }),
        .O({\derivative_reg[11]_i_117_n_4 ,\derivative_reg[11]_i_117_n_5 ,\derivative_reg[11]_i_117_n_6 ,\derivative_reg[11]_i_117_n_7 }),
        .S({\derivative[11]_i_138_n_0 ,\derivative[11]_i_139_n_0 ,\derivative[11]_i_140_n_0 ,\derivative[11]_i_141_n_0 }));
  CARRY4 \derivative_reg[11]_i_122 
       (.CI(\derivative_reg[11]_i_142_n_0 ),
        .CO({\derivative_reg[11]_i_122_n_0 ,\derivative_reg[11]_i_122_n_1 ,\derivative_reg[11]_i_122_n_2 ,\derivative_reg[11]_i_122_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_137_n_5 ,\derivative_reg[15]_i_137_n_6 ,\derivative_reg[15]_i_137_n_7 ,\derivative_reg[15]_i_157_n_4 }),
        .O({\derivative_reg[11]_i_122_n_4 ,\derivative_reg[11]_i_122_n_5 ,\derivative_reg[11]_i_122_n_6 ,\derivative_reg[11]_i_122_n_7 }),
        .S({\derivative[11]_i_143_n_0 ,\derivative[11]_i_144_n_0 ,\derivative[11]_i_145_n_0 ,\derivative[11]_i_146_n_0 }));
  CARRY4 \derivative_reg[11]_i_127 
       (.CI(\derivative_reg[11]_i_147_n_0 ),
        .CO({\derivative_reg[11]_i_127_n_0 ,\derivative_reg[11]_i_127_n_1 ,\derivative_reg[11]_i_127_n_2 ,\derivative_reg[11]_i_127_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_122_n_5 ,\derivative_reg[11]_i_122_n_6 ,\derivative_reg[11]_i_122_n_7 ,\derivative_reg[11]_i_142_n_4 }),
        .O({\derivative_reg[11]_i_127_n_4 ,\derivative_reg[11]_i_127_n_5 ,\derivative_reg[11]_i_127_n_6 ,\derivative_reg[11]_i_127_n_7 }),
        .S({\derivative[11]_i_148_n_0 ,\derivative[11]_i_149_n_0 ,\derivative[11]_i_150_n_0 ,\derivative[11]_i_151_n_0 }));
  CARRY4 \derivative_reg[11]_i_13 
       (.CI(\derivative_reg[11]_i_27_n_0 ),
        .CO({\derivative_reg[11]_i_13_n_0 ,\derivative_reg[11]_i_13_n_1 ,\derivative_reg[11]_i_13_n_2 ,\derivative_reg[11]_i_13_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_10_n_5 ,\derivative_reg[11]_i_10_n_6 ,\derivative_reg[11]_i_10_n_7 ,\derivative_reg[11]_i_22_n_4 }),
        .O({\derivative_reg[11]_i_13_n_4 ,\derivative_reg[11]_i_13_n_5 ,\derivative_reg[11]_i_13_n_6 ,\derivative_reg[11]_i_13_n_7 }),
        .S({\derivative[11]_i_28_n_0 ,\derivative[11]_i_29_n_0 ,\derivative[11]_i_30_n_0 ,\derivative[11]_i_31_n_0 }));
  CARRY4 \derivative_reg[11]_i_132 
       (.CI(\derivative_reg[11]_i_152_n_0 ),
        .CO({\derivative_reg[11]_i_132_n_0 ,\derivative_reg[11]_i_132_n_1 ,\derivative_reg[11]_i_132_n_2 ,\derivative_reg[11]_i_132_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_127_n_5 ,\derivative_reg[11]_i_127_n_6 ,\derivative_reg[11]_i_127_n_7 ,\derivative_reg[11]_i_147_n_4 }),
        .O({\derivative_reg[11]_i_132_n_4 ,\derivative_reg[11]_i_132_n_5 ,\derivative_reg[11]_i_132_n_6 ,\derivative_reg[11]_i_132_n_7 }),
        .S({\derivative[11]_i_153_n_0 ,\derivative[11]_i_154_n_0 ,\derivative[11]_i_155_n_0 ,\derivative[11]_i_156_n_0 }));
  CARRY4 \derivative_reg[11]_i_137 
       (.CI(\derivative_reg[11]_i_157_n_0 ),
        .CO({\derivative_reg[11]_i_137_n_0 ,\derivative_reg[11]_i_137_n_1 ,\derivative_reg[11]_i_137_n_2 ,\derivative_reg[11]_i_137_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_132_n_5 ,\derivative_reg[11]_i_132_n_6 ,\derivative_reg[11]_i_132_n_7 ,\derivative_reg[11]_i_152_n_4 }),
        .O({\derivative_reg[11]_i_137_n_4 ,\derivative_reg[11]_i_137_n_5 ,\derivative_reg[11]_i_137_n_6 ,\derivative_reg[11]_i_137_n_7 }),
        .S({\derivative[11]_i_158_n_0 ,\derivative[11]_i_159_n_0 ,\derivative[11]_i_160_n_0 ,\derivative[11]_i_161_n_0 }));
  CARRY4 \derivative_reg[11]_i_142 
       (.CI(1'b0),
        .CO({\derivative_reg[11]_i_142_n_0 ,\derivative_reg[11]_i_142_n_1 ,\derivative_reg[11]_i_142_n_2 ,\derivative_reg[11]_i_142_n_3 }),
        .CYINIT(derivative1[12]),
        .DI({\derivative_reg[15]_i_157_n_5 ,\derivative_reg[15]_i_157_n_6 ,derivative20_in[11],1'b0}),
        .O({\derivative_reg[11]_i_142_n_4 ,\derivative_reg[11]_i_142_n_5 ,\derivative_reg[11]_i_142_n_6 ,\NLW_derivative_reg[11]_i_142_O_UNCONNECTED [0]}),
        .S({\derivative[11]_i_163_n_0 ,\derivative[11]_i_164_n_0 ,\derivative[11]_i_165_n_0 ,1'b1}));
  CARRY4 \derivative_reg[11]_i_147 
       (.CI(1'b0),
        .CO({\derivative_reg[11]_i_147_n_0 ,\derivative_reg[11]_i_147_n_1 ,\derivative_reg[11]_i_147_n_2 ,\derivative_reg[11]_i_147_n_3 }),
        .CYINIT(derivative1[11]),
        .DI({\derivative_reg[11]_i_142_n_5 ,\derivative_reg[11]_i_142_n_6 ,derivative20_in[10],1'b0}),
        .O({\derivative_reg[11]_i_147_n_4 ,\derivative_reg[11]_i_147_n_5 ,\derivative_reg[11]_i_147_n_6 ,\NLW_derivative_reg[11]_i_147_O_UNCONNECTED [0]}),
        .S({\derivative[11]_i_167_n_0 ,\derivative[11]_i_168_n_0 ,\derivative[11]_i_169_n_0 ,1'b1}));
  CARRY4 \derivative_reg[11]_i_152 
       (.CI(1'b0),
        .CO({\derivative_reg[11]_i_152_n_0 ,\derivative_reg[11]_i_152_n_1 ,\derivative_reg[11]_i_152_n_2 ,\derivative_reg[11]_i_152_n_3 }),
        .CYINIT(derivative1[10]),
        .DI({\derivative_reg[11]_i_147_n_5 ,\derivative_reg[11]_i_147_n_6 ,derivative20_in[9],1'b0}),
        .O({\derivative_reg[11]_i_152_n_4 ,\derivative_reg[11]_i_152_n_5 ,\derivative_reg[11]_i_152_n_6 ,\NLW_derivative_reg[11]_i_152_O_UNCONNECTED [0]}),
        .S({\derivative[11]_i_171_n_0 ,\derivative[11]_i_172_n_0 ,\derivative[11]_i_173_n_0 ,1'b1}));
  CARRY4 \derivative_reg[11]_i_157 
       (.CI(1'b0),
        .CO({\derivative_reg[11]_i_157_n_0 ,\derivative_reg[11]_i_157_n_1 ,\derivative_reg[11]_i_157_n_2 ,\derivative_reg[11]_i_157_n_3 }),
        .CYINIT(derivative1[9]),
        .DI({\derivative_reg[11]_i_152_n_5 ,\derivative_reg[11]_i_152_n_6 ,derivative20_in[8],1'b0}),
        .O({\derivative_reg[11]_i_157_n_4 ,\derivative_reg[11]_i_157_n_5 ,\derivative_reg[11]_i_157_n_6 ,\NLW_derivative_reg[11]_i_157_O_UNCONNECTED [0]}),
        .S({\derivative[11]_i_175_n_0 ,\derivative[11]_i_176_n_0 ,\derivative[11]_i_177_n_0 ,1'b1}));
  CARRY4 \derivative_reg[11]_i_16 
       (.CI(\derivative_reg[11]_i_32_n_0 ),
        .CO({\derivative_reg[11]_i_16_n_0 ,\derivative_reg[11]_i_16_n_1 ,\derivative_reg[11]_i_16_n_2 ,\derivative_reg[11]_i_16_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_13_n_5 ,\derivative_reg[11]_i_13_n_6 ,\derivative_reg[11]_i_13_n_7 ,\derivative_reg[11]_i_27_n_4 }),
        .O({\derivative_reg[11]_i_16_n_4 ,\derivative_reg[11]_i_16_n_5 ,\derivative_reg[11]_i_16_n_6 ,\derivative_reg[11]_i_16_n_7 }),
        .S({\derivative[11]_i_33_n_0 ,\derivative[11]_i_34_n_0 ,\derivative[11]_i_35_n_0 ,\derivative[11]_i_36_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[11]_i_178 
       (.CI(\derivative_reg[7]_i_178_n_0 ),
        .CO({\derivative_reg[11]_i_178_n_0 ,\derivative_reg[11]_i_178_n_1 ,\derivative_reg[11]_i_178_n_2 ,\derivative_reg[11]_i_178_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[11]_i_178_n_4 ,\derivative_reg[11]_i_178_n_5 ,\derivative_reg[11]_i_178_n_6 ,\derivative_reg[11]_i_178_n_7 }),
        .S({\derivative[11]_i_179_n_0 ,\derivative[11]_i_180_n_0 ,\derivative[11]_i_181_n_0 ,\derivative[11]_i_182_n_0 }));
  CARRY4 \derivative_reg[11]_i_19 
       (.CI(\derivative_reg[11]_i_37_n_0 ),
        .CO({\derivative_reg[11]_i_19_n_0 ,\derivative_reg[11]_i_19_n_1 ,\derivative_reg[11]_i_19_n_2 ,\derivative_reg[11]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_16_n_5 ,\derivative_reg[11]_i_16_n_6 ,\derivative_reg[11]_i_16_n_7 ,\derivative_reg[11]_i_32_n_4 }),
        .O({\derivative_reg[11]_i_19_n_4 ,\derivative_reg[11]_i_19_n_5 ,\derivative_reg[11]_i_19_n_6 ,\derivative_reg[11]_i_19_n_7 }),
        .S({\derivative[11]_i_38_n_0 ,\derivative[11]_i_39_n_0 ,\derivative[11]_i_40_n_0 ,\derivative[11]_i_41_n_0 }));
  CARRY4 \derivative_reg[11]_i_22 
       (.CI(\derivative_reg[11]_i_42_n_0 ),
        .CO({\derivative_reg[11]_i_22_n_0 ,\derivative_reg[11]_i_22_n_1 ,\derivative_reg[11]_i_22_n_2 ,\derivative_reg[11]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_37_n_5 ,\derivative_reg[15]_i_37_n_6 ,\derivative_reg[15]_i_37_n_7 ,\derivative_reg[15]_i_57_n_4 }),
        .O({\derivative_reg[11]_i_22_n_4 ,\derivative_reg[11]_i_22_n_5 ,\derivative_reg[11]_i_22_n_6 ,\derivative_reg[11]_i_22_n_7 }),
        .S({\derivative[11]_i_43_n_0 ,\derivative[11]_i_44_n_0 ,\derivative[11]_i_45_n_0 ,\derivative[11]_i_46_n_0 }));
  CARRY4 \derivative_reg[11]_i_27 
       (.CI(\derivative_reg[11]_i_47_n_0 ),
        .CO({\derivative_reg[11]_i_27_n_0 ,\derivative_reg[11]_i_27_n_1 ,\derivative_reg[11]_i_27_n_2 ,\derivative_reg[11]_i_27_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_22_n_5 ,\derivative_reg[11]_i_22_n_6 ,\derivative_reg[11]_i_22_n_7 ,\derivative_reg[11]_i_42_n_4 }),
        .O({\derivative_reg[11]_i_27_n_4 ,\derivative_reg[11]_i_27_n_5 ,\derivative_reg[11]_i_27_n_6 ,\derivative_reg[11]_i_27_n_7 }),
        .S({\derivative[11]_i_48_n_0 ,\derivative[11]_i_49_n_0 ,\derivative[11]_i_50_n_0 ,\derivative[11]_i_51_n_0 }));
  CARRY4 \derivative_reg[11]_i_32 
       (.CI(\derivative_reg[11]_i_52_n_0 ),
        .CO({\derivative_reg[11]_i_32_n_0 ,\derivative_reg[11]_i_32_n_1 ,\derivative_reg[11]_i_32_n_2 ,\derivative_reg[11]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_27_n_5 ,\derivative_reg[11]_i_27_n_6 ,\derivative_reg[11]_i_27_n_7 ,\derivative_reg[11]_i_47_n_4 }),
        .O({\derivative_reg[11]_i_32_n_4 ,\derivative_reg[11]_i_32_n_5 ,\derivative_reg[11]_i_32_n_6 ,\derivative_reg[11]_i_32_n_7 }),
        .S({\derivative[11]_i_53_n_0 ,\derivative[11]_i_54_n_0 ,\derivative[11]_i_55_n_0 ,\derivative[11]_i_56_n_0 }));
  CARRY4 \derivative_reg[11]_i_37 
       (.CI(\derivative_reg[11]_i_57_n_0 ),
        .CO({\derivative_reg[11]_i_37_n_0 ,\derivative_reg[11]_i_37_n_1 ,\derivative_reg[11]_i_37_n_2 ,\derivative_reg[11]_i_37_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_32_n_5 ,\derivative_reg[11]_i_32_n_6 ,\derivative_reg[11]_i_32_n_7 ,\derivative_reg[11]_i_52_n_4 }),
        .O({\derivative_reg[11]_i_37_n_4 ,\derivative_reg[11]_i_37_n_5 ,\derivative_reg[11]_i_37_n_6 ,\derivative_reg[11]_i_37_n_7 }),
        .S({\derivative[11]_i_58_n_0 ,\derivative[11]_i_59_n_0 ,\derivative[11]_i_60_n_0 ,\derivative[11]_i_61_n_0 }));
  CARRY4 \derivative_reg[11]_i_42 
       (.CI(\derivative_reg[11]_i_62_n_0 ),
        .CO({\derivative_reg[11]_i_42_n_0 ,\derivative_reg[11]_i_42_n_1 ,\derivative_reg[11]_i_42_n_2 ,\derivative_reg[11]_i_42_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_57_n_5 ,\derivative_reg[15]_i_57_n_6 ,\derivative_reg[15]_i_57_n_7 ,\derivative_reg[15]_i_77_n_4 }),
        .O({\derivative_reg[11]_i_42_n_4 ,\derivative_reg[11]_i_42_n_5 ,\derivative_reg[11]_i_42_n_6 ,\derivative_reg[11]_i_42_n_7 }),
        .S({\derivative[11]_i_63_n_0 ,\derivative[11]_i_64_n_0 ,\derivative[11]_i_65_n_0 ,\derivative[11]_i_66_n_0 }));
  CARRY4 \derivative_reg[11]_i_47 
       (.CI(\derivative_reg[11]_i_67_n_0 ),
        .CO({\derivative_reg[11]_i_47_n_0 ,\derivative_reg[11]_i_47_n_1 ,\derivative_reg[11]_i_47_n_2 ,\derivative_reg[11]_i_47_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_42_n_5 ,\derivative_reg[11]_i_42_n_6 ,\derivative_reg[11]_i_42_n_7 ,\derivative_reg[11]_i_62_n_4 }),
        .O({\derivative_reg[11]_i_47_n_4 ,\derivative_reg[11]_i_47_n_5 ,\derivative_reg[11]_i_47_n_6 ,\derivative_reg[11]_i_47_n_7 }),
        .S({\derivative[11]_i_68_n_0 ,\derivative[11]_i_69_n_0 ,\derivative[11]_i_70_n_0 ,\derivative[11]_i_71_n_0 }));
  CARRY4 \derivative_reg[11]_i_52 
       (.CI(\derivative_reg[11]_i_72_n_0 ),
        .CO({\derivative_reg[11]_i_52_n_0 ,\derivative_reg[11]_i_52_n_1 ,\derivative_reg[11]_i_52_n_2 ,\derivative_reg[11]_i_52_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_47_n_5 ,\derivative_reg[11]_i_47_n_6 ,\derivative_reg[11]_i_47_n_7 ,\derivative_reg[11]_i_67_n_4 }),
        .O({\derivative_reg[11]_i_52_n_4 ,\derivative_reg[11]_i_52_n_5 ,\derivative_reg[11]_i_52_n_6 ,\derivative_reg[11]_i_52_n_7 }),
        .S({\derivative[11]_i_73_n_0 ,\derivative[11]_i_74_n_0 ,\derivative[11]_i_75_n_0 ,\derivative[11]_i_76_n_0 }));
  CARRY4 \derivative_reg[11]_i_57 
       (.CI(\derivative_reg[11]_i_77_n_0 ),
        .CO({\derivative_reg[11]_i_57_n_0 ,\derivative_reg[11]_i_57_n_1 ,\derivative_reg[11]_i_57_n_2 ,\derivative_reg[11]_i_57_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_52_n_5 ,\derivative_reg[11]_i_52_n_6 ,\derivative_reg[11]_i_52_n_7 ,\derivative_reg[11]_i_72_n_4 }),
        .O({\derivative_reg[11]_i_57_n_4 ,\derivative_reg[11]_i_57_n_5 ,\derivative_reg[11]_i_57_n_6 ,\derivative_reg[11]_i_57_n_7 }),
        .S({\derivative[11]_i_78_n_0 ,\derivative[11]_i_79_n_0 ,\derivative[11]_i_80_n_0 ,\derivative[11]_i_81_n_0 }));
  CARRY4 \derivative_reg[11]_i_6 
       (.CI(\derivative_reg[11]_i_10_n_0 ),
        .CO({\NLW_derivative_reg[11]_i_6_CO_UNCONNECTED [3:2],derivative1[11],\derivative_reg[11]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[12],\derivative_reg[15]_i_19_n_4 }),
        .O({\NLW_derivative_reg[11]_i_6_O_UNCONNECTED [3:1],\derivative_reg[11]_i_6_n_7 }),
        .S({1'b0,1'b0,\derivative[11]_i_11_n_0 ,\derivative[11]_i_12_n_0 }));
  CARRY4 \derivative_reg[11]_i_62 
       (.CI(\derivative_reg[11]_i_82_n_0 ),
        .CO({\derivative_reg[11]_i_62_n_0 ,\derivative_reg[11]_i_62_n_1 ,\derivative_reg[11]_i_62_n_2 ,\derivative_reg[11]_i_62_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_77_n_5 ,\derivative_reg[15]_i_77_n_6 ,\derivative_reg[15]_i_77_n_7 ,\derivative_reg[15]_i_97_n_4 }),
        .O({\derivative_reg[11]_i_62_n_4 ,\derivative_reg[11]_i_62_n_5 ,\derivative_reg[11]_i_62_n_6 ,\derivative_reg[11]_i_62_n_7 }),
        .S({\derivative[11]_i_83_n_0 ,\derivative[11]_i_84_n_0 ,\derivative[11]_i_85_n_0 ,\derivative[11]_i_86_n_0 }));
  CARRY4 \derivative_reg[11]_i_67 
       (.CI(\derivative_reg[11]_i_87_n_0 ),
        .CO({\derivative_reg[11]_i_67_n_0 ,\derivative_reg[11]_i_67_n_1 ,\derivative_reg[11]_i_67_n_2 ,\derivative_reg[11]_i_67_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_62_n_5 ,\derivative_reg[11]_i_62_n_6 ,\derivative_reg[11]_i_62_n_7 ,\derivative_reg[11]_i_82_n_4 }),
        .O({\derivative_reg[11]_i_67_n_4 ,\derivative_reg[11]_i_67_n_5 ,\derivative_reg[11]_i_67_n_6 ,\derivative_reg[11]_i_67_n_7 }),
        .S({\derivative[11]_i_88_n_0 ,\derivative[11]_i_89_n_0 ,\derivative[11]_i_90_n_0 ,\derivative[11]_i_91_n_0 }));
  CARRY4 \derivative_reg[11]_i_7 
       (.CI(\derivative_reg[11]_i_13_n_0 ),
        .CO({\NLW_derivative_reg[11]_i_7_CO_UNCONNECTED [3:2],derivative1[10],\derivative_reg[11]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[11],\derivative_reg[11]_i_10_n_4 }),
        .O({\NLW_derivative_reg[11]_i_7_O_UNCONNECTED [3:1],\derivative_reg[11]_i_7_n_7 }),
        .S({1'b0,1'b0,\derivative[11]_i_14_n_0 ,\derivative[11]_i_15_n_0 }));
  CARRY4 \derivative_reg[11]_i_72 
       (.CI(\derivative_reg[11]_i_92_n_0 ),
        .CO({\derivative_reg[11]_i_72_n_0 ,\derivative_reg[11]_i_72_n_1 ,\derivative_reg[11]_i_72_n_2 ,\derivative_reg[11]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_67_n_5 ,\derivative_reg[11]_i_67_n_6 ,\derivative_reg[11]_i_67_n_7 ,\derivative_reg[11]_i_87_n_4 }),
        .O({\derivative_reg[11]_i_72_n_4 ,\derivative_reg[11]_i_72_n_5 ,\derivative_reg[11]_i_72_n_6 ,\derivative_reg[11]_i_72_n_7 }),
        .S({\derivative[11]_i_93_n_0 ,\derivative[11]_i_94_n_0 ,\derivative[11]_i_95_n_0 ,\derivative[11]_i_96_n_0 }));
  CARRY4 \derivative_reg[11]_i_77 
       (.CI(\derivative_reg[11]_i_97_n_0 ),
        .CO({\derivative_reg[11]_i_77_n_0 ,\derivative_reg[11]_i_77_n_1 ,\derivative_reg[11]_i_77_n_2 ,\derivative_reg[11]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_72_n_5 ,\derivative_reg[11]_i_72_n_6 ,\derivative_reg[11]_i_72_n_7 ,\derivative_reg[11]_i_92_n_4 }),
        .O({\derivative_reg[11]_i_77_n_4 ,\derivative_reg[11]_i_77_n_5 ,\derivative_reg[11]_i_77_n_6 ,\derivative_reg[11]_i_77_n_7 }),
        .S({\derivative[11]_i_98_n_0 ,\derivative[11]_i_99_n_0 ,\derivative[11]_i_100_n_0 ,\derivative[11]_i_101_n_0 }));
  CARRY4 \derivative_reg[11]_i_8 
       (.CI(\derivative_reg[11]_i_16_n_0 ),
        .CO({\NLW_derivative_reg[11]_i_8_CO_UNCONNECTED [3:2],derivative1[9],\derivative_reg[11]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[10],\derivative_reg[11]_i_13_n_4 }),
        .O({\NLW_derivative_reg[11]_i_8_O_UNCONNECTED [3:1],\derivative_reg[11]_i_8_n_7 }),
        .S({1'b0,1'b0,\derivative[11]_i_17_n_0 ,\derivative[11]_i_18_n_0 }));
  CARRY4 \derivative_reg[11]_i_82 
       (.CI(\derivative_reg[11]_i_102_n_0 ),
        .CO({\derivative_reg[11]_i_82_n_0 ,\derivative_reg[11]_i_82_n_1 ,\derivative_reg[11]_i_82_n_2 ,\derivative_reg[11]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_97_n_5 ,\derivative_reg[15]_i_97_n_6 ,\derivative_reg[15]_i_97_n_7 ,\derivative_reg[15]_i_117_n_4 }),
        .O({\derivative_reg[11]_i_82_n_4 ,\derivative_reg[11]_i_82_n_5 ,\derivative_reg[11]_i_82_n_6 ,\derivative_reg[11]_i_82_n_7 }),
        .S({\derivative[11]_i_103_n_0 ,\derivative[11]_i_104_n_0 ,\derivative[11]_i_105_n_0 ,\derivative[11]_i_106_n_0 }));
  CARRY4 \derivative_reg[11]_i_87 
       (.CI(\derivative_reg[11]_i_107_n_0 ),
        .CO({\derivative_reg[11]_i_87_n_0 ,\derivative_reg[11]_i_87_n_1 ,\derivative_reg[11]_i_87_n_2 ,\derivative_reg[11]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_82_n_5 ,\derivative_reg[11]_i_82_n_6 ,\derivative_reg[11]_i_82_n_7 ,\derivative_reg[11]_i_102_n_4 }),
        .O({\derivative_reg[11]_i_87_n_4 ,\derivative_reg[11]_i_87_n_5 ,\derivative_reg[11]_i_87_n_6 ,\derivative_reg[11]_i_87_n_7 }),
        .S({\derivative[11]_i_108_n_0 ,\derivative[11]_i_109_n_0 ,\derivative[11]_i_110_n_0 ,\derivative[11]_i_111_n_0 }));
  CARRY4 \derivative_reg[11]_i_9 
       (.CI(\derivative_reg[11]_i_19_n_0 ),
        .CO({\NLW_derivative_reg[11]_i_9_CO_UNCONNECTED [3:2],derivative1[8],\derivative_reg[11]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[9],\derivative_reg[11]_i_16_n_4 }),
        .O({\NLW_derivative_reg[11]_i_9_O_UNCONNECTED [3:1],\derivative_reg[11]_i_9_n_7 }),
        .S({1'b0,1'b0,\derivative[11]_i_20_n_0 ,\derivative[11]_i_21_n_0 }));
  CARRY4 \derivative_reg[11]_i_92 
       (.CI(\derivative_reg[11]_i_112_n_0 ),
        .CO({\derivative_reg[11]_i_92_n_0 ,\derivative_reg[11]_i_92_n_1 ,\derivative_reg[11]_i_92_n_2 ,\derivative_reg[11]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_87_n_5 ,\derivative_reg[11]_i_87_n_6 ,\derivative_reg[11]_i_87_n_7 ,\derivative_reg[11]_i_107_n_4 }),
        .O({\derivative_reg[11]_i_92_n_4 ,\derivative_reg[11]_i_92_n_5 ,\derivative_reg[11]_i_92_n_6 ,\derivative_reg[11]_i_92_n_7 }),
        .S({\derivative[11]_i_113_n_0 ,\derivative[11]_i_114_n_0 ,\derivative[11]_i_115_n_0 ,\derivative[11]_i_116_n_0 }));
  CARRY4 \derivative_reg[11]_i_97 
       (.CI(\derivative_reg[11]_i_117_n_0 ),
        .CO({\derivative_reg[11]_i_97_n_0 ,\derivative_reg[11]_i_97_n_1 ,\derivative_reg[11]_i_97_n_2 ,\derivative_reg[11]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_92_n_5 ,\derivative_reg[11]_i_92_n_6 ,\derivative_reg[11]_i_92_n_7 ,\derivative_reg[11]_i_112_n_4 }),
        .O({\derivative_reg[11]_i_97_n_4 ,\derivative_reg[11]_i_97_n_5 ,\derivative_reg[11]_i_97_n_6 ,\derivative_reg[11]_i_97_n_7 }),
        .S({\derivative[11]_i_118_n_0 ,\derivative[11]_i_119_n_0 ,\derivative[11]_i_120_n_0 ,\derivative[11]_i_121_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[12] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[15]_i_1_n_7 ),
        .Q(derivative_out[12]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[13] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[15]_i_1_n_6 ),
        .Q(derivative_out[13]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[14] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[15]_i_1_n_5 ),
        .Q(derivative_out[14]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[15] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[15]_i_1_n_4 ),
        .Q(derivative_out[15]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[15]_i_1 
       (.CI(\derivative_reg[11]_i_1_n_0 ),
        .CO({\derivative_reg[15]_i_1_n_0 ,\derivative_reg[15]_i_1_n_1 ,\derivative_reg[15]_i_1_n_2 ,\derivative_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[15]_i_1_n_4 ,\derivative_reg[15]_i_1_n_5 ,\derivative_reg[15]_i_1_n_6 ,\derivative_reg[15]_i_1_n_7 }),
        .S({\derivative[15]_i_2_n_0 ,\derivative[15]_i_3_n_0 ,\derivative[15]_i_4_n_0 ,\derivative[15]_i_5_n_0 }));
  CARRY4 \derivative_reg[15]_i_10 
       (.CI(\derivative_reg[15]_i_22_n_0 ),
        .CO({\derivative_reg[15]_i_10_n_0 ,\derivative_reg[15]_i_10_n_1 ,\derivative_reg[15]_i_10_n_2 ,\derivative_reg[15]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_19_n_5 ,\derivative_reg[19]_i_19_n_6 ,\derivative_reg[19]_i_19_n_7 ,\derivative_reg[19]_i_37_n_4 }),
        .O({\derivative_reg[15]_i_10_n_4 ,\derivative_reg[15]_i_10_n_5 ,\derivative_reg[15]_i_10_n_6 ,\derivative_reg[15]_i_10_n_7 }),
        .S({\derivative[15]_i_23_n_0 ,\derivative[15]_i_24_n_0 ,\derivative[15]_i_25_n_0 ,\derivative[15]_i_26_n_0 }));
  CARRY4 \derivative_reg[15]_i_102 
       (.CI(\derivative_reg[15]_i_122_n_0 ),
        .CO({\derivative_reg[15]_i_102_n_0 ,\derivative_reg[15]_i_102_n_1 ,\derivative_reg[15]_i_102_n_2 ,\derivative_reg[15]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_117_n_5 ,\derivative_reg[19]_i_117_n_6 ,\derivative_reg[19]_i_117_n_7 ,\derivative_reg[19]_i_137_n_4 }),
        .O({\derivative_reg[15]_i_102_n_4 ,\derivative_reg[15]_i_102_n_5 ,\derivative_reg[15]_i_102_n_6 ,\derivative_reg[15]_i_102_n_7 }),
        .S({\derivative[15]_i_123_n_0 ,\derivative[15]_i_124_n_0 ,\derivative[15]_i_125_n_0 ,\derivative[15]_i_126_n_0 }));
  CARRY4 \derivative_reg[15]_i_107 
       (.CI(\derivative_reg[15]_i_127_n_0 ),
        .CO({\derivative_reg[15]_i_107_n_0 ,\derivative_reg[15]_i_107_n_1 ,\derivative_reg[15]_i_107_n_2 ,\derivative_reg[15]_i_107_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_102_n_5 ,\derivative_reg[15]_i_102_n_6 ,\derivative_reg[15]_i_102_n_7 ,\derivative_reg[15]_i_122_n_4 }),
        .O({\derivative_reg[15]_i_107_n_4 ,\derivative_reg[15]_i_107_n_5 ,\derivative_reg[15]_i_107_n_6 ,\derivative_reg[15]_i_107_n_7 }),
        .S({\derivative[15]_i_128_n_0 ,\derivative[15]_i_129_n_0 ,\derivative[15]_i_130_n_0 ,\derivative[15]_i_131_n_0 }));
  CARRY4 \derivative_reg[15]_i_112 
       (.CI(\derivative_reg[15]_i_132_n_0 ),
        .CO({\derivative_reg[15]_i_112_n_0 ,\derivative_reg[15]_i_112_n_1 ,\derivative_reg[15]_i_112_n_2 ,\derivative_reg[15]_i_112_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_107_n_5 ,\derivative_reg[15]_i_107_n_6 ,\derivative_reg[15]_i_107_n_7 ,\derivative_reg[15]_i_127_n_4 }),
        .O({\derivative_reg[15]_i_112_n_4 ,\derivative_reg[15]_i_112_n_5 ,\derivative_reg[15]_i_112_n_6 ,\derivative_reg[15]_i_112_n_7 }),
        .S({\derivative[15]_i_133_n_0 ,\derivative[15]_i_134_n_0 ,\derivative[15]_i_135_n_0 ,\derivative[15]_i_136_n_0 }));
  CARRY4 \derivative_reg[15]_i_117 
       (.CI(\derivative_reg[15]_i_137_n_0 ),
        .CO({\derivative_reg[15]_i_117_n_0 ,\derivative_reg[15]_i_117_n_1 ,\derivative_reg[15]_i_117_n_2 ,\derivative_reg[15]_i_117_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_112_n_5 ,\derivative_reg[15]_i_112_n_6 ,\derivative_reg[15]_i_112_n_7 ,\derivative_reg[15]_i_132_n_4 }),
        .O({\derivative_reg[15]_i_117_n_4 ,\derivative_reg[15]_i_117_n_5 ,\derivative_reg[15]_i_117_n_6 ,\derivative_reg[15]_i_117_n_7 }),
        .S({\derivative[15]_i_138_n_0 ,\derivative[15]_i_139_n_0 ,\derivative[15]_i_140_n_0 ,\derivative[15]_i_141_n_0 }));
  CARRY4 \derivative_reg[15]_i_122 
       (.CI(\derivative_reg[15]_i_142_n_0 ),
        .CO({\derivative_reg[15]_i_122_n_0 ,\derivative_reg[15]_i_122_n_1 ,\derivative_reg[15]_i_122_n_2 ,\derivative_reg[15]_i_122_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_137_n_5 ,\derivative_reg[19]_i_137_n_6 ,\derivative_reg[19]_i_137_n_7 ,\derivative_reg[19]_i_157_n_4 }),
        .O({\derivative_reg[15]_i_122_n_4 ,\derivative_reg[15]_i_122_n_5 ,\derivative_reg[15]_i_122_n_6 ,\derivative_reg[15]_i_122_n_7 }),
        .S({\derivative[15]_i_143_n_0 ,\derivative[15]_i_144_n_0 ,\derivative[15]_i_145_n_0 ,\derivative[15]_i_146_n_0 }));
  CARRY4 \derivative_reg[15]_i_127 
       (.CI(\derivative_reg[15]_i_147_n_0 ),
        .CO({\derivative_reg[15]_i_127_n_0 ,\derivative_reg[15]_i_127_n_1 ,\derivative_reg[15]_i_127_n_2 ,\derivative_reg[15]_i_127_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_122_n_5 ,\derivative_reg[15]_i_122_n_6 ,\derivative_reg[15]_i_122_n_7 ,\derivative_reg[15]_i_142_n_4 }),
        .O({\derivative_reg[15]_i_127_n_4 ,\derivative_reg[15]_i_127_n_5 ,\derivative_reg[15]_i_127_n_6 ,\derivative_reg[15]_i_127_n_7 }),
        .S({\derivative[15]_i_148_n_0 ,\derivative[15]_i_149_n_0 ,\derivative[15]_i_150_n_0 ,\derivative[15]_i_151_n_0 }));
  CARRY4 \derivative_reg[15]_i_13 
       (.CI(\derivative_reg[15]_i_27_n_0 ),
        .CO({\derivative_reg[15]_i_13_n_0 ,\derivative_reg[15]_i_13_n_1 ,\derivative_reg[15]_i_13_n_2 ,\derivative_reg[15]_i_13_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_10_n_5 ,\derivative_reg[15]_i_10_n_6 ,\derivative_reg[15]_i_10_n_7 ,\derivative_reg[15]_i_22_n_4 }),
        .O({\derivative_reg[15]_i_13_n_4 ,\derivative_reg[15]_i_13_n_5 ,\derivative_reg[15]_i_13_n_6 ,\derivative_reg[15]_i_13_n_7 }),
        .S({\derivative[15]_i_28_n_0 ,\derivative[15]_i_29_n_0 ,\derivative[15]_i_30_n_0 ,\derivative[15]_i_31_n_0 }));
  CARRY4 \derivative_reg[15]_i_132 
       (.CI(\derivative_reg[15]_i_152_n_0 ),
        .CO({\derivative_reg[15]_i_132_n_0 ,\derivative_reg[15]_i_132_n_1 ,\derivative_reg[15]_i_132_n_2 ,\derivative_reg[15]_i_132_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_127_n_5 ,\derivative_reg[15]_i_127_n_6 ,\derivative_reg[15]_i_127_n_7 ,\derivative_reg[15]_i_147_n_4 }),
        .O({\derivative_reg[15]_i_132_n_4 ,\derivative_reg[15]_i_132_n_5 ,\derivative_reg[15]_i_132_n_6 ,\derivative_reg[15]_i_132_n_7 }),
        .S({\derivative[15]_i_153_n_0 ,\derivative[15]_i_154_n_0 ,\derivative[15]_i_155_n_0 ,\derivative[15]_i_156_n_0 }));
  CARRY4 \derivative_reg[15]_i_137 
       (.CI(\derivative_reg[15]_i_157_n_0 ),
        .CO({\derivative_reg[15]_i_137_n_0 ,\derivative_reg[15]_i_137_n_1 ,\derivative_reg[15]_i_137_n_2 ,\derivative_reg[15]_i_137_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_132_n_5 ,\derivative_reg[15]_i_132_n_6 ,\derivative_reg[15]_i_132_n_7 ,\derivative_reg[15]_i_152_n_4 }),
        .O({\derivative_reg[15]_i_137_n_4 ,\derivative_reg[15]_i_137_n_5 ,\derivative_reg[15]_i_137_n_6 ,\derivative_reg[15]_i_137_n_7 }),
        .S({\derivative[15]_i_158_n_0 ,\derivative[15]_i_159_n_0 ,\derivative[15]_i_160_n_0 ,\derivative[15]_i_161_n_0 }));
  CARRY4 \derivative_reg[15]_i_142 
       (.CI(1'b0),
        .CO({\derivative_reg[15]_i_142_n_0 ,\derivative_reg[15]_i_142_n_1 ,\derivative_reg[15]_i_142_n_2 ,\derivative_reg[15]_i_142_n_3 }),
        .CYINIT(derivative1[16]),
        .DI({\derivative_reg[19]_i_157_n_5 ,\derivative_reg[19]_i_157_n_6 ,derivative20_in[15],1'b0}),
        .O({\derivative_reg[15]_i_142_n_4 ,\derivative_reg[15]_i_142_n_5 ,\derivative_reg[15]_i_142_n_6 ,\NLW_derivative_reg[15]_i_142_O_UNCONNECTED [0]}),
        .S({\derivative[15]_i_163_n_0 ,\derivative[15]_i_164_n_0 ,\derivative[15]_i_165_n_0 ,1'b1}));
  CARRY4 \derivative_reg[15]_i_147 
       (.CI(1'b0),
        .CO({\derivative_reg[15]_i_147_n_0 ,\derivative_reg[15]_i_147_n_1 ,\derivative_reg[15]_i_147_n_2 ,\derivative_reg[15]_i_147_n_3 }),
        .CYINIT(derivative1[15]),
        .DI({\derivative_reg[15]_i_142_n_5 ,\derivative_reg[15]_i_142_n_6 ,derivative20_in[14],1'b0}),
        .O({\derivative_reg[15]_i_147_n_4 ,\derivative_reg[15]_i_147_n_5 ,\derivative_reg[15]_i_147_n_6 ,\NLW_derivative_reg[15]_i_147_O_UNCONNECTED [0]}),
        .S({\derivative[15]_i_167_n_0 ,\derivative[15]_i_168_n_0 ,\derivative[15]_i_169_n_0 ,1'b1}));
  CARRY4 \derivative_reg[15]_i_152 
       (.CI(1'b0),
        .CO({\derivative_reg[15]_i_152_n_0 ,\derivative_reg[15]_i_152_n_1 ,\derivative_reg[15]_i_152_n_2 ,\derivative_reg[15]_i_152_n_3 }),
        .CYINIT(derivative1[14]),
        .DI({\derivative_reg[15]_i_147_n_5 ,\derivative_reg[15]_i_147_n_6 ,derivative20_in[13],1'b0}),
        .O({\derivative_reg[15]_i_152_n_4 ,\derivative_reg[15]_i_152_n_5 ,\derivative_reg[15]_i_152_n_6 ,\NLW_derivative_reg[15]_i_152_O_UNCONNECTED [0]}),
        .S({\derivative[15]_i_171_n_0 ,\derivative[15]_i_172_n_0 ,\derivative[15]_i_173_n_0 ,1'b1}));
  CARRY4 \derivative_reg[15]_i_157 
       (.CI(1'b0),
        .CO({\derivative_reg[15]_i_157_n_0 ,\derivative_reg[15]_i_157_n_1 ,\derivative_reg[15]_i_157_n_2 ,\derivative_reg[15]_i_157_n_3 }),
        .CYINIT(derivative1[13]),
        .DI({\derivative_reg[15]_i_152_n_5 ,\derivative_reg[15]_i_152_n_6 ,derivative20_in[12],1'b0}),
        .O({\derivative_reg[15]_i_157_n_4 ,\derivative_reg[15]_i_157_n_5 ,\derivative_reg[15]_i_157_n_6 ,\NLW_derivative_reg[15]_i_157_O_UNCONNECTED [0]}),
        .S({\derivative[15]_i_175_n_0 ,\derivative[15]_i_176_n_0 ,\derivative[15]_i_177_n_0 ,1'b1}));
  CARRY4 \derivative_reg[15]_i_16 
       (.CI(\derivative_reg[15]_i_32_n_0 ),
        .CO({\derivative_reg[15]_i_16_n_0 ,\derivative_reg[15]_i_16_n_1 ,\derivative_reg[15]_i_16_n_2 ,\derivative_reg[15]_i_16_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_13_n_5 ,\derivative_reg[15]_i_13_n_6 ,\derivative_reg[15]_i_13_n_7 ,\derivative_reg[15]_i_27_n_4 }),
        .O({\derivative_reg[15]_i_16_n_4 ,\derivative_reg[15]_i_16_n_5 ,\derivative_reg[15]_i_16_n_6 ,\derivative_reg[15]_i_16_n_7 }),
        .S({\derivative[15]_i_33_n_0 ,\derivative[15]_i_34_n_0 ,\derivative[15]_i_35_n_0 ,\derivative[15]_i_36_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[15]_i_178 
       (.CI(\derivative_reg[11]_i_178_n_0 ),
        .CO({\derivative_reg[15]_i_178_n_0 ,\derivative_reg[15]_i_178_n_1 ,\derivative_reg[15]_i_178_n_2 ,\derivative_reg[15]_i_178_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[15]_i_178_n_4 ,\derivative_reg[15]_i_178_n_5 ,\derivative_reg[15]_i_178_n_6 ,\derivative_reg[15]_i_178_n_7 }),
        .S({\derivative[15]_i_179_n_0 ,\derivative[15]_i_180_n_0 ,\derivative[15]_i_181_n_0 ,\derivative[15]_i_182_n_0 }));
  CARRY4 \derivative_reg[15]_i_19 
       (.CI(\derivative_reg[15]_i_37_n_0 ),
        .CO({\derivative_reg[15]_i_19_n_0 ,\derivative_reg[15]_i_19_n_1 ,\derivative_reg[15]_i_19_n_2 ,\derivative_reg[15]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_16_n_5 ,\derivative_reg[15]_i_16_n_6 ,\derivative_reg[15]_i_16_n_7 ,\derivative_reg[15]_i_32_n_4 }),
        .O({\derivative_reg[15]_i_19_n_4 ,\derivative_reg[15]_i_19_n_5 ,\derivative_reg[15]_i_19_n_6 ,\derivative_reg[15]_i_19_n_7 }),
        .S({\derivative[15]_i_38_n_0 ,\derivative[15]_i_39_n_0 ,\derivative[15]_i_40_n_0 ,\derivative[15]_i_41_n_0 }));
  CARRY4 \derivative_reg[15]_i_22 
       (.CI(\derivative_reg[15]_i_42_n_0 ),
        .CO({\derivative_reg[15]_i_22_n_0 ,\derivative_reg[15]_i_22_n_1 ,\derivative_reg[15]_i_22_n_2 ,\derivative_reg[15]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_37_n_5 ,\derivative_reg[19]_i_37_n_6 ,\derivative_reg[19]_i_37_n_7 ,\derivative_reg[19]_i_57_n_4 }),
        .O({\derivative_reg[15]_i_22_n_4 ,\derivative_reg[15]_i_22_n_5 ,\derivative_reg[15]_i_22_n_6 ,\derivative_reg[15]_i_22_n_7 }),
        .S({\derivative[15]_i_43_n_0 ,\derivative[15]_i_44_n_0 ,\derivative[15]_i_45_n_0 ,\derivative[15]_i_46_n_0 }));
  CARRY4 \derivative_reg[15]_i_27 
       (.CI(\derivative_reg[15]_i_47_n_0 ),
        .CO({\derivative_reg[15]_i_27_n_0 ,\derivative_reg[15]_i_27_n_1 ,\derivative_reg[15]_i_27_n_2 ,\derivative_reg[15]_i_27_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_22_n_5 ,\derivative_reg[15]_i_22_n_6 ,\derivative_reg[15]_i_22_n_7 ,\derivative_reg[15]_i_42_n_4 }),
        .O({\derivative_reg[15]_i_27_n_4 ,\derivative_reg[15]_i_27_n_5 ,\derivative_reg[15]_i_27_n_6 ,\derivative_reg[15]_i_27_n_7 }),
        .S({\derivative[15]_i_48_n_0 ,\derivative[15]_i_49_n_0 ,\derivative[15]_i_50_n_0 ,\derivative[15]_i_51_n_0 }));
  CARRY4 \derivative_reg[15]_i_32 
       (.CI(\derivative_reg[15]_i_52_n_0 ),
        .CO({\derivative_reg[15]_i_32_n_0 ,\derivative_reg[15]_i_32_n_1 ,\derivative_reg[15]_i_32_n_2 ,\derivative_reg[15]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_27_n_5 ,\derivative_reg[15]_i_27_n_6 ,\derivative_reg[15]_i_27_n_7 ,\derivative_reg[15]_i_47_n_4 }),
        .O({\derivative_reg[15]_i_32_n_4 ,\derivative_reg[15]_i_32_n_5 ,\derivative_reg[15]_i_32_n_6 ,\derivative_reg[15]_i_32_n_7 }),
        .S({\derivative[15]_i_53_n_0 ,\derivative[15]_i_54_n_0 ,\derivative[15]_i_55_n_0 ,\derivative[15]_i_56_n_0 }));
  CARRY4 \derivative_reg[15]_i_37 
       (.CI(\derivative_reg[15]_i_57_n_0 ),
        .CO({\derivative_reg[15]_i_37_n_0 ,\derivative_reg[15]_i_37_n_1 ,\derivative_reg[15]_i_37_n_2 ,\derivative_reg[15]_i_37_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_32_n_5 ,\derivative_reg[15]_i_32_n_6 ,\derivative_reg[15]_i_32_n_7 ,\derivative_reg[15]_i_52_n_4 }),
        .O({\derivative_reg[15]_i_37_n_4 ,\derivative_reg[15]_i_37_n_5 ,\derivative_reg[15]_i_37_n_6 ,\derivative_reg[15]_i_37_n_7 }),
        .S({\derivative[15]_i_58_n_0 ,\derivative[15]_i_59_n_0 ,\derivative[15]_i_60_n_0 ,\derivative[15]_i_61_n_0 }));
  CARRY4 \derivative_reg[15]_i_42 
       (.CI(\derivative_reg[15]_i_62_n_0 ),
        .CO({\derivative_reg[15]_i_42_n_0 ,\derivative_reg[15]_i_42_n_1 ,\derivative_reg[15]_i_42_n_2 ,\derivative_reg[15]_i_42_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_57_n_5 ,\derivative_reg[19]_i_57_n_6 ,\derivative_reg[19]_i_57_n_7 ,\derivative_reg[19]_i_77_n_4 }),
        .O({\derivative_reg[15]_i_42_n_4 ,\derivative_reg[15]_i_42_n_5 ,\derivative_reg[15]_i_42_n_6 ,\derivative_reg[15]_i_42_n_7 }),
        .S({\derivative[15]_i_63_n_0 ,\derivative[15]_i_64_n_0 ,\derivative[15]_i_65_n_0 ,\derivative[15]_i_66_n_0 }));
  CARRY4 \derivative_reg[15]_i_47 
       (.CI(\derivative_reg[15]_i_67_n_0 ),
        .CO({\derivative_reg[15]_i_47_n_0 ,\derivative_reg[15]_i_47_n_1 ,\derivative_reg[15]_i_47_n_2 ,\derivative_reg[15]_i_47_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_42_n_5 ,\derivative_reg[15]_i_42_n_6 ,\derivative_reg[15]_i_42_n_7 ,\derivative_reg[15]_i_62_n_4 }),
        .O({\derivative_reg[15]_i_47_n_4 ,\derivative_reg[15]_i_47_n_5 ,\derivative_reg[15]_i_47_n_6 ,\derivative_reg[15]_i_47_n_7 }),
        .S({\derivative[15]_i_68_n_0 ,\derivative[15]_i_69_n_0 ,\derivative[15]_i_70_n_0 ,\derivative[15]_i_71_n_0 }));
  CARRY4 \derivative_reg[15]_i_52 
       (.CI(\derivative_reg[15]_i_72_n_0 ),
        .CO({\derivative_reg[15]_i_52_n_0 ,\derivative_reg[15]_i_52_n_1 ,\derivative_reg[15]_i_52_n_2 ,\derivative_reg[15]_i_52_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_47_n_5 ,\derivative_reg[15]_i_47_n_6 ,\derivative_reg[15]_i_47_n_7 ,\derivative_reg[15]_i_67_n_4 }),
        .O({\derivative_reg[15]_i_52_n_4 ,\derivative_reg[15]_i_52_n_5 ,\derivative_reg[15]_i_52_n_6 ,\derivative_reg[15]_i_52_n_7 }),
        .S({\derivative[15]_i_73_n_0 ,\derivative[15]_i_74_n_0 ,\derivative[15]_i_75_n_0 ,\derivative[15]_i_76_n_0 }));
  CARRY4 \derivative_reg[15]_i_57 
       (.CI(\derivative_reg[15]_i_77_n_0 ),
        .CO({\derivative_reg[15]_i_57_n_0 ,\derivative_reg[15]_i_57_n_1 ,\derivative_reg[15]_i_57_n_2 ,\derivative_reg[15]_i_57_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_52_n_5 ,\derivative_reg[15]_i_52_n_6 ,\derivative_reg[15]_i_52_n_7 ,\derivative_reg[15]_i_72_n_4 }),
        .O({\derivative_reg[15]_i_57_n_4 ,\derivative_reg[15]_i_57_n_5 ,\derivative_reg[15]_i_57_n_6 ,\derivative_reg[15]_i_57_n_7 }),
        .S({\derivative[15]_i_78_n_0 ,\derivative[15]_i_79_n_0 ,\derivative[15]_i_80_n_0 ,\derivative[15]_i_81_n_0 }));
  CARRY4 \derivative_reg[15]_i_6 
       (.CI(\derivative_reg[15]_i_10_n_0 ),
        .CO({\NLW_derivative_reg[15]_i_6_CO_UNCONNECTED [3:2],derivative1[15],\derivative_reg[15]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[16],\derivative_reg[19]_i_19_n_4 }),
        .O({\NLW_derivative_reg[15]_i_6_O_UNCONNECTED [3:1],\derivative_reg[15]_i_6_n_7 }),
        .S({1'b0,1'b0,\derivative[15]_i_11_n_0 ,\derivative[15]_i_12_n_0 }));
  CARRY4 \derivative_reg[15]_i_62 
       (.CI(\derivative_reg[15]_i_82_n_0 ),
        .CO({\derivative_reg[15]_i_62_n_0 ,\derivative_reg[15]_i_62_n_1 ,\derivative_reg[15]_i_62_n_2 ,\derivative_reg[15]_i_62_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_77_n_5 ,\derivative_reg[19]_i_77_n_6 ,\derivative_reg[19]_i_77_n_7 ,\derivative_reg[19]_i_97_n_4 }),
        .O({\derivative_reg[15]_i_62_n_4 ,\derivative_reg[15]_i_62_n_5 ,\derivative_reg[15]_i_62_n_6 ,\derivative_reg[15]_i_62_n_7 }),
        .S({\derivative[15]_i_83_n_0 ,\derivative[15]_i_84_n_0 ,\derivative[15]_i_85_n_0 ,\derivative[15]_i_86_n_0 }));
  CARRY4 \derivative_reg[15]_i_67 
       (.CI(\derivative_reg[15]_i_87_n_0 ),
        .CO({\derivative_reg[15]_i_67_n_0 ,\derivative_reg[15]_i_67_n_1 ,\derivative_reg[15]_i_67_n_2 ,\derivative_reg[15]_i_67_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_62_n_5 ,\derivative_reg[15]_i_62_n_6 ,\derivative_reg[15]_i_62_n_7 ,\derivative_reg[15]_i_82_n_4 }),
        .O({\derivative_reg[15]_i_67_n_4 ,\derivative_reg[15]_i_67_n_5 ,\derivative_reg[15]_i_67_n_6 ,\derivative_reg[15]_i_67_n_7 }),
        .S({\derivative[15]_i_88_n_0 ,\derivative[15]_i_89_n_0 ,\derivative[15]_i_90_n_0 ,\derivative[15]_i_91_n_0 }));
  CARRY4 \derivative_reg[15]_i_7 
       (.CI(\derivative_reg[15]_i_13_n_0 ),
        .CO({\NLW_derivative_reg[15]_i_7_CO_UNCONNECTED [3:2],derivative1[14],\derivative_reg[15]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[15],\derivative_reg[15]_i_10_n_4 }),
        .O({\NLW_derivative_reg[15]_i_7_O_UNCONNECTED [3:1],\derivative_reg[15]_i_7_n_7 }),
        .S({1'b0,1'b0,\derivative[15]_i_14_n_0 ,\derivative[15]_i_15_n_0 }));
  CARRY4 \derivative_reg[15]_i_72 
       (.CI(\derivative_reg[15]_i_92_n_0 ),
        .CO({\derivative_reg[15]_i_72_n_0 ,\derivative_reg[15]_i_72_n_1 ,\derivative_reg[15]_i_72_n_2 ,\derivative_reg[15]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_67_n_5 ,\derivative_reg[15]_i_67_n_6 ,\derivative_reg[15]_i_67_n_7 ,\derivative_reg[15]_i_87_n_4 }),
        .O({\derivative_reg[15]_i_72_n_4 ,\derivative_reg[15]_i_72_n_5 ,\derivative_reg[15]_i_72_n_6 ,\derivative_reg[15]_i_72_n_7 }),
        .S({\derivative[15]_i_93_n_0 ,\derivative[15]_i_94_n_0 ,\derivative[15]_i_95_n_0 ,\derivative[15]_i_96_n_0 }));
  CARRY4 \derivative_reg[15]_i_77 
       (.CI(\derivative_reg[15]_i_97_n_0 ),
        .CO({\derivative_reg[15]_i_77_n_0 ,\derivative_reg[15]_i_77_n_1 ,\derivative_reg[15]_i_77_n_2 ,\derivative_reg[15]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_72_n_5 ,\derivative_reg[15]_i_72_n_6 ,\derivative_reg[15]_i_72_n_7 ,\derivative_reg[15]_i_92_n_4 }),
        .O({\derivative_reg[15]_i_77_n_4 ,\derivative_reg[15]_i_77_n_5 ,\derivative_reg[15]_i_77_n_6 ,\derivative_reg[15]_i_77_n_7 }),
        .S({\derivative[15]_i_98_n_0 ,\derivative[15]_i_99_n_0 ,\derivative[15]_i_100_n_0 ,\derivative[15]_i_101_n_0 }));
  CARRY4 \derivative_reg[15]_i_8 
       (.CI(\derivative_reg[15]_i_16_n_0 ),
        .CO({\NLW_derivative_reg[15]_i_8_CO_UNCONNECTED [3:2],derivative1[13],\derivative_reg[15]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[14],\derivative_reg[15]_i_13_n_4 }),
        .O({\NLW_derivative_reg[15]_i_8_O_UNCONNECTED [3:1],\derivative_reg[15]_i_8_n_7 }),
        .S({1'b0,1'b0,\derivative[15]_i_17_n_0 ,\derivative[15]_i_18_n_0 }));
  CARRY4 \derivative_reg[15]_i_82 
       (.CI(\derivative_reg[15]_i_102_n_0 ),
        .CO({\derivative_reg[15]_i_82_n_0 ,\derivative_reg[15]_i_82_n_1 ,\derivative_reg[15]_i_82_n_2 ,\derivative_reg[15]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_97_n_5 ,\derivative_reg[19]_i_97_n_6 ,\derivative_reg[19]_i_97_n_7 ,\derivative_reg[19]_i_117_n_4 }),
        .O({\derivative_reg[15]_i_82_n_4 ,\derivative_reg[15]_i_82_n_5 ,\derivative_reg[15]_i_82_n_6 ,\derivative_reg[15]_i_82_n_7 }),
        .S({\derivative[15]_i_103_n_0 ,\derivative[15]_i_104_n_0 ,\derivative[15]_i_105_n_0 ,\derivative[15]_i_106_n_0 }));
  CARRY4 \derivative_reg[15]_i_87 
       (.CI(\derivative_reg[15]_i_107_n_0 ),
        .CO({\derivative_reg[15]_i_87_n_0 ,\derivative_reg[15]_i_87_n_1 ,\derivative_reg[15]_i_87_n_2 ,\derivative_reg[15]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_82_n_5 ,\derivative_reg[15]_i_82_n_6 ,\derivative_reg[15]_i_82_n_7 ,\derivative_reg[15]_i_102_n_4 }),
        .O({\derivative_reg[15]_i_87_n_4 ,\derivative_reg[15]_i_87_n_5 ,\derivative_reg[15]_i_87_n_6 ,\derivative_reg[15]_i_87_n_7 }),
        .S({\derivative[15]_i_108_n_0 ,\derivative[15]_i_109_n_0 ,\derivative[15]_i_110_n_0 ,\derivative[15]_i_111_n_0 }));
  CARRY4 \derivative_reg[15]_i_9 
       (.CI(\derivative_reg[15]_i_19_n_0 ),
        .CO({\NLW_derivative_reg[15]_i_9_CO_UNCONNECTED [3:2],derivative1[12],\derivative_reg[15]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[13],\derivative_reg[15]_i_16_n_4 }),
        .O({\NLW_derivative_reg[15]_i_9_O_UNCONNECTED [3:1],\derivative_reg[15]_i_9_n_7 }),
        .S({1'b0,1'b0,\derivative[15]_i_20_n_0 ,\derivative[15]_i_21_n_0 }));
  CARRY4 \derivative_reg[15]_i_92 
       (.CI(\derivative_reg[15]_i_112_n_0 ),
        .CO({\derivative_reg[15]_i_92_n_0 ,\derivative_reg[15]_i_92_n_1 ,\derivative_reg[15]_i_92_n_2 ,\derivative_reg[15]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_87_n_5 ,\derivative_reg[15]_i_87_n_6 ,\derivative_reg[15]_i_87_n_7 ,\derivative_reg[15]_i_107_n_4 }),
        .O({\derivative_reg[15]_i_92_n_4 ,\derivative_reg[15]_i_92_n_5 ,\derivative_reg[15]_i_92_n_6 ,\derivative_reg[15]_i_92_n_7 }),
        .S({\derivative[15]_i_113_n_0 ,\derivative[15]_i_114_n_0 ,\derivative[15]_i_115_n_0 ,\derivative[15]_i_116_n_0 }));
  CARRY4 \derivative_reg[15]_i_97 
       (.CI(\derivative_reg[15]_i_117_n_0 ),
        .CO({\derivative_reg[15]_i_97_n_0 ,\derivative_reg[15]_i_97_n_1 ,\derivative_reg[15]_i_97_n_2 ,\derivative_reg[15]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[15]_i_92_n_5 ,\derivative_reg[15]_i_92_n_6 ,\derivative_reg[15]_i_92_n_7 ,\derivative_reg[15]_i_112_n_4 }),
        .O({\derivative_reg[15]_i_97_n_4 ,\derivative_reg[15]_i_97_n_5 ,\derivative_reg[15]_i_97_n_6 ,\derivative_reg[15]_i_97_n_7 }),
        .S({\derivative[15]_i_118_n_0 ,\derivative[15]_i_119_n_0 ,\derivative[15]_i_120_n_0 ,\derivative[15]_i_121_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[16] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[19]_i_1_n_7 ),
        .Q(derivative_out[16]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[17] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[19]_i_1_n_6 ),
        .Q(derivative_out[17]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[18] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[19]_i_1_n_5 ),
        .Q(derivative_out[18]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[19] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[19]_i_1_n_4 ),
        .Q(derivative_out[19]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[19]_i_1 
       (.CI(\derivative_reg[15]_i_1_n_0 ),
        .CO({\derivative_reg[19]_i_1_n_0 ,\derivative_reg[19]_i_1_n_1 ,\derivative_reg[19]_i_1_n_2 ,\derivative_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[19]_i_1_n_4 ,\derivative_reg[19]_i_1_n_5 ,\derivative_reg[19]_i_1_n_6 ,\derivative_reg[19]_i_1_n_7 }),
        .S({\derivative[19]_i_2_n_0 ,\derivative[19]_i_3_n_0 ,\derivative[19]_i_4_n_0 ,\derivative[19]_i_5_n_0 }));
  CARRY4 \derivative_reg[19]_i_10 
       (.CI(\derivative_reg[19]_i_22_n_0 ),
        .CO({\derivative_reg[19]_i_10_n_0 ,\derivative_reg[19]_i_10_n_1 ,\derivative_reg[19]_i_10_n_2 ,\derivative_reg[19]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_19_n_5 ,\derivative_reg[23]_i_19_n_6 ,\derivative_reg[23]_i_19_n_7 ,\derivative_reg[23]_i_37_n_4 }),
        .O({\derivative_reg[19]_i_10_n_4 ,\derivative_reg[19]_i_10_n_5 ,\derivative_reg[19]_i_10_n_6 ,\derivative_reg[19]_i_10_n_7 }),
        .S({\derivative[19]_i_23_n_0 ,\derivative[19]_i_24_n_0 ,\derivative[19]_i_25_n_0 ,\derivative[19]_i_26_n_0 }));
  CARRY4 \derivative_reg[19]_i_102 
       (.CI(\derivative_reg[19]_i_122_n_0 ),
        .CO({\derivative_reg[19]_i_102_n_0 ,\derivative_reg[19]_i_102_n_1 ,\derivative_reg[19]_i_102_n_2 ,\derivative_reg[19]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_117_n_5 ,\derivative_reg[23]_i_117_n_6 ,\derivative_reg[23]_i_117_n_7 ,\derivative_reg[23]_i_137_n_4 }),
        .O({\derivative_reg[19]_i_102_n_4 ,\derivative_reg[19]_i_102_n_5 ,\derivative_reg[19]_i_102_n_6 ,\derivative_reg[19]_i_102_n_7 }),
        .S({\derivative[19]_i_123_n_0 ,\derivative[19]_i_124_n_0 ,\derivative[19]_i_125_n_0 ,\derivative[19]_i_126_n_0 }));
  CARRY4 \derivative_reg[19]_i_107 
       (.CI(\derivative_reg[19]_i_127_n_0 ),
        .CO({\derivative_reg[19]_i_107_n_0 ,\derivative_reg[19]_i_107_n_1 ,\derivative_reg[19]_i_107_n_2 ,\derivative_reg[19]_i_107_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_102_n_5 ,\derivative_reg[19]_i_102_n_6 ,\derivative_reg[19]_i_102_n_7 ,\derivative_reg[19]_i_122_n_4 }),
        .O({\derivative_reg[19]_i_107_n_4 ,\derivative_reg[19]_i_107_n_5 ,\derivative_reg[19]_i_107_n_6 ,\derivative_reg[19]_i_107_n_7 }),
        .S({\derivative[19]_i_128_n_0 ,\derivative[19]_i_129_n_0 ,\derivative[19]_i_130_n_0 ,\derivative[19]_i_131_n_0 }));
  CARRY4 \derivative_reg[19]_i_112 
       (.CI(\derivative_reg[19]_i_132_n_0 ),
        .CO({\derivative_reg[19]_i_112_n_0 ,\derivative_reg[19]_i_112_n_1 ,\derivative_reg[19]_i_112_n_2 ,\derivative_reg[19]_i_112_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_107_n_5 ,\derivative_reg[19]_i_107_n_6 ,\derivative_reg[19]_i_107_n_7 ,\derivative_reg[19]_i_127_n_4 }),
        .O({\derivative_reg[19]_i_112_n_4 ,\derivative_reg[19]_i_112_n_5 ,\derivative_reg[19]_i_112_n_6 ,\derivative_reg[19]_i_112_n_7 }),
        .S({\derivative[19]_i_133_n_0 ,\derivative[19]_i_134_n_0 ,\derivative[19]_i_135_n_0 ,\derivative[19]_i_136_n_0 }));
  CARRY4 \derivative_reg[19]_i_117 
       (.CI(\derivative_reg[19]_i_137_n_0 ),
        .CO({\derivative_reg[19]_i_117_n_0 ,\derivative_reg[19]_i_117_n_1 ,\derivative_reg[19]_i_117_n_2 ,\derivative_reg[19]_i_117_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_112_n_5 ,\derivative_reg[19]_i_112_n_6 ,\derivative_reg[19]_i_112_n_7 ,\derivative_reg[19]_i_132_n_4 }),
        .O({\derivative_reg[19]_i_117_n_4 ,\derivative_reg[19]_i_117_n_5 ,\derivative_reg[19]_i_117_n_6 ,\derivative_reg[19]_i_117_n_7 }),
        .S({\derivative[19]_i_138_n_0 ,\derivative[19]_i_139_n_0 ,\derivative[19]_i_140_n_0 ,\derivative[19]_i_141_n_0 }));
  CARRY4 \derivative_reg[19]_i_122 
       (.CI(\derivative_reg[19]_i_142_n_0 ),
        .CO({\derivative_reg[19]_i_122_n_0 ,\derivative_reg[19]_i_122_n_1 ,\derivative_reg[19]_i_122_n_2 ,\derivative_reg[19]_i_122_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_137_n_5 ,\derivative_reg[23]_i_137_n_6 ,\derivative_reg[23]_i_137_n_7 ,\derivative_reg[23]_i_157_n_4 }),
        .O({\derivative_reg[19]_i_122_n_4 ,\derivative_reg[19]_i_122_n_5 ,\derivative_reg[19]_i_122_n_6 ,\derivative_reg[19]_i_122_n_7 }),
        .S({\derivative[19]_i_143_n_0 ,\derivative[19]_i_144_n_0 ,\derivative[19]_i_145_n_0 ,\derivative[19]_i_146_n_0 }));
  CARRY4 \derivative_reg[19]_i_127 
       (.CI(\derivative_reg[19]_i_147_n_0 ),
        .CO({\derivative_reg[19]_i_127_n_0 ,\derivative_reg[19]_i_127_n_1 ,\derivative_reg[19]_i_127_n_2 ,\derivative_reg[19]_i_127_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_122_n_5 ,\derivative_reg[19]_i_122_n_6 ,\derivative_reg[19]_i_122_n_7 ,\derivative_reg[19]_i_142_n_4 }),
        .O({\derivative_reg[19]_i_127_n_4 ,\derivative_reg[19]_i_127_n_5 ,\derivative_reg[19]_i_127_n_6 ,\derivative_reg[19]_i_127_n_7 }),
        .S({\derivative[19]_i_148_n_0 ,\derivative[19]_i_149_n_0 ,\derivative[19]_i_150_n_0 ,\derivative[19]_i_151_n_0 }));
  CARRY4 \derivative_reg[19]_i_13 
       (.CI(\derivative_reg[19]_i_27_n_0 ),
        .CO({\derivative_reg[19]_i_13_n_0 ,\derivative_reg[19]_i_13_n_1 ,\derivative_reg[19]_i_13_n_2 ,\derivative_reg[19]_i_13_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_10_n_5 ,\derivative_reg[19]_i_10_n_6 ,\derivative_reg[19]_i_10_n_7 ,\derivative_reg[19]_i_22_n_4 }),
        .O({\derivative_reg[19]_i_13_n_4 ,\derivative_reg[19]_i_13_n_5 ,\derivative_reg[19]_i_13_n_6 ,\derivative_reg[19]_i_13_n_7 }),
        .S({\derivative[19]_i_28_n_0 ,\derivative[19]_i_29_n_0 ,\derivative[19]_i_30_n_0 ,\derivative[19]_i_31_n_0 }));
  CARRY4 \derivative_reg[19]_i_132 
       (.CI(\derivative_reg[19]_i_152_n_0 ),
        .CO({\derivative_reg[19]_i_132_n_0 ,\derivative_reg[19]_i_132_n_1 ,\derivative_reg[19]_i_132_n_2 ,\derivative_reg[19]_i_132_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_127_n_5 ,\derivative_reg[19]_i_127_n_6 ,\derivative_reg[19]_i_127_n_7 ,\derivative_reg[19]_i_147_n_4 }),
        .O({\derivative_reg[19]_i_132_n_4 ,\derivative_reg[19]_i_132_n_5 ,\derivative_reg[19]_i_132_n_6 ,\derivative_reg[19]_i_132_n_7 }),
        .S({\derivative[19]_i_153_n_0 ,\derivative[19]_i_154_n_0 ,\derivative[19]_i_155_n_0 ,\derivative[19]_i_156_n_0 }));
  CARRY4 \derivative_reg[19]_i_137 
       (.CI(\derivative_reg[19]_i_157_n_0 ),
        .CO({\derivative_reg[19]_i_137_n_0 ,\derivative_reg[19]_i_137_n_1 ,\derivative_reg[19]_i_137_n_2 ,\derivative_reg[19]_i_137_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_132_n_5 ,\derivative_reg[19]_i_132_n_6 ,\derivative_reg[19]_i_132_n_7 ,\derivative_reg[19]_i_152_n_4 }),
        .O({\derivative_reg[19]_i_137_n_4 ,\derivative_reg[19]_i_137_n_5 ,\derivative_reg[19]_i_137_n_6 ,\derivative_reg[19]_i_137_n_7 }),
        .S({\derivative[19]_i_158_n_0 ,\derivative[19]_i_159_n_0 ,\derivative[19]_i_160_n_0 ,\derivative[19]_i_161_n_0 }));
  CARRY4 \derivative_reg[19]_i_142 
       (.CI(1'b0),
        .CO({\derivative_reg[19]_i_142_n_0 ,\derivative_reg[19]_i_142_n_1 ,\derivative_reg[19]_i_142_n_2 ,\derivative_reg[19]_i_142_n_3 }),
        .CYINIT(derivative1[20]),
        .DI({\derivative_reg[23]_i_157_n_5 ,\derivative_reg[23]_i_157_n_6 ,derivative20_in[19],1'b0}),
        .O({\derivative_reg[19]_i_142_n_4 ,\derivative_reg[19]_i_142_n_5 ,\derivative_reg[19]_i_142_n_6 ,\NLW_derivative_reg[19]_i_142_O_UNCONNECTED [0]}),
        .S({\derivative[19]_i_163_n_0 ,\derivative[19]_i_164_n_0 ,\derivative[19]_i_165_n_0 ,1'b1}));
  CARRY4 \derivative_reg[19]_i_147 
       (.CI(1'b0),
        .CO({\derivative_reg[19]_i_147_n_0 ,\derivative_reg[19]_i_147_n_1 ,\derivative_reg[19]_i_147_n_2 ,\derivative_reg[19]_i_147_n_3 }),
        .CYINIT(derivative1[19]),
        .DI({\derivative_reg[19]_i_142_n_5 ,\derivative_reg[19]_i_142_n_6 ,derivative20_in[18],1'b0}),
        .O({\derivative_reg[19]_i_147_n_4 ,\derivative_reg[19]_i_147_n_5 ,\derivative_reg[19]_i_147_n_6 ,\NLW_derivative_reg[19]_i_147_O_UNCONNECTED [0]}),
        .S({\derivative[19]_i_167_n_0 ,\derivative[19]_i_168_n_0 ,\derivative[19]_i_169_n_0 ,1'b1}));
  CARRY4 \derivative_reg[19]_i_152 
       (.CI(1'b0),
        .CO({\derivative_reg[19]_i_152_n_0 ,\derivative_reg[19]_i_152_n_1 ,\derivative_reg[19]_i_152_n_2 ,\derivative_reg[19]_i_152_n_3 }),
        .CYINIT(derivative1[18]),
        .DI({\derivative_reg[19]_i_147_n_5 ,\derivative_reg[19]_i_147_n_6 ,derivative20_in[17],1'b0}),
        .O({\derivative_reg[19]_i_152_n_4 ,\derivative_reg[19]_i_152_n_5 ,\derivative_reg[19]_i_152_n_6 ,\NLW_derivative_reg[19]_i_152_O_UNCONNECTED [0]}),
        .S({\derivative[19]_i_171_n_0 ,\derivative[19]_i_172_n_0 ,\derivative[19]_i_173_n_0 ,1'b1}));
  CARRY4 \derivative_reg[19]_i_157 
       (.CI(1'b0),
        .CO({\derivative_reg[19]_i_157_n_0 ,\derivative_reg[19]_i_157_n_1 ,\derivative_reg[19]_i_157_n_2 ,\derivative_reg[19]_i_157_n_3 }),
        .CYINIT(derivative1[17]),
        .DI({\derivative_reg[19]_i_152_n_5 ,\derivative_reg[19]_i_152_n_6 ,derivative20_in[16],1'b0}),
        .O({\derivative_reg[19]_i_157_n_4 ,\derivative_reg[19]_i_157_n_5 ,\derivative_reg[19]_i_157_n_6 ,\NLW_derivative_reg[19]_i_157_O_UNCONNECTED [0]}),
        .S({\derivative[19]_i_175_n_0 ,\derivative[19]_i_176_n_0 ,\derivative[19]_i_177_n_0 ,1'b1}));
  CARRY4 \derivative_reg[19]_i_16 
       (.CI(\derivative_reg[19]_i_32_n_0 ),
        .CO({\derivative_reg[19]_i_16_n_0 ,\derivative_reg[19]_i_16_n_1 ,\derivative_reg[19]_i_16_n_2 ,\derivative_reg[19]_i_16_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_13_n_5 ,\derivative_reg[19]_i_13_n_6 ,\derivative_reg[19]_i_13_n_7 ,\derivative_reg[19]_i_27_n_4 }),
        .O({\derivative_reg[19]_i_16_n_4 ,\derivative_reg[19]_i_16_n_5 ,\derivative_reg[19]_i_16_n_6 ,\derivative_reg[19]_i_16_n_7 }),
        .S({\derivative[19]_i_33_n_0 ,\derivative[19]_i_34_n_0 ,\derivative[19]_i_35_n_0 ,\derivative[19]_i_36_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[19]_i_178 
       (.CI(\derivative_reg[15]_i_178_n_0 ),
        .CO({\derivative_reg[19]_i_178_n_0 ,\derivative_reg[19]_i_178_n_1 ,\derivative_reg[19]_i_178_n_2 ,\derivative_reg[19]_i_178_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[19]_i_178_n_4 ,\derivative_reg[19]_i_178_n_5 ,\derivative_reg[19]_i_178_n_6 ,\derivative_reg[19]_i_178_n_7 }),
        .S({\derivative[19]_i_179_n_0 ,\derivative[19]_i_180_n_0 ,\derivative[19]_i_181_n_0 ,\derivative[19]_i_182_n_0 }));
  CARRY4 \derivative_reg[19]_i_19 
       (.CI(\derivative_reg[19]_i_37_n_0 ),
        .CO({\derivative_reg[19]_i_19_n_0 ,\derivative_reg[19]_i_19_n_1 ,\derivative_reg[19]_i_19_n_2 ,\derivative_reg[19]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_16_n_5 ,\derivative_reg[19]_i_16_n_6 ,\derivative_reg[19]_i_16_n_7 ,\derivative_reg[19]_i_32_n_4 }),
        .O({\derivative_reg[19]_i_19_n_4 ,\derivative_reg[19]_i_19_n_5 ,\derivative_reg[19]_i_19_n_6 ,\derivative_reg[19]_i_19_n_7 }),
        .S({\derivative[19]_i_38_n_0 ,\derivative[19]_i_39_n_0 ,\derivative[19]_i_40_n_0 ,\derivative[19]_i_41_n_0 }));
  CARRY4 \derivative_reg[19]_i_22 
       (.CI(\derivative_reg[19]_i_42_n_0 ),
        .CO({\derivative_reg[19]_i_22_n_0 ,\derivative_reg[19]_i_22_n_1 ,\derivative_reg[19]_i_22_n_2 ,\derivative_reg[19]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_37_n_5 ,\derivative_reg[23]_i_37_n_6 ,\derivative_reg[23]_i_37_n_7 ,\derivative_reg[23]_i_57_n_4 }),
        .O({\derivative_reg[19]_i_22_n_4 ,\derivative_reg[19]_i_22_n_5 ,\derivative_reg[19]_i_22_n_6 ,\derivative_reg[19]_i_22_n_7 }),
        .S({\derivative[19]_i_43_n_0 ,\derivative[19]_i_44_n_0 ,\derivative[19]_i_45_n_0 ,\derivative[19]_i_46_n_0 }));
  CARRY4 \derivative_reg[19]_i_27 
       (.CI(\derivative_reg[19]_i_47_n_0 ),
        .CO({\derivative_reg[19]_i_27_n_0 ,\derivative_reg[19]_i_27_n_1 ,\derivative_reg[19]_i_27_n_2 ,\derivative_reg[19]_i_27_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_22_n_5 ,\derivative_reg[19]_i_22_n_6 ,\derivative_reg[19]_i_22_n_7 ,\derivative_reg[19]_i_42_n_4 }),
        .O({\derivative_reg[19]_i_27_n_4 ,\derivative_reg[19]_i_27_n_5 ,\derivative_reg[19]_i_27_n_6 ,\derivative_reg[19]_i_27_n_7 }),
        .S({\derivative[19]_i_48_n_0 ,\derivative[19]_i_49_n_0 ,\derivative[19]_i_50_n_0 ,\derivative[19]_i_51_n_0 }));
  CARRY4 \derivative_reg[19]_i_32 
       (.CI(\derivative_reg[19]_i_52_n_0 ),
        .CO({\derivative_reg[19]_i_32_n_0 ,\derivative_reg[19]_i_32_n_1 ,\derivative_reg[19]_i_32_n_2 ,\derivative_reg[19]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_27_n_5 ,\derivative_reg[19]_i_27_n_6 ,\derivative_reg[19]_i_27_n_7 ,\derivative_reg[19]_i_47_n_4 }),
        .O({\derivative_reg[19]_i_32_n_4 ,\derivative_reg[19]_i_32_n_5 ,\derivative_reg[19]_i_32_n_6 ,\derivative_reg[19]_i_32_n_7 }),
        .S({\derivative[19]_i_53_n_0 ,\derivative[19]_i_54_n_0 ,\derivative[19]_i_55_n_0 ,\derivative[19]_i_56_n_0 }));
  CARRY4 \derivative_reg[19]_i_37 
       (.CI(\derivative_reg[19]_i_57_n_0 ),
        .CO({\derivative_reg[19]_i_37_n_0 ,\derivative_reg[19]_i_37_n_1 ,\derivative_reg[19]_i_37_n_2 ,\derivative_reg[19]_i_37_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_32_n_5 ,\derivative_reg[19]_i_32_n_6 ,\derivative_reg[19]_i_32_n_7 ,\derivative_reg[19]_i_52_n_4 }),
        .O({\derivative_reg[19]_i_37_n_4 ,\derivative_reg[19]_i_37_n_5 ,\derivative_reg[19]_i_37_n_6 ,\derivative_reg[19]_i_37_n_7 }),
        .S({\derivative[19]_i_58_n_0 ,\derivative[19]_i_59_n_0 ,\derivative[19]_i_60_n_0 ,\derivative[19]_i_61_n_0 }));
  CARRY4 \derivative_reg[19]_i_42 
       (.CI(\derivative_reg[19]_i_62_n_0 ),
        .CO({\derivative_reg[19]_i_42_n_0 ,\derivative_reg[19]_i_42_n_1 ,\derivative_reg[19]_i_42_n_2 ,\derivative_reg[19]_i_42_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_57_n_5 ,\derivative_reg[23]_i_57_n_6 ,\derivative_reg[23]_i_57_n_7 ,\derivative_reg[23]_i_77_n_4 }),
        .O({\derivative_reg[19]_i_42_n_4 ,\derivative_reg[19]_i_42_n_5 ,\derivative_reg[19]_i_42_n_6 ,\derivative_reg[19]_i_42_n_7 }),
        .S({\derivative[19]_i_63_n_0 ,\derivative[19]_i_64_n_0 ,\derivative[19]_i_65_n_0 ,\derivative[19]_i_66_n_0 }));
  CARRY4 \derivative_reg[19]_i_47 
       (.CI(\derivative_reg[19]_i_67_n_0 ),
        .CO({\derivative_reg[19]_i_47_n_0 ,\derivative_reg[19]_i_47_n_1 ,\derivative_reg[19]_i_47_n_2 ,\derivative_reg[19]_i_47_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_42_n_5 ,\derivative_reg[19]_i_42_n_6 ,\derivative_reg[19]_i_42_n_7 ,\derivative_reg[19]_i_62_n_4 }),
        .O({\derivative_reg[19]_i_47_n_4 ,\derivative_reg[19]_i_47_n_5 ,\derivative_reg[19]_i_47_n_6 ,\derivative_reg[19]_i_47_n_7 }),
        .S({\derivative[19]_i_68_n_0 ,\derivative[19]_i_69_n_0 ,\derivative[19]_i_70_n_0 ,\derivative[19]_i_71_n_0 }));
  CARRY4 \derivative_reg[19]_i_52 
       (.CI(\derivative_reg[19]_i_72_n_0 ),
        .CO({\derivative_reg[19]_i_52_n_0 ,\derivative_reg[19]_i_52_n_1 ,\derivative_reg[19]_i_52_n_2 ,\derivative_reg[19]_i_52_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_47_n_5 ,\derivative_reg[19]_i_47_n_6 ,\derivative_reg[19]_i_47_n_7 ,\derivative_reg[19]_i_67_n_4 }),
        .O({\derivative_reg[19]_i_52_n_4 ,\derivative_reg[19]_i_52_n_5 ,\derivative_reg[19]_i_52_n_6 ,\derivative_reg[19]_i_52_n_7 }),
        .S({\derivative[19]_i_73_n_0 ,\derivative[19]_i_74_n_0 ,\derivative[19]_i_75_n_0 ,\derivative[19]_i_76_n_0 }));
  CARRY4 \derivative_reg[19]_i_57 
       (.CI(\derivative_reg[19]_i_77_n_0 ),
        .CO({\derivative_reg[19]_i_57_n_0 ,\derivative_reg[19]_i_57_n_1 ,\derivative_reg[19]_i_57_n_2 ,\derivative_reg[19]_i_57_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_52_n_5 ,\derivative_reg[19]_i_52_n_6 ,\derivative_reg[19]_i_52_n_7 ,\derivative_reg[19]_i_72_n_4 }),
        .O({\derivative_reg[19]_i_57_n_4 ,\derivative_reg[19]_i_57_n_5 ,\derivative_reg[19]_i_57_n_6 ,\derivative_reg[19]_i_57_n_7 }),
        .S({\derivative[19]_i_78_n_0 ,\derivative[19]_i_79_n_0 ,\derivative[19]_i_80_n_0 ,\derivative[19]_i_81_n_0 }));
  CARRY4 \derivative_reg[19]_i_6 
       (.CI(\derivative_reg[19]_i_10_n_0 ),
        .CO({\NLW_derivative_reg[19]_i_6_CO_UNCONNECTED [3:2],derivative1[19],\derivative_reg[19]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[20],\derivative_reg[23]_i_19_n_4 }),
        .O({\NLW_derivative_reg[19]_i_6_O_UNCONNECTED [3:1],\derivative_reg[19]_i_6_n_7 }),
        .S({1'b0,1'b0,\derivative[19]_i_11_n_0 ,\derivative[19]_i_12_n_0 }));
  CARRY4 \derivative_reg[19]_i_62 
       (.CI(\derivative_reg[19]_i_82_n_0 ),
        .CO({\derivative_reg[19]_i_62_n_0 ,\derivative_reg[19]_i_62_n_1 ,\derivative_reg[19]_i_62_n_2 ,\derivative_reg[19]_i_62_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_77_n_5 ,\derivative_reg[23]_i_77_n_6 ,\derivative_reg[23]_i_77_n_7 ,\derivative_reg[23]_i_97_n_4 }),
        .O({\derivative_reg[19]_i_62_n_4 ,\derivative_reg[19]_i_62_n_5 ,\derivative_reg[19]_i_62_n_6 ,\derivative_reg[19]_i_62_n_7 }),
        .S({\derivative[19]_i_83_n_0 ,\derivative[19]_i_84_n_0 ,\derivative[19]_i_85_n_0 ,\derivative[19]_i_86_n_0 }));
  CARRY4 \derivative_reg[19]_i_67 
       (.CI(\derivative_reg[19]_i_87_n_0 ),
        .CO({\derivative_reg[19]_i_67_n_0 ,\derivative_reg[19]_i_67_n_1 ,\derivative_reg[19]_i_67_n_2 ,\derivative_reg[19]_i_67_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_62_n_5 ,\derivative_reg[19]_i_62_n_6 ,\derivative_reg[19]_i_62_n_7 ,\derivative_reg[19]_i_82_n_4 }),
        .O({\derivative_reg[19]_i_67_n_4 ,\derivative_reg[19]_i_67_n_5 ,\derivative_reg[19]_i_67_n_6 ,\derivative_reg[19]_i_67_n_7 }),
        .S({\derivative[19]_i_88_n_0 ,\derivative[19]_i_89_n_0 ,\derivative[19]_i_90_n_0 ,\derivative[19]_i_91_n_0 }));
  CARRY4 \derivative_reg[19]_i_7 
       (.CI(\derivative_reg[19]_i_13_n_0 ),
        .CO({\NLW_derivative_reg[19]_i_7_CO_UNCONNECTED [3:2],derivative1[18],\derivative_reg[19]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[19],\derivative_reg[19]_i_10_n_4 }),
        .O({\NLW_derivative_reg[19]_i_7_O_UNCONNECTED [3:1],\derivative_reg[19]_i_7_n_7 }),
        .S({1'b0,1'b0,\derivative[19]_i_14_n_0 ,\derivative[19]_i_15_n_0 }));
  CARRY4 \derivative_reg[19]_i_72 
       (.CI(\derivative_reg[19]_i_92_n_0 ),
        .CO({\derivative_reg[19]_i_72_n_0 ,\derivative_reg[19]_i_72_n_1 ,\derivative_reg[19]_i_72_n_2 ,\derivative_reg[19]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_67_n_5 ,\derivative_reg[19]_i_67_n_6 ,\derivative_reg[19]_i_67_n_7 ,\derivative_reg[19]_i_87_n_4 }),
        .O({\derivative_reg[19]_i_72_n_4 ,\derivative_reg[19]_i_72_n_5 ,\derivative_reg[19]_i_72_n_6 ,\derivative_reg[19]_i_72_n_7 }),
        .S({\derivative[19]_i_93_n_0 ,\derivative[19]_i_94_n_0 ,\derivative[19]_i_95_n_0 ,\derivative[19]_i_96_n_0 }));
  CARRY4 \derivative_reg[19]_i_77 
       (.CI(\derivative_reg[19]_i_97_n_0 ),
        .CO({\derivative_reg[19]_i_77_n_0 ,\derivative_reg[19]_i_77_n_1 ,\derivative_reg[19]_i_77_n_2 ,\derivative_reg[19]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_72_n_5 ,\derivative_reg[19]_i_72_n_6 ,\derivative_reg[19]_i_72_n_7 ,\derivative_reg[19]_i_92_n_4 }),
        .O({\derivative_reg[19]_i_77_n_4 ,\derivative_reg[19]_i_77_n_5 ,\derivative_reg[19]_i_77_n_6 ,\derivative_reg[19]_i_77_n_7 }),
        .S({\derivative[19]_i_98_n_0 ,\derivative[19]_i_99_n_0 ,\derivative[19]_i_100_n_0 ,\derivative[19]_i_101_n_0 }));
  CARRY4 \derivative_reg[19]_i_8 
       (.CI(\derivative_reg[19]_i_16_n_0 ),
        .CO({\NLW_derivative_reg[19]_i_8_CO_UNCONNECTED [3:2],derivative1[17],\derivative_reg[19]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[18],\derivative_reg[19]_i_13_n_4 }),
        .O({\NLW_derivative_reg[19]_i_8_O_UNCONNECTED [3:1],\derivative_reg[19]_i_8_n_7 }),
        .S({1'b0,1'b0,\derivative[19]_i_17_n_0 ,\derivative[19]_i_18_n_0 }));
  CARRY4 \derivative_reg[19]_i_82 
       (.CI(\derivative_reg[19]_i_102_n_0 ),
        .CO({\derivative_reg[19]_i_82_n_0 ,\derivative_reg[19]_i_82_n_1 ,\derivative_reg[19]_i_82_n_2 ,\derivative_reg[19]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_97_n_5 ,\derivative_reg[23]_i_97_n_6 ,\derivative_reg[23]_i_97_n_7 ,\derivative_reg[23]_i_117_n_4 }),
        .O({\derivative_reg[19]_i_82_n_4 ,\derivative_reg[19]_i_82_n_5 ,\derivative_reg[19]_i_82_n_6 ,\derivative_reg[19]_i_82_n_7 }),
        .S({\derivative[19]_i_103_n_0 ,\derivative[19]_i_104_n_0 ,\derivative[19]_i_105_n_0 ,\derivative[19]_i_106_n_0 }));
  CARRY4 \derivative_reg[19]_i_87 
       (.CI(\derivative_reg[19]_i_107_n_0 ),
        .CO({\derivative_reg[19]_i_87_n_0 ,\derivative_reg[19]_i_87_n_1 ,\derivative_reg[19]_i_87_n_2 ,\derivative_reg[19]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_82_n_5 ,\derivative_reg[19]_i_82_n_6 ,\derivative_reg[19]_i_82_n_7 ,\derivative_reg[19]_i_102_n_4 }),
        .O({\derivative_reg[19]_i_87_n_4 ,\derivative_reg[19]_i_87_n_5 ,\derivative_reg[19]_i_87_n_6 ,\derivative_reg[19]_i_87_n_7 }),
        .S({\derivative[19]_i_108_n_0 ,\derivative[19]_i_109_n_0 ,\derivative[19]_i_110_n_0 ,\derivative[19]_i_111_n_0 }));
  CARRY4 \derivative_reg[19]_i_9 
       (.CI(\derivative_reg[19]_i_19_n_0 ),
        .CO({\NLW_derivative_reg[19]_i_9_CO_UNCONNECTED [3:2],derivative1[16],\derivative_reg[19]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[17],\derivative_reg[19]_i_16_n_4 }),
        .O({\NLW_derivative_reg[19]_i_9_O_UNCONNECTED [3:1],\derivative_reg[19]_i_9_n_7 }),
        .S({1'b0,1'b0,\derivative[19]_i_20_n_0 ,\derivative[19]_i_21_n_0 }));
  CARRY4 \derivative_reg[19]_i_92 
       (.CI(\derivative_reg[19]_i_112_n_0 ),
        .CO({\derivative_reg[19]_i_92_n_0 ,\derivative_reg[19]_i_92_n_1 ,\derivative_reg[19]_i_92_n_2 ,\derivative_reg[19]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_87_n_5 ,\derivative_reg[19]_i_87_n_6 ,\derivative_reg[19]_i_87_n_7 ,\derivative_reg[19]_i_107_n_4 }),
        .O({\derivative_reg[19]_i_92_n_4 ,\derivative_reg[19]_i_92_n_5 ,\derivative_reg[19]_i_92_n_6 ,\derivative_reg[19]_i_92_n_7 }),
        .S({\derivative[19]_i_113_n_0 ,\derivative[19]_i_114_n_0 ,\derivative[19]_i_115_n_0 ,\derivative[19]_i_116_n_0 }));
  CARRY4 \derivative_reg[19]_i_97 
       (.CI(\derivative_reg[19]_i_117_n_0 ),
        .CO({\derivative_reg[19]_i_97_n_0 ,\derivative_reg[19]_i_97_n_1 ,\derivative_reg[19]_i_97_n_2 ,\derivative_reg[19]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[19]_i_92_n_5 ,\derivative_reg[19]_i_92_n_6 ,\derivative_reg[19]_i_92_n_7 ,\derivative_reg[19]_i_112_n_4 }),
        .O({\derivative_reg[19]_i_97_n_4 ,\derivative_reg[19]_i_97_n_5 ,\derivative_reg[19]_i_97_n_6 ,\derivative_reg[19]_i_97_n_7 }),
        .S({\derivative[19]_i_118_n_0 ,\derivative[19]_i_119_n_0 ,\derivative[19]_i_120_n_0 ,\derivative[19]_i_121_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[1] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[3]_i_1_n_6 ),
        .Q(derivative_out[1]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[20] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[23]_i_1_n_7 ),
        .Q(derivative_out[20]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[21] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[23]_i_1_n_6 ),
        .Q(derivative_out[21]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[22] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[23]_i_1_n_5 ),
        .Q(derivative_out[22]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[23] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[23]_i_1_n_4 ),
        .Q(derivative_out[23]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[23]_i_1 
       (.CI(\derivative_reg[19]_i_1_n_0 ),
        .CO({\derivative_reg[23]_i_1_n_0 ,\derivative_reg[23]_i_1_n_1 ,\derivative_reg[23]_i_1_n_2 ,\derivative_reg[23]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[23]_i_1_n_4 ,\derivative_reg[23]_i_1_n_5 ,\derivative_reg[23]_i_1_n_6 ,\derivative_reg[23]_i_1_n_7 }),
        .S({\derivative[23]_i_2_n_0 ,\derivative[23]_i_3_n_0 ,\derivative[23]_i_4_n_0 ,\derivative[23]_i_5_n_0 }));
  CARRY4 \derivative_reg[23]_i_10 
       (.CI(\derivative_reg[23]_i_22_n_0 ),
        .CO({\derivative_reg[23]_i_10_n_0 ,\derivative_reg[23]_i_10_n_1 ,\derivative_reg[23]_i_10_n_2 ,\derivative_reg[23]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_19_n_5 ,\derivative_reg[27]_i_19_n_6 ,\derivative_reg[27]_i_19_n_7 ,\derivative_reg[27]_i_37_n_4 }),
        .O({\derivative_reg[23]_i_10_n_4 ,\derivative_reg[23]_i_10_n_5 ,\derivative_reg[23]_i_10_n_6 ,\derivative_reg[23]_i_10_n_7 }),
        .S({\derivative[23]_i_23_n_0 ,\derivative[23]_i_24_n_0 ,\derivative[23]_i_25_n_0 ,\derivative[23]_i_26_n_0 }));
  CARRY4 \derivative_reg[23]_i_102 
       (.CI(\derivative_reg[23]_i_122_n_0 ),
        .CO({\derivative_reg[23]_i_102_n_0 ,\derivative_reg[23]_i_102_n_1 ,\derivative_reg[23]_i_102_n_2 ,\derivative_reg[23]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_117_n_5 ,\derivative_reg[27]_i_117_n_6 ,\derivative_reg[27]_i_117_n_7 ,\derivative_reg[27]_i_137_n_4 }),
        .O({\derivative_reg[23]_i_102_n_4 ,\derivative_reg[23]_i_102_n_5 ,\derivative_reg[23]_i_102_n_6 ,\derivative_reg[23]_i_102_n_7 }),
        .S({\derivative[23]_i_123_n_0 ,\derivative[23]_i_124_n_0 ,\derivative[23]_i_125_n_0 ,\derivative[23]_i_126_n_0 }));
  CARRY4 \derivative_reg[23]_i_107 
       (.CI(\derivative_reg[23]_i_127_n_0 ),
        .CO({\derivative_reg[23]_i_107_n_0 ,\derivative_reg[23]_i_107_n_1 ,\derivative_reg[23]_i_107_n_2 ,\derivative_reg[23]_i_107_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_102_n_5 ,\derivative_reg[23]_i_102_n_6 ,\derivative_reg[23]_i_102_n_7 ,\derivative_reg[23]_i_122_n_4 }),
        .O({\derivative_reg[23]_i_107_n_4 ,\derivative_reg[23]_i_107_n_5 ,\derivative_reg[23]_i_107_n_6 ,\derivative_reg[23]_i_107_n_7 }),
        .S({\derivative[23]_i_128_n_0 ,\derivative[23]_i_129_n_0 ,\derivative[23]_i_130_n_0 ,\derivative[23]_i_131_n_0 }));
  CARRY4 \derivative_reg[23]_i_112 
       (.CI(\derivative_reg[23]_i_132_n_0 ),
        .CO({\derivative_reg[23]_i_112_n_0 ,\derivative_reg[23]_i_112_n_1 ,\derivative_reg[23]_i_112_n_2 ,\derivative_reg[23]_i_112_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_107_n_5 ,\derivative_reg[23]_i_107_n_6 ,\derivative_reg[23]_i_107_n_7 ,\derivative_reg[23]_i_127_n_4 }),
        .O({\derivative_reg[23]_i_112_n_4 ,\derivative_reg[23]_i_112_n_5 ,\derivative_reg[23]_i_112_n_6 ,\derivative_reg[23]_i_112_n_7 }),
        .S({\derivative[23]_i_133_n_0 ,\derivative[23]_i_134_n_0 ,\derivative[23]_i_135_n_0 ,\derivative[23]_i_136_n_0 }));
  CARRY4 \derivative_reg[23]_i_117 
       (.CI(\derivative_reg[23]_i_137_n_0 ),
        .CO({\derivative_reg[23]_i_117_n_0 ,\derivative_reg[23]_i_117_n_1 ,\derivative_reg[23]_i_117_n_2 ,\derivative_reg[23]_i_117_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_112_n_5 ,\derivative_reg[23]_i_112_n_6 ,\derivative_reg[23]_i_112_n_7 ,\derivative_reg[23]_i_132_n_4 }),
        .O({\derivative_reg[23]_i_117_n_4 ,\derivative_reg[23]_i_117_n_5 ,\derivative_reg[23]_i_117_n_6 ,\derivative_reg[23]_i_117_n_7 }),
        .S({\derivative[23]_i_138_n_0 ,\derivative[23]_i_139_n_0 ,\derivative[23]_i_140_n_0 ,\derivative[23]_i_141_n_0 }));
  CARRY4 \derivative_reg[23]_i_122 
       (.CI(\derivative_reg[23]_i_142_n_0 ),
        .CO({\derivative_reg[23]_i_122_n_0 ,\derivative_reg[23]_i_122_n_1 ,\derivative_reg[23]_i_122_n_2 ,\derivative_reg[23]_i_122_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_137_n_5 ,\derivative_reg[27]_i_137_n_6 ,\derivative_reg[27]_i_137_n_7 ,\derivative_reg[27]_i_157_n_4 }),
        .O({\derivative_reg[23]_i_122_n_4 ,\derivative_reg[23]_i_122_n_5 ,\derivative_reg[23]_i_122_n_6 ,\derivative_reg[23]_i_122_n_7 }),
        .S({\derivative[23]_i_143_n_0 ,\derivative[23]_i_144_n_0 ,\derivative[23]_i_145_n_0 ,\derivative[23]_i_146_n_0 }));
  CARRY4 \derivative_reg[23]_i_127 
       (.CI(\derivative_reg[23]_i_147_n_0 ),
        .CO({\derivative_reg[23]_i_127_n_0 ,\derivative_reg[23]_i_127_n_1 ,\derivative_reg[23]_i_127_n_2 ,\derivative_reg[23]_i_127_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_122_n_5 ,\derivative_reg[23]_i_122_n_6 ,\derivative_reg[23]_i_122_n_7 ,\derivative_reg[23]_i_142_n_4 }),
        .O({\derivative_reg[23]_i_127_n_4 ,\derivative_reg[23]_i_127_n_5 ,\derivative_reg[23]_i_127_n_6 ,\derivative_reg[23]_i_127_n_7 }),
        .S({\derivative[23]_i_148_n_0 ,\derivative[23]_i_149_n_0 ,\derivative[23]_i_150_n_0 ,\derivative[23]_i_151_n_0 }));
  CARRY4 \derivative_reg[23]_i_13 
       (.CI(\derivative_reg[23]_i_27_n_0 ),
        .CO({\derivative_reg[23]_i_13_n_0 ,\derivative_reg[23]_i_13_n_1 ,\derivative_reg[23]_i_13_n_2 ,\derivative_reg[23]_i_13_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_10_n_5 ,\derivative_reg[23]_i_10_n_6 ,\derivative_reg[23]_i_10_n_7 ,\derivative_reg[23]_i_22_n_4 }),
        .O({\derivative_reg[23]_i_13_n_4 ,\derivative_reg[23]_i_13_n_5 ,\derivative_reg[23]_i_13_n_6 ,\derivative_reg[23]_i_13_n_7 }),
        .S({\derivative[23]_i_28_n_0 ,\derivative[23]_i_29_n_0 ,\derivative[23]_i_30_n_0 ,\derivative[23]_i_31_n_0 }));
  CARRY4 \derivative_reg[23]_i_132 
       (.CI(\derivative_reg[23]_i_152_n_0 ),
        .CO({\derivative_reg[23]_i_132_n_0 ,\derivative_reg[23]_i_132_n_1 ,\derivative_reg[23]_i_132_n_2 ,\derivative_reg[23]_i_132_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_127_n_5 ,\derivative_reg[23]_i_127_n_6 ,\derivative_reg[23]_i_127_n_7 ,\derivative_reg[23]_i_147_n_4 }),
        .O({\derivative_reg[23]_i_132_n_4 ,\derivative_reg[23]_i_132_n_5 ,\derivative_reg[23]_i_132_n_6 ,\derivative_reg[23]_i_132_n_7 }),
        .S({\derivative[23]_i_153_n_0 ,\derivative[23]_i_154_n_0 ,\derivative[23]_i_155_n_0 ,\derivative[23]_i_156_n_0 }));
  CARRY4 \derivative_reg[23]_i_137 
       (.CI(\derivative_reg[23]_i_157_n_0 ),
        .CO({\derivative_reg[23]_i_137_n_0 ,\derivative_reg[23]_i_137_n_1 ,\derivative_reg[23]_i_137_n_2 ,\derivative_reg[23]_i_137_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_132_n_5 ,\derivative_reg[23]_i_132_n_6 ,\derivative_reg[23]_i_132_n_7 ,\derivative_reg[23]_i_152_n_4 }),
        .O({\derivative_reg[23]_i_137_n_4 ,\derivative_reg[23]_i_137_n_5 ,\derivative_reg[23]_i_137_n_6 ,\derivative_reg[23]_i_137_n_7 }),
        .S({\derivative[23]_i_158_n_0 ,\derivative[23]_i_159_n_0 ,\derivative[23]_i_160_n_0 ,\derivative[23]_i_161_n_0 }));
  CARRY4 \derivative_reg[23]_i_142 
       (.CI(1'b0),
        .CO({\derivative_reg[23]_i_142_n_0 ,\derivative_reg[23]_i_142_n_1 ,\derivative_reg[23]_i_142_n_2 ,\derivative_reg[23]_i_142_n_3 }),
        .CYINIT(derivative1[24]),
        .DI({\derivative_reg[27]_i_157_n_5 ,\derivative_reg[27]_i_157_n_6 ,derivative20_in[23],1'b0}),
        .O({\derivative_reg[23]_i_142_n_4 ,\derivative_reg[23]_i_142_n_5 ,\derivative_reg[23]_i_142_n_6 ,\NLW_derivative_reg[23]_i_142_O_UNCONNECTED [0]}),
        .S({\derivative[23]_i_163_n_0 ,\derivative[23]_i_164_n_0 ,\derivative[23]_i_165_n_0 ,1'b1}));
  CARRY4 \derivative_reg[23]_i_147 
       (.CI(1'b0),
        .CO({\derivative_reg[23]_i_147_n_0 ,\derivative_reg[23]_i_147_n_1 ,\derivative_reg[23]_i_147_n_2 ,\derivative_reg[23]_i_147_n_3 }),
        .CYINIT(derivative1[23]),
        .DI({\derivative_reg[23]_i_142_n_5 ,\derivative_reg[23]_i_142_n_6 ,derivative20_in[22],1'b0}),
        .O({\derivative_reg[23]_i_147_n_4 ,\derivative_reg[23]_i_147_n_5 ,\derivative_reg[23]_i_147_n_6 ,\NLW_derivative_reg[23]_i_147_O_UNCONNECTED [0]}),
        .S({\derivative[23]_i_167_n_0 ,\derivative[23]_i_168_n_0 ,\derivative[23]_i_169_n_0 ,1'b1}));
  CARRY4 \derivative_reg[23]_i_152 
       (.CI(1'b0),
        .CO({\derivative_reg[23]_i_152_n_0 ,\derivative_reg[23]_i_152_n_1 ,\derivative_reg[23]_i_152_n_2 ,\derivative_reg[23]_i_152_n_3 }),
        .CYINIT(derivative1[22]),
        .DI({\derivative_reg[23]_i_147_n_5 ,\derivative_reg[23]_i_147_n_6 ,derivative20_in[21],1'b0}),
        .O({\derivative_reg[23]_i_152_n_4 ,\derivative_reg[23]_i_152_n_5 ,\derivative_reg[23]_i_152_n_6 ,\NLW_derivative_reg[23]_i_152_O_UNCONNECTED [0]}),
        .S({\derivative[23]_i_171_n_0 ,\derivative[23]_i_172_n_0 ,\derivative[23]_i_173_n_0 ,1'b1}));
  CARRY4 \derivative_reg[23]_i_157 
       (.CI(1'b0),
        .CO({\derivative_reg[23]_i_157_n_0 ,\derivative_reg[23]_i_157_n_1 ,\derivative_reg[23]_i_157_n_2 ,\derivative_reg[23]_i_157_n_3 }),
        .CYINIT(derivative1[21]),
        .DI({\derivative_reg[23]_i_152_n_5 ,\derivative_reg[23]_i_152_n_6 ,derivative20_in[20],1'b0}),
        .O({\derivative_reg[23]_i_157_n_4 ,\derivative_reg[23]_i_157_n_5 ,\derivative_reg[23]_i_157_n_6 ,\NLW_derivative_reg[23]_i_157_O_UNCONNECTED [0]}),
        .S({\derivative[23]_i_175_n_0 ,\derivative[23]_i_176_n_0 ,\derivative[23]_i_177_n_0 ,1'b1}));
  CARRY4 \derivative_reg[23]_i_16 
       (.CI(\derivative_reg[23]_i_32_n_0 ),
        .CO({\derivative_reg[23]_i_16_n_0 ,\derivative_reg[23]_i_16_n_1 ,\derivative_reg[23]_i_16_n_2 ,\derivative_reg[23]_i_16_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_13_n_5 ,\derivative_reg[23]_i_13_n_6 ,\derivative_reg[23]_i_13_n_7 ,\derivative_reg[23]_i_27_n_4 }),
        .O({\derivative_reg[23]_i_16_n_4 ,\derivative_reg[23]_i_16_n_5 ,\derivative_reg[23]_i_16_n_6 ,\derivative_reg[23]_i_16_n_7 }),
        .S({\derivative[23]_i_33_n_0 ,\derivative[23]_i_34_n_0 ,\derivative[23]_i_35_n_0 ,\derivative[23]_i_36_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[23]_i_178 
       (.CI(\derivative_reg[19]_i_178_n_0 ),
        .CO({\derivative_reg[23]_i_178_n_0 ,\derivative_reg[23]_i_178_n_1 ,\derivative_reg[23]_i_178_n_2 ,\derivative_reg[23]_i_178_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[23]_i_178_n_4 ,\derivative_reg[23]_i_178_n_5 ,\derivative_reg[23]_i_178_n_6 ,\derivative_reg[23]_i_178_n_7 }),
        .S({\derivative[23]_i_179_n_0 ,\derivative[23]_i_180_n_0 ,\derivative[23]_i_181_n_0 ,\derivative[23]_i_182_n_0 }));
  CARRY4 \derivative_reg[23]_i_19 
       (.CI(\derivative_reg[23]_i_37_n_0 ),
        .CO({\derivative_reg[23]_i_19_n_0 ,\derivative_reg[23]_i_19_n_1 ,\derivative_reg[23]_i_19_n_2 ,\derivative_reg[23]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_16_n_5 ,\derivative_reg[23]_i_16_n_6 ,\derivative_reg[23]_i_16_n_7 ,\derivative_reg[23]_i_32_n_4 }),
        .O({\derivative_reg[23]_i_19_n_4 ,\derivative_reg[23]_i_19_n_5 ,\derivative_reg[23]_i_19_n_6 ,\derivative_reg[23]_i_19_n_7 }),
        .S({\derivative[23]_i_38_n_0 ,\derivative[23]_i_39_n_0 ,\derivative[23]_i_40_n_0 ,\derivative[23]_i_41_n_0 }));
  CARRY4 \derivative_reg[23]_i_22 
       (.CI(\derivative_reg[23]_i_42_n_0 ),
        .CO({\derivative_reg[23]_i_22_n_0 ,\derivative_reg[23]_i_22_n_1 ,\derivative_reg[23]_i_22_n_2 ,\derivative_reg[23]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_37_n_5 ,\derivative_reg[27]_i_37_n_6 ,\derivative_reg[27]_i_37_n_7 ,\derivative_reg[27]_i_57_n_4 }),
        .O({\derivative_reg[23]_i_22_n_4 ,\derivative_reg[23]_i_22_n_5 ,\derivative_reg[23]_i_22_n_6 ,\derivative_reg[23]_i_22_n_7 }),
        .S({\derivative[23]_i_43_n_0 ,\derivative[23]_i_44_n_0 ,\derivative[23]_i_45_n_0 ,\derivative[23]_i_46_n_0 }));
  CARRY4 \derivative_reg[23]_i_27 
       (.CI(\derivative_reg[23]_i_47_n_0 ),
        .CO({\derivative_reg[23]_i_27_n_0 ,\derivative_reg[23]_i_27_n_1 ,\derivative_reg[23]_i_27_n_2 ,\derivative_reg[23]_i_27_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_22_n_5 ,\derivative_reg[23]_i_22_n_6 ,\derivative_reg[23]_i_22_n_7 ,\derivative_reg[23]_i_42_n_4 }),
        .O({\derivative_reg[23]_i_27_n_4 ,\derivative_reg[23]_i_27_n_5 ,\derivative_reg[23]_i_27_n_6 ,\derivative_reg[23]_i_27_n_7 }),
        .S({\derivative[23]_i_48_n_0 ,\derivative[23]_i_49_n_0 ,\derivative[23]_i_50_n_0 ,\derivative[23]_i_51_n_0 }));
  CARRY4 \derivative_reg[23]_i_32 
       (.CI(\derivative_reg[23]_i_52_n_0 ),
        .CO({\derivative_reg[23]_i_32_n_0 ,\derivative_reg[23]_i_32_n_1 ,\derivative_reg[23]_i_32_n_2 ,\derivative_reg[23]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_27_n_5 ,\derivative_reg[23]_i_27_n_6 ,\derivative_reg[23]_i_27_n_7 ,\derivative_reg[23]_i_47_n_4 }),
        .O({\derivative_reg[23]_i_32_n_4 ,\derivative_reg[23]_i_32_n_5 ,\derivative_reg[23]_i_32_n_6 ,\derivative_reg[23]_i_32_n_7 }),
        .S({\derivative[23]_i_53_n_0 ,\derivative[23]_i_54_n_0 ,\derivative[23]_i_55_n_0 ,\derivative[23]_i_56_n_0 }));
  CARRY4 \derivative_reg[23]_i_37 
       (.CI(\derivative_reg[23]_i_57_n_0 ),
        .CO({\derivative_reg[23]_i_37_n_0 ,\derivative_reg[23]_i_37_n_1 ,\derivative_reg[23]_i_37_n_2 ,\derivative_reg[23]_i_37_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_32_n_5 ,\derivative_reg[23]_i_32_n_6 ,\derivative_reg[23]_i_32_n_7 ,\derivative_reg[23]_i_52_n_4 }),
        .O({\derivative_reg[23]_i_37_n_4 ,\derivative_reg[23]_i_37_n_5 ,\derivative_reg[23]_i_37_n_6 ,\derivative_reg[23]_i_37_n_7 }),
        .S({\derivative[23]_i_58_n_0 ,\derivative[23]_i_59_n_0 ,\derivative[23]_i_60_n_0 ,\derivative[23]_i_61_n_0 }));
  CARRY4 \derivative_reg[23]_i_42 
       (.CI(\derivative_reg[23]_i_62_n_0 ),
        .CO({\derivative_reg[23]_i_42_n_0 ,\derivative_reg[23]_i_42_n_1 ,\derivative_reg[23]_i_42_n_2 ,\derivative_reg[23]_i_42_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_57_n_5 ,\derivative_reg[27]_i_57_n_6 ,\derivative_reg[27]_i_57_n_7 ,\derivative_reg[27]_i_77_n_4 }),
        .O({\derivative_reg[23]_i_42_n_4 ,\derivative_reg[23]_i_42_n_5 ,\derivative_reg[23]_i_42_n_6 ,\derivative_reg[23]_i_42_n_7 }),
        .S({\derivative[23]_i_63_n_0 ,\derivative[23]_i_64_n_0 ,\derivative[23]_i_65_n_0 ,\derivative[23]_i_66_n_0 }));
  CARRY4 \derivative_reg[23]_i_47 
       (.CI(\derivative_reg[23]_i_67_n_0 ),
        .CO({\derivative_reg[23]_i_47_n_0 ,\derivative_reg[23]_i_47_n_1 ,\derivative_reg[23]_i_47_n_2 ,\derivative_reg[23]_i_47_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_42_n_5 ,\derivative_reg[23]_i_42_n_6 ,\derivative_reg[23]_i_42_n_7 ,\derivative_reg[23]_i_62_n_4 }),
        .O({\derivative_reg[23]_i_47_n_4 ,\derivative_reg[23]_i_47_n_5 ,\derivative_reg[23]_i_47_n_6 ,\derivative_reg[23]_i_47_n_7 }),
        .S({\derivative[23]_i_68_n_0 ,\derivative[23]_i_69_n_0 ,\derivative[23]_i_70_n_0 ,\derivative[23]_i_71_n_0 }));
  CARRY4 \derivative_reg[23]_i_52 
       (.CI(\derivative_reg[23]_i_72_n_0 ),
        .CO({\derivative_reg[23]_i_52_n_0 ,\derivative_reg[23]_i_52_n_1 ,\derivative_reg[23]_i_52_n_2 ,\derivative_reg[23]_i_52_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_47_n_5 ,\derivative_reg[23]_i_47_n_6 ,\derivative_reg[23]_i_47_n_7 ,\derivative_reg[23]_i_67_n_4 }),
        .O({\derivative_reg[23]_i_52_n_4 ,\derivative_reg[23]_i_52_n_5 ,\derivative_reg[23]_i_52_n_6 ,\derivative_reg[23]_i_52_n_7 }),
        .S({\derivative[23]_i_73_n_0 ,\derivative[23]_i_74_n_0 ,\derivative[23]_i_75_n_0 ,\derivative[23]_i_76_n_0 }));
  CARRY4 \derivative_reg[23]_i_57 
       (.CI(\derivative_reg[23]_i_77_n_0 ),
        .CO({\derivative_reg[23]_i_57_n_0 ,\derivative_reg[23]_i_57_n_1 ,\derivative_reg[23]_i_57_n_2 ,\derivative_reg[23]_i_57_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_52_n_5 ,\derivative_reg[23]_i_52_n_6 ,\derivative_reg[23]_i_52_n_7 ,\derivative_reg[23]_i_72_n_4 }),
        .O({\derivative_reg[23]_i_57_n_4 ,\derivative_reg[23]_i_57_n_5 ,\derivative_reg[23]_i_57_n_6 ,\derivative_reg[23]_i_57_n_7 }),
        .S({\derivative[23]_i_78_n_0 ,\derivative[23]_i_79_n_0 ,\derivative[23]_i_80_n_0 ,\derivative[23]_i_81_n_0 }));
  CARRY4 \derivative_reg[23]_i_6 
       (.CI(\derivative_reg[23]_i_10_n_0 ),
        .CO({\NLW_derivative_reg[23]_i_6_CO_UNCONNECTED [3:2],derivative1[23],\derivative_reg[23]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[24],\derivative_reg[27]_i_19_n_4 }),
        .O({\NLW_derivative_reg[23]_i_6_O_UNCONNECTED [3:1],\derivative_reg[23]_i_6_n_7 }),
        .S({1'b0,1'b0,\derivative[23]_i_11_n_0 ,\derivative[23]_i_12_n_0 }));
  CARRY4 \derivative_reg[23]_i_62 
       (.CI(\derivative_reg[23]_i_82_n_0 ),
        .CO({\derivative_reg[23]_i_62_n_0 ,\derivative_reg[23]_i_62_n_1 ,\derivative_reg[23]_i_62_n_2 ,\derivative_reg[23]_i_62_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_77_n_5 ,\derivative_reg[27]_i_77_n_6 ,\derivative_reg[27]_i_77_n_7 ,\derivative_reg[27]_i_97_n_4 }),
        .O({\derivative_reg[23]_i_62_n_4 ,\derivative_reg[23]_i_62_n_5 ,\derivative_reg[23]_i_62_n_6 ,\derivative_reg[23]_i_62_n_7 }),
        .S({\derivative[23]_i_83_n_0 ,\derivative[23]_i_84_n_0 ,\derivative[23]_i_85_n_0 ,\derivative[23]_i_86_n_0 }));
  CARRY4 \derivative_reg[23]_i_67 
       (.CI(\derivative_reg[23]_i_87_n_0 ),
        .CO({\derivative_reg[23]_i_67_n_0 ,\derivative_reg[23]_i_67_n_1 ,\derivative_reg[23]_i_67_n_2 ,\derivative_reg[23]_i_67_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_62_n_5 ,\derivative_reg[23]_i_62_n_6 ,\derivative_reg[23]_i_62_n_7 ,\derivative_reg[23]_i_82_n_4 }),
        .O({\derivative_reg[23]_i_67_n_4 ,\derivative_reg[23]_i_67_n_5 ,\derivative_reg[23]_i_67_n_6 ,\derivative_reg[23]_i_67_n_7 }),
        .S({\derivative[23]_i_88_n_0 ,\derivative[23]_i_89_n_0 ,\derivative[23]_i_90_n_0 ,\derivative[23]_i_91_n_0 }));
  CARRY4 \derivative_reg[23]_i_7 
       (.CI(\derivative_reg[23]_i_13_n_0 ),
        .CO({\NLW_derivative_reg[23]_i_7_CO_UNCONNECTED [3:2],derivative1[22],\derivative_reg[23]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[23],\derivative_reg[23]_i_10_n_4 }),
        .O({\NLW_derivative_reg[23]_i_7_O_UNCONNECTED [3:1],\derivative_reg[23]_i_7_n_7 }),
        .S({1'b0,1'b0,\derivative[23]_i_14_n_0 ,\derivative[23]_i_15_n_0 }));
  CARRY4 \derivative_reg[23]_i_72 
       (.CI(\derivative_reg[23]_i_92_n_0 ),
        .CO({\derivative_reg[23]_i_72_n_0 ,\derivative_reg[23]_i_72_n_1 ,\derivative_reg[23]_i_72_n_2 ,\derivative_reg[23]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_67_n_5 ,\derivative_reg[23]_i_67_n_6 ,\derivative_reg[23]_i_67_n_7 ,\derivative_reg[23]_i_87_n_4 }),
        .O({\derivative_reg[23]_i_72_n_4 ,\derivative_reg[23]_i_72_n_5 ,\derivative_reg[23]_i_72_n_6 ,\derivative_reg[23]_i_72_n_7 }),
        .S({\derivative[23]_i_93_n_0 ,\derivative[23]_i_94_n_0 ,\derivative[23]_i_95_n_0 ,\derivative[23]_i_96_n_0 }));
  CARRY4 \derivative_reg[23]_i_77 
       (.CI(\derivative_reg[23]_i_97_n_0 ),
        .CO({\derivative_reg[23]_i_77_n_0 ,\derivative_reg[23]_i_77_n_1 ,\derivative_reg[23]_i_77_n_2 ,\derivative_reg[23]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_72_n_5 ,\derivative_reg[23]_i_72_n_6 ,\derivative_reg[23]_i_72_n_7 ,\derivative_reg[23]_i_92_n_4 }),
        .O({\derivative_reg[23]_i_77_n_4 ,\derivative_reg[23]_i_77_n_5 ,\derivative_reg[23]_i_77_n_6 ,\derivative_reg[23]_i_77_n_7 }),
        .S({\derivative[23]_i_98_n_0 ,\derivative[23]_i_99_n_0 ,\derivative[23]_i_100_n_0 ,\derivative[23]_i_101_n_0 }));
  CARRY4 \derivative_reg[23]_i_8 
       (.CI(\derivative_reg[23]_i_16_n_0 ),
        .CO({\NLW_derivative_reg[23]_i_8_CO_UNCONNECTED [3:2],derivative1[21],\derivative_reg[23]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[22],\derivative_reg[23]_i_13_n_4 }),
        .O({\NLW_derivative_reg[23]_i_8_O_UNCONNECTED [3:1],\derivative_reg[23]_i_8_n_7 }),
        .S({1'b0,1'b0,\derivative[23]_i_17_n_0 ,\derivative[23]_i_18_n_0 }));
  CARRY4 \derivative_reg[23]_i_82 
       (.CI(\derivative_reg[23]_i_102_n_0 ),
        .CO({\derivative_reg[23]_i_82_n_0 ,\derivative_reg[23]_i_82_n_1 ,\derivative_reg[23]_i_82_n_2 ,\derivative_reg[23]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_97_n_5 ,\derivative_reg[27]_i_97_n_6 ,\derivative_reg[27]_i_97_n_7 ,\derivative_reg[27]_i_117_n_4 }),
        .O({\derivative_reg[23]_i_82_n_4 ,\derivative_reg[23]_i_82_n_5 ,\derivative_reg[23]_i_82_n_6 ,\derivative_reg[23]_i_82_n_7 }),
        .S({\derivative[23]_i_103_n_0 ,\derivative[23]_i_104_n_0 ,\derivative[23]_i_105_n_0 ,\derivative[23]_i_106_n_0 }));
  CARRY4 \derivative_reg[23]_i_87 
       (.CI(\derivative_reg[23]_i_107_n_0 ),
        .CO({\derivative_reg[23]_i_87_n_0 ,\derivative_reg[23]_i_87_n_1 ,\derivative_reg[23]_i_87_n_2 ,\derivative_reg[23]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_82_n_5 ,\derivative_reg[23]_i_82_n_6 ,\derivative_reg[23]_i_82_n_7 ,\derivative_reg[23]_i_102_n_4 }),
        .O({\derivative_reg[23]_i_87_n_4 ,\derivative_reg[23]_i_87_n_5 ,\derivative_reg[23]_i_87_n_6 ,\derivative_reg[23]_i_87_n_7 }),
        .S({\derivative[23]_i_108_n_0 ,\derivative[23]_i_109_n_0 ,\derivative[23]_i_110_n_0 ,\derivative[23]_i_111_n_0 }));
  CARRY4 \derivative_reg[23]_i_9 
       (.CI(\derivative_reg[23]_i_19_n_0 ),
        .CO({\NLW_derivative_reg[23]_i_9_CO_UNCONNECTED [3:2],derivative1[20],\derivative_reg[23]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[21],\derivative_reg[23]_i_16_n_4 }),
        .O({\NLW_derivative_reg[23]_i_9_O_UNCONNECTED [3:1],\derivative_reg[23]_i_9_n_7 }),
        .S({1'b0,1'b0,\derivative[23]_i_20_n_0 ,\derivative[23]_i_21_n_0 }));
  CARRY4 \derivative_reg[23]_i_92 
       (.CI(\derivative_reg[23]_i_112_n_0 ),
        .CO({\derivative_reg[23]_i_92_n_0 ,\derivative_reg[23]_i_92_n_1 ,\derivative_reg[23]_i_92_n_2 ,\derivative_reg[23]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_87_n_5 ,\derivative_reg[23]_i_87_n_6 ,\derivative_reg[23]_i_87_n_7 ,\derivative_reg[23]_i_107_n_4 }),
        .O({\derivative_reg[23]_i_92_n_4 ,\derivative_reg[23]_i_92_n_5 ,\derivative_reg[23]_i_92_n_6 ,\derivative_reg[23]_i_92_n_7 }),
        .S({\derivative[23]_i_113_n_0 ,\derivative[23]_i_114_n_0 ,\derivative[23]_i_115_n_0 ,\derivative[23]_i_116_n_0 }));
  CARRY4 \derivative_reg[23]_i_97 
       (.CI(\derivative_reg[23]_i_117_n_0 ),
        .CO({\derivative_reg[23]_i_97_n_0 ,\derivative_reg[23]_i_97_n_1 ,\derivative_reg[23]_i_97_n_2 ,\derivative_reg[23]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[23]_i_92_n_5 ,\derivative_reg[23]_i_92_n_6 ,\derivative_reg[23]_i_92_n_7 ,\derivative_reg[23]_i_112_n_4 }),
        .O({\derivative_reg[23]_i_97_n_4 ,\derivative_reg[23]_i_97_n_5 ,\derivative_reg[23]_i_97_n_6 ,\derivative_reg[23]_i_97_n_7 }),
        .S({\derivative[23]_i_118_n_0 ,\derivative[23]_i_119_n_0 ,\derivative[23]_i_120_n_0 ,\derivative[23]_i_121_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[24] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[27]_i_1_n_7 ),
        .Q(derivative_out[24]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[25] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[27]_i_1_n_6 ),
        .Q(derivative_out[25]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[26] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[27]_i_1_n_5 ),
        .Q(derivative_out[26]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[27] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[27]_i_1_n_4 ),
        .Q(derivative_out[27]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[27]_i_1 
       (.CI(\derivative_reg[23]_i_1_n_0 ),
        .CO({\derivative_reg[27]_i_1_n_0 ,\derivative_reg[27]_i_1_n_1 ,\derivative_reg[27]_i_1_n_2 ,\derivative_reg[27]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[27]_i_1_n_4 ,\derivative_reg[27]_i_1_n_5 ,\derivative_reg[27]_i_1_n_6 ,\derivative_reg[27]_i_1_n_7 }),
        .S({\derivative[27]_i_2_n_0 ,\derivative[27]_i_3_n_0 ,\derivative[27]_i_4_n_0 ,\derivative[27]_i_5_n_0 }));
  CARRY4 \derivative_reg[27]_i_10 
       (.CI(\derivative_reg[27]_i_22_n_0 ),
        .CO({\derivative_reg[27]_i_10_n_0 ,\derivative_reg[27]_i_10_n_1 ,\derivative_reg[27]_i_10_n_2 ,\derivative_reg[27]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_32_n_5 ,\derivative_reg[31]_i_32_n_6 ,\derivative_reg[31]_i_32_n_7 ,\derivative_reg[31]_i_55_n_4 }),
        .O({\derivative_reg[27]_i_10_n_4 ,\derivative_reg[27]_i_10_n_5 ,\derivative_reg[27]_i_10_n_6 ,\derivative_reg[27]_i_10_n_7 }),
        .S({\derivative[27]_i_23_n_0 ,\derivative[27]_i_24_n_0 ,\derivative[27]_i_25_n_0 ,\derivative[27]_i_26_n_0 }));
  CARRY4 \derivative_reg[27]_i_102 
       (.CI(\derivative_reg[27]_i_122_n_0 ),
        .CO({\derivative_reg[27]_i_102_n_0 ,\derivative_reg[27]_i_102_n_1 ,\derivative_reg[27]_i_102_n_2 ,\derivative_reg[27]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_186_n_5 ,\derivative_reg[31]_i_186_n_6 ,\derivative_reg[31]_i_186_n_7 ,\derivative_reg[31]_i_219_n_4 }),
        .O({\derivative_reg[27]_i_102_n_4 ,\derivative_reg[27]_i_102_n_5 ,\derivative_reg[27]_i_102_n_6 ,\derivative_reg[27]_i_102_n_7 }),
        .S({\derivative[27]_i_123_n_0 ,\derivative[27]_i_124_n_0 ,\derivative[27]_i_125_n_0 ,\derivative[27]_i_126_n_0 }));
  CARRY4 \derivative_reg[27]_i_107 
       (.CI(\derivative_reg[27]_i_127_n_0 ),
        .CO({\derivative_reg[27]_i_107_n_0 ,\derivative_reg[27]_i_107_n_1 ,\derivative_reg[27]_i_107_n_2 ,\derivative_reg[27]_i_107_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_102_n_5 ,\derivative_reg[27]_i_102_n_6 ,\derivative_reg[27]_i_102_n_7 ,\derivative_reg[27]_i_122_n_4 }),
        .O({\derivative_reg[27]_i_107_n_4 ,\derivative_reg[27]_i_107_n_5 ,\derivative_reg[27]_i_107_n_6 ,\derivative_reg[27]_i_107_n_7 }),
        .S({\derivative[27]_i_128_n_0 ,\derivative[27]_i_129_n_0 ,\derivative[27]_i_130_n_0 ,\derivative[27]_i_131_n_0 }));
  CARRY4 \derivative_reg[27]_i_112 
       (.CI(\derivative_reg[27]_i_132_n_0 ),
        .CO({\derivative_reg[27]_i_112_n_0 ,\derivative_reg[27]_i_112_n_1 ,\derivative_reg[27]_i_112_n_2 ,\derivative_reg[27]_i_112_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_107_n_5 ,\derivative_reg[27]_i_107_n_6 ,\derivative_reg[27]_i_107_n_7 ,\derivative_reg[27]_i_127_n_4 }),
        .O({\derivative_reg[27]_i_112_n_4 ,\derivative_reg[27]_i_112_n_5 ,\derivative_reg[27]_i_112_n_6 ,\derivative_reg[27]_i_112_n_7 }),
        .S({\derivative[27]_i_133_n_0 ,\derivative[27]_i_134_n_0 ,\derivative[27]_i_135_n_0 ,\derivative[27]_i_136_n_0 }));
  CARRY4 \derivative_reg[27]_i_117 
       (.CI(\derivative_reg[27]_i_137_n_0 ),
        .CO({\derivative_reg[27]_i_117_n_0 ,\derivative_reg[27]_i_117_n_1 ,\derivative_reg[27]_i_117_n_2 ,\derivative_reg[27]_i_117_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_112_n_5 ,\derivative_reg[27]_i_112_n_6 ,\derivative_reg[27]_i_112_n_7 ,\derivative_reg[27]_i_132_n_4 }),
        .O({\derivative_reg[27]_i_117_n_4 ,\derivative_reg[27]_i_117_n_5 ,\derivative_reg[27]_i_117_n_6 ,\derivative_reg[27]_i_117_n_7 }),
        .S({\derivative[27]_i_138_n_0 ,\derivative[27]_i_139_n_0 ,\derivative[27]_i_140_n_0 ,\derivative[27]_i_141_n_0 }));
  CARRY4 \derivative_reg[27]_i_122 
       (.CI(\derivative_reg[27]_i_142_n_0 ),
        .CO({\derivative_reg[27]_i_122_n_0 ,\derivative_reg[27]_i_122_n_1 ,\derivative_reg[27]_i_122_n_2 ,\derivative_reg[27]_i_122_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_219_n_5 ,\derivative_reg[31]_i_219_n_6 ,\derivative_reg[31]_i_219_n_7 ,\derivative_reg[31]_i_252_n_4 }),
        .O({\derivative_reg[27]_i_122_n_4 ,\derivative_reg[27]_i_122_n_5 ,\derivative_reg[27]_i_122_n_6 ,\derivative_reg[27]_i_122_n_7 }),
        .S({\derivative[27]_i_143_n_0 ,\derivative[27]_i_144_n_0 ,\derivative[27]_i_145_n_0 ,\derivative[27]_i_146_n_0 }));
  CARRY4 \derivative_reg[27]_i_127 
       (.CI(\derivative_reg[27]_i_147_n_0 ),
        .CO({\derivative_reg[27]_i_127_n_0 ,\derivative_reg[27]_i_127_n_1 ,\derivative_reg[27]_i_127_n_2 ,\derivative_reg[27]_i_127_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_122_n_5 ,\derivative_reg[27]_i_122_n_6 ,\derivative_reg[27]_i_122_n_7 ,\derivative_reg[27]_i_142_n_4 }),
        .O({\derivative_reg[27]_i_127_n_4 ,\derivative_reg[27]_i_127_n_5 ,\derivative_reg[27]_i_127_n_6 ,\derivative_reg[27]_i_127_n_7 }),
        .S({\derivative[27]_i_148_n_0 ,\derivative[27]_i_149_n_0 ,\derivative[27]_i_150_n_0 ,\derivative[27]_i_151_n_0 }));
  CARRY4 \derivative_reg[27]_i_13 
       (.CI(\derivative_reg[27]_i_27_n_0 ),
        .CO({\derivative_reg[27]_i_13_n_0 ,\derivative_reg[27]_i_13_n_1 ,\derivative_reg[27]_i_13_n_2 ,\derivative_reg[27]_i_13_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_10_n_5 ,\derivative_reg[27]_i_10_n_6 ,\derivative_reg[27]_i_10_n_7 ,\derivative_reg[27]_i_22_n_4 }),
        .O({\derivative_reg[27]_i_13_n_4 ,\derivative_reg[27]_i_13_n_5 ,\derivative_reg[27]_i_13_n_6 ,\derivative_reg[27]_i_13_n_7 }),
        .S({\derivative[27]_i_28_n_0 ,\derivative[27]_i_29_n_0 ,\derivative[27]_i_30_n_0 ,\derivative[27]_i_31_n_0 }));
  CARRY4 \derivative_reg[27]_i_132 
       (.CI(\derivative_reg[27]_i_152_n_0 ),
        .CO({\derivative_reg[27]_i_132_n_0 ,\derivative_reg[27]_i_132_n_1 ,\derivative_reg[27]_i_132_n_2 ,\derivative_reg[27]_i_132_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_127_n_5 ,\derivative_reg[27]_i_127_n_6 ,\derivative_reg[27]_i_127_n_7 ,\derivative_reg[27]_i_147_n_4 }),
        .O({\derivative_reg[27]_i_132_n_4 ,\derivative_reg[27]_i_132_n_5 ,\derivative_reg[27]_i_132_n_6 ,\derivative_reg[27]_i_132_n_7 }),
        .S({\derivative[27]_i_153_n_0 ,\derivative[27]_i_154_n_0 ,\derivative[27]_i_155_n_0 ,\derivative[27]_i_156_n_0 }));
  CARRY4 \derivative_reg[27]_i_137 
       (.CI(\derivative_reg[27]_i_157_n_0 ),
        .CO({\derivative_reg[27]_i_137_n_0 ,\derivative_reg[27]_i_137_n_1 ,\derivative_reg[27]_i_137_n_2 ,\derivative_reg[27]_i_137_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_132_n_5 ,\derivative_reg[27]_i_132_n_6 ,\derivative_reg[27]_i_132_n_7 ,\derivative_reg[27]_i_152_n_4 }),
        .O({\derivative_reg[27]_i_137_n_4 ,\derivative_reg[27]_i_137_n_5 ,\derivative_reg[27]_i_137_n_6 ,\derivative_reg[27]_i_137_n_7 }),
        .S({\derivative[27]_i_158_n_0 ,\derivative[27]_i_159_n_0 ,\derivative[27]_i_160_n_0 ,\derivative[27]_i_161_n_0 }));
  CARRY4 \derivative_reg[27]_i_142 
       (.CI(1'b0),
        .CO({\derivative_reg[27]_i_142_n_0 ,\derivative_reg[27]_i_142_n_1 ,\derivative_reg[27]_i_142_n_2 ,\derivative_reg[27]_i_142_n_3 }),
        .CYINIT(derivative1[28]),
        .DI({\derivative_reg[31]_i_252_n_5 ,\derivative_reg[31]_i_252_n_6 ,derivative20_in[27],1'b0}),
        .O({\derivative_reg[27]_i_142_n_4 ,\derivative_reg[27]_i_142_n_5 ,\derivative_reg[27]_i_142_n_6 ,\NLW_derivative_reg[27]_i_142_O_UNCONNECTED [0]}),
        .S({\derivative[27]_i_163_n_0 ,\derivative[27]_i_164_n_0 ,\derivative[27]_i_165_n_0 ,1'b1}));
  CARRY4 \derivative_reg[27]_i_147 
       (.CI(1'b0),
        .CO({\derivative_reg[27]_i_147_n_0 ,\derivative_reg[27]_i_147_n_1 ,\derivative_reg[27]_i_147_n_2 ,\derivative_reg[27]_i_147_n_3 }),
        .CYINIT(derivative1[27]),
        .DI({\derivative_reg[27]_i_142_n_5 ,\derivative_reg[27]_i_142_n_6 ,derivative20_in[26],1'b0}),
        .O({\derivative_reg[27]_i_147_n_4 ,\derivative_reg[27]_i_147_n_5 ,\derivative_reg[27]_i_147_n_6 ,\NLW_derivative_reg[27]_i_147_O_UNCONNECTED [0]}),
        .S({\derivative[27]_i_167_n_0 ,\derivative[27]_i_168_n_0 ,\derivative[27]_i_169_n_0 ,1'b1}));
  CARRY4 \derivative_reg[27]_i_152 
       (.CI(1'b0),
        .CO({\derivative_reg[27]_i_152_n_0 ,\derivative_reg[27]_i_152_n_1 ,\derivative_reg[27]_i_152_n_2 ,\derivative_reg[27]_i_152_n_3 }),
        .CYINIT(derivative1[26]),
        .DI({\derivative_reg[27]_i_147_n_5 ,\derivative_reg[27]_i_147_n_6 ,derivative20_in[25],1'b0}),
        .O({\derivative_reg[27]_i_152_n_4 ,\derivative_reg[27]_i_152_n_5 ,\derivative_reg[27]_i_152_n_6 ,\NLW_derivative_reg[27]_i_152_O_UNCONNECTED [0]}),
        .S({\derivative[27]_i_171_n_0 ,\derivative[27]_i_172_n_0 ,\derivative[27]_i_173_n_0 ,1'b1}));
  CARRY4 \derivative_reg[27]_i_157 
       (.CI(1'b0),
        .CO({\derivative_reg[27]_i_157_n_0 ,\derivative_reg[27]_i_157_n_1 ,\derivative_reg[27]_i_157_n_2 ,\derivative_reg[27]_i_157_n_3 }),
        .CYINIT(derivative1[25]),
        .DI({\derivative_reg[27]_i_152_n_5 ,\derivative_reg[27]_i_152_n_6 ,derivative20_in[24],1'b0}),
        .O({\derivative_reg[27]_i_157_n_4 ,\derivative_reg[27]_i_157_n_5 ,\derivative_reg[27]_i_157_n_6 ,\NLW_derivative_reg[27]_i_157_O_UNCONNECTED [0]}),
        .S({\derivative[27]_i_175_n_0 ,\derivative[27]_i_176_n_0 ,\derivative[27]_i_177_n_0 ,1'b1}));
  CARRY4 \derivative_reg[27]_i_16 
       (.CI(\derivative_reg[27]_i_32_n_0 ),
        .CO({\derivative_reg[27]_i_16_n_0 ,\derivative_reg[27]_i_16_n_1 ,\derivative_reg[27]_i_16_n_2 ,\derivative_reg[27]_i_16_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_13_n_5 ,\derivative_reg[27]_i_13_n_6 ,\derivative_reg[27]_i_13_n_7 ,\derivative_reg[27]_i_27_n_4 }),
        .O({\derivative_reg[27]_i_16_n_4 ,\derivative_reg[27]_i_16_n_5 ,\derivative_reg[27]_i_16_n_6 ,\derivative_reg[27]_i_16_n_7 }),
        .S({\derivative[27]_i_33_n_0 ,\derivative[27]_i_34_n_0 ,\derivative[27]_i_35_n_0 ,\derivative[27]_i_36_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[27]_i_178 
       (.CI(\derivative_reg[23]_i_178_n_0 ),
        .CO({\derivative_reg[27]_i_178_n_0 ,\derivative_reg[27]_i_178_n_1 ,\derivative_reg[27]_i_178_n_2 ,\derivative_reg[27]_i_178_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[27]_i_178_n_4 ,\derivative_reg[27]_i_178_n_5 ,\derivative_reg[27]_i_178_n_6 ,\derivative_reg[27]_i_178_n_7 }),
        .S({\derivative[27]_i_179_n_0 ,\derivative[27]_i_180_n_0 ,\derivative[27]_i_181_n_0 ,\derivative[27]_i_182_n_0 }));
  CARRY4 \derivative_reg[27]_i_19 
       (.CI(\derivative_reg[27]_i_37_n_0 ),
        .CO({\derivative_reg[27]_i_19_n_0 ,\derivative_reg[27]_i_19_n_1 ,\derivative_reg[27]_i_19_n_2 ,\derivative_reg[27]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_16_n_5 ,\derivative_reg[27]_i_16_n_6 ,\derivative_reg[27]_i_16_n_7 ,\derivative_reg[27]_i_32_n_4 }),
        .O({\derivative_reg[27]_i_19_n_4 ,\derivative_reg[27]_i_19_n_5 ,\derivative_reg[27]_i_19_n_6 ,\derivative_reg[27]_i_19_n_7 }),
        .S({\derivative[27]_i_38_n_0 ,\derivative[27]_i_39_n_0 ,\derivative[27]_i_40_n_0 ,\derivative[27]_i_41_n_0 }));
  CARRY4 \derivative_reg[27]_i_22 
       (.CI(\derivative_reg[27]_i_42_n_0 ),
        .CO({\derivative_reg[27]_i_22_n_0 ,\derivative_reg[27]_i_22_n_1 ,\derivative_reg[27]_i_22_n_2 ,\derivative_reg[27]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_55_n_5 ,\derivative_reg[31]_i_55_n_6 ,\derivative_reg[31]_i_55_n_7 ,\derivative_reg[31]_i_87_n_4 }),
        .O({\derivative_reg[27]_i_22_n_4 ,\derivative_reg[27]_i_22_n_5 ,\derivative_reg[27]_i_22_n_6 ,\derivative_reg[27]_i_22_n_7 }),
        .S({\derivative[27]_i_43_n_0 ,\derivative[27]_i_44_n_0 ,\derivative[27]_i_45_n_0 ,\derivative[27]_i_46_n_0 }));
  CARRY4 \derivative_reg[27]_i_27 
       (.CI(\derivative_reg[27]_i_47_n_0 ),
        .CO({\derivative_reg[27]_i_27_n_0 ,\derivative_reg[27]_i_27_n_1 ,\derivative_reg[27]_i_27_n_2 ,\derivative_reg[27]_i_27_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_22_n_5 ,\derivative_reg[27]_i_22_n_6 ,\derivative_reg[27]_i_22_n_7 ,\derivative_reg[27]_i_42_n_4 }),
        .O({\derivative_reg[27]_i_27_n_4 ,\derivative_reg[27]_i_27_n_5 ,\derivative_reg[27]_i_27_n_6 ,\derivative_reg[27]_i_27_n_7 }),
        .S({\derivative[27]_i_48_n_0 ,\derivative[27]_i_49_n_0 ,\derivative[27]_i_50_n_0 ,\derivative[27]_i_51_n_0 }));
  CARRY4 \derivative_reg[27]_i_32 
       (.CI(\derivative_reg[27]_i_52_n_0 ),
        .CO({\derivative_reg[27]_i_32_n_0 ,\derivative_reg[27]_i_32_n_1 ,\derivative_reg[27]_i_32_n_2 ,\derivative_reg[27]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_27_n_5 ,\derivative_reg[27]_i_27_n_6 ,\derivative_reg[27]_i_27_n_7 ,\derivative_reg[27]_i_47_n_4 }),
        .O({\derivative_reg[27]_i_32_n_4 ,\derivative_reg[27]_i_32_n_5 ,\derivative_reg[27]_i_32_n_6 ,\derivative_reg[27]_i_32_n_7 }),
        .S({\derivative[27]_i_53_n_0 ,\derivative[27]_i_54_n_0 ,\derivative[27]_i_55_n_0 ,\derivative[27]_i_56_n_0 }));
  CARRY4 \derivative_reg[27]_i_37 
       (.CI(\derivative_reg[27]_i_57_n_0 ),
        .CO({\derivative_reg[27]_i_37_n_0 ,\derivative_reg[27]_i_37_n_1 ,\derivative_reg[27]_i_37_n_2 ,\derivative_reg[27]_i_37_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_32_n_5 ,\derivative_reg[27]_i_32_n_6 ,\derivative_reg[27]_i_32_n_7 ,\derivative_reg[27]_i_52_n_4 }),
        .O({\derivative_reg[27]_i_37_n_4 ,\derivative_reg[27]_i_37_n_5 ,\derivative_reg[27]_i_37_n_6 ,\derivative_reg[27]_i_37_n_7 }),
        .S({\derivative[27]_i_58_n_0 ,\derivative[27]_i_59_n_0 ,\derivative[27]_i_60_n_0 ,\derivative[27]_i_61_n_0 }));
  CARRY4 \derivative_reg[27]_i_42 
       (.CI(\derivative_reg[27]_i_62_n_0 ),
        .CO({\derivative_reg[27]_i_42_n_0 ,\derivative_reg[27]_i_42_n_1 ,\derivative_reg[27]_i_42_n_2 ,\derivative_reg[27]_i_42_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_87_n_5 ,\derivative_reg[31]_i_87_n_6 ,\derivative_reg[31]_i_87_n_7 ,\derivative_reg[31]_i_120_n_4 }),
        .O({\derivative_reg[27]_i_42_n_4 ,\derivative_reg[27]_i_42_n_5 ,\derivative_reg[27]_i_42_n_6 ,\derivative_reg[27]_i_42_n_7 }),
        .S({\derivative[27]_i_63_n_0 ,\derivative[27]_i_64_n_0 ,\derivative[27]_i_65_n_0 ,\derivative[27]_i_66_n_0 }));
  CARRY4 \derivative_reg[27]_i_47 
       (.CI(\derivative_reg[27]_i_67_n_0 ),
        .CO({\derivative_reg[27]_i_47_n_0 ,\derivative_reg[27]_i_47_n_1 ,\derivative_reg[27]_i_47_n_2 ,\derivative_reg[27]_i_47_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_42_n_5 ,\derivative_reg[27]_i_42_n_6 ,\derivative_reg[27]_i_42_n_7 ,\derivative_reg[27]_i_62_n_4 }),
        .O({\derivative_reg[27]_i_47_n_4 ,\derivative_reg[27]_i_47_n_5 ,\derivative_reg[27]_i_47_n_6 ,\derivative_reg[27]_i_47_n_7 }),
        .S({\derivative[27]_i_68_n_0 ,\derivative[27]_i_69_n_0 ,\derivative[27]_i_70_n_0 ,\derivative[27]_i_71_n_0 }));
  CARRY4 \derivative_reg[27]_i_52 
       (.CI(\derivative_reg[27]_i_72_n_0 ),
        .CO({\derivative_reg[27]_i_52_n_0 ,\derivative_reg[27]_i_52_n_1 ,\derivative_reg[27]_i_52_n_2 ,\derivative_reg[27]_i_52_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_47_n_5 ,\derivative_reg[27]_i_47_n_6 ,\derivative_reg[27]_i_47_n_7 ,\derivative_reg[27]_i_67_n_4 }),
        .O({\derivative_reg[27]_i_52_n_4 ,\derivative_reg[27]_i_52_n_5 ,\derivative_reg[27]_i_52_n_6 ,\derivative_reg[27]_i_52_n_7 }),
        .S({\derivative[27]_i_73_n_0 ,\derivative[27]_i_74_n_0 ,\derivative[27]_i_75_n_0 ,\derivative[27]_i_76_n_0 }));
  CARRY4 \derivative_reg[27]_i_57 
       (.CI(\derivative_reg[27]_i_77_n_0 ),
        .CO({\derivative_reg[27]_i_57_n_0 ,\derivative_reg[27]_i_57_n_1 ,\derivative_reg[27]_i_57_n_2 ,\derivative_reg[27]_i_57_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_52_n_5 ,\derivative_reg[27]_i_52_n_6 ,\derivative_reg[27]_i_52_n_7 ,\derivative_reg[27]_i_72_n_4 }),
        .O({\derivative_reg[27]_i_57_n_4 ,\derivative_reg[27]_i_57_n_5 ,\derivative_reg[27]_i_57_n_6 ,\derivative_reg[27]_i_57_n_7 }),
        .S({\derivative[27]_i_78_n_0 ,\derivative[27]_i_79_n_0 ,\derivative[27]_i_80_n_0 ,\derivative[27]_i_81_n_0 }));
  CARRY4 \derivative_reg[27]_i_6 
       (.CI(\derivative_reg[27]_i_10_n_0 ),
        .CO({\NLW_derivative_reg[27]_i_6_CO_UNCONNECTED [3:2],derivative1[27],\derivative_reg[27]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[28],\derivative_reg[31]_i_32_n_4 }),
        .O({\NLW_derivative_reg[27]_i_6_O_UNCONNECTED [3:1],\derivative_reg[27]_i_6_n_7 }),
        .S({1'b0,1'b0,\derivative[27]_i_11_n_0 ,\derivative[27]_i_12_n_0 }));
  CARRY4 \derivative_reg[27]_i_62 
       (.CI(\derivative_reg[27]_i_82_n_0 ),
        .CO({\derivative_reg[27]_i_62_n_0 ,\derivative_reg[27]_i_62_n_1 ,\derivative_reg[27]_i_62_n_2 ,\derivative_reg[27]_i_62_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_120_n_5 ,\derivative_reg[31]_i_120_n_6 ,\derivative_reg[31]_i_120_n_7 ,\derivative_reg[31]_i_153_n_4 }),
        .O({\derivative_reg[27]_i_62_n_4 ,\derivative_reg[27]_i_62_n_5 ,\derivative_reg[27]_i_62_n_6 ,\derivative_reg[27]_i_62_n_7 }),
        .S({\derivative[27]_i_83_n_0 ,\derivative[27]_i_84_n_0 ,\derivative[27]_i_85_n_0 ,\derivative[27]_i_86_n_0 }));
  CARRY4 \derivative_reg[27]_i_67 
       (.CI(\derivative_reg[27]_i_87_n_0 ),
        .CO({\derivative_reg[27]_i_67_n_0 ,\derivative_reg[27]_i_67_n_1 ,\derivative_reg[27]_i_67_n_2 ,\derivative_reg[27]_i_67_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_62_n_5 ,\derivative_reg[27]_i_62_n_6 ,\derivative_reg[27]_i_62_n_7 ,\derivative_reg[27]_i_82_n_4 }),
        .O({\derivative_reg[27]_i_67_n_4 ,\derivative_reg[27]_i_67_n_5 ,\derivative_reg[27]_i_67_n_6 ,\derivative_reg[27]_i_67_n_7 }),
        .S({\derivative[27]_i_88_n_0 ,\derivative[27]_i_89_n_0 ,\derivative[27]_i_90_n_0 ,\derivative[27]_i_91_n_0 }));
  CARRY4 \derivative_reg[27]_i_7 
       (.CI(\derivative_reg[27]_i_13_n_0 ),
        .CO({\NLW_derivative_reg[27]_i_7_CO_UNCONNECTED [3:2],derivative1[26],\derivative_reg[27]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[27],\derivative_reg[27]_i_10_n_4 }),
        .O({\NLW_derivative_reg[27]_i_7_O_UNCONNECTED [3:1],\derivative_reg[27]_i_7_n_7 }),
        .S({1'b0,1'b0,\derivative[27]_i_14_n_0 ,\derivative[27]_i_15_n_0 }));
  CARRY4 \derivative_reg[27]_i_72 
       (.CI(\derivative_reg[27]_i_92_n_0 ),
        .CO({\derivative_reg[27]_i_72_n_0 ,\derivative_reg[27]_i_72_n_1 ,\derivative_reg[27]_i_72_n_2 ,\derivative_reg[27]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_67_n_5 ,\derivative_reg[27]_i_67_n_6 ,\derivative_reg[27]_i_67_n_7 ,\derivative_reg[27]_i_87_n_4 }),
        .O({\derivative_reg[27]_i_72_n_4 ,\derivative_reg[27]_i_72_n_5 ,\derivative_reg[27]_i_72_n_6 ,\derivative_reg[27]_i_72_n_7 }),
        .S({\derivative[27]_i_93_n_0 ,\derivative[27]_i_94_n_0 ,\derivative[27]_i_95_n_0 ,\derivative[27]_i_96_n_0 }));
  CARRY4 \derivative_reg[27]_i_77 
       (.CI(\derivative_reg[27]_i_97_n_0 ),
        .CO({\derivative_reg[27]_i_77_n_0 ,\derivative_reg[27]_i_77_n_1 ,\derivative_reg[27]_i_77_n_2 ,\derivative_reg[27]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_72_n_5 ,\derivative_reg[27]_i_72_n_6 ,\derivative_reg[27]_i_72_n_7 ,\derivative_reg[27]_i_92_n_4 }),
        .O({\derivative_reg[27]_i_77_n_4 ,\derivative_reg[27]_i_77_n_5 ,\derivative_reg[27]_i_77_n_6 ,\derivative_reg[27]_i_77_n_7 }),
        .S({\derivative[27]_i_98_n_0 ,\derivative[27]_i_99_n_0 ,\derivative[27]_i_100_n_0 ,\derivative[27]_i_101_n_0 }));
  CARRY4 \derivative_reg[27]_i_8 
       (.CI(\derivative_reg[27]_i_16_n_0 ),
        .CO({\NLW_derivative_reg[27]_i_8_CO_UNCONNECTED [3:2],derivative1[25],\derivative_reg[27]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[26],\derivative_reg[27]_i_13_n_4 }),
        .O({\NLW_derivative_reg[27]_i_8_O_UNCONNECTED [3:1],\derivative_reg[27]_i_8_n_7 }),
        .S({1'b0,1'b0,\derivative[27]_i_17_n_0 ,\derivative[27]_i_18_n_0 }));
  CARRY4 \derivative_reg[27]_i_82 
       (.CI(\derivative_reg[27]_i_102_n_0 ),
        .CO({\derivative_reg[27]_i_82_n_0 ,\derivative_reg[27]_i_82_n_1 ,\derivative_reg[27]_i_82_n_2 ,\derivative_reg[27]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_153_n_5 ,\derivative_reg[31]_i_153_n_6 ,\derivative_reg[31]_i_153_n_7 ,\derivative_reg[31]_i_186_n_4 }),
        .O({\derivative_reg[27]_i_82_n_4 ,\derivative_reg[27]_i_82_n_5 ,\derivative_reg[27]_i_82_n_6 ,\derivative_reg[27]_i_82_n_7 }),
        .S({\derivative[27]_i_103_n_0 ,\derivative[27]_i_104_n_0 ,\derivative[27]_i_105_n_0 ,\derivative[27]_i_106_n_0 }));
  CARRY4 \derivative_reg[27]_i_87 
       (.CI(\derivative_reg[27]_i_107_n_0 ),
        .CO({\derivative_reg[27]_i_87_n_0 ,\derivative_reg[27]_i_87_n_1 ,\derivative_reg[27]_i_87_n_2 ,\derivative_reg[27]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_82_n_5 ,\derivative_reg[27]_i_82_n_6 ,\derivative_reg[27]_i_82_n_7 ,\derivative_reg[27]_i_102_n_4 }),
        .O({\derivative_reg[27]_i_87_n_4 ,\derivative_reg[27]_i_87_n_5 ,\derivative_reg[27]_i_87_n_6 ,\derivative_reg[27]_i_87_n_7 }),
        .S({\derivative[27]_i_108_n_0 ,\derivative[27]_i_109_n_0 ,\derivative[27]_i_110_n_0 ,\derivative[27]_i_111_n_0 }));
  CARRY4 \derivative_reg[27]_i_9 
       (.CI(\derivative_reg[27]_i_19_n_0 ),
        .CO({\NLW_derivative_reg[27]_i_9_CO_UNCONNECTED [3:2],derivative1[24],\derivative_reg[27]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[25],\derivative_reg[27]_i_16_n_4 }),
        .O({\NLW_derivative_reg[27]_i_9_O_UNCONNECTED [3:1],\derivative_reg[27]_i_9_n_7 }),
        .S({1'b0,1'b0,\derivative[27]_i_20_n_0 ,\derivative[27]_i_21_n_0 }));
  CARRY4 \derivative_reg[27]_i_92 
       (.CI(\derivative_reg[27]_i_112_n_0 ),
        .CO({\derivative_reg[27]_i_92_n_0 ,\derivative_reg[27]_i_92_n_1 ,\derivative_reg[27]_i_92_n_2 ,\derivative_reg[27]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_87_n_5 ,\derivative_reg[27]_i_87_n_6 ,\derivative_reg[27]_i_87_n_7 ,\derivative_reg[27]_i_107_n_4 }),
        .O({\derivative_reg[27]_i_92_n_4 ,\derivative_reg[27]_i_92_n_5 ,\derivative_reg[27]_i_92_n_6 ,\derivative_reg[27]_i_92_n_7 }),
        .S({\derivative[27]_i_113_n_0 ,\derivative[27]_i_114_n_0 ,\derivative[27]_i_115_n_0 ,\derivative[27]_i_116_n_0 }));
  CARRY4 \derivative_reg[27]_i_97 
       (.CI(\derivative_reg[27]_i_117_n_0 ),
        .CO({\derivative_reg[27]_i_97_n_0 ,\derivative_reg[27]_i_97_n_1 ,\derivative_reg[27]_i_97_n_2 ,\derivative_reg[27]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[27]_i_92_n_5 ,\derivative_reg[27]_i_92_n_6 ,\derivative_reg[27]_i_92_n_7 ,\derivative_reg[27]_i_112_n_4 }),
        .O({\derivative_reg[27]_i_97_n_4 ,\derivative_reg[27]_i_97_n_5 ,\derivative_reg[27]_i_97_n_6 ,\derivative_reg[27]_i_97_n_7 }),
        .S({\derivative[27]_i_118_n_0 ,\derivative[27]_i_119_n_0 ,\derivative[27]_i_120_n_0 ,\derivative[27]_i_121_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[28] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[31]_i_2_n_7 ),
        .Q(derivative_out[28]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[29] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[31]_i_2_n_6 ),
        .Q(derivative_out[29]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[2] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[3]_i_1_n_5 ),
        .Q(derivative_out[2]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[30] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[31]_i_2_n_5 ),
        .Q(derivative_out[30]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[31] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[31]_i_2_n_4 ),
        .Q(derivative_out[31]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_101 
       (.CI(\derivative_reg[31]_i_134_n_0 ),
        .CO({\derivative_reg[31]_i_101_n_0 ,\derivative_reg[31]_i_101_n_1 ,\derivative_reg[31]_i_101_n_2 ,\derivative_reg[31]_i_101_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_101_n_4 ,\derivative_reg[31]_i_101_n_5 ,\derivative_reg[31]_i_101_n_6 ,\derivative_reg[31]_i_101_n_7 }),
        .S({\derivative[31]_i_135_n_0 ,\derivative[31]_i_136_n_0 ,\derivative[31]_i_137_n_0 ,\derivative[31]_i_138_n_0 }));
  CARRY4 \derivative_reg[31]_i_106 
       (.CI(\derivative_reg[31]_i_139_n_0 ),
        .CO({\derivative_reg[31]_i_106_n_0 ,\derivative_reg[31]_i_106_n_1 ,\derivative_reg[31]_i_106_n_2 ,\derivative_reg[31]_i_106_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_92_n_6 ,\derivative_reg[31]_i_92_n_7 ,\derivative_reg[31]_i_125_n_4 ,\derivative_reg[31]_i_125_n_5 }),
        .O({\derivative_reg[31]_i_106_n_4 ,\derivative_reg[31]_i_106_n_5 ,\derivative_reg[31]_i_106_n_6 ,\derivative_reg[31]_i_106_n_7 }),
        .S({\derivative[31]_i_140_n_0 ,\derivative[31]_i_141_n_0 ,\derivative[31]_i_142_n_0 ,\derivative[31]_i_143_n_0 }));
  CARRY4 \derivative_reg[31]_i_115 
       (.CI(\derivative_reg[31]_i_148_n_0 ),
        .CO({\derivative_reg[31]_i_115_n_0 ,\derivative_reg[31]_i_115_n_1 ,\derivative_reg[31]_i_115_n_2 ,\derivative_reg[31]_i_115_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_106_n_5 ,\derivative_reg[31]_i_106_n_6 ,\derivative_reg[31]_i_106_n_7 ,\derivative_reg[31]_i_139_n_4 }),
        .O({\derivative_reg[31]_i_115_n_4 ,\derivative_reg[31]_i_115_n_5 ,\derivative_reg[31]_i_115_n_6 ,\derivative_reg[31]_i_115_n_7 }),
        .S({\derivative[31]_i_149_n_0 ,\derivative[31]_i_150_n_0 ,\derivative[31]_i_151_n_0 ,\derivative[31]_i_152_n_0 }));
  CARRY4 \derivative_reg[31]_i_120 
       (.CI(\derivative_reg[31]_i_153_n_0 ),
        .CO({\derivative_reg[31]_i_120_n_0 ,\derivative_reg[31]_i_120_n_1 ,\derivative_reg[31]_i_120_n_2 ,\derivative_reg[31]_i_120_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_115_n_5 ,\derivative_reg[31]_i_115_n_6 ,\derivative_reg[31]_i_115_n_7 ,\derivative_reg[31]_i_148_n_4 }),
        .O({\derivative_reg[31]_i_120_n_4 ,\derivative_reg[31]_i_120_n_5 ,\derivative_reg[31]_i_120_n_6 ,\derivative_reg[31]_i_120_n_7 }),
        .S({\derivative[31]_i_154_n_0 ,\derivative[31]_i_155_n_0 ,\derivative[31]_i_156_n_0 ,\derivative[31]_i_157_n_0 }));
  CARRY4 \derivative_reg[31]_i_125 
       (.CI(\derivative_reg[31]_i_158_n_0 ),
        .CO({\derivative_reg[31]_i_125_n_0 ,\derivative_reg[31]_i_125_n_1 ,\derivative_reg[31]_i_125_n_2 ,\derivative_reg[31]_i_125_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_159_n_0 ,\derivative[31]_i_160_n_0 ,\derivative[31]_i_161_n_0 ,\derivative[31]_i_162_n_0 }),
        .O({\derivative_reg[31]_i_125_n_4 ,\derivative_reg[31]_i_125_n_5 ,\derivative_reg[31]_i_125_n_6 ,\derivative_reg[31]_i_125_n_7 }),
        .S({\derivative[31]_i_163_n_0 ,\derivative[31]_i_164_n_0 ,\derivative[31]_i_165_n_0 ,\derivative[31]_i_166_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_134 
       (.CI(\derivative_reg[31]_i_167_n_0 ),
        .CO({\derivative_reg[31]_i_134_n_0 ,\derivative_reg[31]_i_134_n_1 ,\derivative_reg[31]_i_134_n_2 ,\derivative_reg[31]_i_134_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_134_n_4 ,\derivative_reg[31]_i_134_n_5 ,\derivative_reg[31]_i_134_n_6 ,\derivative_reg[31]_i_134_n_7 }),
        .S({\derivative[31]_i_168_n_0 ,\derivative[31]_i_169_n_0 ,\derivative[31]_i_170_n_0 ,\derivative[31]_i_171_n_0 }));
  CARRY4 \derivative_reg[31]_i_139 
       (.CI(\derivative_reg[31]_i_172_n_0 ),
        .CO({\derivative_reg[31]_i_139_n_0 ,\derivative_reg[31]_i_139_n_1 ,\derivative_reg[31]_i_139_n_2 ,\derivative_reg[31]_i_139_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_125_n_6 ,\derivative_reg[31]_i_125_n_7 ,\derivative_reg[31]_i_158_n_4 ,\derivative_reg[31]_i_158_n_5 }),
        .O({\derivative_reg[31]_i_139_n_4 ,\derivative_reg[31]_i_139_n_5 ,\derivative_reg[31]_i_139_n_6 ,\derivative_reg[31]_i_139_n_7 }),
        .S({\derivative[31]_i_173_n_0 ,\derivative[31]_i_174_n_0 ,\derivative[31]_i_175_n_0 ,\derivative[31]_i_176_n_0 }));
  CARRY4 \derivative_reg[31]_i_148 
       (.CI(\derivative_reg[31]_i_181_n_0 ),
        .CO({\derivative_reg[31]_i_148_n_0 ,\derivative_reg[31]_i_148_n_1 ,\derivative_reg[31]_i_148_n_2 ,\derivative_reg[31]_i_148_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_139_n_5 ,\derivative_reg[31]_i_139_n_6 ,\derivative_reg[31]_i_139_n_7 ,\derivative_reg[31]_i_172_n_4 }),
        .O({\derivative_reg[31]_i_148_n_4 ,\derivative_reg[31]_i_148_n_5 ,\derivative_reg[31]_i_148_n_6 ,\derivative_reg[31]_i_148_n_7 }),
        .S({\derivative[31]_i_182_n_0 ,\derivative[31]_i_183_n_0 ,\derivative[31]_i_184_n_0 ,\derivative[31]_i_185_n_0 }));
  CARRY4 \derivative_reg[31]_i_153 
       (.CI(\derivative_reg[31]_i_186_n_0 ),
        .CO({\derivative_reg[31]_i_153_n_0 ,\derivative_reg[31]_i_153_n_1 ,\derivative_reg[31]_i_153_n_2 ,\derivative_reg[31]_i_153_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_148_n_5 ,\derivative_reg[31]_i_148_n_6 ,\derivative_reg[31]_i_148_n_7 ,\derivative_reg[31]_i_181_n_4 }),
        .O({\derivative_reg[31]_i_153_n_4 ,\derivative_reg[31]_i_153_n_5 ,\derivative_reg[31]_i_153_n_6 ,\derivative_reg[31]_i_153_n_7 }),
        .S({\derivative[31]_i_187_n_0 ,\derivative[31]_i_188_n_0 ,\derivative[31]_i_189_n_0 ,\derivative[31]_i_190_n_0 }));
  CARRY4 \derivative_reg[31]_i_158 
       (.CI(\derivative_reg[31]_i_191_n_0 ),
        .CO({\derivative_reg[31]_i_158_n_0 ,\derivative_reg[31]_i_158_n_1 ,\derivative_reg[31]_i_158_n_2 ,\derivative_reg[31]_i_158_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_192_n_0 ,\derivative[31]_i_193_n_0 ,\derivative[31]_i_194_n_0 ,\derivative[31]_i_195_n_0 }),
        .O({\derivative_reg[31]_i_158_n_4 ,\derivative_reg[31]_i_158_n_5 ,\derivative_reg[31]_i_158_n_6 ,\derivative_reg[31]_i_158_n_7 }),
        .S({\derivative[31]_i_196_n_0 ,\derivative[31]_i_197_n_0 ,\derivative[31]_i_198_n_0 ,\derivative[31]_i_199_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_167 
       (.CI(\derivative_reg[31]_i_200_n_0 ),
        .CO({\derivative_reg[31]_i_167_n_0 ,\derivative_reg[31]_i_167_n_1 ,\derivative_reg[31]_i_167_n_2 ,\derivative_reg[31]_i_167_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_167_n_4 ,\derivative_reg[31]_i_167_n_5 ,\derivative_reg[31]_i_167_n_6 ,\derivative_reg[31]_i_167_n_7 }),
        .S({\derivative[31]_i_201_n_0 ,\derivative[31]_i_202_n_0 ,\derivative[31]_i_203_n_0 ,\derivative[31]_i_204_n_0 }));
  CARRY4 \derivative_reg[31]_i_172 
       (.CI(\derivative_reg[31]_i_205_n_0 ),
        .CO({\derivative_reg[31]_i_172_n_0 ,\derivative_reg[31]_i_172_n_1 ,\derivative_reg[31]_i_172_n_2 ,\derivative_reg[31]_i_172_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_158_n_6 ,\derivative_reg[31]_i_158_n_7 ,\derivative_reg[31]_i_191_n_4 ,\derivative_reg[31]_i_191_n_5 }),
        .O({\derivative_reg[31]_i_172_n_4 ,\derivative_reg[31]_i_172_n_5 ,\derivative_reg[31]_i_172_n_6 ,\derivative_reg[31]_i_172_n_7 }),
        .S({\derivative[31]_i_206_n_0 ,\derivative[31]_i_207_n_0 ,\derivative[31]_i_208_n_0 ,\derivative[31]_i_209_n_0 }));
  CARRY4 \derivative_reg[31]_i_181 
       (.CI(\derivative_reg[31]_i_214_n_0 ),
        .CO({\derivative_reg[31]_i_181_n_0 ,\derivative_reg[31]_i_181_n_1 ,\derivative_reg[31]_i_181_n_2 ,\derivative_reg[31]_i_181_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_172_n_5 ,\derivative_reg[31]_i_172_n_6 ,\derivative_reg[31]_i_172_n_7 ,\derivative_reg[31]_i_205_n_4 }),
        .O({\derivative_reg[31]_i_181_n_4 ,\derivative_reg[31]_i_181_n_5 ,\derivative_reg[31]_i_181_n_6 ,\derivative_reg[31]_i_181_n_7 }),
        .S({\derivative[31]_i_215_n_0 ,\derivative[31]_i_216_n_0 ,\derivative[31]_i_217_n_0 ,\derivative[31]_i_218_n_0 }));
  CARRY4 \derivative_reg[31]_i_186 
       (.CI(\derivative_reg[31]_i_219_n_0 ),
        .CO({\derivative_reg[31]_i_186_n_0 ,\derivative_reg[31]_i_186_n_1 ,\derivative_reg[31]_i_186_n_2 ,\derivative_reg[31]_i_186_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_181_n_5 ,\derivative_reg[31]_i_181_n_6 ,\derivative_reg[31]_i_181_n_7 ,\derivative_reg[31]_i_214_n_4 }),
        .O({\derivative_reg[31]_i_186_n_4 ,\derivative_reg[31]_i_186_n_5 ,\derivative_reg[31]_i_186_n_6 ,\derivative_reg[31]_i_186_n_7 }),
        .S({\derivative[31]_i_220_n_0 ,\derivative[31]_i_221_n_0 ,\derivative[31]_i_222_n_0 ,\derivative[31]_i_223_n_0 }));
  CARRY4 \derivative_reg[31]_i_191 
       (.CI(\derivative_reg[31]_i_224_n_0 ),
        .CO({\derivative_reg[31]_i_191_n_0 ,\derivative_reg[31]_i_191_n_1 ,\derivative_reg[31]_i_191_n_2 ,\derivative_reg[31]_i_191_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_225_n_0 ,\derivative[31]_i_226_n_0 ,\derivative[31]_i_227_n_0 ,\derivative[31]_i_228_n_0 }),
        .O({\derivative_reg[31]_i_191_n_4 ,\derivative_reg[31]_i_191_n_5 ,\derivative_reg[31]_i_191_n_6 ,\derivative_reg[31]_i_191_n_7 }),
        .S({\derivative[31]_i_229_n_0 ,\derivative[31]_i_230_n_0 ,\derivative[31]_i_231_n_0 ,\derivative[31]_i_232_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_2 
       (.CI(\derivative_reg[27]_i_1_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_2_CO_UNCONNECTED [3],\derivative_reg[31]_i_2_n_1 ,\derivative_reg[31]_i_2_n_2 ,\derivative_reg[31]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_2_n_4 ,\derivative_reg[31]_i_2_n_5 ,\derivative_reg[31]_i_2_n_6 ,\derivative_reg[31]_i_2_n_7 }),
        .S({\derivative[31]_i_9_n_0 ,\derivative[31]_i_10_n_0 ,\derivative[31]_i_11_n_0 ,\derivative[31]_i_12_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_200 
       (.CI(\derivative_reg[31]_i_233_n_0 ),
        .CO({\derivative_reg[31]_i_200_n_0 ,\derivative_reg[31]_i_200_n_1 ,\derivative_reg[31]_i_200_n_2 ,\derivative_reg[31]_i_200_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_200_n_4 ,\derivative_reg[31]_i_200_n_5 ,\derivative_reg[31]_i_200_n_6 ,\derivative_reg[31]_i_200_n_7 }),
        .S({\derivative[31]_i_234_n_0 ,\derivative[31]_i_235_n_0 ,\derivative[31]_i_236_n_0 ,\derivative[31]_i_237_n_0 }));
  CARRY4 \derivative_reg[31]_i_205 
       (.CI(\derivative_reg[31]_i_238_n_0 ),
        .CO({\derivative_reg[31]_i_205_n_0 ,\derivative_reg[31]_i_205_n_1 ,\derivative_reg[31]_i_205_n_2 ,\derivative_reg[31]_i_205_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_191_n_6 ,\derivative_reg[31]_i_191_n_7 ,\derivative_reg[31]_i_224_n_4 ,\derivative_reg[31]_i_224_n_5 }),
        .O({\derivative_reg[31]_i_205_n_4 ,\derivative_reg[31]_i_205_n_5 ,\derivative_reg[31]_i_205_n_6 ,\derivative_reg[31]_i_205_n_7 }),
        .S({\derivative[31]_i_239_n_0 ,\derivative[31]_i_240_n_0 ,\derivative[31]_i_241_n_0 ,\derivative[31]_i_242_n_0 }));
  CARRY4 \derivative_reg[31]_i_21 
       (.CI(\derivative_reg[31]_i_25_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_21_CO_UNCONNECTED [3:1],derivative1[31]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_derivative_reg[31]_i_21_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  CARRY4 \derivative_reg[31]_i_214 
       (.CI(\derivative_reg[31]_i_247_n_0 ),
        .CO({\derivative_reg[31]_i_214_n_0 ,\derivative_reg[31]_i_214_n_1 ,\derivative_reg[31]_i_214_n_2 ,\derivative_reg[31]_i_214_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_205_n_5 ,\derivative_reg[31]_i_205_n_6 ,\derivative_reg[31]_i_205_n_7 ,\derivative_reg[31]_i_238_n_4 }),
        .O({\derivative_reg[31]_i_214_n_4 ,\derivative_reg[31]_i_214_n_5 ,\derivative_reg[31]_i_214_n_6 ,\derivative_reg[31]_i_214_n_7 }),
        .S({\derivative[31]_i_248_n_0 ,\derivative[31]_i_249_n_0 ,\derivative[31]_i_250_n_0 ,\derivative[31]_i_251_n_0 }));
  CARRY4 \derivative_reg[31]_i_219 
       (.CI(\derivative_reg[31]_i_252_n_0 ),
        .CO({\derivative_reg[31]_i_219_n_0 ,\derivative_reg[31]_i_219_n_1 ,\derivative_reg[31]_i_219_n_2 ,\derivative_reg[31]_i_219_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_214_n_5 ,\derivative_reg[31]_i_214_n_6 ,\derivative_reg[31]_i_214_n_7 ,\derivative_reg[31]_i_247_n_4 }),
        .O({\derivative_reg[31]_i_219_n_4 ,\derivative_reg[31]_i_219_n_5 ,\derivative_reg[31]_i_219_n_6 ,\derivative_reg[31]_i_219_n_7 }),
        .S({\derivative[31]_i_253_n_0 ,\derivative[31]_i_254_n_0 ,\derivative[31]_i_255_n_0 ,\derivative[31]_i_256_n_0 }));
  CARRY4 \derivative_reg[31]_i_22 
       (.CI(\derivative_reg[31]_i_26_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_22_CO_UNCONNECTED [3:2],derivative1[30],\derivative_reg[31]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[31],\derivative_reg[31]_i_25_n_5 }),
        .O({\NLW_derivative_reg[31]_i_22_O_UNCONNECTED [3:1],\derivative_reg[31]_i_22_n_7 }),
        .S({1'b0,1'b0,\derivative[31]_i_27_n_0 ,\derivative[31]_i_28_n_0 }));
  CARRY4 \derivative_reg[31]_i_224 
       (.CI(1'b0),
        .CO({\derivative_reg[31]_i_224_n_0 ,\derivative_reg[31]_i_224_n_1 ,\derivative_reg[31]_i_224_n_2 ,\derivative_reg[31]_i_224_n_3 }),
        .CYINIT(1'b1),
        .DI({\derivative[31]_i_257_n_0 ,\derivative[31]_i_258_n_0 ,\derivative[31]_i_259_n_0 ,derivative20_in[31]}),
        .O({\derivative_reg[31]_i_224_n_4 ,\derivative_reg[31]_i_224_n_5 ,\derivative_reg[31]_i_224_n_6 ,\derivative_reg[31]_i_224_n_7 }),
        .S({\derivative[31]_i_261_n_0 ,\derivative[31]_i_262_n_0 ,\derivative[31]_i_263_n_0 ,\derivative[31]_i_264_n_0 }));
  CARRY4 \derivative_reg[31]_i_23 
       (.CI(\derivative_reg[31]_i_29_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_23_CO_UNCONNECTED [3:2],derivative1[29],\derivative_reg[31]_i_23_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[30],\derivative_reg[31]_i_26_n_4 }),
        .O({\NLW_derivative_reg[31]_i_23_O_UNCONNECTED [3:1],\derivative_reg[31]_i_23_n_7 }),
        .S({1'b0,1'b0,\derivative[31]_i_30_n_0 ,\derivative[31]_i_31_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_233 
       (.CI(\derivative_reg[31]_i_265_n_0 ),
        .CO({\derivative_reg[31]_i_233_n_0 ,\derivative_reg[31]_i_233_n_1 ,\derivative_reg[31]_i_233_n_2 ,\derivative_reg[31]_i_233_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_233_n_4 ,\derivative_reg[31]_i_233_n_5 ,\derivative_reg[31]_i_233_n_6 ,\derivative_reg[31]_i_233_n_7 }),
        .S({\derivative[31]_i_266_n_0 ,\derivative[31]_i_267_n_0 ,\derivative[31]_i_268_n_0 ,\derivative[31]_i_269_n_0 }));
  CARRY4 \derivative_reg[31]_i_238 
       (.CI(1'b0),
        .CO({\derivative_reg[31]_i_238_n_0 ,\derivative_reg[31]_i_238_n_1 ,\derivative_reg[31]_i_238_n_2 ,\derivative_reg[31]_i_238_n_3 }),
        .CYINIT(derivative1[31]),
        .DI({\derivative_reg[31]_i_224_n_6 ,\derivative_reg[31]_i_224_n_7 ,derivative20_in[30],1'b0}),
        .O({\derivative_reg[31]_i_238_n_4 ,\derivative_reg[31]_i_238_n_5 ,\derivative_reg[31]_i_238_n_6 ,\NLW_derivative_reg[31]_i_238_O_UNCONNECTED [0]}),
        .S({\derivative[31]_i_271_n_0 ,\derivative[31]_i_272_n_0 ,\derivative[31]_i_273_n_0 ,1'b1}));
  CARRY4 \derivative_reg[31]_i_24 
       (.CI(\derivative_reg[31]_i_32_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_24_CO_UNCONNECTED [3:2],derivative1[28],\derivative_reg[31]_i_24_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[29],\derivative_reg[31]_i_29_n_4 }),
        .O({\NLW_derivative_reg[31]_i_24_O_UNCONNECTED [3:1],\derivative_reg[31]_i_24_n_7 }),
        .S({1'b0,1'b0,\derivative[31]_i_33_n_0 ,\derivative[31]_i_34_n_0 }));
  CARRY4 \derivative_reg[31]_i_247 
       (.CI(1'b0),
        .CO({\derivative_reg[31]_i_247_n_0 ,\derivative_reg[31]_i_247_n_1 ,\derivative_reg[31]_i_247_n_2 ,\derivative_reg[31]_i_247_n_3 }),
        .CYINIT(derivative1[30]),
        .DI({\derivative_reg[31]_i_238_n_5 ,\derivative_reg[31]_i_238_n_6 ,derivative20_in[29],1'b0}),
        .O({\derivative_reg[31]_i_247_n_4 ,\derivative_reg[31]_i_247_n_5 ,\derivative_reg[31]_i_247_n_6 ,\NLW_derivative_reg[31]_i_247_O_UNCONNECTED [0]}),
        .S({\derivative[31]_i_279_n_0 ,\derivative[31]_i_280_n_0 ,\derivative[31]_i_281_n_0 ,1'b1}));
  CARRY4 \derivative_reg[31]_i_25 
       (.CI(\derivative_reg[31]_i_35_n_0 ),
        .CO({\derivative_reg[31]_i_25_n_0 ,\derivative_reg[31]_i_25_n_1 ,\derivative_reg[31]_i_25_n_2 ,\derivative_reg[31]_i_25_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_36_n_0 ,\derivative[31]_i_37_n_0 ,\derivative[31]_i_38_n_0 ,\derivative[31]_i_39_n_0 }),
        .O({\derivative_reg[31]_i_25_n_4 ,\derivative_reg[31]_i_25_n_5 ,\derivative_reg[31]_i_25_n_6 ,\derivative_reg[31]_i_25_n_7 }),
        .S({\derivative[31]_i_40_n_0 ,\derivative[31]_i_41_n_0 ,\derivative[31]_i_42_n_0 ,\derivative[31]_i_43_n_0 }));
  CARRY4 \derivative_reg[31]_i_252 
       (.CI(1'b0),
        .CO({\derivative_reg[31]_i_252_n_0 ,\derivative_reg[31]_i_252_n_1 ,\derivative_reg[31]_i_252_n_2 ,\derivative_reg[31]_i_252_n_3 }),
        .CYINIT(derivative1[29]),
        .DI({\derivative_reg[31]_i_247_n_5 ,\derivative_reg[31]_i_247_n_6 ,derivative20_in[28],1'b0}),
        .O({\derivative_reg[31]_i_252_n_4 ,\derivative_reg[31]_i_252_n_5 ,\derivative_reg[31]_i_252_n_6 ,\NLW_derivative_reg[31]_i_252_O_UNCONNECTED [0]}),
        .S({\derivative[31]_i_283_n_0 ,\derivative[31]_i_284_n_0 ,\derivative[31]_i_285_n_0 ,1'b1}));
  CARRY4 \derivative_reg[31]_i_26 
       (.CI(\derivative_reg[31]_i_44_n_0 ),
        .CO({\derivative_reg[31]_i_26_n_0 ,\derivative_reg[31]_i_26_n_1 ,\derivative_reg[31]_i_26_n_2 ,\derivative_reg[31]_i_26_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_25_n_6 ,\derivative_reg[31]_i_25_n_7 ,\derivative_reg[31]_i_35_n_4 ,\derivative_reg[31]_i_35_n_5 }),
        .O({\derivative_reg[31]_i_26_n_4 ,\derivative_reg[31]_i_26_n_5 ,\derivative_reg[31]_i_26_n_6 ,\derivative_reg[31]_i_26_n_7 }),
        .S({\derivative[31]_i_45_n_0 ,\derivative[31]_i_46_n_0 ,\derivative[31]_i_47_n_0 ,\derivative[31]_i_48_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_265 
       (.CI(1'b0),
        .CO({\derivative_reg[31]_i_265_n_0 ,\derivative_reg[31]_i_265_n_1 ,\derivative_reg[31]_i_265_n_2 ,\derivative_reg[31]_i_265_n_3 }),
        .CYINIT(\derivative[31]_i_287_n_0 ),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_265_n_4 ,\derivative_reg[31]_i_265_n_5 ,\derivative_reg[31]_i_265_n_6 ,\derivative_reg[31]_i_265_n_7 }),
        .S({\derivative[31]_i_288_n_0 ,\derivative[31]_i_289_n_0 ,\derivative[31]_i_290_n_0 ,\derivative[31]_i_291_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_286 
       (.CI(\derivative_reg[31]_i_294_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_286_CO_UNCONNECTED [3:2],\derivative_reg[31]_i_286_n_2 ,\derivative_reg[31]_i_286_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_derivative_reg[31]_i_286_O_UNCONNECTED [3],\derivative_reg[31]_i_286_n_5 ,\derivative_reg[31]_i_286_n_6 ,\derivative_reg[31]_i_286_n_7 }),
        .S({1'b0,\derivative[31]_i_295_n_0 ,\derivative[31]_i_296_n_0 ,\derivative[31]_i_297_n_0 }));
  CARRY4 \derivative_reg[31]_i_29 
       (.CI(\derivative_reg[31]_i_50_n_0 ),
        .CO({\derivative_reg[31]_i_29_n_0 ,\derivative_reg[31]_i_29_n_1 ,\derivative_reg[31]_i_29_n_2 ,\derivative_reg[31]_i_29_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_26_n_5 ,\derivative_reg[31]_i_26_n_6 ,\derivative_reg[31]_i_26_n_7 ,\derivative_reg[31]_i_44_n_4 }),
        .O({\derivative_reg[31]_i_29_n_4 ,\derivative_reg[31]_i_29_n_5 ,\derivative_reg[31]_i_29_n_6 ,\derivative_reg[31]_i_29_n_7 }),
        .S({\derivative[31]_i_51_n_0 ,\derivative[31]_i_52_n_0 ,\derivative[31]_i_53_n_0 ,\derivative[31]_i_54_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_294 
       (.CI(\derivative_reg[27]_i_178_n_0 ),
        .CO({\derivative_reg[31]_i_294_n_0 ,\derivative_reg[31]_i_294_n_1 ,\derivative_reg[31]_i_294_n_2 ,\derivative_reg[31]_i_294_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_294_n_4 ,\derivative_reg[31]_i_294_n_5 ,\derivative_reg[31]_i_294_n_6 ,\derivative_reg[31]_i_294_n_7 }),
        .S({\derivative[31]_i_298_n_0 ,\derivative[31]_i_299_n_0 ,\derivative[31]_i_300_n_0 ,\derivative[31]_i_301_n_0 }));
  CARRY4 \derivative_reg[31]_i_32 
       (.CI(\derivative_reg[31]_i_55_n_0 ),
        .CO({\derivative_reg[31]_i_32_n_0 ,\derivative_reg[31]_i_32_n_1 ,\derivative_reg[31]_i_32_n_2 ,\derivative_reg[31]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_29_n_5 ,\derivative_reg[31]_i_29_n_6 ,\derivative_reg[31]_i_29_n_7 ,\derivative_reg[31]_i_50_n_4 }),
        .O({\derivative_reg[31]_i_32_n_4 ,\derivative_reg[31]_i_32_n_5 ,\derivative_reg[31]_i_32_n_6 ,\derivative_reg[31]_i_32_n_7 }),
        .S({\derivative[31]_i_56_n_0 ,\derivative[31]_i_57_n_0 ,\derivative[31]_i_58_n_0 ,\derivative[31]_i_59_n_0 }));
  CARRY4 \derivative_reg[31]_i_35 
       (.CI(\derivative_reg[31]_i_60_n_0 ),
        .CO({\derivative_reg[31]_i_35_n_0 ,\derivative_reg[31]_i_35_n_1 ,\derivative_reg[31]_i_35_n_2 ,\derivative_reg[31]_i_35_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_61_n_0 ,\derivative[31]_i_62_n_0 ,\derivative[31]_i_63_n_0 ,\derivative[31]_i_64_n_0 }),
        .O({\derivative_reg[31]_i_35_n_4 ,\derivative_reg[31]_i_35_n_5 ,\derivative_reg[31]_i_35_n_6 ,\derivative_reg[31]_i_35_n_7 }),
        .S({\derivative[31]_i_65_n_0 ,\derivative[31]_i_66_n_0 ,\derivative[31]_i_67_n_0 ,\derivative[31]_i_68_n_0 }));
  CARRY4 \derivative_reg[31]_i_44 
       (.CI(\derivative_reg[31]_i_70_n_0 ),
        .CO({\derivative_reg[31]_i_44_n_0 ,\derivative_reg[31]_i_44_n_1 ,\derivative_reg[31]_i_44_n_2 ,\derivative_reg[31]_i_44_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_35_n_6 ,\derivative_reg[31]_i_35_n_7 ,\derivative_reg[31]_i_60_n_4 ,\derivative_reg[31]_i_60_n_5 }),
        .O({\derivative_reg[31]_i_44_n_4 ,\derivative_reg[31]_i_44_n_5 ,\derivative_reg[31]_i_44_n_6 ,\derivative_reg[31]_i_44_n_7 }),
        .S({\derivative[31]_i_71_n_0 ,\derivative[31]_i_72_n_0 ,\derivative[31]_i_73_n_0 ,\derivative[31]_i_74_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_49 
       (.CI(\derivative_reg[31]_i_69_n_0 ),
        .CO({\NLW_derivative_reg[31]_i_49_CO_UNCONNECTED [3:2],\derivative_reg[31]_i_49_n_2 ,\derivative_reg[31]_i_49_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_derivative_reg[31]_i_49_O_UNCONNECTED [3],\derivative_reg[31]_i_49_n_5 ,\derivative_reg[31]_i_49_n_6 ,\derivative_reg[31]_i_49_n_7 }),
        .S({1'b0,\derivative[31]_i_79_n_0 ,\derivative[31]_i_80_n_0 ,\derivative[31]_i_81_n_0 }));
  CARRY4 \derivative_reg[31]_i_50 
       (.CI(\derivative_reg[31]_i_82_n_0 ),
        .CO({\derivative_reg[31]_i_50_n_0 ,\derivative_reg[31]_i_50_n_1 ,\derivative_reg[31]_i_50_n_2 ,\derivative_reg[31]_i_50_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_44_n_5 ,\derivative_reg[31]_i_44_n_6 ,\derivative_reg[31]_i_44_n_7 ,\derivative_reg[31]_i_70_n_4 }),
        .O({\derivative_reg[31]_i_50_n_4 ,\derivative_reg[31]_i_50_n_5 ,\derivative_reg[31]_i_50_n_6 ,\derivative_reg[31]_i_50_n_7 }),
        .S({\derivative[31]_i_83_n_0 ,\derivative[31]_i_84_n_0 ,\derivative[31]_i_85_n_0 ,\derivative[31]_i_86_n_0 }));
  CARRY4 \derivative_reg[31]_i_55 
       (.CI(\derivative_reg[31]_i_87_n_0 ),
        .CO({\derivative_reg[31]_i_55_n_0 ,\derivative_reg[31]_i_55_n_1 ,\derivative_reg[31]_i_55_n_2 ,\derivative_reg[31]_i_55_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_50_n_5 ,\derivative_reg[31]_i_50_n_6 ,\derivative_reg[31]_i_50_n_7 ,\derivative_reg[31]_i_82_n_4 }),
        .O({\derivative_reg[31]_i_55_n_4 ,\derivative_reg[31]_i_55_n_5 ,\derivative_reg[31]_i_55_n_6 ,\derivative_reg[31]_i_55_n_7 }),
        .S({\derivative[31]_i_88_n_0 ,\derivative[31]_i_89_n_0 ,\derivative[31]_i_90_n_0 ,\derivative[31]_i_91_n_0 }));
  CARRY4 \derivative_reg[31]_i_60 
       (.CI(\derivative_reg[31]_i_92_n_0 ),
        .CO({\derivative_reg[31]_i_60_n_0 ,\derivative_reg[31]_i_60_n_1 ,\derivative_reg[31]_i_60_n_2 ,\derivative_reg[31]_i_60_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_93_n_0 ,\derivative[31]_i_94_n_0 ,\derivative[31]_i_95_n_0 ,\derivative[31]_i_96_n_0 }),
        .O({\derivative_reg[31]_i_60_n_4 ,\derivative_reg[31]_i_60_n_5 ,\derivative_reg[31]_i_60_n_6 ,\derivative_reg[31]_i_60_n_7 }),
        .S({\derivative[31]_i_97_n_0 ,\derivative[31]_i_98_n_0 ,\derivative[31]_i_99_n_0 ,\derivative[31]_i_100_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[31]_i_69 
       (.CI(\derivative_reg[31]_i_101_n_0 ),
        .CO({\derivative_reg[31]_i_69_n_0 ,\derivative_reg[31]_i_69_n_1 ,\derivative_reg[31]_i_69_n_2 ,\derivative_reg[31]_i_69_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[31]_i_69_n_4 ,\derivative_reg[31]_i_69_n_5 ,\derivative_reg[31]_i_69_n_6 ,\derivative_reg[31]_i_69_n_7 }),
        .S({\derivative[31]_i_102_n_0 ,\derivative[31]_i_103_n_0 ,\derivative[31]_i_104_n_0 ,\derivative[31]_i_105_n_0 }));
  CARRY4 \derivative_reg[31]_i_70 
       (.CI(\derivative_reg[31]_i_106_n_0 ),
        .CO({\derivative_reg[31]_i_70_n_0 ,\derivative_reg[31]_i_70_n_1 ,\derivative_reg[31]_i_70_n_2 ,\derivative_reg[31]_i_70_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_60_n_6 ,\derivative_reg[31]_i_60_n_7 ,\derivative_reg[31]_i_92_n_4 ,\derivative_reg[31]_i_92_n_5 }),
        .O({\derivative_reg[31]_i_70_n_4 ,\derivative_reg[31]_i_70_n_5 ,\derivative_reg[31]_i_70_n_6 ,\derivative_reg[31]_i_70_n_7 }),
        .S({\derivative[31]_i_107_n_0 ,\derivative[31]_i_108_n_0 ,\derivative[31]_i_109_n_0 ,\derivative[31]_i_110_n_0 }));
  CARRY4 \derivative_reg[31]_i_82 
       (.CI(\derivative_reg[31]_i_115_n_0 ),
        .CO({\derivative_reg[31]_i_82_n_0 ,\derivative_reg[31]_i_82_n_1 ,\derivative_reg[31]_i_82_n_2 ,\derivative_reg[31]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_70_n_5 ,\derivative_reg[31]_i_70_n_6 ,\derivative_reg[31]_i_70_n_7 ,\derivative_reg[31]_i_106_n_4 }),
        .O({\derivative_reg[31]_i_82_n_4 ,\derivative_reg[31]_i_82_n_5 ,\derivative_reg[31]_i_82_n_6 ,\derivative_reg[31]_i_82_n_7 }),
        .S({\derivative[31]_i_116_n_0 ,\derivative[31]_i_117_n_0 ,\derivative[31]_i_118_n_0 ,\derivative[31]_i_119_n_0 }));
  CARRY4 \derivative_reg[31]_i_87 
       (.CI(\derivative_reg[31]_i_120_n_0 ),
        .CO({\derivative_reg[31]_i_87_n_0 ,\derivative_reg[31]_i_87_n_1 ,\derivative_reg[31]_i_87_n_2 ,\derivative_reg[31]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[31]_i_82_n_5 ,\derivative_reg[31]_i_82_n_6 ,\derivative_reg[31]_i_82_n_7 ,\derivative_reg[31]_i_115_n_4 }),
        .O({\derivative_reg[31]_i_87_n_4 ,\derivative_reg[31]_i_87_n_5 ,\derivative_reg[31]_i_87_n_6 ,\derivative_reg[31]_i_87_n_7 }),
        .S({\derivative[31]_i_121_n_0 ,\derivative[31]_i_122_n_0 ,\derivative[31]_i_123_n_0 ,\derivative[31]_i_124_n_0 }));
  CARRY4 \derivative_reg[31]_i_92 
       (.CI(\derivative_reg[31]_i_125_n_0 ),
        .CO({\derivative_reg[31]_i_92_n_0 ,\derivative_reg[31]_i_92_n_1 ,\derivative_reg[31]_i_92_n_2 ,\derivative_reg[31]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative[31]_i_126_n_0 ,\derivative[31]_i_127_n_0 ,\derivative[31]_i_128_n_0 ,\derivative[31]_i_129_n_0 }),
        .O({\derivative_reg[31]_i_92_n_4 ,\derivative_reg[31]_i_92_n_5 ,\derivative_reg[31]_i_92_n_6 ,\derivative_reg[31]_i_92_n_7 }),
        .S({\derivative[31]_i_130_n_0 ,\derivative[31]_i_131_n_0 ,\derivative[31]_i_132_n_0 ,\derivative[31]_i_133_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[3] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[3]_i_1_n_4 ),
        .Q(derivative_out[3]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\derivative_reg[3]_i_1_n_0 ,\derivative_reg[3]_i_1_n_1 ,\derivative_reg[3]_i_1_n_2 ,\derivative_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,p_0_out}),
        .O({\derivative_reg[3]_i_1_n_4 ,\derivative_reg[3]_i_1_n_5 ,\derivative_reg[3]_i_1_n_6 ,\derivative_reg[3]_i_1_n_7 }),
        .S({\derivative[3]_i_3_n_0 ,\derivative[3]_i_4_n_0 ,\derivative[3]_i_5_n_0 ,\derivative[3]_i_6_n_0 }));
  CARRY4 \derivative_reg[3]_i_10 
       (.CI(\derivative_reg[3]_i_20_n_0 ),
        .CO({\NLW_derivative_reg[3]_i_10_CO_UNCONNECTED [3:1],derivative1[0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,derivative1[1]}),
        .O(\NLW_derivative_reg[3]_i_10_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\derivative[3]_i_21_n_0 }));
  CARRY4 \derivative_reg[3]_i_102 
       (.CI(\derivative_reg[3]_i_122_n_0 ),
        .CO({\derivative_reg[3]_i_102_n_0 ,\derivative_reg[3]_i_102_n_1 ,\derivative_reg[3]_i_102_n_2 ,\derivative_reg[3]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_117_n_5 ,\derivative_reg[7]_i_117_n_6 ,\derivative_reg[7]_i_117_n_7 ,\derivative_reg[7]_i_137_n_4 }),
        .O({\derivative_reg[3]_i_102_n_4 ,\derivative_reg[3]_i_102_n_5 ,\derivative_reg[3]_i_102_n_6 ,\derivative_reg[3]_i_102_n_7 }),
        .S({\derivative[3]_i_123_n_0 ,\derivative[3]_i_124_n_0 ,\derivative[3]_i_125_n_0 ,\derivative[3]_i_126_n_0 }));
  CARRY4 \derivative_reg[3]_i_107 
       (.CI(\derivative_reg[3]_i_127_n_0 ),
        .CO({\derivative_reg[3]_i_107_n_0 ,\derivative_reg[3]_i_107_n_1 ,\derivative_reg[3]_i_107_n_2 ,\derivative_reg[3]_i_107_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_102_n_5 ,\derivative_reg[3]_i_102_n_6 ,\derivative_reg[3]_i_102_n_7 ,\derivative_reg[3]_i_122_n_4 }),
        .O({\derivative_reg[3]_i_107_n_4 ,\derivative_reg[3]_i_107_n_5 ,\derivative_reg[3]_i_107_n_6 ,\derivative_reg[3]_i_107_n_7 }),
        .S({\derivative[3]_i_128_n_0 ,\derivative[3]_i_129_n_0 ,\derivative[3]_i_130_n_0 ,\derivative[3]_i_131_n_0 }));
  CARRY4 \derivative_reg[3]_i_11 
       (.CI(\derivative_reg[3]_i_22_n_0 ),
        .CO({\derivative_reg[3]_i_11_n_0 ,\derivative_reg[3]_i_11_n_1 ,\derivative_reg[3]_i_11_n_2 ,\derivative_reg[3]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_19_n_5 ,\derivative_reg[7]_i_19_n_6 ,\derivative_reg[7]_i_19_n_7 ,\derivative_reg[7]_i_37_n_4 }),
        .O({\derivative_reg[3]_i_11_n_4 ,\derivative_reg[3]_i_11_n_5 ,\derivative_reg[3]_i_11_n_6 ,\derivative_reg[3]_i_11_n_7 }),
        .S({\derivative[3]_i_23_n_0 ,\derivative[3]_i_24_n_0 ,\derivative[3]_i_25_n_0 ,\derivative[3]_i_26_n_0 }));
  CARRY4 \derivative_reg[3]_i_112 
       (.CI(\derivative_reg[3]_i_132_n_0 ),
        .CO({\derivative_reg[3]_i_112_n_0 ,\derivative_reg[3]_i_112_n_1 ,\derivative_reg[3]_i_112_n_2 ,\derivative_reg[3]_i_112_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_107_n_5 ,\derivative_reg[3]_i_107_n_6 ,\derivative_reg[3]_i_107_n_7 ,\derivative_reg[3]_i_127_n_4 }),
        .O({\derivative_reg[3]_i_112_n_4 ,\derivative_reg[3]_i_112_n_5 ,\derivative_reg[3]_i_112_n_6 ,\derivative_reg[3]_i_112_n_7 }),
        .S({\derivative[3]_i_133_n_0 ,\derivative[3]_i_134_n_0 ,\derivative[3]_i_135_n_0 ,\derivative[3]_i_136_n_0 }));
  CARRY4 \derivative_reg[3]_i_117 
       (.CI(\derivative_reg[3]_i_137_n_0 ),
        .CO({\derivative_reg[3]_i_117_n_0 ,\derivative_reg[3]_i_117_n_1 ,\derivative_reg[3]_i_117_n_2 ,\derivative_reg[3]_i_117_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_112_n_4 ,\derivative_reg[3]_i_112_n_5 ,\derivative_reg[3]_i_112_n_6 ,\derivative_reg[3]_i_112_n_7 }),
        .O(\NLW_derivative_reg[3]_i_117_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_138_n_0 ,\derivative[3]_i_139_n_0 ,\derivative[3]_i_140_n_0 ,\derivative[3]_i_141_n_0 }));
  CARRY4 \derivative_reg[3]_i_122 
       (.CI(\derivative_reg[3]_i_142_n_0 ),
        .CO({\derivative_reg[3]_i_122_n_0 ,\derivative_reg[3]_i_122_n_1 ,\derivative_reg[3]_i_122_n_2 ,\derivative_reg[3]_i_122_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_137_n_5 ,\derivative_reg[7]_i_137_n_6 ,\derivative_reg[7]_i_137_n_7 ,\derivative_reg[7]_i_157_n_4 }),
        .O({\derivative_reg[3]_i_122_n_4 ,\derivative_reg[3]_i_122_n_5 ,\derivative_reg[3]_i_122_n_6 ,\derivative_reg[3]_i_122_n_7 }),
        .S({\derivative[3]_i_143_n_0 ,\derivative[3]_i_144_n_0 ,\derivative[3]_i_145_n_0 ,\derivative[3]_i_146_n_0 }));
  CARRY4 \derivative_reg[3]_i_127 
       (.CI(\derivative_reg[3]_i_147_n_0 ),
        .CO({\derivative_reg[3]_i_127_n_0 ,\derivative_reg[3]_i_127_n_1 ,\derivative_reg[3]_i_127_n_2 ,\derivative_reg[3]_i_127_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_122_n_5 ,\derivative_reg[3]_i_122_n_6 ,\derivative_reg[3]_i_122_n_7 ,\derivative_reg[3]_i_142_n_4 }),
        .O({\derivative_reg[3]_i_127_n_4 ,\derivative_reg[3]_i_127_n_5 ,\derivative_reg[3]_i_127_n_6 ,\derivative_reg[3]_i_127_n_7 }),
        .S({\derivative[3]_i_148_n_0 ,\derivative[3]_i_149_n_0 ,\derivative[3]_i_150_n_0 ,\derivative[3]_i_151_n_0 }));
  CARRY4 \derivative_reg[3]_i_132 
       (.CI(\derivative_reg[3]_i_152_n_0 ),
        .CO({\derivative_reg[3]_i_132_n_0 ,\derivative_reg[3]_i_132_n_1 ,\derivative_reg[3]_i_132_n_2 ,\derivative_reg[3]_i_132_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_127_n_5 ,\derivative_reg[3]_i_127_n_6 ,\derivative_reg[3]_i_127_n_7 ,\derivative_reg[3]_i_147_n_4 }),
        .O({\derivative_reg[3]_i_132_n_4 ,\derivative_reg[3]_i_132_n_5 ,\derivative_reg[3]_i_132_n_6 ,\derivative_reg[3]_i_132_n_7 }),
        .S({\derivative[3]_i_153_n_0 ,\derivative[3]_i_154_n_0 ,\derivative[3]_i_155_n_0 ,\derivative[3]_i_156_n_0 }));
  CARRY4 \derivative_reg[3]_i_137 
       (.CI(\derivative_reg[3]_i_157_n_0 ),
        .CO({\derivative_reg[3]_i_137_n_0 ,\derivative_reg[3]_i_137_n_1 ,\derivative_reg[3]_i_137_n_2 ,\derivative_reg[3]_i_137_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_132_n_4 ,\derivative_reg[3]_i_132_n_5 ,\derivative_reg[3]_i_132_n_6 ,\derivative_reg[3]_i_132_n_7 }),
        .O(\NLW_derivative_reg[3]_i_137_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_158_n_0 ,\derivative[3]_i_159_n_0 ,\derivative[3]_i_160_n_0 ,\derivative[3]_i_161_n_0 }));
  CARRY4 \derivative_reg[3]_i_14 
       (.CI(\derivative_reg[3]_i_27_n_0 ),
        .CO({\derivative_reg[3]_i_14_n_0 ,\derivative_reg[3]_i_14_n_1 ,\derivative_reg[3]_i_14_n_2 ,\derivative_reg[3]_i_14_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_11_n_5 ,\derivative_reg[3]_i_11_n_6 ,\derivative_reg[3]_i_11_n_7 ,\derivative_reg[3]_i_22_n_4 }),
        .O({\derivative_reg[3]_i_14_n_4 ,\derivative_reg[3]_i_14_n_5 ,\derivative_reg[3]_i_14_n_6 ,\derivative_reg[3]_i_14_n_7 }),
        .S({\derivative[3]_i_28_n_0 ,\derivative[3]_i_29_n_0 ,\derivative[3]_i_30_n_0 ,\derivative[3]_i_31_n_0 }));
  CARRY4 \derivative_reg[3]_i_142 
       (.CI(1'b0),
        .CO({\derivative_reg[3]_i_142_n_0 ,\derivative_reg[3]_i_142_n_1 ,\derivative_reg[3]_i_142_n_2 ,\derivative_reg[3]_i_142_n_3 }),
        .CYINIT(derivative1[4]),
        .DI({\derivative_reg[7]_i_157_n_5 ,\derivative_reg[7]_i_157_n_6 ,derivative20_in[3],1'b0}),
        .O({\derivative_reg[3]_i_142_n_4 ,\derivative_reg[3]_i_142_n_5 ,\derivative_reg[3]_i_142_n_6 ,\NLW_derivative_reg[3]_i_142_O_UNCONNECTED [0]}),
        .S({\derivative[3]_i_163_n_0 ,\derivative[3]_i_164_n_0 ,\derivative[3]_i_165_n_0 ,1'b1}));
  CARRY4 \derivative_reg[3]_i_147 
       (.CI(1'b0),
        .CO({\derivative_reg[3]_i_147_n_0 ,\derivative_reg[3]_i_147_n_1 ,\derivative_reg[3]_i_147_n_2 ,\derivative_reg[3]_i_147_n_3 }),
        .CYINIT(derivative1[3]),
        .DI({\derivative_reg[3]_i_142_n_5 ,\derivative_reg[3]_i_142_n_6 ,derivative20_in[2],1'b0}),
        .O({\derivative_reg[3]_i_147_n_4 ,\derivative_reg[3]_i_147_n_5 ,\derivative_reg[3]_i_147_n_6 ,\NLW_derivative_reg[3]_i_147_O_UNCONNECTED [0]}),
        .S({\derivative[3]_i_167_n_0 ,\derivative[3]_i_168_n_0 ,\derivative[3]_i_169_n_0 ,1'b1}));
  CARRY4 \derivative_reg[3]_i_152 
       (.CI(1'b0),
        .CO({\derivative_reg[3]_i_152_n_0 ,\derivative_reg[3]_i_152_n_1 ,\derivative_reg[3]_i_152_n_2 ,\derivative_reg[3]_i_152_n_3 }),
        .CYINIT(derivative1[2]),
        .DI({\derivative_reg[3]_i_147_n_5 ,\derivative_reg[3]_i_147_n_6 ,derivative20_in[1],1'b0}),
        .O({\derivative_reg[3]_i_152_n_4 ,\derivative_reg[3]_i_152_n_5 ,\derivative_reg[3]_i_152_n_6 ,\NLW_derivative_reg[3]_i_152_O_UNCONNECTED [0]}),
        .S({\derivative[3]_i_171_n_0 ,\derivative[3]_i_172_n_0 ,\derivative[3]_i_173_n_0 ,1'b1}));
  CARRY4 \derivative_reg[3]_i_157 
       (.CI(1'b0),
        .CO({\derivative_reg[3]_i_157_n_0 ,\derivative_reg[3]_i_157_n_1 ,\derivative_reg[3]_i_157_n_2 ,\derivative_reg[3]_i_157_n_3 }),
        .CYINIT(derivative1[1]),
        .DI({\derivative_reg[3]_i_152_n_4 ,\derivative_reg[3]_i_152_n_5 ,\derivative_reg[3]_i_152_n_6 ,derivative4__93[0]}),
        .O(\NLW_derivative_reg[3]_i_157_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_174_n_0 ,\derivative[3]_i_175_n_0 ,\derivative[3]_i_176_n_0 ,\derivative[3]_i_177_n_0 }));
  CARRY4 \derivative_reg[3]_i_17 
       (.CI(\derivative_reg[3]_i_32_n_0 ),
        .CO({\derivative_reg[3]_i_17_n_0 ,\derivative_reg[3]_i_17_n_1 ,\derivative_reg[3]_i_17_n_2 ,\derivative_reg[3]_i_17_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_14_n_5 ,\derivative_reg[3]_i_14_n_6 ,\derivative_reg[3]_i_14_n_7 ,\derivative_reg[3]_i_27_n_4 }),
        .O({\derivative_reg[3]_i_17_n_4 ,\derivative_reg[3]_i_17_n_5 ,\derivative_reg[3]_i_17_n_6 ,\derivative_reg[3]_i_17_n_7 }),
        .S({\derivative[3]_i_33_n_0 ,\derivative[3]_i_34_n_0 ,\derivative[3]_i_35_n_0 ,\derivative[3]_i_36_n_0 }));
  CARRY4 \derivative_reg[3]_i_20 
       (.CI(\derivative_reg[3]_i_37_n_0 ),
        .CO({\derivative_reg[3]_i_20_n_0 ,\derivative_reg[3]_i_20_n_1 ,\derivative_reg[3]_i_20_n_2 ,\derivative_reg[3]_i_20_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_17_n_4 ,\derivative_reg[3]_i_17_n_5 ,\derivative_reg[3]_i_17_n_6 ,\derivative_reg[3]_i_17_n_7 }),
        .O(\NLW_derivative_reg[3]_i_20_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_38_n_0 ,\derivative[3]_i_39_n_0 ,\derivative[3]_i_40_n_0 ,\derivative[3]_i_41_n_0 }));
  CARRY4 \derivative_reg[3]_i_22 
       (.CI(\derivative_reg[3]_i_42_n_0 ),
        .CO({\derivative_reg[3]_i_22_n_0 ,\derivative_reg[3]_i_22_n_1 ,\derivative_reg[3]_i_22_n_2 ,\derivative_reg[3]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_37_n_5 ,\derivative_reg[7]_i_37_n_6 ,\derivative_reg[7]_i_37_n_7 ,\derivative_reg[7]_i_57_n_4 }),
        .O({\derivative_reg[3]_i_22_n_4 ,\derivative_reg[3]_i_22_n_5 ,\derivative_reg[3]_i_22_n_6 ,\derivative_reg[3]_i_22_n_7 }),
        .S({\derivative[3]_i_43_n_0 ,\derivative[3]_i_44_n_0 ,\derivative[3]_i_45_n_0 ,\derivative[3]_i_46_n_0 }));
  CARRY4 \derivative_reg[3]_i_27 
       (.CI(\derivative_reg[3]_i_47_n_0 ),
        .CO({\derivative_reg[3]_i_27_n_0 ,\derivative_reg[3]_i_27_n_1 ,\derivative_reg[3]_i_27_n_2 ,\derivative_reg[3]_i_27_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_22_n_5 ,\derivative_reg[3]_i_22_n_6 ,\derivative_reg[3]_i_22_n_7 ,\derivative_reg[3]_i_42_n_4 }),
        .O({\derivative_reg[3]_i_27_n_4 ,\derivative_reg[3]_i_27_n_5 ,\derivative_reg[3]_i_27_n_6 ,\derivative_reg[3]_i_27_n_7 }),
        .S({\derivative[3]_i_48_n_0 ,\derivative[3]_i_49_n_0 ,\derivative[3]_i_50_n_0 ,\derivative[3]_i_51_n_0 }));
  CARRY4 \derivative_reg[3]_i_32 
       (.CI(\derivative_reg[3]_i_52_n_0 ),
        .CO({\derivative_reg[3]_i_32_n_0 ,\derivative_reg[3]_i_32_n_1 ,\derivative_reg[3]_i_32_n_2 ,\derivative_reg[3]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_27_n_5 ,\derivative_reg[3]_i_27_n_6 ,\derivative_reg[3]_i_27_n_7 ,\derivative_reg[3]_i_47_n_4 }),
        .O({\derivative_reg[3]_i_32_n_4 ,\derivative_reg[3]_i_32_n_5 ,\derivative_reg[3]_i_32_n_6 ,\derivative_reg[3]_i_32_n_7 }),
        .S({\derivative[3]_i_53_n_0 ,\derivative[3]_i_54_n_0 ,\derivative[3]_i_55_n_0 ,\derivative[3]_i_56_n_0 }));
  CARRY4 \derivative_reg[3]_i_37 
       (.CI(\derivative_reg[3]_i_57_n_0 ),
        .CO({\derivative_reg[3]_i_37_n_0 ,\derivative_reg[3]_i_37_n_1 ,\derivative_reg[3]_i_37_n_2 ,\derivative_reg[3]_i_37_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_32_n_4 ,\derivative_reg[3]_i_32_n_5 ,\derivative_reg[3]_i_32_n_6 ,\derivative_reg[3]_i_32_n_7 }),
        .O(\NLW_derivative_reg[3]_i_37_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_58_n_0 ,\derivative[3]_i_59_n_0 ,\derivative[3]_i_60_n_0 ,\derivative[3]_i_61_n_0 }));
  CARRY4 \derivative_reg[3]_i_42 
       (.CI(\derivative_reg[3]_i_62_n_0 ),
        .CO({\derivative_reg[3]_i_42_n_0 ,\derivative_reg[3]_i_42_n_1 ,\derivative_reg[3]_i_42_n_2 ,\derivative_reg[3]_i_42_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_57_n_5 ,\derivative_reg[7]_i_57_n_6 ,\derivative_reg[7]_i_57_n_7 ,\derivative_reg[7]_i_77_n_4 }),
        .O({\derivative_reg[3]_i_42_n_4 ,\derivative_reg[3]_i_42_n_5 ,\derivative_reg[3]_i_42_n_6 ,\derivative_reg[3]_i_42_n_7 }),
        .S({\derivative[3]_i_63_n_0 ,\derivative[3]_i_64_n_0 ,\derivative[3]_i_65_n_0 ,\derivative[3]_i_66_n_0 }));
  CARRY4 \derivative_reg[3]_i_47 
       (.CI(\derivative_reg[3]_i_67_n_0 ),
        .CO({\derivative_reg[3]_i_47_n_0 ,\derivative_reg[3]_i_47_n_1 ,\derivative_reg[3]_i_47_n_2 ,\derivative_reg[3]_i_47_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_42_n_5 ,\derivative_reg[3]_i_42_n_6 ,\derivative_reg[3]_i_42_n_7 ,\derivative_reg[3]_i_62_n_4 }),
        .O({\derivative_reg[3]_i_47_n_4 ,\derivative_reg[3]_i_47_n_5 ,\derivative_reg[3]_i_47_n_6 ,\derivative_reg[3]_i_47_n_7 }),
        .S({\derivative[3]_i_68_n_0 ,\derivative[3]_i_69_n_0 ,\derivative[3]_i_70_n_0 ,\derivative[3]_i_71_n_0 }));
  CARRY4 \derivative_reg[3]_i_52 
       (.CI(\derivative_reg[3]_i_72_n_0 ),
        .CO({\derivative_reg[3]_i_52_n_0 ,\derivative_reg[3]_i_52_n_1 ,\derivative_reg[3]_i_52_n_2 ,\derivative_reg[3]_i_52_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_47_n_5 ,\derivative_reg[3]_i_47_n_6 ,\derivative_reg[3]_i_47_n_7 ,\derivative_reg[3]_i_67_n_4 }),
        .O({\derivative_reg[3]_i_52_n_4 ,\derivative_reg[3]_i_52_n_5 ,\derivative_reg[3]_i_52_n_6 ,\derivative_reg[3]_i_52_n_7 }),
        .S({\derivative[3]_i_73_n_0 ,\derivative[3]_i_74_n_0 ,\derivative[3]_i_75_n_0 ,\derivative[3]_i_76_n_0 }));
  CARRY4 \derivative_reg[3]_i_57 
       (.CI(\derivative_reg[3]_i_77_n_0 ),
        .CO({\derivative_reg[3]_i_57_n_0 ,\derivative_reg[3]_i_57_n_1 ,\derivative_reg[3]_i_57_n_2 ,\derivative_reg[3]_i_57_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_52_n_4 ,\derivative_reg[3]_i_52_n_5 ,\derivative_reg[3]_i_52_n_6 ,\derivative_reg[3]_i_52_n_7 }),
        .O(\NLW_derivative_reg[3]_i_57_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_78_n_0 ,\derivative[3]_i_79_n_0 ,\derivative[3]_i_80_n_0 ,\derivative[3]_i_81_n_0 }));
  CARRY4 \derivative_reg[3]_i_62 
       (.CI(\derivative_reg[3]_i_82_n_0 ),
        .CO({\derivative_reg[3]_i_62_n_0 ,\derivative_reg[3]_i_62_n_1 ,\derivative_reg[3]_i_62_n_2 ,\derivative_reg[3]_i_62_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_77_n_5 ,\derivative_reg[7]_i_77_n_6 ,\derivative_reg[7]_i_77_n_7 ,\derivative_reg[7]_i_97_n_4 }),
        .O({\derivative_reg[3]_i_62_n_4 ,\derivative_reg[3]_i_62_n_5 ,\derivative_reg[3]_i_62_n_6 ,\derivative_reg[3]_i_62_n_7 }),
        .S({\derivative[3]_i_83_n_0 ,\derivative[3]_i_84_n_0 ,\derivative[3]_i_85_n_0 ,\derivative[3]_i_86_n_0 }));
  CARRY4 \derivative_reg[3]_i_67 
       (.CI(\derivative_reg[3]_i_87_n_0 ),
        .CO({\derivative_reg[3]_i_67_n_0 ,\derivative_reg[3]_i_67_n_1 ,\derivative_reg[3]_i_67_n_2 ,\derivative_reg[3]_i_67_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_62_n_5 ,\derivative_reg[3]_i_62_n_6 ,\derivative_reg[3]_i_62_n_7 ,\derivative_reg[3]_i_82_n_4 }),
        .O({\derivative_reg[3]_i_67_n_4 ,\derivative_reg[3]_i_67_n_5 ,\derivative_reg[3]_i_67_n_6 ,\derivative_reg[3]_i_67_n_7 }),
        .S({\derivative[3]_i_88_n_0 ,\derivative[3]_i_89_n_0 ,\derivative[3]_i_90_n_0 ,\derivative[3]_i_91_n_0 }));
  CARRY4 \derivative_reg[3]_i_7 
       (.CI(\derivative_reg[3]_i_11_n_0 ),
        .CO({\NLW_derivative_reg[3]_i_7_CO_UNCONNECTED [3:2],derivative1[3],\derivative_reg[3]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[4],\derivative_reg[7]_i_19_n_4 }),
        .O({\NLW_derivative_reg[3]_i_7_O_UNCONNECTED [3:1],\derivative_reg[3]_i_7_n_7 }),
        .S({1'b0,1'b0,\derivative[3]_i_12_n_0 ,\derivative[3]_i_13_n_0 }));
  CARRY4 \derivative_reg[3]_i_72 
       (.CI(\derivative_reg[3]_i_92_n_0 ),
        .CO({\derivative_reg[3]_i_72_n_0 ,\derivative_reg[3]_i_72_n_1 ,\derivative_reg[3]_i_72_n_2 ,\derivative_reg[3]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_67_n_5 ,\derivative_reg[3]_i_67_n_6 ,\derivative_reg[3]_i_67_n_7 ,\derivative_reg[3]_i_87_n_4 }),
        .O({\derivative_reg[3]_i_72_n_4 ,\derivative_reg[3]_i_72_n_5 ,\derivative_reg[3]_i_72_n_6 ,\derivative_reg[3]_i_72_n_7 }),
        .S({\derivative[3]_i_93_n_0 ,\derivative[3]_i_94_n_0 ,\derivative[3]_i_95_n_0 ,\derivative[3]_i_96_n_0 }));
  CARRY4 \derivative_reg[3]_i_77 
       (.CI(\derivative_reg[3]_i_97_n_0 ),
        .CO({\derivative_reg[3]_i_77_n_0 ,\derivative_reg[3]_i_77_n_1 ,\derivative_reg[3]_i_77_n_2 ,\derivative_reg[3]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_72_n_4 ,\derivative_reg[3]_i_72_n_5 ,\derivative_reg[3]_i_72_n_6 ,\derivative_reg[3]_i_72_n_7 }),
        .O(\NLW_derivative_reg[3]_i_77_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_98_n_0 ,\derivative[3]_i_99_n_0 ,\derivative[3]_i_100_n_0 ,\derivative[3]_i_101_n_0 }));
  CARRY4 \derivative_reg[3]_i_8 
       (.CI(\derivative_reg[3]_i_14_n_0 ),
        .CO({\NLW_derivative_reg[3]_i_8_CO_UNCONNECTED [3:2],derivative1[2],\derivative_reg[3]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[3],\derivative_reg[3]_i_11_n_4 }),
        .O({\NLW_derivative_reg[3]_i_8_O_UNCONNECTED [3:1],\derivative_reg[3]_i_8_n_7 }),
        .S({1'b0,1'b0,\derivative[3]_i_15_n_0 ,\derivative[3]_i_16_n_0 }));
  CARRY4 \derivative_reg[3]_i_82 
       (.CI(\derivative_reg[3]_i_102_n_0 ),
        .CO({\derivative_reg[3]_i_82_n_0 ,\derivative_reg[3]_i_82_n_1 ,\derivative_reg[3]_i_82_n_2 ,\derivative_reg[3]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_97_n_5 ,\derivative_reg[7]_i_97_n_6 ,\derivative_reg[7]_i_97_n_7 ,\derivative_reg[7]_i_117_n_4 }),
        .O({\derivative_reg[3]_i_82_n_4 ,\derivative_reg[3]_i_82_n_5 ,\derivative_reg[3]_i_82_n_6 ,\derivative_reg[3]_i_82_n_7 }),
        .S({\derivative[3]_i_103_n_0 ,\derivative[3]_i_104_n_0 ,\derivative[3]_i_105_n_0 ,\derivative[3]_i_106_n_0 }));
  CARRY4 \derivative_reg[3]_i_87 
       (.CI(\derivative_reg[3]_i_107_n_0 ),
        .CO({\derivative_reg[3]_i_87_n_0 ,\derivative_reg[3]_i_87_n_1 ,\derivative_reg[3]_i_87_n_2 ,\derivative_reg[3]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_82_n_5 ,\derivative_reg[3]_i_82_n_6 ,\derivative_reg[3]_i_82_n_7 ,\derivative_reg[3]_i_102_n_4 }),
        .O({\derivative_reg[3]_i_87_n_4 ,\derivative_reg[3]_i_87_n_5 ,\derivative_reg[3]_i_87_n_6 ,\derivative_reg[3]_i_87_n_7 }),
        .S({\derivative[3]_i_108_n_0 ,\derivative[3]_i_109_n_0 ,\derivative[3]_i_110_n_0 ,\derivative[3]_i_111_n_0 }));
  CARRY4 \derivative_reg[3]_i_9 
       (.CI(\derivative_reg[3]_i_17_n_0 ),
        .CO({\NLW_derivative_reg[3]_i_9_CO_UNCONNECTED [3:2],derivative1[1],\derivative_reg[3]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[2],\derivative_reg[3]_i_14_n_4 }),
        .O({\NLW_derivative_reg[3]_i_9_O_UNCONNECTED [3:1],\derivative_reg[3]_i_9_n_7 }),
        .S({1'b0,1'b0,\derivative[3]_i_18_n_0 ,\derivative[3]_i_19_n_0 }));
  CARRY4 \derivative_reg[3]_i_92 
       (.CI(\derivative_reg[3]_i_112_n_0 ),
        .CO({\derivative_reg[3]_i_92_n_0 ,\derivative_reg[3]_i_92_n_1 ,\derivative_reg[3]_i_92_n_2 ,\derivative_reg[3]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_87_n_5 ,\derivative_reg[3]_i_87_n_6 ,\derivative_reg[3]_i_87_n_7 ,\derivative_reg[3]_i_107_n_4 }),
        .O({\derivative_reg[3]_i_92_n_4 ,\derivative_reg[3]_i_92_n_5 ,\derivative_reg[3]_i_92_n_6 ,\derivative_reg[3]_i_92_n_7 }),
        .S({\derivative[3]_i_113_n_0 ,\derivative[3]_i_114_n_0 ,\derivative[3]_i_115_n_0 ,\derivative[3]_i_116_n_0 }));
  CARRY4 \derivative_reg[3]_i_97 
       (.CI(\derivative_reg[3]_i_117_n_0 ),
        .CO({\derivative_reg[3]_i_97_n_0 ,\derivative_reg[3]_i_97_n_1 ,\derivative_reg[3]_i_97_n_2 ,\derivative_reg[3]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[3]_i_92_n_4 ,\derivative_reg[3]_i_92_n_5 ,\derivative_reg[3]_i_92_n_6 ,\derivative_reg[3]_i_92_n_7 }),
        .O(\NLW_derivative_reg[3]_i_97_O_UNCONNECTED [3:0]),
        .S({\derivative[3]_i_118_n_0 ,\derivative[3]_i_119_n_0 ,\derivative[3]_i_120_n_0 ,\derivative[3]_i_121_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[4] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[7]_i_1_n_7 ),
        .Q(derivative_out[4]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[5] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[7]_i_1_n_6 ),
        .Q(derivative_out[5]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[6] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[7]_i_1_n_5 ),
        .Q(derivative_out[6]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[7] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[7]_i_1_n_4 ),
        .Q(derivative_out[7]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[7]_i_1 
       (.CI(\derivative_reg[3]_i_1_n_0 ),
        .CO({\derivative_reg[7]_i_1_n_0 ,\derivative_reg[7]_i_1_n_1 ,\derivative_reg[7]_i_1_n_2 ,\derivative_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[7]_i_1_n_4 ,\derivative_reg[7]_i_1_n_5 ,\derivative_reg[7]_i_1_n_6 ,\derivative_reg[7]_i_1_n_7 }),
        .S({\derivative[7]_i_2_n_0 ,\derivative[7]_i_3_n_0 ,\derivative[7]_i_4_n_0 ,\derivative[7]_i_5_n_0 }));
  CARRY4 \derivative_reg[7]_i_10 
       (.CI(\derivative_reg[7]_i_22_n_0 ),
        .CO({\derivative_reg[7]_i_10_n_0 ,\derivative_reg[7]_i_10_n_1 ,\derivative_reg[7]_i_10_n_2 ,\derivative_reg[7]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_19_n_5 ,\derivative_reg[11]_i_19_n_6 ,\derivative_reg[11]_i_19_n_7 ,\derivative_reg[11]_i_37_n_4 }),
        .O({\derivative_reg[7]_i_10_n_4 ,\derivative_reg[7]_i_10_n_5 ,\derivative_reg[7]_i_10_n_6 ,\derivative_reg[7]_i_10_n_7 }),
        .S({\derivative[7]_i_23_n_0 ,\derivative[7]_i_24_n_0 ,\derivative[7]_i_25_n_0 ,\derivative[7]_i_26_n_0 }));
  CARRY4 \derivative_reg[7]_i_102 
       (.CI(\derivative_reg[7]_i_122_n_0 ),
        .CO({\derivative_reg[7]_i_102_n_0 ,\derivative_reg[7]_i_102_n_1 ,\derivative_reg[7]_i_102_n_2 ,\derivative_reg[7]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_117_n_5 ,\derivative_reg[11]_i_117_n_6 ,\derivative_reg[11]_i_117_n_7 ,\derivative_reg[11]_i_137_n_4 }),
        .O({\derivative_reg[7]_i_102_n_4 ,\derivative_reg[7]_i_102_n_5 ,\derivative_reg[7]_i_102_n_6 ,\derivative_reg[7]_i_102_n_7 }),
        .S({\derivative[7]_i_123_n_0 ,\derivative[7]_i_124_n_0 ,\derivative[7]_i_125_n_0 ,\derivative[7]_i_126_n_0 }));
  CARRY4 \derivative_reg[7]_i_107 
       (.CI(\derivative_reg[7]_i_127_n_0 ),
        .CO({\derivative_reg[7]_i_107_n_0 ,\derivative_reg[7]_i_107_n_1 ,\derivative_reg[7]_i_107_n_2 ,\derivative_reg[7]_i_107_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_102_n_5 ,\derivative_reg[7]_i_102_n_6 ,\derivative_reg[7]_i_102_n_7 ,\derivative_reg[7]_i_122_n_4 }),
        .O({\derivative_reg[7]_i_107_n_4 ,\derivative_reg[7]_i_107_n_5 ,\derivative_reg[7]_i_107_n_6 ,\derivative_reg[7]_i_107_n_7 }),
        .S({\derivative[7]_i_128_n_0 ,\derivative[7]_i_129_n_0 ,\derivative[7]_i_130_n_0 ,\derivative[7]_i_131_n_0 }));
  CARRY4 \derivative_reg[7]_i_112 
       (.CI(\derivative_reg[7]_i_132_n_0 ),
        .CO({\derivative_reg[7]_i_112_n_0 ,\derivative_reg[7]_i_112_n_1 ,\derivative_reg[7]_i_112_n_2 ,\derivative_reg[7]_i_112_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_107_n_5 ,\derivative_reg[7]_i_107_n_6 ,\derivative_reg[7]_i_107_n_7 ,\derivative_reg[7]_i_127_n_4 }),
        .O({\derivative_reg[7]_i_112_n_4 ,\derivative_reg[7]_i_112_n_5 ,\derivative_reg[7]_i_112_n_6 ,\derivative_reg[7]_i_112_n_7 }),
        .S({\derivative[7]_i_133_n_0 ,\derivative[7]_i_134_n_0 ,\derivative[7]_i_135_n_0 ,\derivative[7]_i_136_n_0 }));
  CARRY4 \derivative_reg[7]_i_117 
       (.CI(\derivative_reg[7]_i_137_n_0 ),
        .CO({\derivative_reg[7]_i_117_n_0 ,\derivative_reg[7]_i_117_n_1 ,\derivative_reg[7]_i_117_n_2 ,\derivative_reg[7]_i_117_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_112_n_5 ,\derivative_reg[7]_i_112_n_6 ,\derivative_reg[7]_i_112_n_7 ,\derivative_reg[7]_i_132_n_4 }),
        .O({\derivative_reg[7]_i_117_n_4 ,\derivative_reg[7]_i_117_n_5 ,\derivative_reg[7]_i_117_n_6 ,\derivative_reg[7]_i_117_n_7 }),
        .S({\derivative[7]_i_138_n_0 ,\derivative[7]_i_139_n_0 ,\derivative[7]_i_140_n_0 ,\derivative[7]_i_141_n_0 }));
  CARRY4 \derivative_reg[7]_i_122 
       (.CI(\derivative_reg[7]_i_142_n_0 ),
        .CO({\derivative_reg[7]_i_122_n_0 ,\derivative_reg[7]_i_122_n_1 ,\derivative_reg[7]_i_122_n_2 ,\derivative_reg[7]_i_122_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_137_n_5 ,\derivative_reg[11]_i_137_n_6 ,\derivative_reg[11]_i_137_n_7 ,\derivative_reg[11]_i_157_n_4 }),
        .O({\derivative_reg[7]_i_122_n_4 ,\derivative_reg[7]_i_122_n_5 ,\derivative_reg[7]_i_122_n_6 ,\derivative_reg[7]_i_122_n_7 }),
        .S({\derivative[7]_i_143_n_0 ,\derivative[7]_i_144_n_0 ,\derivative[7]_i_145_n_0 ,\derivative[7]_i_146_n_0 }));
  CARRY4 \derivative_reg[7]_i_127 
       (.CI(\derivative_reg[7]_i_147_n_0 ),
        .CO({\derivative_reg[7]_i_127_n_0 ,\derivative_reg[7]_i_127_n_1 ,\derivative_reg[7]_i_127_n_2 ,\derivative_reg[7]_i_127_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_122_n_5 ,\derivative_reg[7]_i_122_n_6 ,\derivative_reg[7]_i_122_n_7 ,\derivative_reg[7]_i_142_n_4 }),
        .O({\derivative_reg[7]_i_127_n_4 ,\derivative_reg[7]_i_127_n_5 ,\derivative_reg[7]_i_127_n_6 ,\derivative_reg[7]_i_127_n_7 }),
        .S({\derivative[7]_i_148_n_0 ,\derivative[7]_i_149_n_0 ,\derivative[7]_i_150_n_0 ,\derivative[7]_i_151_n_0 }));
  CARRY4 \derivative_reg[7]_i_13 
       (.CI(\derivative_reg[7]_i_27_n_0 ),
        .CO({\derivative_reg[7]_i_13_n_0 ,\derivative_reg[7]_i_13_n_1 ,\derivative_reg[7]_i_13_n_2 ,\derivative_reg[7]_i_13_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_10_n_5 ,\derivative_reg[7]_i_10_n_6 ,\derivative_reg[7]_i_10_n_7 ,\derivative_reg[7]_i_22_n_4 }),
        .O({\derivative_reg[7]_i_13_n_4 ,\derivative_reg[7]_i_13_n_5 ,\derivative_reg[7]_i_13_n_6 ,\derivative_reg[7]_i_13_n_7 }),
        .S({\derivative[7]_i_28_n_0 ,\derivative[7]_i_29_n_0 ,\derivative[7]_i_30_n_0 ,\derivative[7]_i_31_n_0 }));
  CARRY4 \derivative_reg[7]_i_132 
       (.CI(\derivative_reg[7]_i_152_n_0 ),
        .CO({\derivative_reg[7]_i_132_n_0 ,\derivative_reg[7]_i_132_n_1 ,\derivative_reg[7]_i_132_n_2 ,\derivative_reg[7]_i_132_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_127_n_5 ,\derivative_reg[7]_i_127_n_6 ,\derivative_reg[7]_i_127_n_7 ,\derivative_reg[7]_i_147_n_4 }),
        .O({\derivative_reg[7]_i_132_n_4 ,\derivative_reg[7]_i_132_n_5 ,\derivative_reg[7]_i_132_n_6 ,\derivative_reg[7]_i_132_n_7 }),
        .S({\derivative[7]_i_153_n_0 ,\derivative[7]_i_154_n_0 ,\derivative[7]_i_155_n_0 ,\derivative[7]_i_156_n_0 }));
  CARRY4 \derivative_reg[7]_i_137 
       (.CI(\derivative_reg[7]_i_157_n_0 ),
        .CO({\derivative_reg[7]_i_137_n_0 ,\derivative_reg[7]_i_137_n_1 ,\derivative_reg[7]_i_137_n_2 ,\derivative_reg[7]_i_137_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_132_n_5 ,\derivative_reg[7]_i_132_n_6 ,\derivative_reg[7]_i_132_n_7 ,\derivative_reg[7]_i_152_n_4 }),
        .O({\derivative_reg[7]_i_137_n_4 ,\derivative_reg[7]_i_137_n_5 ,\derivative_reg[7]_i_137_n_6 ,\derivative_reg[7]_i_137_n_7 }),
        .S({\derivative[7]_i_158_n_0 ,\derivative[7]_i_159_n_0 ,\derivative[7]_i_160_n_0 ,\derivative[7]_i_161_n_0 }));
  CARRY4 \derivative_reg[7]_i_142 
       (.CI(1'b0),
        .CO({\derivative_reg[7]_i_142_n_0 ,\derivative_reg[7]_i_142_n_1 ,\derivative_reg[7]_i_142_n_2 ,\derivative_reg[7]_i_142_n_3 }),
        .CYINIT(derivative1[8]),
        .DI({\derivative_reg[11]_i_157_n_5 ,\derivative_reg[11]_i_157_n_6 ,derivative20_in[7],1'b0}),
        .O({\derivative_reg[7]_i_142_n_4 ,\derivative_reg[7]_i_142_n_5 ,\derivative_reg[7]_i_142_n_6 ,\NLW_derivative_reg[7]_i_142_O_UNCONNECTED [0]}),
        .S({\derivative[7]_i_163_n_0 ,\derivative[7]_i_164_n_0 ,\derivative[7]_i_165_n_0 ,1'b1}));
  CARRY4 \derivative_reg[7]_i_147 
       (.CI(1'b0),
        .CO({\derivative_reg[7]_i_147_n_0 ,\derivative_reg[7]_i_147_n_1 ,\derivative_reg[7]_i_147_n_2 ,\derivative_reg[7]_i_147_n_3 }),
        .CYINIT(derivative1[7]),
        .DI({\derivative_reg[7]_i_142_n_5 ,\derivative_reg[7]_i_142_n_6 ,derivative20_in[6],1'b0}),
        .O({\derivative_reg[7]_i_147_n_4 ,\derivative_reg[7]_i_147_n_5 ,\derivative_reg[7]_i_147_n_6 ,\NLW_derivative_reg[7]_i_147_O_UNCONNECTED [0]}),
        .S({\derivative[7]_i_167_n_0 ,\derivative[7]_i_168_n_0 ,\derivative[7]_i_169_n_0 ,1'b1}));
  CARRY4 \derivative_reg[7]_i_152 
       (.CI(1'b0),
        .CO({\derivative_reg[7]_i_152_n_0 ,\derivative_reg[7]_i_152_n_1 ,\derivative_reg[7]_i_152_n_2 ,\derivative_reg[7]_i_152_n_3 }),
        .CYINIT(derivative1[6]),
        .DI({\derivative_reg[7]_i_147_n_5 ,\derivative_reg[7]_i_147_n_6 ,derivative20_in[5],1'b0}),
        .O({\derivative_reg[7]_i_152_n_4 ,\derivative_reg[7]_i_152_n_5 ,\derivative_reg[7]_i_152_n_6 ,\NLW_derivative_reg[7]_i_152_O_UNCONNECTED [0]}),
        .S({\derivative[7]_i_171_n_0 ,\derivative[7]_i_172_n_0 ,\derivative[7]_i_173_n_0 ,1'b1}));
  CARRY4 \derivative_reg[7]_i_157 
       (.CI(1'b0),
        .CO({\derivative_reg[7]_i_157_n_0 ,\derivative_reg[7]_i_157_n_1 ,\derivative_reg[7]_i_157_n_2 ,\derivative_reg[7]_i_157_n_3 }),
        .CYINIT(derivative1[5]),
        .DI({\derivative_reg[7]_i_152_n_5 ,\derivative_reg[7]_i_152_n_6 ,derivative20_in[4],1'b0}),
        .O({\derivative_reg[7]_i_157_n_4 ,\derivative_reg[7]_i_157_n_5 ,\derivative_reg[7]_i_157_n_6 ,\NLW_derivative_reg[7]_i_157_O_UNCONNECTED [0]}),
        .S({\derivative[7]_i_175_n_0 ,\derivative[7]_i_176_n_0 ,\derivative[7]_i_177_n_0 ,1'b1}));
  CARRY4 \derivative_reg[7]_i_16 
       (.CI(\derivative_reg[7]_i_32_n_0 ),
        .CO({\derivative_reg[7]_i_16_n_0 ,\derivative_reg[7]_i_16_n_1 ,\derivative_reg[7]_i_16_n_2 ,\derivative_reg[7]_i_16_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_13_n_5 ,\derivative_reg[7]_i_13_n_6 ,\derivative_reg[7]_i_13_n_7 ,\derivative_reg[7]_i_27_n_4 }),
        .O({\derivative_reg[7]_i_16_n_4 ,\derivative_reg[7]_i_16_n_5 ,\derivative_reg[7]_i_16_n_6 ,\derivative_reg[7]_i_16_n_7 }),
        .S({\derivative[7]_i_33_n_0 ,\derivative[7]_i_34_n_0 ,\derivative[7]_i_35_n_0 ,\derivative[7]_i_36_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \derivative_reg[7]_i_178 
       (.CI(1'b0),
        .CO({\derivative_reg[7]_i_178_n_0 ,\derivative_reg[7]_i_178_n_1 ,\derivative_reg[7]_i_178_n_2 ,\derivative_reg[7]_i_178_n_3 }),
        .CYINIT(\derivative[7]_i_179_n_0 ),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\derivative_reg[7]_i_178_n_4 ,\derivative_reg[7]_i_178_n_5 ,\derivative_reg[7]_i_178_n_6 ,\derivative_reg[7]_i_178_n_7 }),
        .S({\derivative[7]_i_180_n_0 ,\derivative[7]_i_181_n_0 ,\derivative[7]_i_182_n_0 ,\derivative[7]_i_183_n_0 }));
  CARRY4 \derivative_reg[7]_i_19 
       (.CI(\derivative_reg[7]_i_37_n_0 ),
        .CO({\derivative_reg[7]_i_19_n_0 ,\derivative_reg[7]_i_19_n_1 ,\derivative_reg[7]_i_19_n_2 ,\derivative_reg[7]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_16_n_5 ,\derivative_reg[7]_i_16_n_6 ,\derivative_reg[7]_i_16_n_7 ,\derivative_reg[7]_i_32_n_4 }),
        .O({\derivative_reg[7]_i_19_n_4 ,\derivative_reg[7]_i_19_n_5 ,\derivative_reg[7]_i_19_n_6 ,\derivative_reg[7]_i_19_n_7 }),
        .S({\derivative[7]_i_38_n_0 ,\derivative[7]_i_39_n_0 ,\derivative[7]_i_40_n_0 ,\derivative[7]_i_41_n_0 }));
  CARRY4 \derivative_reg[7]_i_22 
       (.CI(\derivative_reg[7]_i_42_n_0 ),
        .CO({\derivative_reg[7]_i_22_n_0 ,\derivative_reg[7]_i_22_n_1 ,\derivative_reg[7]_i_22_n_2 ,\derivative_reg[7]_i_22_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_37_n_5 ,\derivative_reg[11]_i_37_n_6 ,\derivative_reg[11]_i_37_n_7 ,\derivative_reg[11]_i_57_n_4 }),
        .O({\derivative_reg[7]_i_22_n_4 ,\derivative_reg[7]_i_22_n_5 ,\derivative_reg[7]_i_22_n_6 ,\derivative_reg[7]_i_22_n_7 }),
        .S({\derivative[7]_i_43_n_0 ,\derivative[7]_i_44_n_0 ,\derivative[7]_i_45_n_0 ,\derivative[7]_i_46_n_0 }));
  CARRY4 \derivative_reg[7]_i_27 
       (.CI(\derivative_reg[7]_i_47_n_0 ),
        .CO({\derivative_reg[7]_i_27_n_0 ,\derivative_reg[7]_i_27_n_1 ,\derivative_reg[7]_i_27_n_2 ,\derivative_reg[7]_i_27_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_22_n_5 ,\derivative_reg[7]_i_22_n_6 ,\derivative_reg[7]_i_22_n_7 ,\derivative_reg[7]_i_42_n_4 }),
        .O({\derivative_reg[7]_i_27_n_4 ,\derivative_reg[7]_i_27_n_5 ,\derivative_reg[7]_i_27_n_6 ,\derivative_reg[7]_i_27_n_7 }),
        .S({\derivative[7]_i_48_n_0 ,\derivative[7]_i_49_n_0 ,\derivative[7]_i_50_n_0 ,\derivative[7]_i_51_n_0 }));
  CARRY4 \derivative_reg[7]_i_32 
       (.CI(\derivative_reg[7]_i_52_n_0 ),
        .CO({\derivative_reg[7]_i_32_n_0 ,\derivative_reg[7]_i_32_n_1 ,\derivative_reg[7]_i_32_n_2 ,\derivative_reg[7]_i_32_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_27_n_5 ,\derivative_reg[7]_i_27_n_6 ,\derivative_reg[7]_i_27_n_7 ,\derivative_reg[7]_i_47_n_4 }),
        .O({\derivative_reg[7]_i_32_n_4 ,\derivative_reg[7]_i_32_n_5 ,\derivative_reg[7]_i_32_n_6 ,\derivative_reg[7]_i_32_n_7 }),
        .S({\derivative[7]_i_53_n_0 ,\derivative[7]_i_54_n_0 ,\derivative[7]_i_55_n_0 ,\derivative[7]_i_56_n_0 }));
  CARRY4 \derivative_reg[7]_i_37 
       (.CI(\derivative_reg[7]_i_57_n_0 ),
        .CO({\derivative_reg[7]_i_37_n_0 ,\derivative_reg[7]_i_37_n_1 ,\derivative_reg[7]_i_37_n_2 ,\derivative_reg[7]_i_37_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_32_n_5 ,\derivative_reg[7]_i_32_n_6 ,\derivative_reg[7]_i_32_n_7 ,\derivative_reg[7]_i_52_n_4 }),
        .O({\derivative_reg[7]_i_37_n_4 ,\derivative_reg[7]_i_37_n_5 ,\derivative_reg[7]_i_37_n_6 ,\derivative_reg[7]_i_37_n_7 }),
        .S({\derivative[7]_i_58_n_0 ,\derivative[7]_i_59_n_0 ,\derivative[7]_i_60_n_0 ,\derivative[7]_i_61_n_0 }));
  CARRY4 \derivative_reg[7]_i_42 
       (.CI(\derivative_reg[7]_i_62_n_0 ),
        .CO({\derivative_reg[7]_i_42_n_0 ,\derivative_reg[7]_i_42_n_1 ,\derivative_reg[7]_i_42_n_2 ,\derivative_reg[7]_i_42_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_57_n_5 ,\derivative_reg[11]_i_57_n_6 ,\derivative_reg[11]_i_57_n_7 ,\derivative_reg[11]_i_77_n_4 }),
        .O({\derivative_reg[7]_i_42_n_4 ,\derivative_reg[7]_i_42_n_5 ,\derivative_reg[7]_i_42_n_6 ,\derivative_reg[7]_i_42_n_7 }),
        .S({\derivative[7]_i_63_n_0 ,\derivative[7]_i_64_n_0 ,\derivative[7]_i_65_n_0 ,\derivative[7]_i_66_n_0 }));
  CARRY4 \derivative_reg[7]_i_47 
       (.CI(\derivative_reg[7]_i_67_n_0 ),
        .CO({\derivative_reg[7]_i_47_n_0 ,\derivative_reg[7]_i_47_n_1 ,\derivative_reg[7]_i_47_n_2 ,\derivative_reg[7]_i_47_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_42_n_5 ,\derivative_reg[7]_i_42_n_6 ,\derivative_reg[7]_i_42_n_7 ,\derivative_reg[7]_i_62_n_4 }),
        .O({\derivative_reg[7]_i_47_n_4 ,\derivative_reg[7]_i_47_n_5 ,\derivative_reg[7]_i_47_n_6 ,\derivative_reg[7]_i_47_n_7 }),
        .S({\derivative[7]_i_68_n_0 ,\derivative[7]_i_69_n_0 ,\derivative[7]_i_70_n_0 ,\derivative[7]_i_71_n_0 }));
  CARRY4 \derivative_reg[7]_i_52 
       (.CI(\derivative_reg[7]_i_72_n_0 ),
        .CO({\derivative_reg[7]_i_52_n_0 ,\derivative_reg[7]_i_52_n_1 ,\derivative_reg[7]_i_52_n_2 ,\derivative_reg[7]_i_52_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_47_n_5 ,\derivative_reg[7]_i_47_n_6 ,\derivative_reg[7]_i_47_n_7 ,\derivative_reg[7]_i_67_n_4 }),
        .O({\derivative_reg[7]_i_52_n_4 ,\derivative_reg[7]_i_52_n_5 ,\derivative_reg[7]_i_52_n_6 ,\derivative_reg[7]_i_52_n_7 }),
        .S({\derivative[7]_i_73_n_0 ,\derivative[7]_i_74_n_0 ,\derivative[7]_i_75_n_0 ,\derivative[7]_i_76_n_0 }));
  CARRY4 \derivative_reg[7]_i_57 
       (.CI(\derivative_reg[7]_i_77_n_0 ),
        .CO({\derivative_reg[7]_i_57_n_0 ,\derivative_reg[7]_i_57_n_1 ,\derivative_reg[7]_i_57_n_2 ,\derivative_reg[7]_i_57_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_52_n_5 ,\derivative_reg[7]_i_52_n_6 ,\derivative_reg[7]_i_52_n_7 ,\derivative_reg[7]_i_72_n_4 }),
        .O({\derivative_reg[7]_i_57_n_4 ,\derivative_reg[7]_i_57_n_5 ,\derivative_reg[7]_i_57_n_6 ,\derivative_reg[7]_i_57_n_7 }),
        .S({\derivative[7]_i_78_n_0 ,\derivative[7]_i_79_n_0 ,\derivative[7]_i_80_n_0 ,\derivative[7]_i_81_n_0 }));
  CARRY4 \derivative_reg[7]_i_6 
       (.CI(\derivative_reg[7]_i_10_n_0 ),
        .CO({\NLW_derivative_reg[7]_i_6_CO_UNCONNECTED [3:2],derivative1[7],\derivative_reg[7]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[8],\derivative_reg[11]_i_19_n_4 }),
        .O({\NLW_derivative_reg[7]_i_6_O_UNCONNECTED [3:1],\derivative_reg[7]_i_6_n_7 }),
        .S({1'b0,1'b0,\derivative[7]_i_11_n_0 ,\derivative[7]_i_12_n_0 }));
  CARRY4 \derivative_reg[7]_i_62 
       (.CI(\derivative_reg[7]_i_82_n_0 ),
        .CO({\derivative_reg[7]_i_62_n_0 ,\derivative_reg[7]_i_62_n_1 ,\derivative_reg[7]_i_62_n_2 ,\derivative_reg[7]_i_62_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_77_n_5 ,\derivative_reg[11]_i_77_n_6 ,\derivative_reg[11]_i_77_n_7 ,\derivative_reg[11]_i_97_n_4 }),
        .O({\derivative_reg[7]_i_62_n_4 ,\derivative_reg[7]_i_62_n_5 ,\derivative_reg[7]_i_62_n_6 ,\derivative_reg[7]_i_62_n_7 }),
        .S({\derivative[7]_i_83_n_0 ,\derivative[7]_i_84_n_0 ,\derivative[7]_i_85_n_0 ,\derivative[7]_i_86_n_0 }));
  CARRY4 \derivative_reg[7]_i_67 
       (.CI(\derivative_reg[7]_i_87_n_0 ),
        .CO({\derivative_reg[7]_i_67_n_0 ,\derivative_reg[7]_i_67_n_1 ,\derivative_reg[7]_i_67_n_2 ,\derivative_reg[7]_i_67_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_62_n_5 ,\derivative_reg[7]_i_62_n_6 ,\derivative_reg[7]_i_62_n_7 ,\derivative_reg[7]_i_82_n_4 }),
        .O({\derivative_reg[7]_i_67_n_4 ,\derivative_reg[7]_i_67_n_5 ,\derivative_reg[7]_i_67_n_6 ,\derivative_reg[7]_i_67_n_7 }),
        .S({\derivative[7]_i_88_n_0 ,\derivative[7]_i_89_n_0 ,\derivative[7]_i_90_n_0 ,\derivative[7]_i_91_n_0 }));
  CARRY4 \derivative_reg[7]_i_7 
       (.CI(\derivative_reg[7]_i_13_n_0 ),
        .CO({\NLW_derivative_reg[7]_i_7_CO_UNCONNECTED [3:2],derivative1[6],\derivative_reg[7]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[7],\derivative_reg[7]_i_10_n_4 }),
        .O({\NLW_derivative_reg[7]_i_7_O_UNCONNECTED [3:1],\derivative_reg[7]_i_7_n_7 }),
        .S({1'b0,1'b0,\derivative[7]_i_14_n_0 ,\derivative[7]_i_15_n_0 }));
  CARRY4 \derivative_reg[7]_i_72 
       (.CI(\derivative_reg[7]_i_92_n_0 ),
        .CO({\derivative_reg[7]_i_72_n_0 ,\derivative_reg[7]_i_72_n_1 ,\derivative_reg[7]_i_72_n_2 ,\derivative_reg[7]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_67_n_5 ,\derivative_reg[7]_i_67_n_6 ,\derivative_reg[7]_i_67_n_7 ,\derivative_reg[7]_i_87_n_4 }),
        .O({\derivative_reg[7]_i_72_n_4 ,\derivative_reg[7]_i_72_n_5 ,\derivative_reg[7]_i_72_n_6 ,\derivative_reg[7]_i_72_n_7 }),
        .S({\derivative[7]_i_93_n_0 ,\derivative[7]_i_94_n_0 ,\derivative[7]_i_95_n_0 ,\derivative[7]_i_96_n_0 }));
  CARRY4 \derivative_reg[7]_i_77 
       (.CI(\derivative_reg[7]_i_97_n_0 ),
        .CO({\derivative_reg[7]_i_77_n_0 ,\derivative_reg[7]_i_77_n_1 ,\derivative_reg[7]_i_77_n_2 ,\derivative_reg[7]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_72_n_5 ,\derivative_reg[7]_i_72_n_6 ,\derivative_reg[7]_i_72_n_7 ,\derivative_reg[7]_i_92_n_4 }),
        .O({\derivative_reg[7]_i_77_n_4 ,\derivative_reg[7]_i_77_n_5 ,\derivative_reg[7]_i_77_n_6 ,\derivative_reg[7]_i_77_n_7 }),
        .S({\derivative[7]_i_98_n_0 ,\derivative[7]_i_99_n_0 ,\derivative[7]_i_100_n_0 ,\derivative[7]_i_101_n_0 }));
  CARRY4 \derivative_reg[7]_i_8 
       (.CI(\derivative_reg[7]_i_16_n_0 ),
        .CO({\NLW_derivative_reg[7]_i_8_CO_UNCONNECTED [3:2],derivative1[5],\derivative_reg[7]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[6],\derivative_reg[7]_i_13_n_4 }),
        .O({\NLW_derivative_reg[7]_i_8_O_UNCONNECTED [3:1],\derivative_reg[7]_i_8_n_7 }),
        .S({1'b0,1'b0,\derivative[7]_i_17_n_0 ,\derivative[7]_i_18_n_0 }));
  CARRY4 \derivative_reg[7]_i_82 
       (.CI(\derivative_reg[7]_i_102_n_0 ),
        .CO({\derivative_reg[7]_i_82_n_0 ,\derivative_reg[7]_i_82_n_1 ,\derivative_reg[7]_i_82_n_2 ,\derivative_reg[7]_i_82_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[11]_i_97_n_5 ,\derivative_reg[11]_i_97_n_6 ,\derivative_reg[11]_i_97_n_7 ,\derivative_reg[11]_i_117_n_4 }),
        .O({\derivative_reg[7]_i_82_n_4 ,\derivative_reg[7]_i_82_n_5 ,\derivative_reg[7]_i_82_n_6 ,\derivative_reg[7]_i_82_n_7 }),
        .S({\derivative[7]_i_103_n_0 ,\derivative[7]_i_104_n_0 ,\derivative[7]_i_105_n_0 ,\derivative[7]_i_106_n_0 }));
  CARRY4 \derivative_reg[7]_i_87 
       (.CI(\derivative_reg[7]_i_107_n_0 ),
        .CO({\derivative_reg[7]_i_87_n_0 ,\derivative_reg[7]_i_87_n_1 ,\derivative_reg[7]_i_87_n_2 ,\derivative_reg[7]_i_87_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_82_n_5 ,\derivative_reg[7]_i_82_n_6 ,\derivative_reg[7]_i_82_n_7 ,\derivative_reg[7]_i_102_n_4 }),
        .O({\derivative_reg[7]_i_87_n_4 ,\derivative_reg[7]_i_87_n_5 ,\derivative_reg[7]_i_87_n_6 ,\derivative_reg[7]_i_87_n_7 }),
        .S({\derivative[7]_i_108_n_0 ,\derivative[7]_i_109_n_0 ,\derivative[7]_i_110_n_0 ,\derivative[7]_i_111_n_0 }));
  CARRY4 \derivative_reg[7]_i_9 
       (.CI(\derivative_reg[7]_i_19_n_0 ),
        .CO({\NLW_derivative_reg[7]_i_9_CO_UNCONNECTED [3:2],derivative1[4],\derivative_reg[7]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,derivative1[5],\derivative_reg[7]_i_16_n_4 }),
        .O({\NLW_derivative_reg[7]_i_9_O_UNCONNECTED [3:1],\derivative_reg[7]_i_9_n_7 }),
        .S({1'b0,1'b0,\derivative[7]_i_20_n_0 ,\derivative[7]_i_21_n_0 }));
  CARRY4 \derivative_reg[7]_i_92 
       (.CI(\derivative_reg[7]_i_112_n_0 ),
        .CO({\derivative_reg[7]_i_92_n_0 ,\derivative_reg[7]_i_92_n_1 ,\derivative_reg[7]_i_92_n_2 ,\derivative_reg[7]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_87_n_5 ,\derivative_reg[7]_i_87_n_6 ,\derivative_reg[7]_i_87_n_7 ,\derivative_reg[7]_i_107_n_4 }),
        .O({\derivative_reg[7]_i_92_n_4 ,\derivative_reg[7]_i_92_n_5 ,\derivative_reg[7]_i_92_n_6 ,\derivative_reg[7]_i_92_n_7 }),
        .S({\derivative[7]_i_113_n_0 ,\derivative[7]_i_114_n_0 ,\derivative[7]_i_115_n_0 ,\derivative[7]_i_116_n_0 }));
  CARRY4 \derivative_reg[7]_i_97 
       (.CI(\derivative_reg[7]_i_117_n_0 ),
        .CO({\derivative_reg[7]_i_97_n_0 ,\derivative_reg[7]_i_97_n_1 ,\derivative_reg[7]_i_97_n_2 ,\derivative_reg[7]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\derivative_reg[7]_i_92_n_5 ,\derivative_reg[7]_i_92_n_6 ,\derivative_reg[7]_i_92_n_7 ,\derivative_reg[7]_i_112_n_4 }),
        .O({\derivative_reg[7]_i_97_n_4 ,\derivative_reg[7]_i_97_n_5 ,\derivative_reg[7]_i_97_n_6 ,\derivative_reg[7]_i_97_n_7 }),
        .S({\derivative[7]_i_118_n_0 ,\derivative[7]_i_119_n_0 ,\derivative[7]_i_120_n_0 ,\derivative[7]_i_121_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[8] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[11]_i_1_n_7 ),
        .Q(derivative_out[8]),
        .R(\derivative[31]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \derivative_reg[9] 
       (.C(clock),
        .CE(error),
        .D(\derivative_reg[11]_i_1_n_6 ),
        .Q(derivative_out[9]),
        .R(\derivative[31]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry
       (.CI(1'b0),
        .CO({dt0_carry_n_0,dt0_carry_n_1,dt0_carry_n_2,dt0_carry_n_3}),
        .CYINIT(1'b1),
        .DI(timestamp_new[3:0]),
        .O(dt00_in[3:0]),
        .S({dt0_carry_i_1_n_0,dt0_carry_i_2_n_0,dt0_carry_i_3_n_0,dt0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__0
       (.CI(dt0_carry_n_0),
        .CO({dt0_carry__0_n_0,dt0_carry__0_n_1,dt0_carry__0_n_2,dt0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(timestamp_new[7:4]),
        .O(dt00_in[7:4]),
        .S({dt0_carry__0_i_1_n_0,dt0_carry__0_i_2_n_0,dt0_carry__0_i_3_n_0,dt0_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_1
       (.I0(timestamp_new[7]),
        .I1(timestamp_in[7]),
        .O(dt0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_2
       (.I0(timestamp_new[6]),
        .I1(timestamp_in[6]),
        .O(dt0_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_3
       (.I0(timestamp_new[5]),
        .I1(timestamp_in[5]),
        .O(dt0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__0_i_4
       (.I0(timestamp_new[4]),
        .I1(timestamp_in[4]),
        .O(dt0_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__1
       (.CI(dt0_carry__0_n_0),
        .CO({dt0_carry__1_n_0,dt0_carry__1_n_1,dt0_carry__1_n_2,dt0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(timestamp_new[11:8]),
        .O(dt00_in[11:8]),
        .S({dt0_carry__1_i_1_n_0,dt0_carry__1_i_2_n_0,dt0_carry__1_i_3_n_0,dt0_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_1
       (.I0(timestamp_new[11]),
        .I1(timestamp_in[11]),
        .O(dt0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_2
       (.I0(timestamp_new[10]),
        .I1(timestamp_in[10]),
        .O(dt0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_3
       (.I0(timestamp_new[9]),
        .I1(timestamp_in[9]),
        .O(dt0_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__1_i_4
       (.I0(timestamp_new[8]),
        .I1(timestamp_in[8]),
        .O(dt0_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__2
       (.CI(dt0_carry__1_n_0),
        .CO({dt0_carry__2_n_0,dt0_carry__2_n_1,dt0_carry__2_n_2,dt0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(timestamp_new[15:12]),
        .O(dt00_in[15:12]),
        .S({dt0_carry__2_i_1_n_0,dt0_carry__2_i_2_n_0,dt0_carry__2_i_3_n_0,dt0_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_1
       (.I0(timestamp_new[15]),
        .I1(timestamp_in[15]),
        .O(dt0_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_2
       (.I0(timestamp_new[14]),
        .I1(timestamp_in[14]),
        .O(dt0_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_3
       (.I0(timestamp_new[13]),
        .I1(timestamp_in[13]),
        .O(dt0_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__2_i_4
       (.I0(timestamp_new[12]),
        .I1(timestamp_in[12]),
        .O(dt0_carry__2_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__3
       (.CI(dt0_carry__2_n_0),
        .CO({dt0_carry__3_n_0,dt0_carry__3_n_1,dt0_carry__3_n_2,dt0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(timestamp_new[19:16]),
        .O(dt00_in[19:16]),
        .S({dt0_carry__3_i_1_n_0,dt0_carry__3_i_2_n_0,dt0_carry__3_i_3_n_0,dt0_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_1
       (.I0(timestamp_new[19]),
        .I1(timestamp_in[19]),
        .O(dt0_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_2
       (.I0(timestamp_new[18]),
        .I1(timestamp_in[18]),
        .O(dt0_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_3
       (.I0(timestamp_new[17]),
        .I1(timestamp_in[17]),
        .O(dt0_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__3_i_4
       (.I0(timestamp_new[16]),
        .I1(timestamp_in[16]),
        .O(dt0_carry__3_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__4
       (.CI(dt0_carry__3_n_0),
        .CO({dt0_carry__4_n_0,dt0_carry__4_n_1,dt0_carry__4_n_2,dt0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(timestamp_new[23:20]),
        .O(dt00_in[23:20]),
        .S({dt0_carry__4_i_1_n_0,dt0_carry__4_i_2_n_0,dt0_carry__4_i_3_n_0,dt0_carry__4_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_1
       (.I0(timestamp_new[23]),
        .I1(timestamp_in[23]),
        .O(dt0_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_2
       (.I0(timestamp_new[22]),
        .I1(timestamp_in[22]),
        .O(dt0_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_3
       (.I0(timestamp_new[21]),
        .I1(timestamp_in[21]),
        .O(dt0_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__4_i_4
       (.I0(timestamp_new[20]),
        .I1(timestamp_in[20]),
        .O(dt0_carry__4_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__5
       (.CI(dt0_carry__4_n_0),
        .CO({dt0_carry__5_n_0,dt0_carry__5_n_1,dt0_carry__5_n_2,dt0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(timestamp_new[27:24]),
        .O(dt00_in[27:24]),
        .S({dt0_carry__5_i_1_n_0,dt0_carry__5_i_2_n_0,dt0_carry__5_i_3_n_0,dt0_carry__5_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_1
       (.I0(timestamp_new[27]),
        .I1(timestamp_in[27]),
        .O(dt0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_2
       (.I0(timestamp_new[26]),
        .I1(timestamp_in[26]),
        .O(dt0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_3
       (.I0(timestamp_new[25]),
        .I1(timestamp_in[25]),
        .O(dt0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__5_i_4
       (.I0(timestamp_new[24]),
        .I1(timestamp_in[24]),
        .O(dt0_carry__5_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 dt0_carry__6
       (.CI(dt0_carry__5_n_0),
        .CO({NLW_dt0_carry__6_CO_UNCONNECTED[3],dt0_carry__6_n_1,dt0_carry__6_n_2,dt0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,timestamp_new[30:28]}),
        .O(dt00_in[31:28]),
        .S({dt0_carry__6_i_1_n_0,dt0_carry__6_i_2_n_0,dt0_carry__6_i_3_n_0,dt0_carry__6_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_1
       (.I0(timestamp_in[31]),
        .I1(timestamp_new[31]),
        .O(dt0_carry__6_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_2
       (.I0(timestamp_new[30]),
        .I1(timestamp_in[30]),
        .O(dt0_carry__6_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_3
       (.I0(timestamp_new[29]),
        .I1(timestamp_in[29]),
        .O(dt0_carry__6_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry__6_i_4
       (.I0(timestamp_new[28]),
        .I1(timestamp_in[28]),
        .O(dt0_carry__6_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_1
       (.I0(timestamp_new[3]),
        .I1(timestamp_in[3]),
        .O(dt0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_2
       (.I0(timestamp_new[2]),
        .I1(timestamp_in[2]),
        .O(dt0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_3
       (.I0(timestamp_new[1]),
        .I1(timestamp_in[1]),
        .O(dt0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    dt0_carry_i_4
       (.I0(timestamp_new[0]),
        .I1(timestamp_in[0]),
        .O(dt0_carry_i_4_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 dt1_carry
       (.CI(1'b0),
        .CO({dt1_carry_n_0,dt1_carry_n_1,dt1_carry_n_2,dt1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({dt1_carry_i_1_n_0,dt1_carry_i_2_n_0,dt1_carry_i_3_n_0,dt1_carry_i_4_n_0}),
        .O(NLW_dt1_carry_O_UNCONNECTED[3:0]),
        .S({dt1_carry_i_5_n_0,dt1_carry_i_6_n_0,dt1_carry_i_7_n_0,dt1_carry_i_8_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 dt1_carry__0
       (.CI(dt1_carry_n_0),
        .CO({dt1_carry__0_n_0,dt1_carry__0_n_1,dt1_carry__0_n_2,dt1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({dt1_carry__0_i_1_n_0,dt1_carry__0_i_2_n_0,dt1_carry__0_i_3_n_0,dt1_carry__0_i_4_n_0}),
        .O(NLW_dt1_carry__0_O_UNCONNECTED[3:0]),
        .S({dt1_carry__0_i_5_n_0,dt1_carry__0_i_6_n_0,dt1_carry__0_i_7_n_0,dt1_carry__0_i_8_n_0}));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__0_i_1
       (.I0(timestamp_new[15]),
        .I1(timestamp_in[15]),
        .I2(timestamp_new[14]),
        .I3(timestamp_in[14]),
        .O(dt1_carry__0_i_1_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__0_i_2
       (.I0(timestamp_new[13]),
        .I1(timestamp_in[13]),
        .I2(timestamp_new[12]),
        .I3(timestamp_in[12]),
        .O(dt1_carry__0_i_2_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__0_i_3
       (.I0(timestamp_new[11]),
        .I1(timestamp_in[11]),
        .I2(timestamp_new[10]),
        .I3(timestamp_in[10]),
        .O(dt1_carry__0_i_3_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__0_i_4
       (.I0(timestamp_new[9]),
        .I1(timestamp_in[9]),
        .I2(timestamp_new[8]),
        .I3(timestamp_in[8]),
        .O(dt1_carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__0_i_5
       (.I0(timestamp_in[15]),
        .I1(timestamp_new[15]),
        .I2(timestamp_in[14]),
        .I3(timestamp_new[14]),
        .O(dt1_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__0_i_6
       (.I0(timestamp_in[13]),
        .I1(timestamp_new[13]),
        .I2(timestamp_in[12]),
        .I3(timestamp_new[12]),
        .O(dt1_carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__0_i_7
       (.I0(timestamp_in[11]),
        .I1(timestamp_new[11]),
        .I2(timestamp_in[10]),
        .I3(timestamp_new[10]),
        .O(dt1_carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__0_i_8
       (.I0(timestamp_in[9]),
        .I1(timestamp_new[9]),
        .I2(timestamp_in[8]),
        .I3(timestamp_new[8]),
        .O(dt1_carry__0_i_8_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 dt1_carry__1
       (.CI(dt1_carry__0_n_0),
        .CO({dt1_carry__1_n_0,dt1_carry__1_n_1,dt1_carry__1_n_2,dt1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({dt1_carry__1_i_1_n_0,dt1_carry__1_i_2_n_0,dt1_carry__1_i_3_n_0,dt1_carry__1_i_4_n_0}),
        .O(NLW_dt1_carry__1_O_UNCONNECTED[3:0]),
        .S({dt1_carry__1_i_5_n_0,dt1_carry__1_i_6_n_0,dt1_carry__1_i_7_n_0,dt1_carry__1_i_8_n_0}));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__1_i_1
       (.I0(timestamp_new[23]),
        .I1(timestamp_in[23]),
        .I2(timestamp_new[22]),
        .I3(timestamp_in[22]),
        .O(dt1_carry__1_i_1_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__1_i_2
       (.I0(timestamp_new[21]),
        .I1(timestamp_in[21]),
        .I2(timestamp_new[20]),
        .I3(timestamp_in[20]),
        .O(dt1_carry__1_i_2_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__1_i_3
       (.I0(timestamp_new[19]),
        .I1(timestamp_in[19]),
        .I2(timestamp_new[18]),
        .I3(timestamp_in[18]),
        .O(dt1_carry__1_i_3_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__1_i_4
       (.I0(timestamp_new[17]),
        .I1(timestamp_in[17]),
        .I2(timestamp_new[16]),
        .I3(timestamp_in[16]),
        .O(dt1_carry__1_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__1_i_5
       (.I0(timestamp_in[23]),
        .I1(timestamp_new[23]),
        .I2(timestamp_in[22]),
        .I3(timestamp_new[22]),
        .O(dt1_carry__1_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__1_i_6
       (.I0(timestamp_in[21]),
        .I1(timestamp_new[21]),
        .I2(timestamp_in[20]),
        .I3(timestamp_new[20]),
        .O(dt1_carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__1_i_7
       (.I0(timestamp_in[19]),
        .I1(timestamp_new[19]),
        .I2(timestamp_in[18]),
        .I3(timestamp_new[18]),
        .O(dt1_carry__1_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__1_i_8
       (.I0(timestamp_in[17]),
        .I1(timestamp_new[17]),
        .I2(timestamp_in[16]),
        .I3(timestamp_new[16]),
        .O(dt1_carry__1_i_8_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 dt1_carry__2
       (.CI(dt1_carry__1_n_0),
        .CO({dt1__15,dt1_carry__2_n_1,dt1_carry__2_n_2,dt1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({dt1_carry__2_i_1_n_0,dt1_carry__2_i_2_n_0,dt1_carry__2_i_3_n_0,dt1_carry__2_i_4_n_0}),
        .O(NLW_dt1_carry__2_O_UNCONNECTED[3:0]),
        .S({dt1_carry__2_i_5_n_0,dt1_carry__2_i_6_n_0,dt1_carry__2_i_7_n_0,dt1_carry__2_i_8_n_0}));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__2_i_1
       (.I0(timestamp_new[31]),
        .I1(timestamp_in[31]),
        .I2(timestamp_new[30]),
        .I3(timestamp_in[30]),
        .O(dt1_carry__2_i_1_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__2_i_2
       (.I0(timestamp_new[29]),
        .I1(timestamp_in[29]),
        .I2(timestamp_new[28]),
        .I3(timestamp_in[28]),
        .O(dt1_carry__2_i_2_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__2_i_3
       (.I0(timestamp_new[27]),
        .I1(timestamp_in[27]),
        .I2(timestamp_new[26]),
        .I3(timestamp_in[26]),
        .O(dt1_carry__2_i_3_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry__2_i_4
       (.I0(timestamp_new[25]),
        .I1(timestamp_in[25]),
        .I2(timestamp_new[24]),
        .I3(timestamp_in[24]),
        .O(dt1_carry__2_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__2_i_5
       (.I0(timestamp_in[31]),
        .I1(timestamp_new[31]),
        .I2(timestamp_in[30]),
        .I3(timestamp_new[30]),
        .O(dt1_carry__2_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__2_i_6
       (.I0(timestamp_in[29]),
        .I1(timestamp_new[29]),
        .I2(timestamp_in[28]),
        .I3(timestamp_new[28]),
        .O(dt1_carry__2_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__2_i_7
       (.I0(timestamp_in[27]),
        .I1(timestamp_new[27]),
        .I2(timestamp_in[26]),
        .I3(timestamp_new[26]),
        .O(dt1_carry__2_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry__2_i_8
       (.I0(timestamp_in[25]),
        .I1(timestamp_new[25]),
        .I2(timestamp_in[24]),
        .I3(timestamp_new[24]),
        .O(dt1_carry__2_i_8_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry_i_1
       (.I0(timestamp_new[7]),
        .I1(timestamp_in[7]),
        .I2(timestamp_new[6]),
        .I3(timestamp_in[6]),
        .O(dt1_carry_i_1_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry_i_2
       (.I0(timestamp_new[5]),
        .I1(timestamp_in[5]),
        .I2(timestamp_new[4]),
        .I3(timestamp_in[4]),
        .O(dt1_carry_i_2_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry_i_3
       (.I0(timestamp_new[3]),
        .I1(timestamp_in[3]),
        .I2(timestamp_new[2]),
        .I3(timestamp_in[2]),
        .O(dt1_carry_i_3_n_0));
  LUT4 #(
    .INIT(16'h22B2)) 
    dt1_carry_i_4
       (.I0(timestamp_new[1]),
        .I1(timestamp_in[1]),
        .I2(timestamp_new[0]),
        .I3(timestamp_in[0]),
        .O(dt1_carry_i_4_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry_i_5
       (.I0(timestamp_in[7]),
        .I1(timestamp_new[7]),
        .I2(timestamp_in[6]),
        .I3(timestamp_new[6]),
        .O(dt1_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry_i_6
       (.I0(timestamp_in[5]),
        .I1(timestamp_new[5]),
        .I2(timestamp_in[4]),
        .I3(timestamp_new[4]),
        .O(dt1_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry_i_7
       (.I0(timestamp_in[3]),
        .I1(timestamp_new[3]),
        .I2(timestamp_in[2]),
        .I3(timestamp_new[2]),
        .O(dt1_carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    dt1_carry_i_8
       (.I0(timestamp_in[1]),
        .I1(timestamp_new[1]),
        .I2(timestamp_in[0]),
        .I3(timestamp_new[0]),
        .O(dt1_carry_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry
       (.CI(1'b0),
        .CO({error0_carry_n_0,error0_carry_n_1,error0_carry_n_2,error0_carry_n_3}),
        .CYINIT(1'b1),
        .DI({\saved_target_angle_reg_n_0_[3] ,\saved_target_angle_reg_n_0_[2] ,\saved_target_angle_reg_n_0_[1] ,\saved_target_angle_reg_n_0_[0] }),
        .O(error0[3:0]),
        .S({error0_carry_i_1_n_0,error0_carry_i_2_n_0,error0_carry_i_3_n_0,error0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__0
       (.CI(error0_carry_n_0),
        .CO({error0_carry__0_n_0,error0_carry__0_n_1,error0_carry__0_n_2,error0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({\saved_target_angle_reg_n_0_[7] ,\saved_target_angle_reg_n_0_[6] ,\saved_target_angle_reg_n_0_[5] ,\saved_target_angle_reg_n_0_[4] }),
        .O(error0[7:4]),
        .S({error0_carry_i_1__0_n_0,error0_carry_i_2__0_n_0,error0_carry_i_3__0_n_0,error0_carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__1
       (.CI(error0_carry__0_n_0),
        .CO({error0_carry__1_n_0,error0_carry__1_n_1,error0_carry__1_n_2,error0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({\saved_target_angle_reg_n_0_[11] ,\saved_target_angle_reg_n_0_[10] ,\saved_target_angle_reg_n_0_[9] ,\saved_target_angle_reg_n_0_[8] }),
        .O(error0[11:8]),
        .S({error0_carry_i_1__1_n_0,error0_carry_i_2__1_n_0,error0_carry_i_3__1_n_0,error0_carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__2
       (.CI(error0_carry__1_n_0),
        .CO({error0_carry__2_n_0,error0_carry__2_n_1,error0_carry__2_n_2,error0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({\saved_target_angle_reg_n_0_[15] ,\saved_target_angle_reg_n_0_[14] ,\saved_target_angle_reg_n_0_[13] ,\saved_target_angle_reg_n_0_[12] }),
        .O(error0[15:12]),
        .S({error0_carry_i_1__2_n_0,error0_carry_i_2__2_n_0,error0_carry_i_3__2_n_0,error0_carry_i_4__2_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__3
       (.CI(error0_carry__2_n_0),
        .CO({error0_carry__3_n_0,error0_carry__3_n_1,error0_carry__3_n_2,error0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({\saved_target_angle_reg_n_0_[19] ,\saved_target_angle_reg_n_0_[18] ,\saved_target_angle_reg_n_0_[17] ,\saved_target_angle_reg_n_0_[16] }),
        .O(error0[19:16]),
        .S({error0_carry_i_1__3_n_0,error0_carry_i_2__3_n_0,error0_carry_i_3__3_n_0,error0_carry_i_4__3_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__4
       (.CI(error0_carry__3_n_0),
        .CO({error0_carry__4_n_0,error0_carry__4_n_1,error0_carry__4_n_2,error0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({\saved_target_angle_reg_n_0_[23] ,\saved_target_angle_reg_n_0_[22] ,\saved_target_angle_reg_n_0_[21] ,\saved_target_angle_reg_n_0_[20] }),
        .O(error0[23:20]),
        .S({error0_carry_i_1__4_n_0,error0_carry_i_2__4_n_0,error0_carry_i_3__4_n_0,error0_carry_i_4__4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__5
       (.CI(error0_carry__4_n_0),
        .CO({error0_carry__5_n_0,error0_carry__5_n_1,error0_carry__5_n_2,error0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({\saved_target_angle_reg_n_0_[27] ,\saved_target_angle_reg_n_0_[26] ,\saved_target_angle_reg_n_0_[25] ,\saved_target_angle_reg_n_0_[24] }),
        .O(error0[27:24]),
        .S({error0_carry_i_1__5_n_0,error0_carry_i_2__5_n_0,error0_carry_i_3__5_n_0,error0_carry_i_4__5_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 error0_carry__6
       (.CI(error0_carry__5_n_0),
        .CO({NLW_error0_carry__6_CO_UNCONNECTED[3],error0_carry__6_n_1,error0_carry__6_n_2,error0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,\saved_target_angle_reg_n_0_[30] ,\saved_target_angle_reg_n_0_[29] ,\saved_target_angle_reg_n_0_[28] }),
        .O(error0[31:28]),
        .S({error0_carry_i_1__6_n_0,error0_carry_i_2__6_n_0,error0_carry_i_3__6_n_0,error0_carry_i_4__6_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1
       (.I0(\saved_target_angle_reg_n_0_[3] ),
        .I1(angle[3]),
        .O(error0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__0
       (.I0(\saved_target_angle_reg_n_0_[7] ),
        .I1(angle[7]),
        .O(error0_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__1
       (.I0(\saved_target_angle_reg_n_0_[11] ),
        .I1(angle[11]),
        .O(error0_carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__2
       (.I0(\saved_target_angle_reg_n_0_[15] ),
        .I1(angle[15]),
        .O(error0_carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__3
       (.I0(\saved_target_angle_reg_n_0_[19] ),
        .I1(angle[19]),
        .O(error0_carry_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__4
       (.I0(\saved_target_angle_reg_n_0_[23] ),
        .I1(angle[23]),
        .O(error0_carry_i_1__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__5
       (.I0(\saved_target_angle_reg_n_0_[27] ),
        .I1(angle[27]),
        .O(error0_carry_i_1__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_1__6
       (.I0(\saved_target_angle_reg_n_0_[31] ),
        .I1(angle[31]),
        .O(error0_carry_i_1__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2
       (.I0(\saved_target_angle_reg_n_0_[2] ),
        .I1(angle[2]),
        .O(error0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__0
       (.I0(\saved_target_angle_reg_n_0_[6] ),
        .I1(angle[6]),
        .O(error0_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__1
       (.I0(\saved_target_angle_reg_n_0_[10] ),
        .I1(angle[10]),
        .O(error0_carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__2
       (.I0(\saved_target_angle_reg_n_0_[14] ),
        .I1(angle[14]),
        .O(error0_carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__3
       (.I0(\saved_target_angle_reg_n_0_[18] ),
        .I1(angle[18]),
        .O(error0_carry_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__4
       (.I0(\saved_target_angle_reg_n_0_[22] ),
        .I1(angle[22]),
        .O(error0_carry_i_2__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__5
       (.I0(\saved_target_angle_reg_n_0_[26] ),
        .I1(angle[26]),
        .O(error0_carry_i_2__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_2__6
       (.I0(\saved_target_angle_reg_n_0_[30] ),
        .I1(angle[30]),
        .O(error0_carry_i_2__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3
       (.I0(\saved_target_angle_reg_n_0_[1] ),
        .I1(angle[1]),
        .O(error0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__0
       (.I0(\saved_target_angle_reg_n_0_[5] ),
        .I1(angle[5]),
        .O(error0_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__1
       (.I0(\saved_target_angle_reg_n_0_[9] ),
        .I1(angle[9]),
        .O(error0_carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__2
       (.I0(\saved_target_angle_reg_n_0_[13] ),
        .I1(angle[13]),
        .O(error0_carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__3
       (.I0(\saved_target_angle_reg_n_0_[17] ),
        .I1(angle[17]),
        .O(error0_carry_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__4
       (.I0(\saved_target_angle_reg_n_0_[21] ),
        .I1(angle[21]),
        .O(error0_carry_i_3__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__5
       (.I0(\saved_target_angle_reg_n_0_[25] ),
        .I1(angle[25]),
        .O(error0_carry_i_3__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_3__6
       (.I0(\saved_target_angle_reg_n_0_[29] ),
        .I1(angle[29]),
        .O(error0_carry_i_3__6_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4
       (.I0(\saved_target_angle_reg_n_0_[0] ),
        .I1(angle[0]),
        .O(error0_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__0
       (.I0(\saved_target_angle_reg_n_0_[4] ),
        .I1(angle[4]),
        .O(error0_carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__1
       (.I0(\saved_target_angle_reg_n_0_[8] ),
        .I1(angle[8]),
        .O(error0_carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__2
       (.I0(\saved_target_angle_reg_n_0_[12] ),
        .I1(angle[12]),
        .O(error0_carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__3
       (.I0(\saved_target_angle_reg_n_0_[16] ),
        .I1(angle[16]),
        .O(error0_carry_i_4__3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__4
       (.I0(\saved_target_angle_reg_n_0_[20] ),
        .I1(angle[20]),
        .O(error0_carry_i_4__4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__5
       (.I0(\saved_target_angle_reg_n_0_[24] ),
        .I1(angle[24]),
        .O(error0_carry_i_4__5_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    error0_carry_i_4__6
       (.I0(\saved_target_angle_reg_n_0_[28] ),
        .I1(angle[28]),
        .O(error0_carry_i_4__6_n_0));
  LUT3 #(
    .INIT(8'h08)) 
    \error[31]_i_1 
       (.I0(ps_ready_out),
        .I1(clock_count_reg_n_0),
        .I2(new_target_angle_available),
        .O(error));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[0] 
       (.C(clock),
        .CE(error),
        .D(error0[0]),
        .Q(error_out[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[10] 
       (.C(clock),
        .CE(error),
        .D(error0[10]),
        .Q(error_out[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[11] 
       (.C(clock),
        .CE(error),
        .D(error0[11]),
        .Q(error_out[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[12] 
       (.C(clock),
        .CE(error),
        .D(error0[12]),
        .Q(error_out[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[13] 
       (.C(clock),
        .CE(error),
        .D(error0[13]),
        .Q(error_out[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[14] 
       (.C(clock),
        .CE(error),
        .D(error0[14]),
        .Q(error_out[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[15] 
       (.C(clock),
        .CE(error),
        .D(error0[15]),
        .Q(error_out[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[16] 
       (.C(clock),
        .CE(error),
        .D(error0[16]),
        .Q(error_out[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[17] 
       (.C(clock),
        .CE(error),
        .D(error0[17]),
        .Q(error_out[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[18] 
       (.C(clock),
        .CE(error),
        .D(error0[18]),
        .Q(error_out[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[19] 
       (.C(clock),
        .CE(error),
        .D(error0[19]),
        .Q(error_out[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[1] 
       (.C(clock),
        .CE(error),
        .D(error0[1]),
        .Q(error_out[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[20] 
       (.C(clock),
        .CE(error),
        .D(error0[20]),
        .Q(error_out[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[21] 
       (.C(clock),
        .CE(error),
        .D(error0[21]),
        .Q(error_out[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[22] 
       (.C(clock),
        .CE(error),
        .D(error0[22]),
        .Q(error_out[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[23] 
       (.C(clock),
        .CE(error),
        .D(error0[23]),
        .Q(error_out[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[24] 
       (.C(clock),
        .CE(error),
        .D(error0[24]),
        .Q(error_out[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[25] 
       (.C(clock),
        .CE(error),
        .D(error0[25]),
        .Q(error_out[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[26] 
       (.C(clock),
        .CE(error),
        .D(error0[26]),
        .Q(error_out[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[27] 
       (.C(clock),
        .CE(error),
        .D(error0[27]),
        .Q(error_out[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[28] 
       (.C(clock),
        .CE(error),
        .D(error0[28]),
        .Q(error_out[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[29] 
       (.C(clock),
        .CE(error),
        .D(error0[29]),
        .Q(error_out[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[2] 
       (.C(clock),
        .CE(error),
        .D(error0[2]),
        .Q(error_out[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[30] 
       (.C(clock),
        .CE(error),
        .D(error0[30]),
        .Q(error_out[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[31] 
       (.C(clock),
        .CE(error),
        .D(error0[31]),
        .Q(error_out[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[3] 
       (.C(clock),
        .CE(error),
        .D(error0[3]),
        .Q(error_out[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[4] 
       (.C(clock),
        .CE(error),
        .D(error0[4]),
        .Q(error_out[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[5] 
       (.C(clock),
        .CE(error),
        .D(error0[5]),
        .Q(error_out[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[6] 
       (.C(clock),
        .CE(error),
        .D(error0[6]),
        .Q(error_out[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[7] 
       (.C(clock),
        .CE(error),
        .D(error0[7]),
        .Q(error_out[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[8] 
       (.C(clock),
        .CE(error),
        .D(error0[8]),
        .Q(error_out[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \error_reg[9] 
       (.C(clock),
        .CE(error),
        .D(error0[9]),
        .Q(error_out[9]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry
       (.CI(1'b0),
        .CO({integral0_carry_n_0,integral0_carry_n_1,integral0_carry_n_2,integral0_carry_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[3:0]),
        .O({integral0_carry_n_4,integral0_carry_n_5,integral0_carry_n_6,integral0_carry_n_7}),
        .S({integral0_carry_i_1_n_0,integral0_carry_i_2_n_0,integral0_carry_i_3_n_0,integral0_carry_i_4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__0
       (.CI(integral0_carry_n_0),
        .CO({integral0_carry__0_n_0,integral0_carry__0_n_1,integral0_carry__0_n_2,integral0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[7:4]),
        .O({integral0_carry__0_n_4,integral0_carry__0_n_5,integral0_carry__0_n_6,integral0_carry__0_n_7}),
        .S({integral0_carry_i_1__0_n_0,integral0_carry_i_2__0_n_0,integral0_carry_i_3__0_n_0,integral0_carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__1
       (.CI(integral0_carry__0_n_0),
        .CO({integral0_carry__1_n_0,integral0_carry__1_n_1,integral0_carry__1_n_2,integral0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[11:8]),
        .O({integral0_carry__1_n_4,integral0_carry__1_n_5,integral0_carry__1_n_6,integral0_carry__1_n_7}),
        .S({integral0_carry_i_1__1_n_0,integral0_carry_i_2__1_n_0,integral0_carry_i_3__1_n_0,integral0_carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__2
       (.CI(integral0_carry__1_n_0),
        .CO({integral0_carry__2_n_0,integral0_carry__2_n_1,integral0_carry__2_n_2,integral0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[15:12]),
        .O({integral0_carry__2_n_4,integral0_carry__2_n_5,integral0_carry__2_n_6,integral0_carry__2_n_7}),
        .S({integral0_carry_i_1__2_n_0,integral0_carry_i_2__2_n_0,integral0_carry_i_3__2_n_0,integral0_carry_i_4__2_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__3
       (.CI(integral0_carry__2_n_0),
        .CO({integral0_carry__3_n_0,integral0_carry__3_n_1,integral0_carry__3_n_2,integral0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[19:16]),
        .O({integral0_carry__3_n_4,integral0_carry__3_n_5,integral0_carry__3_n_6,integral0_carry__3_n_7}),
        .S({integral0_carry_i_1__3_n_0,integral0_carry_i_2__3_n_0,integral0_carry_i_3__3_n_0,integral0_carry_i_4__3_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__4
       (.CI(integral0_carry__3_n_0),
        .CO({integral0_carry__4_n_0,integral0_carry__4_n_1,integral0_carry__4_n_2,integral0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[23:20]),
        .O({integral0_carry__4_n_4,integral0_carry__4_n_5,integral0_carry__4_n_6,integral0_carry__4_n_7}),
        .S({integral0_carry_i_1__4_n_0,integral0_carry_i_2__4_n_0,integral0_carry_i_3__4_n_0,integral0_carry_i_4__4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__5
       (.CI(integral0_carry__4_n_0),
        .CO({integral0_carry__5_n_0,integral0_carry__5_n_1,integral0_carry__5_n_2,integral0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(integral_in[27:24]),
        .O({integral0_carry__5_n_4,integral0_carry__5_n_5,integral0_carry__5_n_6,integral0_carry__5_n_7}),
        .S({integral0_carry_i_1__5_n_0,integral0_carry_i_2__5_n_0,integral0_carry_i_3__5_n_0,integral0_carry_i_4__5_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral0_carry__6
       (.CI(integral0_carry__5_n_0),
        .CO({NLW_integral0_carry__6_CO_UNCONNECTED[3],integral0_carry__6_n_1,integral0_carry__6_n_2,integral0_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,integral_in[30:28]}),
        .O({integral0_carry__6_n_4,integral0_carry__6_n_5,integral0_carry__6_n_6,integral0_carry__6_n_7}),
        .S({integral0_carry_i_1__6_n_0,integral0_carry_i_2__6_n_0,integral0_carry_i_3__6_n_0,integral0_carry_i_4__6_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1
       (.I0(integral_in[3]),
        .I1(integral1__0_n_102),
        .O(integral0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1__0
       (.I0(integral_in[7]),
        .I1(integral1__0_n_98),
        .O(integral0_carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1__1
       (.I0(integral_in[11]),
        .I1(integral1__0_n_94),
        .O(integral0_carry_i_1__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1__2
       (.I0(integral_in[15]),
        .I1(integral1__0_n_90),
        .O(integral0_carry_i_1__2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1__3
       (.I0(integral_in[19]),
        .I1(integral1_carry_n_4),
        .O(integral0_carry_i_1__3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1__4
       (.I0(integral_in[23]),
        .I1(integral1_carry__0_n_4),
        .O(integral0_carry_i_1__4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1__5
       (.I0(integral_in[27]),
        .I1(integral1_carry__1_n_4),
        .O(integral0_carry_i_1__5_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_1__6
       (.I0(integral_in[31]),
        .I1(integral1_carry__2_n_4),
        .O(integral0_carry_i_1__6_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2
       (.I0(integral_in[2]),
        .I1(integral1__0_n_103),
        .O(integral0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2__0
       (.I0(integral_in[6]),
        .I1(integral1__0_n_99),
        .O(integral0_carry_i_2__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2__1
       (.I0(integral_in[10]),
        .I1(integral1__0_n_95),
        .O(integral0_carry_i_2__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2__2
       (.I0(integral_in[14]),
        .I1(integral1__0_n_91),
        .O(integral0_carry_i_2__2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2__3
       (.I0(integral_in[18]),
        .I1(integral1_carry_n_5),
        .O(integral0_carry_i_2__3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2__4
       (.I0(integral_in[22]),
        .I1(integral1_carry__0_n_5),
        .O(integral0_carry_i_2__4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2__5
       (.I0(integral_in[26]),
        .I1(integral1_carry__1_n_5),
        .O(integral0_carry_i_2__5_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_2__6
       (.I0(integral_in[30]),
        .I1(integral1_carry__2_n_5),
        .O(integral0_carry_i_2__6_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3
       (.I0(integral_in[1]),
        .I1(integral1__0_n_104),
        .O(integral0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3__0
       (.I0(integral_in[5]),
        .I1(integral1__0_n_100),
        .O(integral0_carry_i_3__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3__1
       (.I0(integral_in[9]),
        .I1(integral1__0_n_96),
        .O(integral0_carry_i_3__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3__2
       (.I0(integral_in[13]),
        .I1(integral1__0_n_92),
        .O(integral0_carry_i_3__2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3__3
       (.I0(integral_in[17]),
        .I1(integral1_carry_n_6),
        .O(integral0_carry_i_3__3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3__4
       (.I0(integral_in[21]),
        .I1(integral1_carry__0_n_6),
        .O(integral0_carry_i_3__4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3__5
       (.I0(integral_in[25]),
        .I1(integral1_carry__1_n_6),
        .O(integral0_carry_i_3__5_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_3__6
       (.I0(integral_in[29]),
        .I1(integral1_carry__2_n_6),
        .O(integral0_carry_i_3__6_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4
       (.I0(integral_in[0]),
        .I1(integral1__0_n_105),
        .O(integral0_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4__0
       (.I0(integral_in[4]),
        .I1(integral1__0_n_101),
        .O(integral0_carry_i_4__0_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4__1
       (.I0(integral_in[8]),
        .I1(integral1__0_n_97),
        .O(integral0_carry_i_4__1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4__2
       (.I0(integral_in[12]),
        .I1(integral1__0_n_93),
        .O(integral0_carry_i_4__2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4__3
       (.I0(integral_in[16]),
        .I1(integral1_carry_n_7),
        .O(integral0_carry_i_4__3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4__4
       (.I0(integral_in[20]),
        .I1(integral1_carry__0_n_7),
        .O(integral0_carry_i_4__4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4__5
       (.I0(integral_in[24]),
        .I1(integral1_carry__1_n_7),
        .O(integral0_carry_i_4__5_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral0_carry_i_4__6
       (.I0(integral_in[28]),
        .I1(integral1_carry__2_n_7),
        .O(integral0_carry_i_4__6_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 15x18 4}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(1),
    .BREG(1),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    integral1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,sel0[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_integral1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({error0[31],error0[31],error0[31],error0[31:17]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_integral1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_integral1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_integral1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(error),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(clock),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_integral1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_integral1_OVERFLOW_UNCONNECTED),
        .P({integral1_n_58,integral1_n_59,integral1_n_60,integral1_n_61,integral1_n_62,integral1_n_63,integral1_n_64,integral1_n_65,integral1_n_66,integral1_n_67,integral1_n_68,integral1_n_69,integral1_n_70,integral1_n_71,integral1_n_72,integral1_n_73,integral1_n_74,integral1_n_75,integral1_n_76,integral1_n_77,integral1_n_78,integral1_n_79,integral1_n_80,integral1_n_81,integral1_n_82,integral1_n_83,integral1_n_84,integral1_n_85,integral1_n_86,integral1_n_87,integral1_n_88,integral1_n_89,integral1_n_90,integral1_n_91,integral1_n_92,integral1_n_93,integral1_n_94,integral1_n_95,integral1_n_96,integral1_n_97,integral1_n_98,integral1_n_99,integral1_n_100,integral1_n_101,integral1_n_102,integral1_n_103,integral1_n_104,integral1_n_105}),
        .PATTERNBDETECT(NLW_integral1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_integral1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({integral1_n_106,integral1_n_107,integral1_n_108,integral1_n_109,integral1_n_110,integral1_n_111,integral1_n_112,integral1_n_113,integral1_n_114,integral1_n_115,integral1_n_116,integral1_n_117,integral1_n_118,integral1_n_119,integral1_n_120,integral1_n_121,integral1_n_122,integral1_n_123,integral1_n_124,integral1_n_125,integral1_n_126,integral1_n_127,integral1_n_128,integral1_n_129,integral1_n_130,integral1_n_131,integral1_n_132,integral1_n_133,integral1_n_134,integral1_n_135,integral1_n_136,integral1_n_137,integral1_n_138,integral1_n_139,integral1_n_140,integral1_n_141,integral1_n_142,integral1_n_143,integral1_n_144,integral1_n_145,integral1_n_146,integral1_n_147,integral1_n_148,integral1_n_149,integral1_n_150,integral1_n_151,integral1_n_152,integral1_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_integral1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 18x18 4}}" *) 
  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    integral1__0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,error0[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_integral1__0_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,sel0[16:0]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_integral1__0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_integral1__0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_integral1__0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(error),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(clock),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_integral1__0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_integral1__0_OVERFLOW_UNCONNECTED),
        .P({integral1__0_n_58,integral1__0_n_59,integral1__0_n_60,integral1__0_n_61,integral1__0_n_62,integral1__0_n_63,integral1__0_n_64,integral1__0_n_65,integral1__0_n_66,integral1__0_n_67,integral1__0_n_68,integral1__0_n_69,integral1__0_n_70,integral1__0_n_71,integral1__0_n_72,integral1__0_n_73,integral1__0_n_74,integral1__0_n_75,integral1__0_n_76,integral1__0_n_77,integral1__0_n_78,integral1__0_n_79,integral1__0_n_80,integral1__0_n_81,integral1__0_n_82,integral1__0_n_83,integral1__0_n_84,integral1__0_n_85,integral1__0_n_86,integral1__0_n_87,integral1__0_n_88,integral1__0_n_89,integral1__0_n_90,integral1__0_n_91,integral1__0_n_92,integral1__0_n_93,integral1__0_n_94,integral1__0_n_95,integral1__0_n_96,integral1__0_n_97,integral1__0_n_98,integral1__0_n_99,integral1__0_n_100,integral1__0_n_101,integral1__0_n_102,integral1__0_n_103,integral1__0_n_104,integral1__0_n_105}),
        .PATTERNBDETECT(NLW_integral1__0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_integral1__0_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({integral1__0_n_106,integral1__0_n_107,integral1__0_n_108,integral1__0_n_109,integral1__0_n_110,integral1__0_n_111,integral1__0_n_112,integral1__0_n_113,integral1__0_n_114,integral1__0_n_115,integral1__0_n_116,integral1__0_n_117,integral1__0_n_118,integral1__0_n_119,integral1__0_n_120,integral1__0_n_121,integral1__0_n_122,integral1__0_n_123,integral1__0_n_124,integral1__0_n_125,integral1__0_n_126,integral1__0_n_127,integral1__0_n_128,integral1__0_n_129,integral1__0_n_130,integral1__0_n_131,integral1__0_n_132,integral1__0_n_133,integral1__0_n_134,integral1__0_n_135,integral1__0_n_136,integral1__0_n_137,integral1__0_n_138,integral1__0_n_139,integral1__0_n_140,integral1__0_n_141,integral1__0_n_142,integral1__0_n_143,integral1__0_n_144,integral1__0_n_145,integral1__0_n_146,integral1__0_n_147,integral1__0_n_148,integral1__0_n_149,integral1__0_n_150,integral1__0_n_151,integral1__0_n_152,integral1__0_n_153}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_integral1__0_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 18x15 4}}" *) 
  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    integral1__1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,error0[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_integral1__1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({sel0[31],sel0[31],sel0[31],sel0[31:17]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_integral1__1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_integral1__1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_integral1__1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(error),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(clock),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_integral1__1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_integral1__1_OVERFLOW_UNCONNECTED),
        .P({integral1__1_n_58,integral1__1_n_59,integral1__1_n_60,integral1__1_n_61,integral1__1_n_62,integral1__1_n_63,integral1__1_n_64,integral1__1_n_65,integral1__1_n_66,integral1__1_n_67,integral1__1_n_68,integral1__1_n_69,integral1__1_n_70,integral1__1_n_71,integral1__1_n_72,integral1__1_n_73,integral1__1_n_74,integral1__1_n_75,integral1__1_n_76,integral1__1_n_77,integral1__1_n_78,integral1__1_n_79,integral1__1_n_80,integral1__1_n_81,integral1__1_n_82,integral1__1_n_83,integral1__1_n_84,integral1__1_n_85,integral1__1_n_86,integral1__1_n_87,integral1__1_n_88,integral1__1_n_89,integral1__1_n_90,integral1__1_n_91,integral1__1_n_92,integral1__1_n_93,integral1__1_n_94,integral1__1_n_95,integral1__1_n_96,integral1__1_n_97,integral1__1_n_98,integral1__1_n_99,integral1__1_n_100,integral1__1_n_101,integral1__1_n_102,integral1__1_n_103,integral1__1_n_104,integral1__1_n_105}),
        .PATTERNBDETECT(NLW_integral1__1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_integral1__1_PATTERNDETECT_UNCONNECTED),
        .PCIN({integral1__0_n_106,integral1__0_n_107,integral1__0_n_108,integral1__0_n_109,integral1__0_n_110,integral1__0_n_111,integral1__0_n_112,integral1__0_n_113,integral1__0_n_114,integral1__0_n_115,integral1__0_n_116,integral1__0_n_117,integral1__0_n_118,integral1__0_n_119,integral1__0_n_120,integral1__0_n_121,integral1__0_n_122,integral1__0_n_123,integral1__0_n_124,integral1__0_n_125,integral1__0_n_126,integral1__0_n_127,integral1__0_n_128,integral1__0_n_129,integral1__0_n_130,integral1__0_n_131,integral1__0_n_132,integral1__0_n_133,integral1__0_n_134,integral1__0_n_135,integral1__0_n_136,integral1__0_n_137,integral1__0_n_138,integral1__0_n_139,integral1__0_n_140,integral1__0_n_141,integral1__0_n_142,integral1__0_n_143,integral1__0_n_144,integral1__0_n_145,integral1__0_n_146,integral1__0_n_147,integral1__0_n_148,integral1__0_n_149,integral1__0_n_150,integral1__0_n_151,integral1__0_n_152,integral1__0_n_153}),
        .PCOUT(NLW_integral1__1_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_integral1__1_UNDERFLOW_UNCONNECTED));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry
       (.CI(1'b0),
        .CO({integral1_carry_n_0,integral1_carry_n_1,integral1_carry_n_2,integral1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({integral1__1_n_103,integral1__1_n_104,integral1__1_n_105,1'b0}),
        .O({integral1_carry_n_4,integral1_carry_n_5,integral1_carry_n_6,integral1_carry_n_7}),
        .S({integral1_carry_i_1_n_0,integral1_carry_i_2_n_0,integral1_carry_i_3_n_0,integral1__0_n_89}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry__0
       (.CI(integral1_carry_n_0),
        .CO({integral1_carry__0_n_0,integral1_carry__0_n_1,integral1_carry__0_n_2,integral1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({integral1__1_n_99,integral1__1_n_100,integral1__1_n_101,integral1__1_n_102}),
        .O({integral1_carry__0_n_4,integral1_carry__0_n_5,integral1_carry__0_n_6,integral1_carry__0_n_7}),
        .S({integral1_carry__0_i_1_n_0,integral1_carry__0_i_2_n_0,integral1_carry__0_i_3_n_0,integral1_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_1
       (.I0(integral1__1_n_99),
        .I1(integral1_n_99),
        .O(integral1_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_2
       (.I0(integral1__1_n_100),
        .I1(integral1_n_100),
        .O(integral1_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_3
       (.I0(integral1__1_n_101),
        .I1(integral1_n_101),
        .O(integral1_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__0_i_4
       (.I0(integral1__1_n_102),
        .I1(integral1_n_102),
        .O(integral1_carry__0_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry__1
       (.CI(integral1_carry__0_n_0),
        .CO({integral1_carry__1_n_0,integral1_carry__1_n_1,integral1_carry__1_n_2,integral1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({integral1__1_n_95,integral1__1_n_96,integral1__1_n_97,integral1__1_n_98}),
        .O({integral1_carry__1_n_4,integral1_carry__1_n_5,integral1_carry__1_n_6,integral1_carry__1_n_7}),
        .S({integral1_carry__1_i_1_n_0,integral1_carry__1_i_2_n_0,integral1_carry__1_i_3_n_0,integral1_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_1
       (.I0(integral1__1_n_95),
        .I1(integral1_n_95),
        .O(integral1_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_2
       (.I0(integral1__1_n_96),
        .I1(integral1_n_96),
        .O(integral1_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_3
       (.I0(integral1__1_n_97),
        .I1(integral1_n_97),
        .O(integral1_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__1_i_4
       (.I0(integral1__1_n_98),
        .I1(integral1_n_98),
        .O(integral1_carry__1_i_4_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_carry__2
       (.CI(integral1_carry__1_n_0),
        .CO({NLW_integral1_carry__2_CO_UNCONNECTED[3],integral1_carry__2_n_1,integral1_carry__2_n_2,integral1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,integral1__1_n_92,integral1__1_n_93,integral1__1_n_94}),
        .O({integral1_carry__2_n_4,integral1_carry__2_n_5,integral1_carry__2_n_6,integral1_carry__2_n_7}),
        .S({integral1_carry__2_i_1_n_0,integral1_carry__2_i_2_n_0,integral1_carry__2_i_3_n_0,integral1_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_1
       (.I0(integral1__1_n_91),
        .I1(integral1_n_91),
        .O(integral1_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_2
       (.I0(integral1__1_n_92),
        .I1(integral1_n_92),
        .O(integral1_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_3
       (.I0(integral1__1_n_93),
        .I1(integral1_n_93),
        .O(integral1_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry__2_i_4
       (.I0(integral1__1_n_94),
        .I1(integral1_n_94),
        .O(integral1_carry__2_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry_i_1
       (.I0(integral1__1_n_103),
        .I1(integral1_n_103),
        .O(integral1_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry_i_2
       (.I0(integral1__1_n_104),
        .I1(integral1_n_104),
        .O(integral1_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    integral1_carry_i_3
       (.I0(integral1__1_n_105),
        .I1(integral1_n_105),
        .O(integral1_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_1
       (.I0(dt0__93[31]),
        .I1(dt1__15),
        .I2(dt00_in[31]),
        .O(sel0[31]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_10
       (.I0(dt0__93[22]),
        .I1(dt1__15),
        .I2(dt00_in[22]),
        .O(sel0[22]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_10__0
       (.I0(dt0__93[7]),
        .I1(dt1__15),
        .I2(dt00_in[7]),
        .O(sel0[7]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_11
       (.I0(dt0__93[21]),
        .I1(dt1__15),
        .I2(dt00_in[21]),
        .O(sel0[21]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_11__0
       (.I0(dt0__93[6]),
        .I1(dt1__15),
        .I2(dt00_in[6]),
        .O(sel0[6]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_12
       (.I0(dt0__93[20]),
        .I1(dt1__15),
        .I2(dt00_in[20]),
        .O(sel0[20]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_12__0
       (.I0(dt0__93[5]),
        .I1(dt1__15),
        .I2(dt00_in[5]),
        .O(sel0[5]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_13
       (.I0(dt0__93[19]),
        .I1(dt1__15),
        .I2(dt00_in[19]),
        .O(sel0[19]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_13__0
       (.I0(dt0__93[4]),
        .I1(dt1__15),
        .I2(dt00_in[4]),
        .O(sel0[4]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_14
       (.I0(dt0__93[18]),
        .I1(dt1__15),
        .I2(dt00_in[18]),
        .O(sel0[18]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_14__0
       (.I0(dt0__93[3]),
        .I1(dt1__15),
        .I2(dt00_in[3]),
        .O(sel0[3]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_15
       (.I0(dt0__93[17]),
        .I1(dt1__15),
        .I2(dt00_in[17]),
        .O(sel0[17]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_15__0
       (.I0(dt0__93[2]),
        .I1(dt1__15),
        .I2(dt00_in[2]),
        .O(sel0[2]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_16
       (.I0(dt0__93[1]),
        .I1(dt1__15),
        .I2(dt00_in[1]),
        .O(sel0[1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_16__0
       (.CI(integral1_i_17__0_n_0),
        .CO({NLW_integral1_i_16__0_CO_UNCONNECTED[3:2],integral1_i_16__0_n_2,integral1_i_16__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_integral1_i_16__0_O_UNCONNECTED[3],dt0__93[31:29]}),
        .S({1'b0,integral1_i_20_n_0,integral1_i_21_n_0,integral1_i_22_n_0}));
  LUT1 #(
    .INIT(2'h2)) 
    integral1_i_17
       (.I0(dt00_in[0]),
        .O(sel0[0]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_17__0
       (.CI(integral1_i_18__0_n_0),
        .CO({integral1_i_17__0_n_0,integral1_i_17__0_n_1,integral1_i_17__0_n_2,integral1_i_17__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0__93[28:25]),
        .S({integral1_i_23_n_0,integral1_i_24_n_0,integral1_i_25_n_0,integral1_i_26_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_18
       (.CI(integral1_i_19_n_0),
        .CO({integral1_i_18_n_0,integral1_i_18_n_1,integral1_i_18_n_2,integral1_i_18_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0__93[16:13]),
        .S({integral1_i_22__0_n_0,integral1_i_23__0_n_0,integral1_i_24__0_n_0,integral1_i_25__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_18__0
       (.CI(integral1_i_19__0_n_0),
        .CO({integral1_i_18__0_n_0,integral1_i_18__0_n_1,integral1_i_18__0_n_2,integral1_i_18__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0__93[24:21]),
        .S({integral1_i_27_n_0,integral1_i_28_n_0,integral1_i_29_n_0,integral1_i_30_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_19
       (.CI(integral1_i_20__0_n_0),
        .CO({integral1_i_19_n_0,integral1_i_19_n_1,integral1_i_19_n_2,integral1_i_19_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0__93[12:9]),
        .S({integral1_i_26__0_n_0,integral1_i_27__0_n_0,integral1_i_28__0_n_0,integral1_i_29__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_19__0
       (.CI(integral1_i_18_n_0),
        .CO({integral1_i_19__0_n_0,integral1_i_19__0_n_1,integral1_i_19__0_n_2,integral1_i_19__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0__93[20:17]),
        .S({integral1_i_31_n_0,integral1_i_32_n_0,integral1_i_33_n_0,integral1_i_34__0_n_0}));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_1__0
       (.I0(dt0__93[16]),
        .I1(dt1__15),
        .I2(dt00_in[16]),
        .O(sel0[16]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_2
       (.I0(dt0__93[30]),
        .I1(dt1__15),
        .I2(dt00_in[30]),
        .O(sel0[30]));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_20
       (.I0(dt00_in[31]),
        .O(integral1_i_20_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_20__0
       (.CI(integral1_i_21__0_n_0),
        .CO({integral1_i_20__0_n_0,integral1_i_20__0_n_1,integral1_i_20__0_n_2,integral1_i_20__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0__93[8:5]),
        .S({integral1_i_30__0_n_0,integral1_i_31__0_n_0,integral1_i_32__0_n_0,integral1_i_33__0_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_21
       (.I0(dt00_in[30]),
        .O(integral1_i_21_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 integral1_i_21__0
       (.CI(1'b0),
        .CO({integral1_i_21__0_n_0,integral1_i_21__0_n_1,integral1_i_21__0_n_2,integral1_i_21__0_n_3}),
        .CYINIT(integral1_i_34_n_0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(dt0__93[4:1]),
        .S({integral1_i_35_n_0,integral1_i_36_n_0,integral1_i_37_n_0,integral1_i_38_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_22
       (.I0(dt00_in[29]),
        .O(integral1_i_22_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_22__0
       (.I0(dt00_in[16]),
        .O(integral1_i_22__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_23
       (.I0(dt00_in[28]),
        .O(integral1_i_23_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_23__0
       (.I0(dt00_in[15]),
        .O(integral1_i_23__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_24
       (.I0(dt00_in[27]),
        .O(integral1_i_24_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_24__0
       (.I0(dt00_in[14]),
        .O(integral1_i_24__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_25
       (.I0(dt00_in[26]),
        .O(integral1_i_25_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_25__0
       (.I0(dt00_in[13]),
        .O(integral1_i_25__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_26
       (.I0(dt00_in[25]),
        .O(integral1_i_26_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_26__0
       (.I0(dt00_in[12]),
        .O(integral1_i_26__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_27
       (.I0(dt00_in[24]),
        .O(integral1_i_27_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_27__0
       (.I0(dt00_in[11]),
        .O(integral1_i_27__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_28
       (.I0(dt00_in[23]),
        .O(integral1_i_28_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_28__0
       (.I0(dt00_in[10]),
        .O(integral1_i_28__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_29
       (.I0(dt00_in[22]),
        .O(integral1_i_29_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_29__0
       (.I0(dt00_in[9]),
        .O(integral1_i_29__0_n_0));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_2__0
       (.I0(dt0__93[15]),
        .I1(dt1__15),
        .I2(dt00_in[15]),
        .O(sel0[15]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_3
       (.I0(dt0__93[29]),
        .I1(dt1__15),
        .I2(dt00_in[29]),
        .O(sel0[29]));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_30
       (.I0(dt00_in[21]),
        .O(integral1_i_30_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_30__0
       (.I0(dt00_in[8]),
        .O(integral1_i_30__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_31
       (.I0(dt00_in[20]),
        .O(integral1_i_31_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_31__0
       (.I0(dt00_in[7]),
        .O(integral1_i_31__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_32
       (.I0(dt00_in[19]),
        .O(integral1_i_32_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_32__0
       (.I0(dt00_in[6]),
        .O(integral1_i_32__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_33
       (.I0(dt00_in[18]),
        .O(integral1_i_33_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_33__0
       (.I0(dt00_in[5]),
        .O(integral1_i_33__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_34
       (.I0(dt00_in[0]),
        .O(integral1_i_34_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_34__0
       (.I0(dt00_in[17]),
        .O(integral1_i_34__0_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_35
       (.I0(dt00_in[4]),
        .O(integral1_i_35_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_36
       (.I0(dt00_in[3]),
        .O(integral1_i_36_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_37
       (.I0(dt00_in[2]),
        .O(integral1_i_37_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    integral1_i_38
       (.I0(dt00_in[1]),
        .O(integral1_i_38_n_0));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_3__0
       (.I0(dt0__93[14]),
        .I1(dt1__15),
        .I2(dt00_in[14]),
        .O(sel0[14]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_4
       (.I0(dt0__93[28]),
        .I1(dt1__15),
        .I2(dt00_in[28]),
        .O(sel0[28]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_4__0
       (.I0(dt0__93[13]),
        .I1(dt1__15),
        .I2(dt00_in[13]),
        .O(sel0[13]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_5
       (.I0(dt0__93[27]),
        .I1(dt1__15),
        .I2(dt00_in[27]),
        .O(sel0[27]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_5__0
       (.I0(dt0__93[12]),
        .I1(dt1__15),
        .I2(dt00_in[12]),
        .O(sel0[12]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_6
       (.I0(dt0__93[26]),
        .I1(dt1__15),
        .I2(dt00_in[26]),
        .O(sel0[26]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_6__0
       (.I0(dt0__93[11]),
        .I1(dt1__15),
        .I2(dt00_in[11]),
        .O(sel0[11]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_7
       (.I0(dt0__93[25]),
        .I1(dt1__15),
        .I2(dt00_in[25]),
        .O(sel0[25]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_7__0
       (.I0(dt0__93[10]),
        .I1(dt1__15),
        .I2(dt00_in[10]),
        .O(sel0[10]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_8
       (.I0(dt0__93[24]),
        .I1(dt1__15),
        .I2(dt00_in[24]),
        .O(sel0[24]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_8__0
       (.I0(dt0__93[9]),
        .I1(dt1__15),
        .I2(dt00_in[9]),
        .O(sel0[9]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_9
       (.I0(dt0__93[23]),
        .I1(dt1__15),
        .I2(dt00_in[23]),
        .O(sel0[23]));
  LUT3 #(
    .INIT(8'hE2)) 
    integral1_i_9__0
       (.I0(dt0__93[8]),
        .I1(dt1__15),
        .I2(dt00_in[8]),
        .O(sel0[8]));
  LUT3 #(
    .INIT(8'hD0)) 
    \integral[31]_i_1 
       (.I0(clock_count_reg_n_0),
        .I1(new_target_angle_available),
        .I2(ps_ready_out),
        .O(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[0] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry_n_7),
        .Q(integral_out[0]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[10] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__1_n_5),
        .Q(integral_out[10]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[11] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__1_n_4),
        .Q(integral_out[11]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[12] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__2_n_7),
        .Q(integral_out[12]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[13] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__2_n_6),
        .Q(integral_out[13]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[14] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__2_n_5),
        .Q(integral_out[14]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[15] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__2_n_4),
        .Q(integral_out[15]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[16] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__3_n_7),
        .Q(integral_out[16]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[17] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__3_n_6),
        .Q(integral_out[17]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[18] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__3_n_5),
        .Q(integral_out[18]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[19] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__3_n_4),
        .Q(integral_out[19]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[1] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry_n_6),
        .Q(integral_out[1]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[20] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__4_n_7),
        .Q(integral_out[20]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[21] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__4_n_6),
        .Q(integral_out[21]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[22] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__4_n_5),
        .Q(integral_out[22]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[23] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__4_n_4),
        .Q(integral_out[23]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[24] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__5_n_7),
        .Q(integral_out[24]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[25] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__5_n_6),
        .Q(integral_out[25]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[26] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__5_n_5),
        .Q(integral_out[26]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[27] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__5_n_4),
        .Q(integral_out[27]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[28] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__6_n_7),
        .Q(integral_out[28]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[29] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__6_n_6),
        .Q(integral_out[29]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[2] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry_n_5),
        .Q(integral_out[2]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[30] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__6_n_5),
        .Q(integral_out[30]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[31] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__6_n_4),
        .Q(integral_out[31]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[3] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry_n_4),
        .Q(integral_out[3]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[4] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__0_n_7),
        .Q(integral_out[4]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[5] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__0_n_6),
        .Q(integral_out[5]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[6] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__0_n_5),
        .Q(integral_out[6]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[7] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__0_n_4),
        .Q(integral_out[7]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[8] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__1_n_7),
        .Q(integral_out[8]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    \integral_reg[9] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(integral0_carry__1_n_6),
        .Q(integral_out[9]),
        .R(integral));
  FDRE #(
    .INIT(1'b0)) 
    ps_ready_reg
       (.C(clock),
        .CE(1'b1),
        .D(ps_ready_in),
        .Q(ps_ready_out),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h80)) 
    \saved_target_angle[31]_i_1 
       (.I0(ps_ready_out),
        .I1(new_target_angle_available),
        .I2(clock_count_reg_n_0),
        .O(saved_target_angle));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[0] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[0]),
        .Q(\saved_target_angle_reg_n_0_[0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[10] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[10]),
        .Q(\saved_target_angle_reg_n_0_[10] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[11] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[11]),
        .Q(\saved_target_angle_reg_n_0_[11] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[12] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[12]),
        .Q(\saved_target_angle_reg_n_0_[12] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[13] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[13]),
        .Q(\saved_target_angle_reg_n_0_[13] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[14] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[14]),
        .Q(\saved_target_angle_reg_n_0_[14] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[15] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[15]),
        .Q(\saved_target_angle_reg_n_0_[15] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[16] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[16]),
        .Q(\saved_target_angle_reg_n_0_[16] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[17] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[17]),
        .Q(\saved_target_angle_reg_n_0_[17] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[18] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[18]),
        .Q(\saved_target_angle_reg_n_0_[18] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[19] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[19]),
        .Q(\saved_target_angle_reg_n_0_[19] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[1] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[1]),
        .Q(\saved_target_angle_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[20] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[20]),
        .Q(\saved_target_angle_reg_n_0_[20] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[21] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[21]),
        .Q(\saved_target_angle_reg_n_0_[21] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[22] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[22]),
        .Q(\saved_target_angle_reg_n_0_[22] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[23] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[23]),
        .Q(\saved_target_angle_reg_n_0_[23] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[24] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[24]),
        .Q(\saved_target_angle_reg_n_0_[24] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[25] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[25]),
        .Q(\saved_target_angle_reg_n_0_[25] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[26] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[26]),
        .Q(\saved_target_angle_reg_n_0_[26] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[27] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[27]),
        .Q(\saved_target_angle_reg_n_0_[27] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[28] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[28]),
        .Q(\saved_target_angle_reg_n_0_[28] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[29] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[29]),
        .Q(\saved_target_angle_reg_n_0_[29] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[2] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[2]),
        .Q(\saved_target_angle_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[30] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[30]),
        .Q(\saved_target_angle_reg_n_0_[30] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[31] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[31]),
        .Q(\saved_target_angle_reg_n_0_[31] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[3] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[3]),
        .Q(\saved_target_angle_reg_n_0_[3] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[4] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[4]),
        .Q(\saved_target_angle_reg_n_0_[4] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[5] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[5]),
        .Q(\saved_target_angle_reg_n_0_[5] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[6] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[6]),
        .Q(\saved_target_angle_reg_n_0_[6] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[7] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[7]),
        .Q(\saved_target_angle_reg_n_0_[7] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[8] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[8]),
        .Q(\saved_target_angle_reg_n_0_[8] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \saved_target_angle_reg[9] 
       (.C(clock),
        .CE(saved_target_angle),
        .D(target_angle[9]),
        .Q(\saved_target_angle_reg_n_0_[9] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[0] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[0]),
        .Q(timestamp_out[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[10] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[10]),
        .Q(timestamp_out[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[11] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[11]),
        .Q(timestamp_out[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[12] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[12]),
        .Q(timestamp_out[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[13] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[13]),
        .Q(timestamp_out[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[14] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[14]),
        .Q(timestamp_out[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[15] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[15]),
        .Q(timestamp_out[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[16] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[16]),
        .Q(timestamp_out[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[17] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[17]),
        .Q(timestamp_out[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[18] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[18]),
        .Q(timestamp_out[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[19] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[19]),
        .Q(timestamp_out[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[1] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[1]),
        .Q(timestamp_out[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[20] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[20]),
        .Q(timestamp_out[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[21] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[21]),
        .Q(timestamp_out[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[22] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[22]),
        .Q(timestamp_out[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[23] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[23]),
        .Q(timestamp_out[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[24] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[24]),
        .Q(timestamp_out[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[25] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[25]),
        .Q(timestamp_out[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[26] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[26]),
        .Q(timestamp_out[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[27] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[27]),
        .Q(timestamp_out[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[28] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[28]),
        .Q(timestamp_out[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[29] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[29]),
        .Q(timestamp_out[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[2] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[2]),
        .Q(timestamp_out[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[30] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[30]),
        .Q(timestamp_out[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[31] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[31]),
        .Q(timestamp_out[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[3] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[3]),
        .Q(timestamp_out[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[4] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[4]),
        .Q(timestamp_out[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[5] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[5]),
        .Q(timestamp_out[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[6] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[6]),
        .Q(timestamp_out[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[7] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[7]),
        .Q(timestamp_out[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[8] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[8]),
        .Q(timestamp_out[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timestamp_saved_reg[9] 
       (.C(clock),
        .CE(ps_ready_out),
        .D(timestamp_new[9]),
        .Q(timestamp_out[9]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
