// (c) Copyright 1995-2026 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:initial_math:1.0
// IP Revision: 1

(* X_CORE_INFO = "initial_math,Vivado 2021.1" *)
(* CHECK_LICENSE_TYPE = "pid_expand_time_initial_math_0_0,initial_math,{}" *)
(* CORE_GENERATION_INFO = "pid_expand_time_initial_math_0_0,initial_math,{x_ipProduct=Vivado 2021.1,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=initial_math,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module pid_expand_time_initial_math_0_0 (
  clock,
  angle,
  target_angle,
  new_target_angle_available,
  ps_ready_in,
  timestamp_new,
  error_in,
  integral_in,
  timestamp_in,
  ps_ready_out,
  error_out,
  integral_out,
  derivative_out,
  timestamp_out
);

(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN pid_expand_time_clock_0, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clock CLK" *)
input wire clock;
input wire [31 : 0] angle;
input wire [31 : 0] target_angle;
input wire new_target_angle_available;
input wire ps_ready_in;
input wire [31 : 0] timestamp_new;
input wire [31 : 0] error_in;
input wire [31 : 0] integral_in;
input wire [31 : 0] timestamp_in;
output wire [31 : 0] ps_ready_out;
output wire [31 : 0] error_out;
output wire [31 : 0] integral_out;
output wire [31 : 0] derivative_out;
output wire [31 : 0] timestamp_out;

  initial_math inst (
    .clock(clock),
    .angle(angle),
    .target_angle(target_angle),
    .new_target_angle_available(new_target_angle_available),
    .ps_ready_in(ps_ready_in),
    .timestamp_new(timestamp_new),
    .error_in(error_in),
    .integral_in(integral_in),
    .timestamp_in(timestamp_in),
    .ps_ready_out(ps_ready_out),
    .error_out(error_out),
    .integral_out(integral_out),
    .derivative_out(derivative_out),
    .timestamp_out(timestamp_out)
  );
endmodule
