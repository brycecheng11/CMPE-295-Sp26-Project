vopt +acc=npr -l elaborate.log -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.pid_expand_time xil_defaultlib.glbl -o pid_expand_time_opt
