onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib pid_expand_time_opt

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure
view signals

do {pid_expand_time.udo}

run -all

quit -force
