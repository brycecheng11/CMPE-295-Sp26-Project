vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xil_defaultlib

vmap xil_defaultlib questa_lib/msim/xil_defaultlib

vlog -work xil_defaultlib  -incr -mfcu \
"../../../bd/pid_expand_time/ip/pid_expand_time_k_math_0_0/sim/pid_expand_time_k_math_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_prev_value_flip_flop_0_0/sim/pid_expand_time_prev_value_flip_flop_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_term_calculation_0_0/sim/pid_expand_time_term_calculation_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_velocity_calculation_0_0/sim/pid_expand_time_velocity_calculation_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_initial_math_0_0/sim/pid_expand_time_initial_math_0_0.v" \
"../../../bd/pid_expand_time/sim/pid_expand_time.v" \


vlog -work xil_defaultlib \
"glbl.v"

