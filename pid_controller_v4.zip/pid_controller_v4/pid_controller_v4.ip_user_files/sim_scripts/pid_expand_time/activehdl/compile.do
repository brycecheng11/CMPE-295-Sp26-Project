vlib work
vlib activehdl

vlib activehdl/xil_defaultlib

vmap xil_defaultlib activehdl/xil_defaultlib

vlog -work xil_defaultlib  -v2k5 \
"../../../bd/pid_expand_time/ip/pid_expand_time_k_math_0_0/sim/pid_expand_time_k_math_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_prev_value_flip_flop_0_0/sim/pid_expand_time_prev_value_flip_flop_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_term_calculation_0_0/sim/pid_expand_time_term_calculation_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_velocity_calculation_0_0/sim/pid_expand_time_velocity_calculation_0_0.v" \
"../../../bd/pid_expand_time/ip/pid_expand_time_initial_math_0_0/sim/pid_expand_time_initial_math_0_0.v" \
"../../../bd/pid_expand_time/sim/pid_expand_time.v" \


vlog -work xil_defaultlib \
"glbl.v"

