onbreak {quit -force}
onerror {quit -force}

asim +access +r +m+pid_expand_time -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.pid_expand_time xil_defaultlib.glbl

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure

do {pid_expand_time.udo}

run -all

endsim

quit -force
